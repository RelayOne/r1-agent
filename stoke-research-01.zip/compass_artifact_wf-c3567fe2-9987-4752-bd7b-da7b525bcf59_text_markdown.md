# Observability patterns for AI coding agent rules

**Every production service needs observability built in from the first commit, not bolted on after the first outage.** This report synthesizes the most comprehensive, actionable observability patterns across ten domains — OpenTelemetry, structured logging, metrics design, alerting, dashboards, incident response, health checks, cost management, production debugging, and existing AI agent rule formats — specifically structured for encoding into AI coding agent instruction files like SKILL.md, .cursorrules, or similar. The patterns below represent battle-tested practices from Google SRE, Grafana Labs, and the broader cloud-native ecosystem as of early 2026. OpenTelemetry has emerged as the universal standard, with **85% of organizations** using or investigating it in production, while observability costs now consume **10–30% of infrastructure budgets** at scale, making efficiency-aware instrumentation a first-class design concern.

---

## OpenTelemetry instrumentation is the foundation

**Initialize the OpenTelemetry SDK before any other imports or library loading** — this is the single most common silent failure mode. Late initialization returns no-op providers, and instrumentation libraries permanently grab references to them, producing zero telemetry with zero errors.

The recommended approach is **hybrid instrumentation**: start with auto-instrumentation for broad HTTP/DB/gRPC coverage, then layer manual instrumentation for business-critical paths. Auto-instrumentation takes minutes to set up and covers standard framework calls. Manual instrumentation adds domain-specific context — order IDs, customer tiers, validation outcomes — that auto-instrumentation cannot capture. Every service must set three required resource attributes: **`service.name`**, **`service.version`**, and **`deployment.environment`**.

For trace context propagation, **W3C TraceContext is the default** across all OTel SDKs. The `traceparent` header carries version, trace-id (128-bit), parent-id (64-bit), and trace-flags. Add B3 propagation only for legacy Zipkin compatibility. Context propagation across Kafka and message queues requires explicit injection/extraction — it is not automatic. In async code, context is thread-local; spawning threads or using thread pools loses context unless explicitly captured (Java: `Context.current().wrap()`; Python: `contextvars`; Node.js: `AsyncLocalStorage`).

For sampling, use **`ParentBasedTraceIdRatio`** for head-based sampling where children follow the parent's decision. Tail-based sampling in the OTel Collector keeps all errors and high-latency traces regardless of sample rate. The critical constraint: all spans for a given trace must reach the same collector instance, requiring a load-balancing exporter routing by `traceID` in a two-tier agent-gateway architecture. Always generate RED metrics before sampling — you cannot derive accurate rate/error/duration metrics from sampled trace data.

**SDK initialization checklist for every service:**

1. Create Resource with `service.name`, `service.version`, `deployment.environment`
2. Create OTLP exporter (gRPC port 4317 or HTTP port 4318)
3. Create `BatchSpanProcessor` (never `SimpleSpanProcessor` in production)
4. Create `TracerProvider` with resource and processor
5. Register as global provider before any instrumentation
6. Register shutdown handler (`atexit`, `defer`, JVM shutdown hook`) to flush pending telemetry

The **OTel Collector** should deploy in a combined agent-plus-gateway pattern for production Kubernetes. Agents run as DaemonSets for local collection and batching. Gateways run as Deployments for tail sampling, filtering, and multi-backend export. Always include the `memory_limiter` processor before `batch` in every pipeline. Monitor collector health via internal telemetry on port 8888 and the health check extension on port 13133.

Semantic conventions have stabilized significantly: HTTP attributes now use `http.request.method` (not the deprecated `http.method`), `http.response.status_code` (not `http.status_code`), and `url.full` (not `http.url`). Database conventions are stable for MySQL, PostgreSQL, and SQL Server. The GenAI semantic conventions for LLM agent observability are under active development.

---

## Structured logging demands JSON, correlation, and discipline

**Every log entry must be structured JSON with trace correlation.** The minimum viable log schema includes `timestamp` (ISO 8601), `level`, `message`, `service`, `trace_id`, `span_id`, and request-scoped context like `request_id` and `user_id`. Two established schemas exist: the **OpenTelemetry Log Data Model** (with `SeverityNumber` 1–24, `Body`, `Resource`, and `Attributes` fields) and the **Elastic Common Schema** (with `@timestamp`, `log.level`, `message`, `service.name`, `trace.id`, `error.stack_trace`). The OTel approach uses existing logging libraries with log bridges/appenders that translate to the data model — it does not recommend emitting logs directly in the OTel format.

**Correlation ID propagation** is non-negotiable. Set trace context once at request entry via middleware, and every downstream log entry automatically includes `trace_id` and `span_id`. In Java, use MDC (`MDC.put("trace_id", traceId)`). In Python, use `contextvars.ContextVar`. In Node.js, use `AsyncLocalStorage`. In Go, pass `context.Context` explicitly and use `slog.With()` for persistent attributes. In .NET, use Serilog's `LogContext.PushProperty()`.

**Log level discipline prevents alert fatigue and cost overruns.** TRACE and DEBUG are for development only — never enabled in production by default. INFO covers normal operations (server started, request completed, job finished) and should be the majority of production logs. WARN indicates unexpected but recoverable situations where the system continues working. ERROR means an operation failed but the process continues. FATAL means unrecoverable failure causing application termination. The most common mistakes: logging errors as warnings (masks real problems), over-using INFO for debug-level detail (increases costs), and using ERROR for expected/handled exceptions like 404 Not Found.

**Sensitive data masking** follows a preference hierarchy: don't log it at all (use opaque IDs), mask at source (application-level), mask in pipeline (OTel Collector processors), or mask at storage. The OTel Collector supports a three-processor PII pipeline: the `attributes` processor for fast key-based hashing/deletion, the `redaction` processor for regex scanning of remaining values (SSNs, credit cards, emails, phone numbers), and the `transform` processor for body manipulation using OTTL. Process in that order to minimize expensive regex evaluation.

**Recommended structured logging libraries by language:** Go uses `slog` (stdlib since Go 1.21) or `zerolog` (zero-allocation). Python uses `structlog` with `JSONRenderer` for production and `ConsoleRenderer` for development. Node.js uses `pino` (faster than winston, JSON-native). .NET uses `serilog` with `CompactJsonFormatter`. Java uses Logback with `logstash-logback-encoder` or ECS logging libraries.

---

## Metrics need RED for services, USE for resources, and cardinality control

The **RED method** (Rate, Errors, Duration) applies to every request-driven service and serves as a proxy for user happiness. Three concrete Prometheus metrics cover it: `http_requests_total` counter with method/path/status labels, `http_request_duration_seconds` histogram with method/path labels, and PromQL queries for `rate()`, error ratio, and `histogram_quantile()` at p50/p95/p99. The **USE method** (Utilization, Saturation, Errors) applies to every infrastructure resource — CPU, memory, disk, network. RED tells you about your users; USE tells you about your machines.

**Histogram bucket selection** directly affects percentile accuracy and cardinality cost. The Prometheus defaults (`{.005, .01, .025, .05, .1, .25, .5, 1, 2.5, 5, 10}`) work for typical web services. Customize buckets per service type: fast APIs need more resolution at low latencies (`{0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1}`), while batch jobs need resolution at higher values (`{1, 5, 10, 30, 60, 120, 300, 600}`). Align bucket boundaries with SLO thresholds — if your SLO is "99% < 300ms," include buckets at 200ms, 300ms, and 400ms. Each bucket creates a separate time series, so a histogram with 12 buckets across 3 labels with moderate cardinality can produce **30,000+ series from a single metric**.

**Cardinality explosion is the most expensive observability mistake.** Never use user IDs, request IDs, trace IDs, full URLs with path parameters, pod UIDs, or any unbounded set as metric labels. The rule: if a label could have 10,000 unique values in production, it belongs in a trace span attribute, not a metric label. Detect cardinality problems with `topk(20, count by (__name__) ({__name__=~".+"}))`. Prevent them with metric relabeling at scrape time — `labeldrop` for known offenders, regex replacement to normalize dynamic paths (`/users/[0-9]+` → `/users/:id``), and recording rules for pre-aggregation.

**Prometheus naming conventions** require snake_case, base units (seconds not milliseconds, bytes not kilobytes), `_total` suffix for counters, `_seconds` for durations, `_bytes` for sizes, `_info` for info metrics, and colons reserved exclusively for recording rules (`job:http_requests:rate5m`). Don't embed label names in metric names — use `{method="GET"}` not `http_get_requests`.

**SLI/SLO metrics** follow the formula: SLI = good events / total events. For a 99.9% availability SLO over 30 days, the error budget is 0.1% = **43.2 minutes of allowed downtime**. Define availability SLI as `sum(rate(http_requests_total{status!~"5.."}[30d])) / sum(rate(http_requests_total[30d]))` and latency SLI as `sum(rate(http_request_duration_seconds_bucket{le="0.3"}[30d])) / sum(rate(http_request_duration_seconds_count[30d]))`.

---

## Alerting on burn rates eliminates fatigue

The Google SRE multi-window multi-burn-rate approach (documented as "Option 6" in the SRE Workbook) is the gold standard. **Burn rate** measures how fast a service consumes its error budget relative to the SLO window. A burn rate of 1 means even consumption over 30 days; a burn rate of 14.4 means the budget exhausts in roughly 2 days.

Each alert uses two windows: a long window to detect sustained issues and a short window (1/12 of the long window) to confirm the issue is still ongoing. This prevents stale alerts from firing after resolution. The standard four tiers are:

- **Critical page**: burn rate 14.4, windows 1h/5m, consumes 2% of budget
- **Critical page**: burn rate 6, windows 6h/30m, consumes 5% of budget
- **Warning ticket**: burn rate 3, windows 1d/2h, consumes 10% of budget
- **Warning ticket**: burn rate 1, windows 3d/6h, consumes 10% of budget

Google explicitly warns against using `for` duration clauses in SLO alerting — intermittent error spikes reset the timer, causing missed alerts even while consuming significant error budget.

**Alertmanager configuration** should group alerts by `['alertname', 'cluster', 'service']`, use `group_wait: 30s` for critical and `1-2m` for warnings, `repeat_interval: 4h` for critical and `12h` for warnings, and route critical alerts to PagerDuty with `continue: true` to also send to Slack for visibility. Inhibition rules suppress warnings when a critical alert exists for the same service, and suppress all alerts for a cluster when a `ClusterDown` alert fires. Every alert rule must include `runbook_url` and `dashboard_url` annotations with dynamic templating to pre-fill filters.

**Error budget policies** govern deployment velocity. When budget is healthy (>50% remaining), ship features normally. When budget drops below 20%, reduce deployment frequency. When budget is exhausted, **freeze all non-critical changes** and redirect all effort to reliability. This policy requires organizational buy-in — leadership must support feature freezes when error budgets are exhausted.

---

## Dashboards belong in version control, not the UI

**All dashboards should be created through code** — Grafana JSON provisioning, Terraform with the `grafana/grafana` provider, or Grafonnet/jsonnet for programmatic generation. Users get write access for temporary investigation, but CI/CD overwrites manual changes. Code-review dashboards like code; reviewers should be application experts who can validate query correctness.

The **four golden signals** (latency, traffic, errors, saturation) should appear in a single row at the top of every service dashboard, creating a consistent scanning pattern during incidents. Latency uses `histogram_quantile()` at p50/p95/p99. Traffic uses `sum(rate(http_requests_total[5m]))`. Errors use `sum(rate(http_requests_total{status=~"5.."}[5m])) / sum(rate(http_requests_total[5m])) * 100`. Saturation tracks CPU/memory utilization against limits.

**Dashboard anti-patterns** to encode as rules: no more than 10–15 panels per dashboard (50-panel dashboards are overwhelming and slow), never show only average latency (hides long-tail problems), never use red thresholds for non-critical metrics (trains people to ignore red), and never mix data sources for the same metric. Use `rate()` for dashboards and `irate()` for alerting on spikes. Rate windows should be at least 4× the scrape interval. Grafana 12 introduced a v2 dashboard schema that decouples layout from panel configuration, producing cleaner Git diffs, and Git Sync enables bi-directional sync with GitHub repos.

---

## Incident response follows a structured playbook

**Severity classification** determines response speed and communication cadence. SEV-1 is a critical issue affecting all or most users with revenue impact — response within 15 minutes, 24/7 effort, public notification, incident commander assigned. SEV-2 is a critical system issue degrading core functionality for many users — response within 30 minutes, extended hours. SEV-3 affects a subset of users with partial loss — response within 2–4 hours, high-urgency page to service team. SEV-4 is minor with minimal customer impact — business hours, JIRA ticket. When in doubt, classify higher; it is easier to downgrade than to explain a delayed response.

The **incident commander** coordinates but does not make technical changes. Responsibilities: declare the incident, establish severity, create communication channels (`#inc-YYYY-MM-DD-service-description`), assign roles (Communications Lead, Operations Lead, Scribe), maintain timeline, provide regular updates every 15–30 minutes for SEV-1/2, decide escalation, and initiate postmortem. Deep technical knowledge is not required — communication skills, rapid decision-making, and the willingness to maintain order on a call are the critical attributes.

**Blameless postmortems** must be held within 24–72 hours of resolution, last 30–60 minutes maximum, and follow the "5 Whys" to dig past human error to systemic causes. The template includes metadata (incident ID, severity, duration), impact (affected users, failed transactions, revenue impact, SLA breach status), a detailed UTC timeline with sources, root cause analysis, contributing factors, what went well, what went wrong, and prioritized action items with owners, due dates, and ticket references. The facilitator redirects any blame to "What about our process made this likely?" Publish broadly — lessons almost always apply beyond the immediate team.

**ChatOps** automates the incident lifecycle: alert fires → bot creates incident channel → assigns roles → pages on-call → team collaborates → bot tracks timeline → incident resolved → channel archived → postmortem generated. Tools like `incidentbot` integrate with Confluence, Jira, PagerDuty, and Statuspage. All operational commands go through chat to create an automatic audit trail.

---

## Health checks must distinguish liveness from readiness

Kubernetes provides three probe types with distinct purposes that must never be conflated. **Startup probes** disable liveness and readiness checks until they succeed, protecting slow-starting containers from premature termination — set `failureThreshold × periodSeconds` to allow 2–5 minutes. **Liveness probes** detect deadlocks and restart the container — check only that the process is functional with a simple 200 OK, **never check external dependencies**. **Readiness probes** determine if the pod can serve traffic — check critical dependencies like database connection pools and required caches, and return structured JSON with per-dependency status and latency.

The most dangerous mistake is including dependency checks in liveness probes. When all instances include deep health checks on a shared dependency like a database, a brief database outage causes all pods to fail liveness, triggering cascading restarts and a complete outage even though instances could serve cached responses. Mitigation: only include critical dependencies in readiness checks, add strict timeouts to every dependency check, implement circuit breaker patterns, and consider graceful degradation (read-only mode) instead of marking unhealthy.

**Recommended probe configuration:**

- Startup: `periodSeconds: 5`, `failureThreshold: 60` (300s max startup)
- Liveness: `periodSeconds: 15`, `failureThreshold: 3`, `timeoutSeconds: 3` (45s tolerance)
- Readiness: `periodSeconds: 5`, `failureThreshold: 3`, `timeoutSeconds: 3` (15s removal)

Run probes on a separate port or lightweight handler to avoid competing with real request traffic under load.

---

## Observability costs can exceed compute costs

**Observability spending** has become one of the largest line items in cloud budgets. OpenAI projected spending **~$170–200 million on Datadog alone in 2025**. Coinbase's annual Datadog bill hit $65 million in 2022. Gartner reports 36% of enterprise clients spend over $1 million annually on observability, with over 50% of that going to logs alone. The OneUptime analysis found organizations spending **70% of infrastructure budget** on observability tools at extreme scale. Wakefield Research found 98% of companies experience unexpected cost spikes, with 51% experiencing them monthly.

**Datadog** charges per-host ($15–34/month) with high-water-mark billing that bills the peak hour's count for the entire month. Custom metrics cost $5 per 100/month and can constitute up to 52% of the total bill. All OpenTelemetry metrics count as custom. **CloudWatch** charges $0.50/GB for log ingestion with indefinite default retention — teams commonly underestimate spend by 2–4×. **Grafana Cloud** uses consumption-based pricing with no per-host charges and is typically **60–80% cheaper** than Datadog for equivalent coverage. **New Relic** charges per-user ($49–$419/month) plus per-GB data ingestion ($0.30–$0.50/GB) after 100GB free.

**Cost optimization strategies** that every AI coding agent should enforce: use the OTel Collector as a pre-processing layer for filtering, sampling, and enrichment before vendor ingestion. Head-based sampling at 10–20% captures enough for performance analysis. Tail-based sampling retains all errors and slow requests while achieving 70–80% cost savings. Drop health check and readiness probe logs at ingestion. Set explicit log retention policies (default indefinite retention is a cost trap). Replace high-cardinality attributes in metrics (`/users/[a-f0-9-]+` → `/users/{id}`). One mid-sized e-commerce platform reduced monthly observability costs from **$25,000 to $6,500** with comprehensive OTel Collector optimization.

---

## Production debugging works without SSH

The modern debugging toolkit eliminates SSH access entirely. **Structured logs with request context** form the foundation — every log entry includes `trace_id`, `span_id`, and `request_id` so you can reconstruct the complete request lifecycle across services. **Distributed tracing** provides waterfall views of request flow; identify slow spans by width, error spans by status, and gaps between child span end and parent span end that reveal unmeasured work.

**Ephemeral debug containers** (`kubectl debug -it <pod> --image=nicolaka/netshoot --target=app`) inject debugging tools into running pods without modifying deployments. This is the only option for debugging distroless containers with no shell. Ephemeral containers share the PID namespace with the target container. For node-level debugging, `kubectl debug node/<node-name> -it --image=ubuntu` mounts the host filesystem at `/host`.

**Feature flags for debug mode** enable per-user or per-tenant verbose logging without affecting other traffic. Create a multivariate feature flag that adjusts log level at runtime — DEBUG for the affected user, INFO for everyone else. Debug headers (`X-Debug: true`) activate verbose response metadata gated behind authentication. Time-box all debug activation to automatically revert after N minutes to prevent log explosion.

**Continuous profiling** with Grafana Pyroscope or Parca adds always-on flame graphs with **<5% overhead**. Parca uses eBPF-based profiling deployed as a DaemonSet, profiling all processes on each node with auto-discovery of Kubernetes objects. Go services should expose pprof endpoints (`/debug/pprof/`) on a separate port behind authentication — endpoints have zero cost until called, and CPU profiling adds ~1–2% during capture only. The critical security note: CVE-2019-11248 exposed pprof on unauthenticated ports, and **296,000+ exposed Prometheus instances** were discovered in 2024. Always run debug endpoints on a separate port with auth middleware, IP whitelisting, and rate limiting.

---

## Existing AI agent rule files establish the pattern

Several production-quality observability rule formats exist for AI coding agents. **Elastic's `agent-skills` repository** provides official SKILL.md files for observability including `elastic-observability` (log investigation), SLO management, APM service health, and LLM monitoring — each with YAML frontmatter, references directories for deep docs, and helper scripts. The **`petekp/agent-skills` agent-telemetry skill** bridges static code analysis and runtime execution by implementing structured JSON logging with correlation IDs, exposing logs via dev-only endpoints, and documenting query commands in CLAUDE.md so coding agents can independently diagnose issues.

The **Cursor Directory** (`cursor.directory/rules/observability`) maintains curated rules mandating OpenTelemetry for distributed tracing, span propagation across all service boundaries, `otel.Tracer` for spans and `otel.Meter` for metrics, log correlation via trace ID injection, JSON-formatted logs, appropriate log levels, unique request IDs, SLI definitions, and cardinality awareness. The **Orchestra-Research/AI-Research-SKILLs** repository covers 87 skills across 22 categories including LangSmith and Phoenix for AI observability.

Common patterns across all discovered rule files: structured JSON logging enforcement (never printf-style), OpenTelemetry as the universal default, context propagation across all service boundaries, cardinality awareness in labels, SLI/SLO definition requirements, alert configuration for key conditions, log level discipline (INFO/WARN in production, DEBUG only temporarily), request ID correlation in all logs, agent-friendly telemetry with queryable endpoints, and progressive disclosure where SKILL.md contains high-level rules while deeper documentation loads on demand from references directories.

---

## Conclusion

The observability landscape in 2026 has converged on a clear set of enforceable patterns. **OpenTelemetry is the universal instrumentation standard** — initialize it first, use hybrid auto-plus-manual instrumentation, propagate W3C TraceContext everywhere, and deploy collectors in agent-gateway topology. **Structured JSON logging with trace correlation** is non-negotiable; every log must carry `trace_id` for cross-signal linking. **Metrics must follow RED for services and USE for resources** with relentless cardinality control. **Alerting must use multi-window multi-burn-rate SLO alerts** to eliminate fatigue — the Google SRE approach with four tiers (14.4×/1h, 6×/6h, 3×/1d, 1×/3d) remains the gold standard. **Dashboards belong in version control** with four golden signals at the top of every service dashboard. **Health checks must never conflate liveness with readiness** — dependency checks in liveness probes cause cascading failures. **Cost optimization is a design concern**, not an afterthought — the OTel Collector as a pre-processing layer, tail-based sampling that preserves all errors, and explicit retention policies can reduce observability costs by 60–75%. These patterns are directly encodable into AI agent instruction files, and the SKILL.md format with frontmatter, concise rules, and progressive-disclosure references directories has emerged as the most effective structure for doing so.