# Production scaling failures and performance patterns for Go and TypeScript

**The most common production outages in polyglot systems stem from connection pool exhaustion, goroutine/event loop resource leaks, and cache stampedes — not from algorithmic complexity.** This report distills quantitative thresholds, battle-tested formulas, and detection patterns across PostgreSQL, MongoDB, Redis, and Kafka for systems handling 10K+ concurrent connections. Each section provides failure modes, root causes, monitoring approaches, and mitigation patterns suitable for encoding into AI coding agent rules.

---

## 1. Connection pool exhaustion kills services silently

The canonical PostgreSQL pool sizing formula, authored by **Kevin Grittner** on the PostgreSQL mailing list in 2011, is:

```
pool_size = (core_count × 2) + effective_spindle_count
```

`core_count` excludes HyperThreading — physical cores only. `effective_spindle_count` is 0 when the working set fits in RAM, approaches actual spindle count as cache hit ratio falls, and should be treated as **1 for SSDs**. A 4-core server with SSD yields `(4 × 2) + 1 = 9` active connections. This formula works because blocked-on-disk processes free CPU for additional processes. PostgreSQL forks a new OS process per connection consuming **~10 MB each**, and `GetSnapshotData()` must iterate all process slots — so more connections produce worse performance, not better.

**Divide the formula result across application instances**: `per_instance_pool = formula_result / num_instances`. Reserve 3–10 connections for admin and monitoring. With PgBouncer fronting PostgreSQL, set `max_connections = 200–400` on the database and let PgBouncer handle thousands of client connections at ~2 KB memory each.

**PgBouncer transaction mode is the production default but carries sharp edges.** `SET SESSION` and plain `SET` silently break — only `SET LOCAL` within a transaction is safe. LISTEN/NOTIFY is unusable because clients get different backends per transaction. Prepared statements were completely broken before v1.21; since v1.21, protocol-level prepared statements work via internal name remapping (`PGBOUNCER_{unique_id}`), reducing CPU ~30% in production benchmarks. SQL-level `PREPARE ... AS` still doesn't work. Session-level advisory locks also fail in transaction mode — a critical trap when using `pg_try_advisory_lock()` for leader election through PgBouncer.

**MongoDB pool math is multiplicative across replica set members.** Default `maxPoolSize = 100` per server means a 3-member replica set consumes 300 outgoing connections per app instance. Four app servers produce 1,200 total. The tuning formula is `maxPoolSize = avg_concurrent_requests × avg_query_time_sec × 1.5`. Production defaults should include `waitQueueTimeoutMS: 5000` to fail fast and `maxIdleTimeMS: 30000` to reclaim idle connections.

**Redis connection strategy differs by language runtime.** Node.js clients (ioredis, node-redis) use single-connection multiplexing — one TCP connection handles all commands via implicit pipelining. Go and Java clients use connection pooling. Multiplexing cannot support blocking commands (BLPOP, BRPOP, XREAD...BLOCK) — these stall the shared connection for all callers. After a Redis restart, reconnection storms from all clients simultaneously can cause 100% CPU. Mitigation: bounded pool sizes, exponential backoff, and `socket_connect_timeout`.

**Detection requires monitoring three signals.** For PostgreSQL: `pg_stat_activity` grouped by state (watch for `idle in transaction` > 10 minutes), connection count vs `max_connections` (alert at 80%), and `pg_blocking_pids()` for blocked processes. For PgBouncer: `SHOW POOLS` where `client_waiting > 0` sustained is a fire. For application pools: connection acquire time histograms spiking above **100ms** and `waitingCount > 0`.

---

## 2. Horizontal scaling creates five distinct trap categories

**Sticky sessions fail silently during scale events.** When a pinned server dies, all its sessions are lost — dropped connections, lost shopping carts, failed transactions. During scale-out, new pods receive zero traffic from existing sticky sessions, effectively nullifying the scaling action while old pods remain overloaded. The fix is an external session store (Redis adds ~1–3ms per lookup) or stateless JWT-based authentication.

**In-process cache divergence is the hardest problem to detect.** When each instance maintains its own cache, a database write invalidates data in one instance while others serve stale data. Meta improved TAO's cache consistency from **99.9999% to 99.99999999%** — illustrating that even 0.0001% inconsistency means millions of stale reads per day at scale. Mitigation requires layered defense: pub/sub invalidation (Redis pub/sub or Kafka CDC events) for immediate cache busting, mandatory TTLs as a safety net, and optionally replacing local caches with a distributed cache for consistency-critical data.

**Cron job duplication is the most common horizontal scaling bug.** With N instances, a scheduled job runs N times. Three leader election approaches ranked by infrastructure complexity:

- **Redis `SET job-lock {node-id} NX PX 10000`**: Simple, fast, already in most stacks. Single Redis point of failure acceptable for advisory locks.
- **PostgreSQL `pg_try_advisory_lock(2929)`**: No extra infrastructure. Session-level locks auto-release on connection drop. **Does not work with PgBouncer transaction pooling** — requires session mode.
- **etcd/ZooKeeper**: Strong consistency via Raft/Paxos. Required for correctness-critical coordination where Redlock's timing assumptions (as identified by Martin Kleppmann's 2016 critique — no fencing tokens, clock skew vulnerability) are unacceptable.

**Auto-scaling lag compounds across five components**: container image pull (2–30s), container startup (1–5s), application initialization (2–60s), connection pool warmup (1–10s), and cache warming (10s to minutes). Total cold-start spans **15 seconds to several minutes**. Kubernetes HPA checks metrics every 15 seconds by default. Go starts in ~100ms vs seconds for JVM frameworks — a meaningful advantage for rapid scaling. Mitigations: readiness probes gating on warmup completion, pre-warming synthetic requests to key endpoints, and maintaining buffer pods for immediate capacity.

**Scale-down requires a two-phase shutdown pattern.** In Go, call `isShuttingDown.Store(true)`, wait 5 seconds for load balancer drain (readiness probe fails), then call `srv.Shutdown(ctx)` with a 15-second timeout. Go's `http.Server.Shutdown()` is built-in: it stops accepting new connections and waits for in-flight requests. In Node.js, `server.close()` immediately closes idle keep-alive connections, causing a race where clients send requests just as the socket closes, producing TCP RST → 502 errors. Fix: set `Connection: close` header during drain. Docker's `CMD ["npm", "start"]` doesn't forward SIGTERM — use `CMD ["node", "src"]` or `dumb-init`.

---

## 3. Session architecture is a security-performance spectrum

**JWTs trade revocability for network independence.** A minimal JWT is ~300–400 bytes; with roles and custom claims it grows to **800–2000+ bytes**. Opaque tokens are 32–64 bytes. JWTs validate locally (no network call), while opaque tokens require an introspection call adding **10–50ms+ latency**. The production consensus is **JWTs for access tokens (speed) + opaque tokens for refresh tokens (revocability)**, used by Auth0, Ory, and most OAuth 2.0 implementations.

JWT-specific vulnerabilities demand explicit safeguards. Algorithm confusion attacks exploit the `alg` header: setting `alg: "none"` bypasses verification entirely, and switching from RS256 to HS256 lets attackers forge tokens using the server's public key as an HMAC secret. Always whitelist algorithms explicitly: `{ algorithms: ['RS256'] }`. Use **5–15 minute** access token expiry and asymmetric algorithms (RS256, ES256) for public APIs.

**Refresh token rotation with family tracking catches theft.** Each refresh token belongs to a "family" rooted in the original login. On refresh, the old token is invalidated and a new one issued. If a previously-rotated token is reused, the **entire family is invalidated**, forcing re-authentication — catching theft regardless of whether attacker or legitimate user refreshes first. The concurrent refresh race condition (multiple tabs, network retries) requires a **grace period of 10–30 seconds** where a rotated token can be reused idempotently.

**The gold standard for token storage** is access tokens in JavaScript memory (immune to both XSS and CSRF, lost on page refresh) with refresh tokens in `HttpOnly; Secure; SameSite=Strict` cookies. On page load, a silent `/refresh` call obtains a new access token. Required cookie attributes: `HttpOnly` (prevents JavaScript access), `Secure` (HTTPS only), `SameSite=Strict` (eliminates most CSRF). localStorage is vulnerable to XSS — any injected script can `localStorage.getItem('token')` and exfiltrate.

Use **absolute expiration on access tokens (15 minutes)** and **sliding window on refresh tokens (7–14 days, reset on each rotation)**. Regenerate session IDs on authentication to prevent session fixation.

---

## 4. Real-time synchronization demands architectural decisions at every layer

**WebSocket scaling beyond a single server requires Redis pub/sub fanout.** All WebSocket servers subscribe to Redis channels. When a message arrives on any server, it's published to the channel; Redis delivers to all subscribers; each server fans out to local clients. Socket.io provides `@socket.io/redis-adapter` that handles this automatically. AWS ALB natively supports WebSocket upgrades (increase idle timeout from default 60s to up to 4000s); NLB provides TCP passthrough for raw throughput. HAProxy requires `timeout tunnel 1h` for long-lived WebSocket connections.

**Connection limits per server** are bounded by file descriptors — Linux defaults to 1024 per process but can be raised to 100K–1M+ via `ulimit -n`. Practical production targets are **50K–100K concurrent connections** on commodity hardware. Each WebSocket connection consumes **~10–12 KB in Go** (goroutine + 4096-byte read/write buffers) and **~5–40 KB in Node.js** (ws library at ~5 KB, Socket.IO at ~40 KB). Discord achieves **~2 million concurrent users per gateway server** on Elixir/BEAM. Phoenix framework demonstrated 2 million concurrent WebSocket connections on a single machine.

**Presence systems must optimize for selective subscription.** Slack tracks 5+ million simultaneous WebSocket sessions with dedicated Presence Servers using consistent hashing. Their critical optimization: clients receive presence notifications only for users **visible on the current screen**, not the entire workspace — early broadcast-to-everyone architecture didn't scale. Standard heartbeat interval is **30 seconds**. Ghost user cleanup uses TTL-based keys in Redis: set heartbeat key with 60-second TTL, if not renewed the key expires and the user is marked offline.

**CRDTs and OT represent fundamentally different tradeoffs for collaborative editing.** OT (used by Google Docs) requires a central server and has hundreds of edge cases in transformation functions but low memory overhead. CRDTs (used by Figma, Notion) work offline, merge in any order, and guarantee convergence, but carry **16–32 bytes metadata per character** — a 10,000-character document grows from 10 KB to 320 KB. Figma discovered documents with **10+ million tombstones** (deleted element markers at 32 bytes each), consuming gigabytes. Their fix: aggressive compaction above 1 million tombstones, discarding history older than 7 days, achieving **90% file size reduction**. For new features, Figma adopted the **Eg-walker algorithm** — a hybrid that's "as fast as CRDTs at merging but with minimal memory overhead like OT." Yjs dominates benchmarks for sequential text editing and handles 10M+ character documents; Automerge 2.0 (Rust-based) achieves similar performance but uses more memory due to full history preservation.

**Reconnection uses state vectors for efficient delta sync.** Each client maintains `{ clientId: lastKnownClock }` mappings. On reconnection, the client sends its state vector; the server computes the delta of missing operations. Last-write-wins (LWW) resolves simple property conflicts (used by Figma for position, color). For text, CRDTs preserve concurrent editing intent where LWW would lose data.

---

## 5. Cache stampedes are solved with layered defense

**The XFetch algorithm provides mathematically optimal stampede prevention.** Formalized by Vattani, Chierichetti, and Lowenstein (VLDB 2015), the formula is:

```
should_recompute = (currentTime - delta × beta × log(rand(0,1))) >= expiry
```

Where `delta` is the last recomputation duration, `beta` is a tuning parameter (default 1.0; higher favors earlier recomputation), and `log(rand(0,1))` produces an exponentially distributed negative value. As the cache entry approaches expiration, the probability of triggering early recomputation increases. The paper proves this reduces stampede from **O(n) to O(1) expected recomputations** regardless of request rate.

**Go's `singleflight` is the essential in-process deduplication pattern.** The first goroutine executes the function; subsequent goroutines with the same key wait and receive the same result. It's ~150 lines of code using a `sync.Mutex` protecting a `map[string]*call`. Critical limitations: it works **within a single process only** — 10 replicas each have independent singleflight groups. Error propagation means all waiters receive the failing goroutine's error. Node.js equivalents include `cache-manager` v6+ (embeds `promise-coalesce`) and `Map<string, Promise>` patterns.

**Cross-node deduplication uses Redis SET NX + stale data fallback.** On cache miss, attempt `SET lock:{key} {unique_token} NX EX 5`. If acquired: recompute, update both fresh and stale cache keys, release lock. If not acquired: serve stale data from `stale:{key}` (with much longer TTL). Release locks atomically via Lua script to prevent accidentally releasing another client's lock. The Redis MemoLock pattern (inspired by Instagram) extends this with pub/sub: non-lock-holders subscribe to `notif:{key}` and wait for notification instead of polling.

**Facebook's memcache leases solved thundering herd at billion-request scale.** On cache miss, memcache issues a 64-bit lease token; only that client can SET the value. Others requesting the same key within 10 seconds wait and retry or receive stale data. Result: **peak DB query rates dropped from 17K/s to 1.3K/s**.

**Hot key detection and splitting prevents single-shard bottlenecks.** Redis is single-threaded — all operations for keys in the same hash slot hit one CPU core. Detect hot keys with `redis-cli --hotkeys` (requires LFU eviction policy), `OBJECT FREQ <key>`, or proxy-level sampling (Roblox's approach at **1.38 billion QPS**). Split hot keys by appending a random suffix (`hot:K#0` through `hot:K#N`), writing to all N shards and reading from a random one. This provides **linear read scalability** at the cost of N× write amplification.

**Always add TTL jitter**: `TTL = base_ttl + random(0, 0.1 × base_ttl)`. This two-line change prevents synchronized expiration stampedes. The layered defense hierarchy: TTL jitter (always) → singleflight (in-process) → distributed locking (cross-node) → probabilistic early expiration (high-traffic keys).

---

## 6. PostgreSQL scaling has three existential failure modes

**Transaction ID wraparound can halt all writes.** PostgreSQL uses 32-bit XIDs — every table must be vacuumed within 2 billion transactions. At `autovacuum_freeze_max_age` (default 200M), anti-wraparound autovacuum triggers automatically. At 40M transactions from the limit (PostgreSQL 14+), warnings begin. At **<3M from the limit, PostgreSQL goes read-only**, refusing all write transactions. Monitor with `SELECT datname, age(datfrozenxid) FROM pg_database ORDER BY 2 DESC`. Alert thresholds: **warning at 500M, critical at 1.5B**.

**Autovacuum defaults are too conservative for production.** Critical tuning changes for SSD/NVMe storage:

| Parameter | Default | Production |
|---|---|---|
| `autovacuum_vacuum_cost_delay` | 2ms | **0ms** |
| `autovacuum_vacuum_cost_limit` | 200 | **1000–2000** |
| `autovacuum_max_workers` | 3 | **4–8** |
| `autovacuum_vacuum_scale_factor` | 0.1 | **0.01–0.05** |
| `maintenance_work_mem` | 64MB | **512MB–1GB** |
| `idle_in_transaction_session_timeout` | 0 (disabled) | **60s** |

An AWS case study found all 3 default workers occupied by large tables while smaller tables accumulated dead tuples unchecked. A session stuck `idle in transaction` for **2 days 22 hours** blocked autovacuum entirely. They increased workers to 8 and cost_limit to 4800 to resolve.

**Three VACUUM blockers cause cascading failures.** Long-running `idle in transaction` sessions hold back the visibility horizon. Inactive replication slots retain WAL indefinitely and block dead tuple cleanup across the entire cluster — one postmortem documented storage growing from 70 GB to **1.06 TB** from retained WAL. `hot_standby_feedback` on replicas prevents primary VACUUM from removing recently-dead rows. Always configure `log_autovacuum_min_duration = 200` to surface autovacuum behavior.

**Replication lag requires application-level handling for read-your-writes consistency.** After a write, route subsequent reads to the primary for a defined window, or track write LSN and compare with `pg_last_wal_replay_lsn()` on replicas before serving read results. GitLab uses feature flags to dynamically adjust replication lag tolerance. Monitor lag via `pg_stat_replication`: `write_lag` indicates network issues, `flush_lag` indicates disk I/O on replica, `replay_lag` indicates long-running queries or CPU saturation on replica.

**Online schema migrations require lock-aware tooling.** `ALTER TABLE` acquires `ACCESS EXCLUSIVE` locks, blocking all reads and writes. Use pg_osc (shadow table + triggers, brief lock at swap) or pgroll (versioned views, zero exclusive locks, instant rollback). Always set `lock_timeout = '3s'` on migrations with automatic retry. PostgreSQL 11+ makes `ADD COLUMN ... DEFAULT ...` instant by storing defaults in catalog metadata instead of rewriting the table. Use `CREATE INDEX CONCURRENTLY` to avoid blocking writes.

---

## 7. Kafka rebalancing storms are the leading cause of consumer outages

**A single rolling deployment can trigger a 45-minute processing outage.** A NashTech case with 100 consumer instances and 25 simultaneous pod restarts produced cascading rebalances where each wave prevented the previous from completing. The root cause: eager rebalancing forces **all** consumers to stop, revoke **all** partitions, rejoin, and receive new assignments — a stop-the-world pause where processing halts entirely.

**Three configuration changes eliminate most rebalancing storms.** Switch to `CooperativeStickyAssignor` (default in Kafka 3.0+), which performs incremental two-phase rebalancing — only affected partitions are revoked while unaffected consumers continue processing. Set `group.instance.id=${HOSTNAME}` for static membership, allowing restarting consumers to rejoin within `session.timeout.ms` and reclaim their partitions without triggering a rebalance. Tune timeouts:

| Parameter | Default | Recommended |
|---|---|---|
| `session.timeout.ms` | 45s (Kafka 3.0+) | 30–45s |
| `max.poll.interval.ms` | 300,000ms (5 min) | Up to 1,800,000ms for heavy processing |
| `heartbeat.interval.ms` | 3s | ≤ 1/3 of session.timeout.ms |
| `max.poll.records` | 500 | 50–100 for slow processing |

**Partition count formula** (Jun Rao, Confluent): `partitions = max(t/p, t/c)` where t = target throughput, p = producer throughput per partition, c = consumer throughput per partition. Maximum **~4,000 partitions per broker**, **~200,000 per ZooKeeper cluster**, millions with KRaft. Over-partition slightly for future growth — increasing partition count later breaks key-partition mapping for keyed messages. Use multiples of consumer count and broker count for even distribution.

**Consumer lag monitoring using Burrow** (LinkedIn's open-source tool) avoids false positives from simple threshold alerting. Burrow evaluates lag trends over sliding windows, classifying consumers as OK, WARNING (falling behind), or ERR (stopped). Maximum consumer parallelism equals partition count — consumers beyond this sit idle. Scale consumers to match partition count first, then increase partitions if more parallelism is needed.

**Exactly-once semantics carry real performance costs.** Idempotent producers (`enable.idempotence=true`, default since Kafka 3.0) add negligible overhead. Transactional consumers add milliseconds to tens of milliseconds per commit from two-phase coordination. Short commit intervals with many small transactions produce significant RPC overhead. In practice, **at-least-once with consumer-side deduplication** is simpler and more common than full exactly-once. Kafka transactions only cover data within Kafka — external side effects require the transactional outbox pattern.

---

## 8. Node.js event loop blocking hides in five common patterns

**`JSON.parse` on payloads >1 MB causes measurable blocking; >10 MB causes severe blocking.** The V8 engine processes JSON synchronously on the main thread regardless of whether it's inside an async callback. Mitigation: streaming parsers (`JSONStream`, `stream-json`) or worker threads for large payloads.

**Synchronous crypto is the most dramatic performance trap.** Voodoo Engineering documented switching from per-request `crypto` token generation to cached tokens: throughput improved from 195 requests/10s to **39,434 requests/10s** — a 200× improvement. Always use async equivalents: `crypto.pbkdf2` not `pbkdf2Sync`, `crypto.scrypt` not `scryptSync`. Similarly, loading a GeoIP database via `fs.readFileSync` on every request saturated the libuv thread pool; loading into memory at startup eliminated the bottleneck.

**`UV_THREADPOOL_SIZE` defaults to 4 threads** — used for DNS lookups, file I/O, crypto, and zlib. This means 5 concurrent `dns.lookup()` calls will queue. Maximum value is 1024. Set before process starts: `UV_THREADPOOL_SIZE=16 node app.js`. Recommended formula: `UV_THREADPOOL_SIZE = number_of_logical_cores`. Each cluster worker gets its own pool (10 workers × 4 threads = 40 total).

**Monitor event loop delay with `perf_hooks.monitorEventLoopDelay`** — thresholds of **>20ms warning, >100ms critical**. Trigger.dev found lags of several hundred milliseconds causing Prisma transaction timeouts. `performance.eventLoopUtilization()` (ELU) returns idle/active time ratio — values above **0.80 indicate server pressure**. The `blocked` npm package (518 bytes) provides lightweight detection for production.

**Worker threads (`worker_threads`) serve CPU-bound tasks only.** Use Piscina or workerpool for pool management. Worker creation incurs ~30ms overhead — pool workers to amortize this. Data transfer via `postMessage` involves structured cloning (copying); use `SharedArrayBuffer` for zero-copy shared memory. Set Piscina's `idleTimeout` explicitly to avoid constant worker restart overhead.

**V8 heap in containers**: Node.js 12+ reads cgroup limits and adjusts heap to ~50% of container memory up to 4 GiB. Set `--max-old-space-size` to **70–75% of container memory** for explicit control. Common memory leaks: closures holding references to large objects, global caches without eviction (unbounded Maps), and event emitter listener accumulation (Node.js warns at 11+ listeners).

---

## 9. Go goroutine leaks and GC tuning for containers

**Five goroutine leak patterns account for most production incidents.** Forgotten `context.WithCancel` where `cancel()` is never called — always `defer cancel()` immediately after creation. Unbuffered channel sends with no reader — use buffered channels matching goroutine count. HTTP response bodies not closed (`resp.Body.Close()` must be deferred after error check). `time.After` in loops, where each iteration creates a new timer that won't GC until fired — use `time.NewTimer` with `timer.Reset()`. Range over channels that are never closed.

**Uber's LeakProf found 252 goroutine leak reports over 24 hours** in a single production service by periodically profiling call stacks via pprof and inspecting for goroutines blocked on channel operations. For testing, `uber-go/goleak` detects leaked goroutines with exponential backoff inspection. In production, expose `net/http/pprof` on a debug port and monitor `runtime.NumGoroutine()` — a constantly growing count when idle confirms a leak.

**GOMEMLIMIT (Go 1.19+) replaces the ballast pattern for container GC tuning.** Set `GOGC=off GOMEMLIMIT=<container_limit × 0.9>` — GC becomes aggressive only as memory approaches the limit. One production deployment reported GC pause frequency dropping from **350 to 30 calls/min** and GC pause time dropping from **40ms to 400µs** at peak. The earlier ballast pattern (Twitch, 2019) — `make([]byte, 10<<30)` — achieved 99% reduction in GC cycles, 30% CPU reduction, and 45% P99 latency reduction, but GOMEMLIMIT is the modern replacement.

**GOMAXPROCS must match container CPU limits.** Before Go 1.25, GOMAXPROCS defaults to host CPU count (e.g., 64), not the container limit (e.g., 2). Benchmarks show **GOMAXPROCS=64 on a 2-CPU container**: P50 = 45ms, P99 = 890ms, throttle rate 72%. **GOMAXPROCS=2 (correct)**: P50 = 12ms, P99 = 35ms, throttle rate 3% — a **4× P50 improvement and 25× P99 improvement**. Use `go.uber.org/automaxprocs` for Go <1.25; Go 1.25+ handles this natively.

**`sync.Pool` provides 3.8× throughput improvement for buffer reuse** — benchmarked at 11.7M ops/sec vs 3.1M ops/sec without pooling for 4 KB `bytes.Buffer` allocations. GC pauses drop ~65% and heap allocations fall ~40%. Gotchas: the pool is cleared on GC (objects survive one cycle in a victim cache), it's not sized, and Pool Get/Put (~3.9 ns/op) is slower than trivial allocation (~0.24 ns/op) — only beneficial for allocations that are expensive or produce GC pressure. Always reset objects before returning to the pool.

---

## 10. Quantitative reference card

**Connection pool sizing:**

| System | Formula / Default | Notes |
|---|---|---|
| PostgreSQL | `(cores × 2) + spindle_count` | Physical cores only; SSD spindle = 1 |
| PostgreSQL per connection | ~10 MB memory | 1.3–14.5 MB actual depending on config |
| MongoDB | `maxPoolSize = concurrent_reqs × avg_query_sec × 1.5` | Default 100; multiply by replica set size |
| Redis | Default `maxclients = 10,000` | Multiplexing: 1 connection per Node.js process |

**Kafka partition sizing:**

```
partitions = max(target_throughput / producer_throughput_per_partition,
                 target_throughput / consumer_throughput_per_partition)
```

Maximum ~4,000 per broker, ~200,000 per ZooKeeper cluster. Start with 2–3× broker count for small clusters.

**Cache TTL with jitter:** `TTL = base_ttl × (1 + random(-0.1, 0.1))`. Session data: 15–30 min. User profiles: 5–15 min. Static config: 1–24 hours. Stale-while-revalidate window ≤ 20% of base TTL.

**Redis throughput:** ~100K–150K ops/sec for simple GET/SET without pipelining. Pipeline=16 yields **6–15× improvement** (600K–1.5M ops/sec). Per-key overhead: **~56–64 bytes** (dictionary entry + metadata + pointers). Redis 8.x delivers 30%+ throughput improvement for caching workloads over prior versions.

**PostgreSQL configuration baselines:** `shared_buffers = 25% of RAM`. `effective_cache_size = 50–75% of RAM`. `work_mem = RAM / (max_connections × 3)`. `maintenance_work_mem = 512MB–1GB`. `statement_timeout = 30s` for web requests.

**Runtime concurrency:**

| Metric | Go | Node.js |
|---|---|---|
| Concurrent connections per instance | 10K–50K+ | 10K–25K (I/O bound) |
| Memory per WebSocket | ~10–12 KB | ~5–40 KB |
| Goroutine/worker overhead | 2 KB initial stack | ~30ms worker creation |
| CPU-bound optimal workers | = CPU cores | = CPU cores (worker_threads) |
| Container CPU fix | `automaxprocs` or Go 1.25+ | N/A (single-threaded) |
| Container memory fix | `GOMEMLIMIT = limit × 0.9` | `--max-old-space-size = limit × 0.75` |

**Latency targets (p99):** API response < 200ms, DB query < 50ms, cache hit < 1ms, inter-service call < 100ms. Circuit breaker: trip at >50% error rate over 10–30 seconds, half-open after 30–60 seconds.

## Conclusion

The patterns in this report converge on a counterintuitive insight: **production failures at scale are dominated by resource exhaustion and coordination problems, not by the computational work itself.** Connection pools sized by intuition rather than formula, autovacuum left at defaults, GOMAXPROCS ignoring container limits, and eager Kafka rebalancing during deployments — these are the actual causes of 3 AM pages.

Three principles emerge across all ten areas. First, **small pools outperform large pools** — PostgreSQL's 9-connection formula outperforms 200 connections because contention costs exceed parallelism benefits. Second, **layered defense beats single solutions** — cache stampede prevention works best as TTL jitter + singleflight + distributed locking + probabilistic early expiration, not any single technique. Third, **detection must precede failure** — monitoring `runtime.NumGoroutine()` trends, `pg_stat_activity` idle-in-transaction durations, event loop delay percentiles, and consumer lag growth rates provides the early warning that threshold-based alerting on error rates cannot.

The most impactful changes for a new production system are also the simplest: set `GOGC=off` with `GOMEMLIMIT` in Go containers, use `automaxprocs`, configure `idle_in_transaction_session_timeout = 60s` and `autovacuum_vacuum_cost_delay = 0` in PostgreSQL, switch Kafka consumers to `CooperativeStickyAssignor` with `group.instance.id`, add TTL jitter to every cache key, and implement graceful shutdown with a pre-drain delay. Each is a configuration change or a few lines of code. Together they prevent the majority of scaling failures documented here.