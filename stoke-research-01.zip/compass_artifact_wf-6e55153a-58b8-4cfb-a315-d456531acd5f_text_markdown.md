# Database migration safety and polyglot persistence across Postgres, MongoDB, Redis, and Kafka

**Every zero-downtime migration follows one meta-pattern: expand the schema, migrate the data, then contract the old structure away.** This expand-and-contract principle applies universally — to PostgreSQL column changes, MongoDB document evolution, Kafka schema registry updates, and cross-service API contracts. The critical implementation details vary by store, but the philosophy is constant: never require a synchronized big-bang cutover. What follows is a practitioner's guide to executing this safely across a polyglot stack of PostgreSQL (primary), MongoDB (document workloads), Redis (cache), and Kafka (event streaming), covering lock management, schema evolution, consistency patterns, connection pooling, rollback strategies, and the tooling that prevents disasters in CI before they reach production.

---

## 1. PostgreSQL zero-downtime migrations demand lock awareness above all else

The single most important fact about PostgreSQL DDL: **ALTER TABLE acquires an ACCESS EXCLUSIVE lock by default**, which blocks all reads and writes. Worse, PostgreSQL's lock queue is FIFO — if an ALTER TABLE is waiting for its lock, every subsequent SELECT queues behind it, causing a cascading outage even though the DDL hasn't started yet. This is why `SET lock_timeout = '5s'` before any DDL is non-negotiable.

Not all ALTER TABLE subcommands are equally dangerous. The lock breakdown determines your migration strategy:

| Operation | Lock level | Duration | Notes |
|-----------|-----------|----------|-------|
| ADD COLUMN (no default or constant default, PG11+) | ACCESS EXCLUSIVE | **Instant** (metadata only) | Safe on large tables |
| ADD COLUMN (volatile default, e.g., `now()`) | ACCESS EXCLUSIVE | **Full table rewrite** | Dangerous — add column first, set default separately |
| DROP COLUMN | ACCESS EXCLUSIVE | Instant | Marks column dropped; no rewrite |
| RENAME COLUMN | ACCESS EXCLUSIVE | Instant | Breaks all queries referencing old name |
| ALTER COLUMN TYPE | ACCESS EXCLUSIVE | Usually table rewrite | Exceptions: VARCHAR(n)→VARCHAR(m) where m>n, VARCHAR→TEXT, NUMERIC(p,s)→NUMERIC |
| SET NOT NULL | ACCESS EXCLUSIVE | Full table scan | Verifies no NULLs exist |
| ADD CONSTRAINT FK | SHARE ROW EXCLUSIVE | Full scan | Locks both parent and child table |
| VALIDATE CONSTRAINT | SHARE UPDATE EXCLUSIVE | Full scan | **Does not block writes** |
| SET STATISTICS, SET (fillfactor) | SHARE UPDATE EXCLUSIVE | Instant | Safe |

**The safe alternatives transform dangerous operations into lock-friendly sequences.** To add a NOT NULL constraint without blocking writes: first `ADD CONSTRAINT CHECK (col IS NOT NULL) NOT VALID` (brief lock, no scan), then `ALTER TABLE VALIDATE CONSTRAINT` (allows concurrent writes). For unique constraints: `CREATE UNIQUE INDEX CONCURRENTLY` followed by `ADD CONSTRAINT USING INDEX`. For foreign keys: `ADD CONSTRAINT FK NOT VALID` then `VALIDATE CONSTRAINT` separately.

### How expand-and-contract works for PostgreSQL

Renaming a column or changing a type cannot be done in a single safe step. Instead, you expand first: add the new column, install a trigger that dual-writes between old and new columns, backfill historical data in batches, switch application reads to the new column, then contract by dropping the old column and trigger. The pgroll tool by Xata automates this entire sequence — it creates versioned schema views so old and new application code can run simultaneously against the same database, with database-level triggers handling the dual-write. Running `pgroll start migration.json` begins the expand phase, and `pgroll complete` finalizes the contract.

**CREATE INDEX CONCURRENTLY** deserves special attention because it is the only safe way to add indexes on live tables. It performs two table scans instead of one, takes a SHARE UPDATE EXCLUSIVE lock (allowing reads and writes), but cannot run inside a transaction block. If it fails — due to deadlocks, disk exhaustion, or uniqueness violations — it leaves an **invalid index** that still consumes write overhead. Always check `pg_index.indisvalid` after concurrent builds and clean up with `DROP INDEX CONCURRENTLY` or `REINDEX INDEX CONCURRENTLY` (PG12+).

For testing migrations safely, clone production data to staging using filesystem snapshots or pg_dump/pg_restore. A migration completing in milliseconds on 100 rows may take minutes on 10 million rows. Use `\timing` in psql and monitor `pg_stat_progress_create_index` during index builds.

---

## 2. MongoDB and Kafka schema evolution follow different compatibility rules

### MongoDB: the schema versioning pattern

MongoDB's flexible document model means schema changes are implicit — they happen document-by-document, not through DDL. The recommended approach is the **Schema Versioning Pattern**: store a `schemaVersion` field in every document. Documents without this field are treated as version 1. The application checks the version on read and handles each shape appropriately.

The choice between lazy and batch migration is a fundamental tradeoff. **Lazy migration** (on-read) transforms documents when accessed and optionally writes them back, spreading the cost over time with zero upfront batch load. It's ideal for MongoDB's flexible schema because cold data that's never accessed is never migrated — but it means old-format documents persist indefinitely, increasing code complexity as version chains accumulate (v1→v2→v3). **Batch migration** processes all documents in a background job with throttled batch sizes, providing a clean cutover point but requiring careful monitoring of replica lag and I/O impact.

For schema validation evolution, MongoDB's `validationLevel: "moderate"` setting is the key transitional tool — it only validates inserts and updates to already-valid documents, allowing existing non-conforming documents to be read without errors. Set validation to moderate/warn during migration, migrate documents, then tighten to strict with the new schema. The `collMod` command that updates validation rules replicates automatically across replica set members through the oplog.

Change streams remain resilient during schema migration because MongoDB documents are self-describing. Consumers should add normalization logic in the change stream pipeline using `$addFields` and `$cond` to handle both old and new document shapes. Resume tokens are unaffected by schema changes.

### Kafka Schema Registry: Avro vs Protobuf evolution

The Confluent Schema Registry enforces compatibility at registration time, preventing schemas that would cause runtime deserialization failures. **BACKWARD compatibility** (the default) means new schemas can read old data — deploy consumers first, then producers. **FORWARD compatibility** means old schemas can read new data — deploy producers first. **FULL compatibility** requires both.

The critical rules differ between serialization formats:

| Change | Avro | Protobuf |
|--------|------|----------|
| Add field with default | ✅ Safe | ✅ Safe |
| Add field without default | ❌ Breaks backward | ✅ Safe (proto3 all fields optional) |
| Remove field | ✅ If had default | ✅ If number reserved |
| Rename field | ❌ Breaking (use aliases) | ✅ Wire-safe (names not on wire) |
| Change field type | Limited promotions (int→long→float→double) | Very limited (int32↔uint32↔bool) |
| Reorder fields | ❌ Can corrupt data | ✅ Safe (identified by number) |
| Add enum value | ❌ Old readers fail | ✅ Stored as unknown int |

**The single most important Avro rule: always add fields with defaults.** The single most important Protobuf rule: **never change or reuse field numbers.** For breaking changes that can't be made compatible, create a new topic with the new schema and run a migration service that transforms messages from old to new.

Always set `auto.register.schemas=false` in production — schemas should be registered exclusively through CI/CD pipelines after passing compatibility checks. Test compatibility before registration using the Schema Registry's `/compatibility` endpoint.

---

## 3. Cross-service schema coordination uses the same expand-and-contract at API boundaries

When Service A adds a field that Service B must start sending, the deployment order is critical: **deploy the consumer first**. Service A (consumer) deploys with the new field treated as optional, using sensible defaults when absent. Only then does Service B (producer) start sending the field. Once all producers are confirmed sending, the consumer can optionally make the field required. This phased approach means no services need to deploy simultaneously.

**Consumer-driven contract testing** (CDCT) encodes this coordination into CI. With tools like Pact, consumers define the minimum API contract they need, generate a contract file, and publish it to a Pact Broker. Provider CI pulls these contracts and verifies against a locally running service. The "Can I Deploy?" check gates deployment — a provider cannot ship changes that break any consumer's contract. The key discipline: contracts should be as loose as possible while ensuring the provider can't break compatibility. Only test fields the consumer actually uses.

The **Tolerant Reader pattern** (Postel's Law applied to APIs) complements contract testing: services extract only needed fields and ignore everything else. Configure JSON deserializers to ignore unknown properties (`@JsonIgnoreProperties(ignoreUnknown = true)` in Jackson). This enables independent evolution — producers can add fields freely without coordinating with consumers. Combined with CDCT, this ensures minimum required fields are always present while new fields don't break existing consumers.

Stripe's production-tested approach for large-scale data model migrations follows four phases: dual-write to old and new tables, switch all reads to the new table (using GitHub's Scientist library to compare results and detect inconsistencies), switch all writes to only the new table, then drop the old table. They report migrating hundreds of millions of subscription objects with zero downtime using this pattern.

---

## 4. Backfilling billions of rows without locking requires batched updates with throttling

The PostgreSQL backfill pattern for production is straightforward but demands discipline. First, add the column as nullable (instant in PG11+). Then update in small batches using primary key ranges, committing each batch independently and sleeping between them:

```sql
DO $$
DECLARE
    batch_size  INT := 10000;
    last_id     BIGINT := 0;
    rows_updated INT;
BEGIN
    LOOP
        WITH batch AS (
            SELECT id FROM events
            WHERE id > last_id AND category_label IS NULL
            ORDER BY id LIMIT batch_size
            FOR UPDATE SKIP LOCKED
        )
        UPDATE events e SET category_label = 'default'
        FROM batch b WHERE e.id = b.id;

        GET DIAGNOSTICS rows_updated = ROW_COUNT;
        EXIT WHEN rows_updated = 0;

        SELECT MAX(id) INTO last_id FROM events
        WHERE id > last_id ORDER BY id LIMIT batch_size;

        PERFORM pg_sleep(0.5);
        RAISE NOTICE 'Backfilled up to id %, rows: %', last_id, rows_updated;
    END LOOP;
END $$;
```

**`FOR UPDATE SKIP LOCKED` prevents contention** with application writes by skipping rows currently locked by other transactions. Each batch must be its own transaction — long-running transactions hold back VACUUM from reclaiming dead tuples, causing table bloat. Start with **10,000 rows per batch** (reduce to 1,000–5,000 for heavily indexed tables), and monitor replica lag: if it exceeds 1 second, increase sleep or reduce batch size.

For resumability, persist progress to a checkpoint table (`backfill_progress`) with the last processed ID and row count. On restart, resume from the checkpoint rather than re-processing everything. After backfill completes, add the NOT NULL constraint safely using the two-step approach: `ADD CHECK NOT VALID` then `VALIDATE CONSTRAINT`.

The comparison of migration strategies is important for choosing the right approach:

| Dimension | Lazy (on-read) | Batch migration | Dual-write (expand-contract) |
|-----------|---------------|-----------------|------------------------------|
| When it happens | First read of each row | Background job | Writes go to both; backfill fills gaps |
| Completeness | Cold data may never migrate | All rows migrated | All rows migrated |
| Read latency impact | Higher P99 for unmigrated rows | None after completion | None |
| App complexity | High (handle N versions) | Low (separate script) | Medium (dual-write + feature flags) |
| Best for PostgreSQL | ⚠️ Unnatural fit | ✅ Primary strategy | ✅ Column renames/type changes |
| Best for MongoDB | ✅ Natural fit | ✅ Complete migration | ✅ Cross-collection restructuring |
| Time to completion | Unbounded | Predictable (hours/days) | Predictable |

The production recommendation combines dual-write and batch: deploy the new nullable column, deploy application dual-write code, run batched backfill with checkpointing, verify consistency using Scientist-style comparisons, switch reads via feature flag, then remove the old column.

---

## 5. Migration rollback and the shadow migration pattern

Most migration tools advertise rollback support but only handle schema rollback — **data rollback almost always requires manual planning**. When you've added a column, backfilled it, and need to undo, a simple `DROP COLUMN` loses all data written exclusively to the new column and breaks any code paths already reading from it.

The safest rollback strategy is the **feature flag approach**: don't drop the column immediately. Instead, toggle a feature flag so application code stops reading/writing the new column. Observe for a sprint. If nothing breaks, plan the actual DROP. If something does break, toggle the flag back — vastly faster than rushing a schema rollback during an incident.

For situations requiring actual reversal, write a **compensating forward migration** rather than attempting to roll backward. This preserves the migration audit trail (critical for compliance) and avoids the complex state management of true rollback. As Flyway's documentation states: "Database state must be preserved, it can only ever move forwards — a rollback is best regarded as a roll forward to a state that happened to exist in the past."

The **shadow migration pattern** (dual-write, compare, cutover) is production-tested at Stripe and GitHub. The process: create a shadow table with the new schema, backfill existing data in chunks, install triggers or CDC to sync ongoing changes, run verification (row count comparison, checksum validation, Scientist-style read comparisons), then perform the cutover with a brief write pause and atomic table rename. Keep the old table for a rollback window of days to weeks. PlanetScale's approach automates this — after an online schema change completes, they keep the old table synced via VReplication, enabling near-instant revert with zero data loss.

**Some migrations are inherently irreversible**: data type narrowing (VARCHAR→INT loses data that doesn't fit), column merges (first_name + last_name → full_name loses the originals), and lossy conversions (FLOAT→INT loses precision). For these, never proceed without keeping the old structure through the entire migration window, taking a logical backup before the irreversible step, and documenting the explicit point of no return.

---

## 6. Polyglot consistency requires the outbox pattern and read-your-writes discipline

The fundamental polyglot problem: a user writes an order to PostgreSQL, but their immediate read hits Redis (stale cache) or a Kafka-fed read model (event hasn't propagated yet). No transactional semantics extend across store boundaries.

**Dual-writing to PostgreSQL and Kafka independently is an anti-pattern.** Three failure modes are all silent: Kafka fails after DB commits (event lost), the app crashes between writes (event lost), or the DB rolls back after Kafka publish (phantom event). Ordering is also broken — concurrent requests may commit in order A→B in PostgreSQL but arrive B→A in Kafka. The fix is the **transactional outbox pattern**.

The outbox works by writing the business data and the event to PostgreSQL in the same transaction, guaranteeing atomicity:

```sql
BEGIN;
INSERT INTO orders (id, customer_id, total, status)
VALUES ('ord-9821', 'cust-442', 159.99, 'placed');

INSERT INTO outbox (aggregate_type, aggregate_id, event_type, payload)
VALUES ('Order', 'ord-9821', 'OrderCreated',
  '{"order_id":"ord-9821","customer_id":"cust-442","total":159.99}'::jsonb);
COMMIT;
```

A relay process — either polling the outbox table or, preferably, **Debezium CDC reading PostgreSQL's WAL** — publishes events to Kafka. Debezium with the EventRouter SMT transforms outbox rows into properly-routed Kafka messages with single-digit millisecond latency. This guarantees at-least-once delivery, so consumers must be idempotent (use `ON CONFLICT DO NOTHING` or track processed event IDs).

For Redis cache consistency, use **cache-aside with TTL as a safety net** (data expires even if invalidation is missed) plus **explicit invalidation on write** (delete the cache key immediately after the PostgreSQL commit). For the writing user specifically, implement **read-your-writes consistency** by setting a short-lived "recently-wrote" flag in Redis; subsequent reads for that user bypass the cache and hit PostgreSQL directly for a 3–5 second window.

Configuring Debezium for PostgreSQL requires `wal_level = 'logical'`, a dedicated replication user with `REPLICATION` privilege, a publication defining captured tables, and `REPLICA IDENTITY FULL` on tables where you need before-images in update/delete events. **Monitor replication slot lag obsessively** — an inactive Debezium connector causes WAL to accumulate indefinitely, eventually filling the disk. Configure heartbeat intervals to force slot advancement during quiet periods.

---

## 7. Connection pooling: the formula is simpler than you think

The PostgreSQL wiki's connection formula is both counterintuitive and well-proven: **connections = (core_count × 2) + effective_spindle_count**, where core_count is physical cores only (not hyper-threads) and effective_spindle_count is 1 for SSDs. A 4-core server with SSD needs only **9 active connections**. An 8-core server needs **17**. Adding more connections beyond this threshold causes context switching overhead, lock contention, and worse latency for everyone — more connections means slower queries, not more throughput.

**PgBouncer in transaction mode** is the standard solution for multiplexing hundreds of application connections down to this small pool. It assigns a backend connection only for the duration of a transaction, then returns it to the pool. The critical limitations in transaction mode: no session-level prepared statements (fixed in PgBouncer 1.21+ with `max_prepared_statements`), no advisory locks (use a direct bypass connection for migrations), no LISTEN/NOTIFY (use a dedicated direct connection), and no SET/RESET (use `SET LOCAL` for transaction-scoped settings or set defaults at the role level).

**pgcat** (written in Rust by PostgresML) is the modern alternative when you need features PgBouncer lacks: automatic read/write splitting (SELECTs to replicas, writes to primary), query-level load balancing, built-in sharding support, automatic replica failover, and native Prometheus metrics. Instacart's production benchmarks show pgcat matching PgBouncer at low concurrency and exceeding it at high concurrency — **59K TPS vs 44K TPS** at 50+ concurrent connections, thanks to multi-threaded Tokio versus PgBouncer's single-threaded libevent.

For MongoDB, the default `maxPoolSize` of **100 connections per mongod** creates up to 300 outgoing connections per app instance (100 × 3 replica set members). Set `maxPoolSize` to 10–20% above peak concurrent query count, `minPoolSize` to handle baseline traffic (10–15 to avoid cold-start latency), and `waitQueueTimeoutMS` to 5000ms to fail fast rather than hang.

In microservices architectures where many services share a database, the math compounds dangerously: 5 services × 2 instances × 10 pool size = 100 connections, already near default `max_connections`. The solution is a centralized connection pooler: each service connects to PgBouncer with a generous client-side pool, and PgBouncer multiplexes down to the optimal backend count. One real-world case showed reducing connection pools from 320 to 40 across microservices improved critical SQL performance by **50%** and reduced resource consumption by **20%**.

---

## 8. Migration safety tools and CI/CD integration catch disasters before production

The ecosystem of open-source tools that prevent dangerous migrations has matured significantly. Here's what each tool does and when to use it:

**squawk** is a static PostgreSQL SQL linter with 30+ rules that catches unsafe operations at the file level. It flags missing `CONCURRENTLY` on index creation, column type changes that cause table rewrites, constraints without `NOT VALID`, missing timeout settings, and more. It integrates directly into GitHub Actions with the `sbdchd/squawk-action` — every PR that touches migration files gets automatically linted.

**strong_migrations** (Rails) catches dangerous operations at runtime before they execute. It detects adding columns with non-null defaults (pre-PG11), non-concurrent index creation, column renames, type changes, and missing NOT VALID on constraints. It provides specific safe alternatives for each dangerous operation. Configure with `StrongMigrations.lock_timeout = 10.seconds` and `StrongMigrations.target_postgresql_version = "14"`.

**Atlas** (by Ariga) takes a declarative schema-as-code approach — you define the desired state in HCL or SQL, and Atlas computes the migration plan with `atlas migrate diff`. Its lint engine has **50+ safety analyzers** that detect destructive changes, table locks, data-dependent changes, and concurrent index violations. It supports 15+ databases and integrates with GORM, TypeORM, Prisma, Django, SQLAlchemy, and other ORMs. The `atlas migrate lint --dev-url "docker://postgres/16/dev"` command spins up a temporary Postgres container to test migrations.

**pgroll** automates the expand-and-contract pattern for PostgreSQL with JSON/YAML migration definitions. It creates versioned schema views and database-level triggers, handles backfilling in batches with lock-safe retries, and provides instant rollback by simply canceling the migration. It requires PostgreSQL 14+ and has 5K+ GitHub stars.

**Flyway** and **Liquibase** are the established migration runners. Flyway is SQL-first and simple, with versioned migration files tracked in a `flyway_schema_history` table — but rollback is Enterprise-only and it has no built-in safety linting. Liquibase offers XML/YAML/JSON changelogs with built-in rollback support and schema diff capabilities, but has a steeper learning curve. Neither tool prevents dangerous DDL — they need squawk or Atlas lint in front.

**gh-ost** and **pt-online-schema-change** are MySQL-specific but embody patterns relevant to all databases. gh-ost creates a shadow table, streams binlog events (triggerless), and does an atomic cutover — GitHub built it to eliminate the trigger overhead and lock contention of pt-online-schema-change's synchronous trigger-based approach.

A production CI/CD pipeline should layer these tools: static SQL linting (squawk) on every PR, schema-aware analysis (Atlas lint) with a disposable Postgres container, migration testing against a production-sized database snapshot, and a manual approval gate (GitHub environment protection rules) for any migration flagged as dangerous. Separate migration deployment from application deployment, and always set `lock_timeout` and `statement_timeout` as safety nets.

---

## 9. PostgreSQL operational monitoring: vacuum, bloat, and query analysis

**pg_stat_statements** is the most important PostgreSQL extension for production. Enable it with `shared_preload_libraries = 'pg_stat_statements'` (requires restart) and `track_io_timing = on`. The top 2–3 queries by `total_exec_time` typically consume over **80% of total database runtime** — optimizing these few queries often has more impact than any other change. Query by `mean_exec_time` with a minimum call threshold to find consistently slow queries, and by `stddev_exec_time` to find queries with high variance (indicating lock contention or plan instability). A high `shared_blks_read` relative to `shared_blks_hit` signals poor cache behavior and likely missing indexes.

VACUUM monitoring is critical because PostgreSQL's MVCC model accumulates dead tuples after every UPDATE and DELETE. Autovacuum triggers when `n_dead_tup > autovacuum_vacuum_threshold + autovacuum_vacuum_scale_factor × reltuples`. The defaults (scale_factor=0.2, threshold=50) mean a 100-million-row table won't vacuum until **20 million dead tuples** accumulate. For high-write tables, set per-table overrides: `autovacuum_vacuum_scale_factor = 0.01` and `autovacuum_vacuum_cost_delay = 0` (aggressive). Monitor dead tuple ratios with `SELECT relname, n_dead_tup, round(n_dead_tup::numeric / NULLIF(n_live_tup,0) * 100, 2) AS dead_pct FROM pg_stat_user_tables ORDER BY n_dead_tup DESC`.

For **bloat detection**, the `pgstattuple` extension provides exact measurements: `SELECT * FROM pgstattuple('orders')` shows `dead_tuple_percent` (concerning above 20%), and `SELECT * FROM pgstatindex('idx_orders_id')` shows `avg_leaf_density` (bloated below 70%). Remediate with `REINDEX INDEX CONCURRENTLY` (PG12+) for indexes or `pg_repack` for tables — never use `VACUUM FULL` during production hours as it takes an ACCESS EXCLUSIVE lock.

**Partition pruning verification** is done through EXPLAIN ANALYZE. Look for "Subplans Removed: N" (plan-time pruning), "(never executed)" annotations (runtime pruning), or only relevant partitions appearing as child nodes. If all partitions are scanned, common causes include: the WHERE clause not referencing the partition key, non-immutable functions in the predicate, type mismatches between the column and the literal, or prepared statements using generic plans (fix with `plan_cache_mode = force_custom_plan`).

---

## Conclusion

The patterns across this entire polyglot stack converge on a few universal principles. **Expand-and-contract is the master pattern** — whether you're renaming a PostgreSQL column, evolving a MongoDB document schema, updating a Kafka Avro schema, or changing a cross-service API contract, the sequence is always: make the new thing optional alongside the old, migrate data and traffic, then remove the old. The only variable is the mechanism: database triggers and pgroll for PostgreSQL, schema versioning fields for MongoDB, Schema Registry compatibility modes for Kafka, and consumer-driven contract testing for service APIs.

The most dangerous moment in any migration isn't the schema change itself — it's the consistency window afterward. The transactional outbox pattern with Debezium CDC has emerged as the industry standard for bridging PostgreSQL to Kafka without the dual-write anti-pattern, while read-your-writes bypass and TTL-based cache-aside handle the Redis consistency gap. Connection pool sizing follows the unintuitive rule that fewer connections yield better throughput, with PgBouncer or pgcat multiplexing hundreds of client connections down to `(cores × 2) + 1` actual backends.

The tooling layer — squawk for SQL linting, strong_migrations for Rails, Atlas for declarative schema management, pgroll for automated expand-and-contract — transforms migration safety from tribal knowledge into automated CI gates. The organizations that avoid migration incidents aren't the ones with the best DBAs; they're the ones where a dangerous ALTER TABLE literally cannot reach production without a human approving it.