# Production i18n, l10n, and multi-region deployment for React SaaS

**For a React/React Native SaaS targeting Canada (EN/FR), US, and EU, the winning stack is react-i18next or LinguiJS with ICU MessageFormat, next-intl for Next.js routing, path-prefix URLs for SEO, cookie-based locale for authenticated dashboards, and Crowdin for continuous localization.** The critical early decisions — ICU message format adoption, CSS logical properties from day one, storing UTC timestamps and `geo_partition` columns on every user record — are nearly impossible to retrofit and must be made before writing the first component. Quebec's Bill 96 makes full French parity a legal requirement, not a nice-to-have, with fines up to C$25M. This guide covers every layer from library choice through CI enforcement, drawing on patterns from companies shipping multi-locale SaaS at scale.

---

## Choosing the right i18n library determines everything downstream

Three libraries dominate React/React Native i18n, and the choice cascades into extraction tooling, translation platform compatibility, bundle size, and developer experience.

**react-i18next** (i18next v24 + react-i18next v17) is the most mature ecosystem at **~22 kB** gzipped. It offers first-class namespace support for lazy-loading translations per route, the deepest plugin ecosystem (HTTP backends, language detection, caching), and seamless React Native support without Intl polyfills. TypeScript support in v24 enables full key autocomplete via `CustomTypeOptions`. The weakness: its default interpolation format (`{{variable}}`, `key_one`/`key_other` suffixes) is non-standard. For proper ICU MessageFormat — essential for French plural rules and Arabic's six forms — you must add the `i18next-icu` plugin.

**LinguiJS v5** delivers the smallest runtime at **~10.4 kB** gzipped. Its macro-based API (`<Trans>`, `t`) compiles to ICU MessageFormat at build time, meaning developers write natural JSX while Lingui generates correct ICU syntax. Extraction is automatic via `lingui extract`. The trade-off is mandatory build tooling (Babel/SWC plugin) and a smaller ecosystem than i18next.

**react-intl (FormatJS v7)** at **~15 kB** provides native ICU MessageFormat, the `formatjs extract` CLI using a native binary (4–17× faster than Node), and `formatjs compile` to pre-compile ICU to AST for faster runtime parsing. It lacks built-in namespace support and language detection, requiring more custom glue code.

For a Canadian EN/FR SaaS, **ICU MessageFormat is non-negotiable** because French treats zero as singular (`0 élément`, not `0 éléments`), unlike English. This single rule breaks naive `count === 1` checks. Arabic needs all six CLDR plural categories (`zero`, `one`, `two`, `few`, `many`, `other`), and ICU handles this declaratively:

```
{count, plural,
  zero {لا رسائل}
  one {رسالة واحدة}
  two {رسالتان}
  few {# رسائل}
  many {# رسالة}
  other {# رسالة}
}
```

Gender-aware translations in French require ICU's `select` combined with `plural` for nested agreement: "Elle a ajouté # photo" vs "Il a ajouté # photos." Always include an `other` case for non-binary/neutral forms.

**Monorepo sharing** between React web and React Native works best with a `shared-i18n` package containing common translations (buttons, errors, validation messages), while platform-specific strings live locally. For React Native on Hermes, always use `@formatjs/intl-pluralrules/polyfill-force` (not `/polyfill`) — the conditional detection variant adds **10+ seconds** to Android startup.

**Recommended choice**: LinguiJS for greenfield projects prioritizing correctness and bundle size; react-i18next for teams wanting maximum ecosystem flexibility and the option to add ICU later.

---

## Text expansion breaks your UI before translators even start

German text runs **30–35% longer** than English, Finnish **30–50%**, and French **15–20%**. Short UI labels suffer the most dramatic expansion: "Close" becomes "Schließen" (+80%), "FAQ" becomes "Preguntas frecuentes" (+700% in Spanish), and "Save changes" becomes "Änderungen speichern" (+67% in German). Compound nouns in German, Finnish, and Dutch form single unbreakable words like "Geschwindigkeitsbegrenzung" (speed limit) that cannot wrap at spaces.

Design every component to accommodate **at least 40% expansion** from English. The patterns that survive translation are flexbox containers with `flex-wrap: wrap`, `min-width` for touch targets, and `overflow-wrap: break-word` with `hyphens: auto` for long compound words. Fixed-width buttons, fixed-column tables, and hardcoded modal dimensions are the top three breakage patterns.

```css
.btn {
  display: inline-flex;
  align-items: center;
  padding: 8px 16px;
  min-width: 80px;
  max-width: 100%;
  white-space: nowrap;
}
```

**Pseudo-localization** catches these issues before real translations exist. It transforms English text into accented Unicode equivalents ("Save changes" → "Šåvé çhåñgéš"), pads strings by 30–40% to simulate expansion, and wraps in brackets so any unbracketed text reveals hardcoded strings. The `pseudo-localization` npm package integrates as a React component in development, and `i18next-pseudo` plugs directly into i18next with configurable `letterMultiplier`. Any string appearing in plain English during pseudo-loc testing is not passing through the translation pipeline.

For CJK scripts, increase line height to **1.6–1.8** (vs 1.4–1.5 for Latin). Arabic ligatures break with any non-zero `letter-spacing`. Build font fallback chains using the Noto Sans family: `"Inter", "Noto Sans", "Noto Sans Arabic", "Noto Sans CJK SC", sans-serif`.

---

## RTL layout requires CSS logical properties from day one

Retrofitting RTL onto an LTR codebase is one of the most expensive i18n debts. **CSS logical properties** eliminate the problem entirely by replacing physical directions with flow-relative equivalents. `margin-inline-start` replaces `margin-left`, `padding-inline-end` replaces `padding-right`, and `inset-inline-start` replaces `left`. A single rule works for both LTR and RTL without any overrides:

```css
.sidebar {
  margin-inline-start: 10px;
  padding-inline-start: 15px;
  inset-inline-start: 8px;
}
```

All modern browsers fully support logical properties. For existing codebases, `stylis-plugin-rtl` (Emotion) and `stylis-rtlcss` (styled-components) automatically transform `margin-left` to `margin-right` in RTL contexts. Tailwind CSS v3.3+ provides `ms-` (margin-start), `me-` (margin-end), `ps-`, `pe-` utilities as built-in logical properties, plus `rtl:` and `ltr:` variant prefixes for edge cases.

**Icon mirroring** follows a clear rule: directional icons (arrows, back/forward, reply, undo/redo, progress bars, breadcrumb separators) must flip via `transform: scaleX(-1)` in RTL. Universal icons (play/pause, checkmarks, clocks, search, close) never flip. Create a `MIRROR_ICONS` set and apply the transform conditionally.

In React Native, use `paddingStart`/`paddingEnd`/`marginStart`/`marginEnd` instead of left/right variants. Flexbox `row` direction auto-reverses in RTL mode. `I18nManager.forceRTL(true)` requires a **full app restart** — use `react-native-restart`. iOS behavior was fixed in React Native 0.79.0 to support dynamic layout context updates. Android requires `android:supportsRTL="true"` in AndroidManifest.xml.

For user-generated content that mixes scripts, always apply `dir="auto"` and `unicode-bidi: isolate` to prevent bidirectional text in one element from affecting adjacent elements. The Unicode BiDi algorithm handles most cases automatically, but explicit direction marks (LRM `U+200E`, RLM `U+200F`) resolve edge cases where punctuation floats to the wrong side.

---

## Formatting dates, numbers, and currency with zero bundle cost

The browser's built-in `Intl` APIs handle locale-aware formatting with zero additional JavaScript, sourcing data from the CLDR embedded in the runtime. This is the highest-leverage decision: **use `Intl.DateTimeFormat` and `Intl.NumberFormat` directly** rather than bundling locale data.

```js
new Intl.DateTimeFormat('en-US').format(date);  // "12/19/2012"
new Intl.DateTimeFormat('fr-CA').format(date);  // "2012-12-19"
new Intl.DateTimeFormat('de-DE').format(date);  // "19.12.2012"
```

`Intl.NumberFormat` **automatically resolves the correct decimal places** per currency from ISO 4217: USD gets 2, JPY gets 0, BHD gets 3. French-Canadian formatting uses narrow no-break space as thousands separator and comma as decimal: `1 234 567,89`. German uses dot for thousands and comma for decimal: `1.234.567,89`. Never hardcode these patterns.

```js
new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD' }).format(1234.5);
// "1 234,50 $"
new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(1234);
// "￥1,234"
```

**The golden rule for timezones**: store all timestamps as UTC (`2026-04-06T14:30:00.000Z`) in the database and convert to local time only at the presentation layer. For date arithmetic, **date-fns v4** (~13 kB, tree-shakeable) is production-ready today. The **Temporal API** (Stage 3, shipping in browsers since mid-2025) offers first-class timezone-aware types (`Temporal.ZonedDateTime`) that make DST bugs structurally impossible. Plan a migration path; use the `@js-temporal/polyfill` (~40 kB) in the meantime for critical timezone logic.

Calendar systems are supported via BCP 47 extensions: `ja-JP-u-ca-japanese` renders dates in the Reiwa era, `th-TH-u-ca-buddhist` adds 543 years to the Gregorian year, and `ar-SA-u-ca-islamic-umalqura` formats in the Hijri calendar used in Saudi Arabia.

Build **custom React hooks** that memoize `Intl` formatter instances by locale to avoid creating new objects on every render:

```tsx
export function useFormatCurrency(currency: string = 'CAD') {
  const locale = useLocale();
  return useMemo(() => {
    const fmt = new Intl.NumberFormat(locale, { style: 'currency', currency });
    return (amount: number) => fmt.format(amount);
  }, [locale, currency]);
}
```

---

## Locale detection cascades from URL through GeoIP to defaults

The recommended resolution order for a SaaS product is: **explicit URL path** → cookie → user profile (DB) → Accept-Language header → GeoIP → application default. Each layer serves a different scenario. The URL is authoritative for SEO crawlers, the cookie persists a manual choice across sessions, and the user profile syncs preferences across devices for authenticated users.

**Path prefix** (`app.com/fr-CA/dashboard`) is the best URL strategy for public/marketing pages: it preserves domain authority (unlike subdomains), is crawlable by search engines, and is straightforward to implement. For authenticated SaaS dashboards behind login, use **cookie-based locale** without URL prefixes — these pages aren't indexed, and locale-free URLs are cleaner.

With Next.js App Router, the built-in i18n routing was removed. **next-intl** is the standard replacement, providing middleware-based locale detection, `[locale]` dynamic segments, and cookie persistence:

```ts
// src/i18n/routing.ts
export const routing = defineRouting({
  locales: ['en-US', 'en-CA', 'fr-CA', 'fr-FR', 'de-DE'],
  defaultLocale: 'en-US',
  localePrefix: 'as-needed',
  localeCookie: { name: 'NEXT_LOCALE', maxAge: 31536000 },
});
```

**Locale fallback chains** prevent blank screens when a specific regional translation is missing. Configure `fr-CA → fr → en` so that a missing French-Canadian string falls back to generic French before English. BCP 47 tags (`fr-CA`, `en-CA`, `de-DE`) should be used consistently across your entire stack — URLs, API headers, database records, and translation files.

**GeoIP is a country signal, not a language signal.** Canada is bilingual; Germany has Turkish-speaking users; Switzerland has four languages. Use Cloudflare's `CF-IPCountry` header or Vercel's `x-vercel-ip-country` as a secondary hint, never as the sole determinant. Always provide a visible language switcher.

For SEO, every localized public page needs **reciprocal hreflang tags** in `<head>` plus a self-referencing canonical. The `x-default` points to your fallback (typically `en-US`). All hreflang links must be reciprocal — if page A references page B, page B must reference page A — or Google ignores the entire set. Use absolute URLs, return 200 status, and implement via XML sitemap for sites with many pages.

---

## Translation workflows that ship continuously, not per-release

**Flat keys** (`checkout.paymentForm.submitButton`) beat nested JSON at scale because diffs are single-line and merge conflicts are trivial. Organize by feature domain, not by page: `common.json`, `checkout.json`, `settings.json`. Each namespace enables lazy loading and prevents one team's translations from blocking another's.

Never reuse keys across different UI contexts — `userProfile.buttons.save` and `documentEditor.buttons.save` should be separate keys because translators may need different wording depending on context. Attach **screenshots and character limits** to every key in your TMS so translators can see exactly where strings appear.

Among continuous localization platforms, **Crowdin** (from €45/month) offers the best value for startups: 700+ integrations, robust GitHub sync via `crowdin.yml`, over-the-air updates for React Native via `@crowdin/ota-client`, in-context editing, and automatic screenshot capture. **Phrase** (from ~$67/month) excels at enterprise workflows with strong Translation Memory from the Memsource acquisition. **Lokalise** ($120/month) has the best Figma plugin for designer-translator collaboration. **POEditor** ($12.74/month) is the most affordable option for smaller teams.

**Over-the-air translation updates** are critical for React Native, where app store review cycles make per-release translation updates impractical. Crowdin OTA uses a CDN vault (AWS CloudFront) that the SDK fetches at app launch, with device caching for offline use. Alternatively, use `i18next-http-backend` pointed at your own CDN for a vendor-neutral approach.

For machine translation, **DeepL** produces the most natural European language translations (EN↔FR is particularly strong for Canadian French) at $25/M characters. Use MT with light human post-editing for UI strings and error messages; use full human translation for marketing copy and legal text. Translation Memory achieves **40–60% leverage** on UI strings, compounding savings with each release.

**File format recommendation**: JSON as primary (native to the JS ecosystem, all TMS platforms support it), XLIFF for exchange with professional translation agencies, and TMX for Translation Memory portability between tools.

---

## Multi-region deployment starts with data residency on day one

The most consequential architectural decision is **storing a `geo_partition` column on every user record from the beginning**. This makes future geo-partitioned database sharding seamless and satisfies data residency requirements without a painful migration.

**Quebec's Law 25** is the strictest privacy regulation in North America — stricter than PIPEDA and aligned with GDPR. It requires **opt-in consent** for tracking technologies, mandatory Privacy Impact Assessments for data transfers even within Canada, privacy-by-default settings, and creates a **private right of action** with minimum C$1,000 damages. Penalties reach C$25M or 4% of worldwide turnover. GDPR adds right to erasure, data portability, and fines up to €20M or 4% of global turnover. CCPA uses an opt-out model with "Do Not Sell/Share" requirements.

For database architecture, start with **PostgreSQL on AWS Aurora in `ca-central-1`** to serve both Canadian and US users. When EU expansion arrives, migrate to **YugabyteDB** with row-level geo-partitioning (100% open-source, 85% PostgreSQL compatibility) or add Aurora Global Database secondaries. YugabyteDB's tablespace-based partitioning pins rows to specific regions at the database level:

```sql
CREATE TABLE users_eu PARTITION OF users
  FOR VALUES IN ('EU') TABLESPACE eu_tablespace;
CREATE TABLE users_ca PARTITION OF users
  FOR VALUES IN ('CA') TABLESPACE ca_tablespace;
```

This achieves **~2ms read latency** within-region and enforces data residency at the infrastructure level.

For latency optimization, deploy static assets globally via CDN and use **Cloudflare Workers** (300+ PoPs, ~0ms cold starts via V8 isolates) for edge middleware: geo-routing, consent banner logic, language detection, and feature flag evaluation. Use **LaunchDarkly** with `country` and `locale` context attributes for regional feature variation, enabling different payment methods, legal disclaimers, and UI features per jurisdiction.

Deploy a **consent management platform** (Osano or Enzuzo for Canadian compliance, OneTrust for enterprise) that auto-detects visitor jurisdiction and serves the correct consent banner: strict opt-in for Quebec and EU, opt-out for California, notice-based for other regions.

---

## International addresses and names defy Western assumptions

Address formats vary dramatically: German addresses place the building number **after** the street name, Japanese addresses go from largest to smallest (postal code → prefecture → city → building), and Brazilian addresses include a neighborhood (bairro) field. A single address form cannot serve all countries.

Build **country-driven adaptive forms** where selecting the country dynamically changes visible fields, field order, labels, and validation rules. Use Google's `libaddressinput` metadata (available via the `localized-address-format` npm package, ~5 kB) for country-specific formatting rules. For address autocomplete, **Mapbox** offers the best value (100K free requests/month, no branding requirement), while **Smarty** provides postal-grade USPS validation for US/CA billing addresses.

For phone numbers, **`libphonenumber-js`** (145 kB) is the lightweight alternative to Google's full library (550 kB). It handles parsing, validation, formatting (national, international, E.164), and as-you-type formatting. Store all phone numbers in **E.164 format** (`+14155552671`) and format for display using the user's locale. The `react-phone-number-input` component provides a country selector with flags and outputs E.164.

**Name ordering** trips up nearly every Western-centric form. Chinese, Japanese, Korean, Hungarian, and Vietnamese cultures place family name first. Use field labels "Given name" and "Family name" instead of "First name" / "Last name." Allow mononymous names (common in Indonesia and Brazil). Add a "Display name" field and store both native script and Latin transliteration where applicable. Detect display order from locale:

```js
const familyFirst = ['zh', 'ja', 'ko', 'hu', 'vi'].some(
  lang => locale.startsWith(lang)
);
```

Postal code validation varies from US 5-digit ZIP to Canada's `A1A 1A1` alphanumeric pattern to Japan's `NNN-NNNN` format. The `postcode-validator` npm package handles validation for most countries.

---

## Cultural localization goes far beyond translating strings

**Color symbolism** differs enough to matter in UI design. Red signals danger in the West but luck and prosperity in China. White means purity in Western cultures but mourning in parts of East Asia. Green is sacred in Islamic cultures. For a SaaS expanding into diverse markets, use CSS custom properties as theme tokens that can be overridden per locale when culturally necessary.

**Payment method preferences** vary dramatically by region. The Netherlands is dominated by **iDEAL**, Germany by SEPA Direct Debit and Giropay, and Brazil by **PIX** and Boleto Bancário. Stripe's Payment Element automatically displays locale-appropriate methods based on the customer's country and currency — always use it instead of the legacy card element. Enable region-specific payment methods in the Stripe Dashboard and let the Payment Element handle display ordering.

**Units of measurement** need locale-aware auto-selection: metric for Canada (officially) and EU, imperial for US. Canada is a special case where metric is official but imperial persists colloquially for height and weight — consider a user preference toggle. Use `Intl.NumberFormat` with `style: 'unit'` for automatic formatting: `new Intl.NumberFormat('en', { style: 'unit', unit: 'kilometer', unitDisplay: 'long' }).format(42)` renders "42 kilometers."

For Quebec specifically, **Bill 96** requires all customer-facing content — UI, terms of service, privacy policies, product descriptions — to be fully available in French. This is not a translation nice-to-have; it's a legal mandate with active OQLF enforcement (10,000+ complaints filed between April 2024 and March 2025). Never auto-translate legal content — use qualified legal translators.

Regional content calendars matter for SaaS engagement: Canada's Thanksgiving falls in October (not November), **Saint-Jean-Baptiste Day** (June 24) is bigger than Canada Day in Quebec, and August is dead season in France and Italy.

---

## Engineering enforcement closes the loop on i18n quality

Without automated enforcement, i18n discipline erodes within weeks. The minimum viable CI pipeline has three stages: lint source code for hardcoded strings, validate translation files for completeness and syntax, and run visual regression tests across locales.

**ESLint enforcement** is the first line of defense. `eslint-plugin-formatjs` provides `no-literal-string-in-jsx` to catch hardcoded strings, `enforce-description` to require translator context on every message, and `enforce-plural-rules` to mandate the `other` category. For i18next users, `eslint-plugin-i18next` offers `no-literal-string` with configurable ignores for `className`, `data-testid`, and console calls. GoDaddy's `eslint-plugin-i18n-json` validates translation files directly: ICU syntax checking (`valid-message-syntax` with `{ syntax: 'icu' }`), key consistency across locales (`identical-keys`), and sorted keys to minimize merge conflicts.

A critical custom rule prevents dynamic translation keys (`t(\`error.${code}\`)`), which break static extraction. Only string literals should be passed to translation functions.

**CI pipeline** (GitHub Actions):

```yaml
jobs:
  i18n-lint:
    steps:
      - run: npx eslint "src/**/*.{ts,tsx}" --rule 'formatjs/no-literal-string-in-jsx: error'
      - run: npm run i18n:extract && git diff --exit-code locales/
      - run: npx eslint --ext .json locales/ --rule 'i18n-json/valid-message-syntax: [2, {syntax: icu}]'
  
  visual-regression:
    steps:
      - run: npx playwright test tests/i18n-visual/
```

The extraction drift check (`git diff --exit-code locales/`) fails the build if extracting keys produces any changes, ensuring developers commit extraction results alongside code changes.

**Visual regression testing** with Playwright captures screenshots across at least four representative locales: English (baseline), German (long text), Arabic (RTL), and Japanese (CJK). Run these in Docker containers for font consistency. Chromatic and Percy provide cloud-based snapshot diffing with team review workflows.

Pre-commit hooks via Husky + lint-staged run ESLint and extraction on staged files, catching violations before they reach CI. Set `maxNewHardCodedPerPR: 0` in i18nGuard configuration for zero tolerance on new hardcoded strings.

---

## Conclusion

The production i18n stack for a React/React Native SaaS targeting Canada, US, and EU rests on a few irreversible early decisions. **Adopt ICU MessageFormat** (via LinguiJS or i18next-icu) before writing the first translatable string — retrofitting plural and gender rules across thousands of keys is prohibitively expensive. **Use CSS logical properties exclusively** in new code and convert existing physical properties with stylis plugins. **Store UTC timestamps and a `geo_partition` column on every record** from day one to make timezone rendering and future data residency compliance trivial.

The most underestimated risk is Quebec's Bill 96, which carries GDPR-level penalties and active enforcement. Full French parity — UI, legal content, customer service — is a launch requirement for the Canadian market, not a post-launch enhancement.

For ongoing quality, the combination of ESLint's `no-literal-string-in-jsx`, extraction drift detection in CI, and pseudo-localization testing catches the vast majority of i18n regressions before they reach translators. Pair this with Crowdin's continuous localization and OTA delivery, and translation becomes a continuous flow rather than a release bottleneck. The goal is an architecture where adding a new locale requires only translations and legal review — zero code changes.