# Go production engineering rules for AI coding agents

**This is a comprehensive reference of Go-specific production patterns, failure modes, and best practices designed to be encoded into AI coding agent configuration files** (CLAUDE.md, SKILL.md, .cursorrules) for Go services deployed on Cloud Run and Fly.io handling payments, Kafka, and PostgreSQL. Every section below contains battle-tested rules drawn from the Go team's guidance, major open-source projects (Kubernetes, CockroachDB, HashiCorp), and real-world CLAUDE.md files found on GitHub.

---

## Concurrency bugs that static analysis misses

Go's concurrency model creates failure modes invisible to `go vet` and `staticcheck`. The race detector only catches data races on exercised code paths, missing logical races, deadlocks, and goroutine leaks entirely.

**Goroutine leaks are the most common production concurrency bug.** They manifest as steadily growing `runtime.NumGoroutine()` until OOM. Five patterns dominate: blocked sends to unbuffered channels with no reader, range-over-channel where the sender never calls `close()`, forgotten `context.WithCancel` where the goroutine ignores `ctx.Done()`, leaked `time.NewTicker` without `defer ticker.Stop()`, and pipeline producers that never close their output channels. Detect leaks with `uber-go/goleak` (`defer goleak.VerifyNone(t)` in every test), export `runtime.NumGoroutine()` as a Prometheus gauge, and in Go 1.24+ use `synctest.Test()` to detect durably blocked goroutines without `time.Sleep`.

**Channel discipline requires three inviolable rules.** First, only the sender closes a channel — closing from the receiver side or closing with multiple senders causes panics. For multiple senders, coordinate via `sync.WaitGroup` and a dedicated closer goroutine. Second, always check the ok value on receive (`v, ok := <-ch`) or use `range` which handles closure automatically. Third, use directional channel types (`chan<- int`, `<-chan int`) in all function signatures to enforce send/receive contracts at compile time.

**sync.Map vs RWMutex has a clear decision boundary.** Default to `map` + `sync.RWMutex`. Switch to `sync.Map` only when profiling reveals RWMutex contention in scenarios with **>95% reads** and <5% writes, append-only caches where keys are written once and read many times, or disjoint key access where goroutines read/write non-overlapping keys. `sync.Map` loses compile-time type safety (stores `interface{}`), doesn't expose `len()`, and has expensive dirty-map promotion overhead above 10-20% write ratios.

**Context cancellation propagation failures** cause cascading timeouts in payment services. Never store `context.Context` in a struct — pass it as the first parameter. Always include `ctx.Done()` in select statements for channel operations. Always `defer cancel()` after `context.WithCancel/Timeout/Deadline`. Use `context.WithCancelCause` (Go 1.20+) to record *why* cancellation happened. Remember that a child timeout longer than its parent is silently ineffective.

**errgroup requires explicit cancellation checking.** Always use `errgroup.WithContext(ctx)`, not bare `errgroup.Group`. The critical mistake: errgroup cancels the derived context when any goroutine returns an error, but **it does not stop other goroutines** — each goroutine must independently check `ctx.Done()`. Use `g.SetLimit(n)` for bounded concurrency. Only the first error is returned by `Wait()`, so log details inside each task.

**The race detector is sound but incomplete.** It adds 5-10× memory and 2-20× execution time, finding only races that actually manifest during execution. Run integration tests and realistic load tests with `-race`, not just unit tests. Use `GORACE="halt_on_error=1"` to stop on the first race. The detector misses logical races, deadlocks, starvation, and data races hidden by happens-before relationships created by mutex acquisition order in a particular execution.

---

## Memory management at scale in containers

**GOMEMLIMIT is mandatory for containerized Go services.** Set `GOMEMLIMIT` to **80-90% of container memory** (e.g., 512 MiB container → `GOMEMLIMIT=400MiB`, 3 GiB container → `GOMEMLIMIT=2750MiB`). This Go 1.19+ soft memory limit prevents OOM kills by making the GC more aggressive as the heap approaches the ceiling. It does not cover cgo memory, memory-mapped files, or OS-held memory. Without `GOMEMLIMIT`, a Go service in a 512 MiB container will OOM under moderate load because `GOGC=100` only triggers GC when the heap doubles, without awareness of container limits.

**Leave GOGC at 100 unless profiling shows a GC bottleneck.** `GOGC` controls GC frequency via heap growth ratio — `GOGC=100` triggers GC when the heap doubles. Doubling GOGC approximately halves GC CPU cost but doubles memory overhead. The `GOGC=off` + `GOMEMLIMIT` pattern (memory grows freely until the limit, then full GC) maximizes throughput but risks a "death spiral" where the GC runs constantly if live heap approaches the limit. Monitor `GCCPUFraction` via `runtime.ReadMemStats()` — target below 5%.

**sync.Pool survives exactly two GC cycles.** Since Go 1.13's victim cache mechanism, pooled objects survive at least two GC cycles before removal (previously, every GC cleared the entire pool). Always reset objects on `Get()` or `Put()` — stale data causes subtle bugs. Pool is slower than direct allocation for trivial types (~3.9 ns/op vs ~0.24 ns/op); use it only for expensive-to-allocate objects like `bytes.Buffer`, JSON encoders, and protocol buffers. Never store references to pooled objects outside the Get/Put lifecycle.

**Heap escape analysis reveals hidden allocations.** Run `go build -gcflags='-m' 2>&1 | grep "escapes\|moved to heap"` to audit performance-critical code. Ten common escape triggers: returning a pointer from a function, storing in a global variable, goroutine closure capture, channel sends, objects larger than ~64 KB, `make([]T, n)` with runtime-determined `n`, interface conversion (boxing), passing to variadic `interface{}` functions like `fmt.Println`, and deferred closures. Return values (not pointers) for small structs under 100 bytes. Pass goroutine-captured variables as function parameters instead of closure capture to prevent escape.

**Pre-allocation eliminates the most common allocation waste.** Always use `make([]T, 0, knownCap)` when the capacity is known or estimable. Use `strings.Builder` instead of `+=` in loops (which causes O(n²) allocations). Avoid `fmt.Sprintf` in hot paths — use `strconv` functions. Order struct fields largest-to-smallest to minimize padding (use the `fieldalignment` tool). Use arrays instead of slices for fixed-size data — `[4]byte` stays on the stack while `[]byte` may escape.

---

## Error handling patterns from production Go projects

**The Go ecosystem has converged on "wrap at the bottom, log at the top."** Low-level functions wrap errors with context using `fmt.Errorf("operation: %w", err)`. Mid-level functions continue wrapping. Top-level handlers (HTTP handlers, main functions) log the complete error chain and translate it to an appropriate response. Never both log and return an error — this produces duplicate log entries that confuse debugging.

**Error strings must be lowercase, without punctuation, and without redundant words.** Write `fmt.Errorf("reading user %d: %w", id, err)`, not `fmt.Errorf("Failed to read user: %w", err)`. The word "failed" is redundant in an error. This convention from the Go team and GitLab's style guide ensures composable error chains: `initApp: loadConfig(/etc/app.yaml): open: no such file`.

**Use `%w` internally and `%v` at API boundaries.** Within a package, `%w` preserves the error chain for `errors.Is`/`errors.As`. At package/service boundaries where you don't want callers to depend on internal error types, use `%v` to break the chain. The Go blog states: "When you return an error from another package, convert it to a form that does not expose the underlying error, unless you are willing to commit to returning that specific error in the future."

**CockroachDB's `cockroachdb/errors` library** is the gold standard for distributed systems error handling. It provides automatic stack traces on `errors.New()`, network-portable errors via protobuf serialization, PII-safe error details for Sentry reporting, multi-cause errors, and forward compatibility for errors from newer software versions. Consider it for payment services where error traceability across service boundaries is critical.

**Kubernetes uses typed errors with predicate functions**, not sentinel values. The `StatusError` type wraps HTTP status codes with Kubernetes-specific metadata, and ~20+ predicate functions (`IsNotFound`, `IsConflict`, `IsAlreadyExists`, `IsTooManyRequests`) check error conditions without direct type assertions. For aggregate errors, K8s is migrating from `NewAggregate` to `errors.Join` (Go 1.20+).

**Three error representation strategies exist on a spectrum of coupling.** Sentinel errors (`var ErrNotFound = errors.New("not found")`) become part of the public API and are appropriate only for well-known conditions callers need to match, like `io.EOF`. Custom error types with `Unwrap()` methods provide structured data but create coupling. Opaque errors (just returning `error`) provide maximum flexibility with minimum coupling. Dave Cheney's hierarchy: prefer opaque errors → behavior assertions → error types → sentinel errors, from most to least flexible.

**Ben Johnson's "Failure is your Domain" pattern** separates error consumers: the application needs error codes for programmatic handling, the end user needs human-readable messages without internal details, and the operator needs full stack traces. Define a domain error type with `Code`, `Message`, `Op`, and `Err` fields. At API boundaries, domain errors map to HTTP/gRPC codes; non-domain errors return a generic 500 with "An internal error has occurred" while logging full details for operators.

**Panics are acceptable in exactly three situations**: the `Must` pattern at init time for known-good values (`regexp.MustCompile`, `template.Must`), programmer errors representing impossible states (exhaustive switch default), and internal control flow within a package caught at the package boundary (as `encoding/json` does). Libraries must never panic. HTTP servers should always recover panics at the boundary with middleware.

---

## Interface design philosophy from the Go team

**"The bigger the interface, the weaker the abstraction"** is Rob Pike's most cited Go proverb. The standard library embodies this: `io.Reader` has one method, `io.Writer` has one method, `error` has one method, `http.Handler` has one method. These single-method interfaces are satisfied by an enormous number of types, making them maximally reusable and trivially testable. Target 1-3 methods per interface; 4+ methods signal the interface should likely be split.

**"Accept interfaces, return structs" is the fundamental API design principle.** Functions should accept interface parameters specifying only the behaviors needed (enabling loose coupling and easy testing) and return concrete struct types (providing full access to all methods, enabling extensibility without breaking changes, and supporting IDE code navigation). Go's implicit interface satisfaction makes this work — the caller can assign the returned struct to any interface it happens to satisfy.

**Define interfaces at the consumer site, not the producer site.** This is the single largest divergence from Java/C#. The Go Code Review Comments (official Google guide) states: "Go interfaces generally belong in the package that uses values of the interface type, not the package that implements those values." Each consumer defines only the methods it actually calls, following the Interface Segregation Principle naturally. Different consumers can define different interfaces over the same concrete type, each with different method subsets. Keep consumer-side interfaces **unexported** when possible.

**Interface pollution is the most common Go anti-pattern from Java/C# developers.** Rob Pike's guidance: "Don't design with interfaces, discover them." Start with concrete types. Extract interfaces only when you have at least two implementations or a clear testing need. Go's implicit interface satisfaction means you can extract an interface later without modifying any existing code. The `iface` linter detects preemptive interfaces, opaque returns, and other interface pollution patterns.

**`interface{}`/`any` says nothing** — Pike's other interface proverb. The empty interface holds any value but provides zero type safety. Since Go 1.18, prefer generics with type constraints over `interface{}` when the function operates on multiple types. Use `any` (the alias) instead of `interface{}` in all new code. Passing values through `interface{}` forces heap allocation via boxing, impacting performance in hot paths.

---

## Project layout that matches Go team guidance

**The Go team published official layout guidance at `go.dev/doc/modules/layout` that is intentionally minimal.** It recommends `cmd/` for multiple binaries, `internal/` for private packages, and flat root-level packages for libraries. It does not mention `pkg/`. For server projects, the key quote: "It's recommended to keep the Go packages implementing the server's logic in the internal directory."

**The golang-standards/project-layout repository (55k stars) is not a standard.** Russ Cox, Go tech lead, filed Issue #117 stating: "The vast majority of packages in the Go ecosystem do not put the importable packages in a pkg subdirectory. It is unfortunate that this is being put forth as 'golang-standards' when it really is not." The repo contains no actual Go code — just empty directories. Do not blindly copy its structure, especially for small-to-medium projects.

**Skip `pkg/` for nearly all projects.** `internal/` already signals "private" via compiler enforcement — everything NOT in `internal/` is implicitly public. The `pkg/` directory adds unnecessary nesting to import paths (`github.com/user/repo/pkg/foo` vs `github.com/user/repo/foo`). Kubernetes uses `pkg/` because it predates the debate; HashiCorp projects do not. For a payment service or Kafka consumer, the recommended layout is:

```
myservice/
  cmd/
    server/main.go
    worker/main.go
  internal/
    handler/
    service/
    repository/
    kafka/
    model/
  go.mod
  Dockerfile
```

**`internal/` is compiler-enforced since Go 1.5.** Packages under `internal/` can only be imported by code in the directory tree rooted at its parent. This means you can confidently refactor internal APIs without worrying about breaking external consumers. For server projects, put virtually everything in `internal/`. Keep `main.go` in `cmd/` minimal — parse flags, wire dependencies, and call into `internal/`.

**Avoid generic package names.** Never use `utils`, `helpers`, `common`, or `base` — use descriptive names like `auth`, `storage`, `validator`, `billing`. Avoid deep nesting (`internal/services/user/handlers/http/v1/`); keep it to 1-2 levels. Never use `src/` — that's a Java pattern, not idiomatic Go.

---

## Testing best practices from the community

**Table-driven tests are the universal Go testing pattern.** Define a slice of test case structs with `name`, inputs, expected output, and `wantErr bool` fields, then iterate with `t.Run()`. Use descriptive names like `"empty input returns error"`, not `"test1"`. For complex setups, include a `setup func()` or `check func(t *testing.T, got Result)` field.

**testcontainers-go replaces mocks for integration testing with real infrastructure.** The PostgreSQL module spins up a real Postgres container: `postgres.Run(ctx, "postgres:16-alpine", postgres.WithDatabase("testdb"))`. The Kafka module does the same for Kafka: `kafka.Run(ctx, "confluentinc/confluent-local:7.5.0")`. Always use `t.Cleanup()` (not `defer`) for container termination — it waits for parallel subtests to complete. The postgres module supports snapshot/restore for fast test isolation: take a snapshot after migrations, restore between tests.

**For mock libraries, mockery (with testify) is the pragmatic default.** gomock (Uber fork at `go.uber.org/mock`) provides a more powerful DSL for detailed interaction verification with ordered calls and argument matchers. counterfeiter generates self-contained fakes popular in the Cloud Foundry ecosystem. For small interfaces, **hand-written fakes are the most idiomatic Go approach** — no code generation required. A hand-written fake implementing a 2-method interface is clearer than any generated mock.

**The race detector belongs in every CI pipeline.** Add `go test -race ./...` to CI. It adds 2-20× slowdown and 5-10× memory, but has zero false positives. It only catches races in exercised code paths, so test coverage matters. There's an **8128-goroutine limit** that can be hit in highly parallel test suites. For integration tests, use `GORACE="halt_on_error=1"`.

**`t.Parallel()` has a critical gotcha with loop variables in Go <1.22.** Always shadow the loop variable: `tt := tt` before `t.Run(tt.name, func(t *testing.T) { t.Parallel(); ... })`. Go 1.22+ changed loop variable semantics, making this unnecessary, but keep it for backward compatibility. Both the parent test and subtests must call `t.Parallel()` for subtests to run concurrently.

**Golden file testing stores expected output in `testdata/` directory files.** Compare actual output against `.golden` files, update with a `-update` flag. This pattern is used by `gofmt`, `go/format`, and many Go tools. The `testdata/` directory is ignored by `go build`. Excellent for testing JSON APIs, code formatters, CLI output, and serialization.

**Use `t.Cleanup()` instead of `defer` for test resource cleanup.** `t.Cleanup()` runs after the test and all its subtests complete, while `defer` runs when the enclosing function returns — critical when `t.Parallel()` is involved. Use `t.TempDir()` for temporary directories (auto-cleaned), `t.Helper()` in test helper functions for better error reporting, and `TestMain` for one-time expensive setup (start containers, seed data).

---

## Performance profiling workflow

**pprof is the primary diagnostic tool and has zero cost until activated.** Expose it via `import _ "net/http/pprof"` on a separate port not publicly accessible. Six profile types serve different diagnoses: CPU (where time is spent), heap/inuse_space (live memory for leak detection), allocs/alloc_space (all allocations for GC pressure), goroutine (leak detection), block (I/O and channel contention), and mutex (lock contention). Block and mutex profiling add continuous overhead — enable only during debugging via `runtime.SetBlockProfileRate()` and `runtime.SetMutexProfileFraction()`.

**The diagnostic decision tree determines which profile to use.** Service is CPU-bound → CPU profile → flame graph → optimize hot functions. High memory or OOM → heap profile (inuse_space). High GC pressure → allocs profile (alloc_space) → reduce allocations with sync.Pool. Goroutine leak → goroutine profile → find growing counts. Lock contention → mutex profile. pprof looks clean but still slow → `go tool trace` for GC pauses, scheduler delays, and I/O blocking.

**Flame graphs are built into pprof since Go 1.11.** Run `go tool pprof -http=:8081 cpu.prof` and navigate to the Flame Graph tab. The x-axis represents proportion of sampled resource (wider = more time), the y-axis shows call stack depth. Follow the widest bars from bottom to top to find the hot path. Wide plateaus at the top indicate functions doing significant work themselves.

**benchstat requires at least 10 runs for statistical significance.** Run `go test -bench=. -count=10 > old.txt`, make changes, run again into `new.txt`, then `benchstat old.txt new.txt`. Results show percentage change with p-value; `~` means no statistically significant difference. Always use `-benchmem` for allocation reporting and `-count=10` minimum.

**Benchmark best practices prevent false results.** Use `b.ResetTimer()` after expensive setup, `b.ReportAllocs()` for allocation counts, and store results in a package-level variable to prevent dead code elimination by the compiler. Use `b.RunParallel()` to benchmark concurrent performance. The compiler can optimize away function calls whose results are unused.

**Pyroscope (now Grafana Pyroscope) provides continuous profiling in production** with ~2-5% overhead. It integrates as a Go library supporting CPU, alloc, goroutine, and mutex profiles with flame graph UI and diff comparison between time ranges. Parca is the alternative with eBPF-based zero-instrumentation profiling at <1% overhead, ideal for infrastructure-wide profiling without code changes.

---

## Module management gotchas

**GOPRIVATE is the single most important setting for private modules.** Set `GOPRIVATE=github.com/mycompany/*` to skip both the module proxy and checksum database for private paths. Without it, `go mod download` fails with `410 Gone` because `sum.golang.org` can't access private repos. In CI, use Docker BuildKit secrets (not build args) for credentials: `RUN --mount=type=secret,id=NETRC,dst=/root/.netrc go mod download`.

**Minimum Version Selection (MVS) is fundamentally different from npm/pip/cargo.** Go selects the minimum version satisfying all constraints, not the newest. This means builds are reproducible without a lock file — `go.mod` IS the lock file. `go get -u ./...` upgrades ALL transitive dependencies to latest, not just direct ones — usually not what you want. Use `go get foo@latest` (without `-u`) to upgrade only a specific dependency.

**Never commit `go.work` files — add them to `.gitignore`.** Workspace mode (Go 1.18+) replaces local `replace` directives for multi-module development. Run production builds with `GOWORK=off go build ./...` to ensure `go.work` isn't accidentally influencing the build. Module vendoring is ignored in workspace mode.

**`go mod tidy` has three gotchas that bite in CI.** It removes dependencies only used in build-tagged files (like `//go:build integration`) if you don't specify that tag. It does NOT remove stale `replace` directives. And its behavior differs across Go versions — Go 1.17+ adds comprehensive indirect dependency entries.

**Major version suffixes are required starting at v2.** The module path must include `/v2`, `/v3`, etc., and ALL import paths within the module must be updated. The most common mistake is forgetting to update internal import paths after changing the module path. Use module retraction (`retract v1.0.0 // critical auth bug`) to mark published versions as "do not use" without breaking existing builds.

---

## Dockerfile patterns for Cloud Run and Fly.io

**The canonical production Dockerfile uses multi-stage builds with distroless.** Build in `golang:1.25-alpine`, run in `gcr.io/distroless/static-debian12:nonroot`. This produces images of **7-12 MB** with zero CVEs, included CA certificates and timezone data, and a pre-configured nonroot user (UID 65532). The complete production Dockerfile:

```dockerfile
FROM golang:1.25-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build \
    -trimpath -ldflags="-s -w" -o /app/server .

FROM gcr.io/distroless/static-debian12:nonroot
COPY --from=builder /app/server /server
USER nonroot:nonroot
EXPOSE 8080
ENTRYPOINT ["/server"]
```

**Compilation flags each serve a specific purpose.** `CGO_ENABLED=0` produces a pure Go static binary with no C library dependencies — essential for scratch/distroless. `-ldflags="-s -w"` strips the symbol table and DWARF debug info, reducing binary size by **20-30%**. `-trimpath` removes filesystem paths from the binary for reproducibility and security.

**Distroless beats scratch for nearly all production use cases.** Scratch is 0 bytes but has no CA certificates (HTTPS fails), no timezone data (`time.LoadLocation` panics), and no `/etc/passwd` for non-root users. Distroless includes all three out of the box. If you must use scratch, either copy CA certs and zoneinfo from the builder stage, or embed them in the binary with `-tags timetzdata` and `import _ "github.com/breml/rootcerts"`.

**Docker layer caching for Go modules saves minutes per build.** Copy `go.mod` and `go.sum` before source code so `go mod download` only re-runs when dependencies change. For even faster builds, use BuildKit cache mounts: `RUN --mount=type=cache,target=/go/pkg/mod --mount=type=cache,target=/root/.cache/go-build go build ...`

**Cloud Run requires reading the `PORT` environment variable** (default 8080) and benefits from fast cold starts — scratch/distroless Go images achieve sub-second cold starts at 5-15 MB. Cloud Run sends SIGTERM with a 10-second default grace period (configurable). Fly.io deploys Docker images as Firecracker microVMs with standard SIGTERM handling and configurable grace periods.

---

## Graceful shutdown for HTTP servers and Kafka consumers

**Graceful shutdown must follow reverse dependency order.** Stop entry points first (HTTP server, gRPC server), then drain background workers, flush async producers, close message consumers, close database and Redis connection pools, and finally flush logs. Getting this order wrong causes errors — shutting down the database before the HTTP server means in-flight requests hit closed connections.

**The canonical signal handling pattern uses `signal.NotifyContext` (Go 1.16+).** Create `ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)`, then `<-ctx.Done()` to block until a signal arrives. Budget **80% of the termination grace period** for actual shutdown (e.g., 25 seconds if Kubernetes `terminationGracePeriodSeconds` is 30).

**HTTP server shutdown with `srv.Shutdown(ctx)` closes listeners, waits for in-flight requests, then returns.** Always set explicit timeouts on the server: `ReadTimeout: 10s`, `WriteTimeout: 30s`, `IdleTimeout: 60s`. Check for `http.ErrServerClosed` from `ListenAndServe` — it's expected, not an error. For Kubernetes, implement a **two-phase drain**: mark not-ready (fail readiness probe, `atomic.Bool`), wait 5 seconds for the load balancer to drain, then shut down the server.

**Kafka consumer shutdown must commit final offsets before closing.** Stop polling for new messages, wait for in-flight message processing to complete, commit uncommitted offsets, then call `client.Close()`. This must happen after HTTP server shutdown but before closing database pools, because in-flight message processing may require database access.

---

## Database and Kafka patterns for production Go services

**pgx native with pgxpool is the correct choice for PostgreSQL in Go.** It's faster than database/sql (binary protocol vs text), supports PostgreSQL-specific features (LISTEN/NOTIFY, COPY, large objects), and automatically caches prepared statements. Key pool configuration for production: `MaxConns` ≤ (PostgreSQL `max_connections` - reserved) / number_of_app_instances, `MinConns` of 5 for warm connections, `MaxConnLifetime` of 1 hour with `MaxConnLifetimeJitter` of 5 minutes to prevent thundering herd, and `HealthCheckPeriod` of 1 minute.

**Use `pgx.BeginFunc` for transactions — it auto-commits on nil return and auto-rollbacks on error.** This eliminates the manual `defer tx.Rollback()` pattern and its associated foot-guns. For payment services needing serializable isolation, use `pgx.BeginTxFunc(ctx, pool, pgx.TxOptions{IsoLevel: pgx.Serializable}, ...)`. Query methods work directly on the pool — no need to `Acquire`/`Release` unless you need same-connection guarantees.

**franz-go is the recommended Kafka library for new Go projects.** It's pure Go (no CGo), feature-complete (every KIP), and benchmarks at **4× producing throughput** and **2-6× consuming throughput** versus confluent-kafka-go. segmentio/kafka-go is the simpler alternative. IBM/sarama (formerly Shopify/sarama) is deprecated — do not use for new projects. confluent-kafka-go requires CGo (librdkafka), complicating Docker builds with `CGO_ENABLED=0`.

**Implement at-least-once delivery with idempotent processing for payment Kafka consumers.** Disable auto-commit, process the message, then commit offsets manually. Use idempotency keys in the database (upserts, unique constraints on message ID) to handle redeliveries. For error handling, classify errors as transient (network timeout, DB unavailable — retry with backoff) or permanent (bad payload, validation failure — send to DLQ). Implement retry topics following Uber's pattern: `orders` → `orders-retry-1` (1min delay) → `orders-retry-2` (5min) → `orders-dlq`.

---

## Structured logging with slog and observability

**slog (Go 1.21+) with `JSONHandler` is the production logging standard.** Use `TextHandler` only in development. slog separates the frontend (Logger) from the backend (Handler), enabling incremental migration from Zap/Zerolog: use the slog API everywhere but wire a Zap handler as the backend initially, then swap to `slog.NewJSONHandler` when all call sites are migrated. Use `slog.SetDefault(logger)` to also bridge the old `log` package.

**Implement `LogValuer` on domain types to prevent sensitive data leaks.** Any type implementing `LogValue() slog.Value` controls its own log representation — critical for payment services where you must never log card numbers, tokens, or PII. Use `ReplaceAttr` in `HandlerOptions` to redact fields like `password` and `token`. Use `slog.LevelVar` for runtime log level changes without restart.

**Correlate logs with traces using context.** Use `InfoContext`, `ErrorContext` to pass request-scoped data. The `slog-otel` handler extracts OpenTelemetry `trace_id`/`span_id` from context into log records. Keep messages short and descriptive (what happened); use attributes for context (who, what, where). Reserve ERROR level for actionable failures — overusing it makes alerting useless.

---

## golangci-lint configuration for production services

The essential linters to enable beyond defaults, drawn from maratori's "Golden Config" (475+ GitHub stars):

- **Bug catchers (must-have)**: `errcheck` (unchecked errors), `staticcheck` (150+ checks), `govet` (suspicious constructs), `gosec` (security problems), `bodyclose` (unclosed HTTP response bodies), `sqlclosecheck` (unclosed sql.Rows/Stmt), `nilerr` (returning nil when error is not nil), `noctx` (HTTP requests without context)
- **Error handling**: `errorlint` (Go 1.13 error wrapping correctness), `wrapcheck` (external package errors are wrapped), `exhaustive` (switch statements cover all enum cases)
- **Code quality**: `gocritic` (bugs, performance, and style), `revive` (configurable golint replacement), `unparam` (unused parameters), `unconvert` (unnecessary conversions), `nakedret` (naked returns in long functions), `sloglint` (consistent slog usage)
- **Formatting**: `goimports` (import ordering), `golines` (line length)
- **Deny list via depguard**: Block `log` package (use `log/slog` instead) and `math/rand` (use `math/rand/v2`)

Relax rules for test files: disable `gocyclo`, `errcheck`, `dupl`, `gosec`, and `funlen` for `_test.go` files. Run in CI with `golangci-lint run --timeout=5m` and `only-new-issues: true` for PR-only checks.

---

## Real-world AI coding agent rules from production Go teams

Analysis of actual CLAUDE.md, .cursorrules, and Copilot instructions files found on GitHub reveals universal patterns. The most comprehensive example — a Go CLAUDE.md by maxdml with MUST/SHOULD/CAN enforcement levels — encodes rules with stable IDs (e.g., `ERR-1`, `CC-2`) enabling precise code review comments and automated policy checks. Key universal patterns across all files found:

**Every production Go CLAUDE.md includes these rules:**

- **ERR-1 (MUST)**: Wrap errors with `%w` and context: `fmt.Errorf("operation: %w", err)`
- **ERR-2 (MUST)**: Use `errors.Is`/`errors.As` for control flow; never match error strings
- **CC-1 (MUST)**: The sender closes channels; receivers never close
- **CC-2 (MUST)**: Tie goroutine lifetime to a `context.Context`; prevent leaks
- **CC-3 (MUST)**: Protect shared state with `sync.Mutex`/`atomic`; no "probably safe" races
- **CTX-1 (MUST)**: Context as first parameter; never store in structs
- **T-1 (MUST)**: Table-driven tests; deterministic and hermetic
- **T-2 (MUST)**: Run `-race` in CI; use `t.Cleanup` for teardown
- **OBS-1 (MUST)**: Structured logging (slog) with consistent fields
- **CI-1 (MUST)**: Lint, vet, test (`-race`), and build on every PR
- **CI-2 (MUST)**: Reproducible builds with `-trimpath`; embed version via `-ldflags`
- **SEC-2 (MUST)**: Never log secrets; manage via env/secret manager
- **CS-2 (MUST)**: Avoid name stutter: `package kv; type Store` not `KVStore`
- **API-2 (MUST)**: Accept interfaces, return concrete types
- **CFG-1 (MUST)**: Config via env/flags; validate on startup; fail fast
- **CS-5 (MUST)**: Use input structs for functions receiving more than 2 arguments

**GitHub's official Copilot instructions for Go** add: prefer generics over `any` when possible, use `any` instead of `interface{}`, use pointer receivers for large structs or when modifying the receiver, value receivers for small immutable structs, and if Go ≥ 1.22 use the enhanced ServeMux with method-based routing.

---

## Comprehensive anti-patterns checklist

These are the patterns to flag and fix automatically in AI-assisted Go development:

- **init() overuse**: Move initialization to explicit functions called from `main()`. The pgx author specifically recommends against creating connection pools in `init()`. Errors in `init()` can only be handled via panic or log.Fatal
- **Global state**: Package-level variables create hidden dependencies and race conditions. Use dependency injection via struct fields or function parameters
- **Ignored errors**: `result, _ := someFunc()` silently swallows errors. The `errcheck` linter catches these. If intentionally ignoring, add a comment explaining why
- **Missing resource cleanup**: Always `defer resp.Body.Close()`, `defer rows.Close()`, `defer f.Close()`. The `bodyclose` and `sqlclosecheck` linters enforce this
- **Default HTTP client**: `http.Get()` uses the default client with no timeout. Always create `http.Client{Timeout: 5*time.Second}`. The `noctx` linter catches `http.Get()` calls
- **Context in struct fields**: Breaks the context lifecycle model. Pass context as the first function parameter. The `containedctx` linter detects this
- **Unbounded goroutine spawning**: `go handleRequest(req)` without limits causes OOM under load. Use worker pools, semaphore pattern, or `errgroup` with `SetLimit`
- **Single model anti-pattern**: Using one struct for API response, DB model, and business logic creates tight coupling. Always separate API models, DB models, and domain models
- **String concatenation in loops**: `s += "..."` causes O(n²) allocations. Use `strings.Builder`
- **Naked returns**: Confusing in functions longer than 5 lines. Use explicit returns. Enable `nakedret` linter

---

## Conclusion

The rules in this document encode hard-won production knowledge that static analysis and testing alone cannot catch. Three insights stand out as non-obvious.

First, **memory management in containers requires active configuration** — `GOMEMLIMIT` at 80-90% of container memory is not optional but mandatory for preventing OOM kills in Go services, yet most Go tutorials and starter templates omit it entirely. Second, **interface design in Go is the inverse of Java** — define interfaces at the consumer, not the producer; start with concrete types and extract interfaces only when actual need arises; the compiler's implicit satisfaction means you never need to plan interfaces in advance. Third, **error handling has a clear topology**: wrap with context at the bottom, log at the top, never both, use `%w` internally and `%v` at API boundaries, and translate domain errors to HTTP/gRPC codes at service boundaries while hiding all internal details from external consumers.

For a payment service on Cloud Run consuming Kafka and writing to PostgreSQL, the highest-impact rules to encode are: `GOMEMLIMIT` in every Dockerfile, `errgroup.WithContext` for all fan-out work with explicit `ctx.Done()` checks, `pgx.BeginFunc` for all transactions, manual Kafka offset commits with idempotency keys, reverse-dependency-order graceful shutdown, and slog with `JSONHandler` and `LogValuer` for PII redaction. These rules prevent the failure modes that cause payment processing incidents — exactly the kind of knowledge that belongs in a CLAUDE.md file.