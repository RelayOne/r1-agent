# Claude Code system prompts: shell limits, native file flags, and caching reality

**Your 10–30 KB system prompts are safe to pass as shell arguments on every common platform, but you shouldn't need to.** Claude Code natively supports `--system-prompt-file` and `--append-system-prompt-file`, eliminating the need for shell argument expansion entirely. Cross-process prompt caching works automatically via Anthropic's server-side cache with a **5-minute TTL**, meaning repeated subprocess invocations share cached system prompts without any special flags. The recommended production pattern is `--append-system-prompt-file` with static prompt files, invoking subprocesses at intervals under 5 minutes to maintain cache hits.

---

## Q1: ARG_MAX is not your bottleneck, but know the walls

On Linux, the binding constraint for a single argument is **not** `ARG_MAX` but `MAX_ARG_STRLEN`, a per-argument kernel limit of **131,072 bytes (128 KiB)** defined in `include/uapi/linux/binfmts.h` as `PAGE_SIZE * 32`. This has been unchanged since Linux 2.6.23 and a 2023 patch proposing to raise it was never merged into mainline.

| Platform | `getconf ARG_MAX` | Per-argument limit | Safe single-arg ceiling | 10–30 KB safe? |
|---|---|---|---|---|
| **Ubuntu 22.04** | 2,097,152 (2 MiB) | 131,072 (128 KiB) | ~128 KiB | ✅ |
| **Ubuntu 24.04** | 2,097,152 (2 MiB) | 131,072 (128 KiB) | ~128 KiB | ✅ |
| **Alpine Linux (Docker)** | 2,097,152 kernel / 131,072 reported by musl | 131,072 (128 KiB) | ~128 KiB | ✅ |
| **macOS Sonoma/Sequoia** | 1,048,576 (1 MiB) | None (per-arg) | ~900 KiB+ | ✅ |
| **macOS ≤ Monterey** | 262,144 (256 KiB) | None (per-arg) | ~200–240 KiB | ✅ |

On Linux, `ARG_MAX` is dynamically computed as `stack_rlimit / 4` (capped at 6 MiB), and this space is **shared** between all arguments, all environment variables, and their pointer arrays. With a default 8 MiB stack, you get 2 MiB total. But the hard wall you'll actually hit first is `MAX_ARG_STRLEN` at 128 KiB per individual argument. A typical Docker environment consumes only 500–5,000 bytes of environment, so overhead is negligible.

macOS (XNU) has **no per-argument limit** — a single argument can consume the entire `ARG_MAX` space. However, the total space is smaller: 1 MiB on current releases, 256 KiB on older versions. The practical cross-platform safe ceiling for a single argument is **~100 KiB (102,400 bytes)**. Your 10–30 KB system prompts sit well within this on every target.

**Alpine Linux caveat:** musl libc's `sysconf(_SC_ARG_MAX)` may report the static kernel define of 131,072 rather than the dynamic stack-based value. The actual kernel-enforced total limit is still ~2 MiB with default stack — musl just reports conservatively.

---

## Q2: `--system-prompt-file` exists and works today

Claude Code provides **four system prompt flags**, all confirmed working in both interactive and print (`-p`) modes as of v2.1.69 (March 5, 2026):

| Flag | Behavior | Preserves defaults? |
|---|---|---|
| `--system-prompt <text>` | Replaces entire system prompt with inline text | ❌ |
| `--system-prompt-file <path>` | Replaces entire system prompt from a file | ❌ |
| `--append-system-prompt <text>` | Appends inline text to default system prompt | ✅ |
| `--append-system-prompt-file <path>` | Appends file contents to default system prompt | ✅ |

**`--system-prompt` and `--system-prompt-file` are mutually exclusive.** The append variants can be combined with either replacement flag. The critical distinction: **`--system-prompt-file` strips ALL default Claude Code instructions** — tool definitions, CLAUDE.md loading, context mechanisms, everything. For a QA-audit system that still needs Claude Code's agentic capabilities, `--append-system-prompt-file` is almost certainly the correct choice.

Usage for your pipeline:

```bash
# Recommended: append your rules to Claude Code's defaults
claude -p --append-system-prompt-file "$system_prompt_file" "Run QA audit on this codebase"

# If you need full control and will replicate all needed instructions:
claude -p --system-prompt-file "$system_prompt_file" "Run QA audit on this codebase"

# Combine: base identity from file + dimension-specific override inline
claude -p --system-prompt-file "$base_prompt" \
  --append-system-prompt "Additional dimension: security focus" \
  "Run QA audit"
```

This means your current shell expansion pattern (`claude_args+=(--system-prompt "$(cat "$system_prompt_file")")`) can be replaced with `claude_args+=(--append-system-prompt-file "$system_prompt_file")` — no subshell, no argument size concerns, no quoting hazards.

The feature history is traceable: GitHub issue #3411 reported Windows `ENAMETOOLONG` errors with long `--system-prompt` strings and specifically requested `--system-prompt-file`. Issue #6153 requested `--append-system-prompt-file`. Both were implemented.

---

## Q3: The workaround landscape, ranked

Since `--system-prompt-file` exists natively, workarounds are fallback options. Here they are ranked by production viability:

**`--append-system-prompt-file` is the clear winner** for your use case. It avoids shell argument limits entirely, preserves Claude Code's default capabilities, supports version-controlled prompt files, and works in both interactive and non-interactive modes.

**CLAUDE.md is not a system prompt substitute.** Per GitHub issue #6973 and official documentation, CLAUDE.md content is injected as the **first user message** following the system prompt — one priority tier lower. When CLAUDE.md instructions conflict with the actual system prompt, the system prompt wins. Issue #31776 confirmed this when CLAUDE.md commit conventions were overridden by system prompt defaults. CLAUDE.md is useful for project-level context but should not be relied upon for authoritative QA rules.

**No environment variables exist for system prompt injection.** There is no `CLAUDE_SYSTEM_PROMPT`, `ANTHROPIC_SYSTEM_PROMPT`, or equivalent. A feature request (issue #2692) asked for Gemini CLI-style `GEMINI_SYSTEM_MD` equivalent, but it hasn't been implemented.

**stdin/stream-json does not support system prompt injection.** The `--input-format stream-json` protocol carries user messages in `{type: "user", message: {...}}` structures with no system prompt field. It's an internal transport protocol for the Agent SDK, not a prompt injection mechanism. Additionally, stream-json has known hanging issues in some environments (issues #3187, #5034).

**The Agent SDK provides full programmatic control** if you need it. The TypeScript/Python SDK accepts a `systemPrompt` option directly, supporting both full replacement and append-to-preset modes. This is the intended production integration path for complex orchestration beyond CLI subprocess patterns.

---

## Q4: Token limits are generous; instruction-following is the real constraint

There is **no separate system prompt token limit**. The system prompt counts toward the model's total context window: **200K tokens** standard, **1M tokens** with the `context-1m-2025-08-07` beta header (available for Opus 4.6, Sonnet 4.5/4.6, tier 4 organizations). The per-request payload cap is **32 MB**.

Your 10–30 KB system prompts translate to roughly **2,500–7,500 tokens** — well under 5% of the 200K context window. This is a comfortable range, but instruction-following research suggests important caveats.

**The "Lost in the Middle" effect** (Liu et al., 2024, *Transactions of the ACL*) demonstrated a U-shaped performance curve: models perform best on information at the **beginning and end** of context, with **>30% degradation** for information positioned in the middle. This has direct implications for system prompt structure — place your highest-priority rules at the very beginning and very end of your prompt file.

**"Context Rot" research** (Chroma, 2025) systematically confirmed all models degrade as input length increases. Claude Opus 4 showed the slowest degradation rate but was the only model to occasionally refuse tasks (2.89% of attempts). More recent models like Opus 4.6 specifically address this — scoring **76% on 8-needle 1M MRCR v2** versus Sonnet 4.5's 18.5%.

**Practical guidance for your 10–30 KB prompts:** At 2,500–7,500 tokens, you're in a safe zone where instruction-following degradation is minimal. Research suggests measurable reasoning degradation begins around **3,000 tokens of system instructions** for complex reasoning tasks, so prompts at the upper end of your range (30 KB / ~7,500 tokens) may benefit from rigorous prioritization. Structure your bundled modules with the most critical rules first (shared rules, exclusion patterns) and least critical last. Avoid redundancy across modules — Claude Code's own system prompt already contains ~50 instructions, and `--append-system-prompt-file` adds yours on top.

**Prompt caching does not change token limits** but dramatically reduces cost and latency. Cache reads cost **10% of base input token price**, and Anthropic reports up to **85% latency reduction** for long cached prompts. Your system prompts exceed the minimum cacheable threshold of 1,024 tokens, so they will cache effectively.

---

## Q5: Cross-process caching works — it's server-side with a 5-minute TTL

**`--cache-prompt` is not an actual Claude Code CLI flag.** Prompt caching in Claude Code is **automatic and always-on** — it's described internally as "the architectural constraint around which the entire product is built." Claude Code declares SEVs when cache hit rates drop.

The mechanism: Claude Code automatically places `cache_control: {"type": "ephemeral"}` breakpoints on API requests. The prompt is ordered for maximum cache efficiency: `[system prompt] → [tool definitions] → [CLAUDE.md content] → [conversation history] → [latest message]`. Tool definitions are locked at session start specifically to prevent cache invalidation.

**The cache is server-side on Anthropic's infrastructure**, stored as KV cache tensors in GPU VRAM. Cache lookup is by content hash against the combination of **API key + model + prompt prefix**. It is **not** tied to any process ID, session ID, or machine. This means:

| Scenario | Cache behavior |
|---|---|
| Same model, same system prompt, invocations <5 min apart | ✅ Cache hit on shared prefix |
| Same model, same system prompt, invocations >5 min apart | ❌ Cache expired, full reprocessing |
| Different models between invocations | ❌ Caches are per-model |
| Any change to system prompt text (even 1 character) | ❌ Prefix mismatch, full miss |
| Different API keys (different organizations) | ❌ Caches are per-organization |

This was empirically confirmed by the Claude Code Camp analysis (February 2026): *"A bonus finding: Request 1 in this experiment actually got a cache hit from Experiment 1, which I'd run seconds earlier. The 5-minute TTL means caches persist across separate API calls."*

**Cost implications for your subprocess pipeline:** The first invocation pays a cache write cost of **1.25x base input tokens**. Every subsequent invocation within 5 minutes pays only **0.1x base** for the cached prefix. Each cache hit refreshes the TTL at no extra cost. For a QA-audit system processing multiple files sequentially, keeping subprocess invocations under 5 minutes apart ensures continuous cache hits. A heavy session without caching might cost $50–100; with 90% cache hit rates, the same workload drops to ~$19.

**Critical implication for your architecture:** Your system prompt files must be **byte-identical** across invocations to get cache hits. If you're templating dynamic content (timestamps, file lists, run IDs) into the system prompt, move that content to the user message or to `--append-system-prompt` while keeping the large static portion in `--system-prompt-file`. Claude Code itself follows this pattern — dynamic information like dates and git status are sent via `<system-reminder>` tags in user messages, not in the system prompt.

---

## Deliverable summary

**1. Maximum safe system prompt size for CLI argument passing:**

| Platform | Hard ceiling (single arg) | Practical safe limit |
|---|---|---|
| Ubuntu 22.04 / 24.04 | 128 KiB (MAX_ARG_STRLEN) | ~100 KiB |
| Alpine Linux (Docker) | 128 KiB (MAX_ARG_STRLEN) | ~100 KiB |
| macOS Sonoma / Sequoia | ~900 KiB (total ARG_MAX minus env) | ~100 KiB (cross-platform) |

Your 10–30 KB prompts are safe everywhere, but this question is now moot — use `--system-prompt-file` instead.

**2. `--system-prompt-file` exists as a native flag.** Yes. Also available: `--append-system-prompt-file` (recommended), `--system-prompt`, and `--append-system-prompt`.

**3. Recommended approach for 10–30 KB system prompts in a non-interactive subprocess pipeline:**

```bash
# Production pattern: static prompt file + dynamic query
claude -p \
  --append-system-prompt-file "$system_prompt_file" \
  --dangerously-skip-permissions \
  --output-format json \
  "$query"
```

Use `--append-system-prompt-file` to preserve Claude Code's default agent capabilities. Keep prompt files byte-identical across invocations for cache efficiency. Move any dynamic content (run IDs, timestamps, file-specific context) into the user message or inline `--append-system-prompt`. Structure your bundled modules with highest-priority rules at the beginning and end of the file to mitigate "Lost in the Middle" effects.

**4. Cache behavior for repeated subprocess invocations:** Cache is server-side, shared across all processes using the same API key, model, and prompt prefix. **5-minute TTL**, refreshed on each hit. Separate subprocess invocations within 5 minutes get cache hits automatically — no flags needed. First call pays 1.25x write cost; subsequent calls pay 0.1x read cost on the cached prefix. Ensure byte-identical prompt prefixes across invocations to maintain hits.