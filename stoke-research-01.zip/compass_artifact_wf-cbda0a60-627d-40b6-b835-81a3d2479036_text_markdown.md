# Multi-tenancy architecture for SaaS on PostgreSQL, Redis, and Kafka

**Row Level Security on a shared PostgreSQL database, combined with tenant-prefixed Redis caching and shared Kafka topics with tenant headers, is the production-proven default stack for most SaaS platforms.** This architecture delivers the best balance of operational simplicity, cost efficiency, and sufficient isolation for the vast majority of tenants—while allowing enterprise customers to be peeled onto dedicated infrastructure when compliance demands it. The ten domains covered here—from database isolation to cross-tenant admin operations—represent the complete surface area that any team building multi-tenant SaaS must address. What follows is a practitioner's guide drawn from engineering blogs at Slack, Figma, Notion, Stripe, DoorDash, Gong, and Supabase, plus AWS, Azure, and Citus Data prescriptive guidance.

---

## 1. Three database isolation models and when each wins

Every multi-tenant PostgreSQL system must choose among three isolation models. The choice radiates through cost, compliance posture, and operational burden.

**Shared database with RLS** places all tenants in one schema, adding a `tenant_id` column to every table. PostgreSQL's Row Level Security engine appends implicit WHERE predicates, enforced at the database level regardless of application code. This is the **lowest cost** model—one instance, one set of migrations, one backup target—and it scales to hundreds of thousands of tenants. Supabase, Nile, and Slack (with `workspace_id` as discriminator) all run this pattern in production. The tradeoff: zero performance isolation. A runaway tenant can exhaust shared CPU, memory, and I/O. Mitigation requires per-role `statement_timeout`, PgBouncer connection caps, and ultimately peeling noisy tenants to dedicated infrastructure.

**Schema-per-tenant** gives each tenant a dedicated PostgreSQL schema (`tenant_acme.orders`). Routing uses `SET LOCAL search_path TO tenant_abc, public;` per transaction. Isolation is stronger—it is physically impossible to forget a WHERE clause since the wrong schema simply is not in scope. Per-schema statistics improve query plans. The wall arrives around **5,000+ schemas**, where catalog bloat in `pg_class` and `pg_attribute` degrades DDL operations and planning. Migrations must fan out across every schema. Django's `django-tenants` and Rails' `apartment` gem automate this. Best suited for regulated B2B SaaS with moderate tenant counts.

**Database-per-tenant** provides maximum isolation: separate encryption keys, independent backups, per-tenant tuning, and provable data destruction (drop the database, revoke the KMS key). Figma vertically partitioned into domain-specific databases; Notion shards across 32+ physical servers. The cost multiplier is significant—every operational task multiplies by N—making this practical only for fewer than ~500 tenants without serverless Postgres (Neon is exploring database-per-user with auto-scaling compute). Enterprise contracts in healthcare, government, and finance often contractually require this model.

| Criterion | Shared + RLS | Schema-per-tenant | Database-per-tenant |
|---|---|---|---|
| Tenant count sweet spot | 100–1M+ | 10–5,000 | 1–500 |
| Infrastructure cost | Lowest | Moderate | Highest |
| Data isolation | Policy-enforced | Schema-enforced | Physical |
| Performance isolation | None | Partial | Full |
| Migration complexity | One migration | Fan-out per schema | Orchestrate per DB |
| Compliance strength | Acceptable | Good | Best |

**The recommended progression**: start with RLS on shared tables at seed/Series A; add hash partitioning by `tenant_id` for growth; peel enterprise customers onto dedicated databases as a premium tier.

---

## 2. PostgreSQL RLS in practice: policies, performance, and the PgBouncer trap

### Policy design with complete SQL

A working RLS implementation requires four elements: a tenant context function, indexed tenant columns, explicit policies, and a non-superuser application role.

```sql
-- Helper: extract tenant from session variable
CREATE OR REPLACE FUNCTION current_tenant_id() RETURNS UUID AS $$
  SELECT NULLIF(current_setting('app.tenant_id', true), '')::UUID;
$$ LANGUAGE SQL STABLE;

-- Table with tenant column + composite index
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    amount DECIMAL(10,2) NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_orders_tenant_status ON orders(tenant_id, status, created_at DESC);

-- Enable RLS and force it even for table owner
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders FORCE ROW LEVEL SECURITY;

-- Isolation policy (USING filters reads; WITH CHECK validates writes)
CREATE POLICY tenant_isolation ON orders
    FOR ALL
    USING (tenant_id = (SELECT current_tenant_id()))
    WITH CHECK (tenant_id = (SELECT current_tenant_id()));

-- Application role (never use superuser—it silently bypasses RLS)
CREATE ROLE app_user LOGIN PASSWORD 'secure_password';
GRANT SELECT, INSERT, UPDATE, DELETE ON orders TO app_user;
```

The `(SELECT current_tenant_id())` wrapper is critical—Supabase documented that wrapping function calls in a subselect forces PostgreSQL to evaluate them **once** rather than per-row, eliminating a common performance pitfall.

### Performance: 2–4% overhead when done right

RLS adds an implicit predicate to every query. On indexed `tenant_id` columns, benchmarks from MVP Factory measured **2–4% overhead**—equivalent to an additional WHERE clause. The danger zone is policies that reference other RLS-enabled tables via subqueries, where evaluation cost becomes multiplicative. The fix: use `SECURITY DEFINER` functions to bypass chained RLS on lookup tables, and always add explicit `WHERE tenant_id = $1` in application queries alongside RLS to help the planner build optimal plans.

### The PgBouncer transaction-mode trap

PgBouncer in **transaction pooling mode** (the most common production configuration) reassigns server connections between clients between transactions. A session-scoped `SET app.tenant_id = 'tenant-A'` persists on the server connection and **bleeds to the next client**—a catastrophic cross-tenant data leak.

The solution is `SET LOCAL`, which scopes the variable to the current transaction and automatically reverts on COMMIT or ROLLBACK:

```sql
BEGIN;
SET LOCAL app.tenant_id = 'abc-123';
SELECT * FROM orders;  -- Scoped to tenant abc-123
COMMIT;
-- Connection is clean for the next client
```

Or equivalently: `SELECT set_config('app.tenant_id', 'abc-123', true);` where the `true` parameter means LOCAL scope. Every production framework—PostgREST, Supabase, Nile—uses this pattern. Configure PgBouncer with `server_reset_query = DISCARD ALL` as an additional safety net. Note: RLS with `SET` or `SET LOCAL` does **not work with statement pooling mode** at all—only transaction and session modes are compatible.

### Testing that RLS actually works

Never test with superusers (they bypass RLS silently). A minimal test harness:

```sql
SET ROLE app_user;
SET LOCAL app.tenant_id = '11111111-...';
SELECT count(*) FROM orders;  -- Should see only tenant A orders

SET LOCAL app.tenant_id = '22222222-...';
INSERT INTO orders (tenant_id, amount)
VALUES ('11111111-...', 99.99);
-- ERROR: new row violates row-level security policy

RESET app.tenant_id;
SELECT count(*) FROM orders;  -- Must return 0 rows
```

Automate this with pgTAP or Testcontainers spinning up real PostgreSQL instances with RLS enabled. Treat RLS tests like auth tests—**if they fail, nothing ships**.

---

## 3. Tenant context propagation: from JWT to database query

The tenant identifier must flow from authentication token through every layer—middleware, service logic, ORM, cache, and event bus—with zero gaps. A single missed code path is a cross-tenant data leak.

### Extraction at the edge

Middleware extracts `tenant_id` from JWT claims, API key lookup, or subdomain, then stores it in a request-scoped context mechanism:

- **Node.js**: `AsyncLocalStorage` from `node:async_hooks`—propagates through promises, timers, and callbacks without prop-drilling
- **Java**: `ThreadLocal<String>` (breaks in reactive frameworks; use Reactor's `Context` instead)
- **Go**: `context.Context` with typed keys—idiomatic explicit passing
- **Python**: `contextvars.ContextVar` for async, `threading.local()` for sync

```typescript
// Node.js: Set once in middleware, read anywhere downstream
import { AsyncLocalStorage } from 'node:async_hooks';
export const tenantStorage = new AsyncLocalStorage<{ tenantId: string }>();

// Middleware
app.use((req, res, next) => {
  const tenantId = extractFromJWT(req.headers.authorization);
  tenantStorage.run({ tenantId }, () => next());
});

// Deep in a service layer—no parameter passing needed
export function getCurrentTenantId(): string {
  const store = tenantStorage.getStore();
  if (!store) throw new Error('No tenant context');
  return store.tenantId;
}
```

### Making it impossible to forget the filter

**ORM-level global filters** are the strongest application-layer defense. Django's `django-multitenant` (from Citus) declares a `tenant_id` field on models and automatically scopes every `QuerySet`. SQLAlchemy's `before_compile` event listener injects tenant predicates—Armin Ronacher's pattern requires an explicit `.tenant_unconstrained_unsafe()` escape hatch. Prisma client extensions combined with `AsyncLocalStorage` auto-inject `tenantId` into every `where` clause.

**Compile-time enforcement** adds another layer. TypeScript branded types prevent plain strings from being passed where a `TenantId` is expected:

```typescript
type TenantId = string & { readonly __brand: unique symbol };
function validateTenantId(id: string): TenantId {
  if (!id) throw new Error('Invalid tenant ID');
  return id as TenantId;
}
// getOrders(rawString) → compile error
// getOrders(validateTenantId(rawString)) → works
```

The **tenant-scoped repository** pattern wraps all data access in a base class that automatically appends tenant context to every query—concrete repositories never touch tenant logic directly. Combined with RLS as the database-level backstop, this creates defense-in-depth where both application and database independently enforce isolation.

---

## 4. Tenant-aware Redis caching: keys, isolation, and noisy neighbors

### Key namespacing strategy

The standard pattern is `tenant:{id}:{resource_type}:{resource_id}`:

```
tenant:acme:user:123
tenant:acme:session:abc-def
tenant:acme:config:feature_flags
```

A thin wrapper class intercepts all Redis operations and prepends the tenant prefix automatically, reading the current tenant from async context. This eliminates human error in key construction.

**In Redis Cluster**, key prefixes naturally distribute across hash slots via `CRC16(key) % 16384`—this is desirable. **Do not use hash tags** like `{tenant:acme}:user:123` for general tenant keys; forcing all of a large tenant's keys into one slot creates hot spots. Reserve hash tags for narrow cases where atomic multi-key operations are required (e.g., an order and its line items).

### Isolation approaches

Key prefixes on a shared Redis instance offer logical-only isolation and are sufficient for most SaaS. **Redis ACLs** add access control (`ACL SETUSER tenant_A on >password ~tenant_A:* +get +set +del`), preventing one tenant's code from touching another's keys. Redis's `SELECT` command for database-per-tenant (0–15) is officially discouraged by Redis's creator as an anti-pattern and is unsupported in Cluster mode. Dedicated Redis instances provide full isolation but at the highest cost—reserve for enterprise tenants.

### Preventing cache crowding

Redis has no native per-tenant memory quotas. Mitigation strategies:

- **Application-layer quotas**: Before each SET, check a counter tracking the tenant's key count against a tier-based limit. Enforce via a Lua script that atomically counts keys matching the tenant prefix and rejects writes if the limit is exceeded.
- **Tier-based TTLs**: Free tenants get **300-second** TTLs; enterprise tenants get **3,600 seconds**. Shorter TTLs for lower tiers naturally reclaim memory faster.
- **Periodic monitoring**: Background jobs use `SCAN` with `MEMORY USAGE` per key to compute per-tenant memory consumption, alerting when a tenant exceeds thresholds.
- **Eviction policy**: `allkeys-lru` as a global safety net ensures the largest consumers' least-recently-used keys are evicted first under memory pressure.

### Bulk cache invalidation

During tenant offboarding or data migration, invalidate all keys with `SCAN` (never `KEYS`, which blocks Redis):

```python
def invalidate_tenant_cache(r, tenant_id):
    cursor, deleted = 0, 0
    while True:
        cursor, keys = r.scan(cursor, match=f"tenant:{tenant_id}:*", count=500)
        if keys:
            pipe = r.pipeline()
            for key in keys: pipe.delete(key)
            deleted += sum(pipe.execute())
        if cursor == 0: break
    return deleted
```

A more elegant approach uses **version-based invalidation**: increment a version counter (`tenant:acme:version:users`), and all subsequent cache reads construct keys with the new version. Old keys expire naturally via TTL—no SCAN required.

---

## 5. Resource quotas and the noisy neighbor problem

### Rate limiting with Redis

The **sliding window counter** is the recommended default for API rate limiting—it maintains two counters (current and previous window) and applies a weighted formula. Near-exact accuracy with only two Redis keys per tenant, versus O(n) memory for sliding window logs.

For burst-tolerant limits, the **token bucket** algorithm (bucket capacity defines max burst, refill rate defines sustained throughput) is implemented atomically via a Redis Lua script:

```lua
local key = KEYS[1]
local capacity = tonumber(ARGV[1])
local refill_rate = tonumber(ARGV[2])
local now = tonumber(ARGV[3])
local bucket = redis.call('HMGET', key, 'tokens', 'last_refill')
local tokens = tonumber(bucket[1]) or capacity
local last = tonumber(bucket[2]) or now
local elapsed = (now - last) / 1000
tokens = math.min(capacity, tokens + elapsed * refill_rate)
if tokens >= 1 then
  redis.call('HMSET', key, 'tokens', tokens - 1, 'last_refill', now)
  redis.call('EXPIRE', key, 120)
  return 1  -- allowed
end
return 0  -- denied
```

**Lua scripts are essential**—`MULTI/EXEC` cannot branch on intermediate values, and `WATCH` creates retry loops that degrade under the exact conditions (high concurrency) where rate limiting matters most.

Tier-based limits are standard: free at 100 requests/hour, pro at 10,000, enterprise at 100,000. Always return quota headers (`X-RateLimit-Remaining`, `X-RateLimit-Reset`, `Retry-After`) on every response. Atlassian's Jira Cloud uses a points-based system where requests are weighted by computational cost.

### Noisy neighbor prevention beyond rate limiting

- **PostgreSQL `statement_timeout` per role**: `ALTER ROLE tenant_basic SET statement_timeout = '15s';`—enterprise gets 60 seconds, basic gets 15
- **PgBouncer connection caps** per tenant prevent connection pool exhaustion
- **Shuffle sharding** (AWS pattern): split tenants into overlapping subsets across infrastructure shards, limiting blast radius while being more efficient than full silos
- **Per-tenant circuit breakers**: if a tenant's requests consistently fail, trip a circuit breaker returning fast 503s instead of consuming shared resources
- **Fair scheduling in background queues**: Inngest-style per-tenant concurrency limits prevent any single tenant from monopolizing workers

---

## 6. Tenant data lifecycle: provisioning through deletion

### Automated provisioning pipeline

Tenant onboarding in a production SaaS touches **8+ systems**: insert tenant config rows, run schema migrations (if schema-per-tenant), seed default roles and reference data from a versioned manifest, create Redis key namespaces, configure Kafka ACLs, provision DNS records via Route53/Cloudflare API, set up identity (SSO/SAML), configure feature flags by tier, create monitoring dashboards, and initialize billing in Stripe. This should be **asynchronous**—accept the request, return immediately, provision in background with status webhooks.

### GDPR-compliant deletion

The offboarding checklist spans every data store: database records, Redis cache keys (bulk invalidation via SCAN), S3 objects, Elasticsearch indices, Kafka topics/events, analytics data, DNS records, API keys, and third-party subprocessor notifications. Publish a `TenantDeleted` event to a message bus; each service subscribes and confirms cleanup. Only mark deletion complete when all services confirm.

**Backup handling** is the thorny edge case. European supervisory authorities clarify: delete from backups where technically possible; if not, document why, ensure data is "beyond use" (ICO guidance), and re-delete if a backup is ever restored. **Cryptographic erasure**—deleting the per-tenant encryption key—renders encrypted backup data permanently inaccessible and is the cleanest compliance path.

Maintain an **immutable deletion audit log** referencing row IDs (not personal data), recording what was deleted, when, and by whom. Provide a formal deletion certificate upon request.

---

## 7. Per-tenant observability without a cardinality explosion

### The Prometheus label trap

Adding `tenant_id` as a Prometheus label is natural but creates a **cardinality bomb**. With 5 methods × 10 status codes × 10,000 tenants, a single metric generates 500,000 time series. Each series is an independent in-memory stream—doubling unique label values roughly doubles memory, leading to OOM kills.

**The solution is a multi-tenant metrics backend.** Grafana Mimir, Cortex, and Thanos Receiver provide first-class multi-tenancy by routing metrics via HTTP headers (`X-Scope-OrgID`), not labels. Each tenant gets isolated metric namespaces, resource quotas, and rate limits—solving the cardinality problem architecturally. For Prometheus-native setups, **recording rules** pre-aggregate tenant metrics: `sum by (service, status) (http_requests_total)` creates a cheap derived metric for alerting while the raw metric supports ad-hoc investigation.

### Structured logging and tracing

Grafana Loki with `auth_enabled: true` provides native multi-tenant log isolation—each request includes an `X-Scope-OrgID` header, and logs are physically separated by tenant in storage. Per-tenant rate limits and retention periods are configurable:

```yaml
limits_config:
  overrides:
    tenant-premium:
      ingestion_rate_mb: 64
      retention_period: 8760h  # 365 days
    tenant-basic:
      ingestion_rate_mb: 8
      retention_period: 720h   # 30 days
```

For distributed tracing, **OpenTelemetry Baggage** propagates `tenant.id` across service boundaries via W3C Baggage headers, automatically flowing through HTTP calls. Span attributes tag individual spans. Configure **tail-based sampling** per tier: 100% for enterprise, 5% for free—balancing observability depth against storage cost.

### Noisy tenant detection

PromQL identifies outliers: `topk(10, sum by (tenant_id) (rate(http_requests_total[5m])))`. Build composite **tenant health scores** from availability, latency percentiles, error rates, and resource consumption. Alert when any tenant exceeds **2× the median** usage. Research from a 2025 WJARR paper found that tenant-aware monitoring detected performance interference **15–20 minutes earlier** than traditional monitoring.

---

## 8. Deployment patterns: feature flags, canary rollouts, and custom domains

### Feature flags targeted by tenant

LaunchDarkly's context system supports a `tenant` context kind with attributes like `plan`, `tier`, and `region`. Feature entitlements become permanent multivariate flags: "transcription minutes" returns 300 for Basic, 3,000 for Pro, 6,000 for Business. Chronosphere's production implementation uses LaunchDarkly for feature toggling, tenant-specific configuration, and control plane management for external components.

**Progressive rollout follows a ring model**: Ring 0 deploys to internal employees (dogfooding), Ring 1 to opt-in tenants or free tier, Ring 2 to all production. InVision's real-world incident validates this—a query refactoring that looked fine in Preview spiked CPU to 100% in multi-tenant production, but a LaunchDarkly kill switch prevented any customer-facing outage.

### Custom domain and white-label support

The standard stack is **Caddy with On-Demand TLS**: it obtains SSL certificates on-the-fly during TLS handshakes and supports dynamic route configuration via REST API without restarts. Caddy's documentation states it is "the secret sauce of almost every white-label SaaS." For higher scale, Cloudflare's SSL for SaaS provisions certificates via a single API call with CDN and DDoS protection included. Store per-tenant branding (logos, colors, email templates) as JSON configuration, served dynamically based on hostname.

### Kubernetes and Istio tenant routing

Istio's `VirtualService` enables header-based routing to send specific tenants to canary deployments:

```yaml
http:
  - match:
      - headers:
          x-tenant-id:
            exact: "tenant-beta"
    route:
      - destination: { host: api, subset: v2 }
  - route:
      - destination: { host: api, subset: v1 }
```

The `Sidecar` resource limits service discovery per namespace—**Tenant A's sidecars won't even know Tenant B's services exist**. Flagger and Argo Rollouts automate progressive delivery with automatic rollback when per-tenant error rates breach thresholds.

---

## 9. Compliance: data residency, encryption, and audit trails

### Cell-based architecture for data residency

Slack's cellular architecture is the gold standard. After a June 2021 AWS availability zone outage, Slack migrated to AZ-scoped cells where each cell contains a completely siloed backend. Traffic drains can remove an affected AZ within **5 minutes**, supporting their 99.99% SLA. For data residency, each Slack channel can be stored in a specific region—a German company and US partner sharing a Slack Connect channel have their data in their respective jurisdictions. The storage layer uses **Vitess** for horizontal sharding, now handling 99% of query load.

The practical starting point: make `region` a first-class field on the tenant entity at creation time. A global tenant directory service maps `tenant_id → region`, and the API gateway routes requests to the correct regional deployment.

### Per-tenant encryption keys (BYOK)

AWS's prescriptive pattern centralizes key management: one KMS Customer Master Key per tenant, alias format `alias/customer-{tenant_id}`, managed in a dedicated AWS account. Business services in other accounts assume a cross-account IAM role with session-scoped policies restricting access to only the current tenant's key alias. **Envelope encryption** generates a Data Encryption Key under the tenant's CMK; the DEK encrypts actual data. Key cost is **$1/month per key** (up to $3 with rotations).

For GDPR's right to erasure, cryptographic erasure—deleting the tenant's CMK—renders all encrypted data permanently inaccessible, even in backups. This is the cleanest path to provable data destruction.

### Immutable audit logging

Every tenant-scoped mutation must generate a structured audit event:

```json
{
  "tenant_id": "uuid",
  "actor_id": "uuid",
  "actor_type": "user|admin|system",
  "action": "order.created",
  "resource_type": "order",
  "resource_id": "uuid",
  "timestamp": "2026-04-06T12:00:00Z",
  "changes": {"status": {"old": "draft", "new": "confirmed"}}
}
```

Store in append-only tables with triggers preventing UPDATE and DELETE. Partition by `(tenant_id, timestamp)` for efficient querying. Retention periods are regulation-specific: **HIPAA requires 6 years**, SOX requires 7. FedRAMP penetration testing explicitly requires "a full application test which attempts to use provisional access of one tenant to compromise another tenant."

---

## 10. Cross-tenant admin operations done safely

### Bypassing RLS for admin queries

PostgreSQL provides several mechanisms, each with different security profiles:

```sql
-- Option 1: Dedicated admin role with BYPASSRLS
CREATE ROLE admin_user WITH BYPASSRLS;

-- Option 2: Permissive admin policy checking a session variable
CREATE POLICY admin_access ON orders
    FOR ALL USING (current_setting('app.role', true) = 'super_admin');

-- Option 3: SECURITY DEFINER function (runs as creator, bypasses RLS)
CREATE OR REPLACE FUNCTION admin_get_all_orders()
RETURNS SETOF orders SECURITY DEFINER AS $$
  SELECT * FROM orders;
$$ LANGUAGE SQL;
```

**Critical footgun** (documented by Bytebase): views created by a superuser bypass ALL RLS by default. PostgreSQL 15+ added `security_invoker = true` on views to fix this. Always use it.

### Cross-tenant analytics

The recommended pattern separates analytics from production: `Production DB → ETL pipeline → Analytics warehouse`. AWS Redshift's pool model uses a shared schema with `tenant_id` column and views controlling access; the bridge model uses per-tenant schemas for stronger isolation (up to 9,900 schemas). **Materialized views** pre-compute cross-tenant aggregations, avoiding repeated raw data scans. Anonymize tenant identifiers before any cross-tenant comparison—expose percentiles and relative positioning, never absolute tenant-level metrics.

### Admin impersonation with audit trail

Every impersonation session must: verify admin identity with elevated authentication (MFA), log both admin and impersonated identities, display visual indicators making impersonation obvious, enforce time limits, and create an immutable audit record of start/stop events. Break-glass procedures for emergencies require **multi-party approval** (FedRAMP AC-3) and automatic privilege expiration.

---

## Kafka topic design: shared topics beat topic-per-tenant at scale

### Why shared topics win

**Topic-per-tenant** provides inherent isolation and per-topic retention policies, but Kafka has practical limits on partition count. Each topic requires a minimum partition count; with thousands of tenants, the total partition count explodes. Both DoorDash and Gong cite this as a scalability wall. Ameto started with `user1.jobs`, `user2.jobs` per tenant and found it unsustainable at growth.

**Shared topics with tenant headers** is the scalable default. Messages carry `tenant_id` in Kafka headers; consumers filter by tenant context:

```java
// Producer: tag message with tenant
ProducerRecord<String, String> record = new ProducerRecord<>(topic, key, value);
record.headers().add("tenant_id", tenantId.getBytes(UTF_8));
producer.send(record);

// Consumer: filter by tenant
Header h = record.headers().lastHeader("tenant_id");
String tenant = new String(h.value(), UTF_8);
```

DoorDash propagates tenant context via OpenTelemetry's native Kafka headers, with separate consumer groups per tenant environment and a two-layer filtering approach (context filter + route filter). Gong implements a **repartitioning layer**: source topic → repartition topic (keyed by `tenant_id`) → consumers receive single-tenant batches.

### Partitioning and quotas

Use `tenant_id` as the message key for per-tenant ordering guarantees. For hot partition prevention, use composite keys (`tenant_id + entity_id`) to distribute within a tenant. Kafka's built-in quota system supports per-user bandwidth limits:

```bash
bin/kafka-configs.sh --bootstrap-server localhost:9092 \
  --alter --add-config 'producer_byte_rate=1048576,consumer_byte_rate=2097152' \
  --entity-type users --entity-name tenant-a
```

Confluent Cloud implements custom `ClientQuotaCallback` (KIP-257) for per-logical-cluster quotas that auto-adjust as brokers scale. Per-tenant retention in shared topics requires application-level archival: consume events, archive to per-tenant S3 prefixes via Kafka Connect S3 Sink, then let topic-level retention handle cleanup.

---

## Conclusion: the architecture is the product

Multi-tenancy is not a feature bolted on after launch—it is a foundational architectural decision that shapes every layer of the stack. The key insights from production experience at scale:

**Defense-in-depth is non-negotiable.** Combine ORM-level global filters with PostgreSQL RLS with compile-time type safety. Any single layer can fail; the combination makes cross-tenant data leaks require simultaneous failures across three independent enforcement mechanisms.

**Start pooled, peel when forced.** The shared-database-with-RLS model handles the first 10,000 tenants. Schema-per-tenant serves regulated mid-market. Database-per-tenant is a premium tier for enterprise contracts that demand it. Most compliance frameworks—including SOC 2 and HIPAA—do not prohibit shared resources when proper controls exist.

**The noisy neighbor problem is architectural, not operational.** Rate limiting, connection caps, and statement timeouts are necessary but insufficient. Cell-based architectures (Slack), shuffle sharding (AWS), and per-tenant circuit breakers provide structural isolation that no amount of monitoring can replace.

**Tenant context is the new auth context.** Just as authentication must be verified on every request, tenant identity must propagate through every layer—middleware, service logic, database, cache, event bus, background jobs, and observability. The cost of a single gap is not a bug report; it is a breach disclosure.