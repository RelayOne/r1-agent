# The definitive guide to polyglot monorepo engineering

**For a monorepo spanning Go, Rust, TypeScript/React, React Native, and shared protobuf/GraphQL schemas, Bazel remains the only build system offering true cross-language dependency tracking, hermetic builds, and remote execution — but its steep learning curve makes Nx with language-specific tooling the pragmatic choice for most teams.** The entire monorepo ecosystem is converging on Rust for core tooling performance (Turborepo, Nx, and Pants all rewrote their engines in Rust between 2023–2025), while a critical remote cache vulnerability (CVE-2025-36852, severity 9.4) discovered in June 2025 affects most self-hosted caching setups. This report covers build tools, dependency detection, cache correctness, CI optimization, deployment orchestration, versioning, and developer experience — informed by public practices at Google, Meta, Uber, Airbnb, Stripe, and Microsoft.

---

## 1. Eight build tools and why most polyglot teams should choose two

No single tool handles Go + Rust + TypeScript + React Native + protobuf natively without tradeoffs. The landscape splits into three tiers: **true polyglot build systems** (Bazel, Buck2, Pants), **JavaScript-centric orchestrators** (Turborepo, Nx, Rush), and **emerging middle-ground tools** (Moon, Please).

**Bazel** is the gold standard for polyglot repos, with mature rule sets (`rules_go`, `rules_rust`, `rules_ts`, `rules_proto`) and native protobuf codegen across languages in a single build graph. Its content-addressable cache, sandbox execution, and remote execution API are architecturally unmatched. The cost is severe: expect **months of onboarding** and 1–3 dedicated build engineers. Airbnb's migration to Bazel for their web monorepo yielded TypeScript type checking **34% faster**, ESLint **35% faster**, and Jest tests **42% faster** incrementally — but required substantial infrastructure investment.

**Buck2**, Meta's Bazel alternative open-sourced in April 2023, is architecturally superior in several ways: a single incremental dependency graph (no phases), a Rust core (no GC pauses), and configuration hashes baked into output paths. It achieved **2x speed improvements** over Buck1 internally. However, its external community remains minimal, and Meta's track record on open-source sustainability gives pause. Monitor Buck2; don't bet on it yet.

**Turborepo** offers the lowest learning curve — drop it into an existing workspace, write ~20 lines of `turbo.json`, and immediately get caching and parallel execution. But it is **fundamentally JavaScript-only**: Go and Rust projects require `package.json` wrappers, receive zero dependency graph analysis, and get no hermetic build guarantees. It's a task orchestrator, not a build system.

**Nx** occupies the pragmatic middle ground. Its plugin architecture extends to Go and Rust via community plugins, while providing first-class TypeScript support, dependency graph visualization, module boundary enforcement, and distributed task execution via Nx Cloud. Nx also discovered and published the **CREEP cache poisoning vulnerability** (CVE-2025-36852) and is the only tool with branch-scoped cache isolation by default.

**Pants** is genuinely polyglot with strong Go, Python, and JVM support, plus automatic dependency inference that eliminates most BUILD file boilerplate. However, it lacks native Rust and TypeScript support — a dealbreaker for this stack.

**Moon** (moonrepo) is the most interesting newcomer, offering native Go, Rust, and TypeScript support with integrated toolchain management in a YAML-based configuration. It sits between "shell-script chaos and Bazel-level structure" but lacks fine-grained build-level dependency tracking.

**Rush** (Microsoft) excels at governance for large TypeScript monorepos — phantom dependency detection, approved package lists, controlled publishing workflows — but handles only JavaScript/TypeScript. **Please** (Thought Machine) is Bazel-inspired but has too small a community to recommend.

**The recommended architecture**: Use **Bazel** (50+ engineers) or **Nx** (10–50 engineers) as the orchestration layer, with `go build`, `cargo`, and `tsc`/`esbuild` as the actual compilers underneath. For teams under 10 engineers, **Moon** offers the most natural polyglot experience without Bazel's complexity.

---

## 2. How affected-service detection prevents CI from building the world

Affected detection answers a critical question: which services need testing when a file changes? Two approaches exist. **Git diff–based detection** (`git diff --name-only origin/main...HEAD`) maps changed files to owning packages — simple but blind to transitive dependencies. **Dependency graph–based detection** constructs a full project graph, identifies touched nodes, then traverses reverse dependencies to find all downstream impacts. Production systems combine both.

**Bazel** provides the most precise mechanism through its query language. The command `bazel query "rdeps(//..., //schemas/user:user_proto)"` returns every consumer of a proto library across all languages. One team reduced CI from testing **500+ targets per change to ~12 targets**, cutting pipeline time from 32 to 9 minutes. A critical pitfall: BUILD file changes are **not captured by `rdeps()` queries** (GitHub issue #1831) and require separate handling via `rbuildfiles`.

**Nx** builds a Project Graph by analyzing TypeScript import statements and `package.json` dependencies, then uses `nx affected -t test --base=origin/main` to run tests only for impacted projects. Modifying `nx.json` marks all projects as affected. Lock file changes can trigger full rebuilds unless configured with `projectsAffectedByDependencyUpdates: "auto"`.

**Turborepo** operates at the package level using `turbo run build --filter=...[origin/main]`. A future flag `affectedUsingTaskInputs` enables finer task-level filtering. It requires full Git history (`fetch-depth: 0` in CI) and can produce false positives on root `package.json` changes.

**Pants** takes the most granular approach with **automatic dependency inference at the file level** — it parses import statements in Python, Go, Java, and Shell to determine that `file a.py depends on file b.py`, not just `library A depends on library B`. This precision means near-zero false negatives with minimal BUILD file boilerplate.

**Cross-language dependency tracking** is the hardest problem. When a `.proto` file changes, all language-specific generated code and every consumer must rebuild. In Bazel, `proto_library` rules create explicit edges in the build graph linking proto sources to `go_proto_library`, `ts_proto_library`, and `rust_prost_library` targets, enabling a single `rdeps` query to find all affected targets across all languages. Without Bazel, the pragmatic alternative is committing generated code alongside schemas and relying on the build tool's file-change detection. **Buf** adds breaking change detection (`buf breaking --against .git#branch=main`) as a CI gate, catching API contract violations before they propagate.

The universal rule: **always err toward false positives** (over-building). Remote caching makes rebuilding unchanged targets nearly free. False negatives — missing a build that should have run — ship broken code to production.

---

## 3. Package boundaries that work across language lines

Preventing unintended coupling in a polyglot monorepo requires enforcing boundaries at three levels: within each language, across languages, and architecturally.

**Within TypeScript**, Nx's `@nx/enforce-module-boundaries` ESLint rule provides tag-based constraints. Projects are tagged (e.g., `type:ui`, `scope:orders`) and rules enforce dependency direction — a UI library can depend on model libraries but not infrastructure. The `bannedExternalImports` option prevents backend packages from importing React. For deeper control, **eslint-plugin-boundaries** enforces architectural layering (controller → service → model) without requiring Nx, and **dependency-cruiser** validates custom rules while generating visual dependency graphs.

**Within Go**, the `internal` directory convention is enforced by the compiler itself — code outside the parent tree cannot import internal packages, requiring zero configuration. This is the strongest per-service isolation mechanism available in any language in this stack.

**Within Rust**, the visibility system (`pub(crate)`, `pub(super)`, `pub(in crate::path)`) provides the most granular controls. In a Cargo workspace, each service is a separate crate, and `pub(crate)` prevents implementation details from leaking between crates at compile time with zero runtime cost.

**Across language boundaries**, Bazel's visibility rules are the strongest enforcement mechanism. A proto library can be restricted to specific consuming packages: `visibility = ["//services/auth/...", "//apps/admin-web/..."]`, blocking unauthorized consumers at build time. Without Bazel, teams use a combination of **CODEOWNERS** (requiring review from the owning team for any dependency on their schemas), **package naming conventions** with lint rules (Nx tags on generated type packages enforce scope isolation), and **contract packages** that expose only approved types through curated barrel files.

**Architectural layering** works best with multi-dimensional tags. Define both type dimensions (`type:app`, `type:feature`, `type:ui`, `type:data-access`, `type:model`, `type:util`) and scope dimensions (`scope:orders`, `scope:users`, `scope:shared`), then enforce a dependency matrix where apps can depend on features, features on UI and data-access, but models depend on nothing. Run these checks in CI — they catch violations before code review.

---

## 4. Build cache correctness and the CREEP vulnerability

Remote caching dramatically accelerates CI but introduces correctness risks that most teams underestimate. The architectural differences between caching systems determine both performance and safety.

**Bazel's two-tier architecture** separates the Action Cache (mapping action hashes to result metadata) from the Content-Addressable Store (mapping SHA-256 content hashes to file contents). Actions are the unit of caching — a single file compilation, not an entire package build. This fine granularity means changing one file invalidates only actions that depend on that file, and identical output files are stored once regardless of which action produced them. Bazel also supports **remote execution**, distributing individual actions across worker farms, which forces hermeticity because all inputs must be explicitly declared.

**Turborepo's single-tier system** caches at the task level: a task hash maps to a zipped tarball of the entire output directory. This is simpler but coarser — no deduplication, no ability to distribute individual compilation steps. **Nx's computation cache** adds tree-diffing on restoration (only restoring changed files, faster than Turborepo's full extraction) and branch-scoped isolation in Nx Cloud.

**CVE-2025-36852 (CREEP)**, discovered by Nx researchers in June 2025 with a severity score of **9.4**, exploits a "first-to-cache-wins" race condition. An attacker creates a PR branch where source files match the main branch's hash, injecting malicious code into the build pipeline rather than the source. Whichever build completes first writes to the shared cache slot. This affects **any self-hosted cache using bucket-based storage without branch isolation** — including Turborepo, self-hosted Nx, and most custom Bazel cache setups. Only Nx Cloud's multi-tiered, branch-scoped caching and properly configured Bazel setups (write-restricted to CI-only) are secure by default.

**Ensuring hermeticity** requires sandbox execution, where each action runs in an isolated filesystem view with only declared inputs visible. Bazel provides this via Linux namespaces and macOS sandbox-exec. Turborepo, Nx, Rush, and Moon offer **no sandbox execution** — tasks can access the entire filesystem, making cache correctness dependent on correct configuration rather than enforced isolation.

**Language-specific determinism challenges** are substantial. Go builds are generally reproducible with `-trimpath` and consistent toolchains, but **CGo breaks determinism** by linking system C libraries. Rust proc macros execute arbitrary code at compile time — the **Watt** library compiles them to WebAssembly for isolation. Incremental Rust compilation is non-deterministic by design; disable it in CI with `CARGO_INCREMENTAL=0`. TypeScript's module resolution is affected by `node_modules` hoisting behavior — pnpm's strict isolation produces the most reproducible results. Always include toolchain versions, platform/architecture, and lockfile hashes in cache keys.

---

## 5. Workspace dependencies across three ecosystems

Managing dependencies across Go modules, Cargo workspaces, and JavaScript package managers requires coordinating three fundamentally different resolution systems.

**pnpm workspaces** are the strongest choice for JavaScript/TypeScript. pnpm's content-addressable store with symlinked `node_modules` enforces strict isolation — each package can only access its declared dependencies. If `package-a` tries to import a library only declared in `package-b`, it **fails immediately in development**, catching phantom dependencies before production. Version alignment across packages uses **pnpm catalogs** (v9.5+), which define reusable version ranges (`catalog: { react: "^18.3.0" }`) referenced in `package.json` as `"react": "catalog:"`. The **syncpack** tool (used by AWS, Cloudflare, Vercel) enforces consistent versions across all workspace packages.

**React Native complicates everything.** Metro bundler cannot follow symlinks by default, breaking pnpm's isolation model. The simplest fix is `node-linker=hoisted` in `.npmrc`, which reverts to npm-like flat `node_modules` for the entire workspace. The better approach configures Metro with `unstable_enableSymlinks: true` and adds monorepo-root watch folders. Expo SDK 55+ handles this automatically.

**Go workspaces** (`go.work`, introduced in Go 1.18) coordinate multiple modules without polluting individual `go.mod` files with `replace` directives. The recommended practice: **do not commit `go.work`** to version control — treat it as a local development convenience, building each module independently via `go.mod` in CI. If committing `go.work`, enforce `GOWORK=off` in production builds. Use `go work sync` to align dependency versions across modules.

**Cargo workspaces** share a single `Cargo.lock` and `target/` directory across all crates, avoiding redundant compilation. The `[workspace.dependencies]` table centralizes version declarations: member crates reference them with `serde = { workspace = true }`. A critical pitfall is **feature unification**: Cargo enables all features requested by any workspace member for shared dependencies, which can cause binary bloat or build failures. The **cargo-hakari** tool generates a "workspace-hack" crate that explicitly unifies features, preventing recompilation churn when switching between packages.

**Unified cross-language coordination** requires grouping related dependencies in automated update tools. **Renovate** (strongly preferred over Dependabot for polyglot repos) supports npm, Go modules, Cargo, Docker, and 50+ managers with grouped updates. Configure package rules to group all protobuf-related dependencies across languages (`google.golang.org/protobuf`, `prost`, `@bufbuild/protobuf`) into a single PR. Pin tool versions with **mise** (`mise.toml` committed to the repo root), which manages Node, Go, Rust, and Python versions in one file and auto-switches on directory entry.

**Buf** provides first-class monorepo support for protobuf schemas with a single `buf.yaml` defining multiple modules that can import each other locally, atomic pushes to the Buf Schema Registry, and cross-language code generation via `buf generate`. For GraphQL, **Apollo Federation** suits large teams with independent subgraphs, while **schema stitching** (`@graphql-tools/stitch`) works better for smaller teams wanting simplicity.

---

## 6. CI that stays fast as the monorepo scales to thousands of packages

CI optimization for monorepos operates on four axes: running less (affected detection), running faster (parallelism and caching), preventing breakage (merge queues), and spending less (infrastructure optimization).

**Dynamic pipeline generation** is the foundation. Rather than running all tests for every PR, analyze the dependency graph and generate CI jobs for affected targets only. GitHub Actions supports dynamic matrices via `fromJson()` output from a detection job. GitLab offers parent-child pipelines with dynamically generated YAML. Buildkite excels with `buildkite-agent pipeline upload`, allowing programmatic step generation in any language. CircleCI's two-phase dynamic config uses `path-filtering` orbs to map file patterns to pipeline parameters.

**Test sharding** distributes work across runners. Jest v28+ provides `--shard=1/4` for even distribution. **Naive splitting by test count creates imbalanced shards** — use historical timing data instead. At Tanium (200+ packages), they evolved from static equal distribution to timing-based distribution for balanced execution. Rust tests benefit from **cargo nextest**, which provides ~40% speedup over `cargo test` through parallel test execution with `--partition count:1/4` syntax. Go's `go test -parallel` leverages available cores within a single runner before adding shards.

**Merge queues** prevent the fundamental monorepo problem: individually-passing PRs that break main when merged together. GitHub's native merge queue handles **2,500+ PRs/month** internally with batches of 30+ changes. **Mergify** adds speculative checks (testing multiple PRs in parallel) and monorepo-aware scopes that only batch compatible changes. **Aviator MergeQueue** provides the deepest monorepo integration — it detects affected Bazel targets, creates disjoint parallel queues for independent changes, and merges concurrently. Uber's custom SubmitQueue processes **50 code changes/hour** during working hours, achieving **53% CI resource reduction** and 37% P95 wait time reduction through optimized conflict analysis.

**Flaky test management** becomes critical at scale. Uber tracks ~1,000 flaky tests out of 600K in their Go monorepo. **BuildPulse** automatically catalogs flaky tests, quarantines them when disruption exceeds a threshold, and creates tickets for owners. The key insight: "Quarantining doesn't cost you test coverage — it automates the loss of coverage you're going to suffer anyway" when developers start ignoring failures.

**Cost optimization** yields dramatic savings. Self-hosted runners on **AWS Spot instances cost ~$170/month** versus GitHub's $731 for equivalent capacity — a **76% reduction**. Rust compilation needs special attention: 16-core runners with **sccache** and RAM disk (`tmpfs` mounted at `CARGO_TARGET_DIR`) deliver the best performance. React Native iOS builds are the biggest bottleneck; Chime reduced 20-minute builds to **1 minute for 95% of PRs** by caching pre-built iOS binaries and only rebuilding when native code changes.

---

## 7. Deploying only what changed without breaking what didn't

Monorepo deployment orchestration must solve ordering, coordination, and rollback across interdependent services.

**Selective deployment** follows the same dependency graph used for affected detection: compute the diff since the last deployed commit, map changes to affected services, build only those services, and deploy in topological order. When a shared library changes, **all dependent services must rebuild and redeploy** — the dependency graph must capture transitive dependencies.

**ArgoCD with ApplicationSets** provides the best Kubernetes-native pattern for monorepo deployment. Git-generator ApplicationSets auto-discover services by directory pattern (`manifests/*/overlays/production`), automatically creating ArgoCD Applications for each service. **Sync waves** (`argocd.argoproj.io/sync-wave` annotations) enforce deployment ordering: database migrations run at wave 0, dependent services deploy at wave 1, with health checks between waves. At scale (1,000+ applications), every commit briefly puts all applications into "Unknown" state; mitigate with `manifest-generate-path` annotations and repo-server autoscaling.

**Database migration coordination** follows the expand-and-contract pattern: first add new columns/tables (backward-compatible), deploy the new application version, then remove old structures after all instances run the new code. Migrations should run as standalone Kubernetes Jobs before application deployments, not during Pod initialization. Each service manages its own migration directory (`services/api/migrations/`).

**Canary deployments for interdependent services** require service mesh integration. Use **Argo Rollouts** with Istio for Go backend services (fine-grained traffic splitting), **blue-green switching at the CDN/load balancer** for React web apps, and **staged rollouts** via TestFlight/Google Play for React Native mobile apps. Header-based routing (`x-canary: true`) through Istio routes specific requests through all canary versions simultaneously, enabling testing of coordinated multi-service changes.

**Feature flags** are essential for decoupling deployment from release. Google, Meta, and Shopify all use feature flags with trunk-based development in their monorepos. Deploy code with features disabled, enable after verification, and disable instantly for rollback without redeployment. Track flag lifecycle and enforce cleanup — Martin Fowler categorizes flags as release toggles (temporary), experiment toggles (temporary), ops toggles (longer-lived), and permission toggles (permanent).

**Separate the source code monorepo from a GitOps config repo.** CI builds images from the source monorepo and updates tags in the config repo; ArgoCD/Flux watches only the config repo. This provides clean deployment history, different access controls, and eliminates noise from code changes in the deployment pipeline.

---

## 8. Versioning shared libraries without version hell

Two models dominate: **"all at HEAD"** (source of truth) and **"published packages"** (versioned releases). The choice shapes your entire development workflow.

**All at HEAD** means every consumer references shared libraries directly from the monorepo source tree. No versions are published for internal use. Changes are atomic — a breaking change to a shared library and all consumer fixes land in one commit. Google, Meta, and Microsoft's internal repos use this model. The tradeoff: it requires comprehensive CI validating all consumers on every shared library change, and breaking changes block the entire monorepo. **Aspect Build recommends a single weekly tag** for the entire monorepo, letting Bazel's stamping feature embed versions.

**Published packages** version libraries independently via registries (npm, crates.io, Go module proxy). Consumers upgrade at their own pace. This works when libraries are consumed externally or when CI can't test all consumers on every change. The overhead is significant: CI, publishing infrastructure, version management, changelog generation, and diamond dependency risks.

The **recommended hybrid**: use source references internally (workspace protocol for TypeScript, `go.work` for Go, Cargo workspace paths for Rust) and publish versioned packages only for external consumers. **Changesets** (`@changesets/cli`) manages versioning with developer-authored change descriptions per PR. For polyglot repos, Luke Hsiao documented using proxy `package.json` files for non-JS packages with custom scripts syncing version bumps to `Cargo.toml` and Go modules.

**Breaking change detection** should gate every PR. Run **api-extractor** for TypeScript (generates reviewable `.api.md` diffs of public API surfaces), **cargo-semver-checks** for Rust (scans rustdoc JSON for semver violations — a study found **>3% of 14,000+ crate releases** had violations), **gorelease** for Go (suggests minimum semver version consistent with changes), **buf breaking** for protobuf (with FILE-level strictness by default), and **graphql-inspector** for GraphQL schemas (labels changes as breaking, non-breaking, or dangerous). Buffer uses graphql-inspector in GitHub Actions to block PRs with breaking schema changes.

---

## 9. Developer experience that doesn't punish you for using a monorepo

IDE performance, code navigation, local development tooling, and Git performance all degrade in large monorepos without deliberate optimization.

**VS Code multi-root workspaces** are essential for polyglot repos. Create team-specific `.code-workspace` files listing only relevant directories (`services/api`, `packages/shared`, `apps/web`). Aggressively exclude `node_modules`, `target`, `dist`, and generated code from file watchers via `files.watcherExclude` and `search.exclude`. Cross-language code navigation has no native solution — each language server (gopls, rust-analyzer, tsserver) operates independently. The best workaround: configure Buf's VS Code extension for proto navigation and ensure generated code directories are properly indexed by each language server.

**Local development** with inter-service dependencies requires orchestration. **Docker Compose** remains the simplest option for teams not on Kubernetes. **Tilt** provides the best visual developer experience with its web UI showing build status, logs, and service health in real-time, plus Starlark-based configuration and live file sync into running containers. **Skaffold** (Google) offers stronger CI/CD integration with profiles for different environments. For hot reloading, use `air` for Go, Vite HMR for React, and `cargo watch` for Rust.

**Git performance** degrades predictably at scale. Enable **FSMonitor** (`core.fsmonitor = true`, Git 2.37+): Chromium's 400K-file repo saw `git status` drop from **~18 seconds to ~1 second**. Enable `core.untrackedCache`, `fetch.writeCommitGraph`, and `feature.manyFiles` for additional gains. Run `git maintenance start` on all developer machines for automatic background prefetch, commit-graph updates, and incremental repacking.

**Sparse checkout** (Git 2.25+) combined with **partial clone** (`git clone --filter=blob:none --sparse`) is transformative for large repos. In GitHub's benchmark with 2M files, sparse checkout reduced the working directory to ~100K files, and combined with sparse index (Git 2.32+), commands like `git status` showed **5–10x speedups**. Microsoft's **Scalar** auto-configures all these optimizations with a single `scalar register` command. In CI, combine `--filter=blob:none` with `--sparse --no-checkout`, then `git sparse-checkout set` to only materialize what the job needs.

**Task runners** complement build systems for local workflows. **mise** (Rust-based, replaces asdf/nvm/pyenv) provides unified tool version management and task running across languages. Its 2025 monorepo tasks feature supports namespaced tasks (`//projects/frontend:build`) with wildcard execution. **just** (casey/just) offers clean syntax for polyglot command running with parameterized recipes. Use these for local developer commands; use Bazel/Nx/Turborepo for CI orchestration with caching.

---

## 10. What Google, Meta, Uber, and Stripe actually built

Every company at extreme monorepo scale built custom tooling, but their approaches reveal universal patterns.

**Google's Piper** holds **2 billion+ lines of code** across 86 TB, processing **40,000+ commits/day** by 10,000+ engineers. CitC (Clients in the Cloud) provides FUSE-based virtual filesystem workspaces where developers see their changes overlaid on the full repository, with only modified files stored locally. Blaze (open-sourced as Bazel) processes the dependency DAG, and TAP (Test Automation Platform) handles presubmit testing. The entire system enforces trunk-based development with no long-lived branches.

**Meta** open-sourced **Buck2** (April 2023), a complete Rust rewrite achieving 2x Buck1's speed. **Sapling** replaced Mercurial with a Rust-based client supporting **EdenFS** — a virtual filesystem where files appear to exist but download on demand. In 2025, Meta introduced **directory branching** via `sl subtree` commands, creating branch-like structures while maintaining a linear commit graph critical for scalability. **Watchman** monitors filesystem changes for efficient build triggering.

**Uber** operates **language-split monorepos**: their Go monorepo contains ~**50 million lines**, ~2,100 services, with 1,000+ commits/day from ~900 engineers. They migrated from Make to Bazel and became top contributors to Gazelle (Bazel's Go BUILD file generator). Their custom **SubmitQueue** handles 50 changes/hour, achieving 53% CI resource reduction. A single Uber commit can affect up to **3,000 microservices**; their domain-oriented architecture reduced cross-domain dependencies by 67%.

**Airbnb** operates an **11 million+ line web monorepo** and converted **86% of their 6M-line frontend to TypeScript**, building the open-source ts-migrate tool that can convert 50,000+ lines in a single day. Their Bazel migration delivered 34% faster type checking and 42% faster incremental test execution.

**Stripe** maintains one of the **world's largest Ruby codebases** (20M+ lines) with ~1,145 PRs/day. They use cloud devboxes with Watchman + rsync file synchronization, custom Git sparse checkout tooling, and feature flags with per-account targeting. Their developer productivity team prioritizes stability and reliability over features — a lesson Stripe's Nelson Elhage emphasized: "The best tooling in the world will struggle to make up for regularly losing a day debugging your environment."

**Microsoft** built **VFS for Git** (GVFS) specifically for the Windows OS monorepo (300GB, 3.5M files), evolved it into **Scalar** (a lighter wrapper around native Git features), and is upstreaming those features into Git itself. Their **Rush** tool provides governance-focused TypeScript monorepo management with phantom dependency detection and controlled publishing.

Five patterns emerge universally. Every successful large monorepo has **dedicated DevInfra/platform teams**. All use **trunk-based development** with feature flags. All invested in **custom merge queue infrastructure**. All hit version control performance limits and built solutions (Piper, Sapling, GVFS, patched Git). And all teams behind Turborepo, Nx, and Pants are **converging on Rust** for core tooling performance (2023–2025), narrowing the performance gap while differentiation shifts to features and philosophy.

---

## Conclusion

The polyglot monorepo problem decomposes into a tooling stack, not a single tool choice. For the Go + Rust + TypeScript/React/React Native + protobuf/GraphQL stack described here, the recommended architecture layers **pnpm** for JavaScript dependency isolation, **Cargo workspaces** with `workspace.dependencies` for Rust, **go.work** for Go module coordination, and **Buf** for protobuf schema management — all orchestrated by either Bazel (with dedicated build engineers) or Nx with language-specific plugins (for pragmatic teams). Use **mise** for unified toolchain management, **Renovate** with grouped package rules for automated dependency updates, and **cargo-hakari** to prevent Rust feature unification issues.

Three non-obvious insights deserve emphasis. First, **cache security is an unsolved problem for most teams**: CVE-2025-36852 means any self-hosted cache without branch isolation is vulnerable, and only Nx Cloud provides this by default. Second, **React Native is the hardest integration point** — Metro's inability to follow symlinks forces compromises in pnpm's strict isolation model, and iOS build times dominate CI costs until you cache pre-built native binaries. Third, **affected detection's value depends entirely on package granularity**: a single "shared" library that everything depends on makes the entire dependency graph useless. The most impactful architectural decision is splitting shared code into fine-grained, domain-scoped modules with enforced boundaries — the technical foundation that makes every other optimization possible.