# Open source licensing compliance for engineering teams

**Every dependency your team adds carries legal obligations that can torpedo a product launch, block an acquisition, or force open-sourcing proprietary code.** This guide provides the complete operational playbook for engineering teams working with Go, Rust, and TypeScript codebases — covering automated license scanning, copyleft risks, contributor agreements, export controls, patent strategy, and the rapidly shifting landscape of "source available" licenses like BSL. All tools, configurations, and CI pipeline examples reflect current best practices as of 2025–2026.

The stakes are real: companies have faced multi-million-dollar lawsuits over GPL violations, IBM paid **$6.4 billion** for HashiCorp only to inherit a BSL licensing controversy, and Google has completely banned AGPL-licensed code internally. Getting license compliance right is not optional — it's infrastructure.

---

## 1. License compliance scanning catches problems before they ship

License compliance scanning works by parsing dependency manifests (`go.mod`, `Cargo.toml`, `package.json`), building a complete dependency tree, and classifying each dependency's license against the **SPDX License List** — an ISO/IEC 5962:2021 standard maintained by the Linux Foundation defining **600+ standardized license identifiers**. Tools compare license file text against SPDX templates using matching algorithms, then report each dependency's license as an SPDX ID like `MIT`, `Apache-2.0`, or `GPL-3.0-only`.

**FOSSA** is the most comprehensive enterprise solution, supporting 20+ package managers including Go modules, Cargo, and npm. Install with `curl -H 'Cache-Control: no-cache' https://raw.githubusercontent.com/fossas/fossa-cli/master/install-latest.sh | bash`, then run `fossa analyze` to scan and `fossa test` as a CI gate. FOSSA generates attribution reports (`fossa report attribution`) in JSON, Markdown, SPDX SBOM, and plain text. Its weakness is requiring a cloud account and API key.

**go-licenses** (Google) is purpose-built for Go. Install with `go install github.com/google/go-licenses/v2@latest`. The critical commands are `go-licenses check --disallowed_types=forbidden,restricted,unknown ./...` to gate CI, and `go-licenses report ./...` for CSV output showing module, license URL, and SPDX type. It classifies licenses into categories: `notice` (permissive), `reciprocal` (weak copyleft), `restricted` (strong copyleft), `forbidden`, and `unencumbered`.

**cargo-deny** (EmbarkStudios) is the gold standard for Rust. It checks licenses, security advisories, banned crates, and source trust in a single tool. Install with `cargo install --locked cargo-deny`, initialize with `cargo deny init`, and run `cargo deny check licenses`. Configuration lives in `deny.toml` with explicit allow/deny lists using SPDX identifiers.

**license-checker-rseidelsohn** is the actively maintained fork for Node.js/TypeScript. Install with `npm install -g license-checker-rseidelsohn`. The key CI command is `license-checker --production --onlyAllow "MIT;ISC;Apache-2.0;BSD-2-Clause;BSD-3-Clause;CC0-1.0;Unlicense;0BSD"` (note: semicolons, not commas, as of v17+). Use `--failOn "GPL-2.0-only;GPL-3.0-only;AGPL-3.0-only"` for block-list enforcement.

**Snyk** provides license compliance alongside vulnerability scanning but requires a **paid plan** (Business tier or higher) for license policy enforcement. Run `snyk test --org=<ORG_ID>` to check against organization-level license policies configured in the Snyk web UI.

### The license compatibility matrix every team needs

Understanding which licenses can coexist as dependencies is fundamental. The key rules:

**Permissive + Permissive always works.** MIT, Apache 2.0, BSD, and ISC dependencies can be freely combined. **Apache 2.0 and GPL v2 are incompatible** — Apache 2.0's patent retaliation clause constitutes an "additional restriction" under GPL v2. However, **Apache 2.0 code can enter GPL v3 projects** (the combined work becomes GPL v3). If your MIT-licensed project uses a GPL dependency, the **combined distributed work must comply with GPL terms** — your standalone source files remain MIT, but the distributed combination is effectively GPL.

| Your project license | Can use MIT deps? | Can use Apache 2.0 deps? | Can use GPL v2 deps? | Can use GPL v3 deps? | Can use AGPL deps? | Can use LGPL deps? | Can use MPL 2.0 deps? | Can use BSL deps? |
|---|---|---|---|---|---|---|---|---|
| **MIT** | ✅ | ✅ | ⚠️ Combined work becomes GPL | ⚠️ Combined work becomes GPL | ⚠️ Combined work becomes AGPL | ✅ Via dynamic linking | ✅ MPL files stay MPL | ❌ Not OSS |
| **Apache 2.0** | ✅ | ✅ | ❌ Incompatible | ⚠️ Combined work becomes GPL v3 | ⚠️ Combined work becomes AGPL | ✅ Via dynamic linking | ✅ | ❌ |
| **GPL v3** | ✅ | ✅ | ✅ If "v2 or later" | ✅ | ✅ | ✅ | ✅ | ❌ |

**BSL 1.1 is not open source** and cannot be freely combined with GPL during its restricted period. LGPL dependencies are safe for all projects via dynamic linking. MPL 2.0 operates at the file level — modifications to MPL files stay MPL, but the larger work can use any license.

---

## 2. SPDX headers belong in every source file

An SPDX-License-Identifier tag is a machine-readable, single-line comment declaring the license of each source file. This matters because when files are copied between projects, a top-level `LICENSE` file stays behind — but SPDX headers travel with the file. The Linux kernel, Kubernetes, and all CNCF projects require them.

**Go files:**
```go
// Copyright 2026 Acme Corporation
// SPDX-License-Identifier: Apache-2.0

package main
```

**Rust files** (the ecosystem convention is dual-licensing):
```rust
// Copyright 2026 Acme Corporation
// SPDX-License-Identifier: MIT OR Apache-2.0

fn main() {}
```

**TypeScript/JavaScript files:**
```typescript
// Copyright 2026 Acme Corporation
// SPDX-License-Identifier: Apache-2.0

import { something } from './module';
```

**Google's `addlicense`** is the most versatile insertion tool, handling Go, Rust, TypeScript, and dozens of other formats. Install with `go install github.com/google/addlicense@latest`. Add headers: `addlicense -c "Acme Corporation" -l apache -s .`. Verify in CI: `addlicense -check -c "Acme Corporation" -l apache -s .` (exit code 1 if any file is missing a header).

For TypeScript-specific enforcement, **`eslint-plugin-header`** integrates directly into your ESLint pipeline:
```javascript
// eslint.config.mjs (ESLint 9+ flat config)
import header from "eslint-plugin-header";
export default [{
  plugins: { header },
  rules: {
    "header/header": ["error", "line", [
      " Copyright 2026 Acme Corporation",
      " SPDX-License-Identifier: Apache-2.0"
    ]]
  }
}];
```

Running `npx eslint --fix` auto-inserts missing headers. **`licensure`** (Rust-based, by chasinglogic) provides cross-language header management configured via `.licensure.yml`, with SPDX API integration for standard header templates.

---

## 3. When GPL and AGPL copyleft obligations actually trigger

The single most important rule: **GPL copyleft is triggered by distribution, not by use.** Running GPL code internally — even modifying it extensively — creates zero obligations. The obligations arise only when you distribute the combined work to third parties, at which point the entire combined work must be GPL-licensed with source code provided.

**The SaaS loophole** is the most commercially significant nuance. Because serving software over a network is not "distribution" under GPL, SaaS providers can take GPL-licensed software, modify it, deploy it server-side, and serve millions of users without sharing a single line of source code. **AGPL v3 closes this loophole** via Section 13: if you modify AGPL software and make it available over a network, you must provide source code to all network users. This is why Google has completely banned AGPL internally and why many companies treat AGPL as a non-starter.

The **static vs. dynamic linking** debate remains legally unresolved. The FSF holds that dynamic linking makes no difference — linking GPL code in any form creates a combined work. However, **Linus Torvalds disagrees** (allowing proprietary kernel modules), and former OSI General Counsel Larry Rosen has argued that "the meaning of derivative work will not be broadened to include software created by linking to library programs." No court has definitively ruled on this. The conservative approach is to treat all linking to GPL libraries as triggering copyleft.

**Container and microservice isolation provides strong protection.** Richard Fontana (Red Hat Senior Counsel) provides the authoritative analysis: "In the absence of very unusual facts, we should not expect to see copyleft scope extending across multiple containers. Separate containers involve separate processes. Communication between containers by way of network interfaces is analogous to pipes and sockets." Process-level separation via REST APIs, CLI invocations, or IPC is generally sufficient — but the FSF applies an "intimacy test": if communication involves exchanging complex internal data structures, the programs might be considered a combined work.

Practical rules of thumb for engineering teams:

- **Linking a GPL library into your binary and distributing it** → copyleft triggered (FSF view; industry debate on dynamic linking)
- **Using a GPL CLI tool (GCC, Bison) to build your code** → copyleft NOT triggered; output is not derivative
- **Running GPL on your server without distributing** → NOT triggered (unless AGPL)
- **GPL and proprietary code in separate containers via API** → NOT triggered (strong separateness)
- **LGPL library dynamically linked** → NOT triggered (LGPL explicitly permits this)
- **GPL JavaScript sent to user browsers** → triggered (distribution to users)

---

## 4. CLAs and DCO protect project IP in different ways

**CLA Assistant** (by SAP, open source under Apache 2.0) is the most widely used CLA bot for GitHub. Set it up at cla-assistant.io: create a GitHub Gist with your CLA text, link your repository, and configure the bot to comment on PRs requiring unsigned contributors to sign. Signatures are stored in Cosmos DB, and PR status checks block merging until all contributors have signed. The **CLA Assistant Lite** variant (a GitHub Action) stores signatures as a JSON file in the repository itself, with contributors signing by posting "I have read the CLA Document and I hereby sign the CLA" as a PR comment.

The **Developer Certificate of Origin (DCO)** is the lighter-weight alternative, introduced by the Linux Foundation in 2004. Contributors certify they have the right to submit code by adding `Signed-off-by: Name <email>` to every commit via `git commit -s`. The DCO GitHub App (github.com/apps/dco) enforces that all commits in a PR contain a valid Signed-off-by line. **Spring Framework switched from CLA to DCO in January 2025**, joining Node.js and the entire CNCF ecosystem in favoring this simpler approach.

The critical distinction between **IP assignment and license grant**: IP assignment transfers copyright ownership to the project entity, enabling unrestricted relicensing. License grant CLAs (used by Apache, Google, Microsoft) let contributors retain copyright while granting the project broad rights. IP assignment is necessary for dual-licensing business models (e.g., MySQL's GPL + commercial license requires 100% copyright ownership). License grant CLAs are preferred when frictionless contribution matters more than relicensing flexibility.

How major projects handle this:

- **Linux kernel**: DCO only (no CLA). `Signed-off-by` required on every commit. Contributions understood to be under GPLv2.
- **Apache Software Foundation**: Individual CLA (ICLA) required for all committers + optional Corporate CLA (CCLA). Includes both copyright and patent license grants.
- **Google**: Single CLA at cla.developers.google.com covers all Google OSS projects (Kubernetes, Go, Angular). Based on Apache CLA templates.
- **Microsoft**: CLA at cla.opensource.microsoft.com covering .NET, TypeScript, VS Code. Microsoft employees auto-signed; trivial changes labeled "cla-not-required."

The **2025 trend clearly favors DCO and simplification.** Apache 2.0 has risen to the #1 most popular license (surpassing MIT), partly because its explicit patent grant reduces the need for separate CLA patent provisions.

---

## 5. Open source contribution policy protects the business

Before open-sourcing proprietary code, engineering teams must evaluate: does the code represent core competitive IP? Have security reviews cleared it of embedded secrets, credentials, and internal URLs? Does it contain third-party code with restrictive licenses? Has patent counsel assessed whether releasing under Apache 2.0 (which includes an explicit patent grant) will license company patents to the public?

The **internal approval process** should involve engineering management (approving resource allocation), legal/OSPO (license selection, IP clearance), security (secrets audit), and product management (confirming no competitive disclosure). The TODO Group (Linux Foundation) recommends establishing pre-approved categories — bug fixes to upstream OSS, MIT-licensed patches, sub-100 LOC contributions — that bypass full review to minimize friction.

**License selection for new projects** follows a clear decision tree. Use **MIT** for maximum adoption with minimal restrictions. Choose **Apache 2.0** when patent protection matters (it includes an explicit patent grant + retaliation clause). Select **MPL 2.0** for file-level copyleft that allows proprietary use of the larger work. Use **GPL v3** to force all derivative works to remain open source. Choose **AGPL v3** for SaaS/network-deployed software where you want to prevent proprietary cloud offerings.

**Dual licensing** comes in two main forms. The **open core model** (GitLab) keeps the core open source while selling proprietary premium features — this doesn't require contributor copyright control. The **GPL + commercial license model** (MySQL, Qt) offers the software under GPL for open source use and a commercial license for proprietary embedding — this requires 100% copyright ownership via CLAs or assignment. When to choose: use open core when community adoption is paramount; use GPL + commercial when preventing proprietary use without payment is the business model.

---

## 6. Attribution requirements vary significantly by license

**Apache 2.0** has the most explicit attribution requirements: Section 4(d) mandates that any derivative work must include a readable copy of the NOTICE file. The NOTICE file contains copyright holders, project names, and attribution notices required by upstream dependencies. You may add your own notices but cannot remove existing ones.

**MIT and BSD** require including the full license text (with copyright notice) in all copies or substantial portions. **GPL** requires including the full license text, providing source code (or a written offer valid for 3 years), and keeping all copyright notices intact. **MPL 2.0** requires making source code of MPL-licensed files available and including the license text.

For **Go**, use `go-licenses save ./... --save_path=./third_party/licenses` to collect all license files for redistribution, and `go-licenses report ./...` for CSV reports. For **Rust**, `cargo-about` generates HTML attribution reports from Handlebars templates — configure `about.toml` with accepted licenses and run `cargo about generate about.hbs > third_party_licenses.html`. For **Node.js**, `oss-attribution-generator` (`npx generate-attribution`) creates both human-readable `attribution.txt` and machine-readable `licenseInfos.json`.

**Mobile apps have specific requirements.** On iOS, best practice is a Settings.bundle displaying acknowledgements — the **LicensePlist** tool (`brew install licenseplist`) auto-generates plist files from CocoaPods, SwiftPM, and Carthage dependencies. On Android, Google provides the **OSS Licenses Plugin** that adds a built-in licenses activity.

Engineering teams should **automate attribution generation in CI/CD** — run attribution generators as part of the build pipeline and fail builds if the generated output differs from committed attribution files. Add a Makefile target:
```makefile
.PHONY: licenses
licenses:
	go-licenses save ./... --save_path=./third_party/go
	cargo about generate about.hbs > THIRD_PARTY_RUST.html
	npx generate-attribution -o ./third_party/node
```

---

## 7. Export controls apply to encryption code on GitHub

Software implementing encryption for confidentiality protection falls under **ECCN 5D002** in the Export Administration Regulations (EAR). This covers any software using symmetric algorithms with key length exceeding 56 bits (AES-128/256), RSA with factorization exceeding 512 bits, or elliptic curve discrete logarithms exceeding 112 bits — essentially all modern encryption.

The critical exception: **publicly available encryption source code classified under ECCN 5D002 is not subject to the EAR** per 15 CFR §742.15(b)(1). Code on public GitHub repositories qualifies because it is freely accessible without authentication and has no restrictions on further dissemination. The code must genuinely be public — **private repositories do not qualify**, and requiring account creation to download could destroy the "publicly available" classification.

Following a **2021 rule change** implementing Wassenaar Arrangement 2019 decisions, **no email notification is required** for publicly available source code using standard cryptographic algorithms (AES, RSA, TLS, SHA-family, ECDHE). This covers the vast majority of open source projects. Notification to BIS (`crypt@bis.doc.gov`) and NSA (`enc@nsa.gov`) is **still required** only for code implementing non-standard or novel cryptographic algorithms — such as experimental post-quantum ciphers or custom encryption schemes.

Even with the publicly available exception, **sanctions restrictions still apply.** You cannot provide technical assistance related to encryption to Country Groups E:1/E:2 (Cuba, Iran, North Korea, Syria, Crimea/Donetsk/Luhansk regions), and you cannot knowingly export to individuals or entities on the Denied Persons List, Entity List, or SDN List.

Practical steps for teams publishing crypto code: (1) classify whether your software implements confidentiality encryption above thresholds, (2) confirm the code is on a truly public repository, (3) determine if cryptography is standard or non-standard, (4) if non-standard, email BIS and NSA with the URL *before* making the code public.

---

## 8. Patent grants make Apache 2.0 the enterprise default

Apache License 2.0 Section 3 contains an **explicit patent grant**: "each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable... patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work." This covers patents necessarily infringed by each contributor's contributions alone or combined with the Work. **MIT has no explicit patent grant** — it may create an implied license under US law, but this is legally untested. This is the primary reason Apache 2.0 is preferred over MIT for enterprise use.

Apache 2.0's **patent retaliation clause** terminates all patent licenses granted to you if you sue anyone claiming the Work constitutes patent infringement. MPL 2.0 has a similar clause but excludes declaratory judgments, counter-claims, and cross-claims (making it slightly narrower). These clauses create a mutual defense pact: use the software freely, but patent aggression against it costs you your rights.

Three defensive patent organizations matter for open source teams. The **Open Invention Network (OIN)** has **4,100+ members** including IBM, Google, Microsoft (bringing 60,000+ patents), and Toyota. Members cross-license patents covering 5,100+ Linux System packages. It's free for organizations under $10M revenue. The **LOT Network** has **5,800+ members** covering ~6 million patent assets (>24% of all US patents). Its mechanism is different: if any member's patents are sold to a patent troll, all LOT members automatically receive immunity. Free for companies under $25M revenue. The **Defensive Patent License (DPL)** is more radical — members must commit all patents (not just selected ones) but gain broader protection. It has smaller adoption, primarily in academic circles.

**GPL v3 includes an explicit patent grant** (Section 11) covering "essential patent claims" — broader than Apache 2.0 because it covers the entire program as modified, not just individual contributions. GPL v2 has **no explicit patent grant**, though the implied license doctrine under US law provides some protection. BSD and MIT provide no patent coverage at all.

---

## 9. BSL and source-available licenses demand careful evaluation

**HashiCorp's August 2023 move from MPL 2.0 to BSL 1.1** for Terraform, Vault, Consul, and Nomad was the most consequential licensing change in recent years. The BSL Additional Use Grant permits all production use **except** "offering the Licensed Work to third parties on a hosted or embedded basis which is competitive with HashiCorp's products." Internal use, consulting, and cross-product competition are all permitted. Each version converts to MPL 2.0 four years after release (versions from August 2023 convert circa August 2027). **IBM completed its $6.4 billion acquisition of HashiCorp on February 27, 2025** — Terraform and Vault remain BSL with no license reversion announced.

The community responded swiftly: the **OpenTofu** fork launched under the Linux Foundation, was accepted into CNCF in April 2025, and reached **95%+ feature parity** with Terraform including unique capabilities like native state file encryption. A 2025 Pulumi survey found **41% of platform engineers** cite IaC licensing uncertainty as a top-3 risk factor.

BSL is one of several "source available" models, none of which are OSI-approved:

- **Elastic License 2.0 (ELv2)** permits all use except providing the software as a managed service. Unlike BSL, it has **no change date** — restrictions are permanent. Elastic added AGPL v3 as a third option in August 2024, reclaiming "open source" status.
- **MongoDB SSPL** requires that if you offer MongoDB as a service, you must open-source your **entire service stack** — monitoring, backup, hosting, everything. OSI explicitly rejected it; Red Hat, Debian, and Fedora all dropped MongoDB packages.
- **MariaDB BSL** for MaxScale allowed production use with fewer than 3 server instances, converting to GPL after 2-3 years. But in 2025, **MariaDB moved MaxScale to fully closed source** — demonstrating that vendors can always move to *more* restrictive licensing in future versions.

| Dimension | BSL 1.1 | ELv2 | SSPL | Traditional OSS |
|---|---|---|---|---|
| **OSI-approved** | No | No | No | Yes |
| **Managed service** | Depends on Additional Use Grant | Explicitly prohibited | Requires open-sourcing entire stack | Permitted (except AGPL) |
| **Converts to open source** | Yes, ≤4 years | No, permanent | No, permanent | N/A |
| **Notable users** | HashiCorp, CockroachDB, Sentry | Elastic, Apollo GraphQL | MongoDB, Graylog | Linux, PostgreSQL, Kubernetes |

**Risk assessment for engineering teams:** (1) Internal use is generally safe across all source-available licenses. (2) Managed services and competitive products are the primary risk areas. (3) BSL's change date provides a built-in sunset, but 3-4 year old software may lack critical security patches. (4) Always check for viable open-source forks — OpenTofu, OpenSearch, and Valkey exist as insurance against vendor lock-in. (5) Foundation-governed projects (PostgreSQL, Kubernetes, Linux) are immune to vendor-driven license changes because no single entity controls the copyright.

---

## 10. CI/CD pipeline configurations that enforce compliance automatically

### Go license gate with go-licenses

```yaml
# .github/workflows/license-compliance.yml
  go-licenses:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-go@v5
        with:
          go-version: '1.22'
      - run: go install github.com/google/go-licenses@latest
      - run: go-licenses check --disallowed_types=forbidden,restricted,unknown ./...
```

For explicit allow-list control: `go-licenses check --allowed_licenses=MIT,Apache-2.0,BSD-3-Clause,ISC ./...`

### Rust license gate with cargo-deny

The `deny.toml` is your policy-as-code:

```toml
[licenses]
unlicensed = "deny"
confidence-threshold = 0.93
allow = [
    "MIT", "Apache-2.0", "Apache-2.0 WITH LLVM-exception",
    "BSD-2-Clause", "BSD-3-Clause", "ISC", "Zlib",
    "CC0-1.0", "Unlicense", "Unicode-3.0", "MPL-2.0",
]
deny = ["AGPL-3.0", "SSPL-1.0"]
copyleft = "deny"
private = { ignore = true }
exceptions = [
    { allow = ["ISC", "MIT", "OpenSSL"], crate = "ring" },
]
```

```yaml
  cargo-deny:
    runs-on: ubuntu-22.04
    strategy:
      matrix:
        checks: [advisories, "bans licenses sources"]
    continue-on-error: ${{ matrix.checks == 'advisories' }}
    steps:
      - uses: actions/checkout@v4
      - uses: EmbarkStudios/cargo-deny-action@v2
        with:
          command: check ${{ matrix.checks }}
```

### TypeScript/Node license gate with license-checker

```yaml
  node-licenses:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm ci --production
      - run: >
          npx license-checker --production
          --onlyAllow "MIT;ISC;Apache-2.0;BSD-2-Clause;BSD-3-Clause;CC0-1.0;Unlicense;0BSD"
          --excludePrivatePackages
```

### Multi-language pre-commit hooks

```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/EmbarkStudios/cargo-deny
    rev: 0.16.1
    hooks:
      - id: cargo-deny
        args: ["--all-features", "check", "licenses"]
  - repo: local
    hooks:
      - id: go-license-check
        name: Go License Check
        entry: bash -c 'go-licenses check --disallowed_types=forbidden,restricted,unknown ./...'
        language: system
        pass_filenames: false
        files: '(go\.mod|go\.sum)$'
      - id: node-license-check
        name: Node License Check
        entry: bash -c 'npx license-checker --production --onlyAllow "MIT;ISC;Apache-2.0;BSD-2-Clause;BSD-3-Clause;CC0-1.0"'
        language: system
        pass_filenames: false
        files: '(package\.json|package-lock\.json)$'
```

### Tiered license policy design

Maintain a central `license-policy.yml` in a shared repository with three tiers: **Tier 1 (auto-approved)** includes MIT, ISC, BSD-2/3-Clause, Apache-2.0, CC0-1.0, Unlicense, 0BSD, and Zlib. **Tier 2 (conditional, requires legal review)** includes MPL-2.0, LGPL-2.1, LGPL-3.0, EPL-2.0, and CDDL-1.0. **Tier 3 (blocked)** includes GPL-2.0, GPL-3.0, AGPL-3.0, SSPL-1.0, BSL-1.1, and any CC-BY-NC variants. Review this policy quarterly with engineering leads and legal.

When CI flags an unknown license, the workflow should block the PR with a clear error message, prompt the developer to check for permissively-licensed alternatives, and if the license genuinely needs review, require opening a license-review issue using a standardized template. Temporary exceptions can unblock development while review is pending — in `deny.toml`: `exceptions = [{ allow = ["EUPL-1.2"], crate = "under-review", reason = "Pending legal review — JIRA-1234" }]`.

---

## Conclusion: building license compliance into engineering culture

License compliance is not a legal checkbox — it's an engineering discipline that protects your ability to ship, sell, and grow. The most effective teams treat it as automated infrastructure: **cargo-deny's `deny.toml`, go-licenses' allow-lists, and license-checker's `--onlyAllow` flags** encode legal policy as code that runs on every PR. The key insight is that prevention costs almost nothing (a few minutes of CI time), while remediation after shipping can cost everything.

Three trends are reshaping the landscape in 2025-2026. First, the **source-available licensing wave** (HashiCorp, Elastic, Redis, CockroachDB) means teams must distinguish between "open source" and "source available" when evaluating dependencies — the forks (OpenTofu, OpenSearch, Valkey) provide insurance. Second, **Apache 2.0 has overtaken MIT** as the most popular license, driven by its explicit patent grant — teams should strongly prefer it for new projects. Third, the **DCO is replacing CLAs** for contributor agreements (Spring Framework's 2025 switch being the latest signal), favoring simplicity and lower contribution friction.

The complete compliance stack for a Go/Rust/TypeScript team: run cargo-deny, go-licenses, and license-checker in CI on every PR with explicit allow-lists; enforce SPDX headers via addlicense with `--check` mode; generate attribution documents automatically as build artifacts; maintain a tiered license policy reviewed quarterly; and treat BSL/SSPL/ELv2 dependencies as requiring explicit legal sign-off with documented migration plans to open-source alternatives.