# AI coding agent configuration repos worth knowing

**The ecosystem of shared AI coding rules has exploded into a multi-layered landscape spanning six major tool families, with the top repos collectively exceeding 500K GitHub stars.** Three official repos — Anthropic's skills, OpenAI's Codex, and GitHub's awesome-copilot — anchor the ecosystem, while community collections like awesome-cursorrules (38K stars) and obra/superpowers (42K+ stars) demonstrate that practitioner-driven configurations often rival official offerings. The field is converging toward AGENTS.md as a universal standard, now stewarded by the Linux Foundation and supported by 20+ tools. Below are the **40 most significant repositories**, organized by category, with every detail you requested.

---

## Official platform repos set the standard

These repos come directly from the companies building AI coding tools. They serve as both reference implementations and practical configuration sources.

### anthropics/skills — ~111K ⭐
**URL:** https://github.com/anthropics/skills
**Domains:** Creative/design, document creation (DOCX, PDF, PPTX, XLSX), API development, web app testing, MCP server building, brand guidelines, frontend design
**Author:** Anthropic (official)
**Structure:** Folder-per-skill with SKILL.md files. Each skill is self-contained: `skills/<name>/SKILL.md` plus optional `scripts/`, `references/`, `assets/` directories. Includes a built-in `skill-creator` skill for generating new skills.
**Quality:** Apache 2.0 license, 470+ open PRs, actively maintained. **The canonical reference** for how SKILL.md files should be structured. Skills work across Claude.ai, Claude Code, and the Claude API.

### anthropics/claude-code — ~110K ⭐
**URL:** https://github.com/anthropics/claude-code
**Domains:** The Claude Code CLI tool itself, with built-in plugin skills including `skill-development` and `claude-api`
**Author:** Anthropic (official)
**Structure:** Contains nested SKILL.md files in `plugins/` directories serving as reference implementations
**Quality:** The tool powering the entire Claude Code skills ecosystem. Contains the definitive examples of CLAUDE.md usage in its own documentation.

### openai/codex — ~73K ⭐
**URL:** https://github.com/openai/codex
**Domains:** Rust-based CLI development, sandbox security, coding conventions
**Author:** OpenAI (official)
**Structure:** Root AGENTS.md with build/test instructions and coding conventions, plus **88+ nested AGENTS.md files** across subdirectories. The root AGENTS.md is a masterclass in how to write agent instructions.
**Quality:** 640+ releases, updated weekly. **The reference implementation for the AGENTS.md format** — every other AGENTS.md repo derives patterns from this one.

### github/awesome-copilot — ~29K ⭐
**URL:** https://github.com/github/awesome-copilot
**Domains:** 175+ agents, 208+ skills, 176+ instructions covering C#/.NET, Go, Python, TypeScript, Java, Dart/Flutter, Rust, Angular, React, Next.js, Power BI, Azure, Kubernetes
**Author:** GitHub/Microsoft (official)
**Structure:** Organized into `/agents/` (*.agent.md), `/instructions/` (*.instructions.md), `/skills/` (SKILL.md folders), `/hooks/`, `/workflows/`, `/plugins/`. Has plugin system with marketplace.json and a companion website.
**Quality:** Launched July 2025, evolved into a full ecosystem by early 2026 with 600+ total resources. Now has its own CLI installer (`copilot plugin install`), Learning Hub, and plugin system. Updated weekly.

### Aider-AI/aider — ~43K ⭐
**URL:** https://github.com/Aider-AI/aider
**Domains:** Terminal-based AI pair programming, supports any language
**Author:** Paul Gauthier / Aider AI LLC
**Structure:** Configuration via `.aider.conf.yml` (YAML), auto-reads `CONVENTIONS.md`, supports `.aiderignore`. Convention files are read-only markdown documents that guide coding behavior.
**Quality:** One of the most established AI coding tools. Well-documented configuration system.

### continuedev/continue — ~32K ⭐
**URL:** https://github.com/continuedev/continue
**Domains:** Universal (VS Code, JetBrains, CLI). Configurable for any stack.
**Author:** Continue Dev, Inc.
**Structure:** Uses `config.yaml` for configuration (models, rules, context providers, MCP servers). Supports `.continue/checks/` for PR review agents and `.continue/configs/` for shared configs. YAML-based configuration syncs with hub.continue.dev.
**Quality:** Recently pivoted to CI-focused tooling with source-controlled AI checks. Very active development.

---

## Community "awesome" lists are the discovery layer

These curated collections serve as the primary way developers find rules for their specific tech stack. **PatrickJS/awesome-cursorrules dominates** with nearly 38K stars — an order of magnitude larger than any competitor.

### PatrickJS/awesome-cursorrules — ~38K ⭐
**URL:** https://github.com/PatrickJS/awesome-cursorrules
**Domains:** Nearly every major framework and language: React, Next.js (14/15), Angular, Vue, Svelte, Astro, Python, TypeScript, Go (5+ variants including Fiber, ServeMux, Temporal DSL), Rust, Java, Spring Boot, Elixir/Phoenix, Django, Flask, FastAPI, React Native Expo, Flutter, SwiftUI, Jetpack Compose, Docker, Kubernetes, Cloudflare Workers, Supabase, Playwright, Vitest, Tailwind CSS, shadcn/ui, Chrome extensions, SEO, Stripe (via Next.js rules)
**Author:** PatrickJS (well-known Angular/open-source community contributor)
**Structure:** Flat `rules/` directory with folder-per-technology pattern (e.g., `rules/react-typescript-cursorrules-prompt-file/.cursorrules`). CC0 license. Has companion VS Code extension `vscode-cursor-rules` and CLI tool `cursor-setup`.
**Quality:** 105 commits, 43 open issues, 21 open PRs. **The de facto standard** for cursor rules. Acts as the central reference for the entire Cursor rules ecosystem. Primarily `.cursorrules` format (legacy), though many rules are portable to other tools.

### hesreallyhim/awesome-claude-code — ~31K ⭐
**URL:** https://github.com/hesreallyhim/awesome-claude-code
**Domains:** Comprehensive curated list covering CLAUDE.md files, CLI tools, slash commands, workflows, skills, hooks, agent orchestrators, applications, plugins, and learning resources
**Author:** hesreallyhim (individual developer)
**Structure:** Single README with categorized links. CC BY-NC-ND 4.0 license. Unique policy: only Claude is allowed to submit PRs.
**Quality:** **The definitive awesome list for Claude Code.** 2.2K forks. Last updated January 2026. The best starting point for discovering Claude Code configurations.

### josix/awesome-claude-md
**URL:** https://github.com/josix/awesome-claude-md
**Domains:** Curated collection of real-world CLAUDE.md files organized by technology (TypeScript/JS, Python, Rust, Go, Swift) and use case (AI Development, Infrastructure, Web3, High Performance)
**Author:** Josix Wang (Python/ML engineer, PyConTW community leader)
**Structure:** Organized reference list with analyses, best practices, and templates
**Quality:** **The go-to repo for studying real-world CLAUDE.md patterns.** Referenced by multiple other repos. AI-assisted curation with human editorial oversight.

### ichoosetoaccept/awesome-windsurf — ~500 ⭐
**URL:** https://github.com/ichoosetoaccept/awesome-windsurf
**Domains:** Windsurf development, community prompts, tips, best practices
**Author:** ichoosetoaccept / detailobsessed
**Structure:** Includes `.windsurfrules` file, `/memories/` directory for community prompts. Well-maintained with CI/CD, semantic-release, Husky hooks, ESLint.
**Quality:** Most popular Windsurf awesome-list. Automated quality checks. Actively maintained with April 2026 commits.

### continuedev/awesome-rules — ~139 ⭐
**URL:** https://github.com/continuedev/awesome-rules
**Domains:** General coding standards, testing, documentation, technology-specific rules
**Author:** Continue.dev team (official)
**Structure:** Markdown + YAML frontmatter. Compatible with multiple AI assistants. Has CLI tool (`rules add`). CC0 license.
**Quality:** Official product repo from Continue team. Cross-tool compatible. Growing steadily.

---

## The viral frameworks that reshape how agents work

These repos go beyond static rule files — they implement complete methodologies that fundamentally change how AI coding agents behave.

### obra/superpowers — ~42K+ ⭐
**URL:** https://github.com/obra/superpowers
**Domains:** Complete agentic development methodology — brainstorming, TDD, debugging, subagent-driven development, code review, git worktree workflows, verification
**Author:** Jesse Vincent (obra) at Prime Radiant — a veteran open-source developer
**Structure:** Plugin-based with 20+ composable skills in `skills/` directory, each with SKILL.md. Includes `/brainstorm`, `/write-plan`, `/execute-plan` commands. SessionStart hook for automatic skill loading. Has satellite repos: `obra/superpowers-lab` (experimental), `obra/superpowers-marketplace`, `obra/superpowers-skills` (community-editable), `obra/superpowers-developing-for-claude-code`.
**Quality:** Available in the official Anthropic plugin marketplace since January 2026. **Works across Claude Code, Codex, Gemini CLI, and Copilot CLI.** Emphasizes strict TDD discipline with red/green methodology. Went viral in late 2025. Active Discord community. Arguably the most influential single repo in this space for changing AI coding agent behavior.

### grapeot/devin.cursorrules — ~6K ⭐
**URL:** https://github.com/grapeot/devin.cursorrules
**Domains:** General-purpose agentic workflow — autonomous planning, self-evolution, tool calling, web browsing, multi-agent architecture
**Author:** grapeot (individual developer)
**Structure:** Single `.cursorrules` file at root + `tools/` directory with Python scripts. Uses cookiecutter for project scaffolding. Multi-agent branch with Planner (o1) + Executor (Claude/GPT) architecture. "Scratchpad" methodology for task tracking.
**Quality:** Highly innovative approach that turns Cursor into a Devin-like autonomous agent. Blog post "Turning $20 into $500" went viral. CI with unit tests, actively maintained. **One of the most-starred individual cursorrules repos.**

### forrestchang/andrej-karpathy-skills — ~3.5K ⭐
**URL:** https://github.com/forrestchang/andrej-karpathy-skills
**Domains:** General AI coding behavior guidelines derived from Andrej Karpathy's observations on LLM coding pitfalls
**Author:** forrestchang (individual developer)
**Structure:** Single CLAUDE.md file (also usable as .cursorrules). Four core principles: Think Before Coding, Simplicity First, Surgical Changes, Goal-Driven Execution.
**Quality:** Spawned VS Code/Cursor extensions. Influential in the "agentic engineering" movement. Demonstrates that **a single well-crafted file can have more impact than a 200-file collection**.

---

## Notable developers share battle-tested configurations

These repos carry weight because of who created them — practitioners with deep domain expertise who share their actual working configurations.

### steipete/agent-rules — ~5.3K ⭐ (archived)
**URL:** https://github.com/steipete/agent-rules
**Successor:** https://github.com/steipete/agent-scripts
**Domains:** Claude Code and Cursor rules, git workflows, Swift/iOS development, multi-agent coordination
**Author:** **Peter Steinberger** — founder of PSPDFKit, well-known iOS/macOS developer and prolific open-source contributor
**Structure:** `global-rules/` and `project-rules/` directories. Uses `<shared>…</shared>` tagged blocks for rules shared across repos. Rules are extremely terse ("telegraph style" — noun-phrases, dropped grammar, minimal tokens). Archived Dec 2025.
**Quality:** Despite being marked outdated, the **massive fork count (496)** shows significant community adoption. Represents real-world rules from a notable developer's actual multi-project workflow. His successor repo `agent-scripts` shows the evolution toward AGENTS.md-first configuration.

### ChrisWiles/claude-code-showcase — ~5.2K ⭐
**URL:** https://github.com/ChrisWiles/claude-code-showcase
**Domains:** Complete Claude Code project configuration — hooks, skills, agents, commands, GitHub Actions workflows, testing patterns, branch protection
**Author:** Chris Wiles
**Structure:** Complete reference implementation: CLAUDE.md + `.claude/settings.json` + `.claude/skills/testing-patterns/SKILL.md` + hooks + agents. Auto-formatting hooks, testing patterns, branch protection.
**Quality:** **One of the most referenced real-world examples** of a complete Claude Code setup. Used as a template by many other developers.

### pontusab/directories (cursor.directory) — ~3.9K ⭐
**URL:** https://github.com/pontusab/directories
**Website:** https://cursor.directory
**Domains:** Community-submitted rules for Kubernetes, Go, Flutter, React, Next.js, Python, and many more. Also serves as a directory for MCP servers and plugins.
**Author:** Pontus Abrahamsson (creator of Midday.ai)
**Structure:** Next.js monorepo. Rules stored as TypeScript files in `packages/data/rules/`. All data lives in Supabase database. 673 commits.
**Quality:** **The primary web-based directory** for browsing Cursor and Windsurf rules. Community-driven content submission (no PRs needed for data). Recently expanded to include Windsurf rules.

---

## Cross-tool repos solve the fragmentation problem

The most forward-looking repos address a real pain point: teams using multiple AI coding tools shouldn't maintain separate rule files for each one.

### agentsmd/agents.md (Universal Standard)
**URL:** https://github.com/agentsmd/agents.md
**Website:** https://agents.md
**Domains:** Universal agent instruction format
**Author:** AGENTS.md initiative, stewarded by the Agentic AI Foundation under the Linux Foundation
**Structure:** Simple Markdown format with no required fields. Contains sample Next.js AGENTS.md, spec documentation, and website.
**Quality:** **The emerging universal standard**, now supported by Codex, Cursor, GitHub Copilot, Jules (Google), Factory, Aider, goose, Windsurf, Gemini CLI, Junie (JetBrains), Amp, RooCode, Devin, and 20+ other tools. Over **60K+ examples** on GitHub. The most important convergence point in this ecosystem.

### block/ai-rules — 44 ⭐ (company-backed)
**URL:** https://github.com/block/ai-rules
**Domains:** Cross-agent rule management infrastructure (not domain-specific rules, but the tooling for managing them)
**Author:** **Block, Inc.** (formerly Square — Jack Dorsey's company)
**Structure:** CLI tool written in Rust. Creates `ai-rules/` directory with markdown rule files. Generates CLAUDE.md, AGENTS.md, and agent-specific files. Supports nested directories.
**Cross-tool:** Supports **11 agents**: AMP, Claude Code, Cline, Codex, Copilot, Cursor, Firebender, Gemini, Goose, Kilocode, Roo
**Quality:** Official company project from a major tech company. Apache 2.0. **Best option for enterprise teams** needing to standardize AI rules across multiple tools.

### instructa/ai-prompts — ~1K ⭐
**URL:** https://github.com/instructa/ai-prompts
**Domains:** Full-stack web development prompts, project scaffolding, coding standards
**Author:** instructa.ai (regenrek, KerneggerTim)
**Structure:** `/prompts/` directory with subfolders per project type, each with `aiprompt.json`. README has instructions for each supported IDE.
**Cross-tool:** Cursor (.cursor/rules/), Copilot (.github/copilot-instructions.md), Windsurf (.windsurfrules), Cline, and Zed
**Quality:** True multi-tool repo with companion website. One of the few repos that genuinely solves the "write once, use everywhere" problem.

### lifedever/claude-rules
**URL:** https://github.com/lifedever/claude-rules
**Domains:** Language-specific rules for TypeScript, JavaScript, Java, Kotlin, Swift, Python, HTML, CSS, Go, Rust. Framework rules for Vue, React.
**Structure:** Modular: `base/` (core.md, git.md), `languages/` (10 languages), `frameworks/` (Vue, React). Concatenate files to build custom configs.
**Cross-tool:** CLAUDE.md, Cursor (.cursorrules or .cursor/rules/*.mdc), Antigravity, GitHub Copilot
**Quality:** Standout for **quantified, actionable rules** (functions ≤30 lines, files ≤300 lines, nesting ≤3 levels, parameters ≤4). Includes "Bad" vs "Good" code comparisons. Has Claude plugin for auto-installation. One of the best-designed multi-language rule sets.

### obviousworks/agentic-coding-rulebook
**URL:** https://github.com/obviousworks/agentic-coding-rulebook
**Domains:** Security, performance, testing, accessibility. Includes production SaaS template.
**Structure:** `tool-specific/` (Windsurf, Cursor, Copilot, Claude Code), `specialized-rules/` (security, performance, testing, accessibility), `helpers/` (adaptation scripts). Includes universal AGENTS.md template.
**Cross-tool:** Windsurf, Cursor, GitHub Copilot, Claude Code
**Quality:** Built on AGENTS.md 2025 standard. Production-ready templates with phased implementation workflow.

---

## Security-focused repos address a critical gap

AI coding agents can generate insecure code by default. These repos act as guardrails, and their importance is growing after the Pillar Security "Rules File Backdoor" vulnerability disclosure.

### SecureCodeWarrior/ai-security-rules
**URL:** https://github.com/SecureCodeWarrior/ai-security-rules
**Domains:** Backend security, frontend security, mobile security, Python-specific security. Covers injection flaws, CSRF, weak auth flows, insecure deserialization, cryptography.
**Author:** **Secure Code Warrior** — major developer security training company with 600+ enterprise customers including DigitalOcean and Paysafe
**Cross-tool:** GitHub Copilot, Cursor, Windsurf, Cline, Roo, Aider
**Quality:** **Industry-first free security rulesets** from a recognized security company. Announced June 2025 via BusinessWire. Intentionally language/framework-agnostic for broad applicability. CEO Pieter Danhieux personally backed the initiative.

### matank001/cursor-security-rules — ~370 ⭐
**URL:** https://github.com/matank001/cursor-security-rules
**Domains:** Safe coding practices, sensitive operations control, AI agent risk reduction, secret protection, command injection prevention
**Author:** Matan Kotick and Amit Ziv (security researchers specializing in AI agents)
**Structure:** Rules stored in `.cursor/rules/` directory format
**Quality:** Addresses the critical gap that by default Cursor can expose secrets or run dangerous commands. These rules act as **guardrails against AI-generated security vulnerabilities**. Highly relevant post-Pillar Security disclosure.

---

## Domain-specific repos fill the specialist niches

### evanca/flutter-ai-rules — ~492 ⭐
**URL:** https://github.com/evanca/flutter-ai-rules
**Domains:** Flutter, Dart, Bloc, Freezed, Riverpod, Provider, Firebase, Mockito — the complete Flutter ecosystem
**Structure:** `rules/` with topic files (bloc.md, effective_dart.md), `combined/` with pre-curated sets kept under 6K chars (for Windsurf compatibility), `skills/` with SKILL.md files
**Cross-tool:** Cursor, Windsurf, and other AI-powered IDEs
**Quality:** **The most comprehensive Flutter-specific rules repo.** Non-opinionated, based strictly on official docs. Well-maintained.

### irahardianto/awesome-agv — ~104 ⭐
**URL:** https://github.com/irahardianto/awesome-agv
**Domains:** Security (Rugged Software Manifesto, authentication, authorization, input validation, cryptography), Architecture (SOLID, API design), Database (schema design, migrations, query performance), Testing, CI/CD (Docker, GitHub Actions, ArgoCD/Kubernetes, Helm), Observability, Accessibility (WCAG 2.1 AA), Error handling, Concurrency, Performance, Feature flags. Language idioms for Go, TypeScript, Vue, Flutter, Rust, Python.
**Structure:** Highly organized `.agents/` directory with rules/, skills/, and workflows/. Two-tier rule system (mandates always loaded; principles context-dependent). Interactive rule dependency graph. Dedicated documentation site and npx installer.
**Quality:** **Exceptional depth and engineering rigor.** Based on the Rugged Software Manifesto. One of the most comprehensive rule suites found — covers security, architecture, databases, testing, CI/CD, observability, and accessibility in a single modular system. Originally designed for Google Antigravity but portable to any AI tool.

### fidalgok/explorer-ai-rules
**URL:** https://github.com/fidalgok/explorer-ai-rules
**Domains:** Cloudflare (Workers, Pages, D1, KV, R2), Convex, Firebase, Netlify, React Router v7, shadcn, Tailwind, security best practices
**Structure:** `rules/project-tech/` with technology-specific subdirectories + `rules/user/` for personal preferences. Designed as **git submodule** for sharing across projects.
**Quality:** Practical real-world collection with innovative submodule-based sharing approach. **Best available Cloudflare Workers-specific rules.**

---

## Claude Code skills collections beyond the official repo

### alirezarezvani/claude-skills
**URL:** https://github.com/alirezarezvani/claude-skills
**Domains:** Engineering, marketing, product, compliance, C-level advisory — 9 domains, 223 skills, 298 Python tools, 416 reference guides, 23 agents, 22 commands
**Structure:** Modular skill packages with SKILL.md + optional scripts/, references/, assets/. All **332 Python CLI tools are stdlib-only** (zero pip installs).
**Cross-tool:** Works with 11 tools (Claude Code, Codex, Gemini CLI, Cursor, Aider, Windsurf, etc.) via `./scripts/convert.sh`
**Quality:** Impressive scope. Publishes to ClawHub registry. The stdlib-only constraint is a strong engineering decision.

### ComposioHQ/awesome-claude-skills
**URL:** https://github.com/ComposioHQ/awesome-claude-skills
**Domains:** Document handling, dev tools, data analysis, security, testing
**Author:** Composio (company) — features the Connect skill for integrating Claude with 1000+ apps
**Quality:** Company-backed curated list with both community and official skills.

### Aider-AI/conventions — ~189 ⭐
**URL:** https://github.com/Aider-AI/conventions
**Domains:** Community-contributed convention files for various coding styles and practices
**Author:** Aider AI (official)
**Structure:** Markdown convention files specifying coding guidelines (naming, style, testing, patterns)
**Quality:** Official community repository. Convention files are markdown docs that guide aider's coding behavior. Updated June 2025.

---

## Tool-specific community repos round out the ecosystem

### cline/prompts (Official Cline)
**URL:** https://github.com/cline/prompts
**Domains:** Community-contributed .clinerules and workflows
**Author:** Cline (official)
**Structure:** `.clinerules/` directory with markdown rule files (kebab-case naming), `workflows/` for step-by-step guides. Files browsable directly from Cline extension's Prompts Library.
**Quality:** Official community-driven collection. Rules can be applied directly from the Cline VS Code extension.

### sanjeed5/awesome-cursor-rules-mdc
**URL:** https://github.com/sanjeed5/awesome-cursor-rules-mdc
**Domains:** 879 converted .mdc files from the PatrickJS collection, covering all frameworks/languages
**Structure:** Automated conversion of `.cursorrules` → `.mdc` format with generation scripts and CLI tool
**Quality:** **Bridges the gap** between old `.cursorrules` format and modern `.cursor/rules/*.mdc` directory format. Uses Exa for semantic search and Gemini for content generation.

### bmadcode/BMAD-METHOD
**URL:** https://github.com/bmadcode/BMAD-METHOD
**Also:** https://github.com/bmadcode/cursor-auto-rules-agile-workflow
**Domains:** Automated rule generation, custom agent creation, agile workflow methodology
**Author:** Brian Madison (BMad) — notable Cursor educator with active YouTube channel
**Structure:** `.cursor/rules/` with numbered MDC files. `modes.json` for custom agents. Shell scripts for rule application.
**Quality:** Pioneered the "auto-generate rules" approach. Evolved from Cursor-specific into a tool-agnostic methodology. Very influential in the Cursor community.

### Bhartendu-Kumar/rules_template
**URL:** https://github.com/Bhartendu-Kumar/rules_template
**Domains:** Framework-agnostic memory/context persistence, reasoning, best practices enforcement
**Cross-tool:** CLINE, RooCode, Cursor, Windsurf
**Structure:** Three core files per environment: rules, plan, implement, debug. Five-phased workflow.
**Quality:** Unique approach combining memory, reasoning, and software engineering fundamentals. Common memory bank across AI assistants. Auto-updates documentation after each phase.

### abhishekray07/claude-md-templates — ~80 ⭐
**URL:** https://github.com/abhishekray07/claude-md-templates
**Domains:** CLAUDE.md templates for Next.js/TypeScript, Python/FastAPI, generic projects
**Structure:** `global/CLAUDE.md`, `project/nextjs-typescript.md`, `project/python-fastapi.md`, `local/local.md` + `principles.md` + `cheatsheet.md`
**Quality:** Extremely practical. Documents the **~150-200 instruction limit** (with ~50 already used by system prompt). References Boris Cherny's workflow, HumanLayer's 60-line benchmark. **Best starting point for teams writing their first CLAUDE.md.**

### mbeijen/andrej-karpathy-skills-cursor-vscode — ~161 ⭐
**URL:** https://github.com/mbeijen/andrej-karpathy-skills-cursor-vscode
**Domains:** VS Code/Cursor extension wrapping Karpathy's AI coding guidelines
**Quality:** One-click installation of the Karpathy rules. Practical bridge between a single CLAUDE.md and the VS Code/Cursor extension ecosystem.

### botingw/rulebook-ai
**URL:** https://github.com/botingw/rulebook-ai
**Domains:** "Packs" for specific roles (Product Manager, DevOps) or technologies (React, AWS, Data Science)
**Cross-tool:** Supports **10 assistants**: Cursor, Windsurf, Cline, RooCode, Kilo Code, Warp, GitHub Copilot, Claude Code, Codex CLI, Gemini CLI
**Quality:** Novel approach treating AI's operational context as a portable "Environment" (Rules + Context + Tools). Versionable, shareable Packs. Discord community.

---

## Structural patterns and what works best

Across all 40 repos, five distinct structural patterns emerge:

- **Flat single file** (steipete/agent-rules, grapeot/devin.cursorrules, forrestchang/andrej-karpathy-skills): A single CLAUDE.md, .cursorrules, or AGENTS.md. Works for individual developers. Simplest to maintain but doesn't scale to teams or complex projects.

- **Folder-per-skill with SKILL.md** (anthropics/skills, obra/superpowers, alirezarezvani/claude-skills): Each capability is self-contained with instructions, scripts, references, and assets. The dominant pattern for Claude Code. Enables dynamic loading — skills activate only when relevant.

- **Modular concatenation** (lifedever/claude-rules, fidalgok/explorer-ai-rules): Separate files per language/framework that get assembled into a single output. Best for teams working across multiple tech stacks who want to compose rules from building blocks.

- **Hierarchical rules with priority** (irahardianto/awesome-agv, sparesparrow/cursor-rules): Two-tier systems where "mandates" always load and "principles" load contextually. Each rule has metadata (globs, priority, dependencies). Most sophisticated pattern — ideal for large codebases.

- **Progressive disclosure** (abhishekray07/claude-md-templates, Bhartendu-Kumar/rules_template): Minimal top-level file that references detailed docs with conditional triggers. Respects the **~150-200 instruction token budget** that Claude Code operates within.

## Conclusion

The most striking finding is the rapid convergence happening in early 2026. **AGENTS.md is becoming the universal standard**, backed by the Linux Foundation and supported by essentially every major AI coding tool. The smartest repos — block/ai-rules, obra/superpowers, agentsmd/agents.md — are already tool-agnostic, generating output for 10+ agents from a single source of truth.

Three quality signals reliably distinguish genuine engineering value from bulk-generated collections. First, **quantified rules** ("functions ≤30 lines") consistently outperform vague guidance ("keep functions small"). Second, repos backed by real practitioners — steipete, obra, PatrickJS, Block — show patterns refined through actual daily use rather than theoretical ideals. Third, the best repos use **progressive disclosure** rather than dumping hundreds of instructions, respecting the documented ~150-200 instruction budget that agents actually process.

The biggest coverage gaps remain in **GDPR/privacy-specific rules, SEO configurations, Stripe/payment integration guardrails, PostgreSQL/Kafka-specific rules, and monorepo governance** — these exist mainly as individual project configs rather than curated, shareable collections. That represents a significant opportunity for the community.