# The definitive distributed systems skill file resource guide

**Every open source resource, tool, failure pattern, and hard-won lesson needed to build the most comprehensive AI coding agent configuration for distributed systems engineering.** This report synthesizes findings from Jepsen analyses, 200+ production postmortems, AI agent configuration repositories, static analysis toolchains, and deep technical analyses of PostgreSQL, Kafka, Redis, and MongoDB failure modes. The goal: arm AI coding agents with the institutional knowledge that prevents distributed systems disasters.

## AI coding agent configuration files with distributed systems rules

The ecosystem of CLAUDE.md, .cursorrules, and SKILL.md files containing distributed systems patterns is maturing rapidly, though no single file yet covers everything needed. The most valuable finds span several repositories.

**The single best agent definition** is `rohitg00/awesome-claude-code-toolkit`'s `microservices-architect.md` (893 stars). This 74-line file covers all seven core patterns: transactional outbox with Debezium CDC, saga pattern (both choreography for 2–3 services and orchestration via Temporal/Step Functions with explicit compensation chains), CQRS for divergent read/write patterns, event sourcing with complexity warnings, circuit breakers with exponential backoff, idempotent consumers with event ID deduplication windows, and bulkhead isolation. It includes a concrete saga example: `OrderSaga: CreateOrder → ReserveInventory → ProcessPayment → ConfirmOrder` with compensation actions for each step.

**The most comprehensive single .cursorrules file** is `tonynguyennvt/cursor-rules-awesome` at **4,800+ lines across 72 sections**. Part VIII covers event-driven architecture, event sourcing, CQRS, service mesh patterns (Istio, Linkerd), and gRPC/Protocol Buffers. Part VII addresses chaos engineering and SRE practices. Part III handles distributed tracing and message queue async processing.

Other high-value repositories include `ruvnet/ruflo` (enterprise CLAUDE.md wiki pages covering service mesh, API gateway, CQRS, saga, database sharding, consistent hashing, and mTLS), `VoltAgent/awesome-claude-code-subagents` (7,400 stars, DDD-driven microservices architect agent), and `jt828/go-grpc-template` (Go gRPC template with working circuit breaker, idempotency, retry, and Snowflake distributed ID packages).

For SKILL.md files, `alirezarezvani/claude-skills` leads with **220+ skills** including Senior Data Engineer (Kafka pipelines) and AWS Solution Architect (distributed patterns). `Aaronontheweb/dotnet-skills` provides production-grade distributed actor system skills with Akka.NET. The official `anthropics/skills` repository defines the canonical SKILL.md format using YAML frontmatter.

The major collection repositories are `PatrickJS/awesome-cursorrules` (the definitive community collection), `sanjeed5/awesome-cursor-rules-mdc` (auto-generated MDC rules), and `s-smits/agentic-cursorrules` (domain-boundary management for multi-agent workflows). A notable finding: cursor rules files are cross-compatible — a single file can be renamed to work across .cursorrules, CLAUDE.md, .windsurfrules, and .clinerules formats.

**Critical gap**: No CLAUDE.md or SKILL.md file exists that serves as a comprehensive distributed systems reference covering all seven patterns plus database-specific gotchas, Kafka failure modes, and production postmortem lessons. This represents the primary opportunity.

## Jepsen found critical bugs in every system tested

Kyle Kingsbury's Jepsen project has tested all four databases and found serious correctness violations in each. PostgreSQL emerged as the safest, but none is exempt from bugs.

**PostgreSQL** had a serializability violation in its SSI (Serializable Snapshot Isolation) implementation that went **undetected for 9 years** (versions 9.1 through 13). Concurrent inserts and updates could produce G2-item anomalies — transactions that mutually failed to observe each other's writes under serializable isolation, on a single node, with no faults injected. The root cause was a conflict detection mechanism that incorrectly identified an updating transaction's XID as responsible for both original and updated tuple versions. Fixed in August 2020. Separately, Amazon RDS for PostgreSQL multi-AZ clusters were found in 2025 to **violate snapshot isolation** by allowing Long Fork anomalies in healthy clusters across versions 13.15 through 17.4, caused by differing transaction visibility ordering between primary (in-memory lock) and secondaries (WAL order).

**Redis-Raft** yielded **21 issues** in development builds, including total data loss on any failover (newly elected leaders came online with completely fresh state), infinite loops on any write request in follower-proxy mode, and split-brain from a bug that allowed leaders to independently remove all other nodes during network partitions. Stale reads occurred in healthy clusters because leaders failed to issue the required Raft no-op operation upon election. Twenty of 21 issues were subsequently fixed. Standard Redis replication (Sentinel, Cluster) explicitly documents that acknowledged writes can be lost during failover — this is by design, not a bug.

**Kafka's transaction protocol** has a fundamental design flaw (KAFKA-17754) discovered through Jepsen testing of Bufstream and Redpanda. Committed transactions can vanish, aborted transactions can commit, and transactions can be partially committed — some effects preserved, others lost. The root cause: the protocol assumes ordered, reliable delivery where none exists. Messages sent over different TCP connections to different nodes with automatic retries mean a delayed commit/abort message can affect a different, later transaction. **This affects all Kafka-compatible systems.** KIP-890 ("Transactions Server-Side Defense") is the planned fix, opened November 2022 and still in progress. Additionally, Kafka exhibited G0 (dirty write) cycles at both `read_uncommitted` and `read_committed` isolation levels during normal operation.

**MongoDB** is the most extensively criticized. Default settings (`w:1` write concern) mean **MongoDB may lose data by default** — the Jepsen 3.6.4 analysis showed 543 out of 6,095 acknowledged writes lost with journaled write concern on sharded clusters. At the strongest settings (read concern `snapshot`, write concern `majority`), MongoDB 4.2.6 still failed snapshot isolation, with approximately **10% of transactions exhibiting anomalies** including read skew, cyclic information flow, and duplicate writes. Transactions without explicit read concern silently downgrade to `local` (read uncommitted), even when the database-level setting is higher. MongoDB identified a bug (SERVER-48307) believed responsible and scheduled a patch for 4.2.8.

## The 20 most common distributed systems failure patterns

Analysis of 200+ production postmortems from danluu/post-mortems, academic research (Yuan et al., OSDI'14), and real incidents from Amazon, Google, Facebook, GitHub, Cloudflare, and others reveals consistent failure patterns. The most important meta-finding: **92% of catastrophic distributed system failures resulted from incorrect handling of non-fatal errors**, and **77% could have been reproduced by a unit test**.

**Cascading failures** remain the deadliest pattern. Amazon DynamoDB's September 2015 outage started with storage servers requesting partition assignments from a metadata service, creating a feedback loop when the metadata service slowed — a 4+ hour outage in US-East-1. Prevention requires circuit breakers, bulkhead isolation, load shedding, and capacity planning with headroom.

**Configuration errors** cause more production outages than code bugs. Facebook's October 2021 outage — 6+ hours affecting 2+ billion users — was caused by a maintenance command that accidentally disconnected all data centers, and the audit tool that should have prevented it had its own bug. Amazon S3's February 2017 outage was caused by a command typo that removed far more servers than intended.

**Retry storms and thundering herds** amplify failures. Without exponential backoff with jitter, 500 concurrent users with 3 retries each can generate 15,000+ failed calls during a 2-minute API outage, preventing recovery entirely. Discord documented thundering herds at recovery time causing frontend services to run out of memory.

**Metastable failures** — self-sustaining failure states that persist after the original trigger is removed — are the most dangerous variant. A traffic spike causes retries; retries generate load causing more retries; the system stays in this loop indefinitely, requiring manual intervention. Google SRE documented this pattern extensively.

Other critical patterns in order of frequency: incorrect error handling (35% caused by trivial bugs — empty handlers, TODO comments, overly broad catches), deployment failures, DNS failures (Facebook's BGP withdrawal made DNS unreachable), resource exhaustion (memory leaks, connection pools, disk), split brain (GitHub's October 2018 incident caused 24+ hours of degraded service), certificate expiration (Google Voice, Microsoft Teams, Equifax), data corruption from human error (GitLab's `rm -rf` on the primary database, Atlassian's script that deleted 400 customer sites over 8+ days), network partitions, clock skew, power/infrastructure failures, dependency failures (Cloudflare discovered hidden dependencies during a datacenter power outage), database failures (replication lag, schema issues, connection exhaustion), BGP misconfigurations, load balancer failures, and monitoring/alerting system failures.

## Static analysis and linting tools for distributed systems correctness

No turnkey "distributed systems linter" exists — enforcement requires composing multiple tools across the pipeline. Here is the complete toolchain for Go, TypeScript, and Rust ecosystems.

**Protocol Buffer and gRPC linting** is the most mature category. **Buf** (buf.build) provides 40+ lint rules and **53 breaking change rules** for wire/source compatibility, with custom check plugin support. **Google API Linter** enforces Google's API Improvement Proposals including AIP-155 for request ID/idempotency key fields — the closest thing to automated idempotency enforcement. **Protolint** adds pluggable linting without requiring protoc. **Confluent Schema Registry** and its open-source alternative **Karapace** enforce schema compatibility modes (BACKWARD, FORWARD, FULL and transitive variants) for Avro, Protobuf, and JSON Schema evolution in Kafka pipelines.

**Database migration safety** is well-served by **Squawk** (written in Rust, distributed via npm/pip/Docker), which statically analyzes SQL migration files to detect missing `CONCURRENTLY` on index creation, `NOT VALID` on constraints, unsafe column additions, and more. It integrates with GitHub Actions for PR-level feedback. **strong_migrations** (Rails) intercepts unsafe migrations at runtime. **pg-schema-diff** from Stripe generates safe migration plans.

**For Go**, `golangci-lint` aggregates 100+ linters including `errcheck` (unchecked errors on network/DB operations), `bodyclose` (unclosed HTTP response bodies causing connection leaks), `contextcheck` (non-inherited context), and `depguard` (architectural boundary enforcement). **go-ruleguard** enables custom pattern-based rules — teams write rules like "all HTTP client calls must use context with timeout" or "all database queries must check for replication lag."

**For TypeScript**, `dependency-cruiser` validates architectural boundaries in monorepos (preventing cross-service imports), detects circular dependencies, and enforces layer rules. `eslint-plugin-rxjs-x` catches critical reactive programming bugs: unhandled observables, nested subscriptions causing memory leaks, unsafe operator usage, and infinite loop patterns — essential for event-driven TypeScript services.

**For Rust**, Clippy's `await_holding_lock` lint catches the critical pattern of holding `std::sync::Mutex` across `.await` points (deadlock risk). `unused_async` detects unnecessary async overhead. **Tokio Console** provides runtime diagnostics impossible to detect at compile time: tasks blocking the runtime, self-waking tasks, and resource starvation. **Dylint** (Trail of Bits) enables custom lints via dynamic libraries.

**Semgrep** is the most flexible cross-language tool, supporting custom YAML rules across 30+ languages. Teams write rules to detect `sslmode=disable` in PostgreSQL connection strings, enforce logging library usage, catch missing `defer body.Close()` in Go, and flag hardcoded credentials. Trail of Bits published 115+ custom Semgrep rules. **Spectral** handles OpenAPI and AsyncAPI linting with custom rulesets.

The recommended CI pipeline composition:

- **Code linting**: golangci-lint (Go), ESLint + dependency-cruiser (TS), Clippy + Dylint (Rust), Semgrep (all)
- **Proto/API**: buf lint + Google API Linter, Spectral for OpenAPI
- **DB migrations**: Squawk for all PostgreSQL migrations
- **Schema evolution**: buf breaking + Schema Registry compatibility checks
- **Custom patterns**: go-ruleguard (Go), custom ESLint rules (TS), Dylint (Rust), Semgrep custom rules (all)

## Redlock is unsafe for correctness-critical locking

Martin Kleppmann's February 2016 blog post "How to do distributed locking" established the definitive technical case against Redis's Redlock algorithm. The core argument centers on **fencing tokens** — without monotonically increasing tokens that storage servers can use to reject stale writes, any auto-expiring lock is vulnerable to process pauses.

The canonical failure scenario: Client 1 acquires the lock, enters a GC pause, the lock expires, Client 2 acquires it and writes to the shared resource, Client 1 resumes believing it still holds the lock and overwrites Client 2's work. Fencing tokens solve this — ZooKeeper provides them naturally via `zxid`, etcd via `mod_revision`. Redlock cannot generate monotonic fencing tokens because doing so across independent Redis nodes would itself require a consensus algorithm.

Kleppmann's second argument targets Redlock's **timing assumptions**. Redlock assumes bounded network delay, bounded process pauses, and bounded clock drift — a synchronous system model. Redis uses `gettimeofday()` which can jump due to NTP adjustments. If a Redis node's clock jumps forward, keys expire prematurely, allowing two clients to simultaneously hold the lock. Consensus algorithms (Raft, Paxos) ensure safety holds regardless of timing; only liveness depends on timing assumptions. Redlock inverts this — timing failures compromise safety, the worse failure mode.

Antirez's counterarguments have technical merit in two areas. First, most real-world locked resources (external APIs, physical systems) cannot check fencing tokens, making the fencing argument impractical for those cases. Second, Redlock's algorithm does check elapsed time before and after acquiring the majority, detecting delays during acquisition. However, a GC pause after this check but before completing the protected operation remains undetectable.

**The current community consensus** (evidenced by Hacker News discussions through 2024, Redis's own documentation, and practitioner experience) is clear:

- **For efficiency locks** (preventing duplicate work, where failure means minor cost): Use a single Redis instance with `SET NX PX`. Simple, fast, well-understood limitations.
- **For correctness-critical locks** (where failure means data corruption): Use **etcd** (Raft-based, `mod_revision` as natural fencing token, native in Kubernetes), **ZooKeeper** (ZAB-based, `zxid` fencing, proven in production), or **PostgreSQL advisory locks** (no extra infrastructure, auto-release on disconnect, no clock drift issues — but single-primary only).
- **Redlock**: Acceptable only when you need better availability than a single Redis node, can tolerate rare safety violations, and operations are idempotent or recoverable.

Redis's own documentation now links to Kleppmann's analysis and states: "Redis is not using monotonic clock for TTL expiration mechanism. That means that a wall-clock shift may result in a lock being acquired by more than one process."

## Kafka failure modes demand specific operational knowledge

**Consumer group rebalancing storms** are Kafka's most operationally disruptive failure. A NashTech case study documented a **45-minute complete processing outage** when deploying 100 consumer instances — rolling deployment triggered cascading rebalances that prevented any wave from stabilizing. The fix requires three changes: use **CooperativeStickyAssignor** (default in Kafka 3.0+, which revokes only reassigned partitions), enable **static group membership** via `group.instance.id` (consumers rejoin silently without full rebalance), and tune `max.poll.interval.ms` to exceed worst-case processing time with reduced `max.poll.records`.

**Partition skew** creates bottlenecks that horizontal scaling cannot fix. New Relic discovered the top **1.5% of queries accounted for 90% of events**, creating severe hot partitions. Solutions include key salting (`entity_id + random_suffix`), custom partitioners for known hot keys, and monitoring the partition coefficient of variation (alert when stddev/avg > 0.5).

**Exactly-once semantics are limited to Kafka-to-Kafka pipelines only.** If consumers write to external databases, send notifications, or call APIs, Kafka cannot revert those side effects. Applications must implement their own idempotency. Performance overhead includes a few to tens of milliseconds per transaction commit, approximately 19 extra bytes per record batch, and the constraint that each producer supports only one active transaction. Critically, the Jepsen-discovered transaction protocol flaw (KAFKA-17754) means even Kafka-to-Kafka EOS may not hold under network disruptions — KIP-890 remains incomplete.

**Schema evolution pitfalls** differ between Avro and Protobuf. Avro identifies fields by name and requires both reader and writer schemas for deserialization, making Schema Registry essentially mandatory. Protobuf identifies fields by numeric tag and is self-describing. The default BACKWARD compatibility mode is correct for Kafka because it guarantees consumers can rewind to topic beginning. Common breaking changes in Avro: removing fields without defaults, type changes, and enum symbol removal. In Protobuf: changing field numbers, reusing reserved numbers, and incompatible type changes.

**The most dangerous configuration pitfalls**: `acks=1` (was default pre-3.0) acknowledges only on leader — leader crash before replication means data loss. `enable.auto.commit=true` (default) commits offsets before processing completes. `min.insync.replicas=1` (default) with `acks=all` still waits only for the leader. `unclean.leader.election.enable=true` allows out-of-sync replicas to become leader with data loss.

**Idempotent producer edge cases** include: restart without `transactional.id` gets a new PID (losing deduplication state), `UNKNOWN_PRODUCER_ID` after log retention deletes segments containing producer state, and a documented librdkafka bug (#3584) where cluster failover caused permanent "out of order sequence number" fatal errors.

**ISR shrinkage** creates the "Last Replica Standing" problem (KIP-966): when ISR shrinks to just the leader and the leader crashes with unflushed data, that data is permanently lost and all followers must truncate to match. KIP-966 introduces Eligible Leader Replicas as a fix. A separate JIRA (KAFKA-5633) shows that with `unclean.leader.election.enable=false`, a single node's network issues can cause a permanently leaderless partition.

## PostgreSQL's most dangerous failure modes are preventable

**XID wraparound** is PostgreSQL's most catastrophic failure mode. The database uses 32-bit transaction IDs with ~2 billion usable values. When VACUUM fails to freeze old tuples before the counter wraps, committed data becomes invisible — effectively data loss despite data physically existing on disk. At 1 million XIDs remaining, PostgreSQL **refuses all write transactions**. Sentry experienced this requiring ~3 hours of downtime and table truncation; Mailchimp/Mandrill suffered **~40 hours of outage**. Monitor with: `SELECT datname, age(datfrozenxid), ROUND(age(datfrozenxid)::numeric / 2147483647 * 100, 2) AS pct_to_wraparound FROM pg_database`. Alert at 50% towards wraparound, critical at 75%.

**VACUUM failure** is the root cause of both bloat and XID wraparound. A single idle-in-transaction connection can prevent VACUUM from reclaiming anything on busy tables. Default `autovacuum_vacuum_scale_factor = 0.2` means a 1-billion-row table must accumulate 200 million dead tuples before triggering — use **0.02 or lower** for large tables. Inactive replication slots retain WAL indefinitely and can block vacuum on the primary while simultaneously filling disk. **pg_repack** handles online table rebuilding without ACCESS EXCLUSIVE lock during processing. Never run VACUUM FULL on production.

**Migration locking** has a hidden killer: the lock queue. Even if an ALTER TABLE is instant, if it waits for its ACCESS EXCLUSIVE lock, **all subsequent queries queue behind it**, creating a cascading outage. The safe pattern for any migration: `SET lock_timeout = '1s'` (fail fast), add foreign keys with `NOT VALID` then validate separately, always use `CREATE INDEX CONCURRENTLY`, and add NOT NULL constraints via validated CHECK constraints first (PostgreSQL 12+ trusts these). **Squawk** catches these patterns automatically in CI. GoCardless documented a 15-second API outage from a foreign key migration that locked both child and parent tables while a long-running SELECT was active.

**Connection pool exhaustion** hits because PostgreSQL forks a new OS process per connection (5–10 MB each). **PgBouncer in transaction mode** is the correct default — ~75% faster than Pgpool-II in benchmarks, using ~2KB per connection versus Pgpool-II's much higher overhead. The critical gotcha: transaction pooling breaks session-level state including `SET` commands, prepared statements, session advisory locks, `LISTEN/NOTIFY`, and temporary tables. Monitor `cl_waiting > 0` while `sv_idle = 0` as the signal for pool exhaustion.

**Advisory locks** have a dangerous interaction with connection pooling: session-level `pg_advisory_lock` persists when PgBouncer returns the connection to the pool, meaning another client receives a connection with someone else's lock still held. Always use `pg_advisory_xact_lock` (transaction-scoped, auto-releases) with connection poolers. Additional gotcha: `SELECT pg_advisory_lock(id) FROM tasks LIMIT 10` may lock more rows than returned because the planner may acquire locks before applying LIMIT.

**Deadlocks** most commonly arise from row-level lock inversion (two transactions updating the same rows in different orders) and bulk upserts with random row ordering. The fix: sort rows by primary key before bulk `INSERT ... ON CONFLICT DO UPDATE`, access resources in consistent order across all code paths, and use `FOR UPDATE SKIP LOCKED` for queue-like patterns.

**Logical replication** does not replicate DDL, sequences, or large objects. Schema changes must be manually coordinated between publisher and subscriber. After failover, sequences may produce duplicates. Tables require PRIMARY KEY or REPLICA IDENTITY for UPDATE/DELETE replication. Replication slots before PostgreSQL 17 don't survive failover and don't persist through version upgrades.

## Conclusion

Three insights emerge from synthesizing these seven research areas that are rarely discussed together.

First, **the gap between documented guarantees and actual behavior is enormous**. MongoDB's "full ACID" marketing masked ~10% transaction anomaly rates. Kafka's "exactly-once semantics" has a fundamental protocol flaw (KAFKA-17754) affecting all compatible systems. PostgreSQL's serializable isolation had a 9-year-old bug. Redis explicitly documents that acknowledged writes can be lost. AI coding agents must encode these real-world caveats, not documentation-level claims.

Second, **the most impactful safety improvements come from CI pipeline composition, not runtime patterns**. Squawk catching an unsafe `ALTER TABLE` before it reaches production prevents more outages than any circuit breaker library. Buf breaking-change detection prevents more data corruption than any retry strategy. Schema Registry compatibility checks prevent more Kafka incidents than consumer configuration tuning. The toolchain — buf + Squawk + Semgrep + golangci-lint + dependency-cruiser + Clippy — is the first line of defense.

Third, **the missing piece is not more patterns but more institutional memory**. The 92% statistic from OSDI'14 — that catastrophic failures result from incorrect error handling, and 77% could be caught by unit tests — means the highest-value AI agent instruction is not "implement the saga pattern" but "never write an empty catch block, never ignore a returned error, and always test the error path." The most valuable distributed systems skill file would encode not just patterns but the specific failure modes, Jepsen findings, and postmortem lessons documented here, making them available at the point of code generation.