# Designing Actium's onboarding from five best-in-class products

**The fastest path to user activation in a multi-product AI platform is a 4-step wizard that collects only intent and role, pre-populates a working environment with sample data, and defers everything else to contextual progressive disclosure.** This conclusion emerges from a systematic teardown of Linear, Notion, HubSpot, Slack, and Attio — five products that collectively represent the state of the art in SaaS onboarding, empty states, progressive disclosure, and settings architecture. The patterns that win are strikingly consistent: collect less, show more, and let the product teach itself through opinionated defaults and contextual guidance rather than front-loaded tutorials.

---

## Section 1: How five products get users to value in under two minutes

### Linear: 7 steps in 60 seconds with zero configuration questions

Linear's onboarding is the gold standard for developer tools. The flow is a **full-screen dark wizard** with one input per screen: welcome → theme selection (light/dark) → team name → import source (GitHub/Jira/skip) → invite teammates (skippable) → notification setup (Slack/email/skip) → first issue creation. Linear collects **no role, no use case, no company size, no department** — a dramatic departure from competitors like Jira's 15+ configuration screens.

The critical design decision is **pre-populated sample data**. New workspaces arrive with sample projects ("Mobile App," "API"), issues scoped to hours, and cycles showing a two-week rhythm. Users learn by deleting and replacing rather than building from scratch. This "behavioral training" approach teaches best practices through example rather than instruction. Team invitations appear as a dedicated step but are entirely skippable. The visual design uses smooth transitions between steps with no progress indicators — the brevity makes progress bars unnecessary.

### Notion: The three-question gateway that eliminates blank-page paralysis

Notion reaches workspace in **4 steps for personal use, 6-7 for teams**. The pivotal screen is the "What will you use Notion for?" question — users select from options like project planning, notes, or habit tracking, and the workspace **dynamically populates with curated templates** matching those selections. A real-time preview panel on the right updates as users make choices, showing how selections shape their workspace before they commit.

For team accounts, Notion adds role and company size collection, workspace naming, and teammate invitations with a domain-matching toggle ("allow anyone with your company domain to join"). The Getting Started page is itself a Notion page — an interactive checklist teaching slash commands, page creation, and styling through hands-on practice. This "learn the product by using the product" approach is Notion's signature move.

### HubSpot: 22 flows, one checklist, and mandatory onboarding at scale

HubSpot maintains **22 distinct signup flows** serving ~200,000 new accounts monthly, personalized by entry point (Marketing Hub, Sales Hub, Academy, etc.). The typical flow spans 5-7 screens collecting name, email, company name, domain, industry, company size, and role — significantly more data than Linear or Notion.

The real onboarding begins post-signup via a **persistent setup checklist** with assignable tasks, due dates, and completion tracking. Each Hub has its own checklist: Marketing focuses on email configuration and social connections; Sales emphasizes pipeline setup and meeting links. At Professional and Enterprise tiers, HubSpot **requires mandatory onboarding** (either through HubSpot's service or a certified partner), reflecting the product's complexity. Sample contacts demonstrate record formatting, but the CRM otherwise starts empty.

### Slack: Dynamic preview builds the workspace as you watch

Slack achieves first message in **4-5 steps**. The standout pattern is a **split-screen wizard** where the right panel shows a live wireframe of the workspace being assembled as users fill in the left panel's forms. When you type your team name, it appears in the mock sidebar. When you name your first project, it becomes a channel. Confetti animations celebrate milestones. This real-time preview transforms form-filling into workspace-building.

Slack creates two default channels (#general and the user-named project channel), then Slackbot takes over as an in-product onboarding agent — teaching messaging, channels, and reactions through actual Slack conversations. **Password creation is deferred** entirely; users authenticate via a confirmation code and must set a password later. Invited members get an even shorter flow — they enter an already-furnished workspace and learn through Slackbot rather than a wizard.

### Attio: Email sync as instant value creation

Attio's **5-step onboarding** makes a bold move: it blocks personal email addresses entirely, requiring work email to enforce the B2B use case. The critical differentiator is **email and calendar sync during onboarding** (step 3). When users connect Google or Microsoft accounts, Attio automatically populates the CRM with People and Company records extracted from communication history, enriched with job titles, social profiles, and funding data. Users finish onboarding with a **pre-populated CRM** rather than an empty database.

Template selection (step 4) offers dozens of options across sales, recruiting, and marketing, each pre-loaded with illustrative dummy data. A floating **6-item Getting Started checklist** appears after landing in the workspace — non-blocking, minimizable, and exploreable at the user's pace. Attio's strategy is to **prevent empty states from ever occurring** rather than designing around them.

### Comparative summary

| Product | Steps | Time | Info collected | Sample data | Visual pattern |
|---------|-------|------|----------------|-------------|----------------|
| Linear | 7 | ~60s | Team name, theme | Yes — demo projects/issues | Dark full-screen wizard |
| Notion | 4-7 | ~50-60s | Use case, role (teams) | Yes — personalized templates | Split-screen with preview |
| HubSpot | 5-7 | ~2-3min | Company, industry, size, role | Minimal samples | Full-screen → checklist |
| Slack | 4-5 | ~90s | Team name, project name | Default channels + Slackbot | Split-screen dynamic preview |
| Attio | 5 | ~2min | Work email, use case, sync | Auto-populated via email sync | Full-screen → floating checklist |

---

## Section 2: Empty states as strategic onboarding moments

### Linear's single-CTA discipline

Every Linear empty state follows one rigid pattern: **subtle animation drawing the eye + single explanation of what belongs there + one primary CTA**. No secondary options, no "learn more" links, no elaborate illustrations. The Projects empty state is one of the few exceptions, offering both "New issue" and "New document" buttons because Projects support both content types. NicelyDone catalogs **19 distinct empty state screens** in Linear, all maintaining this consistency.

The illustration style is minimal — no cartoon characters or elaborate art. Instead, Linear uses micro-animations: a gentle pulse on the "Create issue" button, icons rotating slowly into view. The copy tone is concise, professional, and action-oriented, matching the developer audience. Empty states do not vary by role or plan.

### Notion's approach: prevent emptiness entirely

Notion's primary empty state strategy is **avoidance** — the three-question onboarding gateway ensures workspaces are pre-populated. The famous blank page with "Type '/' for commands" ghost text is both Notion's brand identity and its biggest UX challenge. When databases are empty, Notion shows clean, minimal messaging with a single "+ New" button. No heavy illustrations — the minimalist aesthetic relies on typography and whitespace.

Sidebar sections are intelligent: **empty sections don't appear**. Teamspaces only show when there are multiple members; Shared only appears when content is shared; Favorites appears after the first page is favorited. This conditional visibility is a form of progressive disclosure applied to navigation itself.

### HubSpot's illustration library sets the industry standard

HubSpot maintains a **formalized EmptyState component** in their design system with **36+ named illustrations** — `contacts`, `deals`, `emptyStateCharts`, `lock` (for feature-gated areas), `missedGoal`, `task`, and more. The style is flat, warm, and brand-consistent using oranges, blues, and teals. Each empty state follows a structure of illustration + title explaining why it's empty + optional description + optional CTA button.

The design guidelines are explicit: make empty states informative (so users understand what will appear when populated), make them actionable (explain benefits and how to add content), and don't make them too long. Feature-gated areas use the **`lock` illustration with upgrade prompts** rather than empty state patterns — a clean distinction between "nothing here yet" and "you need to upgrade."

### Slack turns empty states into personality moments

Slack's empty states are the most personality-driven of the five products. Empty channels show a purpose description and member list with the composer ready for input. The DM empty state suggests messaging yourself — a low-barrier first action that familiarizes users with the interface. The drafts empty state follows a structured pattern: header describing page purpose, body explaining what will appear, and a single CTA to create a draft.

The illustration style is flat, playful, and colorful with friendly characters. Copy is conversational and warm — it never blames the user and always tells them what to **do**, not just what's missing. Slack celebrates cleared states too: completing all tasks triggers celebratory emoji and animations.

### Attio's auto-sync strategy makes empty states irrelevant

Attio's approach is the most aggressive at **eliminating empty states entirely**. Between email/calendar sync (auto-populating contacts and companies) and template dummy data, most views have content from first load. When empty states do appear, they match the minimalist Notion-inspired aesthetic — no heavy illustrations, no mascots, just functional copy with multiple CTAs (import data, sync email, use template, create manually). The design philosophy prioritizes prevention over decoration.

### Cross-product empty state patterns

| Dimension | Linear | Notion | HubSpot | Slack | Attio |
|-----------|--------|--------|---------|-------|-------|
| Illustration style | Micro-animations, no art | Minimal, typography-led | 36+ flat brand illustrations | Playful characters | None — prevention strategy |
| Copy tone | Concise, professional | Functional, minimal | Informative, instructive | Conversational, warm | Functional, direct |
| CTA pattern | Single action only | Single "+ New" button | Illustration + title + CTA | Action-oriented guidance | Multiple options |
| Role/plan variation | Minimal | Plan-gated visibility | Lock icon for gated features | Minimal | Plan-gated objects |

---

## Section 3: Progressive disclosure across product complexity

### Linear's radical anti-onboarding philosophy

Linear uses **no product tours, no tooltip sequences, no onboarding checklists, no gamification**. Instead, it relies on four mechanisms. First, **opinionated defaults** — workflow statuses (Triage → Backlog → In Progress → Done) are pre-configured so users start working immediately. Second, the **command bar (Cmd+K)** serves as the primary discovery mechanism, showing contextually relevant commands based on the current view. Third, **keyboard shortcuts appear on hover** over any element, creating implicit learning without interruption. Fourth, **per-team feature toggles** let teams opt into advanced features (Cycles, Triage, custom Workflows) when ready rather than being overwhelmed upfront.

This approach works because Linear's target audience — developers — prefer discovery through interaction over guided tours. The constraint-based design enforces best practices: issues must have owners, projects require leads, cycles have fixed timeframes. The product itself teaches methodology.

### Notion's template-as-tutorial strategy

Templates are Notion's **entire progressive disclosure mechanism**. The initial curated set (~5 templates) teaches basic concepts. The full template library (30,000+ community templates) functions as an app store of workflows. Each template is a mini-tutorial: a project management template teaches databases, relations, and views by example. Users learn Kanban boards by using a pre-built one rather than reading about the concept.

The slash command system provides a second layer of disclosure — basic users type text, while power users discover 50+ block types through the "/" menu. Advanced features like automations, database relations, and AI appear contextually when relevant, not in upfront tutorials. NNGroup research confirms this approach: **tutorials don't make users faster or more successful** at completing tasks, while contextual guidance does.

### HubSpot's checklist-driven complexity management

HubSpot manages its enormous feature surface through **structured checklists and feature gating**. The setup checklist breaks Hub-specific configuration into assignable, trackable tasks with estimated completion times. HubSpot Academy is deeply integrated — "Recommended learning" widgets appear on the dashboard, and certification courses provide structured paths for feature mastery.

The tiering model creates natural progressive disclosure: Free users see a basic CRM, Starter adds automation, Professional unlocks workflows and advanced reporting, Enterprise reveals custom objects and predictive analytics. **Lock icons and upgrade prompts** mark gated features clearly. A global search bar searches across all assets, tools, learning resources, and settings — critical for a product with hundreds of features.

### Slack's conversational onboarding agent

Slackbot is Slack's primary progressive disclosure tool — it teaches users how to use Slack **by using Slack**. After the initial wizard covers messaging basics, advanced features (Workflows, Canvases, Huddles, integrations) are deliberately excluded from onboarding and discovered through sidebar navigation, contextual prompts during conversations, and empty states with templates.

Slack's evolution is instructive: in 2014, they used hotspot-style tooltips (low click rates); in 2016, they switched to sequential tooltips that defaulted to open (more prescriptive); today, they rely primarily on Slackbot conversations plus sparse, targeted tooltips. As of February 2026, Slackbot has been redesigned as a **full AI agent** capable of intelligent workspace search, document analysis, and calendar management.

### Attio's plan-gated object model

Attio gates complexity through its object model: Free plans get Companies + People + 1 additional object; Plus adds 3 more; Pro allows up to 12 including custom objects. This naturally limits what new users encounter. Contextual tooltips appear when using features for the first time, guiding step-by-step without requiring support. The Getting Started checklist is opt-in and non-blocking — users explore at their own pace.

Attio explicitly differentiates from HubSpot's prescriptive approach. Where HubSpot enforces process and control, Attio enables flow and agency. Even the terminology differs: "Pipeline automation" becomes "Workflows," "Reporting dashboards" become views/reports — signaling a fresh mental model that doesn't carry legacy CRM baggage.

---

## Section 4: Settings architecture that scales with complexity

### The dominant pattern: two-column sidebar navigation

All five products use a **left sidebar for settings navigation with content in the right panel** — the pattern that scores highest on scanning ease and scalability. The key architectural decision is how to separate personal, workspace, and admin settings.

**Linear** (redesigned December 2024) uses four sidebar sections: Account (personal), Features (workspace-level), Administration (admin-only), and Your Teams (per-team settings). Settings are full pages, not modals. Team settings are consolidated into summary cards showing enabled features, with click-through for detailed configuration. The December 2024 redesign also added a **customizable sidebar** where users can hide unused items behind a "More" menu.

**Notion** opens settings as a **full-screen modal overlay** — a departure from full-page navigation. The sidebar splits clearly between "Account" (personal: profile, notifications, connections, language) and "Workspace" (admin: general, members, teamspaces, billing, security). Enterprise adds an Organization-level admin console accessible via the workspace switcher. Plan-gated visibility naturally simplifies settings — Enterprise-only sections (Identity & Provisioning, Audit Log, DLP) simply don't appear on lower tiers.

**HubSpot** has the most complex settings architecture, organized into collapsible sidebar categories: Your Preferences (personal), Account Setup, Data Management, Tools (per-Hub), Integrations, and Advanced. A **search function** is essential given the breadth — HubSpot's settings span hundreds of configuration options. Clicking the settings gear from within a specific tool navigates directly to that tool's settings page, with a "Back to all settings" link for orientation.

**Slack** uniquely **splits settings across two interfaces**: personal preferences open as an in-app modal (accessed via profile picture), while workspace administration opens in a **separate web browser tab**. Enterprise Grid adds a third layer — an org-level admin dashboard. This separation is the least elegant of the five products, creating context-switching friction. However, Slack's preference philosophy is notable: "Preferences should empower advanced users, not grant basic functionality."

**Attio** cleanly separates Account Settings (personal, accessed from workspace name menu) from Workspace Settings (admin-only, same menu). The workspace settings sidebar covers Members and teams, Billing, Plans, Objects, Developers (API), Integrations, Credits, and SSO. The design matches the product's Notion-inspired minimalism — clean typography, generous whitespace, no visual clutter.

### How advanced settings are handled

Three patterns emerge for managing advanced-versus-basic settings:

**Role-based hiding** (Linear, Notion): Admin sections are entirely invisible to non-admin users. This is the cleanest approach — users never see settings they can't change.

**Plan-gated visibility** (Notion, Attio, HubSpot): Advanced settings only appear on appropriate plan tiers. Enterprise-only features like SSO, SCIM provisioning, and audit logs simply don't exist in the UI for lower tiers.

**Expandable advanced sections** (HubSpot, Slack): "Show advanced options" toggles within settings categories, collapsed by default. This preserves discoverability while keeping the default view clean.

---

## Section 5: The Actium onboarding design

### Design principles derived from the research

Three principles should govern Actium's onboarding. First, **collect intent, not demographics** — Linear and Notion prove that use-case selection drives more personalization value than company size or industry. Second, **pre-populate everything** — Linear's sample data, Notion's templates, and Attio's email sync all demonstrate that users who see a populated environment activate faster than those facing blank canvases. Third, **the product should teach itself** — contextual guidance consistently outperforms front-loaded tutorials across all five products studied.

### The 4-step onboarding wizard (target: under 3 minutes)

**Step 1: Account creation + role identification**

*Screen:* Full-screen, dark-themed (matching developer tool conventions). Centered card with SSO options (GitHub, Google) prominently displayed above email/password fields. Below authentication, a single question: "What's your role?"

*Options:* Developer · Product Manager · Technical Lead · Founder/CTO · Other

*Microcopy:* "We'll customize your workspace based on how you work."

*Design notes:* GitHub SSO should be the primary option — Actium targets technical teams. The role question serves double duty: personalizing the experience and enabling analytics segmentation. No company size, no industry, no "how did you hear about us."

**Step 2: Workspace naming + primary product selection**

*Screen:* Split-screen layout (inspired by Notion/Slack). Left panel: workspace name input field with placeholder "e.g., Acme Labs" and optional logo upload. Below that, the key question: "What do you want to build first?"

*Options displayed as product cards with icons and one-line descriptions:*
- **Actium.io CMS** — "Manage content for AI agents"
- **Actium.app Agent Builder** — "Build and deploy AI agents"  
- **Actium.studio Managed Agents** — "Monitor production agents"
- **Actium.chat LLM Interface** — "Chat with any model"

*Right panel:* Dynamic preview showing a wireframe of the selected product populating in real-time (Slack's proven pattern).

*Microcopy:* "Pick one to start — you can access everything anytime." The single-product focus prevents overwhelm in a multi-product suite while establishing immediate context.

**Step 3: Connect + populate**

*Screen:* Full-screen with a clean list of integration options, personalized based on role and product selection.

*For developers selecting Agent Builder:* "Connect your tools to get started faster" — GitHub repository connection, API key entry for preferred LLM provider (OpenAI/Anthropic/Google), optional Slack webhook.

*For those selecting CMS:* GitHub repo, existing CMS import (Contentful/Sanity/markdown files).

*For those selecting Chat:* LLM API key entry with a "Use Actium's hosted models" toggle for instant access.

*For all:* "Skip for now — we'll set up a sandbox environment" link at bottom.

*Microcopy:* "Connecting GitHub? We'll scan your repos for agent configs and import them automatically."

*Design notes:* This step mirrors Attio's email-sync strategy — connecting real data sources creates immediate value. For users who skip, the sandbox (next step) ensures they still see a populated environment.

**Step 4: Invite + land**

*Screen:* Teammate invitation via email with a "Share invite link" alternative. Role assignment (Admin/Member/Viewer) via simple dropdown. Domain-matching toggle: "Allow anyone with @company.com to join."

*Microcopy:* "AI agents are a team sport. Your teammates can start building in their own sandboxes."

*Skip link:* "I'll invite the team later →"

*After this step:* User lands in the selected product workspace with the Getting Started experience.

### The landing experience: populated workspace + contextual checklist

Upon landing, the user sees a **workspace pre-populated with a working sample relevant to their product selection**:

**Agent Builder (Actium.app):** A sample agent called "Customer Support Bot" is pre-deployed with a working conversation flow, connected to a mock knowledge base, and showing real metrics (latency, token usage, success rate). Three sample tools are connected. The agent is in "sandbox" mode — users can interact with it immediately.

**CMS (Actium.io):** A sample content structure with three populated entries — an agent system prompt, a knowledge base article, and a tool configuration. The content model shows relationships between entries. A preview pane demonstrates how content renders in the agent builder.

**Managed Agents (Actium.studio):** A dashboard showing three sample agents with status indicators (Active/Degraded/Stopped), performance charts with 7 days of synthetic data, and an alert log. Users can click into any agent to see the monitoring detail.

**Chat (Actium.chat):** A clean conversation interface (following Gemini's pattern) with a greeting — "Hello [name]. Ask me anything, or try one of these:" followed by 4 contextual prompt cards based on the user's role. For developers: "Explain how to build a RAG pipeline," "Compare GPT-4o vs Claude 3.5 for code generation," "Generate a Python function that…," "Analyze this error log."

**The floating checklist** (inspired by Attio) appears in the bottom-right corner with **5 items tailored to the selected product**:

*Agent Builder checklist:*
1. ✅ Create workspace *(auto-completed)*
2. → Explore the sample agent
3. → Create your first tool
4. → Test a conversation
5. → Invite a teammate

Each item expands on click to show a 2-sentence description and a "Start →" button that navigates to the relevant screen. The checklist is dismissible, minimizable, and persistent across sessions until completed.

### Empty state design direction

Actium's empty states should follow Linear's **single-explanation + single-CTA pattern** with one Actium-specific addition: an AI-powered suggestion.

*Pattern:*
- **Header:** What this space is for (e.g., "Tools connect your agents to external services")  
- **Subtext:** One sentence explaining the value (e.g., "Add API tools, database connectors, or custom functions your agents can call")
- **Primary CTA:** Single action button ("Create your first tool")
- **AI suggestion:** A subtle, differentiated element below the CTA: "💡 Actium can generate a starter tool from your API spec — paste an OpenAPI URL to try it"

*Visual style:* Minimal, no illustrations. Use subtle monochrome iconography consistent with developer tool aesthetics (Linear's approach). Dark theme as default with light option. The AI suggestion element uses a slightly different background color to distinguish it from standard empty state content without being intrusive.

*Copy tone:* Direct, technical, zero fluff. "No agents deployed yet" rather than "It's quiet in here!" The audience is developers — respect their time and intelligence.

*Empty states should never appear simultaneously.* If a user navigates to a dashboard where multiple panels would be empty, show the sample data instead and label it clearly: "Sample data — replace with your own" with a dismiss button.

### Progressive disclosure strategy post-onboarding

**Week 1: Core activation loop.** The floating checklist drives discovery of the primary product selected during onboarding. Contextual tooltips appear on first encounter with each major UI element — tooltip content is role-aware (developers see API-relevant tips; PMs see workflow tips). The command palette (Cmd+K) is introduced via a single, non-blocking tooltip on first workspace load: "Pro tip: Press ⌘K to find anything."

**Week 2-3: Cross-product discovery.** After completing 3+ checklist items in the primary product, a subtle notification badge appears on the sidebar icons for other Actium products. Clicking through shows a product-specific empty state with a "See it in action" button that loads a 30-second interactive demo (not a video — an actual sandboxed instance). This mirrors Linear's per-team feature toggles: products are visible but not forced.

**Week 4+: Power features.** Advanced features (custom workflows, webhook configurations, team permissions, API access) surface contextually when user behavior indicates readiness. If a user creates their 5th agent, a tooltip suggests agent templates. If they share an agent with a teammate, a tooltip introduces role-based access controls. **Never show advanced features in the first session.**

**Ongoing:** A "What's New" section in the command palette (Cmd+K → "What's new") aggregates feature updates with contextual explanations. No modal announcements, no forced tours. Following Slack's evolution, conversational AI assistance through Actium.chat can answer "How do I..." questions about any Actium product, replacing traditional help documentation with interactive guidance.

### Settings page structure recommendation

Actium should use a **two-column layout** with the following four-section sidebar, accessed via a dedicated settings page (not a modal — following Linear's pattern for complex multi-product settings):

**Section 1: Your Account**
Personal settings that follow the user across workspaces. Profile and authentication (name, email, avatar, SSO connections, 2FA). Appearance (dark/light/system theme, editor font, code theme). Notification preferences (per-product toggles: Agent alerts, CMS publish events, Chat mentions, Studio incidents — each with email/in-app/Slack channel options). API keys (personal access tokens with scoped permissions). Connected accounts (GitHub, LLM providers).

**Section 2: Workspace**
Shared settings affecting all members. General (workspace name, logo, default LLM provider, usage limits). Members and roles (invite, assign Admin/Member/Viewer, team creation on Pro+). Billing and usage (plan management, credit consumption dashboard, seat management). Integrations (workspace-level connections: Slack, GitHub org, CI/CD, monitoring).

**Section 3: Products**
Per-product configuration — this is the Actium-specific innovation. Each product gets a sub-section:
- **Actium.io CMS:** Content models, environments (staging/production), webhooks, publishing rules
- **Actium.app Builder:** Default agent settings, tool registry, sandbox configuration, deployment targets
- **Actium.studio Managed:** Alert thresholds, escalation rules, SLA definitions, incident channels
- **Actium.chat Interface:** Model defaults, system prompt templates, conversation retention, rate limits

This per-product grouping prevents the HubSpot problem of settings sprawl. Each sub-section starts with a summary card (Linear's December 2024 pattern) showing enabled features and key configuration at a glance.

**Section 4: Administration** *(Admin-only, hidden from non-admins)*
Security (SSO/SAML, IP allowlists, session management). Audit log. Data retention and export. Workspace danger zone (transfer/delete). Developer settings (OAuth apps, webhook signing keys, API rate limits).

**Search:** A search bar at the top of the settings sidebar filters across all sections. Given Actium's multi-product complexity, this is essential from day one — not a later addition.

**Advanced settings toggle:** Within each section, rarely-used options are collapsed under an "Advanced" expandable area. The default view shows only the 20% of settings that 80% of users need.

---

## Conclusion: What the best products agree on

The five products studied converge on a clear set of principles that should guide Actium's design. **Speed beats completeness** — Linear and Slack prove that collecting less during signup and deferring configuration produces faster activation than HubSpot's comprehensive approach. **Populated beats empty** — every product that pre-loads sample data or auto-syncs real data sees stronger engagement than those relying on empty states with CTAs. **Context beats curriculum** — NNGroup research and the evolution of all five products confirm that contextual, just-in-time guidance outperforms front-loaded tutorials and product tours.

For Actium specifically, the multi-product challenge demands one additional principle: **focus before breadth**. Forcing users to choose a primary product in step 2 of onboarding prevents the paralysis that multi-product suites create. The sample data for each product transforms abstract capabilities into tangible, interactive examples. And the progressive cross-product discovery in weeks 2-4 — surfacing other products only after the primary one is activated — ensures each product gets its own "aha moment" rather than competing for attention.

The target benchmarks: **under 3 minutes to first populated workspace**, **5 checklist items to activation**, and **cross-product discovery by day 14**. These are aggressive but achievable — Linear reaches value in 60 seconds, and Attio populates a full CRM in under 2 minutes. An AI platform with working sample agents and a command palette should be able to match that standard.