# Tool schemas and architecture of AI coding agents

**Claude Code, Codex CLI, and Aider each take fundamentally different approaches to file editing, sandboxing, and context management—and understanding their exact tool definitions is essential for building a competitive tool execution layer.** Claude Code uses ~18 purpose-built tools with formal JSON schemas sent via the Anthropic API's native tool_use mechanism. Codex CLI reduces everything to two primitives: a shell executor and a custom `apply_patch` diff format. Aider bypasses tool_use entirely, relying on text-based SEARCH/REPLACE blocks parsed from raw model output. These design choices reflect deep tradeoffs in reliability, token efficiency, and sandboxing complexity that directly inform how you should architect your Go implementation.

---

## Claude Code's 18 built-in tools and their exact JSON schemas

Claude Code's source code leak (March 2026, version 2.1.88) revealed that the system assembles **110+ prompt strings dynamically**, including tool descriptions for ~18 built-in tools. Each tool is defined as a standard Anthropic API tool with a name, description, and `input_schema` following JSON Schema draft 2020-12. The Piebald-AI repository tracks these definitions across 141+ versions.

**Edit** is Claude Code's primary file modification tool. Its schema requires `file_path` (absolute path, string), `old_string` (text to find, string), and `new_string` (replacement text, string), with an optional `replace_all` boolean (default false). The tool enforces a critical constraint: **the model must have called `Read` on a file before it can `Edit` it**, preventing blind edits. If `old_string` is not unique in the file, the edit fails—the model must provide more surrounding context or use `replace_all`. This is Claude's version of the `str_replace_editor` pattern.

**Bash** accepts `command` (string, required), optional `timeout` (number, max 600000ms, default 120000ms), `description` (string for human-readable explanation), `run_in_background` (boolean), and `dangerouslyDisableSandbox` (boolean). The system prompt explicitly instructs Claude to **prefer dedicated tools over bash equivalents**: use `Read` not `cat`, `Edit` not `sed`, `Grep` not `rg`, `Glob` not `find`, and `Write` not `echo >`. Output is truncated at **30,000 characters**.

**Read** takes `file_path` (string, required), optional `offset` (line number to start), `limit` (number of lines), and `pages` (string for PDF page ranges, e.g. "1-5"). It returns content in `cat -n` format with line numbers starting at 1. Default read limit is **2,000 lines**; lines longer than **2,000 characters** are truncated. It handles images (multimodal), PDFs (max 20 pages per request), and Jupyter notebooks.

**Write** creates or overwrites files. **Grep** wraps ripgrep with parameters: `pattern` (regex, required), optional `path`, `glob` (file filter like "*.js"), `output_mode` (enum: "content", "files_with_matches", "count"), context lines (`-A`, `-B`, `-C`), `-i` (case insensitive), `-n` (line numbers), `type` (file type like "js", "py"), `head_limit`, `offset`, and `multiline` (boolean for cross-line matching). **Glob** takes `pattern` (glob string, required) and optional `path` (directory to search). Both return results sorted by modification time.

Additional tools include **TodoWrite** (task tracking with status management), **AskUserQuestion** (structured multi-choice questions with 1-4 questions, 2-4 options each), **Task** (subagent delegation with `subagent_type` for Explore/Plan/custom), **Skill** (slash command execution), **NotebookEdit** (Jupyter cell editing), **EnterPlanMode** and **ExitPlanMode**, and **WebFetch**. The system prompt splits at `SYSTEM_PROMPT_DYNAMIC_BOUNDARY`—everything before it (instructions, tool definitions) is **cached globally across all organizations**, while session-specific context (CLAUDE.md, git status, date) comes after, enabling efficient prompt caching.

---

## Codex CLI's minimalist two-tool architecture

Codex CLI, rewritten in Rust (the `codex-rs` crate), takes a radically simpler approach: **one shell executor and one `apply_patch` command**. The model's system prompt lives in `codex-rs/core/prompt.md` (and `prompt_with_apply_patch_instructions.md`), and the entire agent loop runs in `codex-rs/core/src/agent_loop.rs`.

The **shell tool** executes arbitrary commands. Command output is truncated after **10 kilobytes or 256 lines**. The model is instructed to use `rg` (ripgrep) for searching and to read files in chunks of max **250 lines**. There is no separate Read, Grep, or Glob tool—the model uses standard Unix commands through the shell.

The **`apply_patch` tool** uses a custom "V4A" diff format that OpenAI co-developed with GPT-4.1. The formal grammar is:

```
Patch     := "*** Begin Patch" NEWLINE { FileOp } "*** End Patch" NEWLINE
FileOp    := AddFile | DeleteFile | UpdateFile
AddFile   := "*** Add File: " path NEWLINE { "+" line NEWLINE }
DeleteFile := "*** Delete File: " path NEWLINE
UpdateFile := "*** Update File: " path NEWLINE [ MoveTo ] { Hunk }
MoveTo    := "*** Move to: " newPath NEWLINE
Hunk      := "@@" [ header ] NEWLINE { HunkLine }
HunkLine  := (" " | "-" | "+") text NEWLINE
```

Context lines (prefixed with space) default to **3 lines above and below** each change. The parser uses progressive matching: exact match first, then ignoring line endings, then ignoring all whitespace. On failure, it returns structured JSON to help the model self-correct. This format was specifically trained into GPT-4.1 and later models, making it highly reliable when used with OpenAI models.

The tool is invoked as a shell command: `{"command":["apply_patch","*** Begin Patch\n..."]}`. The Rust harness intercepts `apply_patch` calls from the shell execution path (in `codex-rs/core/src/tools/handlers/apply_patch.rs`) and processes them internally rather than actually executing them in a shell. An **`update_plan`** tool tracks task steps with `pending`, `in_progress`, and `completed` statuses.

**Key architectural difference from Claude Code**: Codex has no file-reading tool. The model must use shell commands (`cat`, `head`, `rg`) to read files. Context is gathered only when the model explicitly requests it—there is no automatic context injection unless `--full-context` mode is enabled, which reads and caches the entire directory.

---

## Aider's text-based SEARCH/REPLACE editing without tool_use

Aider does **not use the API's native tool_use/function calling mechanism at all**. Instead, it instructs the model via system prompt to emit edits in a specific text format, then parses the raw assistant response with a custom parser. This approach has the advantage of working with any model regardless of tool_use support.

The primary format is the **EditBlock (diff) format**, using git merge conflict-style markers:

```
path/to/file.py
<<<<<<< SEARCH
exact code to find
=======
replacement code
>>>>>>> REPLACE
```

The system prompt in `aider/coders/editblock_prompts.py` enforces several rules: every SEARCH section must **exactly match** existing file content character-for-character; blocks should be kept concise with just changing lines plus a few surrounding lines for uniqueness; moving code requires two blocks (one delete, one insert); and the model should **only create blocks for files the user has added to chat**.

The parser in `editblock_coder.py` implements a **multi-strategy fallback chain** for applying edits, in order of decreasing precision: (1) **perfect_replace** — exact tuple comparison of line sequences; (2) **replace_part_with_missing_leading_whitespace** — handles incorrect indentation by normalizing whitespace; (3) **try_dotdotdots** — processes `...` ellipsis markers for unchanged code sections; (4) **find_similar_lines** — uses Python's `SequenceMatcher` to find the most similar content when exact matching fails. If a SEARCH block fails on the specified file, the system tries all other files in the chat context.

Aider supports **five edit formats**: `whole` (return entire file content—simple but token-expensive), `diff` (SEARCH/REPLACE blocks with filename outside fence), `diff-fenced` (filename inside fence, used for Gemini models), `udiff` (simplified unified diff, used for GPT-4 Turbo to combat lazy coding), and `patch` (OpenAI's V4A format, adopted for GPT-4.1 compatibility). The `editor-diff` and `editor-whole` variants are streamlined versions used in **architect mode**, where one model decides what to change and a second model produces the actual edits.

---

## When str_replace beats whole-file rewrite and vice versa

The str_replace approach (Claude Code's Edit tool, Aider's SEARCH/REPLACE) and whole-file rewrite each have distinct failure modes that determine when each is appropriate.

**str_replace excels** when editing large files (>500 lines) because it only transmits the changed portion, saving significant tokens. It produces minimal, reviewable diffs and preserves unchanged code perfectly. Its failure modes include: **ambiguous matches** (the search string appears multiple times—Claude Code fails the edit and requires more context), **stale context** (the model's search string doesn't match the actual file because it was working from an outdated read), and **ordering sensitivity** (multiple replacements in the same file must be applied in the correct order to avoid offset drift).

**Whole-file rewrite excels** for small files (<100 lines), new file creation, and when making pervasive changes throughout a file. Its failure modes are more severe: **lazy coding** (GPT-4 Turbo-era models would replace large sections with `# ... rest of code ...` comments), **accidental code deletion** (the model omits functions it didn't intend to remove), and **high token cost** (a 1000-line file costs ~4000 tokens even for a one-line change). Aider's benchmarks show that `diff` (SEARCH/REPLACE) format consistently outperforms `whole` for most models on their code editing leaderboard.

**For a Go implementation**, str_replace is the right default. Implement it as: read file → find exact match of `old_string` → verify uniqueness → replace → write. Add a `replace_all` flag for bulk renames. The critical implementation detail is **uniqueness enforcement**: if the search string appears more than once, reject the edit and tell the model to include more surrounding context.

---

## How Claude Code and Codex sandbox bash execution

**Claude Code** implements defense-in-depth with two complementary layers. The **permission system** evaluates rules in strict order: deny → ask → allow. Rules use a `Tool(specifier)` format (e.g., `Bash(npm run *)`, `Read(./.env)`). Deny rules at any level cannot be overridden. The **OS-level sandbox** uses **macOS Seatbelt** profiles (via `sandbox-exec`) and **Linux bubblewrap** (`bwrap`) with Landlock/seccomp. The sandbox enforces: filesystem isolation (write access only to CWD and subdirectories, read access systemwide except explicitly denied paths), and network isolation (all traffic routes through a Unix domain socket proxy that validates allowed domains). With `autoAllowBashIfSandboxed: true` (the default), sandboxed bash commands run without prompting. Anthropic reports this **reduces permission prompts by 84%** in internal usage. PreToolUse hooks provide programmable control—a hook can deny, force-prompt, or allow tool calls before the permission system evaluates them.

**Codex CLI** uses platform-specific sandboxing. On **macOS**, Apple's Seatbelt profile restricts filesystem access to the project directory and blocks all network access except to OpenAI's API. On **Linux**, it ships a custom sandbox binary using Landlock/seccomp (`codex-rs/linux-sandbox/`). Sandbox policies map to one of: `read-only`, `workspace-write` (read anywhere, write only in workspace), or `danger-full-access`. Approval modes include `untrusted` (escalate most commands), `on-failure` (allow in sandbox, escalate failures), `on-request` (model can request escalation), and `never` (fully autonomous). The `apply_patch` tool includes path validation to prevent directory traversal and restricts edits to relative paths only—**absolute paths are never accepted**.

**For your Go implementation**, the minimum viable sandbox should: (1) use `exec.Command` with a restricted environment, (2) set a working directory whitelist, (3) implement a command prefix detection system (Claude Code has an entire agent prompt for this: `agent-prompt-bash-command-prefix-detection.md` at 823 tokens), (4) enforce timeouts (default 2 minutes, max 10 minutes), and (5) truncate output at a fixed limit (30KB for Claude Code, 10KB for Codex).

---

## Formatting tool results for maximum model comprehension

Tool result formatting directly affects the model's ability to self-correct and build on previous actions. Key patterns from the major agents:

**File content** should include line numbers in `cat -n` format (space-padded line number + tab + content). Claude Code's Read tool returns this format with lines starting at 1. This enables the model to reference specific locations and construct precise Edit operations. Lines longer than **2,000 characters** should be truncated with a marker.

**Error formatting** should be structured and actionable. Codex's `apply_patch` returns JSON on failure: `{"status": "failed", "error": "...", "file": "...", "hunk": ...}`. Aider sends failed SEARCH/REPLACE blocks back to the model with: `"SearchReplaceNoExactMatch: This SEARCH block failed to exactly match lines in {filename}"` followed by the failed block. The model gets up to **3 reflections** to fix the match before Aider gives up.

**Truncation** should preserve structure. For large bash output (>30K chars), truncate from the middle, preserving the first and last portions since errors typically appear at the end. Include a message like `"[output truncated: {total} chars, showing first {n} and last {m}]"`. For search results, use `head_limit` and `offset` parameters (as Claude Code's Grep does) to paginate rather than truncating.

**Diff output** after edits helps the model verify its work. Codex's `TurnDiffTracker` aggregates all file changes during a turn and emits a unified diff in `TurnDiffEvent`. This gives the model (and user) a complete picture of what changed without re-reading files.

---

## File context injection via repo maps and relevance ranking

Aider's **repository map** is the gold standard for automatic context injection. The pipeline works in stages: (1) **Parse** all source files with tree-sitter to extract definitions (functions, classes, methods) and references (calls, imports, type usage). Each is stored as a `Tag` named tuple: `(rel_fname, fname, line, name, kind)` where kind is "def" or "ref". (2) **Build a directed graph** where files are nodes and edges connect reference sites to definition sites. (3) **Run personalized PageRank** on this graph, with personalization biased toward files currently in the chat and mentioned identifiers. (4) **Select top-ranked symbols** via **binary search on the token budget** (default `--map-tokens 1024`, dynamically expanded up to `8x` when no files are in the chat). (5) **Render** using `TreeContext` which shows parent scope context (class/function signatures) around each definition, not raw line dumps.

The resulting output looks like a hierarchical tree:

```
src/utils/helper.py
    def calculate_total(items)
    def format_output(data)
src/models/user.py
    class User
        def __init__(self, name)
        def save(self)
```

Claude Code takes a different approach: it has **dedicated Grep and Glob tools** that return structured results, and the `Task` tool with `subagent_type=Explore` for deeper codebase exploration. It reads CLAUDE.md files automatically and injects git status, branch info, and recent commits into every turn. The system prompt explicitly instructs: "Use Task tool for open-ended searches requiring multiple rounds" and "Use Glob/Grep directly for simple, directed searches."

**For your Go implementation**, consider implementing a tree-sitter-based repo map as an MCP server (several open-source implementations exist, like `repomap-mcp`). Use `go-tree-sitter` bindings for parsing, build the reference graph, and run PageRank. Cache parse results keyed by `(path, mtime)`. Default to **1024 tokens** for the map budget, expanding to 8192 when the model hasn't selected specific files yet.

---

## Common multi-tool sequences and optimization patterns

The canonical agent workflow follows a **search → read → edit → verify** pattern. Claude Code's system prompt explicitly encodes this: "NEVER propose changes to code you haven't read." The typical sequence is:

1. **Grep/Glob** to find relevant files (parallelizable—Claude Code launches multiple searches simultaneously)
2. **Read** target files (parallelizable—speculatively read multiple potentially useful files)
3. **Edit** files with str_replace operations (sequential within a file, parallelizable across files)
4. **Bash** to run tests/linting to verify changes
5. **Edit** again to fix issues found by tests (iterate)

**Parallel execution** is a first-class concern. Claude Code's system prompt states: "When multiple independent pieces of information are requested and all commands are likely to succeed, run multiple tool calls in parallel." The leaked source confirmed parallel tool calls are a key optimization. Independent reads, searches, and even edits to different files should execute concurrently.

**The Task/subagent pattern** offloads exploration to reduce context consumption. Claude Code uses Task with `subagent_type=Explore` for broad codebase analysis, keeping the main conversation context clean. The subagent gets its own context window, explores independently, and returns a summary.

**Context compaction** handles growing conversations. Claude Code runs `conversation summarization` when the context grows too large, using a dedicated prompt (`agent-prompt-conversation-summarization.md`) that lists all user messages, preserves key facts, and compresses tool results. The compaction prompt carefully separates user messages from tool results but notably does **not flag file content as untrusted**—a known limitation.

---

## Grep-based vs AST-based vs semantic code search

**Grep-based search** (ripgrep integration) is what both Claude Code and Codex CLI use as their primary search mechanism. Claude Code wraps ripgrep in a dedicated Grep tool with structured parameters rather than raw shell invocation. This provides better parameter validation, output formatting, and permission control. Ripgrep is preferred because it's **fast** (parallel, uses memory maps, respects `.gitignore`), supports regex, and handles binary file detection. For a Go implementation, shell out to `rg` or use a Go regex library on a file walker.

**AST-based search** via tree-sitter is used by Aider for its repo map but not as a direct search tool. Tree-sitter parses source into an AST, enabling queries like "find all function definitions named X" or "find all call sites of method Y." This is semantically richer than grep but slower for ad-hoc queries. The key advantage is for **structural queries**: finding all implementations of an interface, all callers of a function, or understanding class hierarchies. Aider's `tags.scm` query files define extraction patterns for **130+ languages**.

**Semantic search** using embeddings is not widely used by the major agents. Aider experimented with it but found that PageRank-based structural analysis outperformed embedding-based similarity for code context selection. The overhead of maintaining an embedding index and the imprecise nature of vector similarity for code makes it less practical than grep + AST analysis.

**Recommendation for Go**: Implement ripgrep as your primary search (shell out to `rg`), add a tree-sitter-based symbol index for structural queries (use `go-tree-sitter` with language grammars from the tree-sitter ecosystem), and skip semantic search. The combination of fast text search + structural understanding covers >95% of coding agent needs.

---

## Implementing undo, rollback, and transactional file edits

None of the major agents implement true database-style transactions, but they each provide rollback mechanisms through different strategies.

**Git-based snapshots** are the most common approach. Aider automatically commits every change the model makes, creating a clean git history that enables `git revert` or `git reset` for any edit. Claude Code's system prompt explicitly recommends git checkpoints: "consider creating Git checkpoints before and after each task so you can easily revert changes." Codex CLI's docs similarly suggest git-based rollback.

**Codex's TurnDiffTracker** records all file modifications during a turn as unified diffs. If a turn fails, the accumulated diff can theoretically be reversed. The `PatchApplyBegin` and `PatchApplyEnd` events provide precise tracking of when and what was modified.

**For your Go implementation**, the most practical approach combines three mechanisms:

1. **Pre-edit file snapshots**: Before any Edit/Write operation, copy the original file content to an in-memory map keyed by path. This enables instant rollback without git overhead. Structure it as a `TurnSnapshot` that groups all file states at the start of a multi-step operation.

2. **Git auto-commit per logical operation**: After a successful multi-file edit sequence, create an automatic git commit (with a machine-generated message). This provides persistent, reviewable history. Use Go's `os/exec` to run `git add` and `git commit`.

3. **Atomic multi-file writes**: For operations that modify multiple files (e.g., rename + update references), collect all changes in memory first, validate them all, then write atomically. If any write fails, restore all files from the snapshot. A simple implementation:

```go
type FileSnapshot struct {
    Path    string
    Content []byte
    Exists  bool
}

type Transaction struct {
    snapshots []FileSnapshot
    committed bool
}

func (t *Transaction) Rollback() error {
    for _, s := range t.snapshots {
        if !s.Exists {
            os.Remove(s.Path)
        } else {
            os.WriteFile(s.Path, s.Content, 0644)
        }
    }
    return nil
}
```

The key insight from studying these agents: **don't over-engineer transactions**. Git provides the durable rollback layer. In-memory snapshots handle the immediate undo case. The combination covers the practical failure modes (bad edits, test failures, user-requested reverts) without the complexity of a real transaction log.

---

## Conclusion

The three agents represent a spectrum of design philosophies. **Claude Code** invests in purpose-built tools with strict schemas—18 tools with validation, permission hooks, and dedicated search tools—trading complexity for precision and safety. **Codex CLI** takes a Unix philosophy approach: one shell, one patch format, and let the model use standard tools—trading feature richness for simplicity and auditability. **Aider** avoids tool_use entirely, parsing model output with a fault-tolerant text parser—trading API coupling for universal model compatibility.

For a Go tool execution layer, the optimal synthesis draws from all three: use Claude Code's tool schema patterns (especially the Edit tool's read-before-edit constraint and uniqueness enforcement), adopt Codex's `apply_patch` format as an alternative for OpenAI models, implement Aider's tree-sitter PageRank repo map for context injection, and layer OS-level sandboxing (bubblewrap on Linux, Seatbelt on macOS) beneath a permission system with deny-first evaluation. The most impactful single decision is choosing str_replace as your default edit mechanism with `replace_all` support—it's what both Claude Code and Aider converged on as the most reliable approach for LLM-driven code modification.