# Production patterns for transactional email, deliverability, and messaging systems

Building production-grade notification infrastructure requires mastering email authentication, provider selection, multi-channel delivery, and — for Canadian users — strict CASL compliance that exceeds most international standards. This report covers the full stack: from DNS records and IP warmup schedules to push token lifecycle management and webhook signature verification, with concrete schemas, code patterns, and provider comparisons throughout.

---

## 1. Transactional email infrastructure and provider selection

The four leading transactional email providers serve different niches. **Postmark** delivers the highest inbox placement rates (~98.7%) by strictly separating transactional and broadcast streams into isolated IP pools, but charges a premium at $15/month for 10K emails. **AWS SES** is the cheapest at **$0.10 per 1,000 emails** with no monthly base fee, ideal for high-volume senders already on AWS — but demands significant engineering investment for bounce handling via SNS, manual IP warmup, and no built-in deliverability dashboard without the Virtual Deliverability Manager add-on ($0.07/1K). **SendGrid** retired its free tier in May 2025 and now starts at $19.95/month for 50K emails; it remains the best all-in-one platform combining transactional and marketing email with dynamic templates and a drag-and-drop editor. **Resend** targets modern React/TypeScript stacks with 3K free emails/month and first-class React Email integration, starting at $20/month for 50K emails on paid plans.

| Factor | SendGrid | Postmark | AWS SES | Resend |
|--------|----------|----------|---------|--------|
| **Free tier** | 60-day trial only | 100/month | 3K/month (EC2) | 3K/month |
| **Paid from** | $19.95/mo (50K) | $15/mo (10K) | $0.10/1K | $20/mo (50K) |
| **Dedicated IP** | Included on Pro | $50/mo (300K+ vol.) | $24.95/mo | $30/mo |
| **Best for** | All-in-one platform | Mission-critical transactional | High-volume, low cost | React/TypeScript stacks |
| **DX quality** | Good, battle-tested | Excellent, split API | Complex (IAM, SNS) | Best modern DX |

### Dedicated IP vs shared IP

Stay on **shared IPs below 100K emails/month**. Shared pools are pre-warmed and managed by the ESP. A poorly maintained dedicated IP with inconsistent volume performs worse than a well-managed shared pool. Above 100K/month with consistent daily sending, dedicated IPs give you full reputation control, eligibility for whitelisting programs, and easier troubleshooting. Use dedicated IPs to **separate transactional from marketing streams** — this is the single most important isolation boundary.

### IP warmup schedule

Warmup takes **4–8 weeks** with a daily volume increase of 20–50%. Start with your most engaged recipients (opened/clicked in last 30 days) and expand outward:

- **Week 1:** 50–500 emails/day to 30-day engaged users
- **Week 2:** 500–2,000/day expanding to 60-day engaged
- **Week 3–4:** 2,000–15,000/day including 90-day engaged
- **Week 5–8:** Ramp to full volume across all segments

Monitor open rates (aim >25%), bounce rates (must stay <1%), and complaint rates (<0.1%). If Gmail Postmaster Tools shows reputation dropping, pause and reduce volume immediately. Common mistakes: ramping too fast, sending to stale lists, inconsistent sending patterns, and skipping authentication setup.

### Sending domain configuration

Every sending domain needs four DNS records configured correctly:

**SPF** authorizes which servers can send for your domain. Only one TXT record per domain — combine all providers into a single record. Critical constraint: **maximum 10 DNS lookups** (each `include:` counts, nested includes count recursively). Exceeding this triggers PermError, treated as SPF failure.

```
@ TXT "v=spf1 include:sendgrid.net include:amazonses.com ~all"
```

**DKIM** cryptographically signs messages. Use **2048-bit RSA keys** (industry standard minimum). Rotate keys every 90–180 days using unique selectors per service (e.g., `sendgrid._domainkey`, `ses._domainkey`). Rotation process: publish new key → wait for DNS propagation → switch signing → keep old key for 7–30 days → retire by setting `p=` empty.

**DMARC** ties SPF and DKIM to the visible From: domain. Progress through three phases: `p=none` for monitoring (minimum 4 weeks), `p=quarantine` with `pct=25` ramping to 100, then `p=reject` for full enforcement. Aim to reach `p=reject` within 90 days. Set subdomain policy with `sp=reject` once all subdomain senders are authenticated.

```
_dmarc TXT "v=DMARC1; p=reject; pct=100; rua=mailto:dmarc@example.com; adkim=s; aspf=s"
```

**Custom Return-Path** enables SPF alignment under DMARC. Most ESPs use their own bounce domain by default — configure a custom MAIL FROM subdomain (e.g., `em1234.yourdomain.com` pointing to the ESP's bounce handler). Also set up a **custom tracking domain** to isolate click-tracking reputation from the ESP's shared tracking domain.

---

## 2. Email deliverability engineering

### Authentication protocols in depth

**SPF alignment** comes in two modes: relaxed (organizational domain match — `mail.example.com` aligns with `example.com`) and strict (exact domain match). Relaxed is sufficient for most organizations using third-party ESPs. When hitting the 10-lookup limit, use subdomain delegation (each subdomain gets its own SPF budget), SPF flattening (replace includes with IP ranges, but requires continuous monitoring as provider IPs change), or SPF macros for dynamic resolution without consuming lookups.

**DKIM** selectors should follow a naming convention including purpose and date: `sales-202501-2048`. Never reuse selector names after rotation — old messages would fail re-validation. M3AAWG recommends rotation every **6 months minimum**. Keep the old public key in DNS for 7–30 days after switching to the new key.

**BIMI** (Brand Indicators for Message Identification) displays your logo in supporting email clients. It requires DMARC at `p=quarantine` or `p=reject`, plus either a **VMC** (Verified Mark Certificate, ~$1,500/year, requires registered trademark, enables Gmail blue checkmark) or a **CMC** (Common Mark Certificate, no trademark needed, Gmail-only, no checkmark). Organizations with BIMI see open rate increases of **4–6%** and brand recall improvement of 44%.

**ARC** (Authenticated Received Chain) preserves authentication results across intermediaries like mailing lists and forwarding services. Domain owners don't configure ARC — it's implemented by intermediary servers. Gmail trusts ARC seals from known mailing list providers.

### Gmail and Yahoo bulk sender requirements

Since February 2024 (with enforcement tightened to permanent 5xx rejections in November 2025), all bulk senders (5,000+ messages/day to personal Gmail) must implement SPF **and** DKIM, DMARC with minimum `p=none`, DMARC alignment, RFC 8058 one-click unsubscribe for marketing messages, and honor unsubscribes within **48 hours**. Spam complaint rate must stay under **0.1%** (recommended) and never reach **0.3%** (enforcement trigger). Microsoft followed with similar requirements in May 2025.

### Bounce and complaint handling

**Hard bounces** (5xx codes — invalid address, nonexistent domain) require immediate suppression. Never retry. **Soft bounces** (4xx codes — mailbox full, server temporarily unavailable) get 3–5 automatic retry attempts over 24–72 hours. After **3 consecutive soft bounces across campaigns**, treat as hard bounce and suppress.

Target metrics: total bounce rate **under 2%**, hard bounce rate **under 0.5%**, spam complaint rate **under 0.1%**. Above 0.3% complaint rate triggers aggressive ISP filtering that takes weeks to reverse.

Implement **List-Unsubscribe** with the RFC 8058 one-click pattern:

```
List-Unsubscribe: <mailto:unsub@example.com>, <https://example.com/unsubscribe?id=123>
List-Unsubscribe-Post: List-Unsubscribe=One-Click
```

The HTTPS endpoint must process POST requests containing `List-Unsubscribe=One-Click` without redirects, cookies, or authentication. Yahoo reports that implementing one-click unsubscribe reduces spam marks by **30–40%**.

### Sender reputation monitoring

**Domain reputation increasingly dominates IP reputation** — Gmail weights domain reputation heavily and it follows your domain across IP and ESP changes. Build a monitoring stack with Google Postmaster Tools (Gmail domain reputation grade, spam rate, authentication results), Microsoft SNDS (Outlook ecosystem IP reputation), MxToolbox (blacklist monitoring across 50+ blocklists), and Sender Score (aim for 80+). Review weekly; investigate immediately after unusual bounce or complaint spikes. Reputation recovery takes **4–12 weeks** of reduced volume, engaged-segment-only sending, and perfect authentication.

---

## 3. Email template engineering

### MJML remains the cross-client compatibility champion

Email HTML is stuck in the table-layout era because Outlook desktop (2007–2021) uses Microsoft Word's rendering engine instead of a browser engine. This means **no flexbox, no grid, no border-radius, no CSS background images, no media queries** in Word-engine Outlook. MJML abstracts this away by compiling semantic components (`<mj-section>`, `<mj-column>`, `<mj-button>`) into battle-tested nested tables with inline CSS.

**MJML vs React Email vs Maizzle:** MJML has the widest cross-client compatibility and automatic responsive behavior. React Email offers superior developer experience for TypeScript teams but requires patching for MSO conditional comments. Maizzle gives Tailwind CSS workflows but demands deeper email-specific knowledge. For production transactional email with Outlook support requirements, **MJML is the safest choice**.

```xml
<mjml>
  <mj-head>
    <mj-preview>Your order has shipped</mj-preview>
    <mj-attributes>
      <mj-all font-family="Arial, sans-serif" />
      <mj-text font-size="16px" line-height="1.5" />
    </mj-attributes>
  </mj-head>
  <mj-body background-color="#f4f4f4">
    <mj-section background-color="#ffffff" padding="20px">
      <mj-column>
        <mj-text font-size="24px">Welcome, {{name}}!</mj-text>
        <mj-button background-color="#3b82f6" href="https://app.example.com">
          Get Started
        </mj-button>
      </mj-column>
    </mj-section>
  </mj-body>
</mjml>
```

### Outlook conditional comments and ghost tables

The **ghost table pattern** is essential for dual rendering — Outlook gets a fixed-width table while modern clients get fluid CSS layouts:

```html
<!--[if mso]>
<table role="presentation" width="600"><tr><td>
<![endif]-->
<div style="max-width: 600px;"><!-- Modern layout --></div>
<!--[if mso]>
</td></tr></table>
<![endif]-->
```

VML (Vector Markup Language) enables rounded buttons and background images in Outlook. The new Chromium-based Outlook ignores MSO conditionals harmlessly. Microsoft ends Word-engine support in **October 2026**, but expect to support both engines through 2027–2028 given slow enterprise migration.

Gmail has its own gotchas: an **8,192 character limit on `<style>` blocks** (exceeding strips the entire block), `background-image` in `<style>` blocks causes Gmail to strip the whole block, and emails exceeding **~102KB total HTML** get clipped. Always inline critical styles.

### Dark mode requires defensive design

Email clients handle dark mode in three incompatible ways: no change (Yahoo Mail), partial inversion (Gmail app, Outlook mobile), and full inversion (Samsung Mail). **Gmail does not support `@media (prefers-color-scheme: dark)`** — no CSS technique helps.

For clients that do support it (Apple Mail, Outlook for Mac):

```html
<meta name="color-scheme" content="light dark">
<style>
  :root { color-scheme: light dark; }
  @media (prefers-color-scheme: dark) {
    .email-bg { background-color: #1a1a1a !important; }
    .text-dark { color: #e0e0e0 !important; }
  }
</style>
```

Practical rules: avoid pure `#000000` and `#FFFFFF` (triggers aggressive inversion — use `#000001` or `#FFFFFE`), set explicit colors on every element, swap logos using CSS display toggling, and add subtle strokes around transparent PNG logos. Always test in Apple Mail dark mode, Gmail dark mode, and Outlook dark mode — each behaves differently.

### Accessibility is non-negotiable

Add `role="presentation"` to every layout table so screen readers don't announce "Table with 3 columns and 5 rows." Use semantic headings (`<h1>`–`<h3>`), descriptive alt text on every meaningful image (style your alt text for when images are blocked), minimum **4.5:1 color contrast** (WCAG 2.1 AA), **44×44px minimum touch targets**, and the `lang` attribute on the `<html>` element. Place the primary content column first in source order for logical screen reader navigation.

---

## 4. CASL compliance for Canadian users

### Express vs implied consent is the foundation

CASL operates on an **opt-in model** — the opposite of CAN-SPAM's opt-out approach. Express consent requires a clear, proactive action (unchecked checkbox, not pre-checked), must describe the purpose, identify the sender with contact information including physical mailing address, and state the recipient can unsubscribe. **Express consent never expires** until withdrawn.

Implied consent exists in narrow, time-limited windows: **2 years** from the last purchase, contract, or membership payment (existing business relationship), and **6 months** from an inquiry or application. The clock resets with each new qualifying interaction. Critically, **an email requesting consent is itself a Commercial Electronic Message** under CASL — you cannot email someone to request consent unless you already have implied consent.

For SMS specifically under CASL, **express consent is always required** — implied consent is not sufficient. Email consent does not transfer to SMS; channel-specific consent is mandatory.

### Consent expiration tracking requires purpose-built infrastructure

| Consent type | Expiration | Clock starts |
|---|---|---|
| Express (written/oral) | **Never** (until withdrawn) | N/A |
| Business relationship (purchase) | **2 years** | Date of last transaction |
| Business relationship (contract) | **2 years** after expiry | Contract expiry date |
| Inquiry/application | **6 months** | Date of inquiry |
| Non-business (donation/volunteer) | **2 years** | Date of last activity |

Build a consent management microservice with this schema:

```sql
CREATE TABLE consent_records (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  email_address VARCHAR(255) NOT NULL,
  consent_type VARCHAR(50) NOT NULL,  -- 'express_written', 'implied_ebr_purchase', etc.
  consent_status VARCHAR(20) DEFAULT 'active',
  granted_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ,  -- NULL for express consent
  source_url TEXT,
  source_description TEXT NOT NULL,  -- exact wording shown
  purpose TEXT NOT NULL,
  ip_address INET,
  user_agent TEXT,
  form_version_id UUID,  -- FK to form snapshots
  withdrawn_at TIMESTAMPTZ,
  UNIQUE(user_id, email_address, consent_type)
);
```

An **append-only audit log** must record every consent state change (granted, renewed, upgraded, expired, withdrawn) with actor, timestamp, IP, and previous/new state. Retain records for **at least 3 years beyond consent expiration** — the CRTC's limitation period runs from discovery, and discovery can occur long after the violation.

### Pre-send compliance gate

Every outbound message must pass through a compliance middleware that classifies the message type (transactional vs commercial), verifies active consent for commercial messages, checks all required elements (sender identification, physical mailing address, unsubscribe mechanism, contact information), and rejects messages that include **any promotional content in transactional emails**. Under CASL, unlike CAN-SPAM, any commercial content in a transactional message renders the **entire message commercial** and subject to full consent requirements. No cross-sells in receipts, no promotional banners in shipping notifications.

Run a daily cron job to expire implied consents past their date and trigger re-consent campaigns **60–90 days before expiration** — this is your window to convert implied consent to express consent via email.

### CASL penalties are severe

Businesses face up to **$10 million CAD per violation**, individuals up to $1 million. Directors and officers can be held personally liable. Notable enforcement: $1.1M against Compu-Finder, $200K against Rogers Media, $120K against Hudson's Bay Company (2024). Between October 2024 and March 2025, over **208,000 spam complaints** were submitted to the CRTC Spam Reporting Centre, 39% SMS-related. The CRTC actively issues warning letters to high-complaint companies.

### International compliance strategy

When serving Canadian, US, and EU users simultaneously, **apply the strictest standard (CASL) uniformly**: opt-in consent for all, full identification elements, no promotional content in transactional messages, 10-business-day unsubscribe processing. One compliance workflow is simpler and safer than jurisdiction-specific logic.

---

## 5. Unified notification architecture

### Event-driven pipeline with five layers

A production notification system separates concerns into ingestion, preference routing, template rendering, delivery, and observability. The critical design principle: **callers emit events, not channel decisions**. A service publishes `order.shipped` — the notification system decides whether to send email, push, SMS, or all three based on user preferences, channel health, and rate limits.

```typescript
interface NotificationEvent {
  eventId: string;      // idempotency key
  type: string;         // "order.shipped"
  recipientId: string;
  payload: Record<string, unknown>;
  priority: "critical" | "high" | "normal" | "low";
  dedupKey?: string;    // business-level dedup
  ttlSeconds?: number;  // drop if not delivered within window
}
```

Use **SNS/SQS fan-out** or **Kafka topics per channel**: the notification API gateway publishes to a message bus, which fans out to dedicated per-channel queues. Each channel has independent workers — an email provider outage doesn't impact push delivery.

### Build vs buy

**Knock** excels at workflow orchestration with a visual builder but requires you to bring your own delivery providers. **Novu** is open-source and self-hostable (38K+ GitHub stars) — best for data residency requirements. **OneSignal** dominates mobile push (2M+ developers, 20% of mobile apps) but is marketing-oriented. **Courier** suits teams where product/design teams need notification management alongside engineering.

Build in-house only if you process 100M+ notifications monthly with dedicated infrastructure engineers and truly unique requirements. Rough build cost: **6–12 months for a 3-person team** plus 1 FTE ongoing maintenance. Buy when time-to-market matters.

### User preference management

Model preferences as a three-layer matrix: system defaults → category defaults → per-user overrides. Allow per-category AND per-channel granularity (push for mentions, email digest for general updates). Offer frequency controls: immediate, daily digest, weekly digest. **Critical notifications (security alerts, 2FA, legal notices) must bypass all preferences** and deliver on all channels.

```sql
CREATE TABLE user_notification_preferences (
  user_id UUID NOT NULL,
  category_id UUID REFERENCES notification_categories(id),
  channel VARCHAR(20) NOT NULL,
  enabled BOOLEAN NOT NULL,
  frequency VARCHAR(20) DEFAULT 'immediate',
  UNIQUE(user_id, category_id, channel)
);
```

### Priority queues and rate limiting

Use separate queues per priority with different worker concurrency: critical (10 workers, no rate limit, <5s SLA), high (8 workers, <30s), medium (5 workers, rate-limited, <60s), low (2 workers, batched, <5min). Start with **BullMQ** (Redis-backed) for simplicity; migrate to RabbitMQ for complex routing or Kafka at very high scale.

Rate limit per user across multiple dimensions: global (20/hour, 50/day), per-channel (5 push/hour, 2 SMS/day), per-category (3 marketing push/day). Use **sliding window counters** in Redis for per-user limits. Rate-limited notifications aren't dropped — they're queued for digest or delayed delivery.

Implement **quiet hours** per user timezone (e.g., 10pm–8am), checking `user_quiet_hours` before non-critical delivery. Only `in_app` notifications deliver during quiet hours for non-critical items; everything else queues until the delivery window opens.

### Timezone-aware delivery

Store all timestamps in UTC alongside the IANA timezone identifier (e.g., `America/Toronto`). Never store fixed UTC offsets — they break during DST transitions. Infer timezone from explicit user settings, device/browser `Intl.DateTimeFormat()`, or IP geolocation as fallback. For global campaigns, stagger sends starting from the easternmost timezone, delivering at the target local time, progressing westward. OneSignal reports **23% higher open rates** with timezone-optimized delivery.

---

## 6. Push notification patterns

### APNs vs FCM key differences

| Aspect | APNs (Apple) | FCM (Google) |
|---|---|---|
| **Protocol** | HTTP/2 required | HTTP/2 (v1 API) |
| **Auth** | JWT with ES256 (.p8 key) | OAuth 2.0 (service account) |
| **Payload limit** | 4 KB | 4 KB |
| **Token format** | 64-byte hex | ~183-byte alphanumeric |
| **Offline storage** | 1 notification per app (latest wins) | Up to 100 per device |
| **Invalid token signal** | HTTP 410 Gone | NotRegistered error |
| **Environments** | Sandbox vs Production | Single environment |

FCM can wrap APNs tokens for iOS, letting your backend store a single token type. This simplifies the database schema but adds a dependency on Google's infrastructure.

### Push token lifecycle is critical to manage

Register for tokens on every app launch and compare with stored values. Token refresh occurs on app reinstall, device restore, OS updates, and Google-initiated rotation. On every delivery attempt, check the vendor response for invalid tokens — **immediately delete** tokens returning APNs 410 Gone or FCM NotRegistered. Periodic cleanup: send a silent push "pulse" to detect uninstalls, pruning tokens that error.

**Silent push** wakes the app in background without visible notification: set `content-available: 1` with `apns-priority: 5` for iOS, or send data-only messages (no `notification` object) for Android. Apple throttles to ~5 silent pushes/day per device and won't deliver if the user force-quit the app.

### Android notification channels are required since Android 8.0

Map your notification categories to **3–5 channels** (e.g., `order_updates`, `security_alerts`, `social`, `promotions`). Once created, **you cannot change a channel's importance level** — the user has final control. Rich notifications with images increase open rates by up to **56%**; support up to 3 action buttons per notification, and always deep-link to specific content rather than the home screen.

### Permission request timing determines your opt-in rate

Never ask on first launch. Show a **custom in-app screen** explaining what notifications you'll send and why. Only trigger the OS system prompt after the user taps "Yes, notify me." This "push primer" pattern increases acceptance rates by **30–50%**. Optimal timing: after first purchase, after completing onboarding, or at a contextual value moment. On iOS, you get ONE chance with the system prompt — if denied, re-enabling requires the user to navigate to Settings manually. Android 13+ now requires explicit permission (previously opt-in by default).

---

## 7. SMS patterns and compliance

### Short code vs 10DLC vs toll-free

**Short codes** (5–6 digits) deliver 100–500+ messages per second but cost $500–$1,000/month to lease and take 8–12 weeks for carrier approval. **10DLC** (10-digit long codes) cost ~$1/month plus $15/month registration but throughput depends on your TCR trust score: scores of 1–24 get ~4 MPS while 75–100 get ~40–75 MPS. Secondary vetting costs $40 and is essential for meaningful throughput. **Toll-free** numbers offer a middle ground at ~$2/month with 3–150 MPS after verification (1–3 weeks).

### TCPA/CTIA compliance

Express written consent is required before sending promotional/automated SMS. The consent disclosure must include program description, message frequency, "message and data rates may apply," opt-out instructions, and link to terms. **TCPA quiet hours: no solicitation before 8 AM or after 9 PM** in the recipient's timezone. CTIA requires double opt-in for recurring marketing and mandates processing STOP/HELP keywords regardless of protocol. Violations carry $500–$1,500 per unauthorized text; class-action lawsuits are common (Clover $15M in 2024, Cash App $12.5M in 2025).

The FCC's April 2025 update mandates that consumers can revoke consent through **any reasonable method** — not just the exact unsubscribe mechanism. Process revocations within 10 business days.

### International SMS encoding

GSM-7 encoding gives **160 characters per segment** (153 in multi-part messages). Unicode (UCS-2) drops to **70 characters per segment** (67 multi-part). A single emoji forces the entire message to UCS-2, potentially doubling cost. Many countries require pre-registered sender IDs (India requires DLT registration with template approval; UAE and Saudi Arabia require pre-registration). The US and Canada don't support alphanumeric sender IDs — a phone number is required.

**Provider comparison:** Twilio has the best documentation and broadest ecosystem but is most expensive (~$0.0079/segment). Plivo is the cheapest (~$0.0045–$0.005/segment). Vonage offers the best international coverage (200+ countries) with competitive pricing. MessageBird (Bird) is strongest in European and Asian markets.

---

## 8. Webhook delivery as notification

### Retry schedule and signature verification

Webhooks provide **at-least-once delivery** — duplicates are expected. Use this retry schedule with exponential backoff and 25% jitter: 1 min → 5 min → 30 min → 2 hours → 8 hours → 24 hours. After 6 failed attempts (~34 hours total), move to the dead letter queue and alert. Classify responses: **5xx and timeouts are retriable**, 4xx (except 429) go straight to DLQ, and 429 honors the Retry-After header.

Sign every webhook using **HMAC-SHA256** with the Stripe-style timestamp pattern:

```typescript
// Sender: X-Webhook-Signature: t=1712345678,v1=5257a869...
const signedPayload = `${timestamp}.${rawBody}`;
const signature = crypto.createHmac('sha256', secret)
  .update(signedPayload).digest('hex');

// Receiver: reject timestamps >5 minutes old (replay protection)
// Use crypto.timingSafeEqual for constant-time comparison
```

Always verify against the **raw request body** (never parsed JSON). Support two active secrets during rotation periods. Receivers should ACK with 202 immediately and process the event asynchronously via a queue.

### Endpoint health monitoring

Implement a circuit breaker that tracks consecutive failures per endpoint. After **10 consecutive failures**, auto-disable the endpoint: shunt new events to a holding queue, start periodic health probes (every 30 seconds), and alert the endpoint owner. When probes succeed, enter a recovery phase: drain the holding queue at ramped rates (10% → 25% → 50% → 100%). Expose a webhook event browser so endpoint owners can inspect failed deliveries and manually replay from the DLQ.

---

## 9. Email testing and deliverability monitoring

### Rendering and spam testing

**Email on Acid** ($99/month, 90+ clients, unlimited testing) beats **Litmus** ($500/month post-acquisition) on value for QA-focused teams, though Litmus offers a superior visual email builder and collaboration features for design-heavy workflows. GlockApps is the market leader for seed list inbox placement testing — 100+ seed addresses across major providers with automated scheduling and threshold alerts. For spam scoring, **mail-tester.com** provides free SpamAssassin-based scores (aim for 9+/10), though modern providers like Gmail use behavioral ML-based filtering that outweighs traditional content scoring.

### Production monitoring stack

Build a layered monitoring pipeline: **pre-send** (GlockApps seed test for every new template), **authentication** (continuous SPF/DKIM/DMARC monitoring), **reputation** (Google Postmaster Tools + Microsoft SNDS + Sender Score weekly), **complaints** (Yahoo Complaint Feedback Loop + Gmail Feedback-ID tracking), **inbox placement** (GlockApps automated tests with alerts if inbox rate drops below 90%), and **blacklists** (MxToolbox daily checks across 50+ blocklists). Test every new template and significant design change. Test quarterly for existing templates since email client rendering engines update regularly. Test immediately after any infrastructure change.

---

## 10. Agent rules for email and notification infrastructure

These ten rules form the compliance and reliability foundation for any notification system:

1. **Always validate email before sending** — check syntax (RFC 5322), MX records, disposable domains, and role-based addresses
2. **Never send without checking the suppression list** — hard bounces, spam complaints, and unsubscribes must block sending; sync suppression across all platforms
3. **Always include List-Unsubscribe headers** — RFC 8058 one-click unsubscribe is required by Gmail/Yahoo for bulk senders since June 2024
4. **Check consent before every CEM** — verify express consent for SMS (always), check implied consent expiry for email, never send CEM to obtain consent
5. **Never log full email content** — log metadata only (message ID, recipient hash, event type, delivery status); mask email addresses in logs
6. **Use idempotency keys for every notification** — `${event_type}_${resource_id}_${timestamp}` checked against a sent-notifications table before sending
7. **Rate limit all outbound communications** — per-recipient, per-channel, per-domain, and global ESP limits via token bucket or sliding window in Redis
8. **Separate transactional and marketing domains** — different subdomains, different IP pools, different suppression logic; marketing reputation issues must never impact password resets
9. **Monitor deliverability continuously** — alert on bounce rates >2%, complaint rates >0.1%, authentication failures, reputation grade drops, and blacklist appearances
10. **Handle provider failover gracefully** — maintain a ranked list of providers with circuit breakers; after 5 failures in 5 minutes, promote the secondary provider and alert

```typescript
class NotificationSender {
  async send(message: EmailMessage): Promise<SendResult> {
    for (const provider of this.providers) {
      try {
        const result = await provider.send(message);
        if (result.success) return result;
      } catch (err) {
        await this.recordFailure(provider.name, err);
        continue; // Try next provider
      }
    }
    throw new AllProvidersFailedError();
  }
}
```

---

## Conclusion

The critical insight across all these systems is that **compliance and deliverability are architectural concerns, not afterthoughts**. CASL's opt-in model, strict transactional/commercial separation, and severe penalties ($10M/violation) mean consent management must be a first-class microservice with immutable audit logs — not a boolean field on the user table. The February 2024 Gmail/Yahoo sender requirements have made SPF+DKIM+DMARC and one-click unsubscribe mandatory infrastructure, not nice-to-haves. On the multi-channel side, the pattern that pays off most is treating notification routing as a separate concern from event emission: services publish events, and a centralized notification system handles channel selection, preference resolution, rate limiting, timezone scheduling, and provider failover. Start with BullMQ and shared IPs, buy a platform like Knock or Novu unless you're at 100M+ notifications/month, and invest early in the consent tracking infrastructure — it's far harder to retrofit than to build correctly from the start.