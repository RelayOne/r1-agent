# How developer tools build intelligent configuration wizards

**The best configuration wizards ask almost nothing.** They infer project name from the directory, detect the framework from dependency files, read author info from git config, and auto-generate build commands from package manager conventions — reducing what could be 50 questions to fewer than 5. For Stoke's Go-based configuration wizard, the most effective pattern combines aggressive file-based detection (like Vercel's open-source framework detectors), a tiered question model with `--yes` defaults (like npm/cargo), and the Charm ecosystem's Huh library for interactive TUI flows. This report distills the specific heuristics, UX patterns, and implementation architectures used by the most successful developer tools into actionable guidance.

---

## How package managers detect everything from your directory

The spectrum of interactivity across package initialization tools reveals a clear trend: **newer tools ask fewer questions**. `npm init` asks 9 questions, `cargo init` asks zero, and `go mod init` takes a single argument. Each tool demonstrates distinct detection heuristics worth emulating.

**npm init** (powered by the `init-package-json` module) builds defaults from multiple signal sources in a layered priority system. The directory name becomes the package name after sanitization (lowercased, stripped of non-URL-safe characters). Git remote URL is detected via `git remote get-url origin` and used for the repository field, with `bugs` and `homepage` derived automatically by appending `/issues` and `#readme`. Four `.npmrc` config values — `init-author-name`, `init-author-email`, `init-license`, and `init-version` — persist user preferences across all future projects. When an existing `package.json` is present, all its values become the new defaults, making re-initialization additive rather than destructive. The `-y` flag collapses this entire flow to zero prompts, and users can create `~/.npm-init.js` for fully custom initialization logic.

**cargo init** represents the zero-question ideal. It infers the package name from the directory, detects binary vs. library targets by scanning for `main.rs` or `lib.rs` in standard locations, discovers author information through a **six-level fallback chain** (Cargo config → `CARGO_NAME` env → `GIT_AUTHOR_NAME` → `GIT_COMMITTER_NAME` → `git config user.name` → `USER` env var), and skips VCS initialization if already inside a repository. The `--bin` vs `--lib` detection is particularly instructive: cargo checks for existing source files with "typically-named" patterns and adapts its output accordingly, even handling the case where both `main.rs` and `lib.rs` exist.

**go mod init** takes the most opinionated stance — it either infers the module path from `$GOPATH/src/` relative positioning or requires it as an explicit argument. Go deliberately removed git remote inference in v1.13 because the signal was unreliable (module paths can differ from VCS paths via import redirects). This philosophy of **preferring explicit failure over wrong guesses** is worth considering: when getting a value wrong early creates cascading problems, it's better to require one clear input than to guess.

The key implementation pattern across all three: **build a priority chain of signal sources** (existing config files → environment variables → VCS metadata → directory structure → hardcoded defaults) and walk the chain until you find a value, then present it as a pre-filled default rather than an open question.

---

## Vercel's framework detection is a 4,445-line decision engine

Vercel's framework detection, fully open-source in the `@vercel/frameworks` package, provides the most sophisticated example of file-based tech stack identification. The system defines detection rules for **45+ frameworks** using a logical combinator pattern with three matcher types: `matchPackage` (checks dependencies in package.json), `path` (checks file existence), and `matchContent` (checks file contents via string matching).

The detection rules range from simple to nuanced. Next.js detection is a single check: `{ every: [{ matchPackage: 'next' }] }`. But React Router v7 requires content matching to distinguish it from generic Vite: it checks whether `vite.config.js` or `vite.config.ts` contains the string `@react-router/dev/vite`, or whether `react-router.config.js` exists. Remix checks both package presence (`@remix-run/dev`) and config file existence (`remix.config.js`, `remix.config.mjs`) using the `some` combinator — any match suffices.

**Priority resolution** uses three mechanisms working together. A `sort` field gives each framework a numeric priority (Next.js = 1, Gatsby = 5, Remix = 6). A `supersedes` field handles overlap explicitly — Remix declares `supersedes: ['hydrogen', 'vite']`, ensuring it wins when both detectors match. And array ordering places specific frameworks before generic build tools, so the first match wins.

Each framework definition includes auto-configured build settings: build command (`next build`), output directory (`.next`), dev command (`next dev --port $PORT`), and install command (auto-detected from lockfiles — `yarn.lock` → Yarn, `pnpm-lock.yaml` → PNPM, `bun.lockb` → Bun). The install command detection alone saves a question that many tools still ask explicitly.

For ambiguous detection, Vercel's dashboard shows a confirmation pattern: **"Detected Next.js — is this correct?"** with a dropdown to override. This "detect-then-confirm" approach is the optimal UX: it demonstrates the tool's intelligence while preserving user control. The `vercel.json` file serves as the ultimate escape hatch, letting users override any auto-detected value.

---

## Nixpacks and Fly.io scan repos from opposite directions

Where Vercel focuses on frontend frameworks via package.json, **Nixpacks** (Railway's open-source builder) and **Fly.io's scanners** detect full-stack applications from different starting points.

Nixpacks implements a Rust **Provider trait** with `detect()` and `get_build_plan()` methods across **23 language providers**. Each provider's detection is straightforward file-existence checking: `package.json` for Node.js, `go.mod` for Go, `Cargo.toml` for Rust, `requirements.txt` or `pyproject.toml` for Python. The first provider that returns `true` wins. But Nixpacks goes deeper within each language — the Node.js provider detects package managers from lockfiles, identifies monorepo tools (`nx.json` → NX, `turbo.json` → Turborepo, `.moon/workspace.yml` → Moon), recognizes Vite SPAs for Caddy serving, and detects Next.js for cache optimization. The Python provider chains detection priority: Poetry (`[tool.poetry]` in pyproject.toml) → PEP 621 → Pipenv → pip → bare `main.py`, then identifies Django, Flask, FastAPI, or Streamlit to generate appropriate start commands.

Nixpacks' build plan architecture — **phases** (setup → install → build → start) with dependency chains, cache directories, and Nix packages — is a clean model for Stoke to emulate. Users can inspect the plan with `nixpacks plan` and override any part via `nixpacks.toml`.

**Fly.io's `fly launch`** takes an opposite approach: rather than abstracting deployment behind providers, its Go-based scanners **generate Dockerfiles** from templates. Each scanner (Django, Flask, Rails, Laravel, Phoenix, Node.js) uses regex matching on dependency files — Django's scanner checks `requirements.txt`, `Pipfile`, and `pyproject.toml` for the case-insensitive pattern `Django`. Scanners produce a `SourceInfo` struct with framework family, port, environment variables, secrets, and generated files. The Dockerfile-first philosophy means Fly.io's scanners are opinionated but transparent — users can see and modify exactly what will run. A critical design choice: if a `Dockerfile` already exists, it takes priority and blocks all other scanners.

**Render**, by contrast, relies almost entirely on explicit user selection — users choose their runtime and specify build/start commands. This represents the low end of the detection sophistication spectrum but works well for Render's "just tell us what to do" philosophy.

---

## ESLint's conditional branching and the art of question flow design

ESLint's `--init` wizard demonstrates the most sophisticated conditional branching among developer tools. The question flow uses **early choices to prune entire branches** of subsequent questions.

The flow begins with a purpose question: "How would you like to use ESLint?" with three options — syntax checking only, find problems, or enforce code style. Choosing "enforce code style" unlocks an entire additional branch (style guide selection, or manual style questions about indentation, quotes, semicolons, and line endings). Choosing "find problems" skips all style questions entirely. This single branching point eliminates **4-6 questions** for the majority of users who just want error detection.

Subsequent questions progressively narrow the configuration space: module type (ESM/CommonJS/none) → framework (React/Vue/none) → TypeScript (yes/no) → runtime environment (browser/node, multiselect). Each answer maps directly to generated config properties: framework choice adds the appropriate plugin (`plugin:react/recommended`), TypeScript adds `@typescript-eslint/parser`, and environment sets the `env` object. The mapping from answers to config is deterministic and transparent.

The modern `@eslint/create-config` (for flat config) has notably simplified the flow — the style enforcement option has been removed, reflecting a broader industry shift toward Prettier for formatting and ESLint exclusively for logic errors. This evolution itself is instructive: **reduce scope over time** as the ecosystem matures and responsibilities are better distributed.

Prettier takes the philosophical opposite approach: **no wizard at all**. Their documented "Option Philosophy" explicitly states that options are frozen and no new formatting options will be accepted. Setup is `npm install --save-dev prettier && echo {} > .prettierrc`. This works because Prettier's value proposition is eliminating decisions, not enabling them.

For Stoke, the ESLint model suggests a powerful pattern: **use a single high-level intent question to gate entire configuration branches**, then ask progressively more specific questions within the selected branch.

---

## Config migration patterns every versioned schema needs

Tools that evolve their configuration format face a critical challenge: how to upgrade existing configs without breaking workflows. Three mature patterns emerge from the ecosystem.

**Terraform's state upgrader system** is the most rigorous. Each resource schema carries an explicit `SchemaVersion` integer. When Terraform detects that saved state has a lower version than the current schema, it automatically runs upgrade functions. The SDKv2 pattern applies upgraders sequentially (0→1→2), while the newer Framework pattern requires each upgrader to jump directly to the latest version (0→2, 1→2). This version field + upgrader function architecture is directly applicable to Stoke's config format — embedding a `version` field from day one enables automated migration forever.

**ESLint's migration from `.eslintrc` to flat config** demonstrates the tooling approach. The `@eslint/migrate-config` CLI transforms old config files by converting `env` to `globals`, string plugin references to imports, `extends` to direct composition, and `overrides` to separate config objects with `files` patterns. When automatic conversion isn't possible, it wraps legacy code in a `FlatCompat` compatibility bridge. The key lesson: **provide a compatibility layer alongside the migration tool** so teams can migrate incrementally.

**Next.js codemods** use AST transformations (jscodeshift) to rewrite actual application code across major versions. The `npx @next/codemod@latest upgrade` command detects current React/Next.js versions and suggests applicable transforms, letting users select which to apply interactively. Next.js 16 even introduced MCP-based AI-assisted migration. For Stoke, the implications are clear: **design configs as code** (not JSON/YAML) when possible, making AST-based migration tractable; include explicit version fields; and provide both automated migration tools and compatibility bridges.

---

## Monorepo wizards show two philosophies of scaffolding

**`create-turbo`** embodies extreme minimalism: it asks exactly **two questions** — where to create the project and which package manager to use. Everything else uses opinionated defaults (Next.js apps, shared UI package, shared ESLint and TypeScript configs). The `--example` flag provides the escape hatch, supporting 25+ templates including community-maintained ones for Angular, Gatsby, Vue/Nuxt, and more. For adding Turborepo to existing projects, there's no interactive flow — just manual installation of the `turbo` package and creation of `turbo.json`.

**`create-nx-workspace`** takes the opposite approach with a multi-step wizard that branches by stack selection. After naming the workspace, users choose a template (React, Angular, Node, minimal TypeScript, or custom). Each template triggers framework-specific questions: React asks about bundler (Vite/Webpack/Rspack), test runner, and stylesheet format; Node asks about framework (Express, Fastify, Koa, NestJS). The `nx init` command for existing projects is notably intelligent — it detects existing tooling (Vite, Jest, ESLint, Gradle) and suggests corresponding Nx plugins, picks up existing package.json scripts, and enables caching without restructuring.

A detail worth noting from Nx's source code: it includes **A/B testing infrastructure** for prompt messaging experiments and an `isAiAgent()` function for detecting AI agent callers and tailoring output accordingly — a forward-looking pattern as AI coding tools increasingly invoke CLI scaffolders programmatically.

---

## How AI coding tools build codebase understanding

AI-powered tools have developed distinct approaches to analyzing repositories, each offering patterns relevant to Stoke's stack detection goals.

**Cursor** builds a searchable index through **embedding-based semantic search**. When a project opens, Cursor splits files into syntactic chunks, generates embedding vectors, and stores them in Turbopuffer (a serverless vector database) with obfuscated file paths. A Merkle tree structure enables efficient change detection — only modified files need re-embedding, checked every 10 minutes. Queries combine nearest-neighbor search on embeddings with grep/ripgrep for exact matches. Cursor's `.cursor/rules/*.mdc` files use YAML frontmatter to define four rule types: `Always` (always applied), `Auto Attached` (triggered by file glob), `Agent Requested` (AI decides based on description), and `Manual` (user-invoked). This tiered rule activation system is directly relevant to Stoke's policy configuration.

**Aider** takes a lighter approach with its **repository map** — a concise representation of all classes, functions, and call signatures built using tree-sitter AST parsing. Aider applies a PageRank-style algorithm to rank symbols by reference frequency, dynamically selecting the most important symbols to fit within the token budget. This "structured summary, not full source" approach is significantly more efficient than full-file embedding.

**GitHub Copilot Workspace** follows a **specification-plan-implementation** pipeline: it generates a bulleted description of the current codebase state, proposes a target state, discovers relevant files through combined LLM reasoning and traditional code search, generates a file-by-file change plan, then implements it. Every step is editable and regeneratable by the human developer.

The common pattern across all tools: **project-specific configuration files** (`.cursor/rules/`, `.clinerules`, `.aider.conf.yml`, `.github/copilot-instructions.md`) that let teams encode context the tool can't detect automatically. For Stoke, the generated policy config serves this exact function — it becomes the persistent, version-controlled understanding of the project that AI agents consume.

---

## Progressive disclosure: five questions or fifty

The best CLIs present a minimal surface area by default and expand on demand. Three implementation patterns dominate.

**Flag-based bypass** (`--yes`, `--defaults`, `-y`) collapses all questions to zero by applying a default value map. The implementation is straightforward: check for the flag at startup, and if present, skip the prompt loop entirely. npm's `-y` still reads git remote and `.npmrc` config, so the "defaults" are intelligent, not just hardcoded. Many tools also check `stdin.isTTY` — when running in CI/CD (piped input), they automatically fall back to defaults or error rather than hanging on an invisible prompt.

**Conditional branching** (ESLint's model) dynamically shows or hides questions based on earlier answers. This is progressive disclosure within a single session — selecting "enforce code style" reveals style questions; selecting "find problems" hides them. The **80/20 rule** applies: design the basic question set for 80% of users, and gate advanced options behind explicit choices.

**Tiered modes** offer distinct "basic" and "advanced" paths. Some tools implement this with an `--advanced` flag or an interactive "Show advanced options?" prompt midway through the wizard. The most effective approach is **reasonable defaults with escape hatches**: generate a complete, working configuration from minimal input, then let users modify the generated config file for fine-tuning. This separates the "get started fast" experience from the "customize everything" experience entirely.

The CLI design guides — **clig.dev** and **12 Factor CLI Apps** — converge on key principles. Never require interactive input; allow everything via flags. Use stdout for output, stderr for messaging. Confirm before destructive actions. Suggest corrections for typos. Target sub-100ms response time. Respect `NO_COLOR` and `TERM=dumb`. Follow XDG-spec for config storage (`~/.config/myapp`). These aren't just aesthetic choices — they determine whether a CLI works in CI/CD, scripting, and AI agent contexts.

---

## Building wizard flows in Go with the Charm ecosystem

For Stoke's Go implementation, the Charm ecosystem provides the clear best path. **Huh** handles form/wizard flows declaratively, **Bubble Tea** provides the lower-level framework for complex TUI needs, and **Survey is archived** (April 2024) and should not be used for new projects.

**Huh** uses a builder-pattern API where forms are composed of groups (displayed as pages/steps), and each group contains fields (Input, Select, MultiSelect, Confirm, Text, FilePicker, Note). Groups provide **automatic page navigation** including back navigation — a feature that requires manual implementation in raw Bubble Tea. Validation is per-field via `.Validate()` methods with inline error display. Dynamic/conditional logic is supported through function-based field properties. The critical feature: `huh.Form` implements `tea.Model`, so it can be embedded directly in a Bubble Tea application for hybrid flows.

```go
form := huh.NewForm(
    huh.NewGroup(  // Page 1: Detection results
        huh.NewConfirm().Title("Detected Next.js — is this correct?").Value(&confirmed),
    ),
    huh.NewGroup(  // Page 2: Policy options
        huh.NewSelect[string]().Title("Testing framework").Options(...).Value(&testFramework),
    ),
)
```

For **multi-step wizard flows in raw Bubble Tea**, the recommended pattern is a state machine with step enum:

- Define steps as `iota` constants
- Store current step and all collected data in the model struct  
- Switch on current step in both `Update()` (for input handling) and `View()` (for rendering)
- Advance by incrementing the step counter; go back by decrementing
- Final step renders a summary of all collected data with a Confirm prompt

The Huh-in-Bubble Tea hybrid gives the best of both worlds: declarative forms for the configuration wizard sections, with full Bubble Tea control for custom UI elements like detection progress displays, tree-view file structure visualization, or animated scanning feedback.

---

## No tool has truly adaptive defaults, but team conventions fill the gap

The research found **no mainstream developer CLI that uses machine learning to adjust defaults based on usage telemetry**. The closest example is Grafana's Adaptive Telemetry, which analyzes metric usage patterns to recommend optimization — but this is observability, not CLI configuration. Tools like VS Code and npm collect telemetry that informs future release decisions (humans changing defaults based on aggregate data), but this is human-in-the-loop, not automatic adaptation.

What does exist is a robust ecosystem of **team-level and organizational defaults**. ESLint's shareable configs (`eslint-config-airbnb`, `@typescript-eslint/recommended`) let teams codify style decisions as installable packages. Nx supports custom presets where organizations publish their own `@my-org/nx-preset` that scaffolds projects with pre-configured standards. GitHub template repositories combined with Actions enable dynamic scaffolding. `.editorconfig` provides editor-agnostic formatting conventions. And companies routinely build internal `create-acme-app` CLIs that encode their specific conventions.

The **convention-over-configuration** philosophy — pioneered by Rails and now embodied by Next.js (file-based routing), Parcel (zero-config bundling), and others — represents the ultimate form of intelligent defaults: eliminate questions entirely by making the file system structure the configuration. For Stoke, this suggests that the deepest intelligence isn't in asking better questions but in **detecting conventions that already exist in the repository** and generating policy configs that honor them.

The practical preference-persistence mechanisms are well-established: npm uses `.npmrc` with `init.*` keys, git uses a three-tier config hierarchy (system → global → local), Yeoman uses `.yo-rc.json` with namespaced storage per generator, and Cargo uses `.cargo/config.toml`. For Stoke, storing user preferences in `~/.config/stoke/defaults.toml` (following XDG-spec) and project-level overrides in the generated config would follow established conventions.

---

## Conclusion: a detection-first architecture for Stoke

The most effective configuration wizard for Stoke should follow a **detect-confirm-extend** pipeline drawn from the patterns above. First, implement Vercel-style file detectors using a combinator system (`matchFile`, `matchContent`, `matchDependency`) with explicit priority ordering and `supersedes` relationships — this handles framework and tooling detection. Second, implement Nixpacks-style provider chains for language detection from manifest files (`package.json`, `go.mod`, `Cargo.toml`, `pyproject.toml`). Third, layer in cargo-style environment inference (git config for author info, directory name for project name, VCS detection).

Present detection results using the "Detected X — is this correct?" confirmation pattern rather than open-ended questions. Gate advanced configuration behind ESLint-style conditional branching: a single intent question ("Quick setup or customize?") controls whether 5 or 50 options appear. Implement the wizard in Huh for declarative form flows with automatic back navigation, embedded in a Bubble Tea application for custom detection-progress UI. Support `--yes` for zero-prompt operation in CI/CD and AI agent contexts. Embed a `version` field in the config schema from day one, with Terraform-style upgrader functions for future migration. And store user preferences in `~/.config/stoke/` so repeated use across projects gets progressively faster — not through ML, but through the proven pattern of persistent, user-controlled defaults.