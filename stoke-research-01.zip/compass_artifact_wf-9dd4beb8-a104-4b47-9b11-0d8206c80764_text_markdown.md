# The architecture of every major open-source AI coding harness in 2026

**The dominant pattern across all successful AI coding tools is a convergent architecture: an agentic ReAct loop executing structured tool calls against a sandboxed environment, with context compression keeping the conversation alive.** What separates the best from the rest is not the loop itself but the engineering of three subsystems: context management (how the tool selects and compresses relevant code), file editing strategy (how changes are applied reliably), and sandboxing (how destructive operations are contained). An 87K-line Go harness like Stoke should study these subsystems closely — the evidence strongly favors exact-string-replacement editing, tree-sitter-powered context selection, OS-level sandboxing, and hook-based quality enforcement. What it should avoid: JSON-wrapped code output, full-file rewrites as default, and over-reliance on complex agentic scaffolding that frontier models are rapidly making obsolete.

---

## Claude Code sets the architectural standard for CLI harnesses

Claude Code is a **512,000-line TypeScript** application (1,906 files, built with Bun, rendered via a custom Ink fork) running a three-phase agentic loop: **gather context → take action → verify results**. Its architecture, exposed via an accidental npm sourcemap leak on March 31, 2026, reveals the most mature harness engineering in the ecosystem.

**Context management** uses a five-layer compression architecture. MicroCompact trims old tool outputs at zero API cost. AutoCompact triggers at ~95% capacity, generating summaries of up to 20,000 tokens. Manual `/compact` performs full conversation compression with selective re-injection of recently accessed files. A circuit breaker stops after 3 consecutive compression failures — a bug where this retried indefinitely was burning **~250,000 API calls/day globally** before being patched. The system prompt is not monolithic but assembled from **110+ modular components** totaling 2,300–3,600 tokens, with tool definitions adding 14,000–17,600 tokens. Cache boundaries use `cache_control: {"type": "ephemeral"}` annotations for 90% cost reduction on repeated calls.

**File editing uses exact string replacement**, not diffs. The `Edit` tool takes `old_string` and `new_string` parameters, requiring a prior `Read` call and unique match. `MultiEdit` validates all edits before applying any, rolling back the entire batch on failure. External modification detection compares `mtimeMs` timestamps. This design trades expressiveness for reliability — the model must match exact whitespace from the `Read` output's `cat -n` format.

**The tool catalog spans ~40–50 tools** across read-only (Read, Glob, Grep, LS, WebSearch, WebFetch), write (Edit, MultiEdit, Write), execution (Bash with 23 security checks), and orchestration (Agent/Task for subagents, TodoWrite for task management, TeammateTool for inter-agent communication). Security uses a four-layer defense: tool availability → permission gate → PreToolUse hooks → OS sandbox. The **hooks system** (18 events, 4 types) is deterministic — always fires, unlike CLAUDE.md instructions which are probabilistic. PreToolUse hooks can modify tool inputs before execution, invisible to the model.

**Sub-agent architecture** offers three execution models: Fork (background, isolated process), Teammate (parallel agents coordinating via message passing), and Worktree (agents in separate git worktrees for true parallel code modification). The parent explicitly chooses model tier per subagent — there is no automatic routing. An unreleased **KAIROS** daemon mode (referenced 150+ times in source) enables autonomous background work, and **ULTRAPLAN** provides 30-minute thinking budgets on remote hardware.

---

## Aider proves that plain text parsing beats function calling

Aider (Python, by Paul Gauthier) makes a deliberately contrarian architectural choice: **it does not use function calling or structured JSON output**. Benchmarks in July 2023 and August 2024 showed all tested models scored worse with JSON-wrapped responses. The root cause: escaping code in JSON (e.g., nested quotes and backslashes) distracts models from the coding task itself.

**The SEARCH/REPLACE block format** is Aider's core innovation. The model outputs blocks delimited by `<<<<<<< SEARCH`, `=======`, and `>>>>>>> REPLACE` markers. The `EditBlockCoder` applies these through a **multi-strategy cascade**: exact match → whitespace normalization → ellipsis expansion → fuzzy matching via `difflib.SequenceMatcher`. A cross-file fallback tries failed matches against all other files in context. Four edit formats exist — `diff` (SEARCH/REPLACE), `whole` (full file, for weak models), `udiff` (unified diff without line numbers), and `diff-fenced` (for Gemini).

**The repo-map system** uses tree-sitter to extract AST tags (definitions and references) from 130+ languages, then builds a NetworkX MultiDiGraph where nodes are files and edges represent cross-file references. **PageRank with personalization** ranks files by relevance to the current conversation. Edge weights multiply by 10× for mentioned identifiers, 50× for files in the chat, and 0.1× for private symbols. The ranked output is token-budgeted (default 1,024 tokens) via binary search, formatted hierarchically showing function signatures and class definitions with ellipsis for omitted code.

**The architect/editor pipeline** splits inference into two stages: an architect model (strong reasoning, no format constraints) describes the solution, and an editor model (format-compliant) translates it into SEARCH/REPLACE blocks. This separation emerged because OpenAI's o1 models had excellent reasoning but poor structured output. Benchmarks showed same-model pairing (Sonnet as both architect and editor) often outperformed cross-model configs.

Aider's SWE-bench Lite score of **26.3%** (May 2024 SOTA) used a simple retry strategy — alternating GPT-4o/Opus for up to 6 attempts. The polyglot benchmark covers 225 exercises across 6 languages, with GPT-5 scoring **88.0%**. Critically, Aider writes **50–70% of its own code** in recent releases.

---

## OpenAI Codex CLI brings the most sophisticated sandboxing

Codex CLI was **rewritten entirely in Rust** (95.9% of codebase) from an original TypeScript prototype. The legacy TS code remains as an npm wrapper bundling the Rust binary. The architecture uses Ratatui for TUI rendering (OpenAI hired the Ratatui maintainer full-time) and Bazel for build orchestration.

**The sandbox is the most sophisticated in any CLI coding agent.** On Linux, it uses bubblewrap with private user/PID/network namespaces, the entire filesystem mounted read-only by default, explicit writable paths for the workspace, `.git` and `.codex` re-applied as read-only even under writable roots, `PR_SET_NO_NEW_PRIVS`, and seccomp network filters at the syscall level. A managed proxy mode creates a TCP-to-UDS-to-TCP bridge for controlled network access, then blocks new `AF_UNIX` and `socketpair` syscalls to prevent sandbox escape. On macOS, dynamically generated Seatbelt SBPL scripts provide per-mode policies. On Windows, restricted tokens with private desktop isolation (`Winsta0\Default`). Hardcoded banned commands include all shell interpreters (`python -c`, `ruby -e`, `bash -c`, `sudo`).

**File editing** uses `apply_patch` with a formal **Lark grammar** parser for structured validation before application. Two modes: freeform text diffs (most common) and JSON-structured schema. The system prompt explicitly teaches the model the exact patch format. The model is RL-trained to produce patches matching this format.

**Session persistence** uses SQLite-backed threads that survive process restarts and can be resumed, forked, archived, or rolled back — a fundamental difference from Claude Code's in-memory sessions. A two-phase AI-driven memory pipeline extracts patterns from up to 5,000 previous threads using `gpt-5.1-codex-mini`, then consolidates with `gpt-5.3-codex` under a global lock. Context compaction delegates to the Responses API's `/responses/compact` endpoint, which returns encrypted opaque items carrying forward key state.

**GPT-5.3-Codex** achieves **78.2% on SWE-Bench Pro** (multi-language: Python, Go, TypeScript, JavaScript) and 78.0% on SWE-Bench Verified. The `codex-spark` variant runs on Cerebras hardware at **15× faster generation** with comparable scores. Codex CLI exclusively uses the Responses API — Chat Completions format produces a hard error.

---

## Cursor's secret weapons are speculative edits and online RL

Cursor is a **direct VS Code fork** (~7 million lines, ~25,000 files) by Anysphere, not a plugin. Its backend runs primarily TypeScript for business logic with **Rust for all performance-critical components**, deployed as a large monolith on AWS (CPU) and Azure (GPU inference) using tens of thousands of H100s.

**Speculative edits** are Cursor's core innovation for file editing. Because LLMs are terrible at generating accurate diffs (failing **≥40% of the time** per cofounder Aman Sanger), Cursor chose full-file rewrites with a speculative decoding optimization: the original source code serves as "draft tokens" since most output is unchanged code. The system chunks the original file, feeds chunks as speculated output, processes in parallel, and only generates new tokens where the model diverges. A fine-tuned **Llama-3-70B** "fast apply" model achieves ~1,000 tokens/sec (**13× speedup** over vanilla inference), deployed on Fireworks AI.

**Tab autocomplete** uses a custom MoE model retrained via online reinforcement learning **every 90 minutes** from live user data, with new checkpoints deployed multiple times daily at **400M+ daily requests**. The reward structure: +0.75 for accepted suggestions, −0.25 for rejected, 0 for silence. This produced **21% fewer suggestions but 28% higher acceptance rate**. An internal Cursor team member called it "the first large-scale demonstration of the advantage of real-time reinforcement learning."

**Codebase indexing** uses tree-sitter for semantic chunking, a custom embedding model, and **Turbopuffer** (serverless vector DB backed by S3) for storage. File paths are obfuscated client-side using secret-key hashing before upload — only embeddings and masked metadata persist in the cloud. Merkle tree synchronization every ~3–5 minutes identifies changed files via hash mismatch traversal. A fine-tuned **7B CodeLlama reranker** processes up to 500,000 tokens per query.

**Composer 2** (released March 2026) is built on **Kimi K2.5** (Moonshot AI) as base with Cursor's continued pretraining + RL accounting for ~75% of differentiation. It achieves ~250 tokens/sec (4× faster than GPT-5/Claude equivalents). When the 200K-token context fills, Composer 2 **compresses its own context to ~1,000 tokens** as part of the RL reward function — reducing compaction errors by 50% versus prompt-based summarization. **Priompt**, their open-sourced prompt management framework, uses JSX-like components with priority scores and binary search for optimal token budget allocation.

---

## Cline and Roo Code pioneer human-in-the-loop agentic coding

Cline (TypeScript VS Code extension, 58K stars) and its fork Roo Code (22K stars) share ~80% of their codebase but diverge on philosophy. Both use a **decoupled architecture** separating the agentic core from the host environment via a `HostProvider` abstraction, with a React-based webview frontend communicating through a dual protocol: legacy `postMessage` and newer **gRPC-over-postMessage** for type-safe streaming with cancellation.

**The human-in-the-loop approval model** is Cline's defining architectural choice. By default, every file write, terminal command, and destructive action requires explicit user confirmation via `Task.ask()`, which suspends execution until the user responds. This makes Cline ~2× slower than Cursor on comparable tasks (90s vs 45s) but provides maximum safety on the real filesystem — Cline has **no sandboxed execution environment**.

**File editing** uses two approaches: `write_to_file` (whole-file replacement, safer but token-heavy) and `replace_in_file` (SEARCH/REPLACE blocks). The diff application algorithm in `constructNewFileContent` cascades through exact match → whitespace-trimmed fallback → block anchor fuzzy matching. If matching fails 3 times, the system falls back to whole-file rewrite. Roo Code adds `apply_diff` as its primary editing tool with multi-block strategies achieving **~30% token savings**.

**Roo Code's mode system** is its key differentiator: Code (all tools), Architect (read-only), Ask (no filesystem access), Debug (read + command), and unlimited Custom modes with configurable tool groups and file restrictions. Each mode remembers its last-used model ("sticky models"), enabling per-task model routing — Gemini 2.5 for Architect, Claude Sonnet for Code.

**Cline pioneered MCP integration** in the VS Code ecosystem, including an MCP Marketplace for browsing and installing community servers, and the ability to ask Cline to create MCP servers from scratch. Both tools create **checkpoints after every individual tool call** via shadow git repositories (`.cline-checkpoints/` or `.roo-checkpoints/`), enabling granular rollback to any intermediate state.

---

## SWE-agent proved that interface design matters as much as model capability

SWE-agent (Python, Princeton NLP, NeurIPS 2024) introduced the **Agent-Computer Interface (ACI)** concept: LM agents are a new category of end users requiring purpose-built interfaces, analogous to how humans need IDEs. The ACI specifies available commands, feedback format, and history management.

**Ablation studies quantified every design decision.** The custom `edit` command (line-range replacement with automatic linting) provided +7.7 percentage points over raw bash editing. The **100-line file viewer window** was optimal — 30-line viewers lost 3.7 pp, full-file viewers lost 5.3 pp. History compression (keeping only the last 5 observations full, collapsing older ones to single lines) gained 3.0 pp. Post-edit linting with automatic rollback of syntax-errored edits gained 3.0 pp. Total ACI improvement: **+10.7 pp over shell-only** (64% relative increase).

The original system scored **12.47% on SWE-bench Full** and **18.0% on SWE-bench Lite** with GPT-4 Turbo (May 2024). Version 1.0 (February 2025) achieved SOTA on SWE-bench Verified with Claude 3.7 Sonnet. But the most significant finding came from **mini-SWE-agent** (July 2025): just **100 lines of Python** using only bash as a tool achieved **65%+ on SWE-bench Verified**. The team explicitly stated: "As LMs have become more capable, a lot of [the ACI] is not needed at all." SWE-agent is now in **maintenance-only mode**, superseded by mini-swe-agent. This is the single most important finding for harness architecture: **as models improve, elaborate scaffolding yields diminishing returns.**

Failure analysis on the original system: 52.0% incorrect implementations, 23.4% failed edit cascades, 12.9% failed to find edit location, 4.8% gave up prematurely. Agents succeed quickly and fail slowly — successful runs complete earlier and cheaper, suggesting that increasing budgets has diminishing returns.

---

## Web-based tools trade flexibility for instant gratification

**Bolt.new** runs a complete Node.js environment inside the browser via **WebContainers** — 7 years of engineering producing a WASM-based runtime with a custom Rust filesystem on SharedArrayBuffer, a Rust micro-kernel for process management, virtual localhost via Service Workers, and a custom TypeScript shell (JSH). npm installs finish in **<500ms** from CDN-cached layers. The entire app flows through a single LLM call with structured `<boltArtifact>` tags — no multi-model orchestration.

**Lovable** (formerly GPT Engineer, **$100M ARR in 8 months**, ~8M users) uses cloud sandboxes on fly.io (~4,000+ instances) with a multi-model strategy: GPT-4 Mini for fast context hydration, Claude Sonnet 4.5 for generation. The team **explicitly rejected complex agentic architectures** after finding they had lower accuracy, confused users, and were slower. A custom Vite plugin assigns stable IDs to JSX components at compile-time, enabling visual element selection that traces back to exact source locations.

**v0** by Vercel evolved from a component generator to a full development environment. Since February 2026, **Vercel Sandbox** (lightweight Linux VMs) replaced browser-based previews, running full applications exactly as production. Deep integration with shadcn/ui, Next.js, and Vercel's deployment infrastructure creates the strongest prototype-to-production pipeline, at the cost of ecosystem lock-in.

All three tools converge on the same stack (**React, TypeScript, Tailwind CSS, shadcn/ui, Vite**) and face the same "70/30 problem": they deliver ~70% of a production app fast, but the remaining 30% — complex business logic, edge cases, security — requires developer intervention. They are fundamentally **application generators**, not coding assistants for existing codebases.

---

## Everything-Claude-Code formalizes harness engineering as a discipline

ECC (**82K–140K+ GitHub stars**, MIT license) is not a standalone tool but a **configuration and orchestration layer** that installs into `~/.claude/` (and equivalent directories for other tools). Created by Affaan Mustafa after winning the Anthropic × Forum Ventures hackathon, it ships **38 specialized agents, 156 skills, 72 command shims**, and works across Claude Code, Codex, Cursor, and others.

The four-layer architecture separates concerns: User Interaction (57+ slash commands), Intelligence (agents with YAML frontmatter specifying model tier and tool access), Automation (hooks at 8 lifecycle events), and Learning (instinct-based pattern extraction with confidence scores). **NanoClaw v2** handles model routing within the harness, defaulting to Sonnet for ~80% of tasks with Haiku for subagents and Opus for deep reasoning. Auto-compaction triggers at 50% context (versus Claude Code's 95%).

Hook-based quality enforcement runs linters and type-checkers via PostToolUse hooks on every file edit, blocks dangerous operations via PreToolUse hooks (exit code 2 = block action), and extracts patterns at session end via Stop hooks. **AgentShield** integration provides 102 security rules covering OWASP Top 10. The continuous learning system observes every tool interaction, building "instincts" with confidence scores; after 3+ related instincts, `/evolve` aggregates them into reusable skills.

The most common Reddit criticism: **complexity relative to need** — many developers report that a well-crafted 60–200 line CLAUDE.md file covers 80% of what they need. This mirrors the mini-SWE-agent finding: sophisticated scaffolding has diminishing returns as models improve.

---

## What Stoke should adopt and what it should avoid

The cross-cutting analysis reveals clear patterns. Features shared by every successful harness worth studying:

- **Exact-string or line-range editing with validation.** Claude Code's `old_string → new_string`, Aider's SEARCH/REPLACE cascade, Codex CLI's Lark-grammar-validated patches, and SWE-agent's line-range edit with automatic linting all converge on the same principle: small, verifiable edits with fallback strategies. Whole-file rewrites are reserved for new files or last-resort fallbacks. Stoke should implement a cascading edit strategy — exact match → normalized whitespace → fuzzy match — with post-edit linting that rejects syntax-errored edits automatically.

- **Tree-sitter-powered context selection.** Aider's PageRank-ranked repo map, Continue.dev's AST-aware chunking, Cursor's semantic chunking, and Cline's `list_code_definition_names` all use tree-sitter for language-aware code understanding. Stoke, being Go-based, should leverage go-tree-sitter bindings to build a repo map that extracts function signatures, type definitions, and cross-file references, ranked by relevance to the current task.

- **OS-level sandboxing.** Codex CLI's bubblewrap + seccomp (Linux), Seatbelt (macOS), and restricted tokens (Windows) represent the gold standard. Claude Code adopted similar approaches in 2026. Stoke's Go runtime is well-suited for implementing namespace-based sandboxing via direct syscall interfaces — this is one area where Go has a natural advantage over TypeScript/Node.js.

- **Hook-based quality enforcement.** Claude Code's 18-event hook system and ECC's 8-event lifecycle hooks both demonstrate that deterministic quality gates outperform probabilistic instruction-following. Stoke should implement PreToolUse, PostToolUse, and SessionEnd hooks at minimum, with exit-code-based blocking semantics.

- **Aggressive context compression.** Claude Code's five-layer compression, Codex CLI's server-side compaction, and Cursor's RL-trained self-compression all address the same problem: context windows fill up and quality degrades. Stoke should implement at least three tiers — tool-result trimming, conversation summarization, and full compaction — with configurable thresholds.

Patterns proven **ineffective** or counterproductive:

- **JSON-wrapped code output.** Aider's extensive benchmarking showed all tested models scored worse with JSON responses. Stoke should parse plain-text model output, not force structured JSON for code edits.

- **Over-engineered ACI/scaffolding.** Mini-SWE-agent's 65%+ on SWE-bench Verified with 100 lines of Python and bash-only tools definitively proves that elaborate tool interfaces have diminishing returns as models improve. Stoke's 103 internal packages should be scrutinized for scaffolding that frontier models no longer need.

- **Approval-as-default without sandboxing.** Cline's every-action-requires-approval model makes it ~2× slower than alternatives. The better pattern (Codex CLI, Claude Code) is OS-level containment that makes auto-approval safe, with user confirmation reserved for sandbox-escaping operations.

- **Full-file rewrites as default editing strategy.** Cursor found LLMs fail ≥40% of the time on diffs, so they chose full-file rewrites plus speculative decoding to recover speed. But this requires a custom fast-apply model. Without that investment, Stoke should follow the Aider/Claude Code pattern of exact-string replacement with cascading fallbacks.

- **Complex multi-agent orchestration for simple tasks.** Lovable explicitly rejected multi-agent architectures after finding they had lower accuracy, confused users, and were slower. Stoke should use subagents sparingly — primarily for parallel file exploration and verification, not for decomposing straightforward coding tasks.

The state of the art for agentic coding in mid-2026 is clear: **the model provides intelligence, the harness provides control.** But the balance is shifting rapidly toward the model. The most important architectural decision Stoke can make is designing its 103 packages for graceful deprecation — every piece of scaffolding should be removable as models improve, following mini-SWE-agent's lesson that today's essential infrastructure may be tomorrow's unnecessary complexity.

---

## Conclusion

Three insights emerge that weren't obvious before this analysis. First, **there is remarkable convergence** across tools built by different teams with different languages and philosophies — tree-sitter for context, exact-string replacement for editing, OS-level sandboxing for safety, hooks for quality. This convergence suggests these are discovered optima, not arbitrary choices. Second, **the most commercially successful tools (Cursor at $1B+ ARR, Lovable at $100M ARR) invest heavily in custom model training** — speculative edits, online RL, custom embedding models — rather than just scaffolding around frontier APIs. A pure-harness approach hits a ceiling that only custom models break through. Third, **the research trajectory is toward simplification**: SWE-agent's team themselves demonstrated that 100 lines of bash-only code can match what took thousands of lines of ACI engineering 18 months earlier. Stoke should architect for a future where its harness does less, not more — where its value comes from exceptional context selection, reliable file editing, and robust safety guarantees, not from compensating for model limitations that are disappearing quarter by quarter.