# Dependency management for polyglot monorepos

**The hardest problem in modern software engineering isn't writing code — it's managing the code you didn't write.** A typical npm install pulls in **79 transitive dependencies and trusts 39 maintainers**, while attackers published over **454,000 malicious npm packages in 2025 alone**. For teams running polyglot monorepos with Go, Rust, and TypeScript, dependency management demands a unified strategy spanning automated updates, supply chain security, upgrade orchestration, and a deliberate philosophy about what to depend on at all. This report covers ten critical areas with production-grade configurations, specific tooling, and decision frameworks used by teams at companies like Google, Uber, Monzo, and Stripe.

---

## 1. Renovate dominates Dependabot for polyglot monorepos

The choice between Renovate and Dependabot is decisive for polyglot monorepos, and **Renovate wins on nearly every dimension**. It auto-detects 90+ package managers (Go modules, Cargo.toml, npm/yarn/pnpm, Dockerfiles, GitHub Actions, Terraform), supports preset-based grouping via `group:monorepos`, and offers `automergeType: "branch"` — which silently merges updates without creating PRs, eliminating noise entirely. Dependabot supports ~30 ecosystems, requires explicit `directory` entries for each manifest location, has no built-in auto-merge, and has documented issues with npm workspace lockfile updates.

The critical differences that matter in practice: Renovate's **Dependency Dashboard** (a GitHub issue tracking all pending updates), **`minimumReleaseAge`** (wait N days before proposing updates as a supply chain defense), **shared config presets** across an organization, and **regex managers** for extracting versions from arbitrary files. Dependabot offers none of these. Some teams use a hybrid: Dependabot for built-in GitHub security alerts plus Renovate for regular version updates.

**Production Renovate configuration for a Go + Rust + TypeScript monorepo:**

```json5
// renovate.json5
{
  "$schema": "https://docs.renovatebot.com/renovate-schema.json",
  "extends": [
    "config:recommended",
    "group:monorepos",
    "group:recommended",
    ":separateMajorReleases",
    "schedule:nonOfficeHours"
  ],
  "labels": ["dependencies"],
  "prConcurrentLimit": 10,
  "prCreation": "status-success",
  "assigneesFromCodeOwners": true,
  "lockFileMaintenance": {
    "enabled": true,
    "automerge": true,
    "schedule": ["before 4am on monday"]
  },
  "packageRules": [
    {
      "description": "Group all non-major updates together",
      "matchUpdateTypes": ["minor", "patch", "digest"],
      "groupName": "non-major dependencies",
      "groupSlug": "non-major"
    },
    {
      "description": "Automerge non-major for stable (>=1.0) packages",
      "matchUpdateTypes": ["minor", "patch"],
      "matchCurrentVersion": "!/^0/",
      "automerge": true,
      "automergeType": "branch"
    },
    {
      "description": "Automerge devDependencies",
      "matchManagers": ["npm"],
      "matchDepTypes": ["devDependencies"],
      "automerge": true,
      "automergeType": "branch"
    },
    {
      "description": "Require dashboard approval for Go major updates",
      "matchManagers": ["gomod"],
      "matchUpdateTypes": ["major"],
      "dependencyDashboardApproval": true
    },
    {
      "description": "Require dashboard approval for Rust major updates",
      "matchManagers": ["cargo"],
      "matchUpdateTypes": ["major"],
      "dependencyDashboardApproval": true
    },
    {
      "description": "Pin GitHub Actions by digest",
      "matchManagers": ["github-actions"],
      "pinDigests": true
    },
    {
      "description": "Wait 3 days before proposing updates",
      "matchPackageNames": ["*"],
      "minimumReleaseAge": "3 days"
    }
  ]
}
```

**Equivalent Dependabot configuration** requires significantly more verbosity and a separate GitHub Actions workflow for auto-merge:

```yaml
# .github/dependabot.yml
version: 2
updates:
  - package-ecosystem: "gomod"
    directory: "/"
    schedule: { interval: "weekly", day: "monday", time: "04:00" }
    groups:
      go-minor-patch:
        update-types: ["minor", "patch"]
  - package-ecosystem: "cargo"
    directory: "/"
    schedule: { interval: "weekly", day: "monday", time: "04:00" }
    groups:
      rust-minor-patch:
        update-types: ["minor", "patch"]
  - package-ecosystem: "npm"
    directory: "/"
    schedule: { interval: "weekly", day: "monday", time: "04:00" }
    groups:
      ts-production:
        dependency-type: "production"
        update-types: ["minor", "patch"]
      ts-dev:
        dependency-type: "development"
        patterns: ["*"]
  - package-ecosystem: "github-actions"
    directory: "/"
    schedule: { interval: "weekly" }
    groups:
      actions-all:
        patterns: ["*"]
```

Dependabot auto-merge then requires a separate workflow using `dependabot/fetch-metadata` and `gh pr merge --auto`, adding operational complexity Renovate handles natively.

---

## 2. Pin everything, enforce lockfiles everywhere

The production consensus across all three ecosystems is **pin versions + commit lockfiles + enforce frozen installs in CI**. Every ecosystem has a "frozen lockfile" command, and these should be non-negotiable in CI pipelines.

**npm/pnpm/Yarn:** For applications, use `save-exact=true` in `.npmrc` to pin exact versions, ensuring every change is explicit and testable via Renovate PRs. For libraries, use caret (`^`) ranges to avoid forcing version duplication in consumers. The lockfile is the source of truth:

| Package Manager | CI Command | Behavior |
|---|---|---|
| npm | `npm ci` | Deletes `node_modules`, installs exactly from lockfile, fails on mismatch |
| pnpm | `pnpm install --frozen-lockfile` | Fails if lockfile would change (auto-enabled in CI) |
| Yarn Berry | `yarn install --immutable` | Fails if lockfile would be modified |

**Go modules** use Minimum Version Selection — there are no ranges, only exact versions in `go.mod`. The `go.sum` file contains cryptographic checksums verified against Google's `sum.golang.org` checksum database. CI enforcement uses `-mod=readonly` (default since Go 1.16), which prevents build commands from modifying `go.mod` or `go.sum`. Go 1.22+ added `go mod tidy -diff` to preview changes without applying them.

**Cargo (Rust)** updated its longstanding guidance in August 2023: the Cargo team now recommends **committing `Cargo.lock` as the starting point for all project types**, including libraries. `cargo new` no longer adds `Cargo.lock` to `.gitignore`. In CI, use `cargo build --locked` (fails if resolution would differ from lockfile) or `cargo build --frozen` (same plus prevents network access).

**Unified CI lockfile enforcement:**

```yaml
# Polyglot lockfile check job
steps:
  - run: pnpm install --frozen-lockfile      # TypeScript
  - run: go mod tidy -diff && go mod verify  # Go
  - run: cargo check --locked                # Rust
```

Additional security: use `lockfile-lint` to validate that npm lockfiles only reference expected registries (`--allowed-hosts npm --validate-https`). **pnpm is structurally more resistant to lockfile injection** than npm because it doesn't store tarball URLs that can be maliciously redirected.

---

## 3. Evaluating dependencies before you adopt them

Dependency risk assessment should happen before `npm install`, not after a CVE lands. A mature evaluation process uses multiple tools providing complementary signals.

**Socket.dev** detects supply chain attacks through behavioral analysis rather than waiting for CVE assignment. It identifies **70+ risk signals** including typosquatting (via Levenshtein distance analysis), install scripts, obfuscated code, network access, environment variable reads, and shell command execution. This catches attacks pre-CVE — a critical gap that traditional scanners miss.

**OpenSSF Scorecard** evaluates open source project health across checks like branch protection, code review practices, CI testing, fuzzing, SAST, signed releases, and vulnerability response. Projects scoring below 7/10 warrant extra scrutiny. It scans 1M+ repos weekly with results queryable via BigQuery, and CISA recognizes it as a recommended evaluation tool.

**govulncheck** (Go) is the most sophisticated ecosystem-specific scanner because it performs **reachability analysis** — constructing a call graph from `main.main` to determine whether vulnerable code paths are actually reachable. This dramatically reduces false positives compared to manifest-only scanners. **cargo-audit** scans `Cargo.lock` against the RustSec Advisory Database, while **cargo-vet** (created by Mozilla, adopted by Google and Fastly) ensures all third-party crates have been audited by a trusted entity, supporting delta audits and imported audit attestations from organizations like Mozilla and Google.

**deps.dev** (Google Open Source Insights) provides free API access to dependency graphs, vulnerability data, license information, and SLSA provenance across npm, Go, Cargo, Maven, and PyPI — covering 5M+ packages.

**Pre-adoption checklist:**

- **Maintenance**: Active commits in last 90 days? Multiple maintainers? (bus factor ≥ 2)
- **Security posture**: OpenSSF Scorecard ≥ 7? Branch protection enabled? 2FA enforced?
- **Behavioral signals**: Any install scripts? Network access? Obfuscated code? (Socket.dev)
- **Dependency depth**: How many transitive deps? (`npm ls --all`, `cargo tree`, deps.dev graphs)
- **Provenance**: Published with npm provenance? Signed releases?
- **License**: Compatible? Check with `cargo-deny`, `license-checker`, or `go-licenses`
- **Alternatives**: Can stdlib or a smaller package serve the same purpose?

---

## 4. Testing dependency updates without breaking production

Dependency update PRs require the same rigor as feature PRs — full test suites, type checking, build verification, and security scanning. The key CI pattern for polyglot monorepos uses **path filtering** to run only the relevant language checks when specific files change:

```yaml
# Using dorny/paths-filter to detect which ecosystems changed
changes:
  go: ['go.mod', 'go.sum', '**/*.go']
  rust: ['Cargo.toml', 'Cargo.lock', '**/*.rs']
  ts: ['package.json', 'pnpm-lock.yaml', '**/*.ts']
```

Each ecosystem then runs its full verification pipeline: `tsc --noEmit` for TypeScript type checking, `go vet ./...` for Go static analysis, `cargo clippy --all-targets -- -D warnings` for Rust linting (with `RUSTFLAGS="-Dwarnings"` to promote all warnings to errors). Build verification is explicit — `go build -mod=vendor ./...`, `cargo build --workspace --all-targets`, `pnpm build`.

**Auto-merge safety requires all of these gates passing**: unit tests, integration tests, type checking, linting, and security scanning. The safest auto-merge policy is patch updates for stable (≥1.0) packages with `automergeType: "branch"` in Renovate — updates merge silently, and a PR is created only if tests fail. **Major updates should never auto-merge** and should require dashboard approval or manual review.

**Canary deployment** for dependency updates follows the same pattern as feature releases: deploy to a small percentage of traffic, monitor error rates and latency, then gradually increase. Uber's cross-service deployment orchestration tracks large-scale commits through a state machine, where signals from early-deployed services gate deployment to remaining services. For rollback, maintain immutable build artifacts — reverting means promoting the previous artifact rather than rebuilding.

---

## 5. Vendoring is alive for compliance, dead for most teams

Vendoring — committing all dependency source code into your repository — serves specific purposes: **air-gapped builds**, **audit requirements** (SOC2, FedRAMP), and **hermetic reproducibility**. Kubernetes still vendors its Go dependencies as of 2025. For most teams, however, lockfiles plus content-addressed verification have replaced vendoring.

**Go vendoring** is the most mature. `go mod vendor` creates a `vendor/` directory, and `GOFLAGS=-mod=vendor` ensures all commands use it. CI verification is straightforward: `go mod vendor && git diff --exit-code vendor/`. Go's checksum database (`sum.golang.org`) provides cryptographic verification even without vendoring.

**Cargo vendoring** works via `cargo vendor`, which outputs `.cargo/config.toml` configuration to redirect crate resolution to the vendored directory. **Critical polyglot monorepo caveat**: Go and Rust both default to `vendor/` — use `cargo vendor vendor-rust/` and keep Go in `vendor/` to avoid conflicts.

**npm vendoring** is less common. Options include `npm pack` to create auditable tarballs installed via `"dependency": "file:vendor/pkg-1.0.0.tgz"`, Verdaccio as a local caching proxy, or Yarn's offline mirror. For enterprise air-gapped environments, Verdaccio is the most robust approach.

| Factor | Vendoring | Lockfiles only |
|---|---|---|
| Repo size | Large (all dependency source) | Small |
| Offline builds | Built-in | Requires proxy/cache |
| Audit visibility | All code in repo | Requires separate tools |
| Update complexity | High (re-vendor + review diffs) | Low (automated PRs) |

**Decision**: Vendor if you have regulatory audit requirements or air-gapped build infrastructure. Otherwise, commit lockfiles, enforce frozen installs in CI, and use checksum verification.

---

## 6. Supply chain attacks demand defense in depth

The npm ecosystem faces an existential supply chain security crisis. The **September 2025 Shai-Hulud worm** compromised 18 packages including `chalk`, `debug`, and `ansi-styles` — collectively downloaded **2.6 billion times per week** — and self-propagated using stolen npm tokens across 500+ additional packages. The **March 2026 Axios compromise** affected a package with 100M+ weekly downloads, attributed to North Korean APT actors. Attacks now routinely target CI environments specifically, detecting `GITHUB_ACTIONS` and `GITLAB_CI` environment variables before executing payloads.

**Dependency confusion prevention** requires scoped packages and registry configuration. Alex Birsan's 2021 research demonstrated the attack against 35+ organizations including Apple and Microsoft. Prevention is straightforward:

```ini
# .npmrc — scope internal packages to private registry
@mycompany:registry=https://registry.mycompany.internal/
//registry.mycompany.internal/:_authToken=${NPM_TOKEN}
```

Additionally, **claim your organization's scope on the public npm registry** so no external party can publish under it. This single configuration prevents the most common supply chain attack vector.

**pnpm v10 provides the strongest default security posture** of any JavaScript package manager. Lifecycle scripts (postinstall/preinstall) are **disabled by default** — the primary execution vector for npm malware. Key security configuration:

```yaml
# pnpm-workspace.yaml
allowBuilds:
  esbuild: true
  fsevents: true
strictDepBuilds: true          # Block unapproved build scripts in CI
blockExoticSubdeps: true       # Prevent transitive deps from using git/tarball URLs
minimumReleaseAge: 1440        # 24-hour quarantine for new releases
trustPolicy: no-downgrade      # Block packages whose trust level decreased
```

**SLSA (Supply-chain Levels for Software Artifacts)** provides a graduated framework. Level 1 requires documented build processes. Level 2 requires hosted builds with **signed provenance** — achievable via `npm publish --provenance` on GitHub Actions. Level 3 requires **isolated, non-reusable build environments** with unforgeable provenance. Over 16,000 npm packages now publish with provenance, and `npm audit signatures` verifies provenance before installation.

**Lockfile injection attacks** exploit the fact that lockfiles contain registry URLs. The January 2026 CVE-2025-69263 in pnpm revealed that HTTP tarball dependencies were stored without integrity hashes, allowing servers to serve different content on each request. Mitigation: always use `npm ci` / `pnpm install --frozen-lockfile`, validate lockfiles with `lockfile-lint`, and review lockfile changes in PRs as carefully as code changes.

---

## 7. Major upgrades need staged rollout, not big-bang

Upgrading a major dependency across a monorepo with 10+ services demands the same deployment discipline as a production release. The **Monzo pattern** — used across their 2,800 Go microservices — is the gold standard for staged migration:

1. **Wrap the old library** in an abstraction layer before touching anything else
2. **Block new dependencies** on the old library using semgrep CI checks to prevent regression
3. **Add the new library** behind the wrapper, initially disabled via dynamic configuration
4. **Migrate call-sites** — automated (codemods) for the 80% high-frequency patterns, manual for the 20% long-tail
5. **Enable gradually** via feature flags, monitoring error rates at each stage
6. **Clean up** old implementation once fully migrated

**Feature flags are non-negotiable** for major upgrades. Tools like LaunchDarkly, Unleash, or Flagsmith enable percentage-based rollouts (1% → 10% → 50% → 100%) with instant rollback capability — faster than redeployment. Monzo's dynamic config service enables immediate rollback without any deployment.

**Uber's cross-service deployment orchestration** handles the reality that ~0.3% of Go monorepo commits affect 1,000+ services. A state machine tracks each large-scale commit through deployment stages, where gating conditions include prior stage completion, soak time, deployment window constraints, and alert monitoring.

**Migration automation** has matured significantly. **jscodeshift** (Meta) handles AST-based JavaScript/TypeScript transformations. **ts-morph** provides TypeScript-aware manipulation with full type information. The **Codemod.com platform** provides a registry of community codemods with a unified CLI (`npx codemod <name>`). AI-assisted codemod generation is increasingly practical — while vanilla LLM accuracy is ~26%, refinement iterations improve results significantly, and AI coding assistants have been used successfully for migrations like Next.js 14→16 across 120+ files.

---

## 8. Framework upgrades follow predictable patterns

Each ecosystem has its own upgrade mechanics, common breakages, and automated tooling. Understanding these patterns turns a potentially chaotic process into a repeatable playbook.

**React 18→19** removed `PropTypes` runtime checks, `defaultProps` on function components, `ReactDOM.render`/`hydrate`, string refs, legacy Context API, and `react-test-renderer/shallow`. The bridge strategy is to upgrade to **React 18.3 first** (identical to 18.2 but adds deprecation warnings), then run official codemods:

```bash
npx codemod@latest react/19/migration-recipe     # Code transforms
npx types-react-codemod@latest preset-19 ./src    # TypeScript type fixes
```

Available transforms handle `replace-reactdom-render`, `replace-string-ref`, `remove-context-provider`, and more. The most common pain point is third-party library compatibility — MUI, React Router, and React Redux all required patches.

**Next.js 15** made request APIs async (`cookies()`, `headers()`, `params` now require `await`), changed caching defaults (fetch requests and GET Route Handlers no longer cached by default), and added React 19 support. The upgrade CLI handles most migrations: `npx @next/codemod@canary upgrade latest`. Cal.com's **Pages→App Router migration** took 5 months with 3 engineers at 50% allocation, using feature flags to gradually channel production traffic from the old router to the new one.

**Go version migration** benefits from the strongest backward compatibility story in any language. Since Go 1.21, the `go` directive in `go.mod` is mandatory and controls language features, GODEBUG defaults, and minimum toolchain version. The **GODEBUG system** serves as a built-in compatibility shim — programs compiled with Go 1.23 but declaring `go 1.22` in their module automatically get Go 1.22 behavior. Go 1.26 completely rewrote `go fix` as a general-purpose code modernizer with analyzers for `minmax`, `slicescontains`, `rangeint`, `testingcontext`, and more:

```bash
go fix -diff ./...    # Preview modernization changes
go fix ./...          # Apply all available fixes
```

**Rust edition 2024** (stabilized in Rust 1.85.0, February 2025) was the largest edition released. Key changes include `unsafe_op_in_unsafe_fn` warning by default, `std::env::set_var` made `unsafe`, the `gen` keyword reserved, and Cargo resolver v3 with MSRV-aware dependency resolution. Migration is automated: `cargo fix --edition` handles most changes. **Crucially, Rust editions are opt-in per crate** — different crates in a workspace can be on different editions and interoperate seamlessly. A practical strategy is migrating leaf crates first, then working up the dependency tree. To avoid reformatting the entire codebase, add `style_edition = "2021"` to `rustfmt.toml`.

**NestJS v10→v11** switched to Express v5 as default, changing the path route matching algorithm and wildcard syntax. NestJS does **not** provide automated codemods — upgrades are manual with the official migration guide.

---

## 9. Audit reporting closes the loop from detection to remediation

Continuous vulnerability monitoring requires more than scanning — it demands **SLA tracking, escalation workflows, and exception documentation** that satisfy compliance auditors.

**Recommended tool stack**: Trivy in CI/CD for free, comprehensive scanning (32,000+ GitHub stars, supports Go/Rust/Node.js/containers/IaC, generates CycloneDX and SPDX SBOMs) combined with Snyk or GitHub Advanced Security for developer workflow integration and automated fix PRs. **Grype** (Anchore) pairs with **Syft** for SBOM-driven vulnerability scanning with EPSS-based risk scoring.

```yaml
# CI scanning pipeline
- run: govulncheck ./...                              # Go (reachability-aware)
- run: cargo audit && cargo vet                        # Rust (vuln + audit chain)
- run: trivy fs . --format sarif --severity CRITICAL,HIGH  # All ecosystems
- run: syft dir:. -o cyclonedx-json > sbom.cdx.json   # SBOM generation
- run: grype sbom:sbom.cdx.json --fail-on high        # SBOM-based scanning
```

**Industry-standard remediation SLAs** follow a tiered model based on exploit status and exposure:

| Tier | Criteria | Remediation window |
|---|---|---|
| Critical | KEV-listed, confirmed exploited, internet-facing | **24–72 hours** |
| High | High EPSS score, public exploit, business-critical | **7 days** |
| Medium | High severity without confirmed exploitation | **30 days** |
| Low | Moderate risk, compensating controls in place | **60–90 days** |

**Exception workflows** require documented risk justification, compensating controls, time-bound approval from a risk/governance owner, and scheduled review. The policy: "No software deployed to production with unresolved CRITICAL or HIGH findings without documented exception." Post-resolution, a post-mortem documents time unpatched, exploits detected, and mitigation effectiveness.

**SBOM generation** is becoming a compliance requirement. The continuous workflow: generate SBOMs at build time (Syft or Trivy), upload to a central platform (OWASP Dependency-Track ingests CycloneDX), attach to container images via `cosign attach sbom`, and monitor continuously as vulnerability feeds update. CycloneDX is preferred for security workflows; SPDX for license compliance.

---

## 10. The case for depending on less

**"No code runs faster than no code. No code has fewer bugs than no code."** Mike Perham's maxim captures the minimal dependency philosophy that the most security-conscious engineering teams embrace. The npm ecosystem's trivial dependency problem — where `isArray` (one line of code) had 880,000 downloads/day and `left-pad` (17 lines) broke thousands of builds when unpublished in 2016 — is not a historical curiosity. It's an ongoing structural vulnerability.

Armin Ronacher (creator of Flask) articulated the current zeitgeist in January 2025: "The more I build software, the more I despise dependencies." He noted that a brand new Tokio project drags in 28 crates, while a Rocket project balloons to 172 — and offered that AI tools now make it faster to generate a dependency-free implementation than to evaluate and import a package.

**Go has the strongest stdlib-first culture.** Its standard library includes production-ready HTTP server/client, JSON encoding, crypto, testing, and logging (`log/slog` since Go 1.21). Go 1.22 improved the built-in router with HTTP method matching (`HandleFunc("GET /foo", ...)`), negating many ergonomic benefits of frameworks like Gin. **Rust deliberately keeps its stdlib minimal**, relying on ecosystem crates for HTTP, async runtimes, and serialization — but `cargo-vet` and `cargo-deny` provide auditing rigor that npm lacks. **Node.js has progressively reduced the need for common packages**: built-in `fetch` (Node 18+), built-in test runner (stable in Node 20), and built-in mocking eliminate the need for `node-fetch`, Jest, and Mocha for many use cases.

**Decision framework for dependency adoption** (adapted from Perham, Ronacher, and Google's SWE book):

1. **Do I need this at all?** Many dependencies solve problems you don't have
2. **Can I implement the needed subset myself?** Often you need 5% of a library's functionality
3. **Is there a stdlib equivalent?** Prefer `net/http` over Gin, `node:test` over Jest, `std::fs` over filesystem crates
4. **What's the transitive cost?** Check `npm ls --all`, `cargo tree`, dependency graphs on deps.dev
5. **What's the maintenance and security posture?** OpenSSF Scorecard ≥ 7, multiple maintainers, active development

**The monorepo itself is the strongest tool for minimal external dependencies.** Internal packages (`@company/utils`, shared workspace crates, internal Go modules) replace external micro-packages with code your team controls, audits, and maintains. Google's key principle from *Software Engineering at Google*: **"All else being equal, prefer source control problems over dependency-management problems."** Converting external dependencies into internal shared packages transforms an intractable trust problem into a manageable engineering one.

The practical patterns are straightforward: copy small utility functions (Rob Pike's "a little copying is better than a little dependency"), build internal utility libraries, use pnpm catalogs or Cargo workspace dependencies for version consistency, and set dependency budgets per service. Arcjet committed to zero runtime dependencies for their SDK. Sidekiq runs with only 3. The aspiration isn't zero — it's **intentional**, where every dependency represents a deliberate decision rather than a casual `npm install`.

---

## Conclusion

Dependency management in polyglot monorepos is not one problem but a system of interlocking concerns. The highest-leverage interventions are: **adopt Renovate with grouping and branch automerge** to eliminate PR noise while keeping dependencies current; **enforce frozen lockfile installs universally** (`npm ci`, `cargo build --locked`, `go build -mod=readonly`); **deploy pnpm v10 with `strictDepBuilds` and `minimumReleaseAge`** as the strongest default security posture in the JavaScript ecosystem; and **establish a pre-adoption evaluation process** using Socket.dev, OpenSSF Scorecard, and deps.dev before adding any dependency. The teams with the fewest security incidents are not the ones with the most scanning tools — they're the ones who depend on less in the first place, vendor or pin what they must, and treat every `import` statement as a trust decision with long-term consequences.