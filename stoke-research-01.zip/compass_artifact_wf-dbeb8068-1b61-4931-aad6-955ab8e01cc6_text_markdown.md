# Database migration safety and polyglot persistence at scale

**Safe schema evolution across a polyglot stack demands disciplined patterns — expand-and-contract for PostgreSQL, version-field schemas for MongoDB, compatibility modes in Kafka Schema Registry, and cross-store consistency via the outbox pattern and CDC.** The single most dangerous mistake teams make is running DDL that acquires an ACCESS EXCLUSIVE lock for longer than milliseconds on a production table. Every technique below exists to avoid that scenario while keeping data flowing correctly across Postgres, Mongo, Redis, and Kafka. This guide covers zero-downtime migration patterns, schema evolution strategies for each store, cross-service coordination, backfill techniques for billions of rows, and the operational tooling needed to enforce safety in CI/CD.

---

## 1. Zero-downtime PostgreSQL migrations through expand-and-contract

The expand-and-contract pattern breaks destructive schema changes into safe, backward-compatible steps. Old and new application code coexist at every intermediate state.

**The four phases**: (1) *Expand* — add new schema elements alongside existing ones. (2) *Migrate data* — backfill in batches. (3) *Switch* — deploy code that reads/writes the new structure. (4) *Contract* — remove old columns or tables.

A concrete example — adding a NOT NULL column safely:

```sql
-- Phase 1: Add nullable column (ACCESS EXCLUSIVE but instant, milliseconds)
SET lock_timeout = '5s';
ALTER TABLE orders ADD COLUMN status TEXT;
ALTER TABLE orders ALTER COLUMN status SET DEFAULT 'pending';

-- Phase 2: Backfill in batches (normal DML, no DDL lock)
UPDATE orders SET status = 'pending'
  WHERE status IS NULL AND id BETWEEN 1 AND 10000;
-- Continue batching with cursor-based pagination...

-- Phase 3: Add NOT NULL via CHECK constraint (instant, no full scan)
ALTER TABLE orders ADD CONSTRAINT orders_status_nn
  CHECK (status IS NOT NULL) NOT VALID;

-- Phase 4: Validate (SHARE UPDATE EXCLUSIVE — reads and writes continue)
ALTER TABLE orders VALIDATE CONSTRAINT orders_status_nn;

-- Phase 5: SET NOT NULL is now instant (PG12+ sees valid CHECK)
ALTER TABLE orders ALTER COLUMN status SET NOT NULL;
ALTER TABLE orders DROP CONSTRAINT orders_status_nn;
```

### DDL lock types — what's safe and what's dangerous

The risk equation is **lock level × hold duration × traffic**. ACCESS EXCLUSIVE for milliseconds is safe; ACCESS EXCLUSIVE for minutes is catastrophic. The lock queue effect compounds the danger: if DDL waits behind a long-running query, every subsequent query stacks behind the DDL.

| DDL Operation | Lock Type | Duration | Safe in Production? |
|---|---|---|---|
| `ADD COLUMN` (no default or constant default PG11+) | ACCESS EXCLUSIVE | Instant (ms) | ✅ Yes |
| `ADD COLUMN` with volatile default (e.g., `gen_random_uuid()`) | ACCESS EXCLUSIVE | Table rewrite | ❌ Dangerous |
| `ALTER COLUMN TYPE` (most cases) | ACCESS EXCLUSIVE | Table rewrite | ❌ Dangerous |
| `ALTER COLUMN TYPE` (varchar(n)→varchar(m), m>n; varchar→text) | ACCESS EXCLUSIVE | Instant | ✅ Yes |
| `SET NOT NULL` (direct) | ACCESS EXCLUSIVE | Full table scan | ❌ Dangerous |
| `DROP COLUMN` | ACCESS EXCLUSIVE | Instant (marks deleted, no rewrite) | ✅ Yes |
| `ADD CONSTRAINT ... NOT VALID` | SHARE ROW EXCLUSIVE | Instant | ✅ Yes |
| `VALIDATE CONSTRAINT` | SHARE UPDATE EXCLUSIVE | Full scan | ✅ Yes (reads+writes continue) |
| `CREATE INDEX` (regular) | SHARE | Minutes (blocks writes) | ❌ Dangerous |
| `CREATE INDEX CONCURRENTLY` | SHARE UPDATE EXCLUSIVE | Longer but non-blocking | ✅ Yes |
| `DROP INDEX CONCURRENTLY` | SHARE UPDATE EXCLUSIVE | Instant | ✅ Yes |
| `REINDEX CONCURRENTLY` (PG12+) | SHARE UPDATE EXCLUSIVE | Index rebuild | ✅ Yes |
| `ADD CONSTRAINT UNIQUE USING INDEX` | ACCESS EXCLUSIVE | Instant | ✅ Yes |

### The lock_timeout + retry pattern

Always set `lock_timeout` before production DDL. If the lock can't be acquired within the timeout, the statement fails and the application continues:

```sql
SET lock_timeout = '5s';
SET statement_timeout = '30s';
```

pgroll (v0.6.0+) implements automatic retry with configurable backoff for all DDL. In application code, wrap DDL in a retry loop with exponential backoff.

### Tooling: pg_repack and pgroll

**pg_repack** removes table and index bloat online by creating a shadow table, installing a trigger to capture ongoing changes, copying all rows, rebuilding indexes, then atomically swapping via `pg_class` catalog updates. The table must have a primary key, and you need **~2× disk space** temporarily. ACCESS EXCLUSIVE is held only for milliseconds at setup and swap.

```bash
pg_repack -d mydb --table public.orders --jobs 4 --wait-timeout 30
```

**pgroll** (by Xata, Apache 2.0, written in Go) automates expand-and-contract entirely. For breaking changes, it creates a temporary column with the constraint applied via `NOT VALID`, backfills data using user-defined SQL, and installs **triggers for bidirectional dual-writes** between old and new columns. Versioned schema views let old and new clients coexist via `search_path`:

```json
{
  "name": "02_set_not_null",
  "operations": [{
    "alter_column": {
      "table": "users",
      "column": "description",
      "nullable": false,
      "up": "COALESCE(description, 'no description')",
      "down": "description"
    }
  }]
}
```

```bash
pgroll start migration.json --postgres-url postgres://...
pgroll complete --postgres-url postgres://...  # or: pgroll rollback
```

### CREATE INDEX CONCURRENTLY failure cleanup

When `CREATE INDEX CONCURRENTLY` fails (deadlock, disk space, unique violation), it leaves behind an **invalid index** that still consumes write overhead but is never used by the planner:

```sql
-- Detect invalid indexes
SELECT indexrelid::regclass, indisvalid FROM pg_index WHERE NOT indisvalid;

-- Fix: drop and retry
DROP INDEX CONCURRENTLY idx_orders_user_id;
CREATE INDEX CONCURRENTLY idx_orders_user_id ON orders (user_id);
```

---

## 2. MongoDB schema evolution with version fields and lazy migration

MongoDB's flexible document model lets differently-shaped documents coexist in the same collection. The **Schema Versioning Pattern** — adding a `schemaVersion` field to every document — makes this intentional and manageable.

```javascript
// Schema Version 1
{ _id: 1, name: "Taylor", home: "209-555-7788", work: "503-555-0110" }

// Schema Version 2 — restructured contact info
{ _id: 2, schemaVersion: 2, name: "Cameron",
  contactInfo: { cell: "903-555-1122", work: "670-555-7878" } }
```

Documents without a `schemaVersion` field are implicitly version 1. Application code handles both versions at query time.

### Lazy vs batch migration: when to use each

**Lazy migration** transforms documents to the new schema when read, then writes them back. It requires no background job and distributes load over time, but adds read latency on first access, leaves analytics queries seeing mixed schemas, and can accumulate long migration chains across multiple schema versions.

**Batch migration** iterates through all documents using cursor-based pagination with `bulkWrite`, achieving uniform schema state. It consumes significant I/O and generates oplog entries that can cause replication lag.

| Factor | Lazy Migration | Batch Migration |
|---|---|---|
| Billions of documents, hot/cold access | ✅ Preferred | Expensive |
| Need uniform state for analytics | Incomplete coverage | ✅ Preferred |
| Cloud cost sensitivity | ✅ Only accessed docs | High write costs |
| Complex restructuring | Migration chains accumulate | ✅ Clean one-time transform |

The best practice is a **hybrid**: deploy lazy migration immediately for zero downtime, then follow with a throttled batch job to clean up remaining old-version documents.

### Document validation evolution

MongoDB's `$jsonSchema` validator can be evolved safely by using `validationLevel: "moderate"` during transitions. This allows existing non-conforming documents to still be updated, while new inserts must conform. Combine with `validationAction: "warn"` first to monitor violations before enforcing with `"error"`.

For collections with multiple schema versions, use the `oneOf` operator:

```javascript
db.runCommand({
  collMod: "bookings",
  validator: { $jsonSchema: { oneOf: [v1Schema, v2Schema] } },
  validationLevel: "strict",
  validationAction: "error"
});
```

### Change streams during schema migration

Change streams are schema-agnostic — they emit events for any write regardless of document structure. During migration, consumers receive events with both old and new shapes. The key pattern is checking `schemaVersion` in the `fullDocument` and routing to version-specific processors. Increase oplog size before batch migrations to prevent resume token invalidation, and persist resume tokens after every successfully processed event.

---

## 3. Kafka Schema Registry compatibility modes and evolution rules

### Avro vs Protobuf: fundamentally different evolution models

**Avro** uses a writer-schema/reader-schema model where fields are matched **by name**. The Avro library performs automatic schema resolution: unknown writer fields are ignored, missing reader fields use the default value (which must exist, or deserialization fails). Type promotion follows a strict chain: `int` → `long` → `float` → `double`.

**Protobuf** identifies fields **by numeric tag**, making field names cosmetic. Renaming a field is always safe. Proto3 makes all fields implicitly optional with zero-value defaults, and unknown fields are silently preserved during re-serialization. **Protobuf is generally more forgiving** because all fields default to optional.

**JSON Schema** evolution in Schema Registry is the weakest — Confluent's own compatibility checking has been described as problematic. Prefer Avro or Protobuf for Kafka topics requiring evolution.

### The six compatibility modes

**BACKWARD** (default): New schema reads old data. Add fields with defaults; delete fields freely. Deploy consumers first, then producers.

**FORWARD**: Old schema reads new data. Add fields freely (old readers ignore them); delete fields only if they have defaults. Deploy producers first, then consumers.

**FULL**: Both directions with the last version. Only add/delete **optional fields with defaults**. Deploy in any order.

The **TRANSITIVE** variants (`BACKWARD_TRANSITIVE`, `FORWARD_TRANSITIVE`, `FULL_TRANSITIVE`) check against **all** previous versions, not just the last one. This is critical for systems that replay data from the beginning of a topic.

| Change (Avro) | Breaks BACKWARD | Breaks FORWARD | Breaks FULL |
|---|---|---|---|
| Add field with default | No | No | No |
| Add field without default | **Yes** | No | **Yes** |
| Remove field with default | No | No | No |
| Remove field without default | No | **Yes** | **Yes** |
| Change field type | **Yes** | **Yes** | **Yes** |
| Add enum value | **Yes** | No | **Yes** |

### Testing compatibility in CI/CD

```bash
# Test before registering
curl -X POST -H "Content-Type: application/vnd.schemaregistry.v1+json" \
  --data '{"schema": "..."}' \
  http://localhost:8081/compatibility/subjects/my-topic-value/versions/latest?verbose=true

# Set subject-level compatibility
curl -X PUT -H "Content-Type: application/vnd.schemaregistry.v1+json" \
  --data '{"compatibility": "FULL_TRANSITIVE"}' \
  http://localhost:8081/config/my-topic-value
```

Confluent's Schema Registry Maven Plugin provides `validate`, `test-compatibility`, and `register` goals that integrate into GitHub Actions. For Protobuf, **buf** (`buf.build`) offers `buf breaking` for change detection.

**Essential rules**: Always add defaults for new Avro fields. Never reuse Protobuf field numbers — use `reserved`. Disable `auto.register.schemas` in production; register schemas deliberately via CI/CD. Confluent recommends `BACKWARD_TRANSITIVE` for Protobuf because adding new message types is not forward-compatible.

---

## 4. Coordinating cross-service schema changes without downtime

When service A adds a field that service B must start sending, the **expand-contract pattern extends to the service boundary** using feature flags, tolerant readers, and contract testing.

### Feature flags with LaunchDarkly's 6-stage model

LaunchDarkly formalized a 6-stage migration during their MongoDB-to-CockroachDB migration: (1) **Off** — old system only. (2) **Dual-write** — write to both, read from old. (3) **Shadow** — read from both, compare, serve from old. (4) **Live** — new is authoritative. (5) **Rampdown** — stop comparing. (6) **Complete** — stop writing to old.

Each stage is gated by a feature flag with **cohort-based targeting** (test accounts → internal users → percentage rollout → full). If problems arise at any stage, disable the flag instantly — no redeployment needed.

### Tolerant reader pattern

Services should **ignore unknown fields and provide defaults for missing fields**. This is Postel's Law applied to APIs. Configure Jackson with `@JsonIgnoreProperties(ignoreUnknown = true)`. In Protobuf this is built in — unknown field numbers are silently preserved. This single practice enables independent evolution of producers and consumers.

### Consumer-driven contract testing with Pact

Pact inverts the testing model: the *consumer* defines expected interactions, generating a contract file. The *provider* verifies it can fulfill those expectations. The Pact Broker's `can-i-deploy` tool blocks deployment of incompatible versions. When Service A adds a new field, Service B updates its Pact to include the expectation, and the provider verifies the field is present.

### Choreography vs orchestration for migration rollout

For simple 2-3 service migrations, **choreography** works well — services react to domain events (`SchemaV2Ready`) at their own pace. For complex multi-service migrations with strict ordering, use **orchestration** with durable workflow engines like Temporal or AWS Step Functions. The Saga pattern applies directly: each service applies its local schema change, with compensating transactions if any step fails.

---

## 5. Migration rollback: why roll-forward beats roll-back

The industry consensus strongly favors **forward-only migrations**. `ALTER TABLE DROP COLUMN` destroys data irreversibly. Rollback scripts double development effort for code that's rarely tested and likely untrusted if the forward migration failed unexpectedly.

**The expand-contract pattern inherently solves rollback**: during the expand phase, both old and new schemas coexist. To "roll back," disable the feature flag and revert to reading/writing old columns. New column data is redundant because you've been dual-writing.

### Shadow migration pattern for large-scale database moves

The shadow pattern creates a synchronized duplicate of production data in a new structure:

**Phase 1 (Dual-write)**: Create shadow table, set up synchronization via triggers or CDC. Backfill initial data in chunks, replay ongoing changes. **Phase 2 (Shadow-read)**: Read from both, compare results (checksums, row counts), serve from old. Run until discrepancy rate hits zero. **Phase 3 (Cutover)**: Serve from new, continue writing to old as fallback. **Phase 4 (Cleanup)**: Stop writing to old, remove triggers/CDC, drop old table.

### Point-in-time recovery as a last resort

Create named restore points before migrations:

```sql
SELECT pg_create_restore_point('before_schema_migration_v42');
```

PITR restores the **entire cluster** — you cannot selectively roll back one table. All data written after the recovery point is lost. It requires downtime and can take hours for large databases. Use it only for catastrophic failures; prefer expand-contract for planned schema changes.

---

## 6. Backfilling billions of rows without locking or degrading performance

### Cursor-based pagination is non-negotiable

Never use `OFFSET` for large backfills. `OFFSET 1,000,000 LIMIT 1,000` forces PostgreSQL to scan and discard a million rows. Performance degrades linearly with offset. **Keyset pagination** is O(1) regardless of position:

```sql
-- Keyset pagination (good)
UPDATE my_table SET new_column = compute_value(old_column)
WHERE id IN (
  SELECT id FROM my_table
  WHERE new_column IS NULL AND id > $last_processed_id
  ORDER BY id LIMIT 1000
);
```

### Production backfill recipe

- **Batch size**: Start with 1,000–10,000 rows. Crunchy Data found **100,000 optimal** for their INT→BIGINT migration; batches above 4M caused vacuum issues
- **Throttle**: `pg_sleep(0.1)` between batches — but **outside transactions** to avoid holding locks
- **VACUUM periodically**: Run `VACUUM (ANALYZE)` every 5-10 batches (~500K rows) to prevent bloat accumulation
- **Monitor replication lag**: Pause backfill if `replay_lag_bytes > 100MB`
- **Track progress**: Persist `last_processed_id` in a tracking table after each batch for crash recovery
- **Parallelize**: Divide ID space among workers using modular arithmetic (`WHERE id % 4 = $worker_id`) and coordinate with `pg_try_advisory_lock`

```sql
-- Replication lag monitoring
SELECT client_addr, state,
  pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn) AS replay_lag_bytes
FROM pg_stat_replication;
```

### The dual-write transition pattern

During backfill, new writes go to both old and new columns via application code or triggers. After backfill completes, run a final "catch-up" pass for rows inserted during the backfill window, then switch reads to the new column.

---

## 7. Polyglot consistency: when Postgres, Redis, and Kafka disagree

The core problem: user writes to Postgres, read-back from Redis cache is stale, Kafka event hasn't propagated yet.

### Cache invalidation: write to DB first, then delete cache

```python
def update_user(user_id, data):
    db.execute("UPDATE users SET ... WHERE id = %s", user_id)  # DB first
    redis.delete(f"user:{user_id}")  # Then invalidate
    # Next read repopulates from DB
```

**Never update cache on write** — race conditions between concurrent writers corrupt data. Use **two-layer defense**: event-driven invalidation (milliseconds) plus TTL safety net (minutes). If the event is lost, TTL ensures eventual freshness.

### Read-your-writes consistency

After a write, set a short-lived "sticky" flag in Redis that routes subsequent reads from that user to the primary database, bypassing the cache and replicas:

```python
def handle_write(user_id, data):
    db_master.execute("UPDATE ...", data)
    redis.setex(f"sticky:{user_id}", 10, "1")  # 10-second window

def handle_read(user_id, query):
    if redis.get(f"sticky:{user_id}"):
        return db_master.query(query)  # Route to master
    return db_replica.query(query)     # Normal replica read
```

### The outbox pattern: atomic business data + events

Write to a Postgres outbox table in the **same transaction** as business data. A separate relay process publishes to Kafka, guaranteeing at-least-once delivery:

```sql
BEGIN;
  INSERT INTO orders (id, customer_id, total) VALUES ('order-123', 'cust-456', 99.99);
  INSERT INTO outbox (aggregate_type, aggregate_id, event_type, payload)
  VALUES ('Order', 'order-123', 'OrderCreated', '{"total": 99.99}'::jsonb);
COMMIT;
```

The relay polls with `FOR UPDATE SKIP LOCKED` for concurrent processing. Use **BIGINT ids** (not INT), order by `id` (not `created_at` — clock skew across pods), and partition the outbox table for high-throughput systems.

### CDC with Debezium: WAL-based change capture

Debezium reads PostgreSQL's WAL via logical replication, publishing change events to Kafka topics. Configure PostgreSQL with `wal_level = logical`, create a publication and replication slot, and monitor retained WAL carefully:

```sql
SELECT slot_name, active,
  pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn)) AS retained_wal
FROM pg_replication_slots;
```

If Debezium goes down, WAL segments accumulate indefinitely. Set `max_slot_wal_keep_size` and configure `heartbeat.interval.ms` to prevent WAL bloat during low-activity periods. Debezium provides **sub-second latency** compared to seconds for outbox polling, but requires Kafka Connect infrastructure.

### Communicating consistency to clients

Return version tokens on writes; check if the read model has caught up on reads:

```http
HTTP/1.1 503 Service Unavailable
Retry-After: 2
X-Data-Freshness: eventually-consistent
```

Include `ETag`, `Last-Modified`, and custom headers like `X-Data-Freshness: "real-time"` vs `"eventual"` to let clients make informed decisions.

---

## 8. Connection pooling: PgBouncer, pgcat, and sizing formulas

### PgBouncer transaction mode limitations

In transaction mode, connections return to the pool after each transaction ends. This breaks session-scoped features:

- **SET/RESET**: Session settings don't stick across transactions. Workaround: `SET LOCAL` inside explicit transactions, or `ALTER ROLE ... SET search_path`
- **Advisory locks**: `pg_advisory_lock` is session-scoped. Use `pg_advisory_xact_lock` (transaction-scoped) instead
- **LISTEN/NOTIFY**: Registration is lost when the connection returns to the pool. Use a dedicated session-mode connection or Redis pub/sub
- **Prepared statements**: Since **PgBouncer 1.21+**, set `max_prepared_statements > 0`. PgBouncer tracks and re-prepares statements transparently. Before 1.21, disable prepared statements in drivers
- **Temp tables**: Only `ON COMMIT DROP` works. Use regular tables with session identifiers otherwise

### The connection sizing formula

From the PostgreSQL Wiki:

```
optimal_connections = (physical_cores × 2) + effective_spindle_count
```

For a **4-core server with SSD**: (4 × 2) + 1 = **9 connections**. This is the optimal number of *actively working* connections to PostgreSQL, not client connections. Too many connections cause context switching, CPU cache thrashing (~5-10MB RAM per connection), and superlinear lock contention. Architecture: thousands of client connections → PgBouncer → **tens** of pool connections → PostgreSQL.

### PgBouncer vs pgcat vs Odyssey

| Feature | PgBouncer | pgcat (Instacart) | Odyssey (Yandex) |
|---|---|---|---|
| Threading | Single-threaded | Multi-threaded (Tokio) | Multi-threaded (coroutines) |
| Prepared statements (txn mode) | ✅ Since v1.21 | ✅ LRU cache | ✅ Native |
| Load balancing / read replicas | ❌ | ✅ Round-robin, failover | Limited |
| Sharding | ❌ | ✅ Comment-based | ❌ |
| Prometheus metrics | ❌ Needs exporter | ✅ Native `/metrics` | ✅ Native |
| Auth methods | md5, SCRAM, cert, PAM | md5, SCRAM | md5, SCRAM, LDAP, cert, PAM |
| Maturity | Very mature (2007), battle-tested everywhere | Production at Instacart (105k QPS) | Production at Yandex scale |

**PgBouncer** remains the default choice. At scale, run multiple processes with `so_reuseport`. **pgcat** adds load balancing and replica failover — valuable if you need built-in read/write splitting. **Odyssey** offers the best single-process multi-threaded performance.

### Debugging connection pool exhaustion

```sql
-- PgBouncer: look for cl_waiting > 0
SHOW POOLS;

-- PostgreSQL: connection states breakdown
SELECT state, count(*) FROM pg_stat_activity
WHERE backend_type = 'client backend' GROUP BY state;

-- Find idle-in-transaction connections (holding locks!)
SELECT pid, usename, now() - xact_start AS tx_duration, query
FROM pg_stat_activity WHERE state = 'idle in transaction'
ORDER BY tx_duration DESC;
```

Set `idle_in_transaction_session_timeout` in PostgreSQL to auto-kill abandoned transactions. Set `query_wait_timeout` in PgBouncer to cap how long clients wait for a server connection.

---

## 9. Migration safety tools and CI enforcement

### Squawk: PostgreSQL migration linter

Squawk parses raw SQL and flags dangerous operations. It catches missing `CONCURRENTLY`, constraints without `NOT VALID`, direct `UNIQUE` additions, column drops, and more:

```
❯ squawk example.sql
warning[constraint-missing-not-valid]: New constraints require table scan and block writes.
  help: Use NOT VALID with a later VALIDATE CONSTRAINT call.
warning[disallowed-unique-constraint]: Adding UNIQUE requires ACCESS EXCLUSIVE lock.
  help: Create index CONCURRENTLY and add constraint using the index.
```

```yaml
# GitHub Actions integration
- uses: sbdchd/squawk-action@v2
  with:
    pattern: "migrations/*.sql"
```

### strong_migrations (Ruby/Rails)

Intercepts Active Record migration methods at runtime, blocks dangerous operations, and provides step-by-step safe alternatives. Catches non-concurrent index creation, adding foreign keys without `NOT VALID`, changing column types, removing columns (which breaks AR attribute caching), and backfilling in the same transaction as DDL.

### Atlas by Ariga: declarative + versioned migrations

Atlas supports both Terraform-like declarative schema management and versioned migrations. Its linter runs **50+ safety analyzers** covering destructive changes, blocking locks, concurrent index violations, and data-dependent changes:

```bash
atlas migrate lint --dev-url "docker://postgres/16/dev"
atlas schema apply --url "postgres://..." --to "file://schema.sql"
```

### pgroll for automated expand-and-contract

pgroll handles the entire expand-and-contract lifecycle — column creation, trigger installation, dual-write management, backfill, and cleanup — with `start`, `complete`, and `rollback` commands. It supports PostgreSQL 14-17 including RDS and Aurora.

### Flyway and Liquibase: runners, not analyzers

Both are migration execution frameworks. **Liquibase** offers rich preconditions, free rollback support, and XML/YAML/JSON/SQL changelogs. **Flyway** uses file-naming conventions and provides checksums to prevent phantom changes but limits rollback to the paid tier. Neither tool analyzes SQL for safety — **always pair with a linter** (Squawk, Atlas) for production safety.

### Recommended CI pipeline

```yaml
# 1. Static linting (no DB required)
- uses: sbdchd/squawk-action@v2
  with: { pattern: "migrations/*.sql" }

# 2. Database-aware linting (ephemeral dev DB)
- uses: ariga/atlas-action/migrate/lint@v1
  with:
    dir: file://migrations
    dev-url: postgres://postgres:pass@localhost:5432/test

# 3. Apply + validate against production-scale clone
- run: dblab clone create --branch migration-test
- run: psql $CLONE_URL -c "SET lock_timeout='5s'" -f migration.sql
```

---

## 10. PostgreSQL operational monitoring essentials

### pg_stat_statements: finding your worst queries

Enable with `shared_preload_libraries = 'pg_stat_statements'` and `track_io_timing = on`. The top queries by total execution time reveal where the database spends the most cumulative effort:

```sql
SELECT query, calls,
  total_exec_time::int AS total_ms,
  mean_exec_time::int AS mean_ms,
  round((100 * total_exec_time / sum(total_exec_time) OVER())::numeric, 2) AS pct
FROM pg_stat_statements
ORDER BY total_exec_time DESC LIMIT 20;
```

A **cache hit ratio below 98%** for any high-frequency query warrants investigation:

```sql
SELECT query, shared_blks_hit, shared_blks_read,
  round(shared_blks_hit::numeric / NULLIF(shared_blks_hit + shared_blks_read, 0) * 100, 2) AS hit_ratio
FROM pg_stat_statements
WHERE shared_blks_hit + shared_blks_read > 1000
ORDER BY shared_blks_read DESC LIMIT 10;
```

### Autovacuum tuning and wraparound prevention

Autovacuum triggers when dead tuples exceed `threshold + scale_factor × live_rows`. Defaults: **50 + 20%** of live rows. For a 10M-row table, that's ~2M dead tuples before vacuum fires — often too late. For high-churn tables:

```sql
ALTER TABLE high_churn_table SET (
  autovacuum_vacuum_scale_factor = 0.02,  -- 2% instead of 20%
  autovacuum_vacuum_cost_delay = 0,       -- no throttling
  autovacuum_vacuum_cost_limit = 10000
);
```

**Wraparound monitoring is critical**. When `age(relfrozenxid)` approaches **200 million**, aggressive anti-wraparound vacuum is forced. At **2 billion**, PostgreSQL halts all writes:

```sql
SELECT c.oid::regclass, age(c.relfrozenxid) AS xid_age,
  2147483647 - age(c.relfrozenxid) AS xids_remaining
FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind = 'r' AND n.nspname NOT IN ('pg_catalog','information_schema')
ORDER BY age(c.relfrozenxid) DESC LIMIT 20;
```

### Bloat detection and remediation

Use `pgstattuple` for accurate measurement and catalog-based queries for lightweight scanning:

```sql
CREATE EXTENSION pgstattuple;
SELECT * FROM pgstattuple('my_table');
-- dead_tuple_percent > 20-30% = significant bloat
```

For index bloat, `avg_leaf_density` below **70%** indicates significant bloat. Fix with `REINDEX CONCURRENTLY` (PG12+) or `pg_repack --only-indexes`.

### TOAST compression: switch to lz4 on PG14+

TOAST handles values exceeding ~2KB. PG14+ supports **lz4** compression alongside the legacy pglz. lz4 achieves **60-70% faster compression** with only 7% less space savings — a clear win for JSONB-heavy workloads:

```sql
ALTER TABLE my_table ALTER COLUMN payload SET COMPRESSION lz4;
```

### Lock tree visualization for production debugging

This recursive CTE shows the full blocking chain — who blocks whom and for how long:

```sql
SELECT pid, blocked_by, state, wait_event_type || ':' || wait_event AS wait,
  now() - query_start AS duration, query
FROM pg_stat_activity WHERE wait_event_type = 'Lock';

-- For the full blocking tree, use pg_blocking_pids():
SELECT pid, pg_blocking_pids(pid) AS blocked_by, query
FROM pg_stat_activity WHERE cardinality(pg_blocking_pids(pid)) > 0;
```

Set `log_lock_waits = on` and `deadlock_timeout = 1s` in `postgresql.conf` to automatically log lock waits. Set `lock_timeout` per-session for DDL migrations to prevent indefinite queuing.

---

## Conclusion

The central insight across all ten areas is that **safe schema evolution is a coordination problem, not a technology problem**. PostgreSQL's lock system is well-documented and predictable — the danger lies in not knowing which DDL operations are instant versus table-rewriting. The expand-and-contract pattern, applied consistently across Postgres (via pgroll or manual steps), MongoDB (via schema versioning), and Kafka (via compatibility modes), provides the same fundamental guarantee: old and new code coexist safely at every intermediate state.

Three patterns prove indispensable across the entire polyglot stack. The **outbox pattern** solves the dual-write atomicity problem between Postgres and Kafka. **Cursor-based pagination** is non-negotiable for backfilling tables with more than a few million rows. And **feature flags with staged rollout** provide the only reliable mechanism for coordinating schema changes across service boundaries without downtime.

The tooling ecosystem has matured significantly. Squawk and Atlas catch dangerous DDL before it reaches production. pgroll automates expand-and-contract at the database level. Debezium provides sub-second CDC from PostgreSQL WAL to Kafka. PgBouncer 1.21+ finally supports prepared statements in transaction mode. These tools transform migration safety from a discipline problem into an engineering problem — automatable, testable, and enforceable in CI.