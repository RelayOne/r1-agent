# How every AI coding tool handles project configuration

**The configuration surface area of AI coding tools has exploded.** What began as simple API key settings has evolved into layered systems of scoped rules, lifecycle hooks, approval policies, and multi-model routing — yet no two tools take the same approach. This report documents the complete configuration architecture of nine major AI coding tools as of early 2026, covering exact file paths, schema details, defaults, and unique capabilities, concluding with a gap analysis identifying what the ideal system would add.

---

## 1. Claude Code: the deepest settings hierarchy

Claude Code offers the most granular configuration system of any AI coding tool, with **60+ settings keys**, a five-tier scope hierarchy, and an extensive environment variable surface.

### File paths and directory structure

| Path | Purpose | Shared? |
|------|---------|---------|
| `~/.claude/settings.json` | User-level settings | Personal, all projects |
| `.claude/settings.json` | Project settings | Team via Git |
| `.claude/settings.local.json` | Local project overrides | Personal, gitignored |
| `CLAUDE.md` (project root) | Project instructions | Team via Git |
| `CLAUDE.local.md` | Personal project instructions | Gitignored |
| `~/.claude/CLAUDE.md` | Global personal instructions | Personal, all projects |
| `.claude/rules/*.md` | Modular rule files | Team via Git |
| `.claude/commands/*.md` | Custom slash commands | Team via Git |
| `.claude/agents/*.md` | Named subagents | Team via Git |
| `.claude/skills/*/SKILL.md` | Reusable skill definitions | Team via Git |
| `.mcp.json` | Project MCP servers | Team via Git |
| `~/.claude.json` | User MCP servers + global config | Personal |

### Settings scope hierarchy (highest to lowest precedence)

1. **Managed** — Server-managed or MDM-deployed (macOS: `com.anthropic.claudecode` preferences, Linux: `/etc/claude-code/`, Windows: `HKLM\SOFTWARE\Policies\ClaudeCode`). Supports drop-in directories (`managed-settings.d/*.json`) merged alphabetically.
2. **Command-line arguments** — Temporary session overrides (`--model`, `--append-system-prompt`, etc.)
3. **Local** — `.claude/settings.local.json` (gitignored, personal per-project)
4. **Project** — `.claude/settings.json` (committed, team-shared)
5. **User** — `~/.claude/settings.json` (personal defaults)

**Array settings merge** across scopes (concatenated and deduplicated), while scalar values use the most specific scope. The `permissions.allow`, `permissions.deny`, and `sandbox.filesystem.allowWrite` arrays all merge.

### Core settings keys

The `permissions` object controls tool access with a deny → ask → allow evaluation order and pattern matching:

- **`permissions.allow`** (string[]): Rules like `Bash(npm run *)`, `Read(./.env)`, `mcp__servername__toolname`
- **`permissions.deny`** (string[]): Same syntax; evaluated first
- **`permissions.ask`** (string[]): Requires confirmation
- **`permissions.defaultMode`**: `"default"`, `"acceptEdits"`, `"plan"`, `"auto"`, `"dontAsk"`, or `"bypassPermissions"`

Other critical settings include **`model`** (string, override default model), **`hooks`** (object keyed by lifecycle events: `PreToolUse`, `PostToolUse`, `SessionStart`, `SessionEnd`, `CwdChanged`, etc.), **`sandbox`** (full sandboxing with filesystem read/write controls, network domain allowlists, proxy ports), **`availableModels`** (string[], restrict model picker for enterprise), **`env`** (key-value environment variables applied every session), and **`claudeMdExcludes`** (glob patterns to skip specific CLAUDE.md files).

### CLAUDE.md system

The `/init` command analyzes the codebase and generates a CLAUDE.md containing build commands, test instructions, and project conventions. Setting `CLAUDE_CODE_NEW_INIT=1` enables an interactive multi-phase flow with subagent exploration.

Claude walks the directory tree loading `CLAUDE.md` and `CLAUDE.local.md` at each level — all files are **concatenated**, not overridden. Subdirectory CLAUDE.md files load lazily when Claude reads files in those directories. The `.claude/rules/` directory supports path-scoped rules via YAML frontmatter with `paths:` glob patterns, and an import syntax (`@path/to/file.md`) allows cross-referencing with max depth of 5 hops.

### Environment variables

Claude Code exposes **80+ environment variables** spanning authentication (`ANTHROPIC_API_KEY`, `ANTHROPIC_AUTH_TOKEN`), model selection (`ANTHROPIC_MODEL`, `CLAUDE_CODE_SUBAGENT_MODEL`), cloud providers (`CLAUDE_CODE_USE_BEDROCK`, `CLAUDE_CODE_USE_VERTEX`, `CLAUDE_CODE_USE_FOUNDRY`), behavior tuning (`CLAUDE_CODE_EFFORT_LEVEL`, `CLAUDE_CODE_AUTO_COMPACT_WINDOW`, `CLAUDE_AUTOCOMPACT_PCT_OVERRIDE`), feature toggles (`CLAUDE_CODE_DISABLE_AUTO_MEMORY`, `CLAUDE_CODE_DISABLE_CLAUDE_MDS`, `DISABLE_AUTO_COMPACT`), MCP settings (`MCP_TIMEOUT`, `MCP_TOOL_TIMEOUT`, `MAX_MCP_OUTPUT_TOKENS`), and proxy/network (`HTTP_PROXY`, `CLAUDE_CODE_CLIENT_CERT`).

**Unique to Claude Code:** Managed enterprise deployment via MDM, the most extensive permission rule syntax of any tool, sandbox with OS-native isolation (Seatbelt on macOS, Bubblewrap/seccomp on Linux), and the import/`@reference` syntax in CLAUDE.md files.

---

## 2. Cursor: conditional rules with four activation modes

Cursor's configuration centers on its `.cursor/rules/` directory system, which replaced the legacy single `.cursorrules` file with a modular, activation-aware approach.

### Rules directory structure

```
.cursor/
├── rules/
│   ├── code-style.mdc          # alwaysApply: true
│   ├── testing.mdc             # globs: **/*.test.ts
│   ├── api-validation.mdc      # description for agent-requested
│   └── create-rules.mdc        # Manual @mention only
├── environment.json            # Background agent env config
├── hooks.json                  # Lifecycle hooks
└── skills/                     # Reusable workflows
```

Each rule is an `.mdc` file (Markdown Component) with YAML frontmatter containing `description` (string), `globs` (string or array), and `alwaysApply` (boolean). The combination of these fields determines the rule type:

| Rule Type | alwaysApply | globs | description | Activation |
|-----------|------------|-------|-------------|------------|
| **Always** | `true` | empty | optional | Every AI prompt |
| **Auto Attached** | `false` | pattern(s) | optional | When matching files referenced |
| **Agent Requested** | `false` | empty | **required** | AI reads description, decides relevance |
| **Manual** | `false` | empty | empty | Only via `@rule-name` |

### Codebase indexing

Cursor performs **automatic semantic indexing** on project open: files are parsed into semantically meaningful chunks via AST, embedded via Cursor's servers, and stored in a remote vector database (Turbopuffer). A Merkle tree enables efficient incremental updates — only changed files need re-embedding. Team index reuse via simhash matching (>92% similarity threshold) cuts time-to-first-query from hours to seconds for cloned repos.

### Settings hierarchy

User rules live in Cursor Settings → General → Rules for AI (plain text, all projects). Project rules in `.cursor/rules/*.mdc` override them. Workspace settings inherit VS Code's `~/.cursor/User/settings.json`. The `.cursorignore` file (gitignore syntax) blocks files from both indexing and AI access, while `.cursorindexingignore` excludes from indexing only.

### Background agents and automations

Cursor's `.cursor/environment.json` configures cloud-based background agents running in isolated Ubuntu VMs with custom base images, install commands, environment variables, and persisted directories. As of 2026, **Automations** enable always-on agents triggered by schedules or events from Slack, Linear, GitHub, or webhooks.

**Unique to Cursor:** The four-type activation system for rules, semantic codebase indexing with team sharing, background agents in cloud sandboxes, and the `/best-of-n` command that runs tasks across multiple models in parallel worktrees.

---

## 3. GitHub Copilot: the broadest organizational policy surface

Copilot's configuration spans three layers — personal, repository, and organization/enterprise — with the widest organizational governance controls of any tool.

### Repository-level instructions

The **`.github/copilot-instructions.md`** file provides natural language coding conventions automatically appended to every Copilot Chat request, code review, and agent prompt within the repository. No frontmatter required. Path-specific instructions use **`.github/instructions/NAME.instructions.md`** with YAML frontmatter:

```yaml
---
applyTo: '**/*.py'
excludeAgent: 'code-review'
---
```

The `applyTo` field accepts glob patterns; `excludeAgent` optionally prevents specific agents from reading the file. Copilot also reads `AGENTS.md` at repository root (setting: `chat.useAgentsMdFile`) and `CLAUDE.md` (setting: `chat.useClaudeMdFile`), plus `.claude/rules` directory files — achieving cross-tool instruction compatibility.

### Organization and enterprise policies

Organization-level custom instructions (GA April 2026, ~600 character limit) apply to all members. The precedence order is personal instructions > repository instructions > organization instructions. Enterprise policies override organization policies when set. Feature policies control Copilot in IDE, GitHub.com, coding agent, code review, CLI, extensions, and Spaces — each independently toggleable. Content exclusion uses fnmatch-style patterns at repository, organization, or enterprise level, taking up to 30 minutes to propagate.

### VS Code settings surface

Copilot exposes **60+ VS Code settings** including language-specific enable/disable (`github.copilot.enable` object keyed by language ID), agent settings (`chat.agent.maxRequests` default 25, `chat.tools.terminal.autoApprove`, `chat.tools.edits.autoApprove` with glob patterns), and model selection (`chat.planAgent.defaultModel`, `github.copilot.chat.customOAIModels`).

### Coding agent environment

The cloud coding agent's environment is customized via `.github/workflows/copilot-setup-steps.yml`, a standard GitHub Actions workflow. Hooks in `.github/hooks/*.json` provide lifecycle control with six event types (`sessionStart`, `sessionEnd`, `preToolUse`, `postToolUse`, etc.), and custom agents live in `.github/agents/NAME.agent.md` with tool declarations.

**Unique to Copilot:** Organization/enterprise policy inheritance for governance at scale, content exclusion that's managed server-side rather than via repository files, cross-IDE instruction file compatibility, and the deepest integration with GitHub's CI/CD and PR workflows.

---

## 4. Codex CLI: TOML-based config with OS-native sandboxing

OpenAI's Codex CLI uses a TOML-based configuration system with the most detailed sandbox controls of any tool.

### Directory structure

```
~/.codex/
├── config.toml         # Primary user-level config
├── AGENTS.md           # Global custom instructions
├── AGENTS.override.md  # Temporary override instructions
├── rules/              # Exec policy rule files
├── hooks.json          # Lifecycle hooks (experimental)
├── sessions/           # Session transcripts
└── log/                # Log files

.codex/                 # Project-level (requires trust)
└── config.toml         # Project-scoped overrides
```

Configuration precedence: CLI flags > profiles > project config > user config > system config (`/etc/codex/config.toml`) > built-in defaults. Project configs only load when explicitly trusted (`[projects."/path"].trust_level = "trusted"`).

### Approval and sandbox modes

| Approval Policy | Config Value | Behavior |
|----------------|-------------|----------|
| Suggest | `"untrusted"` | Asks before everything |
| Auto-edit | `"on-request"` | Auto-applies file changes, asks for commands |
| Full-auto | `"never"` | Auto-applies everything |

Sandbox modes: `read-only` (no writes, no network), `workspace-write` (write to workspace + /tmp, network blocked by default), and `danger-full-access` (full disk and network). Implementation uses **Apple Seatbelt** on macOS, **Bubblewrap + seccomp** on Linux, and **restricted tokens** on Windows.

### Model and provider configuration

Codex supports extensive provider configuration via `[model_providers.*]` blocks with `base_url`, `env_key`, `wire_api`, retry settings, custom headers, and query parameters. Profiles enable named configuration presets (`[profiles.auto]`, `[profiles.safe]`), switchable via `--profile`. The `shell_environment_policy` block provides fine-grained control over what environment variables the sandboxed agent can see, with `inherit`, `set`, `exclude`, and `include_only` options.

### Feature flags

Codex exposes a `[features]` block with stable flags (`multi_agent`, `shell_tool`, `collaboration_modes`) and experimental ones (`apply_patch_freeform`, `smart_approvals`, `codex_hooks`, `undo`). The `undo` feature creates per-turn git snapshots for rollback.

**Unique to Codex:** TOML configuration format, explicit project trust system, the most granular shell environment policy of any tool, profiles for quick context switching, and OS-native sandbox implementation with debug commands (`codex sandbox landlock -- ls -la`).

---

## 5. Aider: the most transparent model configuration

Aider's configuration is notable for its complete mapping between CLI flags, environment variables, and YAML config keys — every option works in all three forms.

### Configuration files

- **`~/.aider.conf.yml`** — User-level defaults
- **`<git-root>/.aider.conf.yml`** — Repo-level
- **`./.aider.conf.yml`** — Directory-level
- **`.aiderignore`** — Gitignore-syntax file exclusion
- **`.aider.model.settings.yml`** — Custom model behavior settings
- **`.aider.model.metadata.json`** — Model context windows and costs

Every CLI option maps to `AIDER_*` environment variable (replace `--` with `AIDER_`, `-` with `_`, uppercase). Precedence: CLI arguments > environment variables > current directory config > git root config > home directory config.

### Edit format system

Aider's edit format system is its most distinctive feature, directly controlling how the LLM communicates code changes:

- **`diff`** — Search/replace blocks (default for strong models like Claude, GPT-4o)
- **`whole`** — Full file content returned (for weaker models)
- **`udiff`** — Unified diff format (for GPT-4 Turbo)
- **`architect`** — Two-step: architect model proposes changes, editor model applies them
- **`diff-fenced`** / **`udiff-simple`** — Variants optimized for Gemini models
- **`editor-diff`** / **`editor-whole`** — Streamlined formats for the editor step in architect mode

### Repo-map

Aider builds a **PageRank-weighted code structure map** using tree-sitter parsing across 130+ languages. The `--map-tokens` setting (default: **1024**) controls the token budget; `--map-refresh` controls refresh frequency (`auto`, `always`, `files`, `manual`). When no files are explicitly added to chat, the map budget multiplies by `--map-multiplier-no-files` (default: 2).

### Lint and test integration

`--lint-cmd` accepts language-specific commands (`"python: flake8 --select=E,W"`), and `--auto-lint` (default: true) runs linting after every change. `--test-cmd` sets the test command, and `--auto-test` (default: false) runs tests after changes. When errors are detected, Aider automatically feeds them back to the LLM for iterative fixing.

### Model aliases

Built-in aliases map short names to full model identifiers (`sonnet` → `claude-sonnet-4-5`, `deepseek` → `deepseek/deepseek-chat`, `flash` → `gemini/gemini-flash-latest`). Custom aliases via `--alias "fast:gpt-4o-mini"` in config or CLI. Model settings files (`.aider.model.settings.yml`) customize per-model behavior including `edit_format`, `use_repo_map`, `streaming`, `cache_control`, and `extra_params`.

**Unique to Aider:** The most transparent configuration system (every option in three forms), edit format selection tied to model capability, PageRank-based repo-map, conventions loaded as read-only context files, and the most extensive set of pre-configured model aliases.

---

## 6. Windsurf: real-time awareness and automatic context retrieval

Windsurf (acquired by Cognition AI in mid-2025) differentiates through its "flow awareness" — monitoring edits, terminal, clipboard, and browser in real-time without requiring explicit context tagging.

### Rules directory

```
.windsurf/
├── rules/              # Workspace rules (.md files)
├── workflows/          # YAML workflow files (slash commands)
└── skills/             # Bundled reference scripts/templates
```

Rule files use YAML frontmatter with a `trigger` field:

| Trigger | Behavior | Context Cost |
|---------|----------|--------------|
| `always_on` | Included in every system prompt | Every message |
| `glob` | Activated when matching files are touched | Only on match |
| `model_decision` | AI reads description, decides relevance | Description always; content on demand |
| `manual` | Only via `@rule-name` mention | Only when invoked |

**Global rules** are stored at `~/.codeium/windsurf/memories/global_rules.md` (6,000 character limit). Workspace rules have a **12,000 character per file** limit. System-level rules for enterprise deploy via MDM to OS-specific directories (`/Library/Application Support/Windsurf/rules/*.md` on macOS).

### Memory and context system

Cascade (Windsurf's agent) automatically generates and stores memories during conversations at `~/.codeium/windsurf/memories/` — workspace-scoped, not committed to repos, not shared with teams. **Fast Context** uses proprietary SWE-grep models for parallel code retrieval at 20x the speed of traditional agentic search, with up to 8 parallel tool calls per turn. The `.codeiumignore` file (gitignore syntax) excludes files from indexing.

### Comparison with Cursor

The philosophical difference is automation level. Windsurf automatically retrieves context via RAG without manual `@file` tagging, while Cursor gives developers explicit control via `@file`, `@folder`, `@codebase` references. Windsurf supports system-level enterprise rules via MDM deployment; Cursor does not. Windsurf ships proprietary models (SWE-1.5 at 13x Sonnet speed); Cursor relies entirely on third-party models. Cursor offers background agents in cloud sandboxes; Windsurf added simultaneous Cascade panels in early 2026.

**Unique to Windsurf:** Real-time flow awareness, Fast Context with SWE-grep models, Codemaps (AI-annotated visual code navigation), enterprise system-level rules via MDM, and cross-IDE support (40+ IDEs vs. Cursor's single fork).

---

## 7. Continue.dev: the most model-agnostic configuration

Continue's open-source architecture supports the widest range of model providers and the most flexible role-based model assignment.

### Configuration files

The primary config is `~/.continue/config.yaml` (YAML, current) or `~/.continue/config.json` (deprecated). Workspace-level config at `<workspace>/.continue/config.yaml`. The YAML schema has four required fields: `name`, `version`, `schema: v1`, and `models`. Legacy `.continuerc.json` at workspace root provides JSON overlay with `mergeBehavior: "merge"` or `"overwrite"`.

### Model roles system

Continue unifies all model types under a single `models` array differentiated by **roles**: `chat`, `autocomplete`, `embed`, `rerank`, `edit`, `apply`, `summarize`. This enables assigning different providers to different tasks:

```yaml
models:
  - name: Claude Sonnet
    provider: anthropic
    model: claude-sonnet-4-20250514
    roles: [chat, edit, apply]
  - name: Starcoder
    provider: ollama
    model: starcoder2:3b
    roles: [autocomplete]
  - name: Voyage Reranker
    provider: voyage
    model: rerank-2
    roles: [rerank]
```

Continue supports **30+ providers** including OpenAI, Anthropic, Ollama, Azure, Bedrock, Gemini, DeepSeek, Mistral, xAI, Groq, Together, Cohere, LM Studio, and any OpenAI-compatible endpoint.

### Context providers

**15+ built-in providers**: `@File`, `@Code`, `@Diff`, `@CurrentFile`, `@Terminal`, `@Docs`, `@Open`, `@Web`, `@Codebase`, `@Folder`, `@Search`, `@Url`, `@Clipboard`, `@Tree`, `@Problems`, `@Debugger`, `@RepoMap`, `@OS`. Each accepts configuration params (e.g., `@Codebase` takes `nRetrieve: 25`, `nFinal: 5`, `useReranking: true`). Custom HTTP context providers POST to user endpoints.

### MCP server integration

MCP servers configured in the `mcpServers` array support three transport types (`stdio`, `sse`, `streamable-http`). Standalone MCP config files can be placed in `.continue/mcpServers/` directory (workspace or global) — JSON configs from Claude Desktop, Cursor, or Cline are auto-detected and compatible. Secrets use `${{ secrets.NAME }}` syntax resolved from `.env` files or Hub secrets.

**Unique to Continue.dev:** Role-based model assignment, the widest provider support, Hub-based config sharing and distribution, YAML anchors for DRY configuration, and compatibility with MCP config files from other tools.

---

## 8. Cline and Roo Code: mode-driven configuration

### Cline

Cline uses `.clinerules/` at project root (or single `.clinerules` file) containing plain Markdown instruction files. Global rules live at `~/Documents/Cline/Rules`. Files are processed in alphabetical order and injected into the system prompt. Conditional rules use YAML frontmatter with `paths:` glob patterns. Cline automatically detects `.cursorrules`, `.windsurfrules`, and `AGENTS.md` files.

Auto-approve is configured per-category: read project files, read all files, edit project files, edit all files, execute safe commands, execute all commands, use browser, use MCP servers, and mode transitions. YOLO mode auto-approves everything. MCP servers are configured in VS Code's global storage directory with standard JSON format.

### Roo Code extends Cline with modes

Roo Code's most distinctive contribution is **mode-specific configuration**. The `.roo/` directory contains mode-scoped subdirectories:

```
.roo/
├── rules/                # All modes
├── rules-code/           # Code mode only
├── rules-architect/      # Architect mode only
├── rules-debug/          # Debug mode only
├── rules-ask/            # Ask mode only
├── rules-{modeSlug}/    # Any custom mode
└── skills/               # Shared skills
```

**Five built-in modes** (Code, Architect, Ask, Debug, Orchestrator) each have different tool access levels. The **Orchestrator** mode breaks complex tasks into subtasks delegated to specialized modes — each subtask runs in isolated context with only summary returned. **Custom modes** are defined in `.roomodes` with slug, name, roleDefinition, tool groups, optional fileRegex restrictions, and custom instructions.

Global rules at `~/.roo/rules/` and `~/.roo/rules-{mode}/` apply across all projects. Rule loading precedence: global mode-specific → workspace mode-specific → fallback files → AGENTS.md → generic global → generic workspace → legacy fallback. Each mode remembers its last-used model, enabling per-mode model assignment.

Roo Code adds command allow/deny lists (`roo-cline.allowedCommands`, `roo-cline.deniedCommands`), codebase indexing with configurable embedding providers, API configuration profiles, timed auto-approval for follow-ups (1-300 seconds), full settings import/export, and Cloud Agents with Slack/GitHub integration.

**Unique to Roo Code:** Mode-specific rules directories, the Orchestrator/Boomerang pattern for task decomposition, custom mode definitions with tool group restrictions, and the most granular auto-approve system with max-cost budget controls.

---

## 9. Everything-Claude-Code: the meta-configuration layer

ECC is an open-source harness (~140K+ GitHub stars) that wraps Claude Code, Cursor, Codex, and OpenCode with additional configuration layers. Created by Affaan Mustafa, it won the Anthropic × Forum Ventures hackathon in September 2025.

### Four-layer architecture

| Layer | Components | Count |
|-------|-----------|-------|
| User Interaction | Slash commands, Rules | 72+ commands |
| Intelligence | Agents, Skills | 38 agents, 156+ skills |
| Automation | Hooks, Scripts | 20+ hooks |
| Learning | Continuous Learning v1/v2, Instincts | Self-improving |

### Hook profiles

The `ECC_HOOK_PROFILE` environment variable switches between three strictness levels without editing files:

- **`minimal`** — Only essential safety hooks (low overhead)
- **`standard`** (default) — Balanced quality, safety, and context management
- **`strict`** — All hooks active including commit quality checks, tmux reminders, git push reminders

Each hook in `hooks/hooks.json` is wrapped by `run-with-flags.js`, which checks the profile before execution. Individual hooks can be disabled via `ECC_DISABLED_HOOKS="hook-id-1,hook-id-2"`. PreToolUse hooks can **block** execution (exit code 2), while PostToolUse hooks are observational.

### Quality gates and security

The `/quality-gate` command runs ECC's quality pipeline on demand (supports `--strict` flag). **AgentShield** provides 1,282 tests and 102 security rules with an Opus 4.6-powered adversarial red-team/blue-team/auditor pipeline, producing graded security scores (A-F). Pre-commit hooks lint staged files, validate commit message format, and detect `console.log`/`debugger`/secrets. Config protection hooks prevent agents from modifying linter configs.

### Continuous learning

ECC's most novel feature is its **instinct-based learning system**: PreToolUse/PostToolUse observers extract patterns, assign confidence scores (0.3-0.9), and evolve instincts into reusable skills. This creates cross-session knowledge accumulation — no other tool offers self-improving configuration.

### Selective installation

Since v1.9.0, a manifest-driven installer with SQLite state tracking supports `--with`/`--without` flags for precise component selection across 12 language ecosystems. Installation profiles (core, developer, security, full) provide quick presets.

**Unique to ECC:** Cross-tool compatibility from a single repo, runtime hook profile switching, continuous learning with instinct evolution, AgentShield adversarial security scanning, and the largest pre-built component library (38 agents, 156 skills).

---

## 10. What's missing from all of them

Synthesizing across all nine tools reveals significant gaps in what current AI coding configuration systems offer. No single tool addresses all of the following needs, and most address fewer than half.

### Per-file and per-directory instruction scoping remains primitive

Only Claude Code (via `.claude/rules/` with `paths:` frontmatter), Cursor (via `globs` in `.mdc` files), Windsurf (via `trigger: glob`), and Copilot (via `applyTo` in `.instructions.md`) support file-pattern-scoped instructions. But none support **inheritance chains** — a `src/` rule overriding a root rule for its subtree, with `src/api/` further specializing. Roo Code's mode-specific directories come closest but scope by operational mode, not file path. The ideal system would support cascading rule inheritance mirroring CSS specificity: global → directory → file pattern → individual file.

### Dependency-aware context is entirely absent

No tool auto-detects and incorporates dependency relationships. When editing a function, none automatically pulls in the type definitions of its parameters, the implementations it calls, or the tests that exercise it. Aider's repo-map provides structural awareness via PageRank, and Cursor's semantic indexing finds related code, but neither understands the dependency graph. A configuration system should allow declaring dependency-following rules: "when editing files in `src/api/`, always include their corresponding types from `src/types/` and tests from `tests/api/`."

### Test strategy configuration barely exists

Aider offers `--test-cmd` and `--auto-test`; Cline/Roo Code have post-action diagnostics. But no tool allows configuring test strategy at the project level — specifying that new functions require unit tests, that API endpoints need integration tests, that coverage thresholds must be maintained, or that test-driven development should be enforced for specific directories. ECC's TDD workflow agent approximates this, but it's an agent behavior rather than a declarative configuration.

### CI/CD integration is ad-hoc at best

Copilot's coding agent runs as a GitHub Actions workflow, and ECC provides CI validation scripts, but no tool offers declarative CI/CD integration configuration — specifying that changes should trigger specific pipeline stages, that the agent should wait for CI results before proceeding, or that deployment approvals should be required. The `.github/workflows/copilot-setup-steps.yml` is the closest, but it only configures the agent's environment, not its interaction with the pipeline.

### Team and organization policy inheritance needs work

Copilot leads here with enterprise → organization → repository → personal instruction hierarchy and feature policy controls. Claude Code's managed settings provide enterprise enforcement. But most tools have at most two tiers (global and project). No tool supports **team-level policies** between organization and repository — configuring rules for the frontend team vs. the backend team vs. the platform team within the same organization.

### Security policy configuration is fragmented

Claude Code's permission rules and sandbox, Codex's exec policy and sandbox modes, and Copilot's content exclusion each address different security dimensions. But none provide a unified security policy covering file access, command execution, network access, secret handling, and audit requirements in a single declarative configuration. ECC's AgentShield is the most comprehensive security layer but operates as a scanning tool rather than a policy enforcement system.

### Cost and budget controls are minimal

Roo Code's `allowedMaxCost` per-session ceiling is the only explicit budget control. Claude Code surfaces cost information via `/cost` but doesn't enforce limits. Codex's `cost-aware-llm-pipeline` skill provides cost optimization patterns but not hard limits. No tool supports project-level budget allocation, per-developer quotas, model-tier restrictions based on task type, or automatic model downgrade when approaching budget limits.

### Output format and style controls are rudimentary

Claude Code's `outputStyle` setting and `CLAUDE_CODE_BRIEF` env var, plus all tools' instruction files, can influence output style. But no tool provides structured output format configuration — specifying that code should follow specific patterns, that comments should use JSDoc format, that commit messages should follow Conventional Commits, or that documentation should use a particular template. These must be hand-written in instruction files rather than declared as structured configuration.

### Multi-agent coordination config is embryonic

ECC's NanoClaw v2, Roo Code's Orchestrator mode, and Claude Code's subagent system enable multi-agent workflows. But coordination configuration is limited to agent definitions and delegation rules. No tool supports declarative multi-agent pipelines — specifying that code changes flow through architect → implementer → reviewer → tester, with configurable handoff conditions, parallel execution rules, and conflict resolution strategies.

### Approval workflows lack sophistication

Current approvals are binary (approve/deny per action category). No tool supports conditional approval chains — requiring senior review for production config changes, auto-approving test file modifications but requiring approval for API contracts, or escalating approvals when changes exceed a threshold size. Codex's granular approval policy and Roo Code's per-category toggles are the most advanced, but both lack conditional logic.

### Audit logging configuration is almost nonexistent

Codex's PostToolUse command logging and ECC's governance capture hooks provide basic audit trails. But no tool offers configurable audit logging — specifying what actions to log, where to send logs, retention policies, alert conditions, or compliance report generation. For enterprise adoption, declarative audit configuration (specifying that all file modifications, command executions, and model interactions should be logged to a SIEM) is essential.

### Context window management strategy is opaque

Claude Code's `CLAUDE_AUTOCOMPACT_PCT_OVERRIDE` and Aider's `--max-chat-history-tokens` provide some control. But no tool exposes a configurable context management strategy — specifying priority ordering for context elements (rules > current file > repo-map > conversation history), maximum allocation per context type, or compaction strategies (summarize vs. drop oldest vs. prioritize by relevance).

### What the ideal system would look like

The ideal AI coding configuration system would provide a **declarative, composable, inheritable** configuration language with these properties: **cascading specificity** (organization → team → repository → directory → file pattern → individual file), **typed rule categories** (security, style, testing, workflow, model, budget) with structured schemas rather than freeform Markdown, **conditional activation** based on file patterns, git branch, CI stage, or developer role, **policy enforcement tiers** (suggest, warn, block) per rule, **dependency-aware context** automatically following import/call graphs, **declarative multi-agent pipelines** with handoff conditions and parallel execution, **budget controls** with per-project quotas and automatic model tiering, **audit logging** with configurable destinations and retention, and **cross-tool portability** through a shared configuration standard (ECC and the emerging `AGENTS.md` convention are early steps toward this).

---

## Conclusion

The configuration landscape reveals a clear evolutionary trajectory. **Claude Code and Codex CLI** lead in depth — offering the most settings, the finest-grained permission and sandbox controls, and the most extensive environment variable surfaces. **Cursor and Windsurf** lead in conditional activation — their rule-type systems (always/auto-attached/agent-requested/manual) represent the state of the art for context-efficient instruction delivery. **Copilot** leads in organizational governance with its enterprise policy hierarchy. **Continue.dev** leads in model flexibility with its role-based multi-provider system. **Aider** leads in transparency with its every-option-in-three-forms approach. **Roo Code** leads in operational modes with its mode-specific rules and Orchestrator pattern. **ECC** leads in meta-configuration with its hook profiles, continuous learning, and cross-tool compatibility.

The most significant insight is that configuration complexity is growing faster than standardization. The emerging `AGENTS.md` convention (now read by Claude Code, Codex, Copilot, Windsurf, and Roo Code) is the first real cross-tool standard, but it covers only instructions, not the full configuration surface. The tools that will win are those that balance power with portability — enabling deep customization without locking teams into a single editor or provider.