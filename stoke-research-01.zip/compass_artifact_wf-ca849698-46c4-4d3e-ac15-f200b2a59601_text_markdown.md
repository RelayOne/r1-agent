# Production Rust engineering: the deep knowledge compendium

**Rust's production story has matured dramatically.** Cloudflare serves **1 trillion requests/day** through their Rust proxy Pingora, Discord eliminated Go's GC latency spikes with a Rust rewrite, and Google reports a **1000x reduction** in memory-safety vulnerability density for Rust vs C/C++ in Android. This guide distills the hard-won patterns, failure modes, and configuration details that separate production Rust from tutorial Rust — covering async runtimes, error handling, performance optimization, unsafe auditing, deployment, and the AI-assisted development patterns emerging across the ecosystem.

---

## Tokio runtime configuration and async cancellation safety

### Runtime builder for production services

Most production services should use the multi-thread runtime with explicit configuration rather than relying on `#[tokio::main]` defaults. The default worker count equals CPU cores, but containerized environments frequently report host CPU count instead of cgroup limits — requiring explicit override.

```rust
use tokio::runtime;
use std::sync::atomic::{AtomicUsize, Ordering};

fn build_runtime() -> runtime::Runtime {
    runtime::Builder::new_multi_thread()
        .worker_threads(4) // explicit for containers
        .enable_all()
        .thread_name_fn(|| {
            static ID: AtomicUsize = AtomicUsize::new(0);
            format!("svc-worker-{}", ID.fetch_add(1, Ordering::SeqCst))
        })
        .max_blocking_threads(128) // default ~512, often too high
        .thread_stack_size(3 * 1024 * 1024)
        .build()
        .expect("Failed to create Tokio runtime")
}
```

Use `current_thread` only for embedding Tokio in synchronous apps (GUI background threads, CLIs). The critical detail from Tokio GitHub discussion #6831: **with multi-thread runtime, the thread calling `block_on` only executes the single future passed to it** — spawned tasks don't run on that thread. Move server listeners into `tokio::spawn`.

### spawn vs spawn_blocking decision matrix

Alice Ryhl's rule of thumb: **no more than 10–100 microseconds between each `.await`**. Anything longer needs `spawn_blocking` or a dedicated thread.

| Work type | CPU-bound | Synchronous I/O | Long-running |
|-----------|-----------|-----------------|--------------|
| `spawn_blocking` | Suboptimal | ✅ OK | ❌ No |
| `rayon` | ✅ OK | ❌ No | ❌ No |
| Dedicated `std::thread` | ✅ OK | ✅ OK | ✅ OK |

A critical gotcha: **`spawn_blocking` tasks cannot be aborted** once started. Calling `abort()` on their `JoinHandle` has no effect, and they block runtime shutdown. For CPU-heavy computation, prefer `rayon` with a `oneshot` channel bridge:

```rust
async fn compute_hash(data: Vec<u8>) -> Vec<u8> {
    let (tx, rx) = tokio::sync::oneshot::channel();
    rayon::spawn(move || {
        let hash = blake3::hash(&data);
        let _ = tx.send(hash.as_bytes().to_vec());
    });
    rx.await.expect("rayon task panicked")
}
```

### The cancel-safety problem with `tokio::select!`

Cancellation — dropping a future before completion — happens at any `.await` point. This is the single most insidious source of production bugs in async Rust, documented extensively by Rain Paharia at Oxide Computer Company and in Oxide's RFD 400.

**Cancel-safe** operations (from Tokio docs): `mpsc::Receiver::recv()`, `tokio::time::sleep()`, `TcpListener::accept()`, `StreamExt::next()`. **Cancel-unsafe** operations: `mpsc::Sender::send(msg)` (message lost forever), `AsyncReadExt::read_exact()` (partial read data lost), any `async fn` accumulating state across `.await` points.

A real Oxide production bug — `MutexGuard` held across an await with state mutation:

```rust
// DANGEROUS: if cancelled between take() and reassignment, data vanishes
let guard = mutex.lock().await;
let data = guard.data.take(); // State now None
let new_data = process(data).await; // ← cancellation point!
guard.data = Some(new_data); // Never reached if cancelled
```

**Three patterns that fix cancel safety:**

First, use `reserve()` + synchronous `send()` for channel operations in `select!` loops — `reserve()` is cancel-safe, and `send()` on the permit is synchronous. Second, use `tokio::pin!` (or `std::pin::pin!` since Rust 1.68) to persist futures across `select!` loop iterations. Third, spawn tasks for work that must run to completion regardless of parent cancellation.

Oxide's systemic fix: their Dropshot HTTP framework now spawns each request as a separate task that **is not aborted** on client disconnect, eliminating client-initiated cancellation as a bug source.

---

## Error handling: thiserror, anyhow, snafu, and eyre

The core decision isn't "library vs application" — it's **whether callers need to react differently based on the failure mode**. Jane Lusby (eyre's author): "The reasons for using anyhow vs thiserror aren't really about library vs application — it's about whether you need to **handle** errors or **report** them."

### When to use each

**thiserror** generates `std::error::Error` implementations via derive macros. Use it for libraries and any API where callers need matchable variants. It deliberately **does not appear in your public API** — switching from hand-written impls to thiserror is not a breaking change.

**anyhow** provides an opaque `anyhow::Error` for application code where you just propagate and report. Both anyhow and eyre explicitly warn against use in library public APIs. A production caveat from ShakaCode: anyhow becomes messy in large apps when errors that start as "just propagate" later need programmatic handling, forcing refactors to typed errors.

**snafu** uses auto-generated *context selectors* per error variant, type-checking that you provide all required context fields. Its philosophy: "one error enum per module" with private context selectors. Ideal for complex systems where the same underlying error (e.g., `io::Error`) occurs in different contexts.

**eyre** is an anyhow fork with pluggable `EyreHandler` for custom report formatting. Pair with **`color-eyre`** for colorful backtraces and tracing span traces.

### The opaque public error pattern

From thiserror's own docs — this pattern lets you evolve internal errors without breaking downstream:

```rust
#[derive(thiserror::Error, Debug)]
#[error(transparent)]
pub struct PublicError(#[from] ErrorRepr);

// Private and free to change across minor versions
#[derive(thiserror::Error, Debug)]
enum ErrorRepr {
    #[error("invalid header: expected {expected:?}, found {found:?}")]
    InvalidHeader { expected: String, found: String },
    #[error("connection failed")]
    Connection(#[from] std::io::Error),
}
```

Always use **`#[non_exhaustive]`** on public error enums — it forces downstream code to include a wildcard arm, letting you add variants without breaking changes. The standard library previously used a `#[doc(hidden)] __Nonexhaustive` variant hack; the attribute is strictly better.

---

## Ownership patterns that trip up AI code generators

### The clone crutch and its alternatives

The Rust Design Patterns book explicitly documents unnecessary `.clone()` as an anti-pattern. AI code generators — trained primarily on garbage-collected languages — systematically reach for `.clone()` rather than restructuring code to satisfy the borrow checker.

```rust
// ❌ AI-generated: clone in a loop
fn find_longest(strings: &[String]) -> String {
    let mut longest = strings[0].clone();
    for s in strings {
        if s.len() > longest.len() { longest = s.clone(); }
    }
    longest
}

// ✅ Idiomatic: return a reference, zero allocations
fn find_longest(strings: &[String]) -> &str {
    strings.iter().max_by_key(|s| s.len()).map(|s| s.as_str()).unwrap()
}
```

Use `std::mem::take` and `std::mem::replace` instead of cloning when you need to move values out of mutable references. Clone `Arc<T>` freely (just a reference count increment), but clone `String`, `Vec`, and `HashMap` only when genuinely necessary.

### Arc\<Mutex\<T\>\> overuse

AI generators wrap everything in `Arc<Mutex<T>>` as "easy mode concurrency." Alternatives: **channels** (`mpsc`) when threads produce/consume data, **`RwLock`** when reads dominate, **`AtomicU64`** for simple counters, **`tokio::sync::Mutex`** for async code (not `std::sync::Mutex`), or simply **passing data by ownership** instead of sharing.

### Cow\<'\_, str\> for zero-copy APIs

`Cow` eliminates unnecessary allocations in functions that *usually* return borrowed data but sometimes need to allocate:

```rust
fn sanitize(input: &str) -> Cow<'_, str> {
    if input.contains('<') {
        Cow::Owned(input.replace('<', "&lt;"))
    } else {
        Cow::Borrowed(input) // zero allocation
    }
}
```

### Borrow checker fights with idiomatic solutions

**Struct field splitting**: The borrow checker permits simultaneous borrows of disjoint struct fields via direct field access, but not through method calls (which borrow all of `self`). Access fields directly when you need to borrow multiple simultaneously.

**Collection mutation during iteration**: Use `retain()` (Rust 1.70+) or collect keys first, then mutate. Never iterate and mutate a `HashMap` simultaneously.

**`split_at_mut`** for borrowing multiple mutable slice elements: `let (left, right) = v.split_at_mut(1);` gives disjoint mutable slices.

---

## Testing: proptest, fuzzing, criterion, and mutation testing

### Property-based testing with proptest

proptest excels for parsers, serialization roundtrips, and data structures. Unlike QuickCheck, it uses explicit `Strategy` objects for generation and shrinking on a per-value basis:

```rust
use proptest::prelude::*;
proptest! {
    #[test]
    fn parse_roundtrip(y in 2000..2100u32, m in 1..13u32, d in 1..29u32) {
        let s = format!("{:04}-{:02}-{:02}", y, m, d);
        let parsed = parse_date(&s).unwrap();
        prop_assert_eq!(parsed, (y, m, d));
    }
}
```

When a test fails, proptest automatically **shrinks** the input to the minimal failing case — e.g., reducing `(7360, 12, 20)` to `(0, 10, 1)`. Failed cases persist in `proptest-regressions/` files for regression testing.

### Fuzzing with cargo-fuzz

The Rust Fuzz Trophy Case documents hundreds of real bugs found. The canonical setup uses structured fuzzing via the `Arbitrary` trait. For CI, use `-- -runs=0` for regression testing against the existing corpus without open-ended fuzzing. Use `--sanitizer none` for a **2x speedup** when fuzzing safe Rust code (no UB to detect).

### Criterion vs divan for benchmarks

Criterion provides bootstrap resampling (100,000 resamples) with confidence intervals and HTML reports. **Divan** is the newer alternative with more idiomatic `#[divan::bench]` attributes, built-in allocation profiling via `AllocProfiler`, and automatic sample scaling. Criterion has more mature statistical analysis; divan has better ergonomics and active development.

### cargo-mutants for mutation testing

cargo-mutants injects synthetic bugs (replacing function bodies with `Default::default()`, `true`, `0`, etc.) and checks whether tests catch them. **Missed mutants indicate undertested code.** Use `--in-diff git.diff` in CI to only test mutations in changed code. Skip specific functions with `#[mutants::skip]`.

### Test organization best practices

Use `tests/common/mod.rs` (not `tests/common.rs`) for shared fixtures — a file directly in `tests/` is treated as its own test crate. Group related integration tests in a single file or use `tests/main.rs` with submodules to reduce compilation overhead (each `tests/*.rs` file compiles as a separate binary).

---

## Unsafe code audit practices and Miri

### SAFETY comments are mandatory

The Rust standard library, Linux kernel, and Fuchsia OS all enforce a strict convention: **`// SAFETY:` comments** on every `unsafe` block explaining which invariants are upheld, and **`# Safety` doc sections** on every `unsafe fn` documenting the caller's contract. Clippy enforces this via `clippy::undocumented_unsafe_blocks` and `clippy::missing_safety_doc`.

```rust
pub fn split_at(&self, mid: usize) -> (&str, &str) {
    if self.is_char_boundary(mid) {
        // SAFETY: just checked that `mid` is on a char boundary.
        unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
    } else { slice_error_fail(self, 0, mid) }
}
```

### How audit firms find bugs

The RUDRA tool (Georgia Tech, SOSP 2021) scanned **43,000 crates** in 6.5 hours, finding **264 previously unknown memory safety bugs** resulting in **76 CVEs**. The three major bug patterns: panic safety violations (unsafe code not accounting for panics during partial operations), incorrect `Send`/`Sync` trait implementations on generic types, and unsound public APIs wrapping incorrect unsafe internals.

NCC Group has audited RustCrypto AES/GCM, WhatsApp's `opaque-ke`, and Zcash's Zebra. Trail of Bits audited Parity Ethereum's Rust codebase. Common findings include: aliasing violations, missing bounds checks before unchecked operations, panic safety issues where unwinding leaves corrupted state, and missing zeroization of secrets.

### Miri: the definitive UB detector

Miri interprets Rust's MIR to detect undefined behavior including out-of-bounds access, use of uninitialized memory, data races, and **Stacked Borrows aliasing violations**. Run it with `cargo +nightly miri test`. From the POPL 2026 paper by Ralf Jung: Miri is "the first tool that can find all de-facto Undefined Behavior in deterministic Rust programs — no other freely available tool can claim this, for any language."

Use **`#![forbid(unsafe_code)]`** at crate root to statically guarantee pure safe Rust. Use **`cargo-geiger`** to audit unsafe in dependencies — it produces a dependency tree annotated with unsafe usage statistics, using 🔒 (safe + declared), ❓ (safe, missing declaration), and ☢️ (unsafe found).

---

## Performance: release profiles, SIMD, arenas, and PGO

### The production release profile

```toml
[profile.release]
opt-level = 3          # maximum speed
lto = "fat"            # cross-crate link-time optimization
codegen-units = 1      # single LLVM module, best optimization
panic = "abort"         # no unwinding overhead (~5-10% smaller)
strip = true           # remove symbols

# For binary-size-critical deployments (Lambda, embedded):
# opt-level = "z"      # optimize for smallest size
```

**LTO "fat" vs "thin"**: Fat LTO produces the best optimization but can take minutes for large projects. Thin LTO is parallelizable and nearly as good — use it when compile time matters. **`codegen-units = 1`** eliminates compilation parallelism but enables LLVM to optimize across the entire crate. Always pair with `RUSTFLAGS="-C target-cpu=native"` for server deployments to enable AVX2/SSE4.2.

### Allocation-free hot paths

The Rust Performance Book notes that reducing allocation rates by **10 allocations per million instructions** can yield measurable improvements (~1%) in rustc. Key techniques:

- **Reuse buffers**: Take `&mut Vec<T>` and call `.clear()` between iterations instead of allocating per-iteration
- **`Vec::with_capacity(n)`**: Pre-allocate when size is known
- **`clone_from()`**: Reuses existing allocation (`v1.clone_from(&v2)` preserves `v1`'s capacity)
- **`SmallVec<[T; N]>`**: Stack-allocates up to N elements, spilling to heap. Used extensively in rustc and Servo. However, benchmarks show SmallVec can be **slower** than pre-allocated Vec in many cases due to inline/heap checking overhead — always profile

### Arena allocation with bumpalo

Bump allocation is O(1) per allocation and O(1) for mass deallocation — ideal for parsers, compilers, and request-scoped allocations:

```rust
use bumpalo::Bump;
async fn handle_request(req: Request) -> Response {
    let arena = Bump::new();
    let parsed = arena.alloc(parse_headers(req.body()));
    let tokens = bumpalo::vec![in &arena; "a", "b"];
    // All memory freed instantly when arena drops
    Response::new(serialize(&tokens))
}
```

**Important**: Drop implementations are NOT called when the arena drops. Use `bumpalo::boxed::Box` for values that need Drop.

### Profile-guided optimization delivers 10%+ gains

```bash
# Simplified with cargo-pgo:
cargo install cargo-pgo
cargo pgo build                    # instrumented binary
./target/.../mybinary <workload>   # gather profiles
cargo pgo optimize build           # optimized binary
```

Combine PGO with **BOLT** (post-link binary optimization) for an additional 2–5% improvement by reorganizing instructions for better instruction cache utilization. The PGO + LTO + BOLT combination has shown **34–68% performance uplift** in compiled programs.

---

## How Cloudflare, Discord, Figma, and AWS use Rust

### Cloudflare Pingora: 70% less CPU than NGINX

Pingora replaced Cloudflare's NGINX infrastructure and now serves **over 1 trillion requests/day**. The multi-threaded Rust architecture improved connection reuse from 87.1% to **99.92%** — requiring **160x fewer new connections** for one major customer. Rust's async model enabled this: NGINX's per-process architecture couldn't share TCP connections across workers.

### Discord: eliminating Go's GC latency spikes

Discord's Read States service maintained an LRU cache with millions of entries and hundreds of thousands of modifications per second. **Go's garbage collector ran every 2 minutes**, causing **10–40ms latency spikes** as it scanned the entire cache. The Rust rewrite eliminated these spikes entirely — Rust frees memory deterministically when values leave scope. Even with basic optimization, Rust outperformed the hyper-tuned Go version by roughly **4x**.

### Figma: order-of-magnitude multiplayer improvement

Figma rewrote their real-time multiplayer syncing server from TypeScript to Rust. The original single-threaded server couldn't process operations in parallel — a single slow encoding operation would lock the entire worker. The Rust rewrite delivered an **order of magnitude improvement** in server-side performance. An early challenge: two Rust compression libraries had subtle correctness issues; Figma fell back to a proven C library via FFI.

### AWS Firecracker: 50,000 lines powering Lambda

Firecracker's lightweight VMM is **only 50,000 lines of Rust** — a **96% reduction** versus QEMU. It boots in **<125ms** with **<5 MiB memory overhead** per microVM and creates up to **150 microVMs per second**. It powers AWS Lambda (trillions of executions/month) and Fargate. Three threads per VMM: API server, VMM, and vCPU(s), using Rust channels for inter-thread communication.

### The universal migration pattern

Every major migration — Discord from Go, Figma from TypeScript, Cloudflare from Lua/NGINX, Dropbox from Python, 1Password from Go — cites **garbage collection latency** or **unpredictable performance** as the primary motivation. Companies consistently start small (a library, a non-critical service) and expand. Google's Android data is the strongest evidence: memory safety vulnerabilities dropped from **76% of total (2019) to below 20% (2024)** with Rust adoption, and zero memory safety vulnerabilities have been found in Android's Rust code.

---

## Cross-compilation, static binaries, and containers

### musl for fully static Linux binaries

```bash
rustup target add x86_64-unknown-linux-musl
cargo build --release --target=x86_64-unknown-linux-musl
# Result: fully static, zero dynamic dependencies
```

The most common musl pitfall is OpenSSL. Prefer **rustls** over OpenSSL entirely (`reqwest = { features = ["rustls-tls"], default-features = false }`). musl's DNS resolver doesn't support NSS modules — use `hickory-dns` or Tokio's native resolver.

### The cargo-chef Docker pattern

Without cargo-chef, any source change invalidates the dependency compilation cache. cargo-chef achieves **up to 5x speedup** by separating dependency compilation into a cacheable layer:

```dockerfile
FROM lukemathwalker/cargo-chef:latest-rust-1 AS chef
WORKDIR /app

FROM chef AS planner
COPY . .
RUN cargo chef prepare --recipe-path recipe.json

FROM chef AS builder
COPY --from=planner /app/recipe.json recipe.json
RUN cargo chef cook --release --recipe-path recipe.json  # cached layer
COPY . .
RUN cargo build --release --bin app

FROM gcr.io/distroless/cc-debian12
COPY --from=builder /app/target/release/app /
CMD ["/app"]
```

For musl static binaries, use `gcr.io/distroless/static-debian12` or `FROM scratch` for **~2–10 MB final images**. Use **`cargo-zigbuild`** for easy cross-compilation via Zig's bundled sysroots — it handles glibc version targeting (`--target aarch64-unknown-linux-gnu.2.17`) without multiarch packages.

---

## Cargo workspace patterns for monorepos

### Workspace dependency inheritance (Rust 1.64+)

Centralize versions in the root `Cargo.toml`:

```toml
[workspace]
members = ["crates/*"]
resolver = "2"

[workspace.dependencies]
serde = { version = "1.0", features = ["derive"] }
tokio = { version = "1.0", features = ["full"] }
my-core = { path = "crates/my-core" }

[workspace.lints.rust]
unsafe_code = "forbid"

[workspace.lints.clippy]
all = { level = "deny", priority = -1 }
pedantic = { level = "warn", priority = -1 }
unwrap_used = "deny"
module_name_repetitions = "allow"
```

Members opt in with `serde = { workspace = true }` and `[lints] workspace = true`. Features are **additive** — member-level features union with workspace-level features.

### The feature unification pitfall

When multiple workspace crates depend on the same package with different features, Cargo builds it once with the **union of all features**. This can silently include wrong backends. Mitigate by using `default-features = false` at workspace level and enabling features per-member. Use **`cargo-hack check --each-feature --workspace`** in CI to test each feature independently.

### Workspace-hack crates for build speed

If building different workspace members causes shared dependencies to rebuild with different feature sets, use **`cargo-hakari`** to auto-generate a workspace-hack crate that depends on everything with the union of all features. This produces **15–95% speedup** for individual builds. The Rust compiler itself uses `rustc-workspace-hack` for this purpose.

The matklad pattern for monorepo organization: flat `crates/` directory, virtual manifest at root, `version = "0.0.0"` with `publish = false` for internal crates, and the `cargo xtask` pattern for Rust-based automation instead of shell scripts.

---

## AI coding assistant configurations the Rust community has published

### The emerging standard: CLAUDE.md and .cursorrules for Rust

A clear consensus has emerged across dozens of published Rust AI configuration files. The most referenced is **minimaxir's CLAUDE.md** (127 stars), which enforces: no `.unwrap()` in library code, `Result<T, E>` for all fallible operations, `&str` over `String` for parameters, `Cow<'_, str>` when ownership is conditional, `Vec::with_capacity()` when size is known, and `thiserror`/`anyhow` for error handling.

**tyrchen/cursor-rust-rules** (26 stars) provides the most comprehensive `.cursorrules` with a modular `.mdc` file architecture covering Axum, SQLx, concurrency, observability, and workspace patterns. **GitHub's official `awesome-copilot`** repository (28.5k stars) includes `rust.instructions.md` with 135 lines of Rust-specific guidance.

The **ms-rust SKILL.md** pattern is the most rigorous — built on Microsoft's Pragmatic Rust Guidelines, it splits into 12 guideline files (staying under Claude's 25K token limit) covering AI agents, FFI, performance, safety, and library design. It enforces compliance with `// Rust guideline compliant {date}` comments.

### Universal patterns across all configurations

Nearly every Rust AI configuration enforces the same core rules:

- **Pre-commit**: `cargo fmt && cargo clippy -- -D warnings && cargo test` (universal)
- **No `.unwrap()`** in production code; `.expect()` only for invariant violations
- **Prefer borrowing** (`&T`, `&str`) over ownership (`T`, `String`) for parameters
- **thiserror** for library errors, **anyhow** for application errors
- **Iterator combinators** over index-based loops
- **`tokio`** as default async runtime, **`rayon`** for CPU-bound parallelism
- **Avoid `unsafe`** unless required; document safety invariants when used
- **`tracing`** or **`log`** instead of `println!` for diagnostics

The **`zircote/rust-lsp`** Claude Code plugin adds 16 automated hooks including auto-format on edit, compile-check on edit, clippy on edit, and TODO/FIXME surfacing — representing the frontier of automated Rust development assistance.

---

## Conclusion

Production Rust demands a different mental model than tutorial Rust. The critical insights that separate the two: **cancellation safety** in async code is the most insidious source of production bugs — use `reserve()` + synchronous `send()`, spawn tasks for must-complete work, and avoid holding mutated state across `.await` points. **Error types are an API contract** — libraries must use concrete types (thiserror/snafu), not opaque ones (anyhow/eyre). **Clone and Arc\<Mutex\<T\>\> are code smells** when used to silence the borrow checker rather than solve genuine ownership problems.

For performance-critical work (parsers, crypto, VM management), the highest-impact optimizations are: the full release profile (`lto = "fat"`, `codegen-units = 1`, `panic = "abort"`, `strip = true`), PGO + BOLT (10–68% improvement), arena allocation for batch-processed data, and buffer reuse via `clear()` on hot paths. The SmallVec vs Vec choice requires benchmarking — SmallVec's inline/heap checking overhead can actually make it slower than a pre-allocated Vec.

The companies running Rust at the largest scale — Cloudflare, Discord, AWS, Google — all adopted it incrementally, starting with a single non-critical service. The universal migration driver was **deterministic performance** (no GC pauses), and the universal outcome was dramatically fewer production incidents from memory safety bugs. The AI coding configuration ecosystem is converging on a clear set of Rust-specific rules that encode these same production patterns — making the hard-won knowledge of the Rust production community accessible to every developer with an AI assistant.