# Production Go rules for AI coding agents

**The most impactful Go rules for AI coding agents encode hard-won knowledge about concurrency bugs, memory management, and error handling that static analysis cannot catch.** After analyzing production postmortems from Uber, CockroachDB, and Kubernetes, existing CLAUDE.md and .cursorrules files from production Go teams, and official Go team guidance, this report distills the deepest Go-specific patterns into actionable rules organized by failure domain. These rules target the exact stack described — Go services on Cloud Run and Fly.io handling payments, Kafka consumption, and PostgreSQL operations. Research shows that human-curated AI rules files yield ~4% task success improvement, but bloated files actually hurt performance — keep rules under **200 lines** with severity levels and stable IDs for reference.

---

## 1. Concurrency bugs that static analysis misses

Go's concurrency primitives are deceptively simple. Uber's analysis of **2,000 data races across 50 million lines of Go** revealed patterns that no linter catches reliably. The core principle, from Dave Cheney: *"Never start a goroutine without knowing how it will stop."*

**Goroutine leaks** are the most common production failure. A WebSocket notification service leaked **50,846 goroutines** over six weeks, consuming 47 GB of RAM because `context.Cancel` was never called on client disconnect. Uber's LeakProf tool found 10 critical leaking goroutines in production, with fixes yielding **2.5× and 5× memory reductions**. The canonical leak pattern is a goroutine sending on an unbuffered channel after the receiver has returned due to a timeout — fix by using `make(chan result, 1)` for any channel used as a return path in goroutines with timeouts.

**The errgroup context shadow bug** is a particularly insidious production failure found in Ory Kratos. When you write `g, ctx := errgroup.WithContext(ctx)`, the returned context is cancelled when `Wait()` returns — even on success. Any code using `ctx` after `Wait()` fails with "context canceled." The fix is to never shadow the parent context: use `g, gCtx := errgroup.WithContext(ctx)` and use the parent `ctx` for work after the group completes.

**Race conditions on multi-word values** — slices (3 words: pointer, length, capacity) and interfaces (2 words: type, data) — can corrupt memory when accessed concurrently. A concurrent write to an interface value can produce a Frankenstein where the type pointer comes from one goroutine and the data pointer from another. The race detector catches these at runtime, but static analysis cannot.

### Concurrency rules to encode

- Every `go` statement requires a documented exit condition; every goroutine must select on `ctx.Done()` or have bounded lifetime
- Channels used as return paths in timeout/select patterns must be buffered (capacity ≥ 1)
- Only senders close channels; multiple senders coordinate close via `sync.WaitGroup`
- Always check `val, ok := <-ch` when a channel may be closed
- Use directional channel types (`chan<-`, `<-chan`) in function signatures
- Never shadow parent context with errgroup: use `g, gCtx := errgroup.WithContext(ctx)`
- Always `defer cancel()` immediately after creating any derived context
- Always `defer ticker.Stop()` and `defer resp.Body.Close()`
- Place `wg.Add(1)` before `go func()`, never inside the goroutine
- Use `g.SetLimit(n)` for errgroups processing large collections
- Default to `map + sync.RWMutex`; only use `sync.Map` for read-heavy, write-once caches or disjoint key access patterns (per Bryan Mills' documentation)
- Never store contexts in structs; pass as first parameter
- Use `-race` flag in all tests and CI — non-negotiable
- Use `goleak.VerifyNone(t)` from uber-go/goleak in tests to detect goroutine leaks

---

## 2. Memory management at scale in containers

**GOMEMLIMIT, introduced in Go 1.19 by Michael Knyszek, is the single most impactful production tuning knob for containerized Go services.** Without it, Go's GC targets a heap size proportional to current live data (GOGC=100 means 2× live heap), which can overshoot container memory limits and trigger OOM kills. Uber saved **70,000 CPU cores** across 30 mission-critical services by tuning GC behavior relative to container memory.

For dedicated containers where Go is the sole process, the recommended approach is `GOGC=off` with `GOMEMLIMIT` set to **90% of container memory**. This maximizes resource economy — the heap uses available memory freely, with GC triggering only when approaching the limit. The `automemlimit` library (`import _ "github.com/KimMachineGun/automemlimit"`) reads cgroup memory limits automatically and is used by Grafana, GitLab Runner, and Kiali in production. Pair it with `automaxprocs` (`import _ "go.uber.org/automaxprocs"`) for CPU-aware GOMAXPROCS.

**GC pauses in modern Go (1.8+) are typically under 100 microseconds** even with large heaps. The concurrent mark phase can cause application-visible latency, but STW pauses are proportional to GOMAXPROCS, not heap size. Go 1.26's Green Tea GC (default since February 2026) delivers **10–40% reduction in GC CPU overhead** through page-based scanning with SIMD acceleration.

**sync.Pool** survives at least two GC cycles via a victim cache mechanism (since Go 1.13). It's effective for high-frequency, short-lived objects like `bytes.Buffer` and `*flate.Writer`, but counterproductive for trivial allocations — Pool Get/Put costs ~3.9 ns/op versus ~0.24 ns/op for direct allocation of simple types. Always reset objects before `Put()`: call `buf.Reset()`, zero struct fields, or truncate slices to `s[:0]`.

**Heap escape analysis** determines whether a variable lives on the stack (free) or heap (costs GC time). Common escape triggers: returning pointers to local variables, interface conversions (boxing), closures capturing variables, and goroutine captures (always escape). Use `go build -gcflags="-m"` to audit hot paths. Prefer returning structs by value for small types (≤128 bytes), use `strconv` instead of `fmt.Sprintf` in hot paths, and pre-allocate slices with `make([]T, 0, expectedCap)`.

### Memory rules to encode

- In containerized deployments, always set `GOMEMLIMIT` (90% of container memory) or use `automemlimit`
- For dedicated containers, use `GOGC=off` + `GOMEMLIMIT`; for shared containers, keep `GOGC=100` + `GOMEMLIMIT` at 80%
- Use `import _ "go.uber.org/automaxprocs"` for container-aware GOMAXPROCS
- Always reset pooled objects before `Put()` back to `sync.Pool`
- Use `strings.Builder` with `Grow()` for string concatenation in loops — never `+` in loops
- Copy small slices derived from large slices to release the backing array
- When deleting from pointer slices, nil out vacated positions to prevent retention
- Return structs by value instead of pointers when the struct is small and doesn't need shared mutation
- Pre-allocate slices and maps when size is known: `make([]T, 0, n)`
- Avoid `fmt.Sprintf` in hot paths — use `strconv.Itoa`, `strconv.FormatFloat`
- Never expose `/debug/pprof/` endpoints publicly — bind to localhost or internal port only

---

## 3. Error handling patterns from the best Go projects

Go 1.13 introduced `errors.Is`, `errors.As`, and `%w` wrapping — but the real wisdom is in *when* to use each pattern. The official Go blog states: **"Wrap an error to expose it to callers. Do not wrap an error when doing so would expose implementation details."** Use `%w` when the underlying error is part of your API contract; use `%v` to obfuscate internal errors.

**CockroachDB** built `cockroachdb/errors` as a drop-in replacement for the standard library because distributed databases need errors that survive network serialization across nodes running different software versions. Their library adds PII-safe error reporting (redactable vs. non-redactable parts), protobuf-based encoding, and `errors.AssertionFailedf()` for internal bugs that are "louder" than normal errors. The key lesson: in distributed systems and payment services, errors must carry structured metadata while keeping user-facing messages clean.

**Kubernetes** uses a single `StatusError` type wrapping `metav1.Status`, with typed constructor functions for every HTTP-like error (`NewNotFound`, `NewConflict`, `NewTooManyRequests`) and boolean predicates (`IsNotFound(err)`, `IsConflict(err)`). This pattern — **error factories + predicate functions** — is excellent for services with well-defined failure modes like payment processing.

**Dave Cheney's hierarchy** remains the gold standard: assert errors for *behavior*, not type. Define interfaces like `interface{ Retryable() bool }` or `interface{ Temporary() bool }` and check with `errors.As`. This creates the least coupling and works naturally with error wrapping. For payment systems specifically, always classify errors as retryable (408, 429, 5xx, network timeouts) versus non-retryable (400, 401, card declined, insufficient funds), and embed retry-after hints in retryable errors.

For multi-errors, Go 1.20's `errors.Join` replaces `hashicorp/go-multierror` for new projects — the go-multierror README itself recommends this. Use multi-errors for validation functions checking multiple fields and concurrent operations where multiple independent tasks can fail.

### Error handling rules to encode

- Always use `errors.Is` instead of `==` and `errors.As` instead of type assertions
- Wrap with `fmt.Errorf("operation: %w", err)` to add context at each level; use `%v` to hide internals
- Handle errors exactly once — either log or return, never both
- Error strings: lowercase, no trailing punctuation, no "failed to" prefixes (they pile up)
- Define sentinel errors as `var ErrNotFound = errors.New("not found")` with `Err` prefix
- For Go 1.20+, prefer `errors.Join` over third-party multi-error libraries
- Assert errors for behavior (`interface{ Retryable() bool }`) rather than concrete type when possible
- In payment systems: classify retryable vs non-retryable; implement idempotency keys stored in PostgreSQL
- Never `panic` for expected error conditions — only for truly irrecoverable states or `init()`
- Use `context.WithCancelCause` (Go 1.20+) to propagate error reasons through cancellation

---

## 4. Interface design philosophy from the Go team

Rob Pike's Go Proverb #4 — **"The bigger the interface, the weaker the abstraction"** — is the most important interface rule. `io.Reader` has one method and is used by 39+ standard library packages. Every method added to an interface reduces the number of types that can satisfy it.

The Go Code Review Comments wiki (the closest thing to official style rules) states three critical don'ts: **do not define interfaces on the implementor side "for mocking"**; do not define interfaces before they are used; and do not create preemptive interfaces. This directly contradicts Java/C# patterns where interfaces are defined alongside implementations. In Go, interfaces belong in the **consumer** package — the package that *uses* the interface, not the one that implements it. The producer returns concrete types so new methods can be added without breaking consumers.

"Accept interfaces, return structs" means function parameters should be interfaces (accepting any compatible type) while return types should be concrete structs (giving callers full access to capabilities). The exception: factory functions that return different concrete types based on runtime conditions, like `io.LimitReader` returning `io.Reader`.

**When NOT to use interfaces:** When only one implementation exists (premature abstraction), when the interface would have more than 3 methods (too large), and when defining them "for testing" on the implementor side. If a struct has only one implementation and no cross-package boundary to abstract, use the concrete type. Start with concrete types and extract interfaces only when a second implementation or a testing boundary demands it.

### Interface rules to encode

- Keep interfaces to 1–3 methods; compose larger interfaces from smaller ones via embedding
- Define interfaces where they are used (consumer package), not where implemented
- Accept interfaces, return concrete structs
- Never define interfaces before they are used — avoid premature abstraction
- Use compile-time verification: `var _ Interface = (*Type)(nil)`
- Pass interfaces as values, never as pointers to interfaces
- Standard library interfaces (`io.Reader`, `io.Writer`, `http.Handler`, `fmt.Stringer`) are the gold standard — study and follow their patterns
- Use the `-er` suffix for single-method interfaces: `Reader`, `Writer`, `Closer`

---

## 5. Project layout: what actually works

Russ Cox, Go's tech lead, opened an issue on the `golang-standards/project-layout` repository explicitly stating **"this is not a standard Go project layout"** and that "Go repos tend to be much simpler" than what it describes. Eli Bendersky (Go team) called it "harmful for Go beginners." The repository's `pkg/` directory recommendation contradicts actual Go ecosystem practice — the vast majority of Go packages do not use `pkg/`.

The official Go team guidance lives at `go.dev/doc/modules/layout` and prescribes minimal structure: `go.mod` + source files. For a server handling payments, Kafka, and PostgreSQL, `internal/` is the key organizing principle — servers don't export packages, so everything should be internal by default. Eli Bendersky's guidance: "If you're wondering whether some package belongs in internal, begin by answering yes."

**What large projects actually use:** Kubernetes, Docker, Terraform, Consul, Vault, and CockroachDB all use `cmd/` for entry points and `internal/` for private packages. Kubernetes and Docker use `pkg/` but this is legacy — Dave Cheney and Eli Bendersky both argue against it. The practical layout for a Go service:

```
myservice/
  go.mod
  main.go
  internal/
    payment/       # Payment domain logic + handlers
    kafka/         # Consumer/producer
    postgres/      # Repository implementation + migrations
    config/        # App configuration
```

Group by domain/responsibility, not by technical layer. Avoid packages named `util`, `common`, `helpers`, or `models` — every project that allows a `util` package eventually gets a 2,000-line file of unrelated functions.

### Layout rules to encode

- Never recommend `golang-standards/project-layout` as authoritative — it is explicitly rejected by the Go team
- Start simple: `main.go` + `go.mod` is sufficient; add structure only when complexity demands it
- Use `internal/` for all non-exported packages in server applications
- Use `cmd/` only when the repo has multiple binaries
- Avoid `pkg/` — prefer `internal/` or top-level packages
- Package names: short, lowercase, no underscores, singular, no stutter (`payment.Processor` not `payment.PaymentProcessor`)
- Never create `util`, `common`, `helpers`, or `models` packages
- Follow the official guide at `go.dev/doc/modules/layout`

---

## 6. Testing best practices from the Go community

**Table-driven tests with `t.Run()`** are the canonical Go testing pattern. Use descriptive test case names that explain the scenario, `t.Helper()` in all helper functions for accurate line reporting, and `t.Cleanup()` instead of `defer` for teardown. Since Go 1.22, loop variables are safe in closures — no `tt := tt` capture needed. The Uber Go Style Guide recommends `got`/`want` variable naming over `actual`/`expected`.

**testcontainers-go** is the standard for integration testing against real PostgreSQL and Kafka instances. Use module-specific packages (`modules/postgres`, `modules/kafka`) over `GenericContainer`, and separate integration tests with build tags (`//go:build integration`). Run them in CI with `go test -tags=integration -race -count=1 ./...`.

For **mock libraries**, the landscape has consolidated: `go.uber.org/mock` (formerly golang/mock) offers the richest matcher system and is used by Kubernetes. `mockery` generates mocks for the testify ecosystem and has the fastest code generation. The most idiomatic Go approach for simple interfaces is hand-written fakes — no library needed. Use code-generated mocks only when you need rich interaction verification or the interface is large.

**Golden file testing** uses the `testdata/` directory (special — ignored by Go tooling) with an `-update` flag pattern: `flag.Bool("update", false, "update golden files")`. Run `go test -update` to regenerate, then commit changes. This is powerful for testing serialization output, CLI tools, and template rendering.

The **race detector** (`-race`) must run in every CI build — data races are undefined behavior, not mere logic bugs. It adds **2–10× slowdown and 5–10× memory increase** but catches bugs no other tool can find. Use `-count=1` to bust the test cache, which is the idiomatic way documented in official Go docs.

### Testing rules to encode

- Use table-driven tests with `t.Run()` for all functions with more than 2 test cases
- Always run `-race` in CI; use `-count=1` to bust test cache
- Use `t.Helper()` in all test helper functions; use `t.Cleanup()` for teardown
- Separate integration tests with `//go:build integration` build tags
- Use `testcontainers-go` for PostgreSQL and Kafka integration tests
- Store test fixtures in `testdata/` directory
- Test naming: `TestFunction`, `TestStruct_Method`, subtests via `t.Run("scenario", ...)`
- Error messages must include got and want: `t.Errorf("got %q, want %q", got, want)`
- Prefer hand-written fakes for simple interfaces; use go.uber.org/mock or mockery for complex cases
- Use `t.Parallel()` in subtests when tests are independent

---

## 7. Performance profiling workflow

**pprof** is Go's built-in profiling system with six distinct profile types. CPU profiles show where time is spent (sample at ~100 Hz). Heap profiles (`-inuse_space`) show live memory retention — use for leak detection. Allocs profiles (`-alloc_space`) show total allocations since start — use for GC pressure analysis. Goroutine profiles show what all goroutines are doing. Mutex and block profiles require explicit enabling via `runtime.SetMutexProfileFraction(100)` and `runtime.SetBlockProfileRate(100000000)`.

A common misdiagnosis: looking at `alloc_space` for leak detection. High `alloc_space` but low `inuse_space` means high churn (GC pressure), not a leak. For actual leak detection, compare two heap snapshots: `go tool pprof -diff_base heap_before.prof heap_after.prof`.

**The trace tool** (`go tool trace`) reveals what pprof cannot: goroutine scheduling, GC pause timing on specific goroutines, lock contention causing serialization, and poorly parallelized execution. Traces record every scheduler event at microsecond resolution, unlike pprof's statistical sampling.

**benchstat** (rewritten in 2023) computes statistical A/B comparisons. Run benchmarks at least 10 times (`-count=10`) for statistical significance, and never rerun until you get a "significant" result — that's a multiple testing error. For **continuous profiling** in production, Pyroscope (now Grafana) with CPU + memory profiles adds **<1% overhead** at the low budget setting. Go 1.21+ supports Profile-Guided Optimization (PGO): feed production profiles back into the compiler for optimized builds.

### Profiling rules to encode

- Enable pprof on a separate internal port: `go func() { http.ListenAndServe("localhost:6060", nil) }()`
- Use `-inuse_space` for memory leaks, `-alloc_space` for GC pressure sources
- Use `go tool pprof -http=:8080 profile.prof` for flame graph visualization
- Run benchmarks with `-count=10 -benchmem` and compare with `benchstat`
- Use `go tool trace` for latency investigations, scheduler analysis, and GC impact
- Enable mutex/block profiling only for debugging — they add continuous overhead
- Use Pyroscope or Google Cloud Profiler for continuous production profiling
- Feed production profiles back via PGO (Go 1.21+): `go build -pgo=default.pgo`

---

## 8. Module management pitfalls

**GOPRIVATE** is the critical setting for teams with private repositories. Set `GOPRIVATE=github.com/mycompany/*` to prevent leaking private module paths to the public proxy and checksum database. This sets both `GONOPROXY` and `GONOSUMDB` in one variable. Without it, `go mod tidy` will send requests for private module paths to `proxy.golang.org`.

**Major version suffixes** (`/v2`, `/v3`) solve the diamond dependency problem but create a common gotcha: forgetting to update all import paths in source files after changing `go.mod`. The `go mod init` command won't edit `.go` files. For the first major version bump, the simplest approach is updating the module path in-place on the main branch.

**Vendoring** (`go mod vendor`) remains valid for hermetic CI builds and air-gapped environments. Kubernetes vendors all dependencies. However, the Go team generally recommends module proxies over vendoring for most use cases — proxies provide immutability without repository bloat.

**Workspace mode** (`go.work`) is for local multi-module development only. The critical rule: **never commit `go.work` to version control** — add it to `.gitignore`. It replaces the `replace` directive hack in `go.mod` for cross-module development.

**Retraction directives** let you mark published versions as unsuitable without breaking existing builds. Use `retract v1.0.0` in `go.mod` with a comment explaining why. Retracted versions remain downloadable but won't be selected by `go get` or `go mod tidy`.

### Module rules to encode

- Set `GOPRIVATE` for all private module paths to prevent leaking to public proxy/sumdb
- Add `go.work` and `go.work.sum` to `.gitignore` — workspace mode is local only
- When bumping major versions, update ALL import paths in source files, not just `go.mod`
- Use `go mod tidy` after any dependency changes; run `go mod verify` in CI
- Use retraction directives for bad releases instead of deleting tags
- Use vendoring (`go mod vendor`) for hermetic CI builds; otherwise rely on module proxy

---

## 9. Go-specific Dockerfile patterns for Cloud Run and Fly.io

The canonical production Dockerfile for a Go service uses multi-stage builds with **distroless/static as the runtime base image**. Distroless includes CA certificates, timezone data, and a non-root user (UID 65532) out of the box — scratch requires manually copying all of these from the builder stage. Alpine adds a shell and package manager but has ~800 more CVEs than distroless.

```dockerfile
FROM golang:1.22-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 GOOS=linux GOARCH=amd64 \
    go build -trimpath -ldflags="-s -w" -o /app/server .

FROM gcr.io/distroless/static:nonroot
COPY --from=builder /app/server /server
USER nonroot:nonroot
EXPOSE 8080
ENTRYPOINT ["/server"]
```

`CGO_ENABLED=0` produces a fully static binary (required for scratch/distroless). `-ldflags="-s -w"` strips symbol tables and debug info, reducing binary size by **~30%**. `-trimpath` removes filesystem paths for reproducible builds. Layer caching is optimized by copying `go.mod`/`go.sum` and running `go mod download` before copying source code.

**Cloud Run cold starts** for Go are minimal (~<200ms) since image size doesn't affect startup — Cloud Run streams image layers. Cold start is dominated by initialization (database connections, config loading). Use `--cpu-boost` for startup CPU boost and `--min-instances=1` to eliminate scale-from-zero latency. Listen on the `PORT` environment variable immediately and defer expensive initialization.

**Fly.io** supports auto-stop/auto-start machines for cost optimization. Set `min_machines_running = 1` to keep warm. Use process groups in `fly.toml` to run separate web and worker processes from the same image. For graceful shutdown, implement `SIGTERM` handling.

### Dockerfile rules to encode

- Always use multi-stage builds; `gcr.io/distroless/static:nonroot` as default runtime image
- Always set `CGO_ENABLED=0` for static binaries; use `-trimpath -ldflags="-s -w"`
- Copy `go.mod` and `go.sum` before source code for Docker layer caching
- Run as non-root: `USER nonroot:nonroot` (distroless) or create user in builder (scratch)
- Implement `/healthz` (liveness) and `/readyz` (readiness) endpoints
- For Cloud Run: listen on `PORT` env var immediately; use `--cpu-boost` for cold starts
- For Fly.io: use process groups for web/worker separation; implement `SIGTERM` graceful shutdown

---

## 10. Existing AI coding rules files and how to structure them

The most comprehensive Go CLAUDE.md found is **maxdml's gist**, which uses numbered sections (0–16), stable rule IDs (e.g., `BP-1`, `ERR-2`, `CC-3`), and three severity levels: MUST (CI-enforced), SHOULD (strong recommendation), CAN (allowed). This structure enables precise code review references like "violates CC-2." The **everything-claude-code** repository (133K+ stars) provides a layered system where common rules are overridden by Go-specific rules, with separate files for coding style, patterns, security, testing, and hooks.

**JetBrains' go-modern-guidelines plugin** solves a critical problem: AI models generate obsolete Go code due to training data cutoff. It reads the Go version from `go.mod` and instructs agents to use modern features — `slices.Contains()` (Go 1.21+), `errors.AsType[T]` (Go 1.26), and similar patterns.

The **localskills.sh blog** provides the best standalone template, explaining the "why" behind each rule. The **Uber Go Style Guide** remains the most authoritative community style reference, with side-by-side Good/Bad examples. The **Augment Code research** found that LLM-generated AGENTS.md files perform *worse* than no file, while human-curated files yield ~4% improvement — and files beyond **150–200 lines** degrade performance due to context bloat.

### Structure rules for your AI coding agent file

- Keep total rules under 200 lines; split into subdirectory files beyond that
- Place critical rules early — LLMs suffer from "lost-in-the-middle" phenomenon
- Use severity levels (MUST/SHOULD/AVOID) and stable IDs (ERR-1, CC-2) for reference
- Include build/test/lint commands explicitly so the agent can run them
- Always include: error handling, concurrency, interface design, testing, and naming sections
- Reference Go version from `go.mod` to ensure modern idiom usage
- CLAUDE.md can symlink to AGENTS.md to avoid drift across tools
- File locations: `CLAUDE.md` (root) for Claude Code, `.cursorrules` for Cursor, `.github/copilot-instructions.md` for Copilot

---

## Conclusion: the rules that matter most

Three patterns account for the majority of Go production failures in payment services: **goroutine leaks from improper context/channel lifecycle**, **OOM kills from missing GOMEMLIMIT in containers**, and **silent data corruption from undetected race conditions**. Every rule in this report traces back to a real production incident.

The highest-leverage rules for an AI coding agent writing Go services on Cloud Run and Fly.io are these: always set `GOMEMLIMIT` via `automemlimit`; run `-race` in every CI build; never shadow the parent context with errgroup; define interfaces at the consumer; use `internal/` for everything in a server; and build with `CGO_ENABLED=0 -trimpath -ldflags="-s -w"` into `distroless/static:nonroot`. For payments specifically, classify every error as retryable or non-retryable, implement idempotency keys stored in PostgreSQL (not Redis), and handle errors exactly once.

The most effective approach to structuring these rules is the maxdml pattern: categorized sections with stable IDs, severity levels, and explicit build commands — kept under 200 lines with human curation. Use `go-modern-guidelines` to keep the agent aware of your Go version's features. And critically, write the rules yourself — research shows LLM-generated rules files perform worse than having no file at all.