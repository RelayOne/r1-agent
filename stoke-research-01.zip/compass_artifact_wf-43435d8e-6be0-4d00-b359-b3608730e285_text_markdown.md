# The complete Cloudflare Workers ecosystem guide for AI coding agents

**Cloudflare Workers is a V8-isolate-based edge compute platform spanning 330+ cities, with a storage layer (KV, D1, R2, Durable Objects), async primitives (Queues, Workflows), database acceleration (Hyperdrive), and integrated security—all wired together through bindings declared in `wrangler.jsonc`.** AI coding agents consistently generate broken Workers code because they treat the platform like Node.js or AWS Lambda. This guide documents every operational pattern, limit, and gotcha across the full ecosystem so agents can produce correct, production-ready code on the first pass.

---

## 1. The Cloudflare skills repo teaches agents through decision trees

The official repository at `github.com/cloudflare/skills` contains **9 skills, 2 commands, and 4 MCP servers** designed specifically for AI coding agents. It follows the Agent Skills standard and works with Claude Code, Cursor, OpenAI Codex, and similar tools.

**Skills inventory:**

| Skill | Scope | Key patterns |
|-------|-------|-------------|
| `cloudflare` | Master skill with 55+ product references | Decision trees routing to correct product; covers compute, storage, AI, networking, security, media, IaC |
| `agents-sdk` | Building stateful AI agents | `Agent<Env, State>` class, `@callable()` RPC, React hooks (`useAgent()`), streaming chat, Durable Workflows |
| `durable-objects` | Stateful coordination | RPC methods, SQLite storage, alarms, WebSocket hub patterns, Vitest testing |
| `workers-best-practices` | Code review and authoring | Anti-pattern detection (floating promises, global state misuse, secret handling), config validation |
| `wrangler` | CLI and deployment | Commands, bindings config, secrets, type generation, local dev |
| `building-mcp-server-on-cloudflare` | MCP server development | OAuth provider, `createMcpHandler()`, SSE transport, security |
| `building-ai-agent-on-cloudflare` | AI agent lifecycle | State management, WebSocket patterns, tool calling, scheduling |
| `sandbox-sdk` | Isolated code execution | Container lifecycle, `CommandClient`/`FileClient`/`ProcessClient`, Docker conventions |
| `web-perf` | Performance auditing | Core Web Vitals, 5-phase audit, Chrome DevTools MCP integration |

Each skill follows a consistent structure: `SKILL.md` as the entry point with decision trees, then `references/` subdirectories containing `api.md`, `configuration.md`, `patterns.md`, and `gotchas.md`. The teaching philosophy is **retrieval-first**—every skill instructs the agent to fetch current docs rather than relying on pre-trained knowledge, with explicit guidance: "When a reference file and the docs disagree, trust the docs."

The four MCP servers (`cloudflare-docs`, `cloudflare-bindings`, `cloudflare-builds`, `cloudflare-observability`) provide real-time access to documentation, resource management, build insights, and log analytics.

---

## 2. Runtime constraints AI agents consistently violate

The Workers runtime runs on **V8 isolates** (not Node.js, not containers), updated weekly to Chrome stable's V8 version. It follows WinterCG standards and provides Web APIs as the primary interface. Understanding what is and isn't available is the single most important factor for generating correct code.

### CPU time vs wall-clock time

This is the most misunderstood constraint. **CPU time measures only JavaScript execution; I/O wait time is free.**

| Plan | CPU time per request | Cron trigger CPU | Wall-clock limit |
|------|---------------------|-----------------|-----------------|
| Free | **10 ms** | N/A | No hard limit (while client connected) |
| Paid (default) | **30 seconds** | 30s (schedule <1hr), 15min (schedule ≥1hr) | 15 min for cron/alarms/queues |
| Paid (configured) | Up to **5 minutes** (300,000 ms) | Same | Same |

Configure via `"limits": { "cpu_ms": 300000 }` in `wrangler.jsonc`. The average Worker uses **~2.2ms** of CPU per request. Exceeding CPU time returns **Error 1102**. The critical insight: `fetch()`, KV reads, database queries, and all I/O do not count—only actual computation does.

### Bundle size and startup

| Plan | Compressed limit | Uncompressed limit | Startup time limit |
|------|-----------------|--------------------|--------------------|
| Free | **3 MB** | 64 MB | **1 second** |
| Paid | **10 MB** | 64 MB | **1 second** |

Check size with `wrangler deploy --outdir bundled/ --dry-run`. Larger bundles directly impact cold start time.

### Memory and subrequest limits

Each isolate gets **128 MB** of memory (shared across requests hitting the same isolate). Subrequests default to **10,000** on paid plans (configurable up to **10 million**). Free plans get 50 external subrequests.

### Node.js compatibility in 2025-2026

The `nodejs_compat` compatibility flag enables extensive Node.js support. **Fully supported** natively: `crypto`, `buffer`, `path`, `streams`, `url`, `util`, `zlib`, `dns`, `EventEmitter`, `AsyncLocalStorage`, `http`/`https` (client and server since Aug-Sep 2025), `fs` (virtual, ephemeral per-request since Aug 2025), `net`, `tls` (partial). **Non-functional stubs** (import succeeds, methods throw): `child_process`, `cluster`, `dgram`, `worker_threads`, `vm`, `v8`.

Key compatibility date gates: `process.env` auto-population requires **2025-04-01** or `nodejs_compat_populate_process_env`; `node:http` server support requires **2025-09-01**; `node:fs` requires **2025-09-01**. All imports must use the `node:` prefix.

### The nine mistakes AI agents make most often

**Mistake 1: `process.env.API_KEY` instead of `env.API_KEY`.** Historically returned `undefined`. Since April 2025 it works with the right flags, but the canonical pattern remains the `env` parameter from the fetch handler or `import { env } from 'cloudflare:workers'`.

**Mistake 2: `new Response({message: "hello"})`.** Returns `[object Object]`. Must use `Response.json()` or `JSON.stringify()`.

**Mistake 3: Service Worker syntax.** AI generates `addEventListener('fetch')` instead of the required ES Modules `export default { async fetch(request, env, ctx) {} }`.

**Mistake 4: Missing CORS OPTIONS handler.** AI rarely generates proper preflight handling, causing browser failures.

**Mistake 5: Confusing CPU time with wall-clock time.** Long I/O is fine; CPU-bound loops hit the 10ms free limit instantly.

**Mistake 6: Buffering entire bodies.** `await response.text()` on large payloads crashes Workers at 128 MB. Must use streaming.

**Mistake 7: Floating promises.** The runtime may terminate the isolate before un-awaited promises complete. Always `await` or use `ctx.waitUntil()`.

**Mistake 8: Missing DNS record for routes.** Without a proxied AAAA record to `100::`, routes return `ERR_NAME_NOT_RESOLVED`.

**Mistake 9: Mixing `node_compat = true` with `nodejs_compat` flag.** They conflict. Use only the `nodejs_compat` compatibility flag.

---

## 3. Durable Objects implement the actor model with co-located SQLite

Durable Objects provide **globally unique, single-threaded, stateful actors** on Cloudflare's edge. Each DO instance has a unique ID, runs in one location, processes requests sequentially (no concurrent execution), and maintains private persistent storage. This eliminates distributed locking, race conditions, and coordination complexity entirely.

### Addressing and lifecycle

Two ID generation methods: **`idFromName(name)`** is deterministic (same string → same DO globally, recommended for most cases) and **`newUniqueId()`** generates random IDs (must store mapping externally). Creating a stub does not wake the DO—only calling a method activates it. Throughput per DO: **~1,000 req/s** for pass-through, **~500 req/s** for moderate processing, **~200-500 req/s** with storage writes.

### SQLite storage is GA and recommended for all new classes

Since April 2025, Durable Objects with SQLite are generally available with **10 GB per DO**. SQLite-backed DOs offer the `ctx.storage.sql` API for synchronous SQL execution, full-text search (FTS5), JSON functions, and math extensions. Configuration requires a migration tag:

```jsonc
{ "migrations": [{ "tag": "v1", "new_sqlite_classes": ["MyDurableObject"] }] }
```

The `sql.exec()` method returns a `SqlStorageCursor` with `.toArray()`, `.one()`, `.raw()`, `.columnNames`, `.rowsRead`, and `.rowsWritten`. Schema migrations belong in the constructor inside `blockConcurrencyWhile()`. Explicit transactions use `ctx.storage.transactionSync()` for synchronous atomic operations—you cannot issue raw `BEGIN TRANSACTION` SQL.

### Hibernatable WebSockets slash costs by 1000x

The Hibernation API allows DOs to be **evicted from memory while WebSocket connections stay open** on Cloudflare's network. Duration charges do not accrue during hibernation. Core methods: `ctx.acceptWebSocket(ws, tags?)` marks a connection as hibernatable, `ctx.getWebSockets(tag?)` retrieves connected sockets, `ws.serializeAttachment(value)` persists per-connection state across hibernation, and `ctx.setWebSocketAutoResponse(pair)` handles ping/pong without waking the DO.

Event handlers (`webSocketMessage`, `webSocketClose`, `webSocketError`) replace the traditional `ws.addEventListener` pattern. The constructor must restore state from hibernating WebSockets using `deserializeAttachment()`.

### Alarms provide guaranteed-delivery scheduling

Each DO supports **one alarm** at a time with **at-least-once execution** and automatic exponential backoff (up to 6 retries). Set with `ctx.storage.setAlarm(timestamp)`, handle with the `alarm(alarmInfo?)` method. Critical rules: make alarm handlers idempotent, never call `setAlarm()` in the constructor without checking `getAlarm()` first, and remember alarms are not automatically recurring—reschedule in the handler.

### Design patterns that work in production

**Granularity**: one DO per logical coordination unit (per chat room, per user, per game session). A single "global" DO becomes a bottleneck at ~1,000 req/s. **Parent-child**: workspace DOs track child project DO IDs; children handle their own state independently. **Distributed locks**: use a DO with `acquire(clientId, ttl)` and `release(clientId)` methods backed by storage + alarm-based auto-expiration. **State machines**: DOs naturally implement FSMs—persistent state survives hibernation, single-threaded execution prevents concurrent transitions, alarms handle timeouts. **RPC over fetch**: prefer typed `await stub.methodName()` over `await stub.fetch(new Request(...))`.

---

## 4. Storage primitives serve fundamentally different access patterns

| Dimension | Workers KV | D1 | Durable Objects | R2 |
|-----------|-----------|-----|----------------|-----|
| **Model** | Key-value | Relational SQL | Actor + KV/SQL | Object/blob |
| **Consistency** | Eventual (~60s) | Strong (single primary) | **Strong** (serializable) | Strong (per-object) |
| **Read latency** | 500µs–10ms (hot) | Sub-ms (replica) | Sub-ms (co-located) | Varies (CDN cacheable) |
| **Max item size** | 25 MiB | 10 GB per DB | 10 GB per DO | **5 TB** per object |
| **Write rate** | 1/sec per key | ~10–1,000 QPS per DB | 500–1,000 req/s per DO | Unlimited |
| **Storage cost** | $0.50/GB-mo | $0.75/GB-mo | $0.20/GB-mo | **$0.015/GB-mo** |
| **Egress** | Free | Free | Free | **Free** |
| **SQL** | No | Full SQLite | Full SQLite | No |

**Use KV** for read-heavy config, sessions, feature flags, and cached data where **60-second propagation delay** is acceptable. Never for counters, rate limiting, or anything requiring immediate consistency. Write limit: **1 write/second per key**.

**Use D1** for relational data under **10 GB** with SQL queries, JOINs, and indexes. Read replicas (beta) distribute reads globally. Single-threaded per database; throughput depends on query complexity.

**Use Durable Objects** when you need **strong consistency, real-time coordination, or WebSockets**. Compute and storage are co-located on the same machine—zero network latency to data. Ideal for per-user or per-entity isolated state.

**Use R2** for large files, media, ML datasets, and any S3-compatible workload. **Zero egress fees** is the headline feature—$0.015/GB-mo storage vs S3's $0.023/GB-mo plus egress charges. Supports multipart uploads up to 5 TB.

---

## 5. Performance optimization centers on cold starts and streaming

### ES Modules syntax is mandatory for performance

ES Modules (`export default {}`) **reuse execution context across requests**, eliminating per-request context creation overhead that Service Worker syntax incurs. Modules are also required for Durable Objects, D1, Workers AI, Workflows, gradual deployments, and all new features.

### Lazy imports require explicit Wrangler configuration

Dynamic `import()` enables loading code only when needed, but **Wrangler's esbuild bundler inlines dynamic imports by default**, defeating the purpose. Preserve lazy loading boundaries with:

```jsonc
{ "build": { "find_additional_modules": true }, "rules": [{ "type": "ESModule", "globs": ["**/*.mjs"] }] }
```

### Streaming prevents memory exhaustion

Workers have **128 MB memory per isolate**. Buffering large payloads with `await response.text()` will crash. Use `TransformStream` for transformations and pass `response.body` directly for proxying. For OpenAI/LLM streaming, pipe the stream through a `TransformStream` inside `ctx.waitUntil()`.

### Cache API is local per data center

`caches.default` only caches within the handling data center—it is not globally replicated. For global caching, use KV with `expirationTtl`. The `fetch()` API with `cf` options (`cacheTtl`, `cacheEverything`, `cacheTtlByStatus`) supports tiered caching across the CDN. Cache API does not work on `*.workers.dev` domains.

### Cloudflare achieves 99.99% warm requests via consistent hashing

Since September 2025, Cloudflare uses a **"Shard and Conquer" consistent hash ring** within each data center. All requests for a specific Worker route to a single shard server, dramatically reducing cold starts. Combined with TLS handshake pre-warming (loading Workers during the TLS `ClientHello`), simple Workers cold-start in **~5ms**—often finishing before the handshake completes.

**Developer strategies**: minimize global scope work (must complete within 1 second), reduce bundle size, use `wrangler check startup` for CPU profiles, avoid heavy npm packages (use built-in `fetch()` instead of `axios`, `crypto.subtle` instead of `crypto-js`, `URL`/`URLPattern` instead of `path-to-regexp`), and split large Workers via Service Bindings.

---

## 6. Edge-origin architecture demands Smart Placement for database-heavy Workers

### What belongs at the edge vs the origin

**Edge (Workers)**: JWT validation, rate limiting, CORS headers, request routing/transformation, geolocation-based decisions, A/B testing, response caching, HTMLRewriter transformations. These are stateless, sub-millisecond operations that benefit from geographic proximity to users.

**Origin (Cloud Run)**: database CRUD with multiple queries, CPU-intensive processing (image/video), complex multi-step orchestration, large data processing, operations requiring persistent connections. The rule of thumb: if it's stateless, lightweight (<50ms CPU), and benefits from geographic distribution, run it at the edge.

### Smart Placement eliminates the multi-query latency penalty

Without Smart Placement, a Worker in Sydney making 3 round trips to a Frankfurt database adds **300-900ms** of latency that wouldn't exist running near the database. **Smart Placement** (`placement.mode = "smart"`) automatically moves Worker execution closer to backend infrastructure based on observed latency.

For known infrastructure locations, **Placement Hints** (January 2026) are more precise: `placement.region = "gcp:us-east4"` places Workers near your Cloud Run service. Alternatively, `placement.host = "db.example.com:5432"` probes the actual database location.

### The canonical Workers + Cloud Run architecture

The recommended pattern uses **two Workers connected via Service Binding**:

```
User → Auth Worker (edge, no placement) → validates JWT → RPC call →
App Worker (placed near Cloud Run via placement hint) → fetches from Cloud Run
```

The auth Worker runs at the edge for minimum latency on rejections. The app Worker runs near Cloud Run for minimum latency on database calls. Service Bindings between them have **zero cost and bypass the public internet**.

Additional patterns: **edge caching layer** (Cache API stores Cloud Run responses), **async processing** (Queue accepts work, Cloud Run processes via webhook), and **R2 for uploads** (files go directly to R2, avoiding origin bandwidth).

---

## 7. Hyperdrive turns 7 round trips into 1 for database connections

Hyperdrive accelerates Workers-to-database queries through **connection pooling near the database**, **query-level caching**, and **optimized network routing**. Without it, each new database connection requires 7 round trips (TCP + TLS + auth), burning 1+ seconds before executing the first query.

### Performance impact is dramatic

Cached queries see **17-25x improvement**; uncached queries and writes see **6-8x improvement**. A March 2025 update moved connection pools closer to origin databases, reducing uncached latency by **up to 90%**. Combined with Smart Placement, per-query latency drops to **1-3ms** when the Worker runs near the database.

### Configuration is minimal

```jsonc
{
  "hyperdrive": [{
    "binding": "HYPERDRIVE",
    "id": "<CONFIG_ID>",
    "localConnectionString": "postgres://localhost:5432/mydb"
  }]
}
```

Worker code creates a new client per request using `env.HYPERDRIVE.connectionString`—Hyperdrive manages the actual pool. Do not call `client.end()` and never create clients in global scope.

**Supported databases**: PostgreSQL 9.0-17.x (GA), MySQL 5.7-8.x (Beta), plus PG-compatible databases (CockroachDB, Timescale, Neon, Supabase). **Supported ORMs**: Drizzle, Prisma (via `@prisma/adapter-pg`), and any ORM using `pg` or `mysql2` drivers.

### Caching parses the wire protocol

Hyperdrive distinguishes read queries from write queries at the database protocol level. SELECTs with immutable functions are cached across all Cloudflare locations (default **60-second max age**, configurable up to 1 hour). Writes are never cached but still benefit from connection pooling. Queries using `NOW()`, `RANDOM()`, or other volatile functions are not cached—even if those function names appear only in SQL comments.

**Pricing**: included free with Workers plans. Free tier: 100,000 queries/day. Paid tier: unlimited. No egress charges, no per-query fees from Hyperdrive itself.

---

## 8. Queues handle throughput while Workflows handle orchestration

### Queues: at-least-once message passing at 5,000 msg/sec

Queues follow a producer/consumer model with **at-least-once delivery** and **no ordering guarantee**. Each queue supports one consumer (push-based Worker or pull-based HTTP client). Messages are JSON-serializable with a **128 KB** size limit.

**Dead letter queues** receive messages that exhaust `max_retries` (configurable up to **100**, default 3). DLQs are regular queues that can be consumed independently. **Message-level control**: `msg.ack()` prevents redelivery, `msg.retry({ delaySeconds: 3600 })` schedules retry with delay (up to 12 hours). Batch processing supports up to **100 messages** per batch with configurable timeout (up to 60 seconds).

**Pricing**: $0.40/million operations on paid plans (1M included). Each message typically costs 3 operations (write + read + delete). Per-queue throughput: **5,000 messages/second**. Backlog limit: **25 GB per queue**.

### Workflows: durable multi-step execution that survives failures

Workflows (GA since April 2025) provide **step-based durable execution**. Each step's result is persisted; if a step fails, the Workflow resumes from the last successful step without re-executing completed work. Steps can sleep for days or weeks, wait for external events (`step.waitForEvent`), and configure per-step retry policies with exponential backoff.

**Step types**: `step.do(name, callback)` for computation, `step.sleep(name, duration)` for delays, `step.sleepUntil(name, timestamp)` for scheduled wake, `step.waitForEvent(name, options)` for external signals with configurable timeout.

Built on Durable Objects internally, each Workflow instance gets its own SQLite-backed DO. Sleeping instances don't count toward the **10,000 concurrent running instance** limit—millions can sleep simultaneously.

### When to use which

**Queues**: fire-and-forget async work, high-throughput buffering, fan-out to multiple pipelines, rate-limited API consumption, independent message processing. **Workflows**: multi-step orchestration with dependencies, long-running processes, human-in-the-loop approvals, AI agent pipelines, order processing sagas. **Both together**: Queue ingests at high throughput, consumer creates Workflow instances for reliable per-item processing.

---

## 9. Security spans WAF rules through Tunnel origin protection

### Rate limiting at the edge with zero-latency bindings

The `ratelimit` binding (GA since September 2025) provides **in-Worker rate limiting** with near-zero latency—counters are cached on the same machine with no network hop. Configure in `wrangler.jsonc`:

```jsonc
{ "ratelimits": [{ "name": "MY_RATE_LIMITER", "namespace_id": "1001", "simple": { "limit": 100, "period": 60 } }] }
```

Call `await env.MY_RATE_LIMITER.limit({ key: userId })` and check `{ success }`. Limits are **per Cloudflare location** (not global) and eventually consistent—suitable for abuse prevention, not exact accounting. Best practice: key on user IDs or API keys, not IP addresses.

### SSL/TLS: Full (Strict) is the only acceptable production mode

**Flexible** encrypts browser-to-Cloudflare but sends plaintext to origin—vulnerable to eavesdropping. **Full** uses HTTPS to origin but accepts self-signed certificates—vulnerable to MITM. **Full (Strict)** validates the origin certificate against trusted CAs or Cloudflare Origin CA certificates—this is the only mode that provides true end-to-end encryption. Cloudflare Origin CA certificates are free with 15-year validity.

### Cloudflare Tunnel eliminates origin exposure

`cloudflared` creates **outbound-only connections** from your origin to Cloudflare's network. No inbound ports need to be opened, no public IP is required, and all traffic flows through Cloudflare's security stack (WAF, Bot Management, DDoS) before reaching your origin. For Cloud Run backends, this means locking down all inbound access except through the tunnel.

### Security execution order matters for rule design

Features execute in this order: IP Access Rules → Bot Fight Mode → **WAF Custom Rules** → Rate Limiting Rules → WAF Managed Rules → **Workers**. Understanding this prevents conflicts—for example, a WAF Skip rule can bypass Bot Fight Mode for specific paths (like webhook endpoints), and Workers-based rate limiting runs after WAF rules.

### Workers security patterns

**JWT validation at the edge**: use the `jose` library with `createRemoteJWKSet` for automatic JWKS caching. Validate signature, expiration, issuer, and audience. Always use asymmetric algorithms (RS256/ES256) so Workers verify without possessing signing keys. **CORS**: explicitly whitelist origins, handle OPTIONS preflight, never use `*` with credentials. **Secrets**: always use `wrangler secret put` (never `vars` in config), declare required secrets with `"secrets": { "required": ["API_KEY"] }` for deployment validation, and use `.dev.vars` for local development.

---

## 10. Wrangler patterns for development, deployment, and CI/CD

### wrangler.jsonc is now recommended over wrangler.toml

Since Wrangler v3.91.0, **JSON configuration is officially preferred** and some newer features will only be available in JSON format. Include `"$schema": "./node_modules/wrangler/config-schema.json"` for IDE autocomplete. If both formats exist, JSON takes precedence.

### Environment management creates separate Workers

Environments in `wrangler.jsonc` deploy as `<name>-<env>` (e.g., `my-worker-staging`). **Bindings are non-inheritable**—KV namespaces, D1 databases, R2 buckets, and all other bindings must be explicitly defined per environment. Inheritable fields include `name`, `compatibility_date`, `route`, and `placement`.

```bash
npx wrangler dev --env staging        # Local dev with staging config
npx wrangler deploy --env production  # Deploy to production
```

### Local development runs the real runtime

`wrangler dev` uses **Miniflare v3 powered by `workerd`**—the same open-source runtime used in production. This provides near-production-accurate behavior locally. Press **D** to open Chrome DevTools for step-through debugging. Data persists in `.wrangler/state/` between runs. For hybrid development, set `"remote": true` on individual bindings to connect to real deployed resources while executing locally.

### Gradual deployments prevent catastrophic rollouts

```bash
npx wrangler versions upload --tag "v1.2.3"
npx wrangler versions deploy new-version@10 old-version@90   # 10% canary
npx wrangler versions deploy new-version@100                  # Full rollout
npx wrangler rollback <VERSION_ID>                            # Instant rollback
```

Version overrides allow testing before routing traffic: `curl -H 'Cloudflare-Workers-Version-Overrides: my-worker="<VERSION_ID>"' https://example.com`. Up to **100 recent versions** are available for rollback.

### CI/CD with GitHub Actions

```yaml
- uses: cloudflare/wrangler-action@v3
  with:
    apiToken: ${{ secrets.CLOUDFLARE_API_TOKEN }}
    accountId: ${{ secrets.CLOUDFLARE_ACCOUNT_ID }}
    preCommands: |
      echo "${{ secrets.MY_SECRET }}" | npx wrangler secret put MY_SECRET
    command: deploy --env production
```

Cloudflare also offers native Git integration (Workers Builds) that auto-deploys on push—non-production branches run `wrangler versions upload` with preview URLs, production branches run `wrangler deploy`.

## Conclusion

The Cloudflare Workers ecosystem in 2025-2026 has matured into a comprehensive edge platform, but its V8-isolate architecture creates sharp constraints that AI coding agents must internalize. The most impactful corrections: **always use ES Modules syntax with the `env` parameter** (not `process.env`), **understand that CPU time ≠ wall-clock time** (10ms free, 30s paid), **stream everything over 1MB** to avoid the 128MB memory ceiling, and **pick storage primitives by consistency model**—KV for eventual reads, D1 for relational SQL, Durable Objects for strong consistency and coordination, R2 for blobs.

For the user's specific architecture (Workers + Durable Objects + R2 + Cloud Run), the optimal pattern is a **two-Worker Service Binding design**: an edge auth Worker validates JWTs and handles rate limiting at the user's nearest data center, then calls via RPC to a Smart-Placed app Worker running near Cloud Run. Durable Objects handle real-time coordination (WebSockets with hibernation for cost efficiency), R2 stores files with zero egress, and Hyperdrive accelerates any PostgreSQL queries from Workers with connection pooling and caching. Queues decouple async work; Workflows orchestrate multi-step processes. All wired together through bindings in `wrangler.jsonc`, deployed via gradual rollouts, and protected by Cloudflare Tunnel eliminating origin exposure.