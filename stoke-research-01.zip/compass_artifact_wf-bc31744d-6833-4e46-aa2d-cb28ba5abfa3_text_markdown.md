# AI coding agent skills for multi-cloud infrastructure

**The SKILL.md format has emerged as the universal standard for encoding infrastructure knowledge into AI coding agents**, with every major cloud provider now maintaining official skills repositories. Cloudflare, AWS, Azure, and HashiCorp all publish first-party agent skills, while GCP remains a notable gap with only Vertex AI coverage. For the user's primary stack — Cloud Run, Fly.io, Cloudflare Workers, and Firecracker microVMs — Cloudflare has the richest agent skills ecosystem, while Fly.io and Firecracker have zero dedicated agent rule definitions, representing the biggest opportunities for custom skill authoring.

Across all 10 research areas, the ecosystem splits cleanly into two tiers: cloud providers with official SKILL.md repos (Cloudflare, AWS, Azure, HashiCorp) and operational domains where best practices exist only in scattered documentation or policy-as-code tools (Kubernetes, serverless, cost optimization, security). This report maps every actionable resource found.

---

## 1. Official cloud provider skills repositories

**Cloudflare leads the pack** with `cloudflare/skills`, the most mature infrastructure skills repo. It covers Workers, Pages, D1, R2, KV, Durable Objects, Queues, Agents SDK, and 40+ other services using the SKILL.md format with `references/` subdirectories containing per-product `api.md`, `configuration.md`, `patterns.md`, and `gotchas.md` files. Cloudflare also published the `agent-skills-discovery-rfc` proposing a `.well-known/agent-skills` URI standard. Installation is straightforward: `npx skills add https://github.com/cloudflare/skills --skill <skill-name>`. A community counterpart by `dmmulroy/cloudflare-skill` provides additional decision trees.

**AWS** has two key resources. The community-maintained `zxkane/aws-skills` (~197 stars) provides 5 Claude Code plugins — `aws-cdk`, `aws-cost-ops`, `serverless-eda`, `aws-agentic-ai`, and `aws-common` — each with SKILL.md files, reference documents, and **7 integrated MCP servers** for live AWS operations. In March 2026, AWS officially released the `awslabs/agent-plugins` serverless plugin covering Lambda, API Gateway, EventBridge, and Step Functions, installable via `/plugin install aws-serverless@claude-plugins-official`.

**HashiCorp's `hashicorp/agent-skills`** (60 stars, MPL-2.0) is the official Terraform skills repo with three plugin bundles: `terraform-code-generation` (style guide, testing, Azure Verified Modules, search/import), `terraform-module-generation` (refactoring, Terraform Stacks), and `terraform-provider-development` (scaffolding, acceptance tests). The community counterpart `antonbabenko/terraform-skill` (~898 stars) is more popular, offering a decision-framework approach with 6 reference files covering testing, modules, CI/CD, and security patterns, built on enterprise experience from terraform-best-practices.com.

**Microsoft/Azure maintains three repos**: `microsoft/azure-skills` (423 stars) with 20 curated skills plus Azure MCP and Foundry MCP server integration; `MicrosoftDocs/Agent-Skills` auto-generated weekly from Microsoft Learn docs covering 100+ Azure services; and `microsoft/skills` with 132 skills and 1,158 test scenarios. The Azure Verified Modules Spec Kit additionally provides AI-assisted specification-driven workflows using Bicep.

**GCP is the notable gap.** Only `GoogleCloudPlatform/vertex-ai-samples/skills/` exists with 5 SKILL.md files focused exclusively on Vertex AI/ML tasks. No equivalent to the other providers exists for Cloud Run, GKE, Cloud SQL, Pub/Sub, or VPC. The community `hminooei/gcp-owasp-top10-skills` covers security auditing via Gemini CLI extensions but not infrastructure operations.

| Provider | Repo | Official | Stars | MCP integration |
|----------|------|----------|-------|-----------------|
| Cloudflare | `cloudflare/skills` | Yes | — | No |
| AWS | `zxkane/aws-skills` | Community | ~197 | Yes (7 servers) |
| AWS | `awslabs/agent-plugins` | Yes | — | Yes |
| Terraform | `hashicorp/agent-skills` | Yes | 60 | No |
| Terraform | `antonbabenko/terraform-skill` | Community | ~898 | No |
| Azure | `microsoft/azure-skills` | Yes | 423 | Yes |
| Azure | `MicrosoftDocs/Agent-Skills` | Yes | 6 | No |
| GCP | `vertex-ai-samples/skills/` | Partial | — | No |

Key aggregator repos: `VoltAgent/awesome-agent-skills` indexes 1,000+ skills; `rohitg00/awesome-claude-code-toolkit` provides 135 agents and 35 skills including `agents/infrastructure/devops-engineer.md`; and `sickn33/antigravity-awesome-skills` offers 1,372+ installable skills with `npx antigravity-awesome-skills`.

---

## 2. Docker and container best practices as agent rules

The most comprehensive Docker agent rules file is **`sanjeed5/awesome-cursor-rules-mdc`'s `docker.mdc`** (~3,400 stars for the parent repo). This 247-line file auto-attaches to `**/Dockerfile` and `**/docker-compose*.{yml,yaml}` and encodes 10 rules with concrete BAD/GOOD code examples: multi-stage builds, minimal base images (Alpine variants over `ubuntu:latest`), `.dockerignore` templates, **layer caching optimization** (copy lockfiles before source, `npm ci` pattern), non-root execution (`USER node` with `chown`), ARG vs ENV distinction, HEALTHCHECK with proper intervals, stdout/stderr logging, Docker Compose for local dev, and secrets management via Docker Compose secrets feature.

For distroless and BuildKit patterns, the best encodable reference is `caduh.com/blog/dockerfile-best-practices`, which documents: `gcr.io/distroless/static:nonroot` with `USER nonroot:nonroot`, BuildKit `--mount=type=cache` for Go builds, `--mount=type=secret` for build-time secrets, base image pinning with digests (`FROM node:22-slim@sha256:...`), and exec-form ENTRYPOINT/CMD. Additional Docker rules exist in `ivangrynenko/cursorrules` (56 `.mdc` files including `docker-compose-standards.mdc`, `secret-detection.mdc`) and `chand1012/cursorrules` (`languages/docker.mdc`).

**Container security scanning is the biggest gap.** No dedicated `.cursorrules`, `.mdc`, or SKILL.md files encode Trivy/Snyk/Grype workflows as AI agent instructions. The closest references are `rohitg00/awesome-claude-code-toolkit`'s Kubernetes specialist agent, which mentions "Scan container images in CI with Trivy. Block deployment of images with critical CVEs using admission webhooks," and `rallyhealth/conftest-policy-packs`, which provides OPA/Rego policies for Docker (sensitive keys in ENV/ARG, image registry restrictions). This is a clear opportunity for custom skill authoring.

---

## 3. Kubernetes operational skills encoded for AI agents

**The `jeffallan/claude-skills` Kubernetes Specialist** is the most complete K8s agent skill found, with SKILL.md plus 11 reference sub-documents covering workloads, networking, configuration, storage, Helm, troubleshooting, custom operators, service mesh (Istio/Linkerd), GitOps (ArgoCD/Flux), cost optimization, and multi-cluster. Its MUST/MUST NOT constraints are directly actionable: resource requests AND limits on ALL containers, liveness AND readiness probes mandatory, least-privilege RBAC, NetworkPolicies for segmentation, never run production without resource limits, never use `latest` tag, never use default ServiceAccount for app pods. It includes complete YAML templates for Deployments (with `securityContext: runAsNonRoot`, `readOnlyRootFilesystem`, `drop ALL capabilities`), RBAC patterns, and default-deny NetworkPolicies.

**`qdhenry/Claude-Command-Suite`** (~1,100 stars) provides a structured 10-step `setup-kubernetes-deployment.md` slash command covering architecture planning through operations, with specific sections on HPA (custom Prometheus metrics via prometheus-adapter), VPA for resource optimization, Cluster Autoscaler, and PodDisruptionBudgets.

**`alimobrem/pulse-agent`** is the most operationally advanced — a Claude-based SRE agent with Helm chart deployment that includes **11 automated scanners** (crashlooping pods, pending pods, failed deployments, node pressure, cert expiry, firing alerts, OOM-killed, image pull errors, degraded operators, DaemonSet gaps, HPA saturation), RBAC analysis (overly permissive roles, wildcard permissions), pod security analysis, and right-sizing via Prometheus data comparison. Trust levels control auto-remediation: Level 3 auto-fixes safe categories; Level 4 auto-fixes all with rollback snapshots.

**`openclaw/skills`** takes a multi-agent swarm approach with specialized K8s agents: Jarvis (orchestrator), Atlas (cluster ops), Flow (GitOps), Shield (security), Pulse (observability), and Cache (artifacts).

Remaining gaps: no concrete Argo Rollouts or Flagger YAML patterns for canary/blue-green deployments exist as agent rules, and Pod Security Standards enforcement (`restricted`/`baseline`/`privileged`) is only mentioned in `rohitg00/awesome-claude-code-toolkit`, not fully encoded.

---

## 4. Serverless platform gotchas as agent rules

**Cloud Run's container contract** requires the ingress container to listen on `0.0.0.0` on the `PORT` environment variable (default 8080) — never `127.0.0.1`. Maximum concurrent requests per instance: configurable up to **1,000** (default 80 per vCPU). Maximum request timeout: **3,600 seconds**. On SIGTERM, containers get **10 seconds** before SIGKILL. Disk storage is in-memory — files written to disk consume memory and cause OOM if not cleaned. Request-based billing means CPU is only allocated during request processing unless "always allocated CPU" is enabled, which makes background threads unreliable. Cold start mitigation: use startup CPU boost, configure minimum instances, use lean base images.

**Lambda** has a **900-second** maximum timeout and per-region account-level concurrency (typically 1,000). **SnapStart** (Python 3.12+, Java 11/17) snapshots initialization state at deployment time, providing a free alternative to Provisioned Concurrency. VPC-attached Lambdas need dedicated subnets with adequate IP capacity and add cold start latency. Memory allocation directly controls CPU — doubling memory doubles available CPU.

**No Cloud Run-specific `.cursorrules` or SKILL.md files exist.** The `awslabs/serverless-rules` provides prescriptive cfn-lint/tflint rules based on Well-Architected pillars. The `awslabs/agent-plugins` serverless plugin (March 2026) covers Lambda, API Gateway, EventBridge, and Step Functions for Claude Code and Cursor. For a cross-platform comparison rule, the key encoding would be: Lambda 900s vs Cloud Run 3,600s timeout; Lambda per-function concurrency vs Cloud Run per-instance concurrency; Lambda SnapStart vs Cloud Run minimum instances for cold start mitigation.

---

## 5. Firecracker microVM patterns have no agent rules yet

Firecracker provides sub-125ms startup with **<5 MiB memory overhead** per microVM, supporting up to 32 vCPUs and 150 microVM creations per second per host. The minimal device model includes only virtio-net, virtio-block, virtio-vsock, serial console, and a minimal keyboard. Configuration happens via REST API on a Unix socket before the InstanceStart command.

**Snapshot/restore is the killer feature for AI agent sandboxes.** The ForgeVM project (`DohaerisAI/forgevm`, March 2026) achieves **28ms restore times** — 5ms process startup, 8ms mmap memory, 10ms restore CPU/devices, 5ms vsock reconnection. Copy-on-write base snapshots let 50 VMs share memory pages. Critical gotchas: deploy snapshots on **cgroups v2** hosts (v1 causes high latency); guest network connectivity is NOT guaranteed after resume; vsock device resets across snapshot/restore (listen sockets survive, connections close); disk contents are not explicitly flushed during snapshot; never take snapshots during early boot.

**rootfs preparation** requires ext4 filesystem images with filesystem support compiled into the kernel (not as modules, since no initramfs). Kernel must be uncompressed ELF (`vmlinux`) on x86_64. Boot args: `console=ttyS0 reboot=k panic=1 root=/dev/vda`. Networking uses TAP devices exclusively — no built-in CNI. **virtio-vsock provides host-guest communication** without TCP/IP stack overhead, eliminating network-based attack surface. Production deployment requires the **jailer binary** for cgroups/namespace isolation and privilege dropping.

**No `.cursorrules`, `.mdc`, or SKILL.md files exist for Firecracker.** This is one of the largest gaps in the ecosystem and a high-value opportunity for custom skill creation given the complexity of Firecracker configuration.

---

## 6. Fly.io operational patterns lack dedicated agent rules

**fly.toml configuration essentials**: `primary_region` sets where new Machines are created AND sets the `PRIMARY_REGION` env var. Default `kill_signal` is SIGINT (override to SIGTERM for graceful shutdown). `kill_timeout` defaults to 5 seconds (max 300s). Shutdown sequence: kill_signal → wait kill_timeout → unconditional SIGTERM. Autoscale via `auto_stop_machines = "stop"` (or `"suspend"` for faster restart), `auto_start_machines = true`, `min_machines_running = 0`. Fly Proxy starts additional Machines when all running ones exceed `soft_limit`.

**Volume management has critical constraints**: volumes are **1:1 with Machines** (one volume per Machine, one Machine per volume), hardware-pinned to NVMe on a single physical server (NOT network storage), cannot be shrunk, and are not available during build or `release_command`. Always run at least 2 volumes per app for redundancy. IOPS scale with Machine type: shared-cpu-1x gets 4,000 IOPS/16 MiB/s; performance-8x/16x gets 32,000 IOPS/128 MiB/s. Root filesystem is ephemeral (max 2,000 IOPS) and rebuilds on restart.

**Private networking (6PN) gotcha: IP addresses are NOT static** — they can change across Machine lifetime. Always use `.internal` DNS: `<app-name>.internal` resolves to 6PN addresses, `iad.<app-name>.internal` for region-specific resolution. Custom 6PNs isolate per-customer networks (`fly apps create <name> --network <network>`), but apps cannot move between 6PNs. For private services, bind to `fly-local-6pn:<port>`; for Fly Proxy services, bind to `0.0.0.0:<port>`.

**Fly Postgres critical gotcha**: mismatching Postgres parameters and VM RAM causes `FATAL: could not map anonymous shared memory: Cannot allocate memory`. Size `shared_buffers` relative to available VM memory. Fly now offers Managed Postgres; unmanaged Postgres is unsupported.

**No dedicated Fly.io `.cursorrules` or SKILL.md exists.** The `fly-autoscaler` (`superfly/fly-autoscaler`) provides Prometheus-based metric scaling with 15-second reconciliation loops, but it's a tool, not an agent skill definition.

---

## 7. Self-hosted infrastructure and OS hardening skills

**Ansible best practices are well-encoded.** The Cursor Directory provides `.cursorrules` for Ansible covering idempotent design, `group_vars`/`host_vars`, roles for modularity, `ansible-lint` validation, handlers for service restarts, Vault for secrets, dynamic inventories, tags for flexible execution, Jinja2 templates, `block:`/`rescue:` error handling, and `ansible-pull` for client-side deployment. The `sanjeed5/awesome-cursor-rules-mdc` repo provides a 293-line `ansible.mdc` file.

**CIS benchmark automation is mature.** The `ansible-lockdown` project provides the gold standard: `UBUNTU22-CIS` and `DEBIAN12-CIS` Ansible roles with goss-based auditing that checks both config files AND running state. Each control is tagged by level, OS element, patch/audit, rule number, and NIST references. `MVladislav/ansible-cis-ubuntu-2204` extends this with Mozilla OpenSSH guidelines and Molecule test integration, offering granular control variables like `cis_ubuntu2204_rule_1_1_1_9: true`.

**Monitoring stack**: `samber/awesome-prometheus-alerts` (~7,800 stars) is the definitive alerting rules collection with production-ready YAML rules for Prometheus self-monitoring, host/hardware, Docker containers, Kubernetes, databases (MySQL, PostgreSQL, Redis, MongoDB, Elasticsearch), message queues (RabbitMQ, Kafka), and web servers (Nginx, Apache, HAProxy). For log aggregation, Vector (Datadog) uses a DAG model (sources → transforms → sinks) with VRL for parsing/enriching, disk buffers with at-least-once delivery, and unit tests in `vector.yaml`. Key Loki rule: **use low-cardinality labels** (avoid user IDs as labels).

**Gap**: No SKILL.md files exist specifically for self-hosted infrastructure stacks (Prometheus+Grafana+Alertmanager, Loki, Vector). These would need to be authored from the documented best practices.

---

## 8. Multi-cloud cost optimization encoded as rules

**Cloud Custodian** (`cloud-custodian/cloud-custodian`, ~5,940 stars, CNCF Incubating) is the primary rules engine with a YAML-based policy DSL supporting AWS, Azure, and GCP. Policies define resource types, filters, actions, and modes — ideal for AI agents to generate programmatically. Use cases: garbage collection of unused resources, off-hours management, auto-tag enforcement, encryption requirements.

**Infracost** (12,200 stars) provides shift-left FinOps with cost estimation for **1,100+ Terraform resources**, FinOps best practices checking (e.g., "switch gp2→gp3", "use Graviton"), tagging policy enforcement in PRs, and OPA/Rego policy integration for custom cost rules. It has an `agent-skills` repo suggesting dedicated AI agent integration. The AutoFix feature auto-generates PRs with cost optimization code fixes.

Key egress cost data for encoding into agent rules:

- **AWS**: $0.09/GB first 10TB, 100GB free/month; NAT Gateway adds $0.045/GB
- **GCP**: $0.12/GB internet egress, $0.01/GB same-continent; Cloud NAT ~$0.045/GB
- **Azure**: $0.087/GB first 10TB, 100GB free/month
- **Cloudflare R2**: **Free egress** — the clear winner for egress-heavy workloads
- **DigitalOcean**: Much lower (~$0.01/GB or free under quota)

**Decision framework for reserved vs on-demand**: baseline loads (>60% utilization for 30+ days) → reserved/committed use discounts; variable loads → on-demand; interrupt-tolerant batch work → spot/preemptible. AWS offers up to 72% savings on Reserved Instances, GCP offers automatic Sustained Use Discounts plus 1-3 year Committed Use Discounts.

The `tonynguyennvt/cursor-rules-awesome` provides a 4,800-line `.cursorrules` file covering FinOps, auto-scaling strategies, storage lifecycle policies, and 9 compliance frameworks, claiming "20-40% typical cost savings."

---

## 9. IaC drift detection and compliance enforcement

**driftctl** (`snyk/driftctl`) detected managed drift and unmanaged resources with an "IaC coverage" metric, but is now in **maintenance mode**. Recommended alternatives: `terraform plan -refresh-only` for state updates, HCP Terraform built-in drift detection, or Spacelift.

**Spacelift** provides the `spacelift_drift_detection` Terraform resource with cron scheduling and `reconcile = true` for auto-triggered runs. The `spacelift-io/spacelift-policies-example-library` contains OPA/Rego policies (login, plan, push, trigger) with `_test.rego` test files. Plan policies support `deny` (auto-fail) and `warn` (human review) rules, plus tfsec JSON integration via `input.third_party_metadata.custom.tfsec`.

**HashiCorp Sentinel** has two key repos: `hashicorp/terraform-sentinel-policies` (third-generation policies using Sentinel v2 imports for AWS, Azure, GCP, VMware) and `hashicorp/terraform-foundational-policies-library` (CIS Benchmark policies organized by compliance standard, designed for direct VCS integration in Terraform Cloud). Enforcement levels: advisory, soft-mandatory, hard-mandatory.

**OPA/Rego for IaC** is rich with examples: `aws-samples/aws-infra-policy-as-code-with-terraform` (official AWS pattern: `policy/aws/<service>/` with `.rego`, `.mock.json`, `.test.rego`); `Scalr/sample-tf-opa-policies` (9+ policies for IAM, CIDR, KMS, S3); `rallyhealth/conftest-policy-packs` (enterprise compliance-as-code with Conftest, results reported to PRs in 4-10 seconds); `fugue/regula` (Rego library mapped to CIS/NIST controls for Terraform, CloudFormation, K8s).

**Plan-time vs apply-time enforcement**: Terraform `precondition` blocks for plan-time validation, `postcondition` blocks for apply-time verification, Sentinel/OPA policies at organization/workspace level, and **run tasks** for third-party tool integration between plan and apply stages.

**State file management rules**: use remote backends (S3+DynamoDB, Azure Blob, GCS, Terraform Cloud) with state locking and encryption; separate state files per environment via workspaces or backend config; version state history; use `terraform state mv`/`rm` for refactoring.

---

## 10. Cloud security baselines and secrets management

**Prowler** (~13,468 stars) is the most comprehensive open cloud security platform, covering AWS, Azure, GCP, Kubernetes, GitHub, Microsoft 365, Oracle Cloud, Alibaba Cloud, and **Cloudflare**. It maps to CIS, NIST 800, NIST CSF, PCI-DSS, GDPR, HIPAA, SOC 2, and 15+ other frameworks. **Prowler Studio** provides MCP server integration for AI coding assistants (Cursor, VS Code), enabling AI agents to generate security checks. SOC 2 evidence collection automation is built in.

**Checkov** (Bridgecrew/Palo Alto) provides 1,000+ built-in checks for Terraform, CloudFormation, Kubernetes, Helm, Dockerfile, and Bicep with systematic check IDs (e.g., `CKV_AWS_20`). Custom policies in YAML or Python make it highly AI-friendly. Inline suppression via `#checkov:skip=CKV_AWS_20:reason`.

**Secrets management patterns**: SOPS (`getsops/sops`) encrypts YAML/JSON/ENV/INI with AWS KMS, GCP KMS, Azure Key Vault, age, PGP, or Vault Transit. The `.sops.yaml` file defines `creation_rules` for path-based encryption policies with key groups supporting Shamir secret sharing. Best practice: **age keys for development, cloud KMS for production**. Sealed Secrets for Kubernetes uses asymmetric encryption with an in-cluster controller. Pre-commit hooks should verify encryption before any push.

**IAM least-privilege tools**: Policy Sentry (Salesforce) generates least-privilege IAM policies; `iamlive` generates policies from client-side monitoring; `aws-allowlister` auto-compiles SCPs from compliance frameworks. AWS SCPs use a deny-list approach at org/OU level — block CloudTrail deletion, restrict expensive instance types, enforce tagging, prevent IAM user creation. GCP Organization Policies provide constraint-based enforcement at org/folder/project level.

For Cursor-specific security, `matank001/cursor-security-rules` provides purpose-built `.mdc` files in `.cursor/rules/` for safe coding practices, sensitive operations control, and risk reduction, created by security researchers.

---

## Conclusion: where the gaps create opportunity

The AI agent skills ecosystem for infrastructure is maturing rapidly around the SKILL.md standard, but coverage is uneven. **Cloudflare, AWS, Azure, and HashiCorp have strong first-party skills**, while **GCP infrastructure, Fly.io, and Firecracker have zero dedicated agent skill definitions** — the three platforms most central to the user's stack beyond Cloudflare.

The highest-impact custom skills to author would be: a **Cloud Run SKILL.md** encoding the container contract (PORT, SIGTERM, concurrency, billing model), a **Fly.io SKILL.md** encoding volume 1:1 constraints, 6PN non-static IPs, autoscale configuration, and Postgres sizing, and a **Firecracker SKILL.md** encoding snapshot/restore lifecycle, rootfs preparation, jailer requirements, and vsock patterns. Each of these could reference the operational knowledge documented above.

For compliance and cost, the tools exist but are not yet packaged as agent skills. The combination of **Infracost for cost guardrails**, **Prowler Studio for security scanning via MCP**, **Checkov for IaC scanning**, and **Cloud Custodian for runtime policy enforcement** covers the operational needs, but a unified SKILL.md that routes agents to the right tool for each context — analogous to Cloudflare's decision-tree approach — would be the most valuable contribution to this ecosystem.