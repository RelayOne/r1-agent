# SQLite WAL correctness under 20 concurrent writers

**Your qa-audit system's configuration — WAL mode, BEGIN IMMEDIATE, busy_timeout=5000 — provides full ACID correctness guarantees with zero risk of silent data loss**, provided you handle exceptions properly and call `commit()` after every write transaction. SQLite serializes all writes through an exclusive WAL write lock; concurrent writers queue up and take turns. The real risks are not in SQLite's engine but in application-level error handling, a recently-patched WAL corruption bug, and WAL checkpoint starvation under sustained write load. This report covers all eight questions in depth.

---

## SQLite guarantees serializable isolation — even with 20 writers

SQLite's WAL mode documentation is unambiguous: **"there can only be one writer at a time."** An exclusive `WAL_WRITE_LOCK` is held by any connection appending to the WAL file. All transactions are **SERIALIZABLE** — the highest isolation level — achieved by literally serializing writes. Readers get snapshot isolation and are never blocked by writers.

The combination of WAL + `BEGIN IMMEDIATE` is particularly strong. The official docs state: **"If the BEGIN IMMEDIATE operation succeeds, then no subsequent operations in that transaction will ever fail with an SQLITE_BUSY error."** This means once your transaction starts, it is guaranteed to complete without contention. The lock is acquired upfront, eliminating mid-transaction failures entirely.

For your workload of **20-100 total writes/second** (20 writers × 1-5 writes/sec), each write transaction must serialize. If each transaction completes in 5-10ms, SQLite can sustain 100-200 transactions/second — adequate for your throughput. The bottleneck is throughput, never correctness. SQLite will queue writers at the lock and busy-wait up to your 5-second timeout.

**Critical upgrade notice**: A WAL-Reset corruption bug was present in **every SQLite version from 3.7.0 (2010) through 3.51.2 (January 2026)**, fixed in **SQLite 3.52.0 released March 6, 2026** — just two days ago. The bug involves a data race during WAL checkpoint where a committed transaction can be silently skipped when it is being copied to the main database file. The SQLite team states the probability is comparable to "SSD malfunctions and cosmic-ray hits," but with 20 concurrent writers triggering frequent checkpoints, your exposure is elevated. Backport fixes exist for 3.44.6, 3.50.7, and 3.51.3. **Upgrade immediately.**

---

## SQLITE_BUSY never causes silent write loss in Python

This is the most important correctness question, and the answer is definitive: **Python's sqlite3 module always raises `sqlite3.OperationalError` on SQLITE_BUSY. There is no code path where a write fails silently.**

The CPython source code in `cursor.c` checks every return code from `sqlite3_step()`:

```c
rc = stmt_step(self->statement->st);
if (rc != SQLITE_DONE && rc != SQLITE_ROW) {
    set_error_from_db(state, self->connection->db);
    goto error;
}
```

Only `SQLITE_DONE` and `SQLITE_ROW` pass through. Every other return code — including `SQLITE_BUSY` — triggers `set_error_from_db()`, which maps `SQLITE_BUSY` to `sqlite3.OperationalError` via the `get_exception_class()` function in `util.c`. This applies uniformly to `cursor.execute()`, `cursor.executemany()`, and `cursor.executescript()`. **No version of CPython has ever silently swallowed SQLITE_BUSY.**

When `busy_timeout=5000` expires, the behavior chain is: SQLite's internal busy handler retries with a backoff schedule (1, 2, 5, 10, 15, 20, 25, 25, 25, 50, 50, 100ms intervals) → after 5 seconds of accumulated sleep, the handler returns 0 → `sqlite3_step()` returns `SQLITE_BUSY` → Python raises `sqlite3.OperationalError("database is locked")`. A standard `try/except sqlite3.OperationalError` block reliably catches this.

**The three real risks for silent data loss** are application-level, not engine-level:

- **Missing `commit()`**: The most common cause. Python's sqlite3 does not auto-commit on `close()` — an uncommitted INSERT silently rolls back with no exception. Always use `with conn:` context manager or explicit `commit()`.
- **`INSERT OR IGNORE`**: Returns `SQLITE_OK` with `changes()=0` when a constraint is violated — by design, not a bug, but a frequent source of developer confusion.
- **Swallowing exceptions**: If your `try/except` catches `OperationalError` and continues without re-raising or logging, you've silently dropped the write at the application layer.

---

## BEGIN IMMEDIATE eliminates write-write conflicts within transactions

`BEGIN IMMEDIATE` acquires a RESERVED lock instantly (identical to EXCLUSIVE in WAL mode). Only one connection can hold this lock at a time. A second `BEGIN IMMEDIATE` will get `SQLITE_BUSY` immediately or retry until `busy_timeout` expires. **Two BEGIN IMMEDIATE transactions cannot both succeed simultaneously** — this is the fundamental serialization guarantee.

Within a single `BEGIN IMMEDIATE` transaction, there is **no TOCTOU race**: once you hold the lock, no other writer can modify the database. Your reads and writes are fully isolated. However, a subtle gap exists *between* transactions: another connection could commit changes between your previous transaction's COMMIT and your next `BEGIN IMMEDIATE`. If your application logic depends on cross-transaction read-then-write consistency, you need the read and write in the same `BEGIN IMMEDIATE` transaction.

One critical edge case: if you use plain `BEGIN` (DEFERRED) instead of `BEGIN IMMEDIATE`, a read-to-write lock upgrade can fail with `SQLITE_BUSY` **immediately, bypassing busy_timeout entirely**. SQLite's documentation explains: "If SQLite determines that invoking the busy handler could result in a deadlock, it will return SQLITE_BUSY without invoking the busy handler." This still raises an exception (not silent), but your timeout provides no protection. **Your use of `BEGIN IMMEDIATE` correctly avoids this.**

---

## WAL checkpoint starvation is your primary operational risk

Default auto-checkpointing triggers when the WAL reaches **1000 pages (~4MB with the default 4096-byte page size)**. The checkpoint runs as a PASSIVE operation inline with the committing thread. With 20 concurrent writers, checkpoint starvation is a real concern because a PASSIVE checkpoint cannot complete if any other connection has an active transaction.

The SQLite documentation warns: **"If a database has many concurrent overlapping readers and there is always at least one active reader, then no checkpoints will be able to complete and hence the WAL file will grow without bound."** With 20 writers constantly cycling through `BEGIN IMMEDIATE` → write → `COMMIT`, there may rarely be a moment when no transaction is active, preventing the WAL from being reset.

There is no hard size limit on the WAL file — it grows until disk space is exhausted. **Read performance degrades proportionally** to WAL size because each reader must scan the WAL for relevant pages. The wal-index (`.shm` file) helps but cannot fully compensate. Firefox Bug 660036 documented the WAL growing to **300MB+** during batched Sync operations due to exactly this pattern.

Recommended mitigations for your workload:

- Keep the default `wal_autocheckpoint=1000` but supplement with a **dedicated background thread** running `PRAGMA wal_checkpoint(TRUNCATE)` periodically (every 30-60 seconds) during quiet moments
- Monitor WAL file size and alert if it exceeds 50MB
- Keep all write transactions as short as possible — a single INSERT per transaction is ideal
- Ensure heartbeat readers (every 10s) don't hold long-running read transactions open
- Consider `PRAGMA journal_size_limit` to cap residual WAL size after successful checkpoints

---

## synchronous=NORMAL is sufficient when power loss isn't the threat

The **only difference** between `synchronous=FULL` and `synchronous=NORMAL` in WAL mode is a single `fsync()` call on the WAL file after each transaction commit. FULL adds this fsync; NORMAL skips it. The SQLite documentation is explicit: **"Transactions are consistent with or without the extra syncs provided by synchronous=FULL."**

Both settings provide identical Atomicity, Consistency, and Isolation guarantees. Only Durability differs: with NORMAL, a committed transaction could roll back following a **power failure or OS kernel crash** because the WAL data may be in the OS page cache but not yet fsynced to disk. However, **"transactions are durable across application crashes regardless of the synchronous setting"** — if your process crashes, the OS will still flush the page cache to disk.

Since you stated you're worried about correctness under concurrent access, not power loss, `synchronous=NORMAL` provides identical guarantees. The performance benefit is significant — eliminating one fsync per commit typically **doubles write throughput**. One caveat: on macOS, even `synchronous=FULL` doesn't guarantee true durability because macOS `fsync()` doesn't flush the disk's hardware write cache. You'd need `PRAGMA fullfsync=ON` for that, which invokes `F_FULLFSYNC`.

---

## Post-write SELECT verification is unnecessary paranoia

The SQLite community consensus is clear: **if an INSERT returns without raising an exception and the transaction commits successfully, the data is written.** There is no scenario in correctly-functioning SQLite where a successful write silently fails. The `changes()` function reliably reports affected rows, and `last_insert_rowid()` reliably returns the new rowid.

The proper verification pattern is not reading back data, but rigorously checking error codes and using `changes()` to confirm expected row counts. One exception worth noting: with `synchronous=NORMAL`, a successful commit means data is in the WAL but not necessarily fsynced to disk — a power failure could roll it back. This is a durability concern, not a correctness concern, and a post-write SELECT wouldn't help because it reads from the same unfsynced WAL.

---

## How production systems handle SQLite concurrency

Major production users converge on remarkably similar patterns:

**Firefox** uses WAL mode with `PRAGMA synchronous=NORMAL` and **exclusive locking mode** to prevent external access. All database operations run off the main thread through an async connection API. Mozilla's pattern is one write connection pinned to a distinguished thread, with separate read connections. They've encountered WAL growth to 300MB+ during heavy Sync operations and struggled with checkpoint starvation.

**Datasette** (Simon Willison) implements an **in-Python-memory write queue** that serializes all write operations. Rather than letting SQLite manage contention, Datasette routes all writes through a single queue, eliminating `SQLITE_BUSY` entirely. Read operations use a thread pool and can run concurrently.

**Tailscale** migrated their control plane from etcd to SQLite with Litestream backup. They discovered a deadlock bug with `ATTACH`ed databases using `BEGIN DEFERRED` and switched to **`BEGIN IMMEDIATE` for all write transactions** — exactly your pattern. They also shard data across separate database files to reduce per-file write contention.

**Expensify/Bedrock** processes $10 billion in transactions on SQLite using a custom `BEGIN CONCURRENT` branch that enables **optimistic page-level locking** — multiple transactions proceed in parallel, checking for conflicts only at commit time. This experimental branch achieves roughly 4× write throughput but requires a custom SQLite build.

**SkyPilot** discovered that SQLite's busy handler has **no fairness guarantee** — the retry backoff schedule (1, 2, 5, 10, 15, 20, 25... ms) means a new process can steal the lock while an older process sleeps. At 1000 concurrent writers, they increased `busy_timeout` to **60 seconds**. For your 20-writer workload, 5 seconds is likely adequate, but consider increasing to 10-30 seconds for safety margin.

---

## Migration paths depend on what "scale" means

If your system needs to scale to distributed multi-machine access, the options range from zero-effort to full rewrite:

**Litestream** (near-zero migration) provides disaster recovery and read replicas by capturing WAL changes and replicating to S3. All writes still go through a single primary node — it doesn't solve multi-machine writes. But it costs virtually nothing to add, and gives you durable backups with sub-second replication lag. This is the right first step regardless of future plans.

**libSQL/Turso** (low-medium migration) is the most promising SQLite-compatible path. libSQL is an SQLite fork that adds experimental MVCC-based concurrent writes claiming **4× write throughput** improvement. Turso Cloud provides managed multi-region distribution with embedded replicas. However, concurrent writes are explicitly described as "not yet recommended for production workloads" and all writes still route through a single primary. SQL is fully compatible with SQLite.

**rqlite** (medium migration) provides Raft-based distributed SQLite for high availability. Write performance is actually **worse** than standalone SQLite due to Raft consensus overhead. All writes funnel through a single leader. It solves fault tolerance, not write scaling. Requires switching to an HTTP API.

**PostgreSQL** (high migration) is the industry-standard answer. Full MVCC supports hundreds of concurrent writers natively. Streaming and logical replication enable true multi-machine scaling. The migration cost is real — different type system, different SQL dialect, client-server architecture — but the tooling is mature and the path is well-documented. For a system that genuinely needs multi-machine concurrent writes, this is the proven solution.

**DuckDB is not suitable** — it's an OLAP engine optimized for analytics, not transactional workloads. Cross-process concurrent writes are explicitly unsupported and "unlikely to be supported in the future."

---

## Conclusion

Your qa-audit configuration is **correct and safe for the described workload**. SQLite's WAL mode with `BEGIN IMMEDIATE` provides serializable isolation with no silent data loss paths. The three actionable items are:

1. **Upgrade to SQLite 3.52.0** immediately to patch the WAL-Reset corruption bug that has existed since 2010 — your 20-writer workload elevates exposure to this race condition
2. **Implement WAL checkpoint monitoring** — run periodic `PRAGMA wal_checkpoint(TRUNCATE)` from a background thread and alert if WAL exceeds 50MB, because 20 concurrent writers create significant checkpoint starvation risk
3. **Audit your exception handling and commit patterns** — the only realistic path to silent data loss is application code that catches and ignores `OperationalError` or fails to call `commit()` after writes

For future scaling, adding Litestream now costs nothing and provides disaster recovery. If you later need multi-machine writes, PostgreSQL remains the battle-tested path, while libSQL/Turso offers a potentially lower-friction SQLite-compatible alternative once its concurrent write feature matures beyond experimental status.