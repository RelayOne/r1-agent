# Designing a universal event bus for an AI coding orchestrator

**Stoke's event bus can surpass existing hook systems by combining the structured JSON protocol of Claude Code hooks, the gate/transform separation of Kubernetes admission webhooks, the subject-based routing of NATS, and per-subscriber circuit breakers — all unified under a single dispatch architecture.** The key architectural insight from studying 10 systems is that no existing platform solves composition, failure isolation, and transport abstraction simultaneously. Git hooks lack composition. Claude Code hooks lack cross-hook state. Kubernetes webhooks lack transport flexibility. By treating each of these as a solved subproblem and integrating their best patterns, Stoke can deliver the first event bus that handles 73 event types across 6 transports with proper gate/transform/observe semantics and production-grade failure handling.

---

## Git hooks solve nothing but set the baseline everyone improved upon

Native git hooks represent the simplest possible hook architecture: a single executable per event, identified by filename in `.git/hooks/`, communicating through exit codes (0 = allow, non-zero = block) and unstructured stdin/stdout text. Each hook receives event-specific arguments — `pre-push` gets the remote name and URL as arguments plus `<local ref> <local SHA> <remote ref> <remote SHA>` lines on stdin, while `pre-commit` receives nothing at all. Post-hooks like `post-merge` cannot affect outcomes; their exit codes are ignored.

The limitations define the problem space Stoke must solve. **There is no composition** — running ESLint, Prettier, and a type-checker on `pre-commit` requires manually scripting all three into one shell file. There is no parallel execution, no structured input/output, no timeout handling, no error recovery, and hooks are not version-controlled by default (`.git/hooks/` is local). The `--no-verify` flag bypasses hooks entirely with no audit trail.

Three tools evolved to address these gaps, each fixing different problems. **Husky** (v9) solved version control by using Git's `core.hooksPath` to point at a committed `.husky/` directory containing plain shell scripts — zero runtime dependencies, ~2 kB overhead. **lint-staged** solved file targeting by identifying staged files via `git diff --staged --name-only`, matching them against glob patterns, and passing only relevant files to each tool. It handles partial staging by stashing unstaged changes, running tools on staged-only content, then restoring. **Lefthook** solved composition directly: a single `lefthook.yml` file supports multiple named commands per hook event, `parallel: true` execution, glob-based filtering with `{staged_files}` placeholders, conditional execution via `skip`/`only`, and `stage_fixed: true` to auto-stage formatter changes. The **pre-commit framework** solved ecosystem fragmentation with language-agnostic hook repositories pulled from Git, pinned to immutable revisions, with automatic environment isolation and caching.

For Stoke, the critical takeaway is that **composition is the primary unsolved problem** in hook systems. Every improvement tool exists because native hooks lack fan-out. Stoke's event bus must treat multiple subscribers per event as a first-class primitive, not an afterthought.

## Claude Code hooks introduce structured JSON protocols and LLM-native patterns

Claude Code's hook system represents the most sophisticated developer tool hook architecture available today, supporting **27+ hook events** across the full session lifecycle. Events span from `SessionStart` and `UserPromptSubmit` through `PreToolUse`/`PostToolUse` (the workhorses) to `Stop`, `SubagentStop`, `TaskCreated`, `TaskCompleted`, `ConfigChange`, `FileChanged`, `PreCompact`/`PostCompact`, and `SessionEnd`. Each event has defined blocking semantics — `PreToolUse` can deny, allow, ask, or defer operations, while `PostToolUse` can only provide feedback.

The JSON input/output protocol is where Claude Code hooks diverge sharply from git hooks. Hook scripts receive structured JSON on stdin containing `session_id`, `transcript_path`, `cwd`, `hook_event_name`, and event-specific fields. For `PreToolUse`, this includes `tool_name`, `tool_input` (with tool-specific schemas like `command` for Bash or `file_path`/`content` for Write), and `tool_use_id`. The output protocol uses **exit codes as a routing mechanism**: exit 0 means parse stdout as JSON for decisions, exit 2 means blocking error (stderr fed back as error message), and any other exit code means non-blocking error. The JSON output supports `decision`, `reason`, `hookSpecificOutput` with `permissionDecision` (allow/deny/ask/defer), `updatedInput` for transparent input modification, and `additionalContext` for injecting information into Claude's context.

Four handler types address different extensibility needs: **command hooks** (shell scripts with JSON over stdin/stdout), **HTTP hooks** (POST JSON to URLs), **prompt hooks** (single-turn LLM evaluation for semantic checks), and **agent hooks** (subagents with tool access for deep verification). Configuration lives in `.claude/settings.json` with regex-based matchers filtering which tools trigger which hooks and `if` fields using permission rule syntax like `"Bash(git *)"`.

Several Claude Code limitations directly inform Stoke's design. **Infinite loop risk** exists because `Stop` hooks with exit 2 cause Claude to continue — hooks must check `stop_hook_active` to break cycles. The **10,000 character output cap** truncates hook output. **No cross-hook state** exists between independent invocations. HTTP hooks **cannot block via status code** — they must return 2xx with a JSON body containing a blocking decision. The `SessionEnd` timeout defaults to just **1.5 seconds**. When multiple `PreToolUse` hooks disagree, precedence follows `deny > defer > ask > allow`, which is a sensible but rigid conflict resolution strategy.

For Stoke, the key patterns to adopt are the structured JSON protocol, the `updatedInput` transform capability (invisible to the AI agent), the matcher/filter system, and the async hook option. The key patterns to improve upon are conflict resolution (make it configurable), cross-hook state (provide a shared context object), and the output size cap (use streaming for large payloads).

## VS Code and GitHub Actions demonstrate scalable observer patterns

VS Code's extension API solves the "hundreds of extensions observing the same event" problem through three architectural decisions. First, the `Event<T>` / `EventEmitter<T>` pattern separates event production (private `_onDidOpenDocument` emitter with `fire()`) from consumption (public `onDidOpenDocument` event). Only the owning component can fire events — consumers can only subscribe. Second, **event payloads are read-only**: `TextDocumentChangeEvent` contains the document and changes array, but extensions cannot mutate these objects to affect other listeners. Each extension gets its own scoped `vscode` API object created by `createApiFactoryAndRegisterActors`. Third, the **Disposable pattern** prevents memory leaks — every subscription returns a `Disposable` pushed to `context.subscriptions` for automatic cleanup on deactivation. VS Code's internal `LeakageMonitor` detects when too many listeners accumulate on a single emitter.

The extension host process architecture provides **failure isolation**: extensions run in a separate Node.js process communicating with the renderer via bidirectional RPC. A misbehaving extension cannot freeze the UI. The distinction between **events** (one-to-many notifications, all listeners called) and **providers** (registrations where extensions supply functionality, with `CancellationToken` for abandoning stale requests) maps directly to Stoke's observe/gate distinction.

GitHub Actions demonstrates event-driven architecture at repository scale. **35+ event types** each carry structured payloads via the `github.event` context object. Multiple workflows respond independently to the same event — each `.yml` file in `.github/workflows/` is evaluated independently, creating separate workflow runs. **Activity types** provide sub-event filtering (e.g., `pull_request` has `opened`, `synchronize`, `closed`, etc., with only `opened`, `synchronize`, and `reopened` triggering by default). Path and branch filters (`paths: ['src/**']`, `branches: [main]`) reduce unnecessary runs. Conditional execution via `if` expressions enables complex logic: `if: github.ref == 'refs/heads/main' && github.event_name == 'push'`.

Two GitHub Actions patterns are particularly relevant to Stoke. **`repository_dispatch`** enables external event injection via API with custom `client_payload` (max 10 top-level properties, 65,535 chars) — analogous to Stoke's webhook transport for external tools. **Concurrency groups** (`concurrency: { group: deploy-${{ github.ref }}, cancel-in-progress: true }`) prevent simultaneous execution of conflicting workflows — Stoke needs similar per-event-type concurrency control for gate hooks.

## Kubernetes webhooks define the canonical gate/transform pipeline

Kubernetes admission webhooks implement the cleanest separation between gate and transform hooks in any production system. The pipeline flows: **MutatingAdmissionWebhook → ValidatingAdmissionWebhook → etcd persistence**. This ordering guarantee — all mutations complete before any validations run — ensures validators see the final mutated state.

**ValidatingWebhookConfiguration** implements the gate pattern: receive the object, return `allowed: true` or `allowed: false` with an optional status message. Multiple validating webhooks **run in parallel** and all must allow for the request to proceed. **MutatingWebhookConfiguration** implements the transform pattern: receive the object, return `allowed: true` with a base64-encoded JSONPatch array of RFC 6902 operations. Mutating webhooks **run sequentially** in lexical order of configuration names. Each subsequent webhook sees modifications made by preceding webhooks.

The `AdmissionReview` request contains `uid`, `kind`, `resource`, `operation` (CREATE/UPDATE/DELETE/CONNECT), `userInfo`, `object`, `oldObject`, and `dryRun` — a comprehensive context envelope. The response minimum is just `uid` + `allowed`. For mutations, the response includes `patchType: "JSONPatch"` and the `patch` array.

Three Kubernetes patterns directly apply to Stoke's design:

- **`failurePolicy`**: `Fail` (reject on webhook error — fail-closed) vs `Ignore` (allow on webhook error — fail-open). This is exactly the per-subscriber failure policy Stoke needs for gate hooks.
- **`reinvocationPolicy: IfNeeded`**: Re-invoke a mutating webhook after other webhooks modify the object. Stoke needs this for transform hook chains where one transform's output affects another transform's logic.
- **`timeoutSeconds`** (1-30s range, default 10s): Explicit per-webhook timeout with behavior governed by `failurePolicy` on expiry. Stoke should adopt configurable per-subscriber timeouts with the same fail-open/fail-closed semantics.

Real-world implementations prove these patterns at scale: OPA Gatekeeper (validating gate with Rego policies, typically `failurePolicy: Ignore` with 3s timeout), Kyverno (both mutating and validating via CRD-defined policies), and Istio sidecar injection (mutating webhook that adds the Envoy proxy container via JSONPatch).

## Terraform's gRPC plugin protocol proves process-isolated extensibility

Terraform's provider architecture demonstrates how to maintain a stable API boundary between a core system and hundreds of community-maintained plugins. The foundation is HashiCorp's **go-plugin** library: the host process starts the plugin as a subprocess, the plugin prints connection info to stdout (port, protocol version), and both sides negotiate a gRPC channel over localhost. A **MagicCookie** (`TF_PLUGIN_MAGIC_COOKIE` → specific hash) validates the handshake. Process isolation means plugin crashes cannot corrupt the host.

The protocol buffer interface (`tfplugin5.proto` / `tfplugin6.proto`) defines a structured CRUD lifecycle: `GetProviderSchema` → `ValidateResourceConfig` → `PlanResourceChange` → `ApplyResourceChange` → `ReadResource`. State flows through well-defined representations: Configuration (may contain unknowns) → Proposed New State (core's merge) → Planned State (provider's prediction, may contain unknowns) → New State (actual post-apply, must be wholly known). **`DynamicValue`** wraps state in msgpack or JSON encoding. Every response includes `Diagnostic` messages with severity, summary, detail, and attribute path for precise error reporting.

Two Terraform patterns are essential for Stoke's gRPC transport. First, **partial state on error**: if `ApplyResourceChange` fails midway, the provider returns whatever state was successfully written alongside error diagnostics. This prevents "leaked" resources. Stoke's transform hooks should similarly return partial results on failure rather than losing all progress. Second, **plugin multiplexing** via `terraform-plugin-mux` enables combining multiple provider implementations into a single process, routing RPCs by resource type. Stoke could use this pattern to let a single gRPC subscriber handle multiple event types through internal routing.

The protocol versioning strategy is particularly elegant: major version is encoded in the protobuf package name, allowing a plugin server to export multiple gRPC services simultaneously. Minor versions use feature detection, not wire changes. This enables Stoke to evolve its hook protocol without breaking existing subscribers.

## NATS provides the ideal substrate for inter-process event routing

NATS's subject-based routing maps naturally to a hook event bus. Hierarchical dot-separated subjects like `hook.pre.tool_use` or `hook.post.file_write` enable wildcard subscriptions: `hook.*.tool_use` (single-token wildcard) or `hook.>` (multi-token, catches all hook events). For Stoke's 73 event types, a subject hierarchy like `stoke.{mode}.{event_type}` (e.g., `stoke.gate.pre_tool_use`, `stoke.observe.file_changed`) enables subscribers to listen to specific events, all events of a mode, or everything.

The **request-reply pattern** is critical for gate hooks. `nc.Request("stoke.gate.pre_tool_use", payload, 5*time.Second)` sends a message and blocks for a response, with NATS automatically creating a unique `_INBOX` reply subject. This gives synchronous RPC semantics over async pub/sub — exactly what gate hooks need. Queue groups (`nc.QueueSubscribe("stoke.gate.>", "gate_workers", handler)`) distribute messages across multiple subscribers for load balancing, ensuring only one subscriber per group receives each message.

**JetStream** adds the persistence layer needed for audit trails. A stream configured with `Subjects: []string{"stoke.>"}` captures all events with configurable retention (time-based, size-based, or interest-based). Each message gets a sequence number and timestamp. Consumers can replay from any point using `DeliverPolicy` — all messages, from a sequence number, or from a timestamp. The **exactly-once semantics** via `Nats-Msg-Id` header deduplication prevents duplicate audit entries. JetStream's built-in **KV store** (backed by streams) provides configuration storage with watch capability for real-time config updates.

Performance data confirms NATS is suitable for low-latency hook dispatch: **~0.2μs average latency** for small messages in core pub/sub, **4.9 million messages/second** throughput for 1-pub-1-sub with 16-byte payloads, and ~8.6MB memory footprint. JetStream adds persistence latency but async publish with batching approaches core throughput.

However, NATS introduces an operational dependency (a separate server process). For Stoke's in-process and Unix socket transports, a lighter approach may be preferable, using NATS only for the audit trail and cross-process pub/sub while keeping in-process dispatch as a direct function call.

## Unix domain sockets outperform TCP by 3x for local IPC

For Stoke's Unix socket transport, **UDS offers ~30-40% lower latency than TCP loopback** for small messages (~2.3μs vs ~3.6μs for 128-byte ping-pong) and eliminates TCP/IP stack overhead entirely. For small, frequent messages typical of hook invocations, UDS achieves **>2x the packet rate** of TCP. Go benchmarks show 100,000 ping-pongs completing in 454ms over UDS vs 1,474ms over TCP — a **3.2x speedup**. gRPC over UDS is ~20% faster than gRPC over TCP (~100μs/op vs ~125μs/op).

Three JSON-over-socket protocol options exist, each with different tradeoffs. **Newline-delimited JSON** (NDJSON) is simplest: `json.NewEncoder(conn).Encode(event)` writes JSON followed by a newline, and `json.NewDecoder(conn).Decode(&event)` reads it. The caveat is `bufio.Scanner`'s default 64KB max token — use `scanner.Buffer(buf, maxSize)` for larger payloads. **Length-prefixed messages** (4-byte uint32 length prefix + payload) handle binary and large payloads better, using `binary.Write`/`binary.Read` + `io.ReadFull`. **HTTP-over-Unix-socket** (the Docker pattern) uses standard `http.Server` on a Unix listener with a custom `Transport.DialContext` on the client — providing REST semantics with UDS performance.

Security is a key UDS advantage. **Filesystem permissions** on the socket file restrict access to specific users/groups. **SO_PEERCRED** (Linux) provides kernel-verified peer credentials — the PID, UID, and GID of the connecting process — via `unix.GetsockoptUcred`. These credentials cannot be spoofed, providing authentication beyond what TCP can offer without TLS client certificates.

For Stoke, the recommended UDS protocol is **length-prefixed JSON** for gate/transform hooks (where message boundaries must be precise) and **NDJSON** for observe hooks (where streaming simplicity matters). The goroutine-per-connection pattern with `sync.Map` for client tracking enables efficient multiplexing of multiple subscribers. Socket file cleanup on startup (`os.RemoveAll(socketPath)` before `net.Listen`) and signal-handler-based cleanup on shutdown prevent stale socket files.

## Event sourcing creates a queryable record of every hook decision

For Stoke's audit trail, event sourcing provides a complete, immutable record of every hook invocation. The event schema should capture: `hook_id`, `hook_type` (gate/transform/observe), `event_type` (one of 73), `subscriber_id`, `subscriber_transport` (one of 6), `decision` (allow/deny/transform/skip/error), `latency`, `input_hash` (for privacy-preserving correlation), `output_data`, `error_message`, `circuit_state` (closed/open/half-open), and `correlation_id` for distributed tracing.

The **append-only event store** should use optimistic concurrency control with version-based conflict detection. Indexing on `(aggregate_id, version)` enables loading events per aggregate, while a `global_version` counter enables building projections across all aggregates. Time-based indexes support temporal queries like "what was the circuit breaker state for subscriber X at 3:42 PM yesterday?"

**CQRS** separates the write path (append events) from the read path (materialized views). Projections can build real-time dashboards showing failure rates, latency percentiles, decision distributions, and circuit state history. **Consistent projections** (same transaction as event storage) provide immediate availability but slower writes. **Eventually consistent projections** (async via event bus) provide higher throughput but introduce lag.

For Go implementations, **hallgren/eventsourcing** is the most mature library, supporting bbolt, SQLite, PostgreSQL, and EventStoreDB backends with snapshot support. **bbolt** (etcd's embedded B+ tree store) provides ~10K-50K writes/second with ACID transactions — sufficient for hook audit at Stoke's scale. **BadgerDB** (LSM-tree) offers higher write throughput and built-in TTL for retention policies. Snapshotting every 100-1000 events prevents replay overhead from growing unbounded.

The replay capability is where event sourcing pays off: to debug why a hook denied a specific operation, load all events for that invocation's correlation ID, replay them in sequence, and see the exact inputs, subscriber responses, and final decision. For compliance, the complete event log proves every AI action was subject to configured policy hooks.

## Circuit breakers prevent slow subscribers from blocking the pipeline

Without circuit breakers, a dead webhook subscriber causes every gate hook invocation to wait for the full timeout (e.g., 5 seconds) before failing. With **73 event types** and potentially dozens of subscribers, this cascading delay would make Stoke unusable. Circuit breakers detect systemic failure patterns and **fail fast** (~0μs instead of 5,000ms) once tripped.

**sony/gobreaker v2** is the recommended Go library for Stoke. It provides generics support (type-safe `CircuitBreaker[[]byte]`), rolling window metrics via `BucketPeriod`, custom trip logic via `ReadyToTrip(counts Counts) bool`, error exclusion via `IsExcluded` (e.g., ignore `context.Canceled`), and state change callbacks via `OnStateChange`. Configuration per subscriber should include: failure ratio threshold (**0.5** = trip at 50% failure rate), minimum request count (**10** before ratio is meaningful), evaluation window (**60 seconds**), open duration (**30 seconds**), and half-open test requests (**3**).

The critical design decision is **fallback policy per hook mode**:

- **Gate hooks** need a configurable **fail-open vs fail-closed** policy. Security-critical gates (blocking dangerous commands) should fail-closed — when the circuit opens, deny the operation. Advisory gates (style checks) should fail-open — when the circuit opens, allow the operation through.
- **Transform hooks** should **pass through unmodified** when the circuit opens. The pipeline continues with the original data as if the transform didn't exist.
- **Observe hooks** should **skip silently** when the circuit opens, logging the skip in the event store for audit but not propagating errors to the pipeline.

The **bulkhead pattern** complements circuit breakers by isolating resource consumption per subscriber. Each subscriber gets its own goroutine semaphore (buffered channel of configurable size) and a separate `http.Client` with its own connection pool. When a subscriber's bulkhead is at capacity, new invocations are immediately rejected rather than queueing, preventing one slow subscriber from consuming all available goroutines. The layering order should be: **Bulkhead → Circuit Breaker → Timeout → Retry → Fallback**.

**Timeouts and circuit breakers are complementary**, not alternatives. Timeouts protect individual calls (a single webhook invocation that takes too long). Circuit breakers protect against systemic failures (a subscriber that has been failing for the last minute). Every hook invocation should pass through both: `context.WithTimeout` wraps the actual network call inside the circuit breaker's `Execute` function.

## Synthesizing a unified architecture for Stoke's event bus

The event dispatch pipeline should process hooks in a defined order inspired by Kubernetes: **transform subscribers run sequentially** (each sees the previous transform's output, with `reinvocationPolicy` support for transforms that depend on other transforms' mutations), then **gate subscribers run in parallel** (all must allow, with configurable `failurePolicy` per subscriber), then **observe subscribers fire asynchronously** (non-blocking, best-effort). This transform → gate → observe ordering ensures gates validate the final transformed state and observers see the committed outcome.

The subscriber transport abstraction should implement a common interface across all 6 transports:

```
type Subscriber interface {
    Invoke(ctx context.Context, event *Event) (*Response, error)
    Transport() TransportType
    HealthCheck() error
}
```

**In-process** subscribers are direct function calls (~nanoseconds). **Unix socket** subscribers use length-prefixed JSON over UDS (~2-5μs). **gRPC** subscribers use protobuf over UDS or TCP (~100μs). **HTTP webhook** subscribers use POST with JSON body (~1-10ms). **Script** subscribers spawn a subprocess with JSON on stdin, reading JSON from stdout (exit code semantics matching Claude Code's protocol). **MCP** subscribers communicate via the Model Context Protocol for AI-tool interop.

Each subscriber wraps its transport in a **resilience stack**: per-subscriber `gobreaker.CircuitBreaker`, per-subscriber bulkhead semaphore, per-subscriber `http.Client` (for HTTP/gRPC), and configurable timeout. The circuit breaker's `OnStateChange` callback emits events to the event store, creating an audit trail of reliability state alongside hook decisions.

For the **event protocol**, adopt Claude Code's JSON structure as a baseline — `event_type`, `correlation_id`, `timestamp`, `payload` (event-specific structured data) — but add `mode` (gate/transform/observe), `sequence` (for ordering), and `reply_to` (for synchronous gate responses). Gate responses include `decision` (allow/deny) and `reason`. Transform responses include `updated_payload` (the modified event data) and `patch` (JSONPatch operations, Kubernetes-style). Observe hooks return nothing meaningful to the pipeline.

Subject-based routing via NATS-style hierarchical subjects (`stoke.gate.pre_tool_use`, `stoke.transform.file_write`, `stoke.observe.*`) enables flexible subscription patterns. Subscribers can register for specific events, all events of a mode, or everything. The event store captures the full stream for replay and audit. NATS JetStream provides the persistence layer, with the KV store holding subscriber configurations and circuit breaker state.

## Conclusion

Stoke's event bus architecture emerges from a clear pattern across all 10 systems studied: **the best hook systems separate mechanism from policy**. Kubernetes separates webhook transport from admission logic. Terraform separates gRPC transport from provider CRUD semantics. Claude Code separates handler types (command/HTTP/prompt/agent) from hook events. The winning design for Stoke abstracts transport (6 options) from dispatch semantics (gate/transform/observe) from event taxonomy (73 types) from resilience (circuit breakers/bulkheads/timeouts), making each dimension independently configurable.

The three most underappreciated patterns from this research are: **reinvocation** (Kubernetes's ability to re-call mutating webhooks after other mutations — essential when transform hooks interact), **fail-open vs fail-closed as a per-subscriber policy** (not a global setting — security gates fail-closed while advisory gates fail-open), and **event sourcing for the hook system itself** (not just the application — recording every circuit breaker state transition, every gate decision, every transform diff creates a complete audit trail that enables temporal debugging and compliance verification). No existing system combines all three. Stoke should.