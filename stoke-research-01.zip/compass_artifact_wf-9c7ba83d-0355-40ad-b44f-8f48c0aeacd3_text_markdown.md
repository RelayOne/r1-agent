# Advanced git patterns for AI agent orchestration

**Git worktrees, file locking, merge queues, and monorepo optimization form the backbone of any system running parallel AI coding agents against a shared repository.** This guide provides the complete implementation playbook for building an orchestrator like Stoke/Forge — covering every layer from worktree lifecycle management to commit-graph acceleration. Each pattern has been validated against production systems including Claude Code's native worktree support, Composio's agent orchestrator, and Microsoft's Scalar toolchain. The 10 sections below progress from agent isolation primitives through conflict prevention, CI integration, and large-scale performance tuning.

---

## 1. Git worktrees give each agent an isolated workspace for free

A git worktree is a linked working directory that shares the same `.git` object database as the main repository. Introduced in Git 2.5, worktrees are the foundational primitive for parallel agent development because they provide **full filesystem isolation with zero history duplication**. The object store (blobs, trees, commits, pack files) is shared; only the working copy, index (staging area), and HEAD pointer are per-worktree.

```
main-repo/
├── .git/                      # Full git database (SHARED)
│   ├── objects/               # All objects — SHARED
│   ├── refs/                  # Branch refs — SHARED
│   ├── config, hooks/         # SHARED
│   └── worktrees/             # Per-worktree metadata
│       ├── agent-1/
│       │   ├── HEAD           # Per-worktree
│       │   ├── index          # Per-worktree staging area
│       │   └── commondir      # Points back to shared .git
│       └── agent-2/
```

For a 100 MB codebase, 10 worktrees consume roughly 1 GB of working files but only **one copy of git history** — each additional worktree adds approximately 16 KB of metadata overhead.

### The bare clone pattern for orchestrators

The recommended layout for Stoke/Forge starts from a bare clone, preventing any single worktree from being "primary":

```bash
mkdir -p ~/projects/myapp && cd ~/projects/myapp
git clone --bare git@github.com:org/repo.git .bare
echo "gitdir: ./.bare" > .git
git config remote.origin.fetch "+refs/heads/*:refs/remotes/origin/*"

# Agent worktrees as siblings
git worktree add ./main main
git worktree add ./.worktrees/agent-1 -b agent/1/task-auth main
git worktree add ./.worktrees/agent-2 -b agent/2/task-api main
```

### The branch constraint and workarounds

Git enforces that **no two active worktrees can check out the same branch** — this is a safety guarantee, not a bug. Two worktrees on the same branch would corrupt each other's index. The two primary workarounds are unique branches per agent (`-b agent/1/task-$(date +%s)`) and detached HEAD mode (`--detach`). OpenAI's Codex uses detached HEAD; Claude Code creates unique branches. For Stoke/Forge, unique branches per agent are preferable because they enable pushing and creating PRs directly.

### Ephemeral worktree lifecycle

The create-use-destroy pattern keeps the workspace clean:

```bash
AGENT_ID=$1; BRANCH="agent/${AGENT_ID}/$(date +%s)"
WORKTREE_PATH=".worktrees/${AGENT_ID}"

git worktree add "${WORKTREE_PATH}" -b "${BRANCH}" main
# Agent executes, commits, pushes...
git worktree remove "${WORKTREE_PATH}"
git branch -d "${BRANCH}"  # If merged
```

Use `git worktree lock --reason "Agent running"` to prevent auto-pruning of active worktrees. Use `git worktree prune` to clean stale metadata from crashed agents. Claude Code adds a configurable `cleanupPeriodDays` for orphan removal.

### Go implementation

The go-git v5 library lacks linked worktree support. **go-git v6 adds native worktree management** via `github.com/go-git/go-git/v6/x/plumbing/worktree`, but for production use today, shell out to the git CLI:

```go
func CreateWorktree(repoPath, worktreePath, branch, base string) error {
    cmd := exec.Command("git", "worktree", "add", "-b", branch, worktreePath, base)
    cmd.Dir = repoPath
    return cmd.Run()
}

func ListWorktrees(repoPath string) (string, error) {
    cmd := exec.Command("git", "worktree", "list", "--porcelain")
    cmd.Dir = repoPath
    out, err := cmd.Output()
    return string(out), err
}
```

The practical concurrency sweet spot is **3–5 parallel agents**. Beyond that, merge complexity — not compute — becomes the bottleneck.

---

## 2. File-scope conflict prevention through reservation and locking

Worktrees provide filesystem isolation, but they don't prevent two agents from modifying the same logical file on different branches. Conflict prevention operates at a higher layer and requires the orchestrator to coordinate file ownership before agents begin work.

### Declaring file scope before execution

The orchestrator should require agents to declare (or have predicted) their file scope before dispatch:

```yaml
task:
  id: "task-auth-module"
  agent: "agent-1"
  files:
    owns: ["src/auth/*.go", "internal/middleware/auth.go"]
    reads: ["config/config.go"]
    creates: ["src/auth/jwt.go", "src/auth/jwt_test.go"]
```

Domain-based partitioning maps tasks to non-overlapping code zones. A CODEOWNERS-style file can define agent ownership boundaries — files with multiple owners become explicit conflict zones requiring locking.

### In-memory reservation for single-process orchestrators

Since Stoke/Forge is a single Go process, the simplest and fastest approach is an in-memory reservation manager with **read/write lock semantics** and TTL-based expiry:

```go
type ReservationManager struct {
    mu           sync.RWMutex
    reservations map[string]*FileReservation
}

func (rm *ReservationManager) Reserve(agentID string, files []string, mode LockMode) error {
    sort.Strings(files) // Consistent ordering prevents deadlocks
    rm.mu.Lock()
    defer rm.mu.Unlock()

    // Phase 1: Check ALL files for conflicts
    for _, f := range files {
        if existing, ok := rm.reservations[f]; ok {
            if existing.AcquiredAt.Add(existing.TTL).Before(time.Now()) {
                delete(rm.reservations, f) // Expired — reclaim
                continue
            }
            if mode == WriteLock || existing.Mode == WriteLock {
                return fmt.Errorf("conflict: %s locked by %s", f, existing.AgentID)
            }
        }
    }

    // Phase 2: Acquire ALL atomically (all-or-nothing)
    for _, f := range files {
        rm.reservations[f] = &FileReservation{
            AgentID: agentID, Mode: mode,
            AcquiredAt: time.Now(), TTL: 30 * time.Minute,
        }
    }
    return nil
}
```

The all-or-nothing acquisition pattern prevents partial lock states. Sorting paths before locking prevents deadlocks. TTL auto-expiry prevents stale locks from crashed agents.

### Optimistic versus pessimistic strategies

**Pessimistic locking** (lock before work) suits shared files like `go.mod`, protobuf definitions, and configuration — files where conflicts are likely and resolution is expensive. **Optimistic locking** (merge-time conflict detection) suits the vast majority of code where well-decomposed tasks rarely overlap. The recommended hybrid for Stoke/Forge: pessimistic for known shared files, optimistic for everything else via worktree isolation, with pre-validation at dispatch and post-validation at merge.

For cross-process scenarios, `github.com/gofrs/flock` provides production-quality filesystem advisory locks with `TryLockContext()` retry-with-timeout. Git's own `git lfs lock` mechanism works for server-backed coordination but adds latency and requires an LFS server — it's not ideal for ephemeral agent workflows where in-memory or filesystem locks are faster.

---

## 3. Atomic commits with rich agent metadata

Each agent commit should represent exactly one coherent, reviewable, revertable unit of work. The commit metadata should make agent provenance fully traceable.

### Agent identity in every commit

Set distinct author identities per worktree using environment variables:

```bash
GIT_AUTHOR_NAME="Agent-Refactor" \
GIT_AUTHOR_EMAIL="agent-refactor@stoke.dev" \
GIT_COMMITTER_NAME="Agent-Refactor" \
GIT_COMMITTER_EMAIL="agent-refactor@stoke.dev" \
git commit -m "refactor(auth): extract token validation into separate module"
```

This enables `git log --author=Agent-Refactor` for audit trails, differential branch protection rules for bot PRs, and targeted CODEOWNERS review requirements.

### Git trailers for structured metadata

Git trailers are key-value pairs at the end of commit messages, supported natively and machine-parseable. They are the recommended mechanism for agent metadata:

```
feat(checkout): implement cart total calculation with tax support

Implements cart total calculation with regional tax rate support.
Uses a strategy pattern for different tax jurisdictions.

Agent-Id: agent-feature-a1b2
Agent-Model: claude-sonnet-4-20250514
Agent-Task: CHECKOUT-789
Agent-Intent: Implement cart total calculation with multi-region tax
Agent-Confidence: high
Co-authored-by: Forge Orchestrator <forge@stoke.dev>
```

Add trailers programmatically with `git interpret-trailers --trailer "Agent-Id: $ID"`. Configure automatic trailer injection via `git config trailer.agentid.cmd 'echo "$STOKE_AGENT_ID"'`. Parse trailers from existing commits with `git log --format="%(trailers:key=Agent-Id)"`.

### Squash strategy preserving provenance

Let agents make many incremental commits during work, then squash before merge. The squash commit should aggregate all trailers:

```bash
git checkout main
git merge --squash agent/feature-branch
# Collect trailers from all squashed commits
TRAILERS=$(git log --format="%(trailers)" main..agent/feature-branch | sort -u)
git commit -m "feat(checkout): implement cart calculations

Squashed from agent-feature-a1b2 (12 commits).

${TRAILERS}
Original-Commits: abc1234..def5678"
```

For **signed commits** in automation, SSH signing is simpler than GPG: `ssh-keygen -t ed25519 -f agent_key -N ""`, then `git config gpg.format ssh` and `git config user.signingkey agent_key.pub`.

---

## 4. Stacked PRs decompose agent output into reviewable units

Stacked PRs break a large feature into multiple smaller, sequential PRs where each builds on the previous. Research on **1.5 million PRs** shows that PRs under 200 lines are reviewed 3× faster with 40% fewer defects. Each additional 100 lines increases review time by 25 minutes.

For agent workflows, stacking means an agent producing a schema migration, API endpoints, and frontend components can create three separate PRs in a dependency chain rather than one massive diff.

### Creating stacks manually

```bash
git checkout -b feature/checkout-01-schema main
# Schema changes...
git push -u origin feature/checkout-01-schema
# PR #1 → base: main

git checkout -b feature/checkout-02-api
# API changes...
git push -u origin feature/checkout-02-api
# PR #2 → base: feature/checkout-01-schema

git checkout -b feature/checkout-03-ui
# UI changes...
git push -u origin feature/checkout-03-ui
# PR #3 → base: feature/checkout-02-api
```

GitHub automatically retargets downstream PRs when upstream merges. The critical Git 2.38+ feature `--update-refs` makes rebasing entire stacks trivial:

```bash
git config --global rebase.updateRefs true
git checkout feature/checkout-03-ui
git rebase main --update-refs
# All intermediate branches updated automatically
```

### Tool comparison

**Graphite** is the most polished option with a web dashboard, VS Code extension, built-in stack-aware merge queue, and commands like `gt create`, `gt submit --stack`, and `gt sync`. It costs ~$40/user/month for teams. **ghstack** (Meta/Facebook) maps each local commit to its own PR using a three-branch scheme — powerful but requires merging via `ghstack land`, not the GitHub UI. **stack-pr** (Modular) is a lightweight open-source Python tool embedding stack metadata in commit messages. **git-branchless** is a Rust-based commit-centric workflow tool with Mercurial-like smartlog visualization and automatic child rebasing.

For Stoke/Forge, the minimum viable approach is enabling `rebase.updateRefs` globally and structuring agent branches with dependency ordering. For teams, evaluate Graphite (best UX and merge queue integration) or stack-pr (open-source, lightweight).

---

## 5. Merge queues prevent the "merge skew" problem

A merge queue ensures CI runs on the **merged result** — the combination of the base branch, all PRs ahead in the queue, and the current PR — not just the isolated branch. Without a merge queue, two independently passing PRs can break `main` when combined (e.g., one renames a function, the other calls the old name).

### GitHub's native merge queue

Enable via **Settings → Branches → Require merge queue**. The critical Actions configuration requires adding the `merge_group` trigger:

```yaml
name: CI
on:
  pull_request:
    branches: [main]
  merge_group:
    types: [checks_requested]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: go test -race ./...
```

Both the `pull_request` and `merge_group` workflows must use the **same job name** so branch protection accepts results from either context. A two-step pattern runs fast smoke tests on PR push and heavy integration tests only inside the queue.

Key configuration for agent workflows: set **build concurrency** to match your parallel agent count (5–10), **min group size** to 1 (agents should merge fast), and **max group size** to 5–10 for batching. When a merge conflict arises, the conflicting PR is automatically removed from the queue.

GitHub's native merge queue is limited to organization public repos or Enterprise Cloud. It has no priority queue support, no understanding of stacked PR dependencies, and no monorepo scoping.

### Mergify offers more sophisticated queuing

Mergify's merge queue provides **priority queues, monorepo scoping, batch merging, and two-step CI** out of the box:

```yaml
queue_rules:
  - name: default
    merge_method: squash
    batch_size: 5
    batch_max_wait_time: 5 min
    queue_conditions:
      - base=main
      - check-success=ci/test
      - "#approved-reviews-by>=1"
    merge_conditions:
      - check-success=ci/integration
    scopes:
      - match:
          files: ["services/api/**"]
        name: api
      - match:
          files: ["frontend/**"]
        name: frontend
```

The **scopes feature** is particularly valuable for multi-agent workflows: PRs touching different directories merge independently in parallel, dramatically increasing throughput. Mergify also supports scheduled queue freezes, Slack notifications, and flaky test detection.

**Bors-ng** was the original open-source merge queue but was **archived on April 4, 2024**. Its author recommends GitHub's native merge queue as the replacement. Self-hosting remains possible via the `vendrinc/bors-ng` fork.

---

## 6. Git hooks create an automated quality gate agents cannot bypass

Hooks are the first line of defense against agents committing malformed code, leaked secrets, or invalid commit messages. For parallel agent worktrees, all hooks live in the shared `.git/hooks/` directory — every worktree runs the same hooks automatically.

### Essential pre-commit hooks

A production `.pre-commit-config.yaml` for a Go project:

```yaml
repos:
  - repo: https://github.com/golangci/golangci-lint
    rev: v2.3.1
    hooks:
      - id: golangci-lint
  - repo: https://github.com/gitleaks/gitleaks
    rev: v8.24.2
    hooks:
      - id: gitleaks
  - repo: https://github.com/Yelp/detect-secrets
    rev: v1.5.0
    hooks:
      - id: detect-secrets
        args: ['--baseline', '.secrets.baseline']
```

**Gitleaks** scans staged changes with `gitleaks protect --staged` in under 3 seconds. **detect-secrets** adds a baseline system that accepts pre-existing secrets while blocking new ones. For commit message validation, **commitlint** with `@commitlint/config-conventional` enforces the `type(scope): description` format.

### Preventing --no-verify bypass

This is the most critical guardrail for agent workflows. Defense in depth requires three layers:

**Layer 1 — Client-side blocking.** The `block-no-verify` package intercepts git commands and blocks `--no-verify`. For Claude Code, configure in `.claude/settings.json`:

```json
{
  "hooks": {
    "PreToolUse": [{
      "matcher": "Bash",
      "hooks": [{"type": "command", "command": "npx block-no-verify@1.1.2"}]
    }]
  }
}
```

**Layer 2 — Server-side hooks.** A `pre-receive` hook on the remote validates all pushed commits and cannot be bypassed by any client flag.

**Layer 3 — CI validation.** A GitHub Actions workflow runs commitlint, gitleaks, and golangci-lint on every PR as the final safety net.

### Designing hook errors as AI prompts

Traditional error messages like "linting failed" give agents nothing to work with. Fleek's production experience shows that **hook errors should include the rule, exact violation location, and replacement code** — the error message itself becomes prompt engineering for the agent.

### Performance and tooling

Slow hooks encourage bypassing. Keep pre-commit under **5 seconds** by linting only staged/changed files. **Lefthook** (a Go binary) is the recommended hook manager for Go projects — it supports parallel execution natively and avoids Node.js dependencies:

```yaml
# lefthook.yml
pre-commit:
  parallel: true
  commands:
    lint:
      run: golangci-lint run {staged_files}
      glob: "*.go"
    secrets:
      run: gitleaks protect --staged --source .
```

Set `git config core.hooksPath .githooks/` to share hooks across all worktrees via a tracked directory.

---

## 7. Git bisect turns regression finding into a binary search an agent can automate

Git bisect performs a binary search through commit history: given a known good commit and a bad commit, it checks out midpoints and halves the search space each step. **7 tests find the culprit among 100 commits; 14 tests cover 16,000 commits.**

### Automated bisect with `git bisect run`

The test script's exit codes drive the automation: **0 = good**, **1–124 = bad**, **125 = skip** (untestable, e.g., won't compile), **128+ = abort**:

```bash
#!/bin/bash
# /tmp/bisect-test.sh (place OUTSIDE repo to avoid changes during checkout)
if ! go build ./...; then
  exit 125  # Can't build → skip
fi
if go test -run TestMyFeature -count=1 ./pkg/mypackage/...; then
  exit 0    # Passes → good commit
else
  exit 1    # Fails → bad commit
fi
```

```bash
git bisect start HEAD v1.0.0
git bisect run /tmp/bisect-test.sh
git bisect reset
```

### AI agent bisect-analyze-fix cycle

An agent can chain bisect into a full regression resolution workflow: run `git bisect run` to find the breaking commit, extract the diff with `git show`, analyze what changed and why it broke, then propose and verify a fix. Since **`refs/bisect` is per-worktree**, multiple agents can bisect concurrently on different worktrees without interference.

For performance regressions, use custom terminology: `git bisect start --term-old fast --term-new slow`. For path-scoped bisection: `git bisect start HEAD v1.0 -- pkg/engine/`. Use `--first-parent` to follow only merge commits on trunk and avoid false positives from broken side branches.

In CI, bisect requires `fetch-depth: 0` (full history). Set `timeout 3600 git bisect run ./test.sh` to prevent runaway sessions. Go module and build caches persist across bisect steps, making each iteration faster than the last.

---

## 8. Branch protection and rulesets control what reaches main

GitHub offers two protection mechanisms: legacy **branch protection rules** and newer **rulesets**. Rulesets are strictly superior for agent workflows because they support **bypass actors, multiple layered rules, organization-level enforcement, and the "Exempt" bypass type** designed for high-volume automation.

### Recommended ruleset configuration

```
Ruleset: "Main Branch Protection"
Target: main
Enforcement: Active
Bypass: forge-bot (GitHub App) → Exempt

Rules:
  ✅ Require PR before merging (1 approval, dismiss stale, require CODEOWNERS)
  ✅ Require status checks (ci/test, ci/lint)
  ✅ Block force pushes
  ✅ Restrict deletions
  ✅ Require merge queue
```

The **"Exempt" bypass type** (added September 2025) silently skips enforcement for trusted automation — no audit noise, designed for exactly this use case.

### CODEOWNERS for critical path protection

```gitignore
# .github/CODEOWNERS
*                           @org/platform-team
/cmd/forge/                 @org/core-maintainers
/internal/orchestrator/     @org/core-maintainers
/.github/workflows/         @org/devops
go.mod                      @org/core-maintainers
```

When combined with "Require review from Code Owners," this ensures human review of agent changes to critical paths. The last matching pattern wins, so order rules from general to specific.

### GitHub App for safe automation bypass

A dedicated **GitHub App** is the recommended identity for Stoke/Forge's automation. Unlike PATs, Apps aren't tied to user accounts, don't consume seats, trigger downstream workflows, and provide scoped permissions. Generate installation tokens in Actions with `peter-murray/workflow-application-token-action`:

```yaml
- uses: peter-murray/workflow-application-token-action@v3
  with:
    application_id: ${{ secrets.FORGE_APP_ID }}
    application_private_key: ${{ secrets.FORGE_APP_PRIVATE_KEY }}
```

---

## 9. Git LFS and alternatives for large binary and ML assets

Git LFS replaces large files in the object database with small pointer files, storing actual content on a separate LFS server. Track files exceeding **500 KB that are binary and don't diff well**. GitHub warns on files over 50 MB and blocks files over **100 MB**.

### Setup and configuration

```bash
git lfs install
git lfs track "*.pt" "*.onnx" "*.h5"  # ML models
git lfs track --lockable "*.psd"       # Lockable binary assets
git add .gitattributes
```

The resulting `.gitattributes` entries (`filter=lfs diff=lfs merge=lfs -text`) install smudge/clean filters that intercept `git checkout` and `git add` to swap pointer files with real content transparently.

### CI cost optimization

LFS bandwidth costs scale linearly with CI runs. A studio running 1,300 builds/month against 25 GB of LFS content reported **$3,000/month** in GitHub bandwidth. The primary mitigation is `GIT_LFS_SKIP_SMUDGE=1` combined with selective pulls:

```yaml
- uses: actions/checkout@v4
  with:
    lfs: false
- run: git lfs pull --include="path/to/needed/**"
```

For high-volume CI, deploy an **S3 pull-through proxy** between runners and GitHub — this reduced one team's costs from $3,000/month to $7/month. Custom S3 backends like Rudolfs provide a caching LFS server in a Docker image under 10 MB.

### When to choose DVC over LFS

For ML workflows, **DVC (Data Version Control)** is superior: it tracks ML pipelines and experiments natively, supports any S3-compatible backend without a special server, has no per-object size limits, and enables selective file downloads. The trade-off is that `dvc push`/`dvc pull` run separately from git commands — it's not seamless. **Git Annex** suits distributed archival scenarios with multi-remote redundancy but has a steep learning curve and poor Windows support.

LFS objects are stored in `.git/lfs/objects/` — **shared across all worktrees** since worktrees share the `.git` directory. Multiple agent worktrees don't re-download LFS objects. Use `git lfs lock` for coordinating binary file edits between agents; locked files become read-only until explicitly unlocked.

---

## 10. Monorepo performance through sparse checkout, partial clone, and maintenance

Large repositories slow every git operation. The modern Git performance stack — partial clone, sparse checkout, commit-graph, FSMonitor, and scheduled maintenance — addresses each bottleneck.

### Partial clone eliminates unnecessary downloads

**Blobless clone** (`--filter=blob:none`) downloads all commits and trees but fetches blobs on demand. It's the **recommended default** for developer machines and reusable CI environments — `git log`, `git blame`, and `git bisect` all work correctly, with first-run latency on blob-dependent operations. Azure DevOps reported **88.6% average clone time reduction** with partial clones.

**Treeless clone** (`--filter=tree:0`) downloads only commits, fetching trees and blobs on demand. It's faster for initial clone but unsuitable for development — `git log -- <path>` triggers massive tree downloads. Use it only for ephemeral CI builds.

**Shallow clone** (`--depth 1`) is the fastest initial clone but breaks `git bisect`, `git blame`, and `git merge-base`. Use it only for throwaway CI builds. For anything reusable, prefer blobless partial clone.

### Sparse checkout limits what each agent sees

Combined with partial clone, sparse checkout creates the ideal agent worktree — only the relevant directories exist in the working tree:

```bash
git clone --filter=blob:none --no-checkout https://github.com/org/monorepo.git
cd monorepo
git sparse-checkout init --cone
git sparse-checkout set frontend backend/api

# Per-agent worktree with targeted sparse checkout
git worktree add ../agent-1 -b agent/1/task
cd ../agent-1
git sparse-checkout set module-a shared-libs
```

**Cone mode** (the default since Git 2.25) restricts patterns to directory-level matching, enabling O(1) lookups. Enable `git config index.sparse true` for sparse index support, which further accelerates `git status` and `git add` by skipping entries outside the sparse definition.

### Commit-graph and changed-path Bloom filters

The commit-graph file caches commit metadata with generation numbers for fast reachability queries. **Changed-path Bloom filters** store which paths changed per commit, allowing `git log -- <path>` to skip irrelevant commits without computing tree diffs. Microsoft reported this taking `git log -- <path>` from **5 minutes to under 1 second** on large repos.

```bash
git commit-graph write --reachable --changed-paths
```

Configure automatic commit-graph updates: `git config fetch.writeCommitGraph true`.

### Background maintenance keeps the repo fast

`git maintenance start` registers the repository for scheduled background tasks:

| Task | Frequency | Purpose |
|---|---|---|
| `prefetch` | Hourly | Pre-fetches remote objects into `refs/prefetch/` |
| `commit-graph` | Hourly | Incrementally updates commit-graph |
| `loose-objects` | Daily | Packs loose objects (batches of 50K) |
| `incremental-repack` | Daily | Merges small pack files via multi-pack-index |
| `pack-refs` | Weekly | Packs loose refs into `packed-refs` |

This replaces `git gc`, which is too expensive for large repos. Background prefetch means agent worktree operations (fetch, checkout) hit local objects rather than the network.

### FSMonitor eliminates lstat overhead

`git status` normally calls `lstat()` on every file. In repos with 300K+ files, this takes seconds to minutes. **FSMonitor** watches for filesystem changes and reports only modified files:

```bash
git config core.fsmonitor true
git config core.untrackedCache true
```

The Chromium repo saw `git status` drop from **~20 seconds to ~1 second** with FSMonitor enabled.

### The complete performance configuration

For Stoke/Forge, apply this configuration to the main repository — all worktrees inherit the benefits:

```ini
[core]
    fsmonitor = true
    untrackedCache = true
    commitGraph = true
[fetch]
    writeCommitGraph = true
    parallel = 4
[protocol]
    version = 2
[index]
    sparse = true
[maintenance]
    strategy = incremental
```

Run `git maintenance start` once. Microsoft's **Scalar** (`scalar register`) applies all of these settings automatically and is partially upstreamed into Git core since v2.38.

---

## Conclusion

The architecture for running parallel AI coding agents against a shared repository layers five tiers of git primitives. **Worktrees** provide zero-cost filesystem isolation with shared objects. **File reservation** via an in-memory lock manager with TTL prevents conflicts before they happen. **Atomic commits with trailers** make every agent action traceable and auditable. **Merge queues** ensure that independently correct PRs don't break trunk when combined. And **monorepo optimizations** — partial clone, sparse checkout, commit-graph, FSMonitor, and scheduled maintenance — keep every git operation fast regardless of repository scale.

The most actionable insight across all ten patterns is that **the orchestrator is the single point of coordination**. Stoke/Forge should own the worktree lifecycle, the file reservation table, the commit metadata injection, and the merge queue integration. Git provides the primitives; the orchestrator provides the policy. Design for 3–5 concurrent agents as the initial target, use pessimistic locking only for shared files, and invest in hook error messages that double as AI prompts — fast, precise feedback loops are what turn git guardrails from obstacles into productivity multipliers.