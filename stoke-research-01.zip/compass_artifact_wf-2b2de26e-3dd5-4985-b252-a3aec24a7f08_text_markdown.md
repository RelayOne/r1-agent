# Polyglot monorepo engineering: the complete guide

**Bazel is the only build system that natively unifies Go, Rust, and TypeScript into a single dependency graph with hermetic builds, remote execution, and correct cross-language caching — but its steep learning curve makes Nx the pragmatic choice for teams without dedicated build engineers.** This distinction drives nearly every downstream decision about CI, caching, deployment, and developer experience in a polyglot monorepo. The ten areas covered here form an interconnected system: the build tool determines cache correctness guarantees, which shapes CI architecture, which constrains deployment orchestration. A polyglot monorepo containing Go services, Rust libraries, TypeScript/React web apps, React Native mobile apps, and shared protobuf/GraphQL schemas represents one of the most complex build engineering challenges in modern software — and the tooling ecosystem has matured dramatically since 2023 to address it.

---

## Build tool selection defines everything downstream

The choice of build orchestrator is the single highest-leverage decision. Six tools compete, but only two genuinely handle the Go + Rust + TypeScript stack.

**Bazel** (Google) provides the deepest polyglot support through its rule system. `rules_go`, `rules_rust`, and `rules_ts` (from Aspect Build) each define language-specific compilation, testing, and linking rules loaded as external Starlark dependencies. Bazel's killer feature is its unified dependency graph: a `proto_library` target can feed into `go_proto_library`, `ts_proto_library`, and `rust_prost_library` simultaneously, and changing a `.proto` file correctly invalidates all downstream consumers across all three languages. Remote execution via the Remote Execution API distributes compilation across worker farms (BuildBuddy, EngFlow, or self-hosted), and Google builds billions of lines of code this way daily. The cost is extreme: BUILD files must be written for every package, migration takes months, and a dedicated build engineering team of at least two engineers is effectively required. Gazelle auto-generates BUILD files for Go, and `crate_universe` handles Rust's Cargo dependencies, but TypeScript integration still demands significant manual configuration.

**Nx** occupies the pragmatic middle ground. It provides first-class TypeScript/React/React Native support with official plugins, and as of 2026 offers growing Go and Rust integration through its `createNodesV2` plugin API. Community plugins detect `go.mod` and `Cargo.toml` files, wrapping native toolchains while providing Nx's caching, affected detection, and graph visualization. Cross-language dependencies can be modeled through the project graph — a TypeScript app that consumes generated protobuf code can declare an `implicitDependency` on the schema package. Nx Cloud provides distributed task execution and branch-scoped cache isolation. In benchmarks with 26,000 components, **Nx completed builds in 192 seconds versus Turborepo's 1,432 seconds** — a 7x advantage attributed to Rust-based optimizations and tree-diffing cache restoration.

**Buck2** (Meta) is architecturally superior to Bazel — written in Rust with no GC pauses, a single-phase dependency graph via the DICE incremental computation engine, and remote-execution-first design. It completed builds 2x faster than Buck1 internally at Meta. However, its open-source ecosystem is immature: external dependency management relies on git submodules, documentation is sparse, and users report needing "wizard-level" expertise. Not recommended without Meta-scale build engineering resources.

**Pants** excels at automatic dependency inference (parsing import statements to build the graph without BUILD file boilerplate) and has native Go and protobuf backends, but its TypeScript support is experimental and Rust support is community-only. **Turborepo** and **Rush** are JavaScript/TypeScript-only tools that treat Go and Rust as opaque shell commands with no cross-language dependency understanding.

| Capability | Bazel | Buck2 | Nx | Pants | Turborepo | Rush |
|---|---|---|---|---|---|---|
| Go support | rules_go (mature) | Prelude rules | Community plugin | Native backend | CLI wrap | ❌ |
| Rust support | rules_rust (mature) | Prelude rules | Community plugin | Community plugin | CLI wrap | ❌ |
| TypeScript/React | rules_ts (Aspect) | Limited | **Native** | Experimental | **Native** | **Native** |
| Protobuf codegen | **Native** | Prelude rules | Plugin | Native backend | CLI wrap | ❌ |
| Remote execution | Full (REAPI) | Full | Nx Agents | Full (REAPI) | ❌ | Optional |
| Learning curve | Very steep | Very steep | Moderate | Moderate | Low | Moderate |

**The recommendation**: teams with dedicated build engineers should choose Bazel. Teams without should choose Nx with language plugins for the JS/TS layer and custom `createNodesV2` plugins for Go and Rust. A hybrid approach — Nx for JS/TS orchestration, sccache for Rust compilation caching, Go's native build cache, and CI pipeline scripts connecting the layers — offers pragmatism without Bazel's complexity.

---

## Detecting what changed and enforcing where code can reach

Affected-service detection and package boundary enforcement are two sides of the same coin: both depend on an accurate dependency graph.

**The affected detection algorithm** is consistent across all tools: identify changed files via `git diff`, map files to projects/targets, then compute the transitive reverse closure of the dependency graph. The tools differ in granularity and automation. Bazel's `rdeps()` query operates at target-level granularity — `bazel query "kind('go_test', rdeps(//..., //lib/metrics:metrics))"` finds only test targets affected by a metrics library change. Pants infers dependencies at **file-level granularity** by parsing import statements, yielding maximum cache precision: changing one file in a package only re-tests files that actually import from it. Nx operates at project-level granularity using `git diff` between `--base` (default: `main`) and `--head` to identify changed projects and their transitive dependents. Turborepo's `--affected` flag (since v2.1) provides similar project-level detection but cannot analyze non-JS dependency graphs.

**Cross-language dependency tracking** is the critical challenge. When a protobuf schema changes, both Go and TypeScript consumers must rebuild. The architectural pattern that makes this tractable is treating **shared schemas as bottleneck nodes** in the dependency graph. In Bazel, a `proto_library` target feeds language-specific rules (`go_proto_library`, `ts_proto_library`), and the unified graph propagates changes automatically. In Nx, declare the schema package as an `implicitDependency` of all consumers. For GraphQL, the chain is `graphql-schema` → `graphql-codegen-output` → consumer services. The code generation step creates the dependency edge that connects language worlds.

**Package boundary enforcement** prevents the dependency graph from degrading into chaos. Each language has native mechanisms that should be layered with build-system-level rules:

- **TypeScript**: Nx's `@nx/enforce-module-boundaries` ESLint rule assigns tags to projects (`type:feature`, `scope:client`) and restricts which tags can depend on which. It supports `bannedExternalImports` (preventing a frontend package from importing `@nestjs/*`) and enforces barrel-file-only imports. Turborepo added experimental boundaries enforcement in v2.4.2.
- **Go**: The `internal/` package pattern is compiler-enforced — code at `a/b/c/internal/d` can only be imported by code rooted at `a/b/c`. Every Go service should structure implementation under `internal/`.
- **Rust**: `pub(crate)` should be the default visibility. Only items explicitly `pub` in `lib.rs` form the external API. Cargo workspace boundaries enforce that crates can only depend on declared dependencies.
- **Bazel visibility**: `package_group` definitions create reusable visibility sets. Generated protobuf code for Go can be made visible only to Go services: `visibility = ["//services/go-api:__subpackages__"]`.

**The cross-language enforcement principle**: protobuf and GraphQL schemas must be the **only** cross-language interface. TypeScript files should never import Go types directly. Enforce this with a combination of Nx module boundary rules (or Bazel visibility), per-language linters (`depguard` for Go import restrictions), and a CI validation script that scans for imports violating the schema-only boundary. CODEOWNERS files add organizational enforcement — schema changes require platform team review.

For gradual adoption in existing repos, use the **ratchet pattern**: start with warnings, track violation count in CI, fail the build only if violations increase, and progressively reduce the threshold to zero.

---

## Cache correctness is a security problem, not just a performance one

**CVE-2025-36852 (CREEP), rated 9.4 critical severity**, fundamentally changed how the industry thinks about build caching. Discovered by Nx researchers in June 2025, the attack works against virtually all build systems with shared remote caches. A contributor opens a PR that builds identical code to `main`. Both the PR's CI and `main`'s CI compute the same cache key. The PR's malicious build output races to write to the cache first. When `main` reads the cache, it gets poisoned artifacts deployed to production with no trace.

The root cause is "first-to-cache-wins" in bucket-based storage (S3, GCS) with no distinction between trusted and untrusted build environments. **Branch-scoped cache isolation** is the proper mitigation: PR caches are isolated from the main branch cache, with PRs reading from main's cache but writing only to their own scoped cache. Nx Cloud implements this natively. Bazel can achieve it through careful AC/CAS partitioning. Self-hosted Turborepo caches are vulnerable by default.

Beyond CREEP, cache correctness depends on **hermetic builds** — ensuring that all inputs affecting the output are captured in the cache key. Each language presents distinct hermeticity challenges:

- **Go** is relatively hermetic (static linking by default), but CGO dependencies on system C toolchains and `go mod download` network fetches break hermeticity. Bazel's `rules_go` manages the Go SDK hermetically and uses repository rules with hash pinning for module downloads.
- **Rust's** `build.rs` scripts represent the hardest hermeticity challenge — they can execute arbitrary code, read environment variables, and access the network at compile time. Proc macros similarly read the filesystem at compile time. sccache (the standard Rust compilation cache) cannot cache `bin`, `dylib`, or `proc-macro` crate types, and is mutually exclusive with Rust's incremental compilation. Use `SCCACHE_BASEDIRS` to normalize absolute paths for cross-machine cache sharing.
- **TypeScript/npm** has the worst hermeticity story. `npm install` is non-deterministic across platforms (optional dependencies, lifecycle scripts, hoisting variations). Bazel's `rules_js` addresses this by constructing a hermetic `node_modules` tree from pnpm's lockfile. Framework-specific environment variable injection (`NEXT_PUBLIC_*`, `REACT_APP_*`) must be explicitly tracked in cache keys.

**Bazel's cache architecture** is the gold standard: a two-tier system of Action Cache (mapping `hash(command + input digests + env + toolchain)` → `ActionResult`) and Content Addressable Store (mapping `SHA-256(content)` → bytes). The separation allows skipping downloads when files exist locally and avoiding fetches of intermediate outputs. One known weakness: Bazel does not track tools outside the workspace (e.g., `/usr/bin/gcc`), so users with different compilers can wrongly share cache hits.

**Turborepo's cache** hashes non-gitignored files in the workspace plus environment variables and lockfile contents, but provides **no task sandboxing** — tasks can read and write anywhere on the filesystem, leading to false cache hits from undeclared dependencies. Nx's cache includes sandboxing that monitors filesystem access during execution, flagging reads/writes outside declared inputs/outputs.

---

## Managing three dependency ecosystems in one repository

A polyglot monorepo runs three independent dependency management systems simultaneously. Keeping them coherent requires deliberate architecture.

**For JavaScript/TypeScript, pnpm is the clear winner.** Its non-flat `node_modules` structure prevents phantom dependencies — packages that code imports without declaring in `package.json`, which silently work because of hoisting but break unpredictably when transitive dependency trees change. Only declared direct dependencies appear in the top-level `node_modules`; everything else lives in `.pnpm/` (the virtual store). The `workspace:*` protocol ensures local packages resolve locally and never accidentally pull from the npm registry. On publish, `workspace:^` is converted to the actual version (e.g., `^1.2.3`). For React Native compatibility, set `public-hoist-pattern[]=*react-native*` in `.npmrc` since Metro bundler expects traditional `node_modules` layout. Use `pnpm.overrides` in root `package.json` to enforce a single React version across web and mobile apps.

**Go module workspaces** (`go.work` files, Go 1.18+) coordinate multiple Go modules within the monorepo. The `use` directive lists local module directories; the workspace overlays local resolution on top of individual `go.mod` files without modifying them. Best practice: commit `go.work` for team consistency but run CI with `GOWORK=off` to verify each module's `go.mod` is self-sufficient for independent consumption.

**Rust workspaces** use a virtual manifest pattern — a root `Cargo.toml` with `[workspace]` that lists members via glob (`members = ["crates/*", "services/*"]`). The `[workspace.dependencies]` table centralizes version declarations (`serde = { version = "1.0", features = ["derive"] }`), and member crates inherit with `serde = { workspace = true }`. All members share a single `Cargo.lock` for deterministic resolution. Workspace-level `[lints]` enforce uniform Clippy and compiler settings.

**Cross-language version alignment** is managed through a single source of truth for toolchain versions. A `mise.toml` (or `.tool-versions` for asdf) pins `go = "1.22"`, `rust = "1.75"`, `node = "20"`, `protoc = "25.1"` across all environments. For protobuf specifically, `buf.gen.yaml` declares exact plugin versions for each language's code generation, and `buf.yaml` configures lint and breaking change rules.

**Shared schema versioning** follows the "published source" model internally and "published package" externally. Within the monorepo, all services consume schemas at HEAD — no versioned releases. buf's breaking change detection (`buf breaking --against '.git#branch=main'`) gates every PR, ensuring backward wire compatibility. For Rust libraries, `cargo-semver-checks` analyzes rustdoc JSON output to detect API-breaking changes; a study of 14,000+ crate releases found **3%+ had semver violations** it would have caught. For TypeScript, Microsoft's API Extractor generates `.api.md` reports committed to git, making API surface changes reviewable in PRs. For GraphQL, `graphql-inspector` compares schemas and labels changes as breaking/non-breaking, with usage-based analysis that checks whether "breaking" changes actually affect any active client queries.

---

## CI that scales: run less, not faster

The single biggest CI optimization for monorepos is **running less work, not running the same work faster**. In a 45-package monorepo, `nx affected` typically selects ~4 packages — a 10x reduction before any caching or parallelization.

**The architecture is fan-out/fan-in**: a lightweight `detect-changes` job runs first (using `dorny/paths-filter@v3` for GitHub Actions, the monorepo-diff plugin for Buildkite, or `rules:changes:` for GitLab CI), identifies affected services, then fans out into parallel language-specific jobs via dynamic matrix strategies. Schema changes (`schemas/**/*.proto`, `schemas/**/*.graphql`) trigger all downstream consumers.

**Test sharding** distributes work across runners per language. Jest's `--shard` flag (v28+) splits by file count; Tanium discovered static equal distribution creates unbalanced shards and implemented **timing-based balancing** — a custom reporter captures elapsed time per shard, uploads to S3, and subsequent builds optimize distribution. `cargo-nextest` supports `--partition count:1/4` for Rust test sharding. Go lacks built-in sharding but can be split by package with `gotestsum` capturing timing data for optimization.

**Merge queues** prevent monorepo CI from becoming a serialized bottleneck. With 30-minute CI and a serial queue, maximum throughput is ~48 PRs/day. **Scope-based merge queues** (Mergify, Aviator) define scopes based on file paths — PRs affecting different services merge independently. Mergify's speculative checks test multiple PRs concurrently against predicted future states of main with `max_parallel_checks: 3-5`, pushing throughput past 200 PRs/day. Aviator's Bazel integration automatically detects affected targets and creates disjoint queues.

**Dynamic pipeline generation** replaces static CI configs. In Buildkite, a Python script runs `bazel query` against changed files and generates pipeline steps via `buildkite-agent pipeline upload`. In GitHub Actions, the detect-changes job outputs a JSON matrix consumed by downstream jobs. Uber uses `bazel-diff` (created by Tinder) to identify exact affected targets between Git revisions across their 3,000-service Go monorepo processing 1,000+ commits daily.

**Flaky test management** is essential at scale. Google found **84% of pass-to-fail transitions are flaky, not real bugs**, and 16% of all tests exhibit some flakiness. The best pattern is **auto-quarantine with SLA**: quarantined tests still run but don't block CI, auto-created tickets assign ownership, and tests must be resolved within two sprints or deleted. Bazel supports `--flaky_test_attempts=3` natively. Datadog, Buildkite Test Engine, and Trunk.io provide centralized flaky test dashboards with detection, quarantine, and resolution tracking.

---

## Deploying only what changed, in the right order

Deployment orchestration in a monorepo must solve three problems: detecting which services need redeployment, ordering deploys by dependency graph, and handling failures in multi-service deploys.

**Change detection for deployment** mirrors CI affected detection. Container images are built only for affected services, tagged with the git SHA for traceability. ArgoCD's `argocd.argoproj.io/manifest-generate-paths` annotation tells each Application which source paths it depends on, enabling selective reconciliation. ApplicationSets auto-discover services from directory structure, creating one ArgoCD Application per service × environment combination.

**Deployment ordering** follows topological sort of service dependencies. Independent services deploy in parallel; dependent services deploy sequentially. Uber's approach for large-blast-radius changes (1.4% of commits affect 100+ services) groups services into **deployment cohorts**. Early cohorts (lower-criticality services) deploy first. Negative health signals from early cohorts gate later cohorts. A 24-hour maximum deployment window prevents indefinite rollouts.

**Database migrations** use the **Expand-Contract pattern** exclusively. Never rename or drop columns in a single step. Phase 1 (Expand): add new column as nullable. Phase 2 (Migrate): update application code to write to both old and new. Phase 3 (Contract): remove old column after all services have migrated. This ensures old and new application code work simultaneously, making code rollbacks safe without schema rollbacks. Forward-only migrations (deploy a compensating migration rather than rolling back) are strongly preferred — rollback scripts are error-prone and can cause data loss. Tools like `pgroll` provide zero-downtime, reversible PostgreSQL migrations with automatic backward compatibility.

**Progressive delivery** uses Flagger (CNCF) or Argo Rollouts with a service mesh (Istio, Linkerd) for automated canary analysis. Traffic shifts gradually (5% → 20% → 50% → 100%) with Prometheus metrics driving promotion or automatic rollback. Feature flags (LaunchDarkly, Unleash) offer faster rollout/rollback than canary deploys — deploy code behind flags to all services simultaneously, then enable incrementally. Monzo uses this approach across 2,800 microservices.

**Rollback** of one service in a multi-service deploy is safe when services maintain **N-1 version API compatibility**. Protobuf's field numbering (never reuse field numbers, use `reserved` for removed fields) and GraphQL's `@deprecated` directive enable this. Rolling back a service to its previous container image works if the API contract is maintained. The GitOps pattern stores manifest state in a separate repository from source code — CI builds images, updates image tags in the GitOps repo via automated PR, and ArgoCD/Flux syncs only affected applications.

---

## Keeping developers productive in a growing monorepo

Developer experience degrades predictably as monorepos grow. The countermeasures are well-established but must be applied proactively.

**Git performance** follows clear thresholds. Below 10K files, standard Git works fine. At 50K files, `git status` takes 1-2 seconds and `core.fsmonitor` plus commit-graph should be enabled. At 100K files, **sparse checkout becomes mandatory** — `git sparse-checkout set` restricts the working directory to relevant directories per developer role (frontend developers check out `apps/web` and `libs/shared-components`; Go backend developers check out `services/` and `libs/proto`). Partial clone (`--filter=blob:none`) downloads commit and tree objects but fetches file contents on demand, reducing clone time dramatically — Chromium's 60.9GB repo went from **95-minute clones to under 7 minutes**. **Scalar**, now integrated into Git 2.38+, automatically configures all these optimizations (sparse checkout, partial clone, fsmonitor, commit-graph, multi-pack-index, background maintenance). It originated at Microsoft to support the Office monorepo after VFS for Git proved too platform-dependent.

**IDE performance** is the most painful scaling bottleneck. VS Code handles 50K-100K files reasonably with proper `files.exclude` and `search.exclude` settings, but file search degrades beyond that as ripgrep scans the full worktree. JetBrains IDEs (GoLand, IntelliJ) start struggling at **20K-50K indexed files** — users in large Nx monorepos report broken references 90% of the time. The 2025 DPE Summit saw JetBrains formally acknowledge this, proposing reduced working scope, remote development (offloading indexing to servers), and pre-generated indexes from CI. The practical solution is sparse checkout combined with multi-root workspace configurations that scope each IDE instance to a developer's working area.

**Cross-language code navigation** — jumping from a TypeScript GraphQL query to a protobuf definition to a Go service implementation — has no single-IDE solution. The Buf VS Code extension navigates within `.proto` files; Apollo's extension provides GraphQL schema navigation. Sourcegraph's code intelligence layer (or a self-hosted equivalent) provides cross-repo, cross-language navigation via a web interface. For most teams, the practical answer is: use your language-specific IDE for deep work and Sourcegraph/GitHub code search for cross-language exploration.

**Local development orchestration** uses process managers and Kubernetes dev tools. **Overmind** (Go-based, uses tmux) runs a Procfile defining all local services, allowing developers to attach to individual processes for debugging without restarting the stack. For Kubernetes-native teams, **Tilt** provides a web dashboard visualizing build status, logs, and service health across all local services, with Starlark configuration that understands service dependencies and smart rebuilds via file sync. Docker Compose remains the simplest option: run infrastructure (Postgres, Redis, Kafka) in containers while developing the active service natively with hot-reload.

**Onboarding** should target one-command setup. A `mise.toml` pins all toolchain versions; `mise install` configures the environment. Sparse checkout presets per team role (frontend, backend, mobile) limit initial clone scope. Pre-built devcontainers (GitHub Codespaces, Gitpod) eliminate local environment debugging entirely — Stripe's centrally-provisioned ephemeral devboxes made "pull main + re-create devbox" the first-line debugging step, reducing individual environment issues to near-zero.

---

## What the largest monorepos teach us

Real-world monorepos at scale validate several principles that should inform architectural decisions at any size.

**Google's Piper** stores over **1 billion files and 2 billion lines of code**, serving 25,000 developers making 40,000 changes daily (16,000 human, 24,000 automated). Its virtual filesystem layer, CitC (Clients in the Cloud), presents the entire repo as a FUSE filesystem where developer workspaces overlay changes on top of the full repository — the average workspace touches fewer than 10 files. No cloning, no syncing. This model is what Scalar and EdenFS approximate at smaller scale.

**Meta's stack** pairs Buck2 (Rust-based build system with remote-execution-first architecture) with Sapling (Mercurial-derived VCS where all operations scale with files-in-use, not repo size) and EdenFS (virtual filesystem using FUSE on Linux, NFS on macOS, ProjFS on Windows). The key insight: **at Meta's scale, the build system, version control system, and filesystem are co-designed as a single integrated system**. Each component's design assumptions depend on the others.

**Uber's Go monorepo** contains ~50 million lines of code across ~3,000 microservices with 1,000+ daily commits. They migrated to Bazel, contributed significantly to Gazelle (their engineers are #2 and #3 contributors), and built SubmitQueue to ensure main always builds. Their most impactful innovation is **cohort-based deployment orchestration**: analysis of 500K commits showed 1.4% affect 100+ services and 0.3% affect 1,000+ services. For these large-blast-radius changes, services deploy in cohorts with health signals from early cohorts gating later ones.

**Airbnb** migrated their JVM monorepo from Gradle to Bazel after Gradle builds hit 20+ minutes locally with CI p90 at 35 minutes. They co-existed Bazel alongside Gradle during migration, letting developers opt in. Their proof of concept targeted Viaduct, their GraphQL monolith platform with 300 monthly contributing engineers.

**Microsoft's 1JS monorepo** (2,500 packages, 20 million lines of TypeScript) reached a **178GB clone size** before optimization. Using git-sizer profiling, large blob cleaning, and Git client improvements, they reduced it to 5GB — a 94% reduction. This experience drove the creation of VFS for Git, then Scalar, and ultimately contributed sparse-checkout cone mode, background maintenance, commit-graph, and multi-pack-index upstream to Git itself.

---

## Conclusion: the architectural decisions that matter most

The polyglot monorepo with Go, Rust, TypeScript, React, and React Native demands five non-negotiable architectural commitments.

**First, choose your build orchestrator based on team capacity, not feature lists.** Bazel provides the strongest correctness guarantees and the only true polyglot dependency graph, but requires dedicated build engineers. Nx offers 80% of the value at 20% of the complexity for teams that can tolerate wrapping Go and Rust via plugins.

**Second, make shared schemas (protobuf, GraphQL) the only cross-language interface.** This is the single design decision that makes everything else tractable — affected detection, boundary enforcement, cache correctness, and deployment ordering all become simpler when cross-language edges flow exclusively through schema packages with code generation bridges.

**Third, implement branch-scoped cache isolation from day one.** The CREEP vulnerability (CVE-2025-36852) means any shared cache without branch scoping is a supply-chain attack vector. Nx Cloud provides this natively; Bazel requires careful AC/CAS partitioning.

**Fourth, adopt pnpm for JavaScript, `go.work` for Go, and Cargo workspaces for Rust — with toolchain versions pinned in a single `mise.toml`.** Cross-ecosystem version alignment through a single toolchain version source prevents the drift that makes polyglot repos fragile.

**Fifth, invest in sparse checkout and CI affected detection before the repo reaches 50K files.** Git performance, IDE usability, and CI speed all degrade predictably. The teams that scale successfully are those that implement Scalar, sparse checkout presets per role, and affected-only CI before the pain becomes acute — not after.

The monorepo is not a repository strategy. It is a **coordination architecture** that trades version management complexity for integration testing confidence. Every tool and pattern described here serves that trade: ensuring that a single commit affecting a protobuf schema correctly rebuilds, retests, and redeploys exactly the Go services, Rust libraries, TypeScript web apps, and React Native mobile apps that consume it — nothing more, nothing less.