# Production caching architecture: a deep technical reference

**Every cache bug in production traces back to one of three root causes: stale data served too long, fresh data computed too often, or memory wasted on the wrong keys.** This report covers the complete architecture of multi-layer caching systems built on Redis/Valkey, Cloudflare, and in-process caches in Go and Node.js — from byte-level memory overhead to cross-region CRDT replication. It synthesizes patterns from Meta's memcache paper, Uber's CacheFront (150M+ reads/sec), Netflix's EVCache (400M ops/sec), and Cloudflare's edge infrastructure, prioritizing production-grade implementations over textbook concepts.

---

## 1. Cache invalidation strategies and their real failure modes

Five fundamental patterns exist for coordinating cache and database state, each with distinct consistency-latency tradeoffs.

**Cache-aside (lazy loading)** is the dominant pattern in production. The application checks cache, queries the database on miss, and populates the cache. On write, the application updates the database then deletes the cache key. Uber's CacheFront uses this at 150M+ reads/sec with a **99.9% hit rate**, reducing their infrastructure from 60K CPU cores to 3K Redis cores. The critical failure mode is a race condition: Thread A reads "Alice" from the DB, Thread B updates the DB to "Bob" and deletes the cache, then Thread A writes "Alice" to the cache — permanently stale until TTL expires. Uber solves this with **version-based deduplication via Redis Lua scripts**, comparing MySQL row timestamps before allowing cache writes.

```go
// Cache-aside with singleflight for stampede prevention
var g singleflight.Group
func GetUser(ctx context.Context, userID string) (*User, error) {
    cacheKey := "user:" + userID
    if cached, err := rdb.Get(ctx, cacheKey).Result(); err == nil {
        var user User
        json.Unmarshal([]byte(cached), &user)
        return &user, nil
    }
    v, err, _ := g.Do(cacheKey, func() (interface{}, error) {
        user, err := db.QueryUser(ctx, userID)
        if err != nil { return nil, err }
        data, _ := json.Marshal(user)
        rdb.SetEx(ctx, cacheKey, data, jitteredTTL(5*time.Minute, 0.2))
        return user, nil
    })
    return v.(*User), err
}
```

**Read-through** differs in that the cache library itself manages DB fetching on miss. The application only ever talks to the cache. AWS DynamoDB Accelerator (DAX) is the canonical implementation. In Go, `go-redis/cache` provides this with a built-in L1 TinyLFU layer via its `Once()` method. The constraint: cached data must mirror the DB model exactly — you cannot store pre-computed aggregates.

**Write-through** writes synchronously to both cache and database before returning. It provides strong consistency between cache and DB but adds latency to every write (two synchronous operations). DAX implements both read-through and write-through. Best for financial systems where stale cache data is unacceptable.

**Write-behind (write-back)** writes to cache and returns immediately, deferring the DB write to a background worker. This achieves sub-millisecond write latency and can coalesce multiple updates to the same key into a single DB write. The fundamental risk is **data loss** — if Redis crashes before the background worker persists to the DB, writes are lost. Implement the background queue using Redis Streams with consumer groups for durability. Never use write-behind for payment or financial data.

**Refresh-ahead** proactively refreshes entries before TTL expiry. When a request finds a cache entry within its "refresh window" (typically the last 20% of TTL), the current value is returned immediately while a background task refreshes the data. Akamai implements "Cache Prefreshing" at configurable thresholds. Implementation complexity is high — you need tracking of refresh eligibility, background workers, deduplication of refresh tasks, and grace period handling when refreshes fail.

---

## 2. Multi-layer cache coherence: L1 → L2 → L3

The standard multi-layer topology provides **~10ns** access at L1 (in-process), **~0.5–2ms** at L2 (Redis), and **~5–50ms** at L3 (PostgreSQL). The hard problem is invalidation propagation.

For Go, `dgraph-io/ristretto` (LFU-based admission, concurrent) or `go-redis/cache` with built-in TinyLFU serve as L1. For Node.js, `lru-cache` is the standard. Redis/Valkey serves as L2 with typical TTLs of 5 minutes, jittered.

**Redis Pub/Sub acts as the invalidation backplane.** When any service instance updates the database and invalidates a Redis key, it publishes an invalidation event on a dedicated channel. All service instances subscribe and evict the corresponding L1 entry:

```go
// Invalidate across all layers
func (c *MultiLayerCache) Invalidate(ctx context.Context, key string) error {
    c.l1.Del(key)                                        // Local L1
    c.redis.Del(ctx, key)                                // Shared L2
    return c.redis.Publish(ctx, "cache:invalidate", key).Err() // Broadcast to all instances
}

// Every instance runs this as a goroutine
func (c *MultiLayerCache) ListenForInvalidations(ctx context.Context) {
    pubsub := c.redis.Subscribe(ctx, "cache:invalidate")
    ch := pubsub.Channel()
    for msg := range ch {
        c.l1.Del(msg.Payload)
    }
}
```

```javascript
// Node.js equivalent
const subscriber = new Redis(); // Separate connection for Pub/Sub
const l1Cache = new LRU({ max: 1000, ttl: 60000 });
subscriber.subscribe('cache:invalidate');
subscriber.on('message', (_, key) => l1Cache.delete(key));
```

**Redis Pub/Sub is fire-and-forget** — messages are not persisted. If an instance is down during publish, it misses the invalidation. The production defense is **two-layer protection**: event-driven invalidation for the happy path (millisecond propagation) plus TTL as a safety net (bounded staleness). Always set short TTLs on L1 entries (30–60 seconds) even with Pub/Sub. For stronger durability, use **Redis Streams** instead of Pub/Sub — messages persist, consumer groups allow replay, and disconnected instances can catch up. The tradeoff is higher complexity.

The **TOCTOU race** in multi-layer caching is insidious: Instance A reads "old" from L2, the value is updated in DB + L2 with an invalidation broadcast, Instance A receives and processes the invalidation (no-op since it hasn't cached locally yet), then Instance A writes "old" to L1 — stale data persists until L1 TTL. Keeping L1 TTLs very short (30–60 seconds) bounds this window. For data requiring strong consistency, **skip L1 entirely** and read from Redis (L2) directly.

Uber's CacheFront uses a Lua script for atomic compare-and-swap with DB row timestamps — the script rejects cache writes where the incoming timestamp is older than what's already cached. Meta's memcache system uses **lease-based invalidation** (NSDI 2013 paper): the cache issues a 64-bit token on miss, and if a delete arrives for that key before the token is used, the token is invalidated, preventing stale sets.

---

## 3. Cache stampede prevention: four complementary techniques

A cache stampede occurs when a popular key expires and hundreds of concurrent requests simultaneously hit the database. The techniques below operate at different scopes and should be layered.

**Go's `singleflight`** deduplicates concurrent calls within a single process. When multiple goroutines request the same key simultaneously, only one executes the fetch function; all others block and receive the shared result. The `singleflight.Group` uses a `sync.Mutex`-protected `map[string]*call` internally. The first caller creates the entry, runs the function, and broadcasts the result via `sync.WaitGroup`. Scope is single-process only — it does not deduplicate across pods. For Node.js, the equivalent is **promise coalescing**: store the in-flight `Promise` in a `Map` so concurrent callers `await` the same promise. Instagram uses this pattern: "Instead of caching the result, they cache the Promise. First miss creates a Promise. Every other request finds the Promise and awaits it. One DB query."

```javascript
const inFlight = new Map();
async function getWithCoalescing(key, fetchFn) {
    if (inFlight.has(key)) return inFlight.get(key);
    const promise = fetchFn().finally(() => inFlight.delete(key));
    inFlight.set(key, promise);
    return promise;
}
```

**Distributed locking** extends deduplication across processes using `SET lock:{key} {unique_id} NX EX {timeout}`. Only one process recomputes; others poll the cache with short sleeps. Lock release must be atomic via a Lua script that checks ownership before deleting — otherwise a process whose lock expired could delete another process's lock. For cache stampede prevention, single-instance locks suffice; the Redlock algorithm (majority across N independent Redis instances) is overkill and has been criticized by Martin Kleppmann for safety under network partitions and GC pauses.

**Probabilistic early revalidation (XFetch)** from the Vattani, Chierichetti, and Lowenstein paper (VLDB 2015) is the most elegant approach. The formula `shouldRecompute = (currentTime - delta × beta × ln(random())) >= expiry` uses an exponential distribution to probabilistically trigger recomputation before TTL expiry, where `delta` is the last computation duration and `beta` is a tuning parameter (default 1.0). The paper proves this achieves **O(1) expected stampede size** regardless of request rate, with no external coordination. The main implementation overhead is storing `delta` alongside each cached value. Cloudflare uses this in Workers, noting it "adds no latency, requires no external coordination service, and is resilient to lock service failures."

**Request coalescing at the proxy/CDN level** handles stampedes for static or semi-static content. Nginx's `proxy_cache_lock on` allows only one request through to origin per key, but unlocks waiting requests in 500ms intervals. Cloudflare coalesces requests at each edge data center, using file extension to predict cacheability before the origin responds, and streams the response to all waiting clients simultaneously.

| Technique | Scope | Stampede size | Latency impact | Best for |
|-----------|-------|--------------|----------------|----------|
| Singleflight | Single process | 1 per process | Waiters blocked | In-process dedup |
| Distributed lock | Cross-process | 1 globally | Waiters poll | Expensive computations |
| XFetch | Any | O(1) expected | None | High-traffic keys |
| Proxy coalescing | Per-server/POP | 1 per server | Minor | CDN/static content |

---

## 4. Thundering herd mitigation through TTL engineering

While stampede prevention handles one key's expiration, thundering herd mitigation handles thousands of keys expiring simultaneously — typically after a bulk load, deployment, or cache warming event.

**TTL jittering** is the baseline defense. Every cache set should add randomness: `effective_ttl = base_ttl + random(0, base_ttl × 0.2)`. A 5-minute base TTL becomes 5:00–6:00, spreading expirations over a 60-second window instead of a single moment. This is trivial to implement and should be applied universally:

```go
func jitteredTTL(base time.Duration, factor float64) time.Duration {
    jitter := time.Duration(rand.Float64() * float64(base) * factor)
    return base + jitter
}
```

**Stale-while-revalidate (SWR)** serves stale data immediately while refreshing asynchronously. At the HTTP level, `Cache-Control: max-age=60, stale-while-revalidate=300` means the asset is fresh for 60 seconds, then stale-but-servable for 300 more seconds while a background revalidation occurs. As of **February 2026, Cloudflare's SWR is fully asynchronous** — no visitor blocks during revalidation, and all concurrent requests receive stale content with `CF-Cache-Status: UPDATING`. For Redis, SWR requires storing a "soft expiry" timestamp alongside the value: if the current time is past soft expiry but before hard expiry (Redis TTL), serve the cached value and trigger a background refresh.

**Cache warming on deployment** pre-populates the cache before traffic arrives. Identify hot keys via access log analysis, `redis-cli --hotkeys`, or `OBJECT FREQ` (with LFU eviction enabled). Warm in small batches with pauses — fetching 100K keys in parallel is itself a thundering herd against your own database. Always jitter warmed TTLs. A deployment pattern: deploy canary instances with no traffic, run warming scripts against them (populating shared Redis), then gradually shift traffic via the load balancer. IRCTC pre-warms train data by 9:45 AM before the 10 AM Tatkal booking window.

**Meta's lease-based approach** (from their NSDI 2013 memcache paper) rate-limits lease issuance to once per 10 seconds per key. When a second client misses the same key within 10 seconds, the cache returns a "wait and retry" signal instead of a lease. This reduced Meta's peak thundering-herd DB query rate from **17K/sec to 1.3K/sec**.

---

## 5. Hot key detection and the 50% traffic problem

When one cache key absorbs a majority of traffic, it bottlenecks a single Redis shard regardless of cluster size. Redis is single-threaded per shard — 50K req/sec to one key means one CPU core doing all the work. At Twitter, hot key traffic saturated 1Gb NICs, triggered cascading failures in monitoring services, and caused multiple SEV-0 incidents over a decade.

**Detection methods** range from lightweight to heavy. `redis-cli --hotkeys` (requires LFU eviction policy) samples keys and reports access frequency with low overhead. `OBJECT FREQ <key>` returns the logarithmic frequency counter for a specific key. `MONITOR` streams every command in real-time but reduces throughput by ~50% — use only briefly. The most scalable approach is **client-side frequency tracking** using Count-Min Sketch algorithms (e.g., the KeyFlare library for Go) with constant memory, >99% accuracy, and zero Redis overhead.

**L1 in-process caching for hot keys** is the primary defense. When a key is detected as hot (via client-side frequency tracking), auto-promote it from Redis to the in-process cache with a 5–30 second TTL. This eliminates Redis network round-trips entirely for hot data. Twitter's Nighthawk system signals hot keys back through the API layer, and the requesting service (Haplo) caches them locally.

**Key splitting** distributes a hot key across N replicas: `product:iphone:1` through `product:iphone:N`, randomly selected on each read. Each replica maps to a different Redis Cluster hash slot, distributing load across shards. On write, update all N copies or rely on short TTLs for convergence.

**Redis 6+ server-assisted client-side caching** uses `CLIENT TRACKING` to maintain an invalidation table server-side. When any client modifies a tracked key, the server pushes invalidation messages to all tracking clients. Broadcasting mode (`PREFIX user:`) eliminates server-side memory cost but increases invalidation traffic. Redisson reports reads up to **45x faster** with client-side caching enabled. The `tracking-table-max-keys` setting (default 1M) caps server-side memory — when exceeded, the server evicts random entries and sends invalidation.

---

## 6. Cloudflare CDN caching: from Cache Rules to Workers

**Cache Rules** replaced Page Rules and offer richer matching (URI path, hostname, cookie, user agent, headers), stackable evaluation, and AND/OR conditions. A critical behavioral change: selecting "Eligible for cache" enables Cache Everything by default. Configure Edge TTL (how long Cloudflare holds the asset, controlled via `s-maxage`) separately from Browser TTL (controlled via `max-age`). Status code TTLs allow caching 200s for a day while caching 404s for one minute.

**Vary header handling is limited.** Cloudflare ignores most Vary values for caching — `Vary: User-Agent` and `Vary: Accept-Language` have no effect on cache key differentiation. Only `Vary: Accept-Encoding` is respected (Cloudflare handles gzip/br natively). `Vary: Accept` is supported exclusively for images on paid plans ("Vary for Images"), enabling WebP/AVIF/JPEG variants from the same URL. For custom Vary behavior, use Workers to inject varying values into the cache key URL.

**Cache-Tag enables surgical purge** — tag responses with arbitrary labels (`Cache-Tag: product:456, category:electronics`), then purge all responses matching a tag globally via API. Tags are now available on all plans. Maximum aggregate header size is 16KB (~1,000 unique tags). Purge-by-tag rate limits vary by plan: Free gets 5 requests/minute, Enterprise gets a 500-token bucket. The new Cache Response Rules (March 2026) allow adding Cache-Tags without modifying the origin server.

**Workers caching uses two namespaces.** `caches.default` shares the zone's CDN cache — operations affect the same cache as normal proxy traffic. `caches.open('custom-name')` creates isolated namespaces for Worker-specific data. The Cache API is **local to each datacenter** (no global replication) and does **not participate in Tiered Cache** — use `fetch()` with `cf` options for tiered caching. SWR directives are not supported in the Cache API; they only work through the standard fetch-based cache.

```javascript
// Workers: custom cache key by user segment
export default {
  async fetch(request, env, ctx) {
    const cache = caches.default;
    const url = new URL(request.url);
    const segment = request.headers.get('Cookie')?.match(/segment=(\w+)/)?.[1] || 'default';
    url.searchParams.set('_seg', segment);
    const cacheKey = new Request(url.toString(), { method: 'GET' });

    let response = await cache.match(cacheKey);
    if (!response) {
      response = await fetch(request);
      response = new Response(response.body, response);
      response.headers.set('Cache-Control', 's-maxage=600');
      response.headers.set('Cache-Tag', `segment:${segment}`);
      ctx.waitUntil(cache.put(cacheKey, response.clone()));
    }
    return response;
  }
};
```

For **personalized content at edge**, Cloudflare's HTMLRewriter API transforms cached page shells by injecting personalization data from Workers KV. Cache the static shell with a long TTL, then rewrite personalized fragments (greeting, cart count, recommendations) per-request using KV lookups. This achieves CDN-level cache hit rates for the page body while delivering personalized experiences.

**Smart Tiered Cache** automatically selects the optimal upper-tier datacenter nearest to the origin, creating a two-level edge hierarchy that dramatically reduces origin load. Regional Tiered Cache adds intermediate hubs to avoid cross-continent fetches (50–100ms improvement in tail latency). Cache Reserve uses R2 storage as a persistent upper tier, preventing eviction of long-tail content.

---

## 7. Negative caching stops cache penetration attacks

Cache penetration occurs when requests for non-existent keys bypass the cache entirely, hammering the database. Attackers exploit this by querying random invalid IDs (e.g., `product_id=-1`), since there's nothing to cache.

**Sentinel values** solve the common case: when a DB lookup returns empty, cache a marker like `"__NULL__"` with a short TTL (30–60 seconds). Subsequent requests for the same key hit the sentinel in cache instead of the DB. The short TTL ensures recovery when data is actually created. The tradeoff: if attackers query millions of unique non-existent keys, sentinels can fill cache memory.

**Bloom filters** handle the adversarial case. A Bloom filter answers "Is this element in the set?" with zero false negatives — if it says "no," the key definitely doesn't exist, and you skip the DB lookup entirely. For 1 million items at 1% false positive rate, a Bloom filter consumes only **~1.2MB** versus ~85MB for equivalent Redis key-value pairs. Redis provides the RedisBloom module (`BF.RESERVE`, `BF.ADD`, `BF.EXISTS`), or use in-memory Bloom filters in Go (`bits-and-blooms/bloom`) for zero-latency checks.

```go
filter := bloom.NewWithEstimates(1_000_000, 0.01) // 1M items, 1% FPR
// On DB write: filter.AddString("user:" + id)
// On read:
if !filter.TestString("user:" + id) {
    return nil, ErrNotFound // Definitely doesn't exist — skip DB
}
// Might exist — proceed to cache then DB
```

Production defense layers should be stacked: rate limiting at the API gateway → input validation (reject obviously invalid IDs) → Bloom filter → negative caching with sentinels → circuit breaker on DB error rate.

---

## 8. Cache versioning survives rolling deployments

During rolling deployments, old and new service versions read and write the same cache simultaneously. Old instances write v1 format objects; new instances expect v2 format. Without versioning, this causes deserialization failures or silent data corruption.

**Version prefix in cache keys** (`v2:user:123`) is the standard solution. When a schema changes, increment the version — old and new keys coexist without collision. Three approaches to versioning: a global version counter in Redis (`cache:version` incremented on deploy), per-entity versions for granular control, or a schema hash (Shopify's IdentityCache generates a hash of column definitions that changes automatically on schema change).

**Migration strategies** determine how old cached data is handled. **Lazy migration** transforms old format to new on read and writes back the upgraded value — zero upfront cost but requires maintaining transformation code. **TTL-based expiry** simply bumps the version prefix and lets old keys expire naturally — simplest approach but temporarily increases miss rate. **Dual-read** tries the new key first, falls back to the old key with transformation — gracefully handles rolling deployments where both versions coexist:

```go
func GetUser(ctx context.Context, id string) (*UserV2, error) {
    if data, err := cache.Get(ctx, "v2:user:"+id); err == nil {
        return deserializeV2(data)
    }
    if data, err := cache.Get(ctx, "v1:user:"+id); err == nil {
        v2 := transformV1toV2(deserializeV1(data))
        cache.Set(ctx, "v2:user:"+id, serializeV2(v2), ttl) // Upgrade in place
        return v2, nil
    }
    return fetchFromDB(ctx, id) // Cache miss
}
```

**Protocol Buffers** can reduce the frequency of version bumps. Protobuf is forward-compatible by design (old code ignores unknown fields) and backward-compatible via default values. Only truly breaking changes — removing required fields or changing field types — need key version bumps. JSON requires explicit `ignoreUnknown` configuration and manual default handling.

---

## 9. Redis memory: every key costs ~100 bytes before your data

Understanding Redis memory overhead prevents costly surprises when scaling to millions of keys.

Every key in Redis requires a **dictEntry** (24 bytes: key pointer + value pointer + next pointer), an **SDS string** for the key (3-byte sdshdr8 header + key length + null terminator, rounded to jemalloc class), and a **redisObject** (16 bytes: type, encoding, LRU/LFU bits, refcount, data pointer). Redis compiles jemalloc with `--with-lg-quantum=3` for 8-byte granularity allocation classes: [8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, ...].

For strings ≤ 44 bytes, Redis uses **embstr encoding** — the robj and SDS are allocated contiguously in one 64-byte jemalloc allocation (16 robj + 3 sdshdr8 + 44 data + 1 null = 64). For longer strings, two separate allocations are needed (raw encoding).

**Concrete example:** Key `"user:12345"` (10 bytes) with value `{"name":"John","age":30}` (23 bytes) consumes dictEntry 24B + key SDS 16B (14B rounded up) + value embstr 48B (43B rounded up) + hash bucket ~11B = **~99 bytes total**. The useful data is 33 bytes. **Overhead ratio: ~3x.** Adding a TTL costs an additional ~32 bytes (extra dictEntry in the expires dictionary).

**Hash ziplist/listpack optimization** dramatically reduces per-field overhead. When a hash has fewer than `hash-max-listpack-entries` (default 128) entries with values under `hash-max-listpack-value` (default 64 bytes), all fields are stored in a contiguous memory block — one robj, one allocation, ~15–25 bytes per field instead of ~80–100. This delivers **5x memory savings** for small hashes. The hash bucketing pattern (`HSET users:${Math.floor(userId/1000)} ${userId} ${data}`) keeps each hash under the threshold.

**When to skip caching:** If computation takes <0.1ms in-process but a Redis GET takes 0.2ms + 0.05ms deserialization, caching is 250x slower. On AWS ElastiCache, Redis costs ~$13/GB/month — at 100 bytes per key, that's ~$1.30/month per million keys. Worth it for frequently-accessed data; wasteful for keys accessed less than once per day.

**Eviction policy selection** depends on workload. **`allkeys-lfu`** (Redis 4.0+) is the best general-purpose choice for cache workloads — it uses a Morris counter (8-bit logarithmic frequency counter) that prevents rarely-accessed items from evicting consistently popular ones. `allkeys-lru` is simpler and sufficient for most patterns. Redis's LRU is approximate: it samples `maxmemory-samples` random keys (default 5, increase to 10 for near-perfect accuracy) and evicts the one with the longest idle time. **`volatile-ttl`** suits session stores where TTL indicates priority. **`noeviction`** is mandatory for job queues and primary data where data loss is unacceptable.

Monitor fragmentation via `INFO memory`: `mem_fragmentation_ratio` above 1.5 warrants enabling `activedefrag`. Track hit rate with `keyspace_hits / (keyspace_hits + keyspace_misses)` — target >95% for general caching. When `evicted_keys` grows steadily, either increase `maxmemory` or optimize key design.

---

## 10. Distributed caching: from hash slots to cross-region CRDTs

**Redis Cluster** partitions data across **16,384 hash slots** using `CRC16(key) mod 16384`. Each master node owns a subset of slots. Hash tags (`{user:1001}.profile`, `{user:1001}.settings`) force related keys to the same slot, enabling multi-key operations and Lua scripts across them. During resharding, the `MIGRATE` command atomically transfers keys between nodes — `ASK` redirections handle in-flight queries while `MOVED` redirections update clients permanently after completion. The order of `CLUSTER SETSLOT` commands matters: destination must be set to IMPORTING before source is set to MIGRATING, and destination must receive the final SETSLOT NODE first.

**Consistent hashing (Ketama)** maps servers and keys to positions on a circular hash space, with each server occupying multiple virtual node positions for even distribution. When a server is added or removed, only ~1/N of keys are remapped. With 100 virtual nodes per server, standard deviation is ~3.2% per node. **Jump consistent hash** (Google, Lamping & Veach 2014) achieves near-perfect distribution with zero memory overhead and O(ln n) computation, but requires sequential bucket numbering — suitable for stable shard topologies, not arbitrary node failures. Redis Cluster's hash slot approach is explicit (admin assigns slots) versus consistent hashing's implicit assignment; Redis Cluster additionally provides built-in gossip-based discovery, automatic failover, and multi-key operation support.

**Cross-region replication** options span a spectrum. Redis Enterprise's Active-Active uses **operation-based CRDTs with vector clocks**: strings use last-writer-wins, counters use PN-Counters (conflict-free addition/subtraction across replicas), sets use OR-Set (add-wins semantics), and hashes combine per-field LWW with counter support. This provides strong eventual consistency — any two instances receiving the same unordered set of updates converge to identical state. Without Redis Enterprise, alternatives include AWS ElastiCache Global Datastore (active-passive, sub-second async lag, up to 2 read-only secondary clusters), application-level dual-write via Kafka for cross-region sync, or CDC-based replication parsing Redis keyspace notifications.

**Valkey forked from Redis 7.2.4** in March 2024 after Redis Inc. changed licensing from BSD to RSALv2/SSPLv1. Under Linux Foundation governance with backing from AWS, Google Cloud, Oracle, and others, Valkey has diverged significantly. **Valkey 9.0** (October 2025) introduced atomic slot migration (replacing key-by-key MIGRATE with full-slot AOF-based transfer), hash field expiration, numbered databases in cluster mode, support for 2,000-node clusters at 1B+ RPS, and pipeline memory prefetch delivering 40% throughput gains. Valkey 8.0's enhanced I/O threading benchmarked at **1.19M RPS** on AWS r7g — a 230% improvement over 7.2. The per-slot dictionary saves 16 bytes per key-value pair in cluster mode. All existing Redis clients (go-redis, ioredis, redis-py) work with Valkey unchanged. AWS ElastiCache for Valkey is **~20% cheaper** than ElastiCache for Redis. The key gap: Active-Active CRDT replication remains Redis Enterprise-only with no Valkey equivalent yet, and Redis Stack modules (native JSON, vector search, time series) are built into Redis 8 core while Valkey relies on separate BSD-licensed module ports (valkey-json, valkey-search, valkey-bloom).

---

## Conclusion: layering these patterns into a production architecture

The most resilient caching architecture layers multiple techniques simultaneously rather than relying on any single pattern. Use **cache-aside as the default strategy** with TTL jittering on every key (baseline defense), singleflight within each Go process (cheap insurance against stampedes), and Redis Pub/Sub broadcasting L1 invalidations across service instances (with TTL as the safety net for missed messages). For hot keys, auto-promote from Redis to in-process L1 caches based on client-side frequency detection, falling back to key splitting across N Redis replicas when a single shard saturates. At the CDN layer, Cloudflare's Cache-Tag system enables surgical purge without TTL-based expiration delays, while Workers with HTMLRewriter deliver personalized content from cached page shells.

The most commonly underestimated cost is Redis memory overhead — the ~3x ratio between useful data and actual consumption means a "small" cache of 10M keys occupying 1GB of useful data actually requires 3GB of Redis memory at ~$40/month on ElastiCache. The most commonly underestimated risk is the TOCTOU race in multi-layer caching, where a slow reader can permanently cache stale data after an invalidation event has already passed — bounded only by L1 TTL. And the single highest-impact optimization for most systems is simply upgrading from `allkeys-lru` to `allkeys-lfu`, which prevents popular keys from being evicted by recently-accessed but rarely-needed ones.