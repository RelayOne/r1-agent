# How tools reverse-engineer a repository's complete technology profile

**Every major repository analysis tool ultimately relies on the same fundamental insight: a repository's file structure, dependency manifests, configuration files, and git history encode a remarkably complete picture of its technology stack — no code execution required.** GitHub's Linguist classifies languages through an eight-stage cascade ending in Bayesian classification. SonarQube parses ASTs across 30+ languages to compute cognitive complexity and technical debt. Snyk and Mend build full transitive dependency graphs by invoking native package managers or parsing lockfiles. Service catalogs like Backstage still depend heavily on human-authored descriptors, though AI-powered discovery is emerging. Git history analysis can predict defect-prone files with **89% accuracy** using relative churn metrics alone. Together, these approaches form a comprehensive toolkit for auto-detecting a repository's complete technology profile through static analysis.

---

## GitHub Linguist's eight-stage classification cascade

GitHub's Linguist is the canonical open-source language detection engine, powering the language statistics bar on every GitHub repository. It determines each file's language by applying **eight strategies in strict order**, returning a result as soon as any strategy produces a single-language match.

The pipeline proceeds as follows: **modeline detection** (checking for vim/emacs editor declarations like `# vim: set ft=ruby`), **filename matching** (direct mappings like `Makefile` → Make), **shebang parsing** (`#!/usr/bin/env python3`), **file extension lookup** (the most common pathway, using `languages.yml` which defines **600+ languages**), **XML header detection**, **man page detection**, **heuristic disambiguation**, and finally **Naïve Bayesian classification** as the ultimate fallback.

The heuristics layer deserves particular attention. Defined in `heuristics.yml`, these are regex-based disambiguation rules for ambiguous extensions. The classic example is `.h` files: patterns like `@interface` or `#import .+\.h` trigger Objective-C classification, `#include <vector>` triggers C++, and plain C serves as the fallback. Rules support `pattern`, `negative_pattern`, `and` (all must match), and `named_pattern` (reusable references). Rules evaluate in order until one matches; if none does, the file falls through to the Bayesian classifier.

The **Bayesian classifier** in `classifier.rb` implements Naïve Bayes trained on curated sample files in the `samples/` directory. A **flex-based C tokenizer** processes the first 100KB of each file, stripping comments and string literals while preserving significant tokens — keywords, operators, structural punctuation. The classifier computes P(language | tokens) using token frequency tables built during training, returning languages ranked by posterior probability. Only the first **50KB** of content is analyzed for classification.

Before any language detection runs, Linguist pre-filters files. **Vendored code** (patterns in `vendor.yml` matching paths like `node_modules/`, `vendor/`), **generated code** (detected by `generated.rb` checking for filenames like `*.min.js`), and **documentation** (paths matching `docs/`, `documentation/`) are all excluded. Language percentages are calculated by **total bytes of code** per language, counting only programming and markup types. Developers can override everything via `.gitattributes` using attributes like `linguist-language=Java`, `linguist-vendored`, or `linguist-detectable`.

GitHub's **topic suggestion system** (repo-topix) uses a three-stage ML pipeline: extract candidate topics from README text via n-gram analysis with custom stop words, filter candidates through a **logistic regression model** trained on ~300 labeled examples, then rank survivors using **TF-IDF scores** computed against millions of public READMEs. A canonicalization step merges variant forms using edit distance and stemming.

**Dependabot** operates as a four-stage stateless pipeline processing **25+ package ecosystems**. Each ecosystem subclasses `FileFetchers::Base` and implements `fetch_files` to discover manifest files — npm's fetcher, for instance, reads `workspaces` from `package.json` and expands glob patterns via `recursive_find_directories`. The file parser extracts structured `Dependency` objects, the update checker queries registries for new versions (running native package manager tools in ecosystem-specific Docker containers), and the file updater generates PR content. In polyglot repos, each `package-ecosystem` entry in `.github/dependabot.yml` runs its own independent pipeline with separate file fetcher, parser, and updater.

---

## SonarQube's AST-driven quality analysis engine

SonarQube's language detection is deliberately simple: **pure file extension matching**. Each language analyzer plugin registers file suffixes it claims, and during the initial "Indexing files" phase, the scanner walks the project directory assigning each file to exactly one language. If two plugins claim the same extension, analysis fails with an explicit error. Extensions are configurable via `sonar.lang.patterns.<language>` properties, and only files recognized by installed language plugins are loaded.

The real sophistication lies in what happens after detection. Each language analyzer builds an **Abstract Syntax Tree** and a **semantic model** capturing types, symbol resolution, data flow, and control flow. Rules from the active Quality Profile execute against this model. SonarQube ships with **6,000+ pre-defined rules** across all languages, categorized by software quality (security, reliability, maintainability) and coding attributes.

**Cognitive Complexity**, developed by SonarSource's Ann Campbell, represents SonarQube's most distinctive metric contribution. Unlike cyclomatic complexity, it increments for each break in linear flow, **adds penalties for nesting depth** (a nested `if` inside a `for` costs more than a flat `if`), and ignores "shorthand" structures that aid readability. A `switch` statement costs +1 total rather than +1 per case. The default threshold is **15 per method**. Technical debt is computed as the sum of all maintainability issue remediation costs (each rule carries an assigned effort in minutes), with the Technical Debt Ratio expressing cost-to-fix divided by cost-to-develop.

SonarQube also performs **framework-aware analysis**. Spring-specific rules detect incorrect `@EventListener`, `@Scheduled`, and `@InitBinder` usage. React rules cover 48+ patterns including deprecated API usage and accessibility violations. The SAST engine understands native security controls in popular frameworks — it won't flag SQL injection when Django's ORM handles parameterization. This context awareness achieves a **3.2% overall false positive rate** across 137 million reviewed issues.

For multi-language projects, SonarQube assigns one quality profile per detected language and runs each language analyzer independently. Metrics aggregate at the project level. SonarCloud's **AutoScan** mode can analyze GitHub repositories without any CI configuration, triggered on each push to the default branch and PRs, though it lacks monorepo support and cannot import test coverage data.

---

## How dependency scanners build complete dependency graphs

### Snyk's ecosystem-aware resolution

Snyk supports **20+ language ecosystems** and uses different resolution strategies depending on context. The CLI's `--all-projects` flag triggers recursive discovery of all manifest files, with `--detection-depth=N` controlling search depth. For JavaScript, the `getMultiPluginResult` function processes workspaces in order — npm first, then yarn, then pnpm — using `micromatch` to determine which `package.json` files belong to workspace patterns.

**Lockfiles are always preferred** when present, as they provide deterministic dependency graphs. But resolution strategies diverge significantly by ecosystem: npm/Yarn/pnpm lockfiles are parsed directly, while **Maven and Gradle invoke the actual build tool** to resolve dependencies. Go uses `go list -json -deps ./...`. Python with Poetry requires both `pyproject.toml` and `poetry.lock`. This means SCM integrations (which parse statically) can produce different results than CLI scans (which run build tools) — a critical distinction for accuracy.

Snyk maintains a **proprietary vulnerability database** at security.snyk.io, claiming detection **47 days faster** than competing sources on average. The security team manually curates all entries, cross-referencing CVEs and GHSAs while using interval notation for semantic version ranges to express affected versions precisely.

### Socket.dev's behavioral deep package inspection

Socket.dev represents a fundamentally different approach: instead of matching packages against CVE databases, it **analyzes actual package behavior** through static analysis. A custom engine examines every package across entire ecosystems for network access (detecting `fetch()`, Node's `http`/`https` modules), filesystem operations, shell execution via `child_process`, environment variable reads (potential credential exfiltration), install scripts, and obfuscated code. Socket tracks **70+ red flags** including typosquatting (names 1-2 characters from popular packages with 1,000x fewer downloads), maintainer behavior anomalies, and dependency confusion patterns.

### Mend's dual-mode scanning architecture

Mend (formerly WhiteSource) employs two detection methods through its Unified Agent. **Dependency resolution** finds manifest files and runs native package manager commands — `mvn install` for Maven, `npm ls` for npm. **Filesystem scanning** uses SHA1 hash matching against Mend's Knowledge Base of **~340 million files across ~45 million open-source projects**. The newer **SmartMatch** algorithm uses ML to match source files to their origin libraries, though results are "best effort" requiring manual validation. Mend also acquired **Renovate** (the open-source dependency update bot) and supports archive extraction up to configurable depth for nested archives.

### Lockfile parsing across ecosystems

Each lockfile format encodes the dependency graph differently. `package-lock.json` (JSON, versions v1-v3) stores exact resolved versions with integrity hashes. `yarn.lock` uses a custom format in v1 and YAML in v2+. `Cargo.lock` uses TOML with `[[package]]` entries. Go's `go.sum` is technically a checksum database rather than a lockfile — Go's **Minimum Version Selection** algorithm provides deterministic resolution from `go.mod` alone. `Pipfile.lock` and `poetry.lock` store exact versions with hashes for both default and development dependency groups. When no lockfile exists, most tools re-resolve using application-install logic, assuming the latest satisfying version for each range — a significant source of potential inaccuracy.

---

## Service catalogs rely on descriptors, not detection

### Backstage's file-based entity discovery

Backstage's entity discovery is **fundamentally file-based**: it searches for `catalog-info.yaml` files across configured SCM providers. Discovery providers (GitHub, GitLab, Azure DevOps, Bitbucket) crawl organizations looking for these files at configurable paths, with support for branch filtering and repository name regex. The descriptor format uses a Kubernetes-like structure with `apiVersion`, `kind` (Component, API, Resource, System, Domain), `metadata` (name, annotations, tags), and `spec` (type, lifecycle, owner, dependencies).

Critically, **Backstage does not auto-detect** whether a repository contains a service versus a library. The `spec.type` field must be manually set. Ownership, dependencies, and consumed APIs are all declared explicitly. The platform's value lies in standardizing and aggregating this metadata, not in inferring it.

### Port's AI-powered catalog discovery

Port offers the most sophisticated auto-discovery through **AI-powered analysis** of existing catalog data. Users provide prompts with heuristic patterns — "services are represented as code in a repository; check file structure to identify services" or "repos with keywords like 'service', 'ms', 'srv' are likely services." The AI cross-references multiple data sources (Jira projects, Snyk projects, PagerDuty services) to suggest missing entities, which humans then review and approve. Port's **Blueprint** system allows completely custom entity schemas with typed properties and relations, unlike Backstage's fixed entity kinds.

### Cortex's Discovery Audit

Cortex features a **Discovery Audit** system that surfaces discrepancies between environments and the catalog: new repositories not yet registered, deleted repos still tracked, new Kubernetes deployments, new APM services in Datadog/New Relic. It pulls from 15+ sources including AWS, GCP, GitHub, GitLab, and observability platforms. For dependency discovery, Cortex can automatically sync dependencies from **Datadog's Service Map** — the most reliable approach since it captures actual runtime call graphs.

### What signals could indicate a deployable service

While current catalogs mostly rely on human declaration, several file-level signals could drive automated classification. A **deployable service** typically has a Dockerfile, Kubernetes manifests, serverless configs (`serverless.yml`, SAM `template.yaml`), CI/CD deploy steps, or health check endpoints. A **library** typically has package publishing configuration (`setup.py` with PyPI config, `*.gemspec`, `.nuspec`) but no Dockerfile or server/listener code. No widely adopted tool yet combines these signals into reliable automatic classification.

---

## Architectural pattern detection remains heuristic-driven

Detecting high-level architecture from code structure is achievable through file-level signals, though **no widely-adopted ML tool exists specifically for this task**. A practical system examines:

**Microservices indicators** include multiple Dockerfiles, `docker-compose.yml` with multiple application services, per-service Kubernetes manifests, separate package manifests, inter-process communication libraries (gRPC stubs, HTTP clients calling other services), service discovery clients (Eureka, Consul), circuit breaker patterns (Hystrix, Resilience4j), and distributed tracing instrumentation. **Monolith indicators** include a single Dockerfile, single build artifact, shared database configuration, and layered MVC package structure (`controllers/`, `services/`, `repositories/`).

**Event-driven architecture** reveals itself through message broker client libraries (kafka-clients, amqplib, boto3 SQS), handler annotations (`@KafkaListener`, `@RabbitListener`), event classes (`OrderCreatedEvent`), and CQRS patterns (separate command/query directories, MediatR/Axon configs). **GraphQL** is detectable via `.graphql` schema files, resolver implementations, and Apollo/graphql-yoga configurations, while REST shows up through OpenAPI specs, route annotations, and controller classes.

Academic research in this space focuses on **software architecture recovery**. A 2025 systematic comparison identified **13 static analysis tools** for microservice architecture recovery, including Prophet (analyzing source code for endpoints and connections), MicroMiner and MicroTom (recovering architecture from Kubernetes deployment files), and MicroGraal (using GraalVM native image for bytecode analysis). Commercial tools like **jQAssistant** store code structure in a Neo4j graph database enabling Cypher query-based architectural validation, while **Sonargraph-Architect** provides architecture DSL definition, cyclic dependency detection, and virtual refactoring simulation.

Emerging LLM-based approaches show promise: a 2025 paper proposes using reverse engineering combined with LLM-guided abstraction to generate Software Architecture Descriptions from source code, though context window limitations remain a challenge for large codebases.

---

## Git history predicts defects better than code metrics alone

The most powerful insight from git history analysis research is that **process metrics derived from version control outperform static code metrics** for predicting software quality. Nagappan and Ball's landmark ICSE 2005 study at Microsoft found that relative code churn measures — churned LOC / total LOC, deleted LOC / total LOC, files churned / total files — discriminated fault-prone from non-fault-prone binaries in Windows Server 2003 with **89% accuracy**, while absolute churn was a poor predictor.

**Hotspot analysis** combines change frequency with code complexity to identify the files most likely to harbor defects. Adam Tornhill's research (founder of CodeScene, author of "Your Code as a Crime Scene") demonstrates that software evolution follows a **power law** — most development activity concentrates in a small fraction of files. In Linux's `drivers/gpu`, the top hotspots comprised only **1.4% of code but attracted 15.9% of all commits**. CodeScene's Code Health metric (1-10 scale) aggregates 25+ code smells, and files with alert-level health (below 4) contain **15x more defects** and require **124% more development time** for issue resolution.

**Bus factor** calculation has been formalized through algorithms like CST (Cosentino et al., SANER 2015) and RIG (Rigby et al.). A study of 133 popular GitHub projects found **65% have a bus factor of 2 or fewer**. The CST algorithm computes developer knowledge via lines modified per file, identifying primary developers who modified at least 1/N of an artifact. The RIG algorithm uses git-blame to assign each line to its last modifier, then simulates removing contributors until 50% of files are orphaned.

**File coupling** (temporal/logical coupling) detects files that consistently change together in the same commits, revealing hidden architectural dependencies not visible in import statements. Bird et al. found that **fragmented ownership** — many low-expertise contributors to the same files — correlates strongly with pre-release faults in studies of Windows Vista and Windows 7.

Key tools in this space include **git-of-theseus** (survival analysis using Kaplan-Meier estimation, showing how lines from each commit cohort persist over time), **Hercules** (DAG-based analysis with incremental blame using custom Red-Black trees, producing burndown charts and developer churn/overwrites matrices), **gitinspector** (per-author contribution breakdown separating comments from code), and **code-maat** (Tornhill's CLI tool for temporal coupling and entity ownership analysis). CodeScene commercializes these concepts with ML-powered defect risk prediction for pull requests.

---

## Test coverage estimation without execution is qualitative, not quantitative

Detecting test infrastructure from file structure is straightforward: naming conventions are highly standardized (`*_test.go`, `test_*.py`, `*.spec.js`, `*Test.java`, `*_spec.rb`), test framework configs are identifiable (`jest.config.js`, `pytest.ini`, `phpunit.xml`, `.rspec`), and coverage tool configs signal measurement intent (`.nycrc`, `.coveragerc`, `codecov.yml`).

However, **no strong published research directly correlates test file count with actual code coverage percentage**. This is a significant gap. The fundamental problem is that a test file might cover 5% or 95% of its corresponding source — impossible to determine without execution. Empty or trivial tests, cross-cutting integration tests covering many source files, and dead test code all confound any file-based estimate.

A practical scoring system combines multiple signals with increasing confidence: test files matching source files (basic signal), test framework configuration present (testing is structured), coverage tool configuration present (coverage is measured), CI pipeline with test execution (tests actually run), and **coverage badge or threshold in CI** (coverage is tracked and enforced). The most reliable non-execution approach extracts actual percentages from Codecov or Coveralls badges, which often embed the number directly in README markdown. Test file presence serves best as a **qualitative indicator of testing practice maturity** rather than a quantitative proxy.

---

## Docker Compose files encode infrastructure architecture directly

Parsing `docker-compose.yml` provides one of the most reliable signals for infrastructure dependency detection. The distinction between application and infrastructure services follows a clear heuristic: **infrastructure services use well-known official images** (`postgres`, `redis`, `mongo`, `rabbitmq`) while **application services have a `build` context** pointing to a Dockerfile.

Image tags encode version information (`postgres:16.0-alpine`, `redis:7`, `mysql:8.0.32`). Volume mount paths reveal service types: `/var/lib/postgresql/data` means PostgreSQL, `/data/db` means MongoDB, `/var/lib/mysql` means MySQL. Port mappings follow standard conventions (5432 for PostgreSQL, 3306 for MySQL, 6379 for Redis, 9092 for Kafka, 5672/15672 for RabbitMQ AMQP/management). The `depends_on` key with conditions (`service_healthy`, `service_started`) explicitly declares service startup dependencies, while shared `networks` indicate which services can communicate.

The **compose-go** library (`github.com/compose-spec/compose-go`) serves as the official reference parser, used by Docker Compose itself. Visualization tools like **docker-compose-viz** generate dependency graphs showing `depends_on` relationships, port exposures, and network groupings. The `docker compose config --images` command extracts all image names, while `--services` lists service names — useful for automated analysis pipelines.

---

## Environment variables reveal third-party service dependencies

The `.env.example` file functions as a machine-readable manifest of external service dependencies. **DATABASE_URL schemes** directly identify database types: `postgresql://` for PostgreSQL, `mongodb+srv://` for MongoDB, `redis://` for Redis, `amqp://` for RabbitMQ. API key naming conventions map reliably to services: `STRIPE_KEY` means Stripe payments, `SENDGRID_API_KEY` means SendGrid email, `SENTRY_DSN` means Sentry error tracking, `TWILIO_AUTH_TOKEN` means Twilio communications.

Cloud provider detection follows prefix patterns: `AWS_*` variables (AWS_REGION, AWS_ACCESS_KEY_ID, AWS_S3_BUCKET) indicate Amazon Web Services, `GOOGLE_APPLICATION_CREDENTIALS` or `GCLOUD_PROJECT` indicate GCP, and `AZURE_*` variables indicate Azure. Authentication providers surface through `AUTH0_DOMAIN`, `GOOGLE_CLIENT_ID`, or `FIREBASE_*` variables. Structural patterns like `*_HOST`/`*_PORT` indicate network service dependencies, `*_URL` indicates full service endpoints, and `*_DSN` is common for monitoring services.

Within `docker-compose.yml` environment sections, variable values matching other service names (e.g., `DB_HOST=db` where `db` is a defined service) reveal implicit service-to-service dependencies. Official image environment variables like `POSTGRES_USER`, `MYSQL_ROOT_PASSWORD`, and `MONGO_INITDB_ROOT_USERNAME` confirm the infrastructure type and configuration. Framework-specific prefixes (`VITE_*`, `NEXT_PUBLIC_*`, `REACT_APP_*`) additionally reveal the frontend framework in use.

---

## CI/CD configs are the Rosetta Stone for build and deployment infrastructure

CI/CD configuration files may be the single richest source of technology stack information in a repository, encoding build tools, test frameworks, deployment targets, quality gates, and infrastructure dependencies in machine-parseable YAML.

**Build tool detection** maps directly from `run:` commands: `npm install`/`npm run build` indicates Node.js, `mvn package` indicates Maven, `cargo build` indicates Rust, `dotnet build` indicates .NET. **Deployment targets** surface through action names and CLI commands: `aws-actions/configure-aws-credentials` or `aws ecs` commands indicate AWS, `kubectl apply` or `helm upgrade` indicate Kubernetes, and `vercel --prod` indicates Vercel. **Quality gates** reveal the project's engineering practices: `eslint`/`prettier` for linting, `snyk`/`trivy`/`CodeQL` for security scanning, `codecov`/`coveralls` for coverage tracking, and `tsc --noEmit`/`mypy` for type checking.

GitHub Actions `services:` keys and GitLab CI `services:` keys directly declare infrastructure dependencies — a job with `services: { postgres: { image: postgres:14 } }` unambiguously requires PostgreSQL for testing. CircleCI's **orb** names (e.g., `circleci/aws-cli@4.0`) explicitly declare tooling dependencies. Environment and deployment stage information emerges from branch conditions (`if: github.ref == 'refs/heads/main'`), environment keys on jobs, and the presence of separate workflow files for staging versus production.

The **actionlint** tool (`rhysd/actionlint`) provides the most sophisticated GitHub Actions parsing, offering a Go API that returns typed AST nodes (Workflow → Job → Step). CircleCI publishes an official **TypeScript config parser** (`@circleci/circleci-config-parser`) with `parseConfig()`, `parseJob()`, and `parseOrbManifest()` methods. For cross-platform analysis, the general approach parses YAML into data structures, applies schema-specific knowledge, extracts triggers/jobs/steps/service containers, then pattern-matches commands against known tools and services.

---

## Conclusion: toward complete automated technology profiling

The tools and techniques surveyed here collectively demonstrate that a repository's technology profile is **largely recoverable through static analysis** of its file structure, dependency manifests, configuration files, and version control history. The most mature detection systems — Linguist for languages, Snyk/Mend for dependencies, SonarQube for code quality — combine multiple strategies (extension matching, content heuristics, Bayesian classification, build tool invocation) to handle ambiguity and polyglot complexity.

Three areas remain underdeveloped. **Architectural pattern detection** lacks a widely-adopted automated tool, relying instead on heuristic file-pattern matching. **Service catalog auto-discovery** still depends primarily on human-authored descriptors, though Port's AI-powered approach hints at the future. And **test coverage estimation** without execution remains qualitative rather than quantitative, with no published research validating file-count-to-coverage correlations.

The most actionable insight for building a comprehensive repository analysis system is that **different artifact types excel at revealing different aspects**: Linguist-style analysis detects languages, manifest/lockfile parsing reveals dependencies, Docker Compose and environment files expose infrastructure, CI/CD configs encode build and deployment pipelines, and git history predicts quality and organizational health. A complete technology profiling system must orchestrate all these analyses in concert, combining their signals into a unified picture that no single approach could produce alone.