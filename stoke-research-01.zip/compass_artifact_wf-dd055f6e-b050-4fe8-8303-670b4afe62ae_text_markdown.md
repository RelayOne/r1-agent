# Open source AI coding agent security: a complete landscape map

**The ecosystem of security enforcement tools for AI coding agents has exploded in 2025–2026, with Trail of Bits publishing 40+ security plugins, OWASP launching two dedicated agent security top-10 lists, and Snyk building a scanner that found 36% of public agent skills contain prompt-injection techniques.** This matters because AI-generated code is **2.74× more likely** to contain vulnerabilities than human-written code, and AI-assisted commits leak secrets at **twice the baseline rate**. For a polyglot monorepo handling payments, PII, and multi-tenant data, layering these tools into a defense-in-depth pipeline is no longer optional — it's the minimum viable security posture. What follows is a complete inventory of every significant open source tool, skill file, and enforcement pattern available today.

---

## Trail of Bits built the most comprehensive security skills library

Trail of Bits operates the largest open source collection of security-focused AI coding agent skills, hosted at **github.com/trailofbits/skills** (3,300+ stars, CC-BY-SA-4.0). Internally, the company runs **94 plugins, 201 skills, and 84 specialized agents** — their AI-augmented auditors find **200 bugs per week** on active engagements. The public marketplace contains roughly 40 plugins, with ~25 focused on security.

The skills that matter most for a payments/PII monorepo fall into several categories. **insecure-defaults** detects hardcoded credentials, weak crypto (MD5, SHA1, DES, RC4, ECB mode), fail-open patterns, `DEBUG=true`, `AUTH=false`, and permissive CORS — classifying each as either CRITICAL (fail-open) or SAFE (fail-secure). **constant-time-analysis** detects compiler-induced timing side-channels in cryptographic code across C, Go, Rust, TypeScript, and Python — it has already found a real timing side-channel in ML-DSA signing in the RustCrypto library. **supply-chain-risk-auditor** audits dependency threat landscapes, while **static-analysis** integrates CodeQL, Semgrep, and SARIF parsing into a unified workflow.

The **fp-check** skill deserves special attention for payment-critical systems. It deploys three specialized subagents in parallel — a data-flow analyzer (trust boundaries, API contracts), an exploitability verifier (attacker control proofs, mathematical bounds), and a PoC builder — with mandatory gate reviews at each phase and Stop hooks that block premature completion. This dramatically reduces false positives in security analysis.

Trail of Bits' **dimensional-analysis** plugin represents a fundamentally different approach: rather than asking the LLM to "find bugs," it uses the LLM as a vocabulary-building machine to annotate code with dimensional types, then detects mismatches mechanically. This achieved **93% recall vs. 50% for baseline prompts**, specifically because it avoids over-relying on LLM judgment.

Each skill follows a structured plugin format with `SKILL.md` entry points (under 2,000 words), `references/` directories for detailed checklists and vulnerability patterns, and `hooks/` for event-driven enforcement. Skills auto-activate based on context and support both Claude Code (via plugin marketplace) and OpenAI Codex (via `.codex/skills/` sidecar). Additional repositories include **trailofbits/skills-curated** (vetted third-party plugins), **trailofbits/claude-code-config** (opinionated security defaults), and **trailofbits/dropkit** (sandbox tooling for agent environments).

Key security plugins from the full inventory:

- **agentic-actions-auditor** — audits GitHub Actions workflows for AI agent integration vulnerabilities across 9 categories
- **differential-review** — security-focused code review of diffs with git history analysis
- **fix-review** — verifies fix commits address audit findings without introducing regressions
- **semgrep-rule-creator** and **semgrep-rule-variant-creator** — create and port custom vulnerability detection rules
- **sharp-edges** — identifies error-prone APIs, dangerous configurations, and footgun designs
- **variant-analysis** — finds similar vulnerabilities across codebases using pattern-based search
- **testing-handbook-skills** — generates 16 skills from their Application Security Testing Handbook covering fuzzing, sanitizers, coverage analysis, and static analysis tooling
- **zeroize-audit** — detects missing or compiler-eliminated zeroization of secrets in memory (C/C++ and Rust)

---

## Anthropic's security review action uses multi-agent false-positive filtering

The **anthropics/claude-code-security-review** GitHub Action (~3.2k stars) provides automated security review of pull requests through a four-stage pipeline: PR diff analysis, contextual code review using repository exploration tools, finding generation with severity ratings, and multi-stage false-positive filtering. It defaults to **Claude Opus 4.1** and processes only changed files, not the entire codebase.

The false-positive filtering is the action's key innovation. It uses a confidence scoring system from 1–10, surfacing **only findings with confidence ≥ 8**. Hard exclusions automatically filter DoS vulnerabilities, rate-limiting concerns, and memory exhaustion issues. Framework-aware filtering recognizes that React and Angular are generally safe against XSS unless using `dangerouslySetInnerHTML` or `bypassSecurityTrustHtml`. The built-in `/security-review` slash command uses a three-step multi-agent approach: a subtask identifies vulnerabilities, parallel subtasks attempt to disprove each finding (adversarial verification), and anything below confidence 8 is dropped.

The action catches injection attacks (SQL, command, LDAP, NoSQL, XXE), broken authentication and privilege escalation, hardcoded secrets and PII handling violations, weak cryptography, missing input validation, race conditions, TOCTOU issues, and insecure configuration defaults. Real-world deployment at Deriv across 700+ repositories (100+ PRs/week) caught XSS through unsanitized input, debug mode left in production, applications binding to 0.0.0.0, and race conditions in async operations.

Setup requires a single workflow file with `anthropics/claude-code-security-review@main`, an Anthropic API key, and `pull-requests: write` permissions. Configuration inputs include `exclude-directories`, `claudecode-timeout` (default 20 minutes), `false-positive-filtering-instructions` (path to a custom file), and `scanning-instructions`. The repo includes an evaluation framework for testing against specific PRs.

**Critical limitations**: The README explicitly warns it is **not hardened against prompt injection** and should only review trusted PRs. Large PRs can cause silent 406 failures. Token limits can prevent completion. Each review consumes API tokens at scale. It performs static analysis only — no runtime testing, no business logic validation, and probabilistic inference means hallucinated findings are possible.

---

## Snyk's agent-scan creates a new category of supply-chain security

**Snyk agent-scan** (github.com/snyk/agent-scan, 2.1k stars) is an open source scanner purpose-built for AI agent supply chains — scanning not code but the natural-language instructions, tool configurations, and MCP server definitions that power autonomous agents. Built on research from Invariant Labs (acquired by Snyk in June 2025, spun out of ETH Zurich), it represents a fundamentally different scanning paradigm from traditional Snyk products.

The tool auto-discovers agent configurations across Claude Code/Desktop, Cursor, Gemini CLI, Windsurf, and VS Code. For MCP servers, it connects and retrieves tool descriptions, then validates components using a **dual analysis engine** combining calibrated LLM-based judges with deterministic rules. This hybrid approach is essential because agent skills are hybrid artifacts requiring both traditional code analysis and natural-language understanding.

It scans for **15+ distinct risk categories**. For MCP servers: prompt injection (hidden instructions in tool descriptions), tool poisoning (malicious tool definitions), tool shadowing (impersonation of legitimate tools), and **toxic flows** — dangerous combinations where individually safe tools chain together to create attack paths (e.g., a file-reading tool plus an HTTP-request tool enables exfiltration). For skills specifically: prompt injection in obfuscated formats (base64, Unicode), malicious code (backdoors, RCE, credential theft), suspicious downloads from untrusted domains, improper credential handling, hardcoded secrets, third-party content exposure, unverifiable dependencies (`curl | bash` patterns), direct financial account access, and system service modification.

Performance is remarkable: CRITICAL-level detectors achieve **90–100% recall** on confirmed malicious skills while maintaining **0% false positive rate** on the top 100 legitimate skills. Snyk's ToxicSkills research scanned 3,984 skills from the ClawHub marketplace and found **36% contained prompt-injection techniques**. Among confirmed malicious skills, **100% combined malicious code payloads with prompt injection**. Three lines of markdown in a SKILL.md file were sufficient to instruct an agent to read SSH keys and exfiltrate them.

This differs fundamentally from traditional Snyk scanning. Traditional Snyk matches code against known CVE databases; agent-scan analyzes the behavioral intent of natural-language instructions. Traditional Snyk targets libraries and containers; agent-scan targets MCP servers and skill files. Traditional Snyk follows deterministic code paths; agent-scan identifies emergent risks from tool chaining that only manifest during autonomous operation.

---

## OWASP now has two dedicated top-10 lists for agent security

The OWASP landscape for AI agent security has matured rapidly into multiple official projects. The **OWASP Agentic Skills Top 10 (AST10)** covers skill-level risks: malicious skills, supply-chain compromise, identity file protection (SOUL.md, MEMORY.md, AGENTS.md), insecure metadata, unsafe deserialization of YAML/JSON skill files, weak isolation, registry scanning, provenance, audit logging, and trust prompts. Separately, the **OWASP Top 10 for Agentic Applications 2026 (ASI01–ASI10)** covers application-level risks: prompt injection/goal hijacking, tool misuse, identity/privilege abuse, agentic supply chain vulnerabilities, unexpected code execution, memory/context poisoning, insecure inter-agent communication, cascading failures, human trust exploitation, and rogue agent behavior.

Several open source projects translate these into enforceable agent rules. **agamm/claude-code-owasp** provides a Claude Code skill with OWASP Top 10:2025 quick reference, security code review checklists, secure/unsafe code patterns, language-specific security quirks for 20+ languages (including Go, Rust, and TypeScript), and the full ASVS 5.0 requirements. **Microsoft's agent-governance-toolkit** maps all ASI-01 through ASI-10 with deterministic policy enforcement (<0.1ms latency), zero-trust agent identity (Ed25519, SPIFFE/SVID), an MCP security scanner, and multi-language support including Go, TypeScript, and Rust — backed by 9,500+ tests. **HeadyZhang/agent-audit** provides 53 static analysis rules mapped to OWASP Agentic Top 10 with Python AST analysis, taint tracking, and MCP config scanning. **Agent-Threat-Rule/agent-threat-rules** offers 71 YAML-based detection rules across 9 categories (like Sigma rules but for AI agent threats), mapping to 10/10 OWASP Agentic Top 10 items with specific CVE references.

---

## Security skill files exist across every major AI coding agent

The ecosystem of security-focused SKILL.md and rules files has grown substantially across all major platforms. Here are the most significant for a payments/PII/multi-tenant use case:

**BehiSecc/VibeSec-Skill** (741 stars) is the most comprehensive cross-platform security skill, supporting Claude Code, Cursor, Codex, Copilot, and Gemini. It covers IDOR, privilege escalation, XSS (stored, reflected, DOM), CSRF, SSRF, SQL injection, XXE, path traversal, authentication weaknesses, JWT security, and security headers — with bypass techniques and edge cases (URL fragments, DNS rebinding, polyglot files, Unicode tricks) that most other skills miss.

**getsentry/skills** provides Sentry's production-grade security review skill with HIGH-CONFIDENCE-only detection, reference files for injection (SQL, NoSQL, OS command, LDAP, template), XSS, authorization, authentication, cryptography, deserialization, and file security — with context-aware false-positive filtering (MD5 for caching is safe; MD5 for passwords is flagged).

**Bikach/skills-claude-code/security-guardian** covers 8 security domains directly relevant to payment systems: authentication/authorization, injection prevention, cryptography (secure random generation), secrets management (vault integration, key rotation), input validation, API security (rate limiting, CORS, GraphQL), data protection (PII management, GDPR compliance, encryption, secure deletion), and logging/monitoring (audit trails without sensitive data).

**Robotti-io/copilot-security-instructions** provides customizable rulesets for GitHub Copilot's `.github/copilot-instructions.md` with custom security agents for Application Security Orchestration. **Hack23** maintains `.github/copilot-instructions.md` files with 41 security skills including ISMS compliance (ISO 27001, NIST CSF 2.0, CIS Controls), threat modeling (STRIDE), and MCP gateway security patterns. **prompt-security/clawsec** provides a complete security skill suite including live NVD CVE feed, vulnerability scanner, SOUL.md drift detection, and signed releases with SBOM.

**Eyadkelleh/awesome-claude-skills-security** integrates SecLists into Claude Code with 7 installable skills: security-fuzzing (SQL injection, command injection, auth bypass payloads), security-passwords (common credential lists), security-patterns (API key detection, credit card formats, SSN matching), security-payloads (XSS vectors, XXE payloads, template injection), security-usernames (default accounts), security-webshells (PHP/ASP samples for detection), and llm-testing (AI security testing methodologies).

---

## AI coding agents introduce five distinct vulnerability classes

Research from 2022–2026 has identified five distinct categories of security vulnerabilities that AI coding agents specifically introduce or amplify.

**Prompt injection in MCP is the most severe architectural risk.** Invariant Labs discovered Tool Poisoning Attacks where malicious instructions embedded in MCP tool descriptions inside `<IMPORTANT>` tags are invisible to users but visible to AI models — demonstrated against Cursor, Anthropic clients, and OpenAI. CyberArk Labs extended this to "Full-Schema Poisoning" across function names, parameter types, and default values, plus "Advanced Tool Poisoning Attacks" that embed instructions in tool outputs (error messages). The MCPTox benchmark tested 20 LLM agents against 1,312 malicious test cases and found **o1-mini had a 72.8% attack success rate** — with more capable models being MORE susceptible because the attack exploits superior instruction-following. Elastic Security Labs documented rug-pull attacks (silently altering tool behavior after user approval) and demonstrated that a malicious "daily_quote" tool can secretly instruct the model to add hidden 0.5% fees to all payments processed by a separate legitimate tool.

**Secrets leaking has reached epidemic proportions.** GitGuardian's 2026 report found **28.65 million** new hardcoded secrets in public GitHub commits in 2025 — a 34% year-over-year jump. AI-assisted commits leaked secrets at a **3.2% rate vs. 1.5% baseline**. Critically, **24,008 unique secrets** were found specifically in MCP configuration files (`.cursor/mcp.json`, `claude_desktop_config.json`), with 2,117 confirmed as live credentials. Wiz Research found that MCP servers — including the official GitHub MCP server — pervasively recommend hardcoded credentials in configuration examples. Apiiro's analysis of Fortune 50 enterprises showed AI-generated code had a **40% increase in secrets exposure**, with Azure Service Principals exposed nearly twice as often.

**Insecure code generation is well-documented across multiple studies.** The seminal Pearce et al. study (IEEE S&P 2022) found **~40% of Copilot-generated code was vulnerable** across 89 CWE scenarios. Perry et al. (ACM CCS 2023, Stanford) conducted the first user study and found AI-assisted developers wrote **significantly less secure code** while being **more confident** it was secure — only 3% of AI-assisted participants wrote secure cryptographic solutions vs. 21% of the control group. Veracode's 2025 report testing 100+ LLMs found **45% of AI-generated code** contained OWASP Top 10 vulnerabilities, with an **86% XSS failure rate** and **88% path traversal insecure generation rate**.

**Slopsquatting — AI hallucinating fake package names — creates exploitable supply chain entry points.** Spracklen et al. (USENIX Security 2025) tested 16 LLMs generating 576,000 code samples and found an **average 19.7% of recommended packages were non-existent**. Of these hallucinated names, 43% appeared every single time the same prompt was re-run, making them systematically predictable targets for attackers to register as malicious packages.

**IDE-level vulnerabilities affect 100% of tested AI coding tools.** The IDEsaster research (December 2025) uncovered **30+ vulnerabilities** across 10+ products, resulting in **24 assigned CVEs**. Notable: CVE-2025-53773 (GitHub Copilot command injection, CVSS 7.8), CVE-2025-54135 "CurXecute" (Cursor untrusted MCP remote code execution, CVSS 8.6), and CVE-2025-54136 "MCPoison" (Cursor post-approval MCP config modification enabling silent RCE). Georgia Tech's Vibe Security Radar has tracked **74 CVEs attributable to AI-authored code** in public vulnerability databases as of March 2026.

---

## IronClaw provides a secure agent runtime with 13-step enforcement

IronClaw (github.com/nearai/ironclaw, 8.5k stars) is an open source, Rust-based secure AI agent runtime by NEAR AI. No specific repository named "ironclaw-agent-guard" exists as a standalone tool — IronClaw itself IS the guard, with security embedded into every layer of its architecture.

Every agent action passes through a **13-step security pipeline**: Command Guardian (45+ validation patterns), RBAC policy enforcement, sandbox enforcement, audit logging, DLP engine, anti-stealer detection, SSRF protection, network policy enforcement, credential scanning, leak detection, rate limiting, resource limits, and session authentication. Tools run in **WebAssembly sandboxes** with capability-based permissions (zero default access), credentials are stored with **AES-256-GCM encryption** and injected only at the network boundary for explicitly allowlisted endpoints, and all HTTP requests are restricted to approved hosts. An **iron-verify** static analysis tool checks skills for capability over-requests, SQL injection, command injection, and path traversal — flagging 23 of 25 problematic skills in testing.

IronClaw and Snyk agent-scan are complementary: agent-scan performs pre-deployment static analysis of skills and MCP servers, while IronClaw enforces security at runtime through architectural isolation.

---

## Building a DevSecOps pipeline for your polyglot monorepo

For a Go/Rust/TypeScript monorepo handling payments, PII, and multi-tenant data, the emerging consensus is a **four-layer defense strategy** with AI-specific gates layered on top of traditional CI/CD.

**Layer 1 — IDE boundary enforcement.** Install security-focused SKILL.md files (VibeSec-Skill, Trail of Bits insecure-defaults, Sentry security-review). Add a `.cursorrules` or `CLAUDE.md` file with OpenSSF-recommended instructions: never include secrets in output, always use parameterized queries, validate all function arguments, use constant-time comparison for security tokens, avoid logging PII, specify exact dependency versions. Use Cycode AI Guardrails or Legit Security VibeGuard to intercept secrets in prompts and file reads at the IDE boundary.

**Layer 2 — Pre-commit hooks.** Run Gitleaks for secret scanning, language-specific security linters (`gosec` for Go, `cargo clippy` + `cargo audit` for Rust, `eslint-plugin-security` for TypeScript), and PII detection. Run Snyk agent-scan against any SKILL.md or MCP configuration files being committed.

**Layer 3 — CI pipeline with AI-specific gates.** Beyond traditional SAST/SCA, add five AI-specific gates:

1. **Hallucinated dependency verification** — check every new dependency against an approved allowlist; any AI-suggested package not on the list blocks the build pending manual review
2. **AI-specific SAST rules** — custom Semgrep rules for patterns AI commonly generates: hardcoded example credentials, missing parameterized queries, overly permissive CORS, missing input validation on forms, direct SQL concatenation in payment code, database queries without tenant context extraction, PII in log statements
3. **Tiered review routing** — use CODEOWNERS to require `@security-team` approval for `services/payments/`, `services/auth/`, and `services/pii-handler/`; consider prohibiting AI-generated code entirely in these modules or requiring mandatory security lead sign-off
4. **Policy-as-code enforcement** — use OPA/Rego policies to block changes to payment/auth modules without security team approval, reject new unapproved dependencies, and enforce AI contribution percentage thresholds
5. **AI-powered security review** — deploy `anthropics/claude-code-security-review` for semantic analysis that catches context-dependent vulnerabilities pattern-matching tools miss, but treat it as complementary to deterministic scanners, not a replacement

**Layer 4 — Production runtime monitoring.** Deploy Application Detection and Response for runtime exploit detection, monitor for credential leaks in logs and outputs, and run anomaly detection for cross-tenant data access patterns.

A practical Semgrep rule for your tenant isolation requirements:

```yaml
- id: tenant-missing-context
  pattern: |
    func $FUNC($REQ http.Request, ...) {
      ...
      $DB.Query(...)
      ...
    }
  pattern-not: |
    func $FUNC($REQ http.Request, ...) {
      ...
      tenantID
      ...
      $DB.Query(...)
      ...
    }
  message: "Database query without tenant context. Risk of cross-tenant data leak."
  severity: ERROR
  languages: [go]
  paths:
    include: ["services/"]
```

---

## Conclusion: what to install this week

The landscape is rich but fragmented. For immediate impact on a polyglot payments monorepo, prioritize in this order. **First**, install Trail of Bits' `insecure-defaults`, `supply-chain-risk-auditor`, and `static-analysis` skills — they provide the highest security coverage with the least configuration. **Second**, deploy `anthropics/claude-code-security-review` as a GitHub Action on all PRs, with custom `false-positive-filtering-instructions` that account for your payment and PII context. **Third**, run `snyk-agent-scan --skills` against your developer machines to audit every MCP server and skill already installed — the 36% malicious skill rate on public marketplaces means you almost certainly have exposure. **Fourth**, add the VibeSec-Skill and agamm/claude-code-owasp skills to every developer's agent configuration for continuous OWASP enforcement during code generation. **Fifth**, write custom Semgrep rules for your three highest-risk patterns: tenant isolation bypass, PII logging, and payment idempotency enforcement.

The overconfidence finding from Stanford — developers using AI assistants write less secure code while believing it's more secure — is the most dangerous dynamic in this entire space. No tool stack eliminates this risk. The tools above make it manageable, but mandatory human security review of AI-generated code in sensitive modules remains non-negotiable.