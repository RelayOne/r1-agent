# Claude Code's `--allowedTools` is not a true whitelist

**The most critical finding: `--allowedTools` controls permission auto-approval, not tool availability.** Claude still "sees" and may attempt to call tools absent from the list, wasting turns or bypassing restrictions entirely. The reliable mechanism for restricting tools is `--disallowedTools`, which removes tools from the model's context. This distinction—confirmed in official documentation and multiple open GitHub bugs—fundamentally shapes how read-only agentic workflows must be designed with Claude Code.

## 1. Accepting a restricted set like `"Read,Glob,Grep"` — it won't error, but it won't truly restrict either

The CLI accepts `--allowedTools "Read,Glob,Grep"` without erroring at startup. The flag takes a **comma-separated string** of PascalCase tool names. In the TypeScript SDK, it's a JSON array (`allowedTools: ["Read", "Glob", "Grep"]`); in Python SDK, a Python list (`allowed_tools=["Read", "Grep", "Glob"]`); and in `settings.json`, a JSON array.

However, excluding Write, Edit, MultiEdit, and Bash from the allowedTools list does **not** prevent Claude from calling them. The official SDK permissions documentation states explicitly: **"`allowed_tools` and `disallowed_tools` control whether a tool call is approved, not whether the tool is available to Claude."** GitHub Issue #12232 (labeled `bug`, `area:security`, still open) demonstrated this concretely:

```bash
# allowedTools IGNORED — Bash executes despite whitelist specifying only Read
claude --verbose -p "get my public ip from curl ifconfig.me" \
  --allowedTools Read --permission-mode bypassPermissions
# Output: 1.2.3.4 (Bash executed)

# disallowedTools WORKS — Bash actually blocked
claude --verbose -p "get my public ip from curl ifconfig.me" \
  --disallowedTools Bash --permission-mode bypassPermissions
# Output: "I don't have access to execute bash commands..."
```

The only confirmed way to make `allowedTools` function as a true whitelist is pairing it with **`permissionMode: "dontAsk"`** (TypeScript SDK only, not yet available in Python). In this mode, listed tools are approved and everything else is denied outright without prompting. In Python, Claude will still attempt unlisted tools, receive a rejection, and waste a turn discovering the restriction.

**For reliable read-only restriction, use `--disallowedTools` to explicitly blacklist Write, Edit, MultiEdit, Bash, NotebookEdit, TodoWrite, and any other write-capable tools.** This removes them from the model's context entirely.

## 2. When Claude's reasoning wants a disallowed tool, behavior depends on *how* it was disallowed

Three distinct behaviors exist depending on the restriction mechanism:

**If the tool was removed via `--disallowedTools`:** The tool is stripped from Claude's context entirely. Claude never sees it, never attempts it, and naturally uses available alternatives. When Bash is disallowed this way, Claude responds with messages like "I don't have access to execute bash commands" and routes grep operations through the built-in Grep tool. **This is the cleanest behavior — option (a), silent fallback to allowed alternatives.**

**If the tool was excluded from `--allowedTools` without `dontAsk` mode:** Claude still knows the tool exists and may attempt to call it. The system returns a permission error (`"This command requires approval"` or `"The user doesn't want to proceed with this tool use"`) as an `is_error: true` tool result. Claude receives this error, then typically retries with an allowed tool. **This is option (b), report an error and continue — but it wastes turns and tokens.** The official docs acknowledge: "Claude may still attempt to call tools not in `allowed_tools`. The call is rejected at runtime, but Claude wastes a turn discovering this."

**If using `allowedTools` with `permissionMode: "dontAsk"` (TypeScript SDK only):** Unlisted tools are denied outright without prompting. Claude receives a denial and adapts. **This is a cleaner version of option (b).**

Claude Code does **not crash or halt the session** when encountering a disallowed tool — option (c) does not occur. The session continues regardless of which restriction mechanism triggers.

Notably, GitHub Issue #1386 documents that Claude sometimes prefers running `grep` or `rg` via Bash over using the built-in Grep tool. The system prompt explicitly instructs: **"You MUST avoid using search commands like find and grep. Instead use Grep, Glob, or Task to search."** When Bash is properly disallowed, this preference is moot because Claude falls back to the built-in tools.

## 3. Built-in Grep is a full ripgrep wrapper; Bash grep offers more flexibility but less safety

The built-in **Grep tool is powered by ripgrep** and exposes most of its core functionality through structured parameters rather than raw command-line flags. Here is a direct comparison:

| Capability | Built-in Grep | Bash `grep`/`rg` |
|---|---|---|
| **Regex patterns** | ✅ Full regex (`log.*Error`, `function\s+\w+`) | ✅ Full regex |
| **Multi-file search** | ✅ Recursive by default across directories | ✅ With `-r` flag |
| **Context lines (-A/-B/-C)** | ✅ Supported (requires `output_mode: "content"`) | ✅ Native flags |
| **Case-insensitive** | ✅ Via `-i` parameter | ✅ Via `-i` flag |
| **Line numbers** | ✅ Via `-n` parameter | ✅ Via `-n` flag |
| **Multiline matching** | ✅ Via `multiline: true` | ✅ Via `--multiline` |
| **File type filtering** | ✅ Via `type` param (js, py, rust, etc.) | ✅ Via `--type` |
| **Glob file filtering** | ✅ Via `glob` param | ✅ Via `--glob` |
| **Output modes** | Three modes: `files_with_matches` (default), `content`, `count` | Full flexibility |
| **Piping/chaining** | ❌ No pipe support | ✅ Full pipe support |
| **Complex flag combinations** | Limited to exposed parameters | ✅ Arbitrary flags |
| **Permission requirements** | Auto-approved (read-only) | Requires Bash permission |

The built-in Grep tool's default output mode is `files_with_matches` (returns only file paths), which is token-efficient for discovery. The `content` mode with context flags (`-A`, `-B`, `-C`) returns matching lines with surrounding context, closely matching what `grep -C` does via Bash. The main functional gap is **pipe chaining** — you cannot pipe Grep output into `sort`, `uniq`, `wc`, or other utilities. For pure code search, the built-in tool covers **>95% of practical use cases**.

## 4. Multiple GitHub issues document confusion and degradation with restricted tool sets

Several GitHub issues and community reports document problems when tools are restricted:

**Bug: `--allowedTools` silently ignored (Issue #12232, open).** The most security-critical issue. In `bypassPermissions` mode, `--allowedTools` has no effect — Claude executes any tool freely. A user building a CI/CD code review agent noted: "Without working `allowed_tools`, Claude could execute `Bash(rm -rf *)` in automated context." This is labeled `bug` + `area:security`.

**Bug: SDK `allowedTools` doesn't restrict built-in tools (SDK Issue #115, closed).** A developer building a read-only code exploration tool (Datost) reported that `allowedTools: ["Read", "Glob", "Grep"]` with `bypassPermissions` still allowed Claude to use Edit to modify files. This was eventually addressed.

**Bug: `--allowedTools` unreliable in non-interactive mode (Issue #563).** Claude can use Edit in simple prompts but fails in complex prompts with the same `--allowedTools` specification, reporting it "needs permissions" inconsistently.

**Bug: Subagents can bypass tool restrictions (Issue #4740).** Subagents spawned by Claude Code can use tools even when none are permitted in their configuration.

**Bug: Plan mode bypassed by LLM (Issue #13638).** Plan mode's read-only restrictions can be circumvented — the LLM can call Bash/Edit directly despite the intended read-only constraint.

**Feature gap: SDK ignores Skill frontmatter `allowed-tools` (Issue #18737).** A developer creating Skills with strict `allowed-tools` restrictions found these are only enforced in CLI, not SDK, creating a false sense of security.

No reports were found of Claude producing significantly *worse analytical results* when write tools are removed. The degradation is primarily operational — wasted turns, inconsistent enforcement, and security bypasses — rather than reduced reasoning quality.

## 5. Removing Bash has minimal impact on discovery; Glob fully supports recursive patterns

**Glob supports `**/*.ts` and other recursive patterns.** The tool accepts standard glob syntax: `*` (single directory level), **`**` (recursive across directories)**, `?` (single character), `{a,b}` (alternation), `[abc]` (character classes), and `[!abc]` (negation). Practical examples from official documentation include `**/*.js`, `src/**/*.{ts,tsx}`, and `test/**/*.[jt]s`. Results are returned as **flat file path lists sorted by modification time** (most recent first), not directory trees. For directory structure visualization, the `LS` tool lists directory contents at a single level.

**Removing Bash causes minimal degradation for codebase discovery** when Glob, Grep, Read, and LS remain available. Claude Code's architecture already treats Glob and Grep as the primary discovery layer — they return paths and matched lines without loading full files, serving as the lightweight "search" phase before Read provides the "confirm" phase. The built-in Explore subagent (a read-only specialist spawned for deep code exploration) operates with exactly this pattern: Glob, Grep, Read, and only limited Bash.

The specific capabilities lost by removing Bash are:

- **Git operations**: `git log`, `git diff`, `git status`, `git blame` — significant for understanding change history
- **Complex file discovery**: `find` with predicates like `-mtime`, `-size`, `-newer`
- **Output processing**: `wc -l`, `sort`, `head`, `tail`, piping and chaining
- **Runtime inspection**: Process listing, environment variable reading, port checking
- **Build/test execution**: Cannot run tests, linters, or build commands

For pure **static code analysis and exploration**, the built-in tools are sufficient. For workflows requiring change history, runtime state, or build validation, Bash removal is more impactful. A practical compromise is allowing specific Bash commands via specifiers: `Bash(git log:*)`, `Bash(git diff:*)`, `Bash(git status:*)`.

## 6. Exact syntax, case sensitivity, and the complete tool name inventory

**CLI syntax:** `--allowedTools "Read,Glob,Grep"` (comma-separated, quoted string). The companion flag is `--disallowedTools` with identical syntax. A newer `--tools` flag exists for interactive sessions.

**Tool names are case-sensitive.** The official hooks documentation confirms: "matcher: Pattern to match tool names, **case-sensitive**." All tool names use PascalCase consistently across documentation, SDK types, and examples.

**Complete known tool name strings:**

| Category | Tool Names |
|---|---|
| **File operations** | `Read`, `Write`, `Edit`, `MultiEdit`, `NotebookEdit`, `NotebookRead` |
| **Search/discovery** | `Glob`, `Grep`, `LS` |
| **Execution** | `Bash`, `BashOutput`, `KillShell` |
| **Agent/task management** | `Task` (alias: `Agent`), `TaskOutput`, `TaskStop` |
| **Web** | `WebFetch`, `WebSearch` |
| **Planning/tracking** | `TodoWrite`, `TodoRead`, `ExitPlanMode` |
| **User interaction** | `AskUserQuestion`, `Config` |
| **MCP tools** | `mcp__<server>__<tool_name>` (wildcard: `mcp__server__*`) |
| **IDE-specific** | `getDiagnostics`, `executeCode` |

**Specifier syntax** enables granular Bash control: `Bash(git:*)` allows any git command, `Bash(npm run test)` allows a specific command, `Bash(npm run test *)` allows wildcard matching. Path specifiers work for Read/Write: `Read(./.env)`, `Write(src/*)`, `Read(./secrets/**)`.

**Permission rule evaluation order:** Deny rules first → Allow rules second → Permission mode third → `canUseTool` callback fourth. Deny rules override everything, even `bypassPermissions` mode.

## Conclusion: use `disallowedTools`, not `allowedTools`, for reliable restriction

The practical recommendation for read-only agentic workflows is clear: **do not rely on `--allowedTools` as a whitelist**. Instead, use `--disallowedTools "Write,Edit,MultiEdit,Bash,NotebookEdit,TodoWrite"` to explicitly remove write-capable tools from the model's context. This is the only mechanism that works reliably across all permission modes. Alternatively, in the TypeScript SDK, pair `allowedTools: ["Read", "Glob", "Grep", "LS"]` with `permissionMode: "dontAsk"` for proper whitelist behavior.

The built-in Grep and Glob tools are functionally rich — Grep wraps ripgrep with regex, context lines, and multi-file search; Glob supports full recursive patterns. Removing Bash has minimal impact on static code discovery but eliminates git operations and runtime inspection. For a practical read-only agent, the configuration `--disallowedTools "Write,Edit,MultiEdit,Bash,NotebookEdit,TodoWrite"` combined with the built-in search tools provides a robust, safe exploration environment — provided you accept the known bugs in tool restriction enforcement that Anthropic is still working to resolve.