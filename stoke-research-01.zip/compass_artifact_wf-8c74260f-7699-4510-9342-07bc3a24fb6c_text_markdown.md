# Production load testing and performance engineering for Go and TypeScript services

**The single most important thing teams get wrong is measuring performance with tools that suffer from coordinated omission, then trusting averages instead of percentiles.** Everything downstream — capacity planning, regression detection, scaling decisions — inherits that error. This report covers 10 critical areas with tool recommendations, methodology, and configuration examples that work in production, not just in demos. The stack assumption throughout: Go and TypeScript services backed by PostgreSQL and Kafka, deployed on Kubernetes, with CI/CD pipelines gating deployments.

---

## 1. Load testing tools: k6 wins for Go+TypeScript teams, but you need more than one

Six tools dominate the landscape, each written in a different language with different trade-offs. The right choice depends on what you're testing.

**k6 (Grafana Labs)** is the primary recommendation. Written in Go, scripted in JavaScript/TypeScript, it reached **v1.0 in May 2025** with native TypeScript support. Its `constant-arrival-rate` executor avoids coordinated omission, built-in thresholds produce non-zero exit codes for CI gating, and the k6-operator (GA v1.0, September 2025) provides Kubernetes-native distributed testing. The extension ecosystem covers gRPC, Kafka, MQTT, and WebSocket natively. k6 generates substantial load from a single binary — no JVM, no runtime dependencies.

**Vegeta** is the Go team's precision instrument. It sends requests at an exact constant rate regardless of server response time, avoiding coordinated omission by design. As a Go library (`github.com/tsenart/vegeta/lib`), it embeds directly into `go test` suites for programmatic benchmarking. HTTP only, no complex scenarios, but unmatched for accurate latency measurement of individual endpoints.

**wrk2** remains the gold standard for coordinated-omission-corrected HTTP benchmarking. Gil Tene's fork of wrk measures latency from *intended* send time (not actual), using HdrHistogram for precise tail latency recording. Use it when you need the most accurate possible percentile data for a single endpoint.

| Feature | k6 | Locust | Gatling | Artillery | Vegeta | wrk2 |
|---|---|---|---|---|---|---|
| Language | Go | Python | Scala | Node.js | Go | C |
| Scripting | JS/TS | Python | Java/Scala/JS/TS | YAML+JS | CLI/Go lib | Lua |
| HTTP/2 | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ |
| WebSocket | ✅ | Plugin | ✅ | ✅ | ❌ | ❌ |
| gRPC | ✅ | Plugin | ✅ | Plugin | ❌ | ❌ |
| Distributed | k6-operator/Cloud | Built-in master/worker | Enterprise only | Serverless (AWS/Azure) | Manual | Manual |
| CI thresholds | ✅ Native | ❌ Custom | ✅ Assertions | ✅ `ensure` | ❌ Custom | ❌ Custom |
| CO handling | ✅ (arrival-rate) | ❌ Closed model | ⚠️ Partial | ⚠️ Hybrid | ✅ By design | ✅ Gold standard |

**Artillery** deserves consideration if you need Playwright-based browser load testing alongside API testing, or if you test Socket.IO and Kafka. **Gatling** added a JavaScript/TypeScript SDK in 2024, making it accessible to TS teams, with excellent gRPC and MQTT support out of the box. **Locust** suits Python-heavy teams who need maximum scripting flexibility.

For CI pipelines, **k6 + Vegeta** covers nearly everything: k6 for complex scenario-based load tests with threshold-based pass/fail, Vegeta for precise constant-rate API benchmarks embedded in Go test suites.

---

## 2. Designing load tests that reflect production, not wishful thinking

The most common failure mode in load testing is testing against imagined traffic patterns instead of real ones. Start with production data.

**Mine your actual workload from APM and access logs.** Extract the top 5–10 user journeys by traffic volume from tools like Datadog, New Relic, or raw access logs. Calculate their relative weights during peak hours. A typical e-commerce breakdown might be browse/search (55%), product views (20%), add-to-cart (12%), checkout (8%), account management (5%). The critical mistake is testing only the checkout flow — it's the highest-value transaction but generates just 8% of infrastructure load.

**Think time modeling separates realistic tests from synthetic noise.** Without think time, virtual users hammer endpoints back-to-back, creating contention patterns that never exist in production. Worse, constant think times (e.g., every VU pauses exactly 5 seconds) create synchronized request bursts. Research by T. Wilson ("What Were They Thinking," CMG 2011) found that **log-normal distribution is the best empirical fit for real user think times**. In k6, implement this with a Box-Muller transform clamped to reasonable bounds rather than using `sleep(Math.random() * N)`.

Ramp-up patterns should match your testing objective. Gradual ramp-up (linear VU increase) establishes baseline performance and identifies the degradation point. Spike testing (instant VU jump) validates auto-scaling and circuit breakers. Soak testing (sustained 60–80% load for hours) catches resource leaks. Breakpoint testing (continuous increase until failure) establishes hard capacity limits. Each answers a different question — running only one type leaves blind spots.

**Data parameterization determines whether you're testing your service or your cache.** If all virtual users request the same 10 items, you're benchmarking cache hit rates. Use Zipfian distributions to model realistic hot/cold access patterns. Generate unique identifiers per VU to prevent artificial cache warming. In k6, use `SharedArray` for CSV-loaded test data distributed across VUs.

**Environment parity is non-negotiable for meaningful results.** A database with 100 rows behaves fundamentally differently from one with 100 million rows — query plans change, index usage shifts, I/O patterns diverge. Use the same Terraform/Kubernetes manifests as production. Mock external services for cost control and repeatability, but periodically validate against real endpoints.

---

## 3. Why your latency numbers are probably wrong

If you report average latency, you are hiding the failures that matter most. A service with **p50 = 5ms but p99 = 2000ms** shows an "average" of ~25ms — looks excellent on a dashboard, but 1 in 100 users waits 2 full seconds. In a microservices architecture where a user action calls 15 backend APIs, the probability of hitting at least one p99 outlier is 1 − (0.99¹⁵) ≈ **14%**. So 14% of user interactions experience multi-second delays despite "25ms average latency."

**Track p50 for broad regressions, p95 for SLO targets, p99 for architectural bottlenecks.** As Gil Tene notes, 99% of users experience approximately the 99.995th percentile response time across a session — which makes p95 reporting almost dangerously optimistic for user-facing services. Record p99.9 for latency-sensitive paths (payments, real-time features).

**HDR Histogram solves the precision problem.** Standard histograms with fixed bucket sizes either waste memory or lose precision across wide ranges. Gil Tene's High Dynamic Range Histogram provides O(1) recording (~3–6 nanoseconds), constant memory regardless of sample count, and configurable precision via significant figures. In Go: `hdrhistogram.New(1, 30000000, 3)` tracks values from 1µs to 30s with sub-microsecond resolution at the low end. In TypeScript: `hdr-histogram-js` includes a WebAssembly implementation for performance-critical paths.

**The coordinated omission problem silently corrupts your measurements.** In a closed-loop load generator (wrk, ab, JMeter default), each connection waits for a response before sending the next request. When a request takes 5 seconds instead of 1ms, the generator sends nothing during that window — it *coordinates* with the system to avoid measuring during problematic periods. Gil Tene demonstrated cases where reported latency statistics were **35,000× off** at the 99.99th percentile.

The fix is straightforward: use open-model load generation. In k6, use the `constant-arrival-rate` executor instead of `constant-vus`. With Vegeta, constant-rate is the default and only mode. With wrk2, the `-R` flag specifies target RPS and latency is measured from *scheduled* send time. The key question for any benchmark: "Does the load generator fire requests on schedule even when previous requests haven't returned?" If not, your percentile data is fiction.

```javascript
// k6: Open model that avoids coordinated omission
export const options = {
  scenarios: {
    open_model: {
      executor: 'constant-arrival-rate',
      rate: 500,              // 500 RPS
      timeUnit: '1s',
      duration: '5m',
      preAllocatedVUs: 100,
      maxVUs: 200,
    },
  },
  thresholds: {
    http_req_duration: ['p(95)<300', 'p(99)<800'],
    http_req_failed: [{ threshold: 'rate<0.01', abortOnFail: true }],
  },
};
```

**Connection establishment overhead is often invisible but significant.** Each new TCP connection costs a 3-way handshake (1.5 RTTs); with TLS 1.2, add 1–2 more round trips (~60ms). Lob found that enabling HTTP Keep-Alive yielded a **50% increase in maximum throughput** for their Node.js service. When benchmarking, ensure your load generator uses keep-alive (most do by default), and decide whether connection setup time should be included based on whether your production clients maintain persistent connections.

---

## 4. PostgreSQL under pressure: beyond pgbench defaults

**pgbench's default TPC-B-like benchmark tests a 1970s banking workload, not your application.** The built-in script runs 7 commands per transaction (BEGIN, UPDATE accounts, SELECT balance, UPDATE tellers, UPDATE branches, INSERT history, END) — a synthetic pattern that tells you almost nothing about how your Go service's actual queries perform under load.

The value of pgbench lies in custom scripts. Write scripts that mirror your real query patterns:

```sql
\set user_id random_zipfian(1, 1000000, 1.07)
\set amount random(1, 10000)
BEGIN;
SELECT balance FROM accounts WHERE id = :user_id;
UPDATE accounts SET balance = balance + :amount WHERE id = :user_id;
INSERT INTO transactions (account_id, amount, created_at)
  VALUES (:user_id, :amount, now());
COMMIT;
```

Combine multiple scripts with weights to match production ratios: `-f read.sql@3 -f write.sql@1` produces a 75/25 read/write split. Use `random_zipfian()` instead of `random()` to model realistic hot-spot access patterns. Initialize with a scale factor that matches production data volume — `pgbench -i -s 100` creates 10 million account rows.

**Capture your actual query workload with pg_stat_statements.** Enable it (`shared_preload_libraries = 'pg_stat_statements'`), then query the top statements by total execution time. This reveals which queries consume the most backend resources, not which queries developers think are slow. **pgreplay-go** (by GoCardless, written in Go) replays captured PostgreSQL query logs at approximate original rate with Prometheus metrics — far more realistic than any synthetic benchmark.

**Connection pool saturation is where Go services fail silently.** Go's `database/sql` defaults are dangerous: **MaxOpenConns defaults to 0 (unlimited)**, which can overwhelm PostgreSQL's `max_connections` (default 100). **MaxIdleConns defaults to 2**, which is far too low — real-world experience at GoCardless showed that increasing idle connections from 2 to 6 reduced database load by **30–60%** by eliminating connection churn. Set these explicitly:

```go
db.SetMaxOpenConns(25)                     // (PG max_connections / app_instances) - buffer
db.SetMaxIdleConns(10)                     // 25-50% of MaxOpenConns
db.SetConnMaxLifetime(30 * time.Minute)    // Recycle to handle PG config changes
db.SetConnMaxIdleTime(5 * time.Minute)     // Clean up unused connections
```

Monitor pool health via `db.Stats()`: `WaitCount` and `WaitDuration` reveal queueing. If WaitCount grows during load tests, your MaxOpenConns is too low or your queries are too slow. When using PgBouncer in transaction pooling mode, test with clients exceeding `default_pool_size` and watch for `avg_wait_time` spikes in `SHOW STATS`.

Under sustained write-heavy load, watch autovacuum carefully. Dead tuple accumulation (`n_dead_tup` in `pg_stat_user_tables`) causes table bloat, slower sequential scans, and wasted I/O. On very large tables, anti-wraparound vacuum can trigger hours-long VACUUM FREEZE operations. Monitor `age(datfrozenxid)` and set per-table `autovacuum_vacuum_scale_factor` to values much lower than the 0.2 default for high-churn tables.

---

## 5. Kafka performance testing: tuning the parameters that actually matter

Start with Kafka's built-in tools before building custom harnesses. `kafka-producer-perf-test.sh` with `--throughput -1` establishes maximum theoretical producer throughput on your hardware:

```bash
kafka-producer-perf-test.sh \
  --topic bench --num-records 10000000 --record-size 256 \
  --throughput -1 \
  --producer-props acks=all bootstrap.servers=kafka:9092 \
    batch.size=65536 linger.ms=10 compression.type=lz4
```

**Three producer configurations dominate throughput.** `batch.size` (default 16KB) controls maximum bytes per batch — increase to 64KB or 128KB for higher throughput. `linger.ms` (default 0) controls how long to wait for a batch to fill — setting it to 5–50ms dramatically improves throughput by allowing batch accumulation. `compression.type` reduces network and disk usage: **lz4** offers the best throughput-to-ratio balance for most workloads, zstd provides better compression with moderate CPU cost, and gzip has the worst throughput despite highest compression ratio.

The `acks` setting directly trades durability for speed. `acks=0` (fire-and-forget) gives highest throughput but risks data loss. `acks=1` (leader acknowledgment) balances speed and safety. `acks=all` (all ISR replicas acknowledge) provides strongest durability and is required for idempotent producers — enable `enable.idempotence=true` to prevent duplicates during retries.

**Consumer lag monitoring requires dedicated tooling, not ad-hoc checks.** LinkedIn's **Burrow** (written in Go) evaluates lag trend over a sliding window rather than just checking current values, classifying consumers as OK/WARNING/ERR based on lag trajectory. This avoids false positives from threshold-based alerting. For Prometheus-based stacks, `kafka-lag-exporter` exposes per-partition lag as metrics: `sum by (consumergroup) (kafka_consumergroup_lag)` gives total lag, and `rate(kafka_consumergroup_lag[5m])` shows whether a group is falling behind.

**Test broker failure under sustained load with RF=3 and min.insync.replicas=2.** Kill a broker with `kill -9` or `kubectl delete pod kafka-2` during a load test. With one broker down, production should continue (2 ISR remaining ≥ min.insync.replicas) with a brief latency spike during leader election. Record the time until leader election completes, the producer error rate, the consumer lag spike, and the time until full ISR recovery after broker restart. This test validates your replication configuration before production discovers it for you.

Use **CooperativeStickyAssignor** (`partition.assignment.strategy`) for your Go and TypeScript consumers. Unlike eager rebalancing (which stops all consumers, revokes all partitions, and reassigns), cooperative rebalancing only pauses affected partitions while others continue processing. Combined with static group membership (`group.instance.id` per consumer), pod restarts in Kubernetes won't trigger rebalances within `session.timeout.ms`.

---

## 6. Capacity planning: from benchmark numbers to infrastructure budgets

**Define a service capacity unit (SCU)** by load-testing a single instance of known spec. Run k6 or Vegeta against one pod (e.g., 2 vCPU, 4GB RAM) and find the maximum RPS that meets your SLO (e.g., p99 < 200ms). That number — say, 1,200 RPS — is your SCU. Required pods = `(Target RPS × Safety Factor) / RPS_per_pod`.

Google SRE's **N+2 rule** provides the safety factor: provision so peak traffic can be handled while the 2 largest instances are simultaneously unavailable (planned maintenance plus unplanned failure). For a service requiring 10 pods at peak, provision 12. Netflix designs for **4–5× burst** on play-start QPS versus daily average — their open-source `service-capacity-modeling` library uses Monte Carlo simulation (512+ runs) with confidence intervals to output "least regret" hardware choices.

**Cost-per-request math is straightforward but often incomplete.** A c7g.large at $0.09/hour handling 1,000 RPS serves 3.6M requests/hour, yielding **$0.025 per million requests** on compute alone. But all-in cost must include ALB ($0.0225/hr + LCU charges), data transfer ($0.09/GB outbound on AWS), NAT Gateway ($0.045/hr + $0.045/GB — a silent cost killer), database, caching, and monitoring. Use **Infracost** in CI to estimate infrastructure cost changes per PR.

**Verify auto-scaling actually works before you need it.** HPA scale-up latency is 30 seconds to 4 minutes end-to-end: metrics-server scrape (15–30s) + HPA evaluation loop (15s) + pod scheduling and image pull (5–30s) + readiness probe. If Cluster Autoscaler needs a new node, add 1–3 minutes. Go binaries start fast (<100ms), but warming caches and establishing database connection pools takes longer. Run k6 with a ramp-up scenario while watching `kubectl get hpa --watch` and verify no requests are dropped during scale-up. Test scale-down too — the default 5-minute stabilization window prevents premature scale-down but must be validated against your traffic patterns.

CPU-based HPA misses I/O-bound workloads entirely. Use custom metrics — RPS, request latency, or queue depth — via Prometheus Adapter or KEDA. Google Cloud testing showed that targeting 50% CPU provisioned 22 CPUs (293ms avg latency) while 70% CPU provisioned only 12 CPUs (360ms avg) — an **84% resource reduction** with moderate latency increase.

---

## 7. Soak testing catches the bugs that load testing cannot

Short load tests (5–15 minutes) prove your service handles burst capacity. Soak tests (4–72 hours at 60–80% capacity) prove it doesn't slowly degrade. These are different classes of defects.

**Goroutine leaks are the most common Go soak-test finding.** Goroutines blocked on channel operations, leaked contexts, or unclosed tickers accumulate indefinitely, growing memory and CPU overhead. `time.After` inside `select` loops is a classic culprit — it creates a new timer channel each iteration that isn't garbage collected until it fires. Monitor with `runtime.NumGoroutine()` exposed via Prometheus (`go_goroutines` metric), and set an alert if the count trends upward over a 2-hour window. Expose `net/http/pprof` on a debug port for goroutine stack traces at `/debug/pprof/goroutine?debug=1`. Uber's `goleak` package (`defer goleak.VerifyNone(t)`) catches goroutine leaks in unit tests.

**Node.js/TypeScript services leak through event listeners and closures.** `emitter.on()` without corresponding `removeListener()` in long-lived objects, closures capturing large objects in scope, and unfinished streams holding Buffer references all accumulate silently. Monitor `process.memoryUsage()` for RSS/heap trends. Use Chrome DevTools via `--inspect` for heap snapshot comparison: take snapshots at intervals, compare "Objects allocated between s1 and s2," and sort by Retained Size.

**Connection leaks hit both languages.** In Go, always check errors from `db.Query()` and close `*sql.Rows` — unclosed rows keep connections checked out from the pool. In Node.js, always release database clients in `finally` blocks. Monitor open file descriptors (`/proc/<pid>/fd` count) — exhaustion manifests as mysterious "too many open files" errors hours into production.

Set up automated soak tests as weekly CI jobs with 4–6 hour timeouts. Use Docker Compose with your application, Prometheus, and Grafana. Pass/fail criteria: memory growth < 10% over test duration, no latency drift > 15%, error rate < 0.1%, goroutine count stable.

```go
// Go soak monitoring: expose via pprof + Prometheus
import _ "net/http/pprof"
go http.ListenAndServe(":6060", nil)

// Alert on goroutine trends
var memStats runtime.MemStats
runtime.ReadMemStats(&memStats)
// Track: HeapAlloc, HeapInuse, NumGC, PauseNs, NumGoroutine
```

---

## 8. Chaos under load exposes where production actually fails

Most production incidents occur at the intersection of **peak load AND component failure**. Load testing alone assumes all dependencies work. Chaos testing alone typically runs at idle. Neither catches the compound scenario: "What happens when 10,000 users hit checkout while the payment service has 500ms of added latency?"

**toxiproxy (Shopify, written in Go) is the right starting point for CI integration.** It operates as a TCP proxy that injects network-level faults — latency, bandwidth limiting, connection reset, timeout — with < 100µs overhead when no toxics are active. Use it programmatically from Go tests:

```go
client := toxiproxy.NewClient("localhost:8474")
proxy, _ := client.CreateProxy("postgres", "localhost:26379", "localhost:5432")

func TestDBSlow(t *testing.T) {
    proxy.AddToxic("", "latency", "", 1, toxiproxy.Attributes{"latency": 500})
    defer proxy.RemoveToxic("latency")
    // Verify timeout handling, circuit breaker trip, fallback behavior
}
```

For Kubernetes environments, **LitmusChaos** (CNCF Incubating) natively supports k6 as a chaos fault type (`k6-loadgen`). Create k6 scripts as Kubernetes Secrets, configure a ChaosEngine with the `k6-loadgen` experiment, and combine with pod-network-latency or pod-delete faults in a single workflow. **Chaos Mesh** (CNCF Sandbox) provides pod, network, I/O, and time-skew chaos with a dashboard for experiment management.

The methodology follows four steps. First, define a steady-state hypothesis: "At 500 RPS, p99 < 200ms, error rate < 0.1%." Second, establish baseline by running k6 at 70–100% production load for 5–10 minutes. Third, inject a specific failure while load continues — dependency timeouts, network partition, database connection failure, Kafka broker death, DNS resolution failure. Fourth, measure: does the service degrade gracefully or cascade? Do circuit breakers trip? Does it recover automatically when the fault clears?

**Start game days small** — single service, single fault, staging environment — and graduate to multi-service production experiments. Assign clear roles: an owner who decides when to stop, a coordinator who starts attacks, a reporter who collects data. Document every experiment in a runbook: pre-chaos checklist → establish baseline → inject fault → observe → remove fault → verify recovery → post-mortem.

---

## 9. Catching performance regressions before users do

Performance regressions caught in CI cost minutes to fix. The same regressions caught in production cost incidents. The challenge is distinguishing real regressions from measurement noise.

**For Go services, `benchstat` is the official tool.** Rewritten in January 2023 by Austin Clements, it compares two benchmark result files using the Mann-Whitney U test (non-parametric, no normality assumption required) at α = 0.05. If p > 0.05, it displays `~` instead of a percentage — meaning the difference is not statistically significant. **Run benchmarks with `-count=10` minimum, ideally 20.** A critical warning from the benchstat documentation: "If benchstat reports no statistically significant change, avoid simply rerunning your benchmarks until it reports a significant change. This is known as 'multiple testing' and is a common statistical error."

```bash
# Go CI pipeline pattern
go test -bench=. -benchmem -count=10 ./... > new.txt
git checkout main
go test -bench=. -benchmem -count=10 ./... > old.txt
benchstat old.txt new.txt
# Output shows median, 95% CI, delta %, p-value per benchmark
```

**For TypeScript services, k6 thresholds provide API-level performance gates.** Define SLO-aligned thresholds (`p(95)<300`, `error_rate<0.01`) that produce non-zero exit codes on violation. Use `grafana/setup-k6-action` and `grafana/run-k6-action` in GitHub Actions. For microbenchmarks, **autocannon** (by Matteo Collina) provides latency histograms and requests/sec metrics; `autocannon-ci` stores results and generates comparison dashboards.

**Rust's criterion.rs represents the gold standard** that Go and TypeScript tools aspire to. It uses bootstrap resampling to generate confidence intervals around performance measurements, classifies outliers via modified Tukey's Method, automatically stores previous results on disk for comparison, and produces HTML reports with violin plots. Its configurable noise threshold (e.g., ±1%) filters trivially small changes. Go's benchstat provides similar statistical rigor but requires manual orchestration.

The practical CI decision is **when to block merges versus warn**. Block on threshold violations for p95 latency, error rate, and critical-path regressions. Warn on marginal changes within the noise threshold, newly added benchmarks without baselines, and non-critical paths. Track trends over time in InfluxDB/Grafana — single runs are noisy, but sustained upward drift in latency is signal.

---

## 10. Frontend performance gates belong in CI, not in post-mortems

**Lighthouse CI** (`@lhci/cli`, ~2M monthly npm downloads) runs Google Lighthouse audits in CI and fails builds that violate performance budgets. Configure assertions in `lighthouserc.json`:

```json
{
  "ci": {
    "assert": {
      "preset": "lighthouse:recommended",
      "assertions": {
        "first-contentful-paint": ["error", {"maxNumericValue": 2000}],
        "interactive": ["error", {"maxNumericValue": 5000}]
      }
    }
  }
}
```

Run with `numberOfRuns: 3-5` minimum — shared CI runners cause significant score variability, and asserting against a single run creates flaky tests. Use the Lighthouse CI GitHub App for status checks on PRs with links to detailed reports. For historical tracking, deploy the LHCI Server to visualize score trends across builds.

**Core Web Vitals shifted in March 2024**: INP (Interaction to Next Paint) replaced FID as the responsiveness metric. INP measures the worst interaction latency across an entire page session, not just the first input. Only **48% of mobile pages** pass all three Core Web Vitals (LCP < 2.5s, INP < 200ms, CLS < 0.1) according to the 2025 Web Almanac. Google evaluates at the 75th percentile of page loads.

**Bundle size tracking prevents slow TTI regression.** **size-limit** (by Andrey Sitnik) calculates real user cost — not just bytes, but download time plus execution time estimates. Its Webpack plugin creates an empty project, adds your library, and measures the bundle size difference with tree-shaking applied. The size-limit GitHub Action posts bundle size changes as PR comments. Configure in `package.json`: `"size-limit": [{"limit": "9 kB", "path": "index.js"}]`. PostCSS achieved a 25% size reduction and Logux achieved 90% by using size-limit as a CI gate.

**You need both synthetic testing (Lighthouse in CI) and Real User Monitoring (RUM) in production.** Synthetic testing catches regressions before code ships — consistent, reproducible, fast feedback. RUM via the `web-vitals` library (~2KB) tells you what users actually experience, catching issues synthetic misses: geographic CDN gaps, device-specific problems, dynamic content interactions. Google uses field data (CrUX) for search ranking, not lab scores. Implement RUM by sending metrics to your analytics backend with the attribution build for diagnostic info on what element caused poor LCP or what script caused poor INP.

---

## Conclusion: the performance testing stack that actually works

The integrated stack for Go and TypeScript services is not a single tool but a layered system. **k6 handles scenario-based load tests with CI-integrated thresholds.** **Vegeta provides constant-rate HTTP benchmarks embedded in Go test suites.** **benchstat gates Go microbenchmark regressions with statistical rigor.** **Lighthouse CI and size-limit gate frontend regressions.** **toxiproxy injects dependency failures during load tests in CI.** **pgbench with custom scripts and pgreplay-go validate database performance against production-like query patterns.**

Three insights cut across all 10 areas. First, coordinated omission corrupts every downstream decision — use open-model load generation (k6 `constant-arrival-rate`, Vegeta, wrk2) or accept that your percentile data is fiction. Second, statistical comparison (benchstat's Mann-Whitney U test, criterion's bootstrap confidence intervals) separates real regressions from noise; naive threshold comparison creates either alert fatigue or missed regressions. Third, compound failures — peak load combined with dependency failure — cause the production incidents that matter most, and no amount of pure load testing or pure chaos testing alone will find them. The combination, with tools like LitmusChaos + k6 or toxiproxy in integration tests, is where the highest-value testing happens.