# Desktop development with Tauri 2.0 and Electron in 2025–2026

**Tauri 2.0 and Electron have diverged into fundamentally different engineering paradigms.** Tauri 2.0 (stable since October 2024, now at **v2.10.3**) delivers apps at **~8 MB** with **~30–40 MB RAM** usage through a Rust core and OS-native WebViews, while Electron 41 (Chromium 146, Node.js 24) ships a full Chromium instance at **~150–250 MB** per app but provides unmatched rendering consistency and ecosystem depth. This report covers architecture, security, platform engineering, offline-first patterns, CI/CD, monitoring, accessibility, and community tooling across both frameworks with production-ready code and concrete benchmarks.

---

## 1. Tauri 2.0 architecture and its security-first design

### Core-shell trust model

Tauri 2.0 uses a **core-shell architecture** where the Rust backend (trusted zone) is separated from the WebView frontend (untrusted zone) by an IPC boundary. The frontend never has direct system access — all interactions flow through validated IPC channels. Unlike Electron, where developers must opt into security by disabling `nodeIntegration` and enabling `contextIsolation`, Tauri enforces isolation architecturally. The frontend can only call explicitly registered Rust commands, and those commands must be permitted via the capabilities system.

Commands are defined with the `#[tauri::command]` macro, automatically type-checked via Serde deserialization, and registered at build time:

```rust
#[tauri::command]
async fn read_config(app: tauri::AppHandle) -> Result<AppConfig, String> {
    let config_path = app.path().app_config_dir().map_err(|e| e.to_string())?;
    let content = tokio::fs::read_to_string(config_path.join("config.json"))
        .await.map_err(|e| e.to_string())?;
    serde_json::from_str(&content).map_err(|e| e.to_string())
}
```

The frontend invokes commands through `@tauri-apps/api/core`:

```typescript
import { invoke } from '@tauri-apps/api/core';
const config = await invoke<AppConfig>('read_config');
```

Tauri 2.0 introduced three IPC primitives beyond basic commands: **Events** (bidirectional, fire-and-forget), **Channels** (`tauri::ipc::Channel` for streaming ordered data like download progress), and **Raw Payloads** (`tauri::ipc::Request`/`Response` for binary data bypassing JSON serialization).

### The v1 allowlist is gone — capabilities replaced it entirely

Tauri v1 used a flat boolean allowlist in `tauri.conf.json` that toggled entire API categories on/off with no per-window granularity and no plugin coverage. **Tauri 2.0 replaced this with a three-tier ACL**: permissions (on/off toggles for individual commands), scopes (parameter constraints restricting what a command can access), and capabilities (bundles of permissions attached to specific windows/webviews with optional platform targeting).

Capability files live in `src-tauri/capabilities/` as JSON or TOML:

```json
{
  "$schema": "../gen/schemas/desktop-schema.json",
  "identifier": "main-capability",
  "windows": ["main"],
  "permissions": [
    "core:default",
    "dialog:default",
    {
      "identifier": "fs:scope-app-data",
      "allow": [{ "path": "$APPDATA/**" }],
      "deny": [{ "path": "$APPDATA/secrets/**" }]
    }
  ]
}
```

Platform-specific capabilities target mobile or desktop exclusively via `"platforms": ["iOS", "android"]`. At build time, Tauri generates JSON schemas enumerating all available permissions for IDE autocompletion. The migration CLI (`npx tauri migrate`) auto-parses v1 allowlists into capability files.

### CSP and prototype freezing

CSP is configured in `tauri.conf.json` under `app.security.csp`. Tauri **auto-injects nonces and hashes** for bundled scripts at compile time, meaning `'unsafe-inline'` has no effect when Tauri's custom protocol is active. For production, enable `"freezePrototype": true` to harden against prototype pollution. WebAssembly frontends (Leptos, Yew) require `'wasm-unsafe-eval'` in `script-src`. The `ipc:` and `http://ipc.localhost` connect-src values are required for Tauri IPC to function.

### Plugin ecosystem

All official plugins follow a consistent pattern: Cargo dependency + npm package + `.plugin()` registration + capability permissions. Key plugins for production apps:

- **tauri-plugin-store** (`@tauri-apps/plugin-store`): Persistent key-value storage. `await Store.load('settings.json')` then `get`/`set`/`save`.
- **tauri-plugin-sql** (`@tauri-apps/plugin-sql`): SQLite/MySQL/PostgreSQL via sqlx. Supports built-in migrations with a `Migration` struct applied automatically at init.
- **tauri-plugin-updater** (`@tauri-apps/plugin-updater`): Desktop-only auto-updates with Ed25519 signature verification. Requires HTTPS endpoints.
- **tauri-plugin-dialog**, **tauri-plugin-fs**, **tauri-plugin-clipboard-manager**: Native dialogs, scoped filesystem access, clipboard read/write — all gated by explicit capability permissions.

### Mobile support is real but maturing

iOS and Android are supported as first-class build targets since Tauri 2.0.0, using **WKWebView** (iOS) and **Android System WebView** (Android). Core IPC works identically across platforms. Mobile-specific plugins include NFC, barcode scanner, biometric authentication, haptics, and geolocation. However, the Tauri team has acknowledged that mobile developer experience is still being refined in minor releases, not all desktop plugins are ported yet (the updater is desktop-only), and on Linux/Android, Tauri cannot distinguish iframe requests from window requests — an important security consideration.

---

## 2. How Tauri and Electron compare on real benchmarks

### Bundle size: 28× smaller for simple apps

The most dramatic difference between the two frameworks is shipping size. In an April 2025 benchmark by the Hopp team comparing equivalent apps (window + button to spawn windows), **Tauri produced an 8.6 MiB macOS bundle versus Electron's 244 MiB** — roughly a 28× reduction. On Windows, the gap is similar: the Authme authenticator app ships a ~2.5 MB Tauri installer versus ~85 MB on Electron. Hoppscotch's migration from Electron to Tauri cut their bundle from **165 MB to 8 MB** (96% reduction). The reason is architectural: Electron bundles a complete Chromium engine (~100+ MB) and Node.js runtime, while Tauri uses the OS's pre-installed WebView and compiles only app-specific Rust code.

### Memory and startup performance

| Metric | Tauri 2.x | Electron 41 |
|--------|-----------|-------------|
| **Idle (single window)** | ~30–40 MB | ~200–300 MB |
| **6 windows (macOS)** | ~172 MB | ~409 MB |
| **Per-window overhead** | ~22 MB | ~35 MB |
| **Cold start** | <0.5 seconds | 1–2 seconds |
| **Initial build time** | ~81 seconds (Rust) | ~16 seconds |

An important caveat: Electron's memory measurements are inflated by naive RSS measurement. When USS (Unique Set Size) is measured instead, accounting for Chromium's shared memory across renderer processes, the gap narrows somewhat — particularly on Windows where Tauri also uses a Chromium-based WebView (WebView2). The difference is most dramatic on macOS/Linux where Tauri uses WebKit versus Electron's Chromium. Build time is the main Tauri tradeoff: first builds take ~5× longer due to Rust compilation, though incremental builds are fast.

### Platform support and rendering consistency

| Platform | Electron 41 | Tauri 2.x | Tauri WebView engine |
|----------|-------------|-----------|---------------------|
| Windows 10+ | ✅ | ✅ | WebView2 (Chromium/Edge) |
| macOS 12+ | ✅ | ✅ | WKWebView (WebKit) |
| Linux | ✅ | ✅ | WebKitGTK |
| iOS | ❌ | ✅ | WKWebView |
| Android | ❌ | ✅ | Android System WebView |

**Electron guarantees identical rendering** via bundled Chromium. Tauri uses different engines per platform (Chromium on Windows/Android, WebKit on macOS/iOS/Linux), which can cause CSS inconsistencies. WebKit may lag behind Chromium features, requiring `-webkit-` prefixes or polyfills. Developers must test across platforms more carefully with Tauri.

### Ecosystem maturity

Electron's npm ecosystem is vastly larger — over **70,000 Stack Overflow questions**, production use in VS Code, Slack, Discord, Figma, and Notion, and thousands of third-party packages. Tauri has ~25+ official plugins, 50+ community plugins, and production use in apps like Hoppscotch and Sourcegraph Cody. Electron's `electron-store`, `electron-updater`, and broader Node.js ecosystem remain significant advantages for teams without Rust experience. Tauri's advantage is that you can always write custom native functionality in Rust, while Electron's native module story requires native Node-API addons with platform-specific compilation.

---

## 3. Security patterns for production desktop apps

### Treat the frontend as an untrusted client

Both frameworks require the same mental model: **the frontend is hostile**. Every IPC message should be validated as strictly as an HTTP request from the public internet.

In Tauri, Rust's type system provides the first validation layer — arguments must implement `serde::Deserialize` with correct types. For additional validation, use the `validator` crate:

```rust
use validator::Validate;

#[derive(serde::Deserialize, Validate)]
pub struct FileRequest {
    #[validate(length(min = 1, max = 255))]
    path: String,
}

#[tauri::command]
pub async fn read_file(request: FileRequest, app: AppHandle) -> Result<String, String> {
    request.validate().map_err(|e| format!("Validation error: {}", e))?;
    let app_dir = app.path().app_data_dir().map_err(|e| e.to_string())?;
    let canonical = dunce::canonicalize(app_dir.join(&request.path))
        .map_err(|_| "Invalid path")?;
    if !canonical.starts_with(&app_dir) {
        return Err("Access denied: path traversal detected".into());
    }
    std::fs::read_to_string(canonical).map_err(|e| e.to_string())
}
```

For high-security Tauri apps, enable the **Isolation Pattern** which interposes a sandboxed iframe between the frontend and Tauri Core. This iframe intercepts and encrypts all IPC messages using AES-GCM, with keys regenerated per application launch.

In Electron, **never expose raw `ipcRenderer`** through the context bridge. Expose only specific, validated API functions with a channel whitelist:

```javascript
const ALLOWED_CHANNELS = ['file:save', 'file:read', 'app:version'];
contextBridge.exposeInMainWorld('api', {
  invoke: (channel, data) => {
    if (!ALLOWED_CHANNELS.includes(channel)) throw new Error('Forbidden');
    return ipcRenderer.invoke(channel, data);
  }
});
```

In the main process, always validate the sender frame to prevent spoofed IPC from injected content.

### Electron Fuses: compile-time security that cannot be reversed

Electron Fuses are **binary-level flags** embedded in the Electron executable. Once flipped and code-signed, the operating system prevents reversal. This is the strongest Electron hardening mechanism available.

Production-ready fuse configuration via Electron Forge:

```javascript
const { FusesPlugin } = require('@electron-forge/plugin-fuses');
const { FuseV1Options, FuseVersion } = require('@electron/fuses');

module.exports = {
  plugins: [
    new FusesPlugin({
      version: FuseVersion.V1,
      [FuseV1Options.RunAsNode]: false,                          // Prevent ELECTRON_RUN_AS_NODE
      [FuseV1Options.EnableCookieEncryption]: true,              // OS-level cookie encryption
      [FuseV1Options.EnableNodeOptionsEnvironmentVariable]: false, // Block NODE_OPTIONS injection
      [FuseV1Options.EnableNodeCliInspectArguments]: false,       // Block --inspect debug ports
      [FuseV1Options.EnableEmbeddedAsarIntegrityValidation]: true,// Validate ASAR at runtime
      [FuseV1Options.OnlyLoadAppFromAsar]: true,                 // Prevent loading unvalidated code
      [FuseV1Options.GrantFileProtocolExtraPrivileges]: false,   // Remove file:// privileges
    })
  ]
};
```

The `RunAsNode` fuse is critical — without it, attackers can use the `ELECTRON_RUN_AS_NODE` environment variable for "living off the land" attacks, turning a signed Electron app into a general-purpose Node.js runtime. Zettlr was exploited this way (demonstrated at DEFCON 2023); the fix was simply flipping fuses in release 3.0.4. **ASAR integrity** verification computes a SHA-256 hash of the ASAR header at build time and validates it at runtime — if the hash mismatches, the app terminates. Both `EnableEmbeddedAsarIntegrityValidation` AND `OnlyLoadAppFromAsar` fuses must be enabled together, otherwise the integrity check can be bypassed.

### Code signing across all three platforms

**Windows** now mandates hardware-stored keys (FIPS 140-2 Level 2 HSMs or encrypted USB tokens) for all code signing certificates since June 2023. EV certificates **no longer instantly bypass SmartScreen** as of March 2024 — both OV and EV certificates build reputation organically. Microsoft Trusted Signing ($9.99–99.99/month) offers cloud-based signing without physical tokens, ideal for CI/CD.

**macOS** requires a $99/year Apple Developer Program membership, a "Developer ID Application" certificate, hardened runtime, and notarization via `xcrun notarytool submit`. Tauri apps need JIT entitlements (`com.apple.security.cs.allow-jit`) for the WebView to function properly.

**Linux** has no centralized signing authority. GPG signatures are used for AppImage (`appimagetool --sign`), RPM (`rpm --addsign`), and DEB (`debsigs --sign=origin`) packages. Most Debian-based distros verify repository metadata signatures rather than individual package files.

### Auto-updater security

Tauri's updater uses **Ed25519 keypairs** — the public key is embedded in the binary, and update artifacts are signed at build time via `TAURI_SIGNING_PRIVATE_KEY`. The signature is included in the update manifest and verified before installation, with downgrade protection enabled by default.

Electron's auto-update ecosystem is more fragmented. The built-in `autoUpdater` (Squirrel-based) has no signature verification on Windows. `electron-updater` from electron-builder adds certificate validation but has had critical bypass vulnerabilities (simple string comparison of `publisherName`). **Doyensec's SafeUpdater** (February 2026) provides a reference implementation with Ed25519 signatures, SHA-512 integrity verification, downgrade attack protection, and TOCTOU race condition prevention.

---

## 4. Desktop UX that feels native on every platform

### System tray and native menus

Tauri 2.0 provides the tray API via the `tray-icon` Cargo feature. Tray creation supports both Rust and JavaScript APIs, with platform-aware event handling:

```rust
TrayIconBuilder::new()
    .icon(app.default_window_icon().unwrap().clone())
    .menu(&menu)
    .menu_on_left_click(false)
    .on_tray_icon_event(|tray, event| match event {
        TrayIconEvent::Click { button: MouseButton::Left, 
            button_state: MouseButtonState::Up, .. } => {
            let app = tray.app_handle();
            if let Some(window) = app.get_webview_window("main") {
                let _ = window.show();
                let _ = window.set_focus();
            }
        }
        _ => {}
    })
    .build(app)?;
```

Key platform gotchas: Linux requires `libayatana-appindicator` and click events behave differently per desktop environment. macOS needs `iconAsTemplate: true` for menu bar template images. Windows icons must be `.ico` format. In Electron, **always store the `tray` variable globally** to prevent garbage collection — a notorious source of "my tray icon disappeared" bugs.

Context menus are built-in since Tauri v2 with `Menu.new()` in JavaScript. Electron offers two approaches: the `webContents.on('context-menu')` event with `params` for spellcheck/editable context, or IPC-based menus from the renderer.

### Multi-window management costs differ dramatically

Each Electron `BrowserWindow` spawns a separate Chromium renderer process consuming **~150–250 MB**. Tauri windows share the OS WebView engine, using **~10–50 MB per window**. Inter-window communication in Tauri uses the event system (`emit`/`listen` from `@tauri-apps/api/event`), while Electron routes messages through the main process relay or uses the `BroadcastChannel` web standard for same-origin windows.

### Deep linking requires platform-specific patterns

Both frameworks face the same fundamental platform split: macOS emits events natively when deep links arrive, while Windows and Linux spawn a new app instance with the URL as a CLI argument. In Tauri, `tauri-plugin-deep-link` handles this with `onOpenUrl()` for macOS and requires pairing with `tauri-plugin-single-instance` on Windows/Linux. Electron uses `app.on('open-url')` for macOS and `app.on('second-instance')` + `process.argv` parsing for Windows/Linux. Runtime protocol registration only works on Windows/Linux — macOS requires static configuration in Info.plist, handled by both frameworks' bundlers.

---

## 5. Building offline-first desktop architecture

### SQLite is the universal choice

For Tauri, **`tauri-plugin-sql`** (official, sqlx-based) is the recommended default — it provides frontend JavaScript access via `Database.load("sqlite:app.db")` with built-in migration support. For encryption or SQLite extension loading, `tauri-plugin-rusqlite2` (community fork using rusqlite) adds SQLCipher support, explicit transactions, and extension loading. For maximum control, use `sqlx` directly in Rust command handlers.

For Electron, **`better-sqlite3`** (v12.x) is the clear winner — it's the fastest SQLite binding for Node.js with synchronous API that paradoxically provides better concurrency for single-process desktop apps. It requires `@electron/rebuild` for compilation against Electron's Node version. `sql.js` (WASM-based) avoids native compilation entirely but loads the entire database into memory and is significantly slower.

**Always enable WAL mode** (`PRAGMA journal_mode = WAL`) for concurrent read/write performance in desktop apps.

### Migration strategy: sequential, transactional, forward-only

The universal pattern uses SQLite's `PRAGMA user_version` for schema tracking. Each migration runs in a transaction, ensuring atomicity. In production, only forward migrations should run — down migrations are a development convenience. Handle version skipping gracefully, since users may update from v1.0 to v1.5 without intermediate releases.

Tauri's built-in migration support via `tauri-plugin-sql`:
```rust
let migrations = vec![
    Migration { version: 1, description: "create_users",
        sql: "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT);",
        kind: MigrationKind::Up },
    Migration { version: 2, description: "add_email",
        sql: "ALTER TABLE users ADD COLUMN email TEXT;",
        kind: MigrationKind::Up },
];
```

For Electron with better-sqlite3, Drizzle ORM's `migrate()` function or a custom runner using `db.pragma('user_version')` works well.

### Sync strategies when connectivity returns

**Last-write-wins (LWW)** with per-column timestamps handles **~95% of use cases** according to PowerSync's experience building enterprise offline apps. Use per-field timestamps rather than per-row to minimize data loss from concurrent edits.

**CRDTs** (Conflict-free Replicated Data Types) provide mathematical guarantees that concurrent changes always merge correctly, but add storage overhead (tombstones, metadata) and complexity. Use CRDTs only when you need collaborative editing or P2P sync without a central authority.

### Local-first library landscape in 2025–2026

The field has matured significantly:

- **PowerSync**: The most production-ready option. Postgres/MongoDB → client SQLite sync via WebSocket streams. LWW by default with custom merge logic. Cloud + self-hosted options. SDKs for JavaScript, React Native, Flutter, Kotlin, Swift.
- **ElectricSQL**: Evolved to focus on read-path HTTP streaming (Shapes API). Does not handle writes — pair with your own API and TanStack DB for client mutations. Requires Postgres v14+ with logical replication.
- **cr-sqlite** (v0.16.3): SQLite extension adding CRDT support. Call `SELECT crsql_as_crr('tablename')` to upgrade tables. Inserts are ~2.5× slower than regular SQLite. **Not production-ready** — maintainers describe it as WIP.
- **Automerge** (v2.x, Rust core): JSON-like CRDT documents with true P2P support. Best for document-centric collaborative apps. Large histories (>60K edits) can slow down sync.
- **Yjs** (v13.x): Fastest CRDT implementation with the richest editor ecosystem (ProseMirror, TipTap, CodeMirror, Monaco bindings). Best when you need real-time text collaboration.

**Recommended stack**: Start with `better-sqlite3` or `tauri-plugin-sql` + LWW + an upload queue pattern. Add PowerSync for managed sync, or Yjs for collaborative text editing.

---

## 6. CI/CD pipelines that ship to three platforms simultaneously

### GitHub Actions matrix strategy

Both frameworks use `strategy.matrix` to build on Windows, macOS, and Linux in parallel. Critical settings: always set `fail-fast: false` so a failure on one platform doesn't cancel others. Tauri requires separate matrix entries for Apple Silicon and Intel macOS targets.

```yaml
strategy:
  fail-fast: false
  matrix:
    include:
      - platform: 'macos-latest'
        args: '--target aarch64-apple-darwin'
      - platform: 'macos-latest'
        args: '--target x86_64-apple-darwin'
      - platform: 'ubuntu-22.04'
        args: ''
      - platform: 'windows-latest'
        args: ''
```

Tauri builds benefit enormously from `Swatinem/rust-cache@v2` for Rust dependency caching. Without it, expect **5–15 minute** build times; with caching, incremental builds are much faster. macOS notarization adds 5–10 minutes.

### Code signing in CI: 11 secrets for Tauri, 6–9 for Electron

The universal pattern: export certificates as `.p12`/`.pfx`, base64-encode them, store as GitHub Secrets, decode and import in CI. macOS requires creating a temporary keychain, importing the certificate, and unlocking it — **7 secrets total** for Apple signing and notarization (`APPLE_CERTIFICATE`, `APPLE_CERTIFICATE_PASSWORD`, `KEYCHAIN_PASSWORD`, `APPLE_ID`, `APPLE_APP_SPECIFIC_PASSWORD`, `APPLE_TEAM_ID`, plus `GITHUB_TOKEN`). Tauri also needs `TAURI_SIGNING_PRIVATE_KEY` and its password for updater signing.

The **Tauri GitHub Action** (`tauri-apps/tauri-action@v1` for Tauri v2) handles building, code signing, GitHub Release creation, and updater manifest generation in one step. For Electron, `samuelmeuli/action-electron-builder@v1` provides similar automation.

### Electron Forge is now officially recommended over electron-builder

**Electron Forge** (v7.11.1, maintained by the Electron core team) has become the officially recommended build tool. It uses a modular architecture wrapping first-party tools (`@electron/packager`, `@electron/osx-sign`, `@electron/notarize`) and provides built-in Fuses support via `@electron-forge/plugin-fuses`. **electron-builder** (v26.8.1, ~1.5M weekly downloads vs Forge's ~500K) remains more popular by download count and offers broader installer format support (Flatpak, more Linux formats) and a more mature auto-updater (`electron-updater` with channels and staged rollouts). For new projects, start with Electron Forge. For existing electron-builder projects, no urgent migration is needed.

### Recommended installer formats

- **Windows**: **NSIS** is the recommended default — most popular, highly customizable, cross-compilable on Linux/macOS. MSI via WiX for enterprise/IT-managed deployments with Group Policy.
- **macOS**: **DMG** for direct distribution (industry standard drag-to-install UX). ZIP also needed for Squirrel.Mac auto-updates in Electron.
- **Linux**: Ship **AppImage + deb** at minimum. AppImage provides single-file portability across distros; deb covers the largest Linux userbase (Debian/Ubuntu). Add rpm for Fedora and consider Flatpak for Flathub store presence.

---

## 7. Electron security hardening checklist

Every production Electron app must enforce these settings:

```javascript
const mainWindow = new BrowserWindow({
  webPreferences: {
    nodeIntegration: false,        // NEVER enable (default since Electron 5)
    contextIsolation: true,        // ALWAYS keep (default since Electron 12)
    sandbox: true,                 // Default since Electron 20
    webSecurity: true,             // Enforces same-origin + blocks mixed content
    allowRunningInsecureContent: false,
    preload: path.join(__dirname, 'preload.js')
  }
});
```

**Context isolation** (default since Electron 12) runs preload scripts in a dedicated JavaScript context, preventing renderer scripts from modifying prototypes. The `contextBridge` API is the **only safe way** to expose APIs to the renderer. Since Electron 29, `ipcRenderer` can no longer be sent over the contextBridge directly — a breaking change that prevents full IPC system exposure.

The **remote module was fully removed** from Electron in v14 (PR #25734). The `@electron/remote` npm package exists as a replacement but is strongly discouraged — it made sandboxing nearly useless by allowing renderer processes to synchronously access main process objects.

**Disable DevTools in production** by intercepting the `devtools-opened` event and blocking F12/Ctrl+Shift+I keyboard shortcuts. Use the `EnableNodeCliInspectArguments` fuse to prevent `--inspect` flags from opening debug ports.

**CSP in Electron** is set via `<meta>` tags in index.html (since Electron loads local files via `file://`) or programmatically via `session.defaultSession.webRequest.onHeadersReceived`. A strict production CSP:

```html
<meta http-equiv="Content-Security-Policy" 
  content="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; 
           img-src 'self' data:; connect-src 'self' https://api.example.com; object-src 'none'">
```

**Restrict navigation and new window creation** to prevent the app from navigating to untrusted URLs:

```javascript
mainWindow.webContents.on('will-navigate', (event, url) => {
  if (!url.startsWith('https://trusted.example.com')) event.preventDefault();
});
mainWindow.webContents.setWindowOpenHandler(({ url }) => {
  shell.openExternal(url);
  return { action: 'deny' };
});
```

---

## 8. Monitoring desktop apps in production

### Crash reporting with Sentry

**Electron** has an official SDK (`@sentry/electron` v7.10.0) capturing Node errors in the main process, JS errors in renderers, and native crash minidumps. It includes built-in offline support (queuing events when disconnected), profiling via `browserProfilingIntegration()`, and automatic release/environment detection.

**Tauri** lacks an official Sentry SDK. The community plugin `tauri-plugin-sentry` (v0.5 for Tauri v2, by timfish) bridges browser and Rust events through a unified pipeline. It enriches browser events with Rust/OS context, merges breadcrumbs from both SDKs, and captures minidumps via `sentry-rust-minidump`:

```rust
let client = sentry::init(("__YOUR_DSN__", sentry::ClientOptions {
    release: sentry::release_name!(),
    auto_session_tracking: true,
    ..Default::default()
}));
let _guard = tauri_plugin_sentry::minidump::init(&client);
tauri::Builder::default()
    .plugin(tauri_plugin_sentry::init(&client))
    .run(tauri::generate_context!())?;
```

### Memory leak detection

Common Electron leak sources: detached DOM trees, `ipcMain.on()` listeners never removed after context reloads, `BrowserWindow` references not cleaned up on `closed`, and WebView cache accumulation. Detection tools include Chrome DevTools Memory tab (heap snapshots), `app.getAppMetrics()` for per-process metrics, Meta's `memlab` for automated E2E leak detection, and `process.memoryUsage()` for RSS/heap tracking. Always remove IPC listeners on unmount and verify listener counts with `ipcRenderer.listenerCount()`.

### GDPR-compliant telemetry

Under GDPR Article 6(1)(a), **active opt-in is required** before any data collection — pre-selected checkboxes are insufficient. Revocation must be as easy as granting consent (Article 7(3)). Consent must be documented. For desktop apps, show a clear dialog at first launch explaining exactly what data is collected (app version, OS, anonymous session IDs, feature usage counts, crash reports without PII) and what is never collected (file contents, personal information, browsing history). TelemetryDeck offers privacy-preserving analytics that anonymizes user IDs before transmission.

---

## 9. Multi-monitor, DPI scaling, and accessibility

### High-DPI handling

Electron uses Chromium's DPI handling with all coordinates in DIP (Device-Independent Pixels) by default. The `screen` module provides `scaleFactor`, `screenToDipPoint()`, and `dipToScreenPoint()` conversion methods. Known issues: dragging windows between monitors with different DPI can cause sizing issues on Windows; Linux DPI change awareness requires app restart.

Tauri exposes DPI through explicit `LogicalPosition`/`PhysicalPosition` and `LogicalSize`/`PhysicalSize` types, with `window.onScaleChanged()` events when displays change resolution or the window moves to a monitor with different scaling.

### Accessibility requires active effort

Both frameworks render HTML in WebViews that bridge to platform accessibility APIs: **UI Automation/IAccessible2** on Windows (used by NVDA, JAWS), **NSAccessibility** on macOS (VoiceOver), and **ATK/AT-SPI** on Linux (Orca). Electron auto-enables accessibility features when assistive technology is detected.

WCAG 2.1/2.2 guidelines apply fully to desktop WebView apps. Key implementation requirements: ARIA live regions for dynamic content updates (`aria-live="polite"`), proper focus management with focus traps in modals, semantic landmarks (`nav`, `main`), skip navigation links, and correct tree view patterns (`role="tree"`, `role="treeitem"`) for file-explorer-style interfaces common in desktop apps.

A **known Tauri accessibility regression** (issue #12901): NVDA stops reading text on mouse hover in frameless windows (`decorations: false`) since Tauri v2.3.0+. Standard window frames work correctly. There's also a Tauri multi-monitor bug on Linux/Wayland (issue #14019) where windows open on the primary monitor regardless of positioning commands.

---

## 10. AI-assistant configuration files in the ecosystem

### The electron/electron repo has a CLAUDE.md

The official Electron repository at `github.com/electron/electron` contains a CLAUDE.md providing guidance for AI assistants working with the codebase. It documents the `@electron/build-tools` CLI (`e build`, `e sync`, `e test`), the patching system for upstream Chromium/Node.js/V8 dependencies, PR requirements (bodies must include a `Notes:` section), backport policy across release lines, and code style conventions.

**The tauri-apps/tauri repository has no AI configuration files** — no CLAUDE.md, no .cursorrules, no SKILL.md, and no .claude/ directory.

### Community resources are richer than official repos

The most comprehensive Tauri AI configuration resource is **dchuk/claude-code-tauri-skills** (12 stars) with **39 SKILL.md files** covering Tauri v2 setup, security, development, and distribution. The **PatrickJS/awesome-cursorrules** collection (38.9K stars) includes both Tauri + Svelte + TypeScript .cursorrules and VSCode Extension (Electron/TypeScript) .cursorrules. Multiple specialized agents exist: `nodnarbnitram/claude-code-extensions` has a comprehensive Tauri v2 expert agent at `.claude/agents/specialized/tauri/tauri-v2-expert.md`, and `VoltAgent/awesome-claude-code-subagents` includes an Electron Pro subagent.

Several production Tauri and Electron apps maintain their own CLAUDE.md files: coollabsio/jean (Tauri 2 app), Rocket.Chat.Electron, 21st-dev/1code (Electron with tRPC + Drizzle + SQLite), and kizuna-ai-lab/sokuji (Electron 34 + React). The **Mindrally/skills** collection offers 240+ skills converted from .cursorrules to Claude Code SKILL.md format.

---

## Conclusion

The Tauri vs. Electron choice has become increasingly clear-cut by 2026. **Tauri 2.0 is the better default for new projects** when the team has Rust capability, bundle size matters, mobile support is needed, or security requirements are stringent — its permission-based ACL system, compiled Rust backend, and ~10× smaller footprint represent genuine architectural advantages. **Electron remains the pragmatic choice** when guaranteed cross-platform rendering consistency is non-negotiable, the team is JavaScript-only, or deep Node.js ecosystem integration is required.

Three patterns deserve emphasis. First, **security is not optional configuration — it's architecture**. Tauri's capabilities system and Electron's Fuses represent the industry moving toward deny-by-default postures where security is enforced at the framework level rather than left to developer discipline. Second, **offline-first has viable production tooling now**. PowerSync, Automerge 2.x, and Yjs have matured to the point where SQLite + LWW sync is a well-understood, battle-tested pattern for most desktop apps. Third, **CI/CD for desktop remains significantly more complex than web** — managing code signing certificates, platform-specific installer formats, and auto-update channels across three operating systems requires 6–11 GitHub Secrets and careful matrix strategy design, but the Tauri GitHub Action and Electron Forge have reduced this to mostly-declarative configuration.