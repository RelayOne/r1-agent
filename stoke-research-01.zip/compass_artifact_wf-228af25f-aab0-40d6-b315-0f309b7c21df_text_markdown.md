# Every user-facing string is an engineering artifact

**Content design has matured from a copywriting concern into a full engineering discipline**, complete with type-safe error registries, automated prose linting in CI/CD, ICU MessageFormat for pluralization-aware i18n, and accessibility-first component patterns. The companies that treat UI strings with the same rigor as code—Stripe's three-tier error taxonomy, Shopify Polaris's component-level content guidelines, GOV.UK's WCAG-compliant error summaries—consistently ship clearer, more accessible, and higher-converting products. This report covers 10 dimensions of content engineering with concrete tools, code patterns, and design system references, focused on practical implementation in a TypeScript/React codebase.

---

## Error taxonomies that actually help users recover

The difference between "Error 500" and "Upload failed: file exceeds 10MB limit" is not just UX polish—it's engineering architecture. World-class APIs structure errors as rich, machine-readable objects that serve both programmatic handling and human comprehension.

**Stripe** defines the gold standard. Every error response includes a `type` (one of `api_error`, `card_error`, `idempotency_error`, `invalid_request_error`), a machine-readable `code` (e.g., `card_declined`, `expired_card`), a human-readable `message`, the specific `param` that triggered the error, and a `doc_url` linking to documentation. Card errors carry a separate `decline_code` from the issuer. This three-tier classification—content errors (4xx), network errors, server errors (5xx)—maps cleanly to SDK exception classes like `StripeCardError` and `StripeRateLimitError`.

**Twilio** uses 5-digit numeric codes grouped by service domain: 10xxx for account errors, 21xxx for REST validation (21211 = invalid phone number), 30xxx for messaging, 60xxx for verification. Each error code page is a self-contained troubleshooting guide with severity level, description, possible causes, and solutions. Their error dictionary is downloadable as JSON and published as the `@twilio/voice-errors` npm package.

**AWS** uses PascalCase error codes (`NoSuchKey`, `AccessDenied`) with `RequestId` headers for support escalation. AWS explicitly notes their messages are developer-facing, not user-facing—a critical distinction that many teams miss. Every error includes the resource involved and unique request identifiers for debugging.

For your own codebase, the pattern that scales best combines a **typed error code registry** with **severity metadata** and **i18n-ready message templates**:

```typescript
// errors/codes.ts
export const ErrorCode = {
  VALIDATION_REQUIRED: 'VALIDATION_REQUIRED',
  PAYMENT_DECLINED: 'PAYMENT_DECLINED',
  NETWORK_TIMEOUT: 'NETWORK_TIMEOUT',
  AUTH_EXPIRED: 'AUTH_EXPIRED',
} as const;
export type ErrorCode = typeof ErrorCode[keyof typeof ErrorCode];

// errors/metadata.ts
export const ERROR_METADATA: Record<ErrorCode, {
  severity: 'critical' | 'error' | 'warning' | 'info';
  retryable: boolean;
  userFacing: boolean;
}> = {
  VALIDATION_REQUIRED: { severity: 'warning', retryable: false, userFacing: true },
  PAYMENT_DECLINED: { severity: 'error', retryable: true, userFacing: true },
  NETWORK_TIMEOUT: { severity: 'error', retryable: true, userFacing: true },
  AUTH_EXPIRED: { severity: 'critical', retryable: false, userFacing: true },
};
```

TypeScript's declaration merging enables a distributed registry pattern where each domain module registers its error types into a central interface—avoiding the growing-union problem that slows type-checking in large monorepos. The canonical error message template follows **[What happened] + [Why it matters] + [What to do next]**: "Your card was declined. Try a different payment method." Severity maps directly to UI patterns: critical errors get full-screen takeovers, high-severity errors get banners with forced action, medium gets inline errors, and low gets subtle hints.

---

## Microcopy conventions differ by platform and design system

The capitalization of a button label is not a trivial decision—it signals platform nativeness, brand voice, and cognitive load. **Apple's Human Interface Guidelines** use Title Case extensively across iOS and macOS (menu items, button labels like "Save Document"), while **Material Design M3** mandates sentence case for all UI elements. IBM Carbon goes further, **explicitly rejecting both Title Case and ALL CAPS** for UI text, arguing sentence case is faster to read and easier for contributors to apply consistently.

Button labels across all major design systems converge on three rules: use a **verb** (almost always), keep it to **three words maximum** (per Carbon), and **never use generic labels** like "OK/Cancel" when specific labels like "Save/Discard" are possible. Carbon maintains a comprehensive action labels reference distinguishing 30+ verbs—`Add` (existing object to new context) vs. `Create` (instantiate new object) vs. `Insert` (into existing structure)—with precise usage guidance for each.

**Confirmation dialogs** represent a critical microcopy pattern. The structure is: title restating the action ("Delete 'Holiday Campaign'?"), body explaining consequences ("This will permanently remove the campaign and its 2,340 subscribers"), a primary destructive button matching the action verb ("Delete campaign"), and a secondary safe exit ("Keep campaign"). For extremely destructive actions, add friction by requiring the user to type the resource name—a pattern GitHub and MailChimp popularized. The "Cancel Cancel" problem (when the destructive action IS cancellation) resolves with patterns like "Cancel order" (red) / "Keep order."

**Shopify Polaris** offers perhaps the most comprehensive content system in any design system. Its four pillars—content-design partnership, lean writing, merchant-voiced language, and action-inspiring copy—are backed by a target **7th-grade reading level** and the practical test: "Read it out loud. Does it sound like something a human would say? Ship it." Every Polaris component includes specific content guidelines, and the system documents grammar rules (American English, contractions encouraged, no ampersands, no colons before radio buttons).

**GitHub Primer** targets seventh-grade or below reading level and maintains strict rules: "pull request" is never abbreviated, GitHub is always capitalized correctly, sentence case is the default (when in doubt, don't capitalize), and exclamation marks are "not appropriate in most cases." Loading states follow time-based guidelines: no indicator under 1 second, spinners for 1–3 seconds, progress bars for 3–10 seconds, and detailed status updates with background operation options beyond 10 seconds.

---

## Enforcing terminology consistency across a codebase

Calling something "Project" in the sidebar and "Workspace" in the settings page erodes user trust. Terminology enforcement spans from human processes (content audits, glossary spreadsheets) to fully automated pipelines.

**Vale** is the most widely adopted prose linter for this purpose. Open-source and CLI-based, it runs locally (no data leaves your machine) and understands Markdown, HTML, reStructuredText, and XML. Rules are YAML files organized into "styles":

```yaml
# styles/MyCompany/Terminology.yml
extends: substitution
message: "Use '%s' instead of '%s'."
level: error
ignorecase: true
swap:
  click on: select
  e-mail: email
  log into: sign in to
  dropdown: drop-down menu
```

Vale supports substitution, existence (banned words), occurrence limits, consistency enforcement, and full regex patterns. Pre-built style packages exist for Microsoft, Google, write-good, and proselint. Companies using Vale in CI include **GitLab**, **Grafana**, **Datadog** (which created `datadog-vale` as their single source of truth), and **Contentsquare** (building a company-wide Vale package synced across all repositories). The `errata-ai/vale-action` GitHub Action posts findings as PR review comments.

**textlint** offers a Node.js-native alternative with plugin architecture. Its `textlint-rule-terminology` enforces correct technical terms, while `textlint-rule-alex` catches insensitive or ableist language ("cripple" → "person with a limp", "obviously" flagged as condescending). **alex** specifically checks for gendered language, ableist phrasing, condescending terms, and profanities—used by React Native, Ember.js, and many open-source projects.

For content design tokens, the most practical implementation today uses i18n systems as the content token layer. Elastic UI's `EuiI18n` component makes this explicit with a `token` + `default` pattern: `<EuiI18n token="euiComboBox.clearSelection" default="Clear selection" />`. A centralized TypeScript content file achieves the same for non-i18n codebases, where every user-facing string is imported from a structured `CONTENT` object rather than hardcoded inline.

---

## Internationalized error messages that handle plurals, gender, and locale

Hardcoding "You have 1 files remaining" is the kind of bug that survives code review but dies in translation. ICU MessageFormat, implemented by FormatJS (`react-intl`) and i18next, handles pluralization, gender selection, and locale-aware formatting natively:

```
{count, plural,
  =0 {No files failed to upload.}
  one {# file failed to upload.}
  other {# files failed to upload.}
}
```

For error messages with dynamic values, `react-intl`'s `defineMessages` pattern provides compile-time extraction and type safety:

```tsx
const errorMessages = defineMessages({
  fileTooLarge: {
    id: 'errors.upload.fileTooLarge',
    defaultMessage: 'File "{fileName}" exceeds the {maxSize, number} MB limit.',
    description: 'Error when uploaded file is too large',
  },
  retryIn: {
    id: 'errors.rateLimit.retryIn',
    defaultMessage: 'Too many attempts. Try again in {seconds, plural, one {# second} other {# seconds}}.',
  },
});
```

Translation key hierarchies should follow the pattern `namespace:feature.component.element` with **maximum 2–3 levels** of nesting. A well-structured errors namespace looks like `errors.validation.required`, `errors.payment.cardDeclined`, `errors.network.timeout`, `errors.auth.sessionExpired`. Best practices from Lokalise, Locize, and Phrase converge on: pick camelCase or snake_case and stick with it, use descriptive keys over literal ones, never interpolate variables in key names, and mirror file structure to namespaces (`locales/en/errors.json`).

i18next v23+ supports full TypeScript type-checking of translation keys through declaration merging—`t('errors:payment.cardDeclined')` will produce a compile error if the key doesn't exist in your resource files. For locale-aware formatting, ICU number skeletons handle currencies (`{amount, number, ::currency/USD}` renders as "$1,234.56" in en-US and "1.234,56 $" in de-DE) and dates (`{date, date, long}` renders as "January 15, 2026" in English and "15. Januar 2026" in German).

---

## Empty states are onboarding opportunities, not error conditions

An empty state is the first impression of every feature. **Notion** treats empty states as the onboarding experience itself—new workspaces contain a functional checklist that IS demo content, teaching by doing. Based on signup survey data, Notion presents a curated shortlist of 5 relevant templates rather than its full library, because **choosing is always easier than imagining**. Guided empty states reportedly increase activation by **30–40%**.

**Linear** uses contextual empty states tailored to each feature, with clean monochrome illustrations and copy explaining the feature's value proposition. **Figma** never shows blank screens for first-time users, populating the file browser with sample projects and design templates.

The canonical empty state component combines illustration, message, and CTA. Atlassian's `@atlaskit/empty-state` provides the reference implementation with props for `header`, `description`, `primaryAction`, `secondaryAction`, `tertiaryAction`, `imageUrl`, and `headingLevel`. ServiceNow's Horizon Design System documents **12 distinct empty state use cases** (first-time experience, no search results, permission denied, not configured, etc.), each available in three sizes.

A critical distinction exists between zero-data states (first-time, no content—focus on education and creation CTAs) and no-results states (search returned nothing—focus on recovery, suggesting filter removal or alternative terms). NNGroup warns: **never show "No records" while data is still loading**—distinguish genuinely empty from still-loading states explicitly.

Progressive onboarding through empty states evolves across user maturity: Day 1 shows rich onboarding with illustrations and detailed explanations; activated users see simpler description + CTA; power users get minimal "No items yet" with a quick-action button.

---

## Help text follows a four-layer progressive disclosure architecture

Contextual help should follow a layered architecture where each level adds depth without cluttering the base experience:

**Layer 1 (always visible)**: Labels, persistent helper text below fields, field sizing hints. Helper text should never disappear on focus and must be linked to inputs via `aria-describedby`.

**Layer 2 (on-demand)**: Tooltips triggered by hover or focus. Intuit's content design guidelines set the standard: tooltips should be "the exception, not the rule" with a maximum of **60 characters for headers and 130 characters for body** (3 lines). Never include links in tooltips (inaccessible to keyboard users), never use them as a band-aid for poor design, and if you can't think of helpful content, don't offer one.

**Layer 3 (requested)**: Expandable sections, "Learn more" links opening inline panels, and popovers with rich content. Stripe's Dashboard architecture exemplifies this with its ContextView (in-context help) and FocusView (deeper workflows with blocking backdrop).

**Layer 4 (deep dive)**: Links to external documentation, help center articles, and video tutorials. Atlassian's design system includes Spotlight (onboarding), Inline Message (contextual info), and Section Message (page-level context) components that map to these progressive layers.

For form fields specifically, the type hierarchy is: label above the field (required, always visible), helper text below (persistent guidance), placeholder inside (formatting examples only—**never as a label substitute**), tooltip on icon (supplementary), error text replacing helper text on validation failure, and character counter for constrained inputs.

---

## Consent copy must balance legal compliance with human language

GDPR, CCPA, and CASL each impose distinct UI requirements. **GDPR** requires cookie consent with Accept and Reject buttons of **identical visual weight** (the EDPB Cookie Banner Taskforce explicitly prohibits asymmetric button design), freely given consent that cannot be conditional on service access, and separate checkboxes for each consent purpose. Pre-ticked boxes are invalid per the CJEU Planet49 ruling.

**CCPA/CPRA** operates on an opt-out model rather than GDPR's opt-in. The key UI requirement is a "Do Not Sell or Share My Personal Information" link on the homepage footer. The Global Privacy Control (GPC) browser signal must be honored as an opt-out. CPRA explicitly states that "agreement obtained through use of dark patterns does not constitute consent."

**CASL** (Canada's Anti-Spam Legislation) requires three mandatory elements in every commercial electronic message: express consent obtained through active opt-in (the checkbox must be unchecked by default), sender identification (name, valid mailing address, phone/email/URL), and an unsubscribe mechanism functional for at least 60 days. Penalties reach **$10M per violation for businesses**, and the request for consent itself is a CEM—you cannot email someone to ask for permission to email them. Express consent template:

```
☐ I consent to receive commercial electronic messages from [Company Name]
([Address], [Contact]) about [products/promotions/updates].
I can unsubscribe at any time.
```

Legal copy should be externalized from code into a CMS or headless API so legal teams can update without deployments. Version legal documents and track user acceptance of specific versions. Create `<ConsentCheckbox>` and `<CookieBanner>` as design system primitives. Services like Termageddon provide API-based policy content with React integration, and `react-iubenda-policy` offers drop-in components for privacy, cookie, and ToS policies.

---

## Accessible content requires both semantic markup and plain language

WCAG 2.1 SC 3.1.5 (Level AAA) requires content to be readable at a lower secondary education level—approximately **US Grade 7–8**. GOV.UK goes further, targeting a reading age of 9. While AAA is aspirational, the practical benefits are universal: plain language supports people with cognitive disabilities, non-native speakers, screen reader users (shorter sentences reduce working memory load), and everyone else through reduced cognitive load.

For dynamic error announcements, the correct pattern combines an **error summary at the page top** with **inline errors per field**. The summary uses `role="alert"` and receives keyboard focus via `tabIndex={-1}` with `.focus()`, while inline errors connect to inputs via `aria-describedby` and set `aria-invalid="true"` on the field. GOV.UK's approach—the most thoroughly tested pattern—also prefixes the page `<title>` with "Error:" so screen reader users know immediately that submission failed.

```tsx
const AccessibleInput: React.FC<Props> = ({ id, label, error, helpText, required }) => {
  const describedBy = [helpText ? `${id}-help` : null, error ? `${id}-error` : null]
    .filter(Boolean).join(' ') || undefined;
  return (
    <div>
      <label htmlFor={id}>{label}{required && <span className="sr-only">(required)</span>}</label>
      {helpText && <p id={`${id}-help`}>{helpText}</p>}
      <input id={id} aria-required={required || undefined}
        aria-invalid={error ? true : undefined} aria-describedby={describedBy} />
      {error && <p id={`${id}-error`} role="alert">{error}</p>}
    </div>
  );
};
```

**aria-live regions** handle non-error dynamic content: `polite` waits until the screen reader finishes the current sentence (use for most updates), `assertive` interrupts immediately (only for critical alerts). The container must exist in the DOM before content changes. Adobe's **react-aria-components** provides the most ergonomic approach, auto-managing `aria-describedby`, `aria-invalid`, and label associations.

Automated accessibility testing with `jest-axe` catches roughly **30–40% of issues**—manual testing with real screen readers (JAWS, NVDA, VoiceOver) remains essential. The `eslint-plugin-jsx-a11y` catches static accessibility violations at lint time.

---

## Automated content quality pipelines treat prose like production code

The most impactful engineering practice in content design is treating every user-facing string as a testable artifact in CI/CD. A comprehensive content quality pipeline layers four checks:

**Prose linting** with Vale enforces style guide rules, terminology, and readability scores on every pull request. Configure it to run on i18n JSON files or extracted string catalogs since Vale doesn't natively parse TSX.

**Code linting** with custom ESLint rules catches hardcoded strings. BigBinary's `eslint-plugin-neeto` flags string literals containing spaces in JSX (filtering out enum keys and CSS classes) with a whitelist (e.g., `className` prop ignored) and blacklist (e.g., `label` prop always flagged). The built-in `eslint-plugin-react` rule `jsx-no-literals` and `eslint-plugin-i18next` detect untranslated strings.

**Translation QA** validates that all localized files have matching placeholders, correct format specifiers, and reasonable length ratios against the source language. Critical checks (missing placeholders) should block deployment; non-critical (length warnings) generate warnings.

**Visual regression** via Percy or Chromatic renders every component in each locale and compares screenshots. Percy's OCR reduces false positives from minor text shifts. The pattern is straightforward: iterate over locales × pages, capture screenshots, and diff against baselines.

```yaml
# .github/workflows/content-quality.yml
name: Content Quality
on: [pull_request]
jobs:
  prose-lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: errata-ai/vale-action@v2
        with: { reporter: github-pr-review, fail_on_error: true }
  inclusive-language:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npx alex src/locales/**/*.json
  a11y-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npm run test:a11y
```

A/B testing microcopy produces dramatic results when applied systematically. Changing "Request a quote" to "Request pricing" increased lead-gen clicks by **161%** at Veeam. Replacing "Continue" with "Review Order" lifted CTR by **39%** at Insound. Pinterest built an internal tool called **Copytune** specifically for testing copy in multiple languages, discovering that different copy wins in different locales. The consistent finding: clarity beats cleverness, and benefit-driven CTAs outperform generic ones.

For readability scoring in CI, Vale's Readability package implements Flesch-Kincaid, SMOG, and Coleman-Liau as enforceable rules. Hemingway Editor has no API—for programmatic use, implement the well-documented Flesch-Kincaid formulas directly or use Vale. Target **Flesch Reading Ease of 60–80** and **Grade Level 6–8** for UI copy.

---

## Conclusion: the content engineering stack for 2026

The essential toolchain for treating content as engineering: **Vale** for prose linting and terminology enforcement in CI, **react-intl** or **i18next** (with TypeScript declarations) for type-safe i18n with ICU MessageFormat, **react-aria-components** for accessible form patterns with automatic ARIA management, **eslint-plugin-i18next** to catch hardcoded strings, **Percy or Chromatic** for visual regression across locales, and **alex** for inclusive language checking. Store all UI strings in structured files separate from components—whether as i18n resources or centralized content token files. Every error message should carry typed metadata (severity, retryability, user-facing flag) alongside its translated template. Every empty state should be a designed onboarding moment, not a blank screen. Every confirmation dialog should describe consequences, not just actions. The companies winning at content engineering—Stripe, Shopify, GitHub, GOV.UK—share one insight: the words in the interface ARE the interface, and they deserve the same engineering rigor as every other system component.