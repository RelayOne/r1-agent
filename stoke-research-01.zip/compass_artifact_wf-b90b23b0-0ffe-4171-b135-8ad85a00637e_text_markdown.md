# The complete Cloudflare Workers operational guide for AI coding agents

**Cloudflare Workers runs V8 isolates — not containers — and this single architectural fact cascades into every constraint, pattern, and pitfall that AI agents get wrong.** This guide covers the full ecosystem as of early 2026: runtime limits, storage trade-offs, Durable Objects patterns, security configuration, performance optimization, and tooling. It is written for developers who already deploy Workers alongside Google Cloud Run backends and need precise operational knowledge, not introductory tutorials. Every number, limit, and pricing figure reflects the latest documentation.

---

## 1. The skills repo teaches agents to build on Cloudflare correctly

The `cloudflare/skills` repository on GitHub (~700 stars) is not a tutorial collection — it is a structured knowledge base designed for AI coding agents (Claude Code, Cursor, Codex, and others) following Anthropic's skills standard. It contains **9 skills** and **50+ product reference directories**, each organized with a consistent `SKILL.md` manifest plus `references/<product>/` subdirectories containing `api.md`, `configuration.md`, `patterns.md`, and `gotchas.md` files.

The nine skills are: **`cloudflare`** (comprehensive platform skill covering all products with decision trees), **`agents-sdk`** (stateful AI agents with WebSockets and scheduling), **`durable-objects`** (stateful coordination with SQLite, alarms, and WebSockets), **`wrangler`** (CLI configuration and deployment), **`workers-best-practices`** (anti-patterns like floating promises, global state, and binding misuse), **`building-mcp-server-on-cloudflare`** (MCP servers with OAuth 2.1), **`building-ai-agent-on-cloudflare`** (end-to-end agent construction), **`sandbox-sdk`** (secure code execution), and **`web-perf`** (Core Web Vitals auditing).

The architectural philosophy is **retrieval over pre-training**. Every skill instructs agents to fetch live documentation from `developers.cloudflare.com` rather than rely on training data. Decision trees in `SKILL.md` files route agents to the right product: "I need to run code" branches to Workers vs Pages vs Durable Objects vs Workflows vs Containers; "I need to store data" branches to KV vs D1 vs R2. The `workers-best-practices` skill explicitly documents anti-patterns — use bindings not REST APIs from within Workers, use `ctx.waitUntil()` for background work, use Service Bindings for Worker-to-Worker calls, never store mutable request-specific state in module scope. Two slash commands (`/cloudflare:build-agent` and `/cloudflare:build-mcp`) and four MCP server connections (docs, bindings, builds, observability) extend the skills beyond static reference into interactive tooling.

---

## 2. Runtime constraints AI agents consistently get wrong

### CPU time is not wall-clock time

The single most common mistake AI agents make is confusing CPU time with wall-clock time. A Worker making 10 `fetch()` calls that each take 1 second uses **~0ms of CPU time** for the waiting. Free tier Workers get **10ms of CPU time** per invocation. Paid Workers get **30 seconds by default**, configurable up to **5 minutes** (300,000ms) via `limits.cpu_ms` in wrangler config. The average Worker uses ~2.2ms CPU per request. HTTP requests have **no wall-clock limit** while the client remains connected, but Cron Triggers and Queue Consumers cap at **15 minutes** wall time. Exceeding CPU limits returns Error 1102 with outcome `exceededCpu`.

### Bundle size limits have changed dramatically

AI agents frequently cite the obsolete 1MB limit. Current limits are **3MB compressed** (free) and **10MB compressed** (paid), with a **64MB uncompressed** ceiling for both tiers. Script metadata is capped at 1MB per Worker. Enabling `nodejs_compat_v2` increases bundle size due to injected polyfills.

### Node.js compatibility is extensive but not complete

With the `nodejs_compat` flag and `compatibility_date >= 2024-09-23`, Workers natively support `node:crypto`, `node:buffer`, `node:stream`, `node:dns`, `node:net` (client only), `node:tls`, `node:zlib`, `node:assert`, `node:events`, `node:path`, `node:url`, `node:util`, `node:timers`, and `node:console`. As of August 2025, `node:fs` provides an **ephemeral virtual filesystem** — per-request isolated in stateless Workers, shared within Durable Objects, **never persistent across deployments**. `node:http` and `node:https` client APIs became default from compatibility date 2025-08-15, with server APIs (`http.createServer`) from 2025-09-01 — Express and Koa now work directly. Completely unavailable: `node:child_process`, `node:cluster`, `node:worker_threads`, `node:vm`, `node:os`, `node:dgram`, and `SharedArrayBuffer` (disabled for Spectre mitigation).

### The V8 isolate model has specific memory and connection limits

Each isolate gets **128MB of memory** (heap + WebAssembly). Startup must complete within **1 second**. Subrequest limits are **50** (free) and **10,000** (paid, configurable to 10 million), but the **6 simultaneous open connections** hard limit is the real constraint — additional attempts queue, and not consuming response bodies (`response.body.cancel()`) frees connections. Environment variables cap at **64** (free) / **128** (paid) per Worker, **5KB each**. Request body limits follow Cloudflare account plan: **100MB** (Free/Pro), **200MB** (Business), **500MB** (Enterprise). Workers per account: **100** (free) / **500** (paid).

### Service Worker syntax is deprecated

AI agents frequently generate `addEventListener('fetch', ...)` syntax. ES modules format (`export default { fetch() {} }`) is required for all new features including versioned deployments, RPC, and Durable Objects. The `env` parameter in the handler provides bindings — `process.env` works only with `nodejs_compat` enabled and auto-populates from bindings starting with compatibility date 2025-04-01.

---

## 3. Durable Objects implement a single-threaded actor model with nuanced concurrency

### Core execution model

Each Durable Object runs in **exactly one location**, in one thread, worldwide. They are created lazily on first access and process requests sequentially — but JavaScript's async/await means multiple requests interleave at `await` points. **Input gates** automatically prevent new events from being delivered while storage operations execute, giving serializable consistency without explicit locking. A single DO handles approximately **500–1,000 requests/second** for simple operations.

### WebSocket hibernation cuts costs by orders of magnitude

The Hibernatable WebSocket API (`ctx.acceptWebSocket()`) is essential for cost control. With standard `ws.accept()`, duration charges accrue for the entire connection lifetime. With hibernation, the DO evicts from memory while clients stay connected to Cloudflare's network — **no duration charges during hibernation**. When a message arrives, the runtime re-creates the DO (runs the constructor), and `webSocketMessage(ws, message)` handles the message. Use `ws.serializeAttachment(value)` to persist per-connection metadata across hibernation, and `ctx.getWebSockets(tag?)` in the constructor to rebuild connection tracking. `setWebSocketAutoResponse()` handles ping/pong without waking the DO. Maximum WebSocket message size is **32MiB**.

### Alarms provide guaranteed at-least-once scheduling

Each DO gets **one alarm** at a time via `ctx.storage.setAlarm(timestamp)`. Alarms retry with exponential backoff up to **6 times**. For cron-like behavior, have `alarm()` process work then call `setAlarm()` for the next interval. Critical gotcha: never call `setAlarm()` unconditionally in the constructor — it interferes with pending alarms after hibernation wake-up. Alarms execute within milliseconds of the set time but can delay **up to a minute** during maintenance.

### SQLite storage is the recommended backend

**SQLite is recommended for all new DO classes** (GA since 2025). Each DO gets a private embedded SQLite database up to **10GB** (paid) or **1GB** (free). SQL operations via `ctx.storage.sql.exec()` are **synchronous** — zero-latency local disk access means the N+1 query pattern is actually fine. Supported extensions include FTS5 (full-text search) and JSON functions. Use `transactionSync(callback)` for atomic multi-statement operations. Schema migrations should use `blockConcurrencyWhile()` in the constructor with a custom `_sql_schema_migrations` table since `PRAGMA user_version` is not supported. Point-in-Time Recovery enables restoration to any point in the past 30 days.

### Location hints versus jurisdiction restrictions

Location hints (`{ locationHint: "enam" }`) are **best-effort** and only affect the first `get()` call for a new object. Jurisdiction restrictions (`env.MY_DO.jurisdiction("eu")`) **guarantee** objects only run and store data within the specified jurisdiction — critical for GDPR compliance. Workers can access jurisdiction-restricted DOs from anywhere, adding latency for distant callers. Key footgun: if the first request creating a DO originates from your Cloud Run origin (e.g., in Ohio), all DOs created from that path pin near Ohio. Create DOs from edge Workers near end users.

### Billing model

Paid plan includes 1M requests and 400,000 GB-seconds. Additional requests cost **$0.15/million**; duration costs **$12.50/million GB-seconds** at 128MB allocation. WebSocket messages bill at a **20:1 ratio** (100 messages = 5 billed requests). SQLite storage billing (live since January 2026) mirrors D1: **$0.001/million rows read**, **$1.00/million rows written**, **$0.20/GB-month** stored, with 25B reads, 50M writes, and 5GB included.

---

## 4. Storage products serve fundamentally different access patterns

| Dimension | KV | D1 | Durable Objects | R2 |
|---|---|---|---|---|
| **Consistency** | Eventually consistent (~60s) | Strong (single primary) | Strictly serializable | Strong per object |
| **Read latency** | 500µs–10ms cached | Low with replicas; variable to primary | Sub-ms in-memory | Medium-high |
| **Write model** | 1 write/sec per key, last-write-wins | All writes to single primary | Single-threaded per object | S3-compatible PUT |
| **Max item/DB size** | 25 MiB per value | 10 GB per database | 10 GB per object (SQLite) | ~5 TiB per object |
| **Query model** | Get/Put/Delete/List by key | Full SQL (SQLite) | SQL or KV API, in-memory | S3 API |
| **Storage cost** | $0.50/GB-month | $0.75/GB-month | $0.20/GB-month (SQLite) | **$0.015/GB-month** |
| **Read cost** | $0.50/M | $0.001/M rows | $0.001/M rows | $0.36/M Class B ops |
| **Write cost** | $5.00/M | $1.00/M rows | $1.00/M rows | $4.50/M Class A ops |
| **Egress** | Free | Free | Free | **Free** |
| **Free tier storage** | 1 GB | 5 GB | 5 GB | 10 GB |

**KV** is for read-heavy, infrequently-written data: configuration, feature flags, session tokens, cached API responses. It is not for counters, real-time data, or anything needing immediate global consistency. The 1-write-per-second-per-key limit and ~60-second propagation delay are hard constraints.

**D1** is for relational application data needing SQL queries, with a 10GB per-database limit addressed by creating many databases (up to 50,000 per account). Read replication (beta) provides near-edge reads with sequential consistency via the Sessions API. Throughput is single-threaded per database — approximately 1,000 QPS for simple queries.

**Durable Objects** are for real-time coordination: chat rooms, multiplayer games, rate limiters, distributed locks, state machines. Strong consistency comes from single-location, single-threaded execution — which means cross-region latency for distant callers.

**R2** is for large objects and files with its zero-egress-fee model. At $0.015/GB-month it is **33x cheaper** than KV for bulk storage and offers S3 API compatibility for multi-cloud portability.

The practical combination pattern: KV for session/config at the edge, D1 for relational data, R2 for files and media, and Durable Objects for real-time coordination. Use KV as a cache layer for D1 to distribute reads globally.

---

## 5. Performance optimization centers on CPU time, bundle size, and caching

### Module syntax and streaming are the foundation

ES modules (`export default {}`) is the only supported path for new features. For streaming, the critical insight is that Cloudflare optimizes **pass-through streaming**: when a Worker returns a response body without modification, the isolate is marked idle after headers are sent, reducing billed duration by ~70%. Always prefer `return new Response(response.body, response)` over buffering with `await response.text()`.

For generated streams (SSE, AI responses), use `TransformStream` with `ctx.waitUntil()` to keep the Worker alive after returning the readable side. Use `IdentityTransformStream` for byte-forwarding and `FixedLengthStream` when total size is known (enables Content-Length instead of chunked encoding).

### Cache API has critical Cloudflare-specific behaviors

Two approaches exist: `fetch()` with the `cf` object integrates with Cloudflare's tiered cache and CDN; the Cache API (`caches.default` / `caches.open()`) provides direct control but is **per-datacenter only** and does not work with Tiered Cache. The Cache API is the only option for caching Worker-generated responses. Critical constraint: **Cache API does not work on `*.workers.dev` domains** — it requires a custom domain. Responses with `Set-Cookie` are never cached.

### Cold starts are nearly eliminated

Cloudflare's "Shard and Conquer" routing (2025) achieves a **99.99% warm start rate** by using consistent hash rings to route all requests for a specific Worker to a single shard server per datacenter, eliminating redundant cold starts. TLS handshake pre-warming runs Worker initialization in parallel with the client handshake, hiding the sub-5ms isolate startup time. Developer-side: minimize top-level code, reduce bundle size, and use dynamic imports for route-specific code.

### Smart Placement reduces multi-hop latency

When a Worker makes multiple subrequests to a centralized backend (your Cloud Run service), Smart Placement moves Worker execution near the backend instead of the user. Enable with `"placement": { "mode": "smart" }` or use explicit Placement Hints with `"hint": { "region": "gcp:us-east4" }` when you know your backend location. It takes ~15 minutes to analyze traffic. Only affects `fetch` event handlers — not RPC or cron triggers. For the Workers + Cloud Run architecture, use a front-end Worker at the edge for auth/caching/routing connected via Service Bindings to a backend Worker with Smart Placement near your Cloud Run region.

---

## 6. Edge architecture patterns for Workers plus Cloud Run

### What belongs at the edge versus origin

Compute at the edge: JWT validation, rate limiting, bot detection, A/B testing, geo-based personalization, response caching, HTML transformation via `HTMLRewriter`, simple CRUD via Hyperdrive, and header/cookie manipulation. Delegate to Cloud Run: complex business logic exceeding 10ms CPU, multi-step transactions, image/PDF generation, ML inference, long-running async processing, and operations requiring the full Node.js ecosystem.

The hybrid architecture pattern routes requests through a Worker that handles auth and caching, then selectively forwards to Cloud Run. Pass an internal shared secret (`X-Internal-Key`) for Worker→Cloud Run trust. For private Cloud Run services, authenticate using Google service account JWTs signed with SubtleCrypto — the standard Google Cloud SDK cannot run in Workers.

### Geographic data residency

Durable Objects support `"eu"` and `"fedramp"` jurisdictions via `env.MY_DO.jurisdiction("eu")`, guaranteeing data stays within those boundaries. R2 buckets accept jurisdictional restrictions at creation time (immutable after). Workers themselves can be constrained via Regional Services (Enterprise only). For non-Enterprise, there is no guaranteed region pinning for Workers — only location hints for Durable Objects and Smart Placement for compute proximity.

### Hyperdrive eliminates database connection overhead

Without Hyperdrive, every Worker invocation requires **7 round-trips** (TCP + TLS + auth) before executing a query — roughly 1200-1500ms. Hyperdrive maintains connection pools near your database, reducing this to ~500ms (connection pooling) or ~320ms (with query caching). It operates in **transaction pooling mode** and caches read queries for 60 seconds by default.

Supported databases: **PostgreSQL** (GA) via node-postgres or Postgres.js, and **MySQL** (Beta) via mysql2. Compatible with Drizzle ORM and Prisma. Critical gotchas: always create database clients inside the `fetch()` handler (never global scope), never use `Pool()` or `createPool()` (Hyperdrive IS the pool), and know that function names in SQL comments (even `-- removed NOW()`) prevent query caching because detection is text-based. Free tier: 100,000 queries/day; paid: unlimited. No additional cost beyond Workers pricing.

---

## 7. Queues handle async work while Workflows orchestrate multi-step processes

### Queues deliver at-least-once with no ordering guarantees

Queues (GA since September 2024) provide a managed message queue with push-based (Worker consumer) or pull-based (HTTP) consumption. **At-least-once delivery** is guaranteed — consumers must design for idempotency. Messages have **no ordering guarantee**. Each queue supports only **one active consumer**. Maximum message size is **128KB**; throughput caps at **5,000 messages/second** per queue with a **25GB backlog**.

Retry configuration: default 3 retries (max 100), configurable delay up to 12 hours. Implement exponential backoff manually using `msg.attempts`. Dead letter queues are auto-created if named but nonexistent; messages failing all retries without a DLQ are **discarded**. Batch processing: up to 100 messages per batch with 60-second timeout. Use explicit `msg.ack()` and `msg.retry()` for per-message control — otherwise batch-level failure retries the entire batch.

Pricing: **$0.40/million operations** after 1M included, where each 64KB chunk written, read, or deleted counts as one operation. A typical message lifecycle costs 3 operations.

### Workflows provide durable multi-step orchestration

Workflows (GA since April 2025) extend `WorkflowEntrypoint` with step-based execution. Each `step.do()` persists its return value durably — once complete, a step **never re-executes** even if the workflow restarts. Steps can sleep up to **365 days** via `step.sleep()` or wait for external events via `step.waitForEvent()`. Maximum **10,000 steps** per instance (configurable to 25,000), with 1MiB max state per step and 1GB per instance.

The key distinction: **Queues answer "do this later"** (independent tasks, fan-out, rate-limited API calls). **Workflows answer "do these things in order"** (order processing, approval flows, AI pipelines). **Durable Objects answer "coordinate this now"** (real-time state). Concurrent Workflow instances: up to **10,000** (raised October 2025). Pricing is identical to Workers Standard: $0.30/million invocations, $0.02/million CPU-ms, $0.20/GB-month storage.

---

## 8. Edge security operates through a defined evaluation order

Security features evaluate in this order: DDoS Protection → URL Normalization → **Custom WAF Rules** → **Rate Limiting Rules** → Super Bot Fight Mode → **WAF Managed Rules** → Access Rules. A Skip rule in Custom Rules can bypass Rate Limiting, SBFM, and Managed Rules but cannot bypass Access Rules or Bot Fight Mode.

### WAF and bot management

Cloudflare provides five managed rulesets: Cloudflare Managed (CVEs, SQLi, XSS), OWASP Core (anomaly scoring with paranoia levels PL1–PL4), Exposed Credentials Check, Sensitive Data Detection, and a Free subset. Custom rules use Rules Language expressions with actions in precedence order: Block → Managed Challenge → Interactive Challenge → Skip → Log. Rule limits: Free 5, Pro 20, Business 100, Enterprise 1000+.

Bot Management (Enterprise) exposes `request.cf.botManagement` in Workers with a **1–99 score** (1 = definitely automated, 50+ = likely human), `verifiedBot` boolean, `ja3Hash`/`ja4` fingerprints, and `jsDetection.passed`. Non-Enterprise plans get Bot Fight Mode (no score access, no Workers integration) or Super Bot Fight Mode (fixed groupings, Skip-only WAF integration).

### Rate limiting at WAF and Workers levels

WAF-based rate limiting runs in the `http_request_ratelimit` phase with configurable characteristics (IP, API key header, visitor ID), periods (10s to 3600s), and actions. Workers-based rate limiting via the binding API (`env.RATE_LIMITER.limit({ key })`) is **per-location** (not global) and eventually consistent — fast but permissive. For precise global rate limiting, use Durable Objects as centralized counters. Workers subrequests to the same zone count toward rate limits — exclude them with `cf.worker.upstream_zone` expressions.

### SSL/TLS modes and common mistakes

**Full (Strict)** is the only production-appropriate mode — it validates origin certificates. Flexible mode sends plaintext between Cloudflare and origin (dangerous). Full mode accepts expired and self-signed certificates (vulnerable to MITM). Install a free Cloudflare Origin CA certificate (15-year validity) and set Full (Strict). Automatic SSL/TLS (rolling out 2025+) probes origins and selects the most secure mode automatically.

### Cloudflare Tunnel eliminates origin exposure

`cloudflared` creates **outbound-only, post-quantum encrypted connections** to Cloudflare — no inbound ports, no public IPs, no attack surface. Each tunnel maintains 4 connections to 2 datacenters. Run up to 25 replicas for high availability. Best practice: block ALL inbound traffic on origin firewall, ensure the origin IP never appears in DNS records.

### mTLS in Workers

Verify incoming client certificates via `request.cf.tlsClientAuth` (checking `certPresented`, `certVerified`, extracting subject/issuer DN and fingerprints). For outbound mTLS to external services, bind certificates via `mtls_certificates` in wrangler config and use `env.MY_CERT.fetch()`. New RFC 9440 fields (March 2026) standardize certificate chain forwarding to origins.

---

## 9. Wrangler CLI has shifted to JSON config and versioned deployments

### Configuration format and environments

**`wrangler.jsonc` is now the recommended format** for new projects, with JSON Schema support for IDE intellisense. `npm create cloudflare@latest` generates it by default. Environments are defined under `env.<name>` keys and create separate Workers named `<name>-<environment>`. Critical rule: **bindings are non-inheritable** — `vars`, `kv_namespaces`, `d1_databases`, `r2_buckets`, and `durable_objects` must be explicitly redefined in each environment block. `wrangler deploy` **overwrites dashboard settings** unless `keep_vars = true` is set.

### Secrets and local development

Secrets are set via `wrangler secret put` (deployed immediately) or `wrangler versions secret put` (for gradual deployments). Local development uses `.dev.vars` or `.env` files (never both — `.dev.vars` takes precedence). Declare required secrets in config under `"secrets": { "required": ["API_KEY"] }` for deploy-time validation. Each secret is limited to **5KB**.

`wrangler dev` runs locally using Miniflare (the same workerd runtime as production) with built-in hot reloading and data persistence in `.wrangler/state/v3/`. Use `"remote": true` on individual bindings to hit real deployed resources during local dev. Durable Objects and Workflows always run locally regardless of this flag.

### Deployment and rollback workflow

Standard `wrangler deploy` pushes to 100% immediately. For gradual deployments: `wrangler versions upload` creates a version without deploying, then `wrangler versions deploy <new>@10% <old>@90%` shifts traffic incrementally. Test specific versions with the `Cloudflare-Workers-Version-Overrides` request header. Rollbacks via `wrangler rollback` point to an old version but use **current secret values** and do not rollback KV/R2/D1/DO data. First deploy must always use `wrangler deploy`, and DO migrations cannot use `versions upload`.

### D1 migration gotcha

In Wrangler v4, all commands **default to local mode**. Always use `--remote` explicitly for production: `wrangler d1 migrations apply DB --remote`. Failed migrations roll back automatically, but D1 has no built-in rollback mechanism — use forward migrations to undo changes.

### Wrangler v4 breaking changes (March 2025)

esbuild upgraded to v0.24 (may affect dynamic imports), all commands default to local mode, Node.js v16 dropped, `legacy_assets` removed, `node_compat` flag replaced by `nodejs_compat` compatibility flag, `getBindingsProxy()` replaced by `getPlatformProxy()`, and Workers Sites deprecated. Wrangler v3 receives bug fixes until Q1 2026, security fixes until Q1 2027.

---

## Conclusion: operational patterns that matter most

Three insights cut across the entire Cloudflare Workers ecosystem. First, **the V8 isolate model is not a container** — this means sub-5ms startup, 128MB memory, no filesystem, no threads, and CPU time billing that makes I/O essentially free. AI agents that internalize this generate correct code; those that don't produce `fs.readFileSync`, `process.spawn`, or `worker_threads` calls that fail at runtime.

Second, **storage choice determines architecture**. KV's 60-second eventual consistency makes it perfect for configuration but unusable for counters. D1's 10GB-per-database limit is a feature, not a bug — it pushes toward per-tenant isolation. Durable Objects' single-location constraint means every cross-region call pays latency tax. R2's zero egress pricing makes it the default for anything larger than 25MiB.

Third, **the edge + origin split is the core architectural decision**. With Smart Placement and Placement Hints, Workers can execute near your Cloud Run backend for multi-query workloads while still serving cached responses from the edge. The pattern is: edge Worker for auth, caching, and routing → Service Binding to backend Worker with Smart Placement near `gcp:<your-region>` → Hyperdrive for database access → Cloud Run for complex business logic. This architecture minimizes both user-perceived latency and Cloud Run invocation costs.