# AI interaction patterns across eight leading products

**The most effective AI interfaces share a counterintuitive trait: they hide the AI.** Products like Notion, Linear, and Attio achieve the highest user adoption not by showcasing AI capabilities, but by embedding intelligence so deeply into existing workflows that users barely notice a model is running. This report documents the precise UI/UX patterns across ChatGPT Canvas, Claude Artifacts, Notion AI, Linear, Attio, Dust.tt, Glean, and Perplexity — covering response rendering, contextual AI, transparency mechanisms, and proactive surfaces — then distills eight concrete design rules for native AI integration.

---

## How each product renders streaming AI responses

Every product studied uses **Server-Sent Events (SSE)** for real-time streaming, but the visual choreography differs meaningfully.

**ChatGPT** streams token-by-token with a **blinking solid circle cursor** that flickers at roughly 0.5-second intervals using a CSS opacity keyframe animation. Under the hood, OpenAI uses private-use Unicode characters (`\ue200`, `\ue201`) as placeholder markers during streaming — the browser swaps these with clickable citation links once reference metadata arrives. When using reasoning models (o1, o3), a **flashing label** displays brief reasoning snippets like "Analyzing the problem..." that update dynamically. Once thinking completes, this section **auto-collapses** and the final answer appears directly. Users must manually expand the collapsed section to inspect reasoning — a deliberate choice placing ChatGPT in the "low transparency, low overload" quadrant.

**Claude** streams token-by-token with a distinctive **shimmer animation** rather than a pulsing cursor — a subtle animated glow that indicates active generation. Extended thinking displays an **animated sparkle icon**, a **dynamic text label**, and a **running time counter** (e.g., "12s," "45s"). The thinking block appears as a **collapsed, expandable section** above the final response. When expanded, reasoning is presented as **structured bullet points** in a separately scrollable container. A notable discoverability issue: it's not immediately obvious to new users that the thinking section is expandable.

**Perplexity** has the most distinctive rendering sequence. **Source cards load first** — a horizontal row of compact cards showing favicons, page titles, and domain names — then the answer text streams below them token-by-token. The answer heading is prefixed with a **sparkle icon (✦)** and the word "Answer" in **cyan (#20b8cd)** against a dark background (#1a1a1a). For Pro Search, the UI shows an **expandable step-by-step plan** before the answer: each research step renders as a collapsible section showing search queries generated, sources found, and snippets retrieved. LangChain's case study confirmed that users were "more willing to wait for results" when they could see intermediate progress — this drove Pro Search's interactive plan display.

**Glean** takes a split approach: AI Answers on search results pages render as **completed static cards** at the top of results, while Glean Chat streams responses in real-time. The API returns alternating `text` and `citation` fragments, rendered sequentially.

**Notion AI** renders streaming responses **inline within the document body** — content appears to type itself directly into the page as new blocks, not in a modal or popover. **Dust.tt** streams via SSE with event types including `generation_tokens` for text and `retrieval_params` for tool activity, supporting LaTeX equations and Mermaid diagrams in rendered output.

---

## Citations and sources: five distinct visual models

The products studied reveal five fundamentally different approaches to source attribution, each optimized for different trust contexts.

**Perplexity's numbered footnote system** is the most citation-dense. Bracketed numbers `[1]`, `[2]`, `[3]` appear inline immediately after each claim. Hovering shows a tooltip with a source excerpt; clicking scrolls to the corresponding source card. Pro users receive **10x more citations per answer**. The source cards panel sits above the answer permanently, each card showing a favicon, truncated title, and domain name. This system pioneered what Shape of AI calls the "multi-source reference" pattern — maintaining claim-to-source granularity that Google AI Overviews later adopted but at lower granularity.

**ChatGPT uses superscript numbered references** (¹, ², ³) with hover preview cards showing source title and summary. A "Sources" button at the end of search-powered responses opens a sidebar listing all cited sources. Search results typically include **3–6 citations**. A globe icon (🌐) signals when web search was used.

**Glean pioneered deep-linked enterprise citations.** Citation pills — small clickable badges showing a document title and datasource favicon — appear inline within AI answers. The advanced deep-linking feature (beta) highlights the **exact cited passage** within the source document, with referenced text shown highlighted and surrounding context in muted gray. Hover previews show the passage with context; clicking opens the document in its native application (Google Drive, Confluence, Slack). When no enterprise sources support a claim, a distinct UI state makes this explicit.

**Claude** provides inline citations with source links only when web search is active, showing an indicator during the search process. Anthropic's API-level Citations feature offers **sentence-level source attribution** with `url_citation` objects, but the consumer UI is lighter than Perplexity's. **Notion AI Q&A** cites internal workspace documents as clickable page links, respecting user permissions. **Dust.tt** shows a "Retrieved" bar positioned between the user's question and the agent's answer, listing which documents and data sources were searched.

| Product | Citation style | Granularity | When shown |
|---------|---------------|-------------|------------|
| Perplexity | Numbered footnotes `[n]` + source cards | Claim-level | Always |
| ChatGPT | Superscript numbers + hover cards | Sentence-level | With web search |
| Glean | Inline citation pills + deep-links | Passage-level | Always |
| Claude | Inline links + source URLs | Sentence-level | With web search |
| Notion AI | Clickable page/doc links | Document-level | In Q&A mode |
| Dust.tt | "Retrieved" bar + action detail panel | Document-level | Always |

---

## AI woven into the product, not bolted on as chat

The most revealing patterns emerge from products that embed AI directly into their core workflows rather than adding a chat interface.

**Notion AI uses three trigger mechanisms** that feel native to the editor. Pressing **space** on an empty line opens the AI prompt input — making AI the default action on blank pages. Typing **/** opens the standard block menu where AI commands appear in **purple text**, visually distinct from regular commands. Highlighting text reveals a floating toolbar with "Ask AI" alongside standard formatting controls (also accessible via **Cmd+J**). The bottom-right corner houses an **animated face icon** — a whimsical line-drawn character that makes subtle "curious-like movements" in peripheral vision without demanding attention. Generated content appears inline with **blue highlighting** for new text and **grayed-out treatment** for deletions, with a floating action toolbar offering Replace, Insert below, Continue writing, Make longer, Try again, and Discard.

Notion's AI database autofill is arguably its most successful AI feature, driving over **50% AI attach rate**. AI-generated property values appear as standard text, select chips, numbers, or currency in database cells — they are **not visually distinguished** from user-entered data. The only indicator is a **wand/magic icon** that appears on hover, signaling the property is AI-powered and can be re-triggered. Values can auto-update **5 minutes after page edits** without user action.

**Attio takes an even more aggressive "invisible AI" approach.** AI attributes occupy regular columns in table views, rendering as standard text, select chips, or numbers indistinguishable from manually entered data at first glance. The column header may include a sparkle icon, and hovering over a cell reveals a "Recalculate value with AI" icon, but the generated values themselves blend completely into the data model. Configuration happens through a clean setup flow: select attribute type → enable AI Autofill toggle → choose task (Summarize Record, Research Agent, Classify Record, or Prompt Completion) → add optional guidance. If AI cannot determine a value, the **cell stays blank** — no error state, no confidence indicator. This binary approach (value or nothing) is deliberate: Attio treats AI attributes as first-class data, not provisional suggestions.

**Linear's Triage Intelligence** sits in a **dedicated module positioned below the issue title** when an issue is in Triage status. It suggests assignee, labels, projects, team, related issues, and duplicates — all rendered using **Linear's existing visual language** (same chips, icons, and styling as manual properties). Hovering over any suggestion reveals the model's reasoning in plain language plus alternative suggestions. Processing takes **1–4 minutes** — deliberately trading speed for quality — with a **timer and thinking-state label** at the bottom of the module. Users can expand a **thinking panel** showing the full trace: context pulled, decisions made, and how guidance shaped the outcome. The system is configurable per property: **Show** (human decides), **Auto-apply** (automatic), or **Hide** (suppress). In the activity feed, AI actions are explicitly attributed: "Triage Intelligence added the label Performance and iOS · 2min ago."

**Dust.tt reveals the most about multi-step execution visibility.** A clickable "Completed in N sec" indicator below each agent response opens an **action detail panel** showing which tools were used, search queries and parameters, retrieved documents with titles and links, agent reasoning ("thoughts"), and for sub-agent calls, a link to inspect the full sub-conversation. During execution, status updates stream in real-time via SSE. The agent builder avoids technical jargon — "instructions" instead of "system prompt" — and includes a **split-panel test mode** for real-time iteration. Agents support a maximum recursion depth of 4 for sub-agent chains, with each step recorded in the action detail panel.

---

## No product shows confidence scores, and that's intentional

**Not a single product in this study displays numeric confidence scores to end users.** This is the most consistent finding across all eight products and aligns with broader industry research showing that raw decimal probabilities create false precision and erode rather than build trust.

Instead, products use **four proxy mechanisms** for communicating AI certainty:

**Citation density as confidence signal.** Perplexity's approach is paradigmatic: a claim backed by five sources feels more trustworthy than one backed by a single source. Pro users receive 10x more citations, which functions as a confidence amplifier. Glean follows the same logic — the presence or absence of enterprise citations signals whether the AI had supporting evidence.

**Hedging language.** ChatGPT and Claude use linguistic uncertainty markers ("I think," "it's possible," "I'm not certain") rather than visual indicators. This is the lowest-friction approach but depends entirely on model calibration.

**Binary display (value or nothing).** Attio shows a value or leaves the cell blank. Linear shows a suggestion or doesn't. This binary treatment avoids the "75% confident" problem entirely — either the AI has a recommendation or it stays silent.

**Source transparency on demand.** Dust.tt, Glean, and Linear all follow a progressive disclosure model: the answer appears clean and confident, but one click reveals full provenance. Dust's action detail panel shows every tool call, query, and retrieved document. Linear's hover-to-see reasoning shows the model's decision process. Glean's deep-linked citations highlight the exact passage used.

Perplexity's Deep Research feature adds a distinctive transparency pattern: a **live progress display** showing which sources are being read, what's being learned, and how the report assembles. Key findings appear as research progresses, so users can start reviewing before the final report completes. Users can even **add follow-up questions while research is still running**.

---

## Proactive AI that avoids annoying users

The spectrum runs from Notion's active nudges to Linear's ambient patience, with a clear design lesson: **the best proactive AI matches the user's current attention state**.

**Notion is the most forward-leaning.** The animated face icon makes subtle movements to attract peripheral attention. Pressing space on an empty line immediately surfaces AI. Database autofill auto-updates on page edits. AI blocks can be embedded in database templates to auto-generate when pages are created. These proactive features drove Notion's high AI adoption, but they work because they appear **in moments of creation** — when users are already looking for what to do next.

**Linear is deliberately ambient.** Triage Intelligence processes every incoming issue automatically in the background over 1–4 minutes. Suggestions appear when ready; users can return later and find them populated. No pop-ups, no notifications, no interruptions. The system bets that most issues aren't triaged within the first four minutes anyway, so the AI has time to think deeply without blocking the user. Teams can configure auto-apply for high-confidence property types (always auto-apply certain labels) while requiring human approval for others (assignee suggestions).

**Perplexity's follow-up suggestions** appear as clickable chips below completed answers — context-aware suggestions like "Broaden scope," "Recent data," or "Counter-arguments." These are strictly post-response, never interrupting the reading flow. The Copilot sidebar offers higher-order meta-suggestions like "What else should I be asking about this topic?"

CHI 2025 research found that **persistent suggestion interfaces** were perceived as "distracting" and "annoying," while one-time suggestions and suggest-and-preview patterns received positive reactions. The key distinction: suggestions should appear at **contextually appropriate moments** (empty page, completed triage, finished answer), not as continuous ambient pressure.

---

## Eight design rules for making AI feel native

These rules are synthesized from the concrete patterns observed across all eight products, cross-referenced with design principles from Figma, Apple's HIG, Google PAIR, and leading AI UX researchers.

**1. Embed AI at the point of action, not in a separate chat panel.** Notion's space-bar trigger, Linear's triage module below the issue title, and Attio's attribute columns all place AI exactly where the user's attention already sits. The industry framework from Sandhya Hegde identifies this as the "Embedded" pattern — the "invisible magician" mode that will comprise **over 50% of all AI interfaces**. ChatGPT Canvas and Claude Artifacts represent a transitional form: the side panel is closer than a separate app but still creates a spatial division. Notion's inline insertion (AI content streams directly into the document body) and Attio's standard-looking cells represent the destination.

**2. Use the product's existing visual language for AI outputs.** Linear renders AI suggestions using the same chips, icons, and styling as manually set properties. Attio makes AI-generated values indistinguishable from human-entered data. Notion's AI autofill produces standard text in database cells. The rule: AI outputs should look like they belong to the product, not to the AI. Vitaly Friedman's framework captures this as the "AI-second" principle — focus on user needs and embed AI where it adds value, rather than building an "AI Mode."

**3. Progressive disclosure: answer first, reasoning on demand.** Every product follows this layered pattern. Layer 1: the answer or value appears cleanly. Layer 2: hover/click reveals reasoning (Linear's tooltip, Dust's "Completed in N sec"). Layer 3: full source material and methodology (Dust's action detail panel, Perplexity's expandable Pro Search steps, Claude's expanded thinking bullets). Perplexity's team stated the philosophy explicitly: "You don't want to overload the user with too much information until they are actually curious. Then, you feed their curiosity."

**4. Make AI outputs directly editable, not just re-promptable.** ChatGPT Canvas lets users click into the document and type. Notion's generated content integrates as standard blocks users can edit, move, or delete. Figma's approach — every AI-generated element remains fully editable — represents the principle most clearly. The alternative (asking AI to regenerate) is slow and frustrating. Providing **UI controls** (sliders for length, toggles for tone, dropdowns for reading level) is consistently more effective than requiring re-prompting. Canvas's floating toolbar with "Adjust length" and "Change reading level" shortcuts exemplifies this.

**5. Citations are the confidence mechanism — not scores.** No product shows numeric confidence, and research confirms raw decimals create false precision. Instead, Perplexity uses citation density (more sources = more trust), Glean uses deep-linked passage highlighting, and Attio uses binary presence/absence. The design insight: **source transparency is more useful than probability estimates** because it gives users the information needed to verify claims themselves. Every claim-making AI interface should show provenance at the claim level (Perplexity), passage level (Glean), or document level (Notion Q&A) — never zero citations.

**6. Design the "AI is wrong" experience as a first-class feature.** Notion offers Discard and Try Again buttons after every generation. ChatGPT Canvas provides inline comment bubbles users can dismiss or edit around. Linear lets users dismiss individual suggestions. Dust shows blank results rather than hallucinated data. Perplexity refuses to generate answers when search yields no reputable sources. The pattern: **always provide escape hatches** — undo, dismiss, retry, and manual override should be as prominent as accept. Duolingo's research adds a counterintuitive insight: small effort (taps, choices) increases perceived value of AI output. Zero-friction AI actually feels suspicious.

**7. Proactive AI should match the user's attention state.** Notion's space-bar trigger works because it fires during a **creation moment** (empty page, empty line) when the user is explicitly looking for what to do next. Linear's background triage works because issues sit in triage queues for minutes or hours, giving AI time to process without blocking anyone. Perplexity's follow-up chips work because they appear after the user has finished reading. The anti-pattern: persistent, always-visible suggestions that compete for attention during focused work. The rule from CHI 2025 research: **suggest at transitions, not during tasks**.

**8. Show the work trail, not the working.** Dust.tt's action detail panel, Linear's reasoning tooltip, and Perplexity's expandable search steps all show what the AI *did* — which tools were called, what sources were consulted, what reasoning was applied — but only when users ask. During execution, the products show minimal indicators: a timer (Linear, Claude), a shimmer (Claude), a step label (Perplexity), or source cards loading (Perplexity). The work trail serves both transparency and debuggability. When AI gives a wrong answer, the trail shows *why* — which is far more actionable than a confidence percentage.

---

## Conclusion

The products in this study form a clear evolutionary arc. First-generation AI interfaces (chatbots in sidebars) are giving way to **embedded AI that operates within existing data models and workflows**. The strongest evidence: Attio and Notion achieve their highest adoption with AI features that produce outputs indistinguishable from human data entry. Linear's most praised AI feature — Triage Intelligence — uses the product's own visual language, appears in the product's own layout, and attributes its actions in the product's own activity feed. The pattern is clear: the less an AI feature looks like "AI," the more users trust and adopt it. Perplexity is the instructive exception — a product built around transparency where dense citations *are* the value proposition. The lesson isn't that all products should hide AI. It's that AI's visibility should be **proportional to the user's need for verification**, and that verification should always be available one click away.