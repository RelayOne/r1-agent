# Auto-detecting repository tech stacks from file structure

**A repository's technology stack can be reliably detected by examining roughly 50 file paths and patterns, parsing 10–15 manifest formats, and matching dependencies against curated technology maps.** The approach used across the industry—by GitHub Linguist, Vercel, Netlify, Nixpacks, Heroku, Renovate, and Dependabot—follows a consistent layered pattern: check for sentinel files first (cheapest), parse manifest files second, scan file content third (most expensive). This report synthesizes the actual detection logic from these open-source tools into a practical, implementable reference for selecting the right AI coding agent skill files based on what a repository actually contains.

The core insight from studying all these systems is that **file existence checks alone cover ~80% of detection needs**. A `go.mod` at root definitively means Go. A `turbo.json` means Turborepo. A `prisma/schema.prisma` means Prisma. The remaining 20%—framework identification, database specifics, cloud provider usage—requires lightweight parsing of JSON, YAML, and TOML manifest files to match dependencies and configuration values.

---

## GitHub Linguist's layered detection strategy sets the foundation

GitHub Linguist, the Ruby library powering GitHub's language statistics for **750+ languages**, applies detection strategies in strict sequential order. Each strategy either narrows candidates or returns a definitive result, and the chain stops when exactly one language remains:

1. **Modeline** — Vim/Emacs modelines (`-*- mode: python -*-`) at file top/bottom
2. **Filename** — Exact filename matches (`Makefile` → Make, `Dockerfile` → Dockerfile)
3. **Shebang** — First-line interpreter (`#!/usr/bin/env python3` → Python)
4. **Extension** — File extension lookup (`.go` → Go, `.rs` → Rust)
5. **XML** — XML namespace detection
6. **Manpage** — Man page format detection
7. **Heuristics** — Regex-based disambiguation from `heuristics.yml` for ambiguous extensions
8. **Classifier** — Naive Bayesian classifier trained on sample files (last resort)

The system's power comes from three data files. **`languages.yml`** defines every known language with its extensions, filenames, interpreters, type (programming/data/markup/prose), and TextMate grammar scope. **`heuristics.yml`** contains regex rules for extensions shared by multiple languages—for example, `.h` files are disambiguated by checking for `@interface` (Objective-C), `#include <` (C++), or falling through to C. **`vendor.yml`** lists path patterns for vendored code (`node_modules/`, `vendor/`, `bower_components/`, `third_party/`) that should be excluded from language statistics.

**Can Linguist's approach be reused for stack detection?** Partially. Its file-to-language mapping via `languages.yml` is an excellent foundation, and its vendor/generated file filtering prevents false signals. But Linguist is purely a language detector—it knows nothing about frameworks, databases, or infrastructure. Full stack detection requires layering additional rules on top, which is exactly what the tools described below do.

**go-enry** (`github.com/go-enry/go-enry/v2`) is the production-ready Go port of Linguist, implementing all detection strategies as importable functions. It auto-generates Go data structures from Linguist's YAML files and stays synchronized with Linguist releases. Key API surface:

```go
lang := enry.GetLanguage("foo.py", content)         // Full detection pipeline
lang, safe := enry.GetLanguageByExtension("foo.go")  // Single strategy
enry.IsVendor("vendor/foo.go")                        // true
enry.IsGenerated("foo.min.js", nil)                    // true
```

go-enry runs **2x faster** than Ruby Linguist, handles all strategies except some regex edge cases (Go's RE2 lacks backreferences), and is the recommended starting point for any Go-based detection system.

---

## Framework detection: how Vercel, Netlify, Nixpacks, and Heroku actually work

### Vercel's detector pattern

Vercel's `packages/frameworks/src/frameworks.ts` (4,445 lines, 40+ frameworks) uses a `detectors` object per framework with combinators. Each detector specifies `every` (all must match) or `some` (any must match) arrays of rules using three primitives: **`matchPackage`** (checks `dependencies`/`devDependencies` in package.json), **`path`** (checks file existence), and **`matchContent`** (checks file content with regex).

| Framework | Detection Rule | Build Command | Output Directory |
|---|---|---|---|
| Next.js | `matchPackage: 'next'` | `next build` | `.next` |
| Astro | `matchPackage: 'astro'` | `astro build` | `dist` |
| Remix | `some[matchPackage: '@remix-run/dev', path: 'remix.config.js']` | `remix build` | `public` |
| Gatsby | `matchPackage: 'gatsby'` | `gatsby build` | `public` |
| Angular | `matchPackage: '@angular/cli'` | `ng build` | `dist` |
| Vue.js (CLI) | `matchPackage: '@vue/cli-service'` | `vue-cli-service build` | `dist` |
| SvelteKit | `matchPackage: '@sveltejs/kit'` | `vite build` | `build` |
| Nuxt | `matchPackage: 'nuxt'` | `nuxt build` | `.nuxt` |
| Eleventy | `matchPackage: '@11ty/eleventy'` | `npx @11ty/eleventy` | `_site` |
| Docusaurus | `matchPackage: '@docusaurus/core'` | `docusaurus build` | `build` |
| SolidStart | `every[matchPackage: 'solid-js', matchPackage: '@solidjs/start']` | `vinxi build` | `.output` |

A critical design principle from Vercel's source comments: **`matchPackage` must reference a CLI package, not the core library**. Preact detection uses `preact-cli` not `preact`, because `preact` might be a dependency of other frameworks. Vercel also uses a `supersedes` property so more specific frameworks override generic ones (e.g., Remix supersedes Vite).

### Netlify's framework-info

Netlify's `netlify/framework-info` repository stores each framework as a JSON file with a `detect` object containing `npmDependencies`, `excludedNpmDependencies`, and `configFiles`. Detection passes if any listed npm dependency appears in package.json AND none of the excluded dependencies are present AND any config file exists. It covers **30+ frameworks** with both SSGs (Gatsby, Hugo, Jekyll, Next.js, Nuxt, Hexo, Eleventy, Gridsome, Docusaurus, VuePress) and frontend frameworks (CRA, Vue CLI, Angular, Ember, Svelte, Expo, Quasar).

### Nixpacks provider detection

Railway's Nixpacks (Rust, `railwayapp/nixpacks`) implements a `Provider` trait with a `detect()` method per language. Detection is purely file-existence based:

| Provider | Detection File(s) |
|---|---|
| Node.js | `package.json` |
| Python | `main.py` OR `requirements.txt` OR `pyproject.toml` OR `Pipfile` |
| Go | `go.mod` |
| Rust | `Cargo.toml` |
| Ruby | `Gemfile` |
| Java | `pom.xml` OR `gradlew` OR `pom.yml` (plus 5 other pom variants) |
| PHP | `composer.json` |
| Elixir | `mix.exs` |
| C# | `*.csproj` |
| Dart | `pubspec.yaml` |
| Deno | `deno.json` / `deno.jsonc` |
| Scala | `build.sbt` |
| Zig | `build.zig` |
| Swift | `Package.swift` |

Nixpacks then sub-detects package managers within each language: for Python, it checks `uv.lock` → uv, `poetry.lock` → Poetry, `requirements.txt` → pip, `Pipfile` → pipenv, in that order. For Node.js, it checks `bun.lockb` → Bun, `pnpm-lock.yaml` → pnpm, `yarn.lock` → Yarn, `package-lock.json` → npm.

### Heroku buildpack detection

Heroku's classic buildpacks search in a **fixed priority order**, and the first match wins. Each buildpack has a `bin/detect` shell script that checks for specific files:

1. Ruby (`Gemfile`) → 2. Node.js (`package.json`) → 3. Clojure (`project.clj`) → 4. Python (any of 13 files including `requirements.txt`, `pyproject.toml`, `Pipfile`, `uv.lock`, `poetry.lock`, `manage.py`, `app.py`, `main.py`) → 5. Java (`pom.xml`) → 6. Gradle (`build.gradle`, `gradlew`) → 7. Scala (`*.sbt`) → 8. PHP (`composer.json`) → 9. Go (`go.mod`) → 10. .NET (`*.csproj`, `*.fsproj`)

**Order matters critically**: a PHP app with both `composer.json` and `package.json` will be detected as Node.js (priority 2), not PHP (priority 8).

---

## Database detection requires multi-signal analysis

Detecting databases requires combining signals from four sources because no single indicator is definitive. The recommended priority: **ORM config files** (highest confidence, exact database specified) → **dependencies in manifests** (high confidence) → **Docker Compose images** (high confidence) → **environment variables** (medium confidence, often templates).

### Docker Compose image matching

Parse `docker-compose.yml`, `docker-compose.yaml`, `compose.yml`, or `compose.yaml` and match the `image` field in each service:

| Regex Pattern | Database |
|---|---|
| `^(postgres\|postgresql)(:\|$)` or `bitnami/postgres` | PostgreSQL |
| `^mysql(:\|$)` or `bitnami/mysql` | MySQL |
| `^mariadb(:\|$)` | MariaDB |
| `^mongo(db)?(:\|$)` | MongoDB |
| `^redis(:\|$)` | Redis |
| `elasticsearch` or `docker.elastic.co/elasticsearch` | Elasticsearch |
| `mcr.microsoft.com/mssql/server` | SQL Server |
| `cockroachdb/cockroach` | CockroachDB |
| `clickhouse/clickhouse-server` | ClickHouse |
| `amazon/dynamodb-local` | DynamoDB |
| `^neo4j(:\|$)` | Neo4j |
| `^rabbitmq(:\|$)` | RabbitMQ |
| `^memcached(:\|$)` | Memcached |
| `^cassandra(:\|$)` | Cassandra |

Secondary signals within Compose services include environment variables like `POSTGRES_PASSWORD`, `MYSQL_ROOT_PASSWORD`, and `MONGO_INITDB_ROOT_USERNAME`—useful when custom image names obscure the actual database.

### Dependency-to-database mapping per ecosystem

**Node.js** (package.json): `pg`/`pg-pool` → PostgreSQL, `mysql2` → MySQL, `mongoose`/`mongodb` → MongoDB, `redis`/`ioredis` → Redis, `better-sqlite3`/`sqlite3` → SQLite, `tedious`/`mssql` → SQL Server, `@elastic/elasticsearch` → Elasticsearch, `neo4j-driver` → Neo4j, `@clickhouse/client` → ClickHouse, `@aws-sdk/client-dynamodb` → DynamoDB.

**Python** (requirements.txt/pyproject.toml): `psycopg2`/`psycopg2-binary`/`asyncpg` → PostgreSQL, `pymysql`/`mysqlclient` → MySQL, `pymongo`/`motor` → MongoDB, `redis`/`aioredis` → Redis, `elasticsearch` → Elasticsearch, `cassandra-driver` → Cassandra.

**Go** (go.mod): `github.com/jackc/pgx` or `github.com/lib/pq` → PostgreSQL, `github.com/go-sql-driver/mysql` → MySQL, `go.mongodb.org/mongo-driver` → MongoDB, `github.com/redis/go-redis` → Redis, `gorm.io/driver/postgres` → PostgreSQL (GORM), `gorm.io/driver/mysql` → MySQL (GORM), `github.com/mattn/go-sqlite3` or `modernc.org/sqlite` → SQLite.

**Rust** (Cargo.toml): `diesel` (check features for `postgres`/`mysql`/`sqlite`), `sqlx` (check features), `tokio-postgres` → PostgreSQL, `redis` → Redis, `mongodb` → MongoDB.

**Ruby** (Gemfile): `pg` → PostgreSQL, `mysql2` → MySQL, `sqlite3` → SQLite, `mongoid` → MongoDB, `redis` → Redis.

**Java** (pom.xml/build.gradle): `org.postgresql:postgresql` → PostgreSQL, `mysql:mysql-connector-java` → MySQL, `org.mongodb:mongodb-driver` → MongoDB, `redis.clients:jedis` or `io.lettuce:lettuce-core` → Redis, `spring-boot-starter-data-mongodb` → MongoDB.

### ORM config file parsing

When an ORM is detected, its config file specifies the exact database. **Prisma**: parse `prisma/schema.prisma` for `provider = "postgresql"` (regex: `datasource\s+\w+\s*\{[^}]*provider\s*=\s*"(postgresql|mysql|sqlite|mongodb|sqlserver|cockroachdb)"`). **TypeORM**: parse `ormconfig.json` for `"type": "postgres"`. **Knex**: parse `knexfile.js` for `client: 'pg'`. **Rails**: parse `config/database.yml` for `adapter: postgresql`. **Django**: parse `settings.py` for `ENGINE.*django\.db\.backends\.(postgresql|mysql|sqlite3|oracle)`. **Spring Boot**: parse `application.properties` for `spring.datasource.url=jdbc:(postgresql|mysql|sqlserver)://`.

### Environment variable patterns

In `.env`, `.env.example`, or `.env.local` files, match `DATABASE_URL` schemes: `postgres://` or `postgresql://` → PostgreSQL, `mysql://` → MySQL, `mongodb://` or `mongodb+srv://` → MongoDB, `redis://` or `rediss://` → Redis, `sqlite://` → SQLite, `sqlserver://` or `mssql://` → SQL Server. Also match variable name prefixes: `POSTGRES_*` or `PG*` → PostgreSQL, `MYSQL_*` → MySQL, `MONGO*` → MongoDB, `REDIS_*` → Redis, `ELASTICSEARCH_*` → Elasticsearch.

---

## Cloud provider detection from config files, IaC, and SDKs

### Sentinel config files (highest confidence)

Each cloud provider and platform has distinctive config files that definitively indicate its use:

| File | Provider | Confidence |
|---|---|---|
| `wrangler.toml` / `wrangler.json` | Cloudflare Workers | High |
| `serverless.yml` (check `provider.name`) | AWS / GCP / Azure | High |
| `template.yaml` with `AWSTemplateFormatVersion` | AWS CloudFormation/SAM | High |
| `.ebextensions/` | AWS Elastic Beanstalk | High |
| `cdk.json` | AWS CDK | High |
| `buildspec.yml` | AWS CodeBuild | High |
| `appspec.yml` | AWS CodeDeploy | High |
| `amplify.yml` | AWS Amplify | High |
| `zappa_settings.json` | AWS Lambda (Python) | High |
| `copilot/` directory | AWS Copilot | High |
| `app.yaml` with `runtime:` | Google App Engine | High |
| `cloudbuild.yaml` | Google Cloud Build | High |
| `.gcloudignore` | GCP | High |
| `firebase.json` / `.firebaserc` | Firebase/GCP | High |
| `fly.toml` | Fly.io | High |
| `render.yaml` | Render | High |
| `vercel.json` | Vercel | High |
| `netlify.toml` | Netlify | High |
| `Procfile` + `app.json` | Heroku | Medium-High |

### Terraform provider detection

In `*.tf` files, scan for provider blocks using the pattern `provider\s+"(aws|google|azurerm|cloudflare)"`. Also scan for resource prefixes: `aws_*` → AWS, `google_*` → GCP, `azurerm_*` → Azure, `cloudflare_*` → Cloudflare. In `required_providers` blocks, match `hashicorp/aws`, `hashicorp/google`, `hashicorp/azurerm`, `cloudflare/cloudflare`.

For **Pulumi**, check `Pulumi.yaml` plus dependencies: `@pulumi/aws` in package.json, `pulumi-aws` in requirements.txt, or `cloud.google.com/go` references. For **AWS CDK**, detect `cdk.json` plus `aws-cdk-lib` in package.json.

### SDK dependency mapping

**Node.js**: `aws-sdk` or `@aws-sdk/*` → AWS, `@google-cloud/*` → GCP, `firebase`/`firebase-admin` → Firebase/GCP, `@azure/*` → Azure, `@cloudflare/workers-types` → Cloudflare, `@vercel/*` → Vercel, `@supabase/supabase-js` → Supabase, `@upstash/redis` → Upstash.

**Python**: `boto3`/`botocore` → AWS, `google-cloud-*`/`google-api-python-client` → GCP, `azure-*` → Azure.

**Go**: `github.com/aws/aws-sdk-go-v2` → AWS, `cloud.google.com/go/*` → GCP, `github.com/Azure/azure-sdk-for-go` → Azure, `github.com/cloudflare/cloudflare-go` → Cloudflare.

### Environment variable prefixes

Match variable names against these prefixes in `.env*` files: `AWS_*` or `AMAZON_*` → AWS, `GOOGLE_CLOUD_*` or `GCLOUD_*` or `GCP_*` or `FIREBASE_*` → GCP, `AZURE_*` → Azure, `CF_*` or `CLOUDFLARE_*` → Cloudflare, `VERCEL_*` → Vercel, `NETLIFY_*` → Netlify, `FLY_*` → Fly.io, `RAILWAY_*` → Railway, `RENDER_*` → Render, `HEROKU_*` → Heroku, `SUPABASE_*` → Supabase, `NEON_*` → Neon, `TURSO_*` → Turso.

---

## Monorepo detection and polyglot workspace scanning

### Tool detection by sentinel files

| File | Tool | Notes |
|---|---|---|
| `turbo.json` | Turborepo | Contains pipeline/task definitions with `dependsOn`, `outputs`, `cache` |
| `nx.json` | Nx | Contains task config, caching, affected detection |
| `pnpm-workspace.yaml` | pnpm Workspaces | Contains `packages:` array with glob patterns |
| `lerna.json` | Lerna | Contains `version`, `packages`, `npmClient` |
| `rush.json` | Rush | Microsoft's RushStack monorepo manager |
| `WORKSPACE` / `WORKSPACE.bazel` / `MODULE.bazel` | Bazel | Root-level files; `BUILD`/`BUILD.bazel` in subdirs |
| `pants.toml` | Pants | With `BUILD` files in subdirectories |

Multiple tools commonly coexist: `pnpm-workspace.yaml` + `turbo.json` is an extremely common combination, as is `pnpm-workspace.yaml` + `nx.json`.

### Workspace pattern detection

In root `package.json`, check for the `"workspaces"` field (npm/yarn workspaces), which appears as either an array (`["packages/*", "apps/*"]`) or an object with a `packages` key. The `"packageManager"` field (Corepack standard, e.g., `"packageManager": "pnpm@8.6.0"`) is the most authoritative signal for package manager identity in JS projects. For pnpm, workspace patterns live in `pnpm-workspace.yaml` under the `packages:` key. For Cargo, a `[workspace]` section in root `Cargo.toml` with `members = ["crates/*"]` indicates a Rust workspace.

### Polyglot monorepo scanning

To detect multiple tech stacks in subdirectories, **scan 2–3 levels deep** for ecosystem-specific manifest files: `package.json` (JS/TS), `go.mod` (Go), `Cargo.toml` (Rust), `requirements.txt`/`pyproject.toml` (Python), `pom.xml`/`build.gradle` (Java), `Gemfile` (Ruby), `composer.json` (PHP), `mix.exs` (Elixir), `pubspec.yaml` (Dart). If two or more different ecosystem manifests appear in separate subdirectories, the repo is polyglot. Common top-level directories to prioritize: `apps/`, `packages/`, `services/`, `libs/`, `modules/`, `tools/`.

---

## CI/CD platform identification from file paths alone

CI/CD detection is almost entirely file-path based with **no content parsing required** for platform identification:

| Platform | Detection Path(s) |
|---|---|
| GitHub Actions | `.github/workflows/*.yml` or `.github/workflows/*.yaml` |
| GitLab CI | `.gitlab-ci.yml` |
| Jenkins | `Jenkinsfile` (no extension) |
| CircleCI | `.circleci/config.yml` |
| Travis CI | `.travis.yml` |
| Bitbucket Pipelines | `bitbucket-pipelines.yml` |
| Azure Pipelines | `azure-pipelines.yml` |
| Drone CI | `.drone.yml` |
| Buildkite | `.buildkite/pipeline.yml` |
| Woodpecker CI | `.woodpecker.yml` or `.woodpecker/*.yml` |
| Earthly | `Earthfile` |
| Google Cloud Build | `cloudbuild.yaml` |
| AWS CodeBuild | `buildspec.yml` |

To determine **pipeline types** from CI config content, scan for keywords: build steps contain `build`, `compile`, `make`, `npm run build`, `go build`, `cargo build`, `docker build`; test steps contain `test`, `pytest`, `jest`, `vitest`, `go test`, `cargo test`; deploy steps contain `deploy`, `publish`, `kubectl apply`, `terraform apply`, `helm upgrade`, `aws deploy`; lint steps contain `lint`, `eslint`, `prettier`, `ruff`, `golangci-lint`.

---

## Package manager detection across all ecosystems

Lock files are the **strongest signal** for package manager identity. When multiple lock files coexist in the same ecosystem, it indicates misconfiguration; apply a priority order.

### JavaScript/TypeScript (priority order)

1. `"packageManager"` field in `package.json` (most authoritative, Corepack standard)
2. `pnpm-lock.yaml` → pnpm
3. `bun.lockb` or `bun.lock` → Bun
4. `yarn.lock` → Yarn (distinguish Classic vs Berry: `.yarnrc.yml` present or `__metadata:` in lock file → Berry v2+)
5. `package-lock.json` → npm (fallback default)

### Python (disambiguation via pyproject.toml)

Check lock files first: `uv.lock` → uv, `poetry.lock` → Poetry, `Pipfile.lock` → pipenv, `pdm.lock` → PDM. If only `pyproject.toml` exists, inspect `[build-system]` → `build-backend`: `"poetry.core.masonry.api"` → Poetry, `"hatchling.build"` → Hatch, `"flit_core.buildapi"` → Flit, `"pdm.backend"` → PDM. Also check `[tool.*]` sections: `[tool.poetry]`, `[tool.hatch]`, `[tool.uv]`, `[tool.pdm]`. Bare `requirements.txt` without other signals → pip.

### Other ecosystems

**Go**: `go.mod` + `go.sum` → Go Modules. **Rust**: `Cargo.toml` + `Cargo.lock` → Cargo. **Ruby**: `Gemfile` + `Gemfile.lock` → Bundler. **PHP**: `composer.json` + `composer.lock` → Composer. **Java**: `pom.xml` → Maven, `build.gradle`/`build.gradle.kts` → Gradle, `build.sbt` → sbt. **Swift**: `Package.swift` → SPM, `Podfile` → CocoaPods. **Elixir**: `mix.exs` → Mix. **Dart**: `pubspec.yaml` → Pub. **.NET**: `*.csproj` → NuGet.

---

## Test framework detection across language ecosystems

Test framework detection follows a consistent pattern: **config file existence** (highest confidence, cheapest) → **manifest dependency check** → **directory convention** → **content scanning** (most expensive, last resort).

**JavaScript/TypeScript**: `jest.config.*` or `"jest"` key in package.json → Jest; `vitest.config.*` → Vitest; `.mocharc.*` → Mocha; `cypress.config.*` or `cypress/` directory → Cypress; `playwright.config.*` or `@playwright/test` in devDependencies → Playwright.

**Python**: `pytest.ini` or `[tool.pytest.ini_options]` in `pyproject.toml` or `conftest.py` → pytest; `tox.ini` → tox; `nose2.cfg` → nose2. The presence of `conftest.py` at any directory level is a high-confidence pytest signal.

**Go**: `*_test.go` files → built-in `testing` package; `github.com/stretchr/testify` in `go.mod` → testify; `go.uber.org/mock` → gomock.

**Rust**: `#[cfg(test)]` or `#[test]` in `.rs` files → built-in; `tests/` directory with `.rs` files → integration tests.

**Ruby**: `.rspec` file or `spec/` directory → RSpec; `test/` directory with `*_test.rb` → Minitest.

**Java**: `junit-jupiter` in pom.xml/build.gradle → JUnit 5; `testng.xml` or `testng` dependency → TestNG; `src/test/java/` directory → Maven/Gradle convention.

**PHP**: `phpunit.xml` or `phpunit.xml.dist` → PHPUnit; `pestphp/pest` in `composer.json` or `tests/Pest.php` → Pest.

---

## Docker and container orchestration detection

### Container file detection

| Pattern | Indicates |
|---|---|
| `Dockerfile` (also `Dockerfile.*`, `*.Dockerfile`) | Docker |
| `Containerfile` (also `Containerfile.*`) | OCI/Podman compatible |
| `docker-compose.yml` / `docker-compose.yaml` | Docker Compose (legacy naming) |
| `compose.yml` / `compose.yaml` | Docker Compose v2 (preferred naming) |
| `.dockerignore` | Docker build context |
| `.containerignore` | Podman equivalent |
| `.devcontainer/devcontainer.json` | Dev Containers |

Renovate's actual regex for Dockerfile detection is `(^|/|\.)([Dd]ocker|[Cc]ontainer)file$` plus `(^|/)([Dd]ocker|[Cc]ontainer)file[^/]*$`, which elegantly catches all naming variants.

### Kubernetes and Helm detection

For Kubernetes manifests, **file existence alone is insufficient**—YAML files are generic. Content must be checked for `apiVersion:` AND `kind:` fields with known Kubernetes values (`apps/v1`, `v1`, `networking.k8s.io/v1`, `batch/v1`). Convention-based paths help: `k8s/` or `kubernetes/` directories with YAML files are strong signals. `kustomization.yaml` definitively indicates Kustomize.

For Helm charts, `Chart.yaml` is definitive. A valid Helm chart requires `Chart.yaml` plus a `templates/` directory. `helmfile.yaml` indicates Helmfile. `values.yaml` alongside `Chart.yaml` increases confidence.

Other orchestration tools: `skaffold.yaml` → Skaffold, `Tiltfile` → Tilt, `garden.yml` → Garden, `*.nomad` or `*.nomad.hcl` → Nomad, `docker-stack.yml` → Docker Swarm, `docker-bake.hcl` → Docker BuildKit Bake.

---

## Open-source tools for comprehensive stack detection

### Specfy Stack Analyser — the most complete open-source solution

**`github.com/specfy/stack-analyser`** (MIT, TypeScript, ~400 stars) detects **700+ technologies** including languages, frameworks, databases, SaaS services, and cloud infrastructure. It recursively traverses directories, parses manifest files (`package.json`, `docker-compose.yml`, `go.mod`, `Gemfile`, `requirements.txt`, `Cargo.toml`), and maps dependencies to known technologies using rules in its `src/rules/` directory. Output is structured JSON with components, technologies, languages, dependencies, and edges between services:

```json
{
  "name": "@fake/api",
  "path": ["pkgs/api/package.json"],
  "techs": ["datadog", "fastify", "nodejs", "prisma", "typescript"],
  "dependencies": [["npm","dd-trace","1.0.1"], ["npm","fastify","4.17.0"]],
  "edges": [{"target": "...", "read": true, "write": true}]
}
```

Its rules database mapping package names to technologies is the single most valuable data source for building a stack detector, though it's TypeScript—porting to Go would require extracting the rules data.

### Renovate Bot's manager detection — the broadest file-pattern coverage

Renovate (`github.com/renovatebot/renovate`, AGPL-3.0, TypeScript) supports **90+ manager types**, each with `managerFilePatterns` (regex/glob). Unlike Dependabot (which requires user configuration), Renovate **automatically discovers** all package files. Its manager list provides a near-complete mapping from file patterns to technology ecosystems: `npm`, `pip_requirements`, `poetry`, `gomod`, `cargo`, `dockerfile`, `docker-compose`, `terraform`, `helm-values`, `helmfile`, `kustomize`, `github-actions`, `gitlabci`, `circleci`, `azure-pipelines`, `kubernetes`, `ansible`, `gradle`, `maven`, and dozens more.

### Dependabot's ecosystem model

Dependabot (`github.com/dependabot/dependabot-core`, MIT, Ruby) supports **25+ ecosystems** with a clean architecture: each ecosystem implements `FileFetcher` (downloads manifests), `FileParser` (extracts dependencies), `UpdateChecker` (queries registries), and `FileUpdater` (generates updates). However, detection is **not automatic**—users must configure `dependabot.yml` specifying ecosystems and directories.

### Other tools worth noting

**Snyk CLI** scans for manifest files in a priority order (`yarn.lock` → `package-lock.json` → `package.json` → `Gemfile.lock` → `pom.xml` → `build.gradle` → etc.) and returns the first match. The `--all-projects` flag enables recursive scanning. **Hyperpolyglot** (`github.com/monkslc/hyperpolyglot`) is a fast Rust port of Linguist for language detection only.

---

## Conclusion: a practical detection architecture for skill file selection

For the use case of selecting the right subset of 51 skill files for AI coding agent prompts, implement a **three-layer detection system** that runs in under a second for any repository.

**Layer 1 (file existence, ~40 checks)**: Scan root and first two directory levels for sentinel files. This alone identifies the language (`go.mod` → Go, `Cargo.toml` → Rust, `package.json` → JS/TS), package manager (lock files), monorepo tool (turbo.json, nx.json), CI/CD platform (.github/workflows/), container usage (Dockerfile, compose.yml, Chart.yaml), and cloud platform config files (wrangler.toml, serverless.yml, firebase.json). Use go-enry for comprehensive language detection with vendor/generated file filtering.

**Layer 2 (manifest parsing, ~10 file types)**: Parse `package.json` dependencies, `go.mod` requires, `Cargo.toml` dependencies, `requirements.txt`/`pyproject.toml` packages, `Gemfile` gems, `pom.xml`/`build.gradle` artifacts, and `docker-compose.yml` service images. Match against curated maps of dependency → technology (framework, database, cloud provider, test framework). For Python, disambiguate the package manager via `pyproject.toml` `[build-system]` and `[tool.*]` sections.

**Layer 3 (config file content, targeted parsing)**: For ORMs detected in Layer 2, parse their config files for database specifics (`prisma/schema.prisma` → provider value, `config/database.yml` → adapter). For Terraform, scan `*.tf` files for provider blocks. For serverless frameworks, check `provider.name` in `serverless.yml`. For environment variables in `.env.example`, match prefixes to cloud providers and database URL schemes.

The key data sources to reuse directly are **go-enry** (Go library, language detection), **Linguist's `languages.yml`** and **`vendor.yml`** (comprehensive language and vendored-path data), **Renovate's manager file patterns** (90+ ecosystem file-pattern mappings), and **Specfy's rules database** (700+ dependency-to-technology mappings). Together, these four sources cover the vast majority of detection needs without building heuristics from scratch.