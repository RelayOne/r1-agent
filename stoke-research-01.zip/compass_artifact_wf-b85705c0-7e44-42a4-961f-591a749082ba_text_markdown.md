# Engineering SEO for multi-tenant platforms in 2026

**The SEO landscape has fractured into four parallel optimization surfaces — traditional Google organic, AI answer engines, voice assistants, and generative AI citations — and engineering teams must now build infrastructure that serves all four simultaneously.** This report provides a complete technical implementation guide for each surface, covering CI/CD automation, framework selection, structured data patterns, and the emerging discipline of Generative Engine Optimization. The core thesis: treat SEO as an engineering constraint, not a marketing afterthought. Every recommendation below targets a multi-tenant SaaS content platform generating thousands to millions of pages.

---

## 1. SEO validation belongs in your CI pipeline

The most impactful architectural decision is enforcing SEO correctness at build time rather than auditing after deployment. A modern SEO CI pipeline chains four validation layers: structured data, meta tag completeness, canonical verification, and performance scoring.

**Structured data validation** runs through two primary tools. The `structured-data-testing-tool` npm package (v4.5.0) provides CLI and programmatic validation against Google, Twitter, and Facebook presets — run `sdtt --file ./build/index.html --schemas Article` in CI. For GitHub Actions, the **Schemar action** (`johnnyreilly/schemar@v0.1.1`) validates structured data on deployed URLs. Adobe's `@adobe/structured-data-validator` validates against both Schema.org specs and Google Rich Results requirements programmatically.

**Meta tag enforcement** uses `seo-analyzer`, which checks title length, meta descriptions, canonical links, Open Graph tags, and Twitter Card completeness. It ships with a GitHub Actions example and supports custom rules via jsdom DOM access. For ESLint integration, **`@html-eslint/eslint-plugin`** (~55K weekly downloads) includes a dedicated SEO rules category: `html/require-title`, `html/require-meta-description`, `html/require-open-graph-protocol`, `html/no-multiple-h1`, and `html/require-lang`. These run as standard ESLint rules in any CI system.

**Canonical URL verification** at scale requires crawl-based approaches. The Vercel SEO Audit GitHub Action detects canonical mismatches with a `--strict` flag that fails builds. For custom verification, use Playwright to crawl rendered pages, extract `<link rel="canonical">`, and assert self-referencing canonicals match the current URL, no canonical chains exist, and all canonical targets return HTTP 200.

**Sitemap generation** for multi-tenant sites at scale requires server-side generation, not build-time. Next.js's built-in `generateSitemaps()` function splits into multiple sitemaps automatically (50,000 URL limit per file). The `next-sitemap` package supports per-tenant sitemaps via `getServerSideSitemapIndex()` with host-based routing. The framework-agnostic `sitemap` npm package provides `SitemapAndIndexStream` for sites exceeding 50K URLs.

**The complete pipeline** as a GitHub Actions workflow chains checkout → build → Schemar structured data check → `seo-analyzer` meta tag audit → Lighthouse CI with SEO score gating (`categories:seo` minimum 0.9) → `html-validate` against the dist output. Gate PR merges by making these required status checks in branch protection rules.

For **AI coding assistant enforcement**, the ecosystem now includes SEO-specific `.cursor/rules/*.mdc` files that encode patterns like "always use `generateMetadata` for SEO" in Next.js projects. The `marketingskills` repository on GitHub provides SKILL.md files for Claude Code agents covering SEO audits, schema markup, programmatic SEO, and AI search optimization.

---

## 2. Generative Engine Optimization is real and measurable

GEO has moved from academic concept to active industry practice in under two years. The foundational paper — "GEO: Generative Engine Optimization" by Aggarwal et al. (Princeton, IIT Delhi, Georgia Tech) — was published at **ACM SIGKDD 2024** and tested 9 optimization strategies against generative engine outputs. The results are specific: **statistics boost visibility by 33.9%**, expert quotes by 32%, citations to authoritative sources by 30.3%, and clear fluent writing by 30%. Keyword stuffing actually reduced visibility by 10%.

**Content structures LLMs preferentially cite** follow patterns distinct from traditional SEO. Lead with a direct answer in the first **40–60 words** of each section. Include statistics every 150–200 words with source attribution — AI systems cannot generate data, so they gravitate toward sources providing it. Use question-format headings followed by concise answers matching how users query AI systems. GenOptima's analysis of 449 citations found **74.2% of all AI citations come from structured "Top N" content**. Pages with FAQ sections, comparison tables near the top, and standalone self-contained sentences with specific data points perform best.

**Schema markup correlates with citation likelihood.** Microsoft's Fabrice Canel confirmed at SMX Munich (March 2025) that "Schema markup helps Microsoft's LLMs understand content." **65% of pages cited by Google AI Mode include structured data; 71% for ChatGPT.** The recommended "triple stack" — Article + ItemList + FAQPage on ranking pages — produces 1.8× more citations than Article schema alone. However, schema alone doesn't compensate for weak content; SE Ranking's analysis found correlations between schema types and citations are "extremely small in practical terms."

**Monitoring brand mentions in LLM outputs** is now served by a growing ecosystem of tools. Otterly.AI (20,000+ professionals, from $29/month) tracks across ChatGPT, Perplexity, Google AI Overviews, Gemini, and Copilot with a 25-factor GEO audit. Other notable platforms include Peec AI (share of voice tracking), Spotlight (covers 7 AI platforms), and AthenaHQ (from $295/month for enterprise). For DIY monitoring, track referral traffic from ai.com, perplexity.ai, and claude.ai in GA4 — ChatGPT appends `utm_source=chatgpt.com` to citation links since June 2025.

**The `llms.txt` proposed standard** (by Jeremy Howard, hosted at llmstxt.org) places a Markdown file at `/llms.txt` providing LLMs a curated table of contents. Its companion `llms-full.txt` contains complete website content in Markdown format. Current adoption status is mixed: Anthropic has published an llms.txt on their site, Yoast and AIOSEO support generation in WordPress, but Semrush analysis found zero visits from GPTBot, ClaudeBot, or PerplexityBot to llms.txt files. It's low-risk to implement but unproven.

**Platform-specific optimization differs significantly.** ChatGPT Search uses Bing's infrastructure (set up Bing Webmaster Tools first), favors Wikipedia (47.9% of top-10 citations), and sessions convert at **2.3× the organic Google rate**. Perplexity crawls the web in real-time for every query, making freshness the primary lever — content with "Last Updated" timestamps outperforms older content. Google AI Overviews show 86% domain overlap with organic results, but the newer Google AI Mode shows only 54% overlap, suggesting increasingly independent source selection.

---

## 3. Answer engines reward extractable, structured content

Featured snippets capture **8–35% of all clicks** for a given query, and 99.58% come from pages already ranking in the top 10. The technical approach to winning them is structural, not magical.

**Paragraph snippets** (the most common type) require a concise 40–60 word answer in a `<p>` tag immediately below a question-format `<h2>` or `<h3>` heading. Start with "is" statements as trigger patterns. **List snippets** need proper `<ol>` or `<ul>` markup with `<li>` tags — Google also compiles list snippets by pulling H2/H3 headings from content. **Table snippets** require semantic `<table>`, `<th>`, `<tr>`, `<td>` elements for comparisons, pricing, or specifications.

**People Also Ask optimization** is achievable from any ranking position — a page at position 12 can win PAA placement with a more direct answer than higher-ranking pages. PAA visibility grew **34.7% in the US from February 2024 to January 2025**. The implementation pattern: use AlsoAsked.com's API (supports webhooks) to build a PAA question database per vertical, map questions to existing content pages, then add question-format H2/H3 headings with 40–60 word direct answers.

**Google AI Overviews** use a "query fan-out" technique, breaking queries into subtopics and issuing dozens of background searches. Being cited in an AI Overview yields **35% more organic clicks** versus not being cited. **99.5% of AI Overview source URLs appear in the top 20 organic results**, and approximately 40–61% of AI Overviews contain bullet points or step-by-step instructions. The content framework that wins citations is CSQAF: Citations to authoritative sources, Statistics with attribution, Quotations from experts, Authoritative confident writing, and Fluent logical structure.

**Speakable schema** (`SpeakableSpecification`) remains in beta, limited to English-language news on Google News-approved sites. Implementation uses `cssSelector` to identify TTS-suitable sections targeting 20–30 seconds of spoken content. Despite limited current support, implementing it positions content for voice assistant expansion.

**For multi-tenant implementation**, build content templates with an answer-first block (40–60 words after H1), question-format section headings, comparison tables, and FAQ sections. Generate JSON-LD schema automatically per page type. Use SEMrush or Ahrefs APIs to identify featured snippet opportunities by filtering ranking keywords (positions 1–10) with existing snippets you don't own, then prioritize by search volume × position proximity.

---

## 4. Programmatic SEO requires quality gates at every stage

Google's March 2024 Core Update introduced **"Scaled Content Abuse"** as a formal spam policy, replacing the older "spammy automatically-generated content" policy. The policy is now **method-agnostic** — it targets mass content creation intent regardless of whether pages are produced by AI, automation, or humans. Google's Helpful Content System now acts as a **site-wide classifier**, meaning even a few unhelpful pages can affect the entire domain.

**Content uniqueness scoring** is the engineering foundation. For scale, use **MinHash with Locality-Sensitive Hashing** via the `datasketch` Python library. Configure with 128–256 permutations and a Jaccard similarity threshold of 0.7. Pages above 85% pairwise similarity within a site are at risk; aim for less than 70% similarity between any two pages. Google's internal threshold isn't published, but analysis of penalized sites suggests templates with less than 30% unique content per page are high-risk. For web-level plagiarism checking, Copyscape's API costs $0.03/search for the first 200 words. For semantic deduplication that catches paraphrased content, run a second pass with `sentence-transformers` embeddings and cosine similarity.

**Internal linking automation** has evolved from keyword-matching to embedding-based approaches. Generate page embeddings with `all-MiniLM-L6-v2`, compute cosine similarity, and automatically link each page to its top-K most semantically related pages. Maintain a **3:1 ratio** of downward (pillar→cluster) to upward (cluster→pillar) links, keep every page within 3 clicks of the homepage, and cap at 40–50 links per page including navigation. Enterprise tools like InLinks (entity-based, 100K+ URLs) and Quattr (NLP-powered with GSC integration) automate this at scale.

**Indexation monitoring** through the Google Search Console URL Inspection API provides the authoritative signal. The API allows **2,000 calls/day per property** and returns `indexingState`, `coverageState`, `lastCrawlTime`, and the critical comparison between `googleCanonical` and `userCanonical`. Scale beyond the daily limit by verifying multiple GSC properties at the subdomain level, prioritizing URLs by importance tier, and rotating checks across days. For Bing and Yandex, implement the **IndexNow protocol** — it now handles 5+ billion URLs submitted daily across 80+ million websites, but Google has not adopted it despite testing since 2021.

**Crawl budget management** matters for sites with 1M+ pages. Each hostname gets separate crawl budget, so the subdomain-vs-subfolder decision directly impacts crawl allocation. Segment sitemaps by category/tenant/priority with aggressive `<lastmod>` dates. Block faceted navigation URLs via robots.txt and canonical the unfiltered category page. Layer defenses: use `robots.txt` for infinite URL generators (calendars, search, session IDs), `noindex` for pages that exist but shouldn't rank, and `canonical` for legitimately different URLs with similar content.

**Progressive rollout** is essential: start with 50–500 pages, validate quality signals (indexation rate, bounce rate, engagement metrics) before scaling to thousands. Sample 5–10% of generated pages for human review. Prune pages that fail to gain traction after 6 months.

---

## 5. Core Web Vitals gates should fail your builds

Google uses only field data (CrUX) for search ranking, but **lab data in CI prevents regressions before they reach users**. The three thresholds are hard numbers: **LCP ≤ 2.5s, CLS ≤ 0.1, INP ≤ 200ms**. INP replaced FID in March 2024, but Lighthouse CI measures TBT (Total Blocking Time) as a proxy since INP requires real user interactions.

**Lighthouse CI configuration** should use `'error'` assertions (not `'warn'`) to fail builds. The key `lighthouserc.js` settings: set `categories:performance` and `categories:seo` to minimum 0.9, `largest-contentful-paint` to maxNumericValue 2500, `cumulative-layout-shift` to 0.1, and `total-blocking-time` to 200 as the INP proxy. Run 3–5 iterations per URL and use the median. The `treosh/lighthouse-ci-action@v12` GitHub Action integrates with Lighthouse CI's GitHub App for status check annotations on every PR.

**Bundle size enforcement** complements Lighthouse scoring. The `size-limit` npm package measures JS bundle size plus execution time using headless Chrome, with PR comment integration via `andresz1/size-limit-action`. Configure per-bundle limits in `package.json` and run as part of the test suite.

**Real User Monitoring** via the `web-vitals` library (v5, ~2KB brotli'd) is the only way to measure true INP. Deploy it centrally in the shared platform code, tag metrics with tenant identifiers, and stream to your analytics backend via `navigator.sendBeacon`. The attribution build (`web-vitals/attribution`) adds diagnostic information identifying which element and scripts caused slow INP. Supplement with the CrUX API for Chrome field data at the 75th percentile (28-day rolling average), though note smaller tenant subdomains may lack sufficient traffic for CrUX visibility — making custom RUM essential.

**For multi-tenant monitoring**, deploy `web-vitals.js` in shared platform code, aggregate by tenant in BigQuery or ClickHouse, and alert when any tenant's p75 metrics cross thresholds. Use Unlighthouse for automated crawl-and-audit across tenant sites.

---

## 6. Framework choice determines your SEO floor

The rendering framework establishes baseline SEO capability that's difficult to overcome later. **Astro delivers the best Core Web Vitals out of the box** through its islands architecture and zero-JS default — it ships no JavaScript unless components explicitly opt in. **Next.js offers the most versatile rendering** for dynamic multi-tenant platforms via its combination of SSR, SSG, ISR, and the new Partial Prerendering (PPR) that combines static shells with dynamic streams.

**Framework SEO ranking for content platforms**: Astro (best CWV, minimal JS) → Next.js (most versatile, ISR scales to millions of pages) → Nuxt 3 (strong convention-driven SSR with Nitro edge deployment) → Remix (smallest React bundles at ~371KB vs Next.js's ~566KB, streaming SSR) → SvelteKit (smallest runtime, compiler-based approach with no virtual DOM).

**Edge rendering reduces TTFB by 60–80%** compared to origin-server rendering — from 200–800ms down to 20–50ms. Cloudflare Workers (330+ global locations, cold starts <5ms) support SSR for Remix, SvelteKit, and Nuxt via Nitro. Vercel Edge Functions provide 0ms cold starts with 126 points of presence. For multi-tenant platforms, edge SSR improves crawl efficiency and industry reports indicate **10–15% more pages indexed within 8 weeks**.

**Dynamic rendering is officially deprecated.** Google's documentation now carries a red warning recommending SSR, SSG, or hydration instead. Google removed the implementation guide, verification, and troubleshooting sections in December 2025. Googlebot's Web Rendering Service uses the latest stable Chromium (evergreen since May 2019) with support for 1,000+ modern features including ES6+, Web Components v1, and all modern frameworks. Rendering remains a two-phase process (crawl → render queue), so JS-only content may face indexing delays, but full SSR eliminates this concern entirely.

**ISR for multi-tenant scale**: Use `dynamicParams: true` with `generateStaticParams` returning only high-traffic pages at build time. Remaining pages generate on-demand on first visit, then cache. On-demand revalidation via `revalidateTag()` invalidates only affected pages when a tenant updates content. Set `revalidate` intervals appropriate to content type — 1 hour for product pages, 24 hours for blog posts. Always use `fallback: 'blocking'` so crawlers get complete HTML on first visit.

---

## 7. JSON-LD structured data should be generated from your content model

Use `@graph` with `@id` cross-references for connected entity relationships, generated server-side during SSR. The **`schema-dts`** npm package (100K+ weekly downloads, by Google) provides TypeScript types for all Schema.org vocabulary with zero runtime cost. In React, `react-schemaorg` provides component-based rendering. In Nuxt, `nuxt-schema-org` auto-generates WebSite + WebPage nodes and offers 30+ composable types.

**Google deprecated HowTo rich results** entirely in September 2023 and **restricted FAQ rich results** to well-known government and health websites in August 2023. In June 2025, seven more types were deprecated including Book Actions, Claim Review, and SpecialAnnouncement. The schema types still producing rich results: **Product, Article, BreadcrumbList, Organization, SoftwareApplication, Event, Recipe, and LocalBusiness**.

For **multi-entity pages**, use a single `@graph` block when entities reference each other. Define stable `@id` URIs (e.g., `https://yourdomain.com/#org`, `#website`, `#person-jane`) and cross-reference via `{"@id": "https://example.com/#org"}`. Build a schema factory function per content type that accepts tenant and page data, generates the Organization node from tenant config, and switches on page type to produce Article, Product, or other schemas alongside BreadcrumbList. Inject via `<script type="application/ld+json">` server-side — client-side `useEffect` injection risks an 800ms–1.2s delay that can result in empty schema for Google.

**SoftwareApplication schema** for SaaS products requires `name`, `offers` (even free apps: `"price": "0"`), and either `aggregateRating` or `review`. Use `WebApplication` subtype with `browserRequirements` for web apps. Multiple pricing tiers use `AggregateOffer` with `lowPrice`/`highPrice`/`offerCount`.

---

## 8. International SEO at scale demands sitemap-based hreflang

For multi-tenant platforms, **XML sitemap-based hreflang is the recommended implementation method** — it centralizes management, avoids HTML `<head>` bloat, and enables programmatic generation. Each `<url>` entry includes `<xhtml:link>` elements for all language/region alternates, always including a self-referencing tag and an `x-default` fallback.

**Subdirectories are the recommended URL structure** for multi-tenant platforms starting out. They consolidate domain authority across all locales, share crawl budget efficiently, and minimize setup complexity. Research across 20,000 keywords in 15 markets found ccTLDs hold over 50% of top ranking positions globally but require significantly more resources. Shopify Markets defaults to subfolders; HubSpot uses subdirectories for multi-language content groups.

**The most common hreflang errors** that engineering teams introduce: missing bidirectional return links (if Page A references Page B, Page B must reference Page A — missing this causes Google to potentially ignore all annotations), conflicting canonical and hreflang signals (hreflang URLs must match canonical URLs), non-200 status codes on hreflang targets, mixing www and non-www across locales, and using incorrect language codes (`hreflang="uk"` is wrong; `hreflang="en-GB"` is correct — always ISO 639-1 language + ISO 3166-1 alpha-2 country).

**CDN-level locale routing** via Cloudflare Workers or Vercel Edge Middleware should route based on `Accept-Language` + geo-IP, but must always allow Googlebot to access all language versions without forced redirects. Set `Vary: Accept-Language` for proper caching and use 302 (temporary) redirects, not 301.

---

## 9. Log file analysis reveals your true crawl efficiency

An e-commerce case study found Googlebot spending **75% of crawl budget on faceted navigation URLs that weren't even indexed**. After implementing fixes, faceted crawling dropped to 8%, product page crawling rose to 79%, and new product indexation time fell from 14 days to 3.

**The recommended pipeline for cloud-native platforms**: Cloudflare → Logflare → BigQuery → Looker Studio. This provides real-time log streaming, SQL-based analysis at ~$5/TB scanned, and permanent data ownership. Cost: approximately $20–25/month for a site with 10M requests/month. For self-hosted environments, the ELK stack (Filebeat → Logstash → Elasticsearch → Kibana) provides full customization with open-source tooling. Use Logstash grok patterns to tag search engine bots and extract URL path components for per-section analysis.

**Verify Googlebot identity** via reverse DNS — user-agent strings can be spoofed. Resolve the IP to confirm it matches `*.googlebot.com` or `*.google.com`, then forward-resolve the hostname to verify it matches the original IP. As a quick heuristic, most Google search bots use IPs starting with `66.`.

**Key metrics to track**: total Googlebot requests per day (trend), requests by URL type/template (percentage distribution), status code breakdown (target >90% 200s), average response time per URL type (target <500ms), crawl depth distribution, and the ratio of crawled-but-not-indexed pages (cross-reference with GSC). Set alerts for sudden crawl frequency drops exceeding 50%, spikes in 5xx errors, or unexpected bot user-agents. Python scripts using `pandas`, `apache-log-parser`, and `dnspython` handle custom analysis efficiently, while commercial tools like JetOctopus, Botify, and OnCrawl provide turnkey dashboards.

---

## Conclusion: building the SEO-native platform

The technical surface area of SEO has expanded dramatically but the engineering response is convergent: **treat every SEO requirement as a testable constraint in your build pipeline**. The five highest-impact investments for a multi-tenant platform launching today are: (1) Lighthouse CI with SEO score gating and performance budgets as required status checks, (2) server-side JSON-LD generation from content models using `schema-dts` types with `@graph` cross-references, (3) ISR with edge rendering for sub-50ms TTFB across all tenants, (4) content uniqueness scoring via MinHash LSH blocking any page above 70% similarity from publishing, and (5) structured content templates with answer-first blocks and question-format headings that serve both featured snippets and AI citations simultaneously.

GEO is not replacing SEO — **76.1% of AI Overview citations also rank in Google's top 10** — but the optimization surface is diverging. The platforms that will win visibility across all four channels are those embedding these constraints into their engineering culture: validated at build time, measured with RUM in production, and monitored across both traditional SERPs and the growing constellation of AI answer engines.