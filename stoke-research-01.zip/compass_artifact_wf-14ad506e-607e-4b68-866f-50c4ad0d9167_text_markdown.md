# TypeScript and Node.js production engineering: what AI agents get wrong

**The gap between TypeScript tutorials and production TypeScript is enormous — and AI coding agents consistently fall into that gap.** This report covers the advanced type patterns, runtime behaviors, framework choices, and configuration details that separate production-grade TypeScript/Node.js engineering from demo code. It synthesizes real patterns from Vercel, Stripe, Prisma, tRPC, Hono, and Cloudflare, alongside production war stories, benchmark data through 2026, and actual AI configuration files teams use to keep agents on track. Every recommendation targets the specific stack of React web apps, React Native, NestJS/Fastify APIs, and Cloudflare Workers.

---

## Advanced type patterns that actually ship in production

AI agents love generating clever types. The question is which patterns real teams use daily versus which exist only in Type Challenges. The answer is clear: **discriminated unions and `as const satisfies` are universal; branded types are growing; template literal types are framework-critical; `NoInfer` is the newest essential utility.**

**Branded types** solve the problem of passing a `UserId` where an `OrderId` belongs — both are `string`, so TypeScript won't catch the swap. The pattern intersects a primitive with a phantom property: `type UserId = string & { readonly __brand: "UserId" }`. Heartbeat uses this across **50+ ID types** by post-processing Prisma's generated `index.d.ts` with a `jscodeshift` codemod, replacing generic `string` with branded types like `CommunityID` and `ChannelID`. Effect-TS ships `Brand.nominal()` and `Brand.refined()` as first-class features. Prisma has an open feature request (#12860) for native `brandTypes` support but doesn't ship it yet. Stripe uses prefixed IDs (`cus_`, `pi_`, `ch_`) at the API level but types them as plain `string` in their SDK — a missed opportunity that template literal types like `` type CustomerId = `cus_${string}` `` can fill.

AI agents consistently botch branded types by forgetting the initial cast (`uuidv4() as UserId`), creating runtime overhead instead of compile-time-only phantom brands, or not handling ORM integration where queries return plain `string`.

**Discriminated unions** are the most universally adopted pattern. Zod ships `z.discriminatedUnion()`. tRPC uses them internally for procedure types. XState, Redux, and Hono all depend on them. The key production pattern models impossible states as unrepresentable:

```typescript
type ApiState<T> =
  | { status: "idle" }
  | { status: "loading"; startedAt: Date }
  | { status: "success"; data: T; fetchedAt: Date }
  | { status: "error"; error: Error; failedAt: Date };
```

The critical companion is exhaustive checking via `assertNever` in `default` cases. AI agents routinely use optional properties (`{ loading?: boolean; data?: T }`) instead of discriminated unions, allowing invalid combinations like `{ loading: true, data: [...] }` to exist.

**Template literal types** power Hono's core framework feature — path parameters are inferred as literal types, and the `hc<typeof app>()` RPC client provides full autocomplete from route definitions. Cloudflare uses Hono internally for D1, KV, Workers Logs, and Queues APIs, all relying on template literal type inference. The pattern also validates Stripe-style prefixed IDs at compile time. AI agents create explosively large union types by combining too many template literal unions, causing "Expression produces a union type that is too complex" errors.

The **`as const satisfies`** combo (TypeScript 4.9+) is now the standard for config objects. `as const` preserves literal types and readonly; `satisfies` validates shape without widening. Matt Pocock's framework: colon annotation (`:Type`) means "type beats value" (widens); `satisfies` means "value beats type" (preserves specificity); `as` means "you're lying to TypeScript." AI agents consistently use `: Type` annotation or `as Type` when `satisfies` is the correct choice, losing literal type inference or hiding bugs.

**`NoInfer<T>`** (TypeScript 5.4+) controls which parameter drives generic inference. Without it, a state machine config where `initial` should be constrained to `states` values would widen `TState` to include any string passed to `initial`. AI agents don't know `NoInfer` exists and instead add a second generic parameter with complex constraints.

The **codegen vs. inference tradeoff** is worth understanding. Prisma pre-computes types via code generation — **72% faster type checking than Drizzle** according to Prisma's benchmarks. Drizzle derives types at compile time using conditional and mapped types — no build step, but slower IDE experience with large schemas. Both use the same TypeScript features; the timing differs.

---

## TypeScript strict mode: the flags that catch real production bugs

The `strict: true` flag enables a family of checks, but several powerful flags remain opt-in. **TypeScript 6.0 (announced August 2025, RC available) makes `strict: true` the default** — a major ecosystem shift. Beyond the baseline, six flags deserve attention.

**`noUncheckedIndexedAccess`** is the single most impactful flag not included in `strict`. It adds `| undefined` to any value accessed via index signature or array indexing. Matt Pocock calls it "the most awesome config option you've never heard of." Without it, `arr[0]` on an empty array is typed as `T`, not `T | undefined` — a lie that causes runtime crashes. Array out-of-bounds and missing object keys are among the most common production bugs. The TypeScript team declined to include it under `strict` (GitHub Issue #49169) due to disruption concerns, but **it belongs in every new project's tsconfig**.

**`exactOptionalPropertyTypes`** distinguishes between a property being absent versus explicitly `undefined`. With it, `colorTheme?: "dark" | "light"` cannot be set to `undefined` — the property must be omitted or assigned a valid value. This catches real bugs in data models and DTOs. However, Zod's `.optional()` generates `{ field?: T | undefined }`, conflicting with this flag. Radix UI and `@typescript-eslint/utils` also have known incompatibilities. Enable it for new projects but expect friction with dependencies.

**`verbatimModuleSyntax`** (TypeScript 5.0) replaces the confusing trio of `importsNotUsedAsValues`, `preserveValueImports`, and `isolatedModules`. It forces explicit `import type` for type-only imports — what you write is exactly what gets emitted. Essential for Node.js type stripping and predictable module behavior.

**`erasableSyntaxOnly`** (TypeScript 5.8+) errors on TypeScript constructs that generate runtime code: enums, namespaces with runtime code, and parameter properties. The primary motivation is **Node.js type stripping** — Node.js v23.6+ can natively execute `.ts` files by stripping types via SWC/Amaro, but only erasable syntax. This flag ensures compatibility. The recommended enum alternative is universally agreed upon:

```typescript
const Color = { Red: "red", Green: "green", Blue: "blue" } as const;
type Color = (typeof Color)[keyof typeof Color];
```

**`isolatedModules`** ensures each file can be independently transpiled — required by Vite (esbuild), SWC, and Babel. Largely superseded by `verbatimModuleSyntax` which provides stricter guarantees. **`noPropertyAccessFromIndexSignature`** forces bracket notation for index signature access, making it visually obvious when accessing dynamic properties. Useful but causes friction with `process.env.*` since `ProcessEnv` uses an index signature — a common Next.js footgun.

The recommended "strictest" configuration for a 2025-2026 project:

```json
{
  "strict": true,
  "noUncheckedIndexedAccess": true,
  "exactOptionalPropertyTypes": true,
  "verbatimModuleSyntax": true,
  "erasableSyntaxOnly": true,
  "noImplicitReturns": true,
  "noImplicitOverride": true,
  "noFallthroughCasesInSwitch": true
}
```

---

## Runtime validation: Zod v4, Valibot, ArkType, and TypeBox in 2026

The runtime validation landscape shifted dramatically with Zod v4's mid-2025 release and the **Standard Schema specification** (co-authored by creators of Zod, Valibot, and ArkType). Standard Schema provides a ~60-line type interface that any validation library can implement, and tRPC, TanStack Form, Hono, and React Hook Form all consume it. You can now swap validation libraries without rewriting integration code.

**Performance tiers are clear.** ArkType and TypeBox+Ajv sit at the top through JIT and AOT compilation respectively. Valibot is ~2× faster than Zod v3 and comparable to Zod v4 for repeated validations. Zod v4 introduced internal JIT compilation that makes reused schemas **8× faster than Zod v3** — but schemas created and used only once (common in React components and serverless cold starts) see a **17× performance regression** due to compilation overhead. For Cloudflare Workers, this matters.

**Bundle size is the decisive factor for edge deployments.** Valibot tree-shakes to **~1.4 KB** for a simple schema — a 90% reduction compared to Zod's ~12 KB. Zod v4 introduced `@zod/mini` (~1.9 KB gzipped) with a functional API to address this. ArkType's JIT parser pushes it to **~42 KB**, making it unsuitable for Workers. TypeBox sits at ~7 KB. For Cloudflare Workers' 3 MB free plan limit and 1-second startup requirement, Valibot or Zod Mini are the only sensible choices.

The **schema-first development** pattern — deriving TypeScript types FROM validation schemas, never the reverse — is universally supported: `z.infer<typeof Schema>` (Zod), `v.InferOutput<typeof Schema>` (Valibot), `typeof User.infer` (ArkType), `Static<typeof Schema>` (TypeBox). Never write interfaces manually then add validation separately. This eliminates drift between runtime validation and compile-time types.

For **Fastify APIs**, TypeBox is the clear winner. It IS JSON Schema natively, integrates with Fastify's `TypeBoxValidatorCompiler` for extremely fast validation, and auto-generates OpenAPI documentation. Val Town switched from Zod to TypeBox specifically for this. For **tRPC stacks**, Zod v4 remains the default with the deepest ecosystem integration (78+ packages). For **React forms**, Valibot's minimal bundle makes it ideal for client-side validation via React Hook Form's `standardSchemaResolver()`.

**Zod v3 → v4 breaking changes that AI agents get wrong:** `.strict()` became `z.strictObject()` as a top-level function; `.merge()` is deprecated (use `.extend()`); `.superRefine()` became `.check()`; `z.coerce.string()` input type changed from `string` to `unknown`; `.default()` now always applies even when the field is absent, which **breaks partial update patterns**. AI agents also misuse `z.coerce.boolean()` without understanding that `"false"` coerces to `true` (non-empty string is truthy).

---

## Node.js event loop and memory: production war stories

The event loop is where AI-generated code most consistently fails — agents write code that appears correct but blocks the loop, starves queues, or leaks memory under production load.

**Microtask queue starvation** is the most dangerous pattern. The event loop drains microtasks (Promises, `queueMicrotask()`, `process.nextTick()`) completely before processing macrotasks (timers, I/O). If microtasks enqueue more microtasks recursively, I/O callbacks never fire. A team using Effect.ts to process **~8,000 WebSocket events/sec** discovered their `Stream.mapEffect` kept the microtask queue perpetually full, preventing Node.js from reaching the I/O poll phase. Postgres queries showed **2-4 second latency** despite 100ms database RTT. The fix: switching to `setImmediate(runBatch)` dropped latency to 100ms at a 12% throughput cost.

Trigger.dev experienced production crashes from an **O(n²) nested loop** processing 20k+ trace logs combined with live-reload every second. After fixing the root cause, they deployed an event loop monitor using `node:async_hooks` that produces OpenTelemetry spans when the loop blocks for >100ms — a pattern worth adopting. DraftKings documented event loop saturation during SSR traffic spikes: at 500 req/s, event loop utilization hit 100%, causing responses that took **698μs at the service** to appear as **397ms from the app's perspective**.

**`UV_THREADPOOL_SIZE`** defaults to 4 threads and governs all `fs.*` async calls, `dns.lookup()`, crypto operations, and zlib. The most common production issue: DNS lookups from outbound HTTP requests exhaust the thread pool, blocking all file I/O and crypto behind them. Set it to the number of CPU cores for general services, or **64+ for DNS-heavy services**. Critical: it must be set as an environment variable before process start — setting `process.env.UV_THREADPOOL_SIZE` in code doesn't work because libuv initializes the pool on first use.

For **event loop monitoring**, use `monitorEventLoopDelay()` from `perf_hooks` (histogram with percentiles) and `performance.eventLoopUtilization()` (0.0 idle to 1.0 saturated). Alert at **0.8 utilization** (warn) and **0.95** (critical). For lag, warn at **50ms** and alert at **100ms**.

The **cluster module vs. container scaling** debate has settled: they're complementary. In Kubernetes, use container replicas for scaling and the cluster module inside multi-core pods to utilize all cores. Halodoc uses PM2 clustering inside K8s pods because pod restarts take ~2 minutes while process restarts are near-instant. For CPU-bound work, **Piscina** (by NearForm/Matteo Collina) is the standard worker thread pool — it handles lifecycle, task queuing, and backpressure.

**Memory management** requires understanding V8's container awareness. Since Node.js 12, the heap auto-sizes to **~50% of container memory** up to ~2 GB. The critical rule: **never set `--max-old-space-size` equal to container memory** — the pod will be OOM-killed before V8 can garbage collect. Reserve 500 MB–1 GB for non-heap overhead; allocate 50-70% of remaining RAM to heap. A Deezer team upgrading Node.js 18→20 hit unexpected heap issues because V8 11.3 changed semi-space computation, shrinking it from ~32 MB to ~8 MB in containers, causing excessive GC and CPU consumption.

The **top memory leak patterns** that AI agents introduce: unbounded caches (global objects that grow forever — use LRU with max size), event listeners added per-request but never removed (use `.once()` or clean up on connection close), closures capturing large scopes (null out references), and timers never cleared. When you see `MaxListenersExceededWarning`, **don't increase the limit — fix the leak**. Use `--heapsnapshot-near-heap-limit=3` in production for automatic crash diagnostics.

---

## Fastify, Express, Hono, and Elysia: choosing by deployment target

The framework choice is now deployment-target-specific rather than one-size-fits-all. **Express 5 finally shipped** (October 2024, became `latest` on npm March 2025), but it's a modernization release, not a performance overhaul.

**For Cloudflare Workers: Hono is the only serious choice.** Purpose-built by a Cloudflare employee, ~14 KB bundle, **402,820 ops/sec** on Workers router benchmarks (fastest), native bindings for D1/KV/R2/Durable Objects. Cloudflare uses it internally for multiple products. Hono now has **14.3 million weekly npm downloads**, surpassing Fastify.

**For Node.js APIs: Fastify delivers 2-3× Express throughput** through optimized JSON serialization, radix-tree routing, and schema-based serialization. Its encapsulated plugin system prevents the middleware-ordering bugs that plague Express at scale. NestJS's official `@nestjs/platform-fastify` adapter is a drop-in replacement yielding ~2× better benchmarks than the Express adapter. TypeBox integration provides the best validation DX: define schema once, get TypeScript types + runtime validation + OpenAPI docs automatically.

**For Bun: Elysia** achieves **~397,000 req/s** with the best TypeScript type inference of any framework — 7 generic type parameters track type transformations through every method call, and Eden Treaty provides tRPC-like end-to-end safety without code generation. However, watch for the v1.4 AOT regression (45.7× performance degradation, December 2025 — use `aot: false` as workaround).

**For multi-runtime/serverless: Hono** runs identical code on Node.js, Bun, Deno, Workers, Vercel Edge, and Lambda via Web Standards (Fetch API). It's growing fastest at 26.6% month-over-month npm growth. The caveat: on Node.js specifically, Hono is **slower than Fastify** due to its Web Standards adapter converting between Fetch API and Node's HTTP. Hono's creator acknowledged: "In the Node environment, Hono is very slow because it uses an Adapter."

**Hono's TypeScript scaling issue** deserves mention: at scale (hundreds of endpoints), type inference can cause **8-minute compile times** in CI (GitHub Issue #3869). For large API surfaces, Fastify's TypeBox type provider may compile faster.

Express 5's key improvements: async error handling (rejected promises auto-caught), security updates to path-to-regexp@8.x (ReDoS mitigation), Node.js 18+ required, wildcard routes must be named (`/*splat` not `/*`). It is not TypeScript-first and adds no performance optimizations.

---

## ESM finally won, and streaming still matters

The ESM/CJS debate is effectively over. **`require(esm)` was marked stable in December 2025** across all supported Node.js LTS lines (v20.19.0+, v22.12.0+). CJS code can now `require()` ESM modules — the previously impossible direction. This removed the last practical barrier to ESM-only packages. ESM adoption on npm grew from **7.8% in 2021 to 25.8% by end of 2024**, and the trend is accelerating.

The consensus is clear: **ship ESM-only for new packages**. Anthony Fu (Vitest, Nuxt core), Sindre Sorhus, and the e18e community all advocate this position. Dual-package publishing carries the "dual-package hazard" — CJS and ESM versions loaded simultaneously create separate module instances, breaking singletons and `instanceof` checks. If you must dual-publish, use **tsup** (`tsup src/index.ts --format cjs,esm --dts --clean`) or the newer **tsdown** from the Rolldown ecosystem.

For TypeScript `moduleResolution`: use **`nodenext`** for libraries (ensures universal compatibility) and **`bundler`** for apps processed by Vite/Webpack/esbuild (allows extensionless imports). The old `node` resolution doesn't understand `package.json` exports and is deprecated. TypeScript requires `.js` extensions in imports under `nodenext` even for `.ts` files — a consistent source of confusion.

**Jest's ESM support remains experimental** as of Jest 30 (June 2025). Vitest has effectively replaced it for modern TypeScript projects: native ESM support, **2-10× faster** benchmarks, Jest-compatible API. Use Vitest for new projects; keep Jest for React Native (better support) or existing codebases.

For **streaming**, always use `pipeline()` from `stream/promises` instead of `.pipe()`. `pipeline()` handles backpressure automatically, propagates errors, and destroys all streams on failure. The golden rule of backpressure: **never call `.write()` after it returns `false`** — wait for the `drain` event. The `highWaterMark` is a threshold (default 16 KB), not a limit.

Rules of thumb: buffer files under 1 MB, stream anything over 100 MB (required over 2 GB — `fs.readFile` throws `ERR_FS_FILE_TOO_LARGE`), and stream HTTP responses for payloads over 10 KB. Streaming uploads are **~3× faster** than buffered uploads with nearly constant memory regardless of concurrency.

The **Web Streams API** (`ReadableStream`, `WritableStream`) is stable in Node.js 18+ but adoption remains mixed. On Cloudflare Workers, Deno, and Bun, Web Streams are the native and only option. On Node.js, stick with Node streams for better ecosystem support and `pipeline()`. Conversion utilities exist: `Readable.fromWeb()` and `Readable.toWeb()`.

---

## Monorepo TypeScript: Turborepo and Nx disagree on project references

The monorepo tooling landscape reveals a fundamental disagreement. **Turborepo explicitly advises against TypeScript project references**, stating they "introduce another point of configuration as well as another caching layer" that conflicts with Turborepo's own caching. Turborepo prefers "Just-in-Time packages" — internal packages that export `.ts` files directly, with the consumer's bundler handling transpilation:

```json
{
  "name": "@repo/ui",
  "exports": { "./button": "./src/button.tsx" }
}
```

**Nx recommends project references** for large monorepos and can automatically sync them with workspace dependencies — solving the biggest pain point of manual `references` list maintenance. Nx provides architectural lint rules (module boundary rules) that catch invalid cross-package imports before deeper issues surface.

**Both agree on these fundamentals:** use `pnpm` workspaces for package management, create a shared `@repo/typescript-config` package with base tsconfig files, and use `package.json` exports (not path aliases) for package resolution. The TypeScript team itself recommends against path aliases, preferring package manager workspaces. Node.js **subpath imports** (`package.json#imports` with `#` prefix) are the modern alternative that works at runtime without additional tooling.

Critical detail: `include` and `exclude` arrays are **NOT inherited** from base tsconfig files. They must be redeclared in every extending config. AI agents routinely miss this.

For `package.json` exports, TypeScript only respects the `exports` field when `moduleResolution` is set to `nodenext`, `node16`, or `bundler`. With the old `node` resolution, it falls back to legacy `main`/`types` fields. Always put the `"types"` condition first in conditional exports — this is a TypeScript requirement.

---

## AI coding agent configs: what production teams actually enforce

A clear ecosystem of AI configuration files has emerged: `.cursorrules` (Cursor), `CLAUDE.md` (Claude Code), `.github/copilot-instructions.md` (GitHub Copilot), `.windsurfrules` (Windsurf), and `SKILL.md` (Claude Code skills). The **PatrickJS/awesome-cursorrules** repository (37.3k stars) is the definitive collection.

Across all sources, these TypeScript rules appear with the highest consistency:

**Never use `any`** — use `unknown` plus narrowing instead. This is the single most universal rule, appearing in GitHub's official Copilot instructions, Windsurf rules, every CLAUDE.md template, and most `.cursorrules` files. **Avoid enums** — use `as const` objects with derived types. This aligns with `erasableSyntaxOnly` and Node.js type stripping. **Use discriminated unions** for state machines and events. **Model expected errors as return values** (not try/catch): `{ success: boolean, data?: T, error?: AppError }`. **Prefer `unknown` in catch blocks** then narrow.

The **MCP TypeScript SDK's CLAUDE.md** is a good reference: strict type checking, ES modules, explicit return types, `.js` extensions in imports, 2-space indentation, semicolons, single quotes, JSDoc for public APIs. Matteo Collina (Node.js core contributor) maintains 11 Claude Code skills covering Node.js, Fastify, TypeScript, and OAuth.

**SpillwaveSolutions' mastering-typescript-skill** targets enterprise TypeScript: TypeScript 5.9+ with `strict: true`, `noUncheckedIndexedAccess`, `exactOptionalPropertyTypes`, Zod validation, NestJS development, and Vite 7 + pnpm + ESLint 9 flat config.

The most actionable meta-insight: **keep CLAUDE.md under 80 lines**. HumanLayer reports that longer files cause Claude to ignore instructions. Include validation commands explicitly (`pnpm typecheck`, `pnpm test`, `pnpm lint`), show negative examples of what NOT to do, and reference specific existing files as pattern templates. Avoid vague instructions ("use good patterns") in favor of specific directives ("use `unknown` instead of `any`").

Common AI agent failures across all sources: using `throw new Error()` when the project uses `Result<T, E>` patterns, violating dependency layer boundaries (platform → core imports), generating out-of-date patterns from training data, hallucinating API methods, over-engineering with excessive types and abstractions, and having no concept of SOLID principles. PostHog's `.cursorrules` captures the sentiment: "DO NOT GIVE ME HIGH LEVEL SHIT, IF I ASK FOR FIX OR EXPLANATION, I WANT ACTUAL CODE."

---

## Conclusion

The production TypeScript/Node.js landscape in 2026 has a few clear trajectories. ESM has won — `require(esm)` stability removes the last CJS argument, and new packages should be ESM-only. TypeScript 6.0 making `strict: true` the default will push the ecosystem toward `noUncheckedIndexedAccess` and `exactOptionalPropertyTypes` as the next frontier. Validation is converging around Standard Schema, making library choice a deployment-target decision: Valibot for edge/Workers, TypeBox for Fastify, Zod for ecosystem breadth.

The framework story is now runtime-specific: Hono for Workers/edge, Fastify for Node.js APIs, Elysia for Bun. Express persists through inertia, not technical merit. For monorepos, the Turborepo "Just-in-Time packages" pattern (export `.ts` directly, no build step) is the simplest path; Nx's auto-managed project references suit larger organizations.

The most underappreciated insight: **TypeScript's type system is your primary defense against AI-generated bugs.** Enable every strict flag, use `pnpm typecheck` as a hard CI gate, write discriminated unions instead of optional properties, and keep your AI configuration files concise, specific, and version-controlled. The type checker catches what code review misses — and with AI agents writing increasing amounts of code, that safety net has never mattered more.