# Contract testing and schema evolution across a polyglot microservices stack

**Enforcing backward compatibility across REST, GraphQL, gRPC, and Kafka requires a layered defense: schema diff tools block breaking changes at PR time, consumer-driven contracts verify runtime integration points, schema registries guard event streams, and CI pipelines tie everything together with deployment gates.** This is not a single-tool problem — each protocol has its own evolution semantics, tooling ecosystem, and deployment ordering constraints. The good news is that production-grade tooling now exists for every layer of the stack, and a well-designed CI pipeline can catch **over 95% of breaking changes before they reach production**.

The architecture described here — polyglot services communicating via REST, GraphQL, gRPC, and Kafka — is common but demanding. Each protocol defines "breaking change" differently. REST breaks when you remove a response field; Protobuf breaks when you reuse a field number; Avro breaks when you add a required field without a default; GraphQL breaks when you make a nullable field non-nullable. A unified compatibility strategy must account for all of these semantics while remaining practical for engineering teams to adopt.

---

## Consumer-driven contract testing with Pact

Pact is the dominant framework for consumer-driven contract testing (CDCT). The workflow is deceptively simple: a consumer writes tests against a mock provider, generating a JSON contract (pact file). The provider then replays those interactions against its real implementation to verify it satisfies consumer expectations. Neither side needs the other's infrastructure to run — tests execute at **unit-test speed** with zero shared environments.

The consumer-side test defines expected interactions — specific requests and their expected responses. When these tests pass, Pact serializes them into a contract file. On the provider side, Pact starts the real API, replays each recorded request, and compares actual responses against consumer expectations. The framework follows **Postel's Law**: strict with outgoing requests, loose with accepted responses. A provider returning extra fields the consumer doesn't use will not break the contract.

The **Pact Broker** (open-source) or **PactFlow** (commercial, by SmartBear) serves as the central contract repository. It stores versioned contracts and verification results, building a **Pact Matrix** — a grid showing which consumer/provider version pairs have been successfully verified. Webhooks trigger provider verification automatically when consumer contracts change. The `can-i-deploy` CLI tool queries this matrix before every deployment, returning a binary pass/fail signal:

```bash
pact-broker can-i-deploy \
  --pacticipant OrderService \
  --version $(git rev-parse HEAD) \
  --to-environment production
```

This single command checks whether the candidate version is compatible with everything currently deployed in the target environment. It blocks deployments when verification results are missing or failed, and supports `--retry-while-unknown` for polling when provider verification is still running. After successful deployment, teams call `record-deployment` to update the matrix. This creates a **closed-loop deployment safety net** where no incompatible version can reach production.

**Pact V4** introduced a plugin architecture enabling contract testing beyond HTTP — gRPC, Protobuf, Avro, and custom protocols are now supported. All modern language implementations (JVM, JavaScript, Go, .NET, Python, Ruby) wrap a shared **Rust core via FFI** for consistency. PactFlow adds **bi-directional contract testing (BDCT)**, where providers publish an OpenAPI spec with test evidence and PactFlow validates consumer pacts against it statically — no provider build needed.

Contract testing and integration testing serve different purposes. Contract tests verify **interface compatibility** between teams at unit-test speed with no infrastructure dependencies. Integration tests verify **business workflows**, authentication, data correctness, and performance. Use both: contracts for schema/interface safety, integration tests for critical end-to-end paths.

---

## OpenAPI breaking change detection blocks PRs before damage

Three tools dominate REST API breaking change detection, each with a distinct philosophy. **oasdiff** (Go CLI) checks **300+ categories** of breaking changes across the full OpenAPI spec, supports OpenAPI 3.0 and 3.1, and provides a free GitHub Action that annotates PRs with findings. **Optic** (TypeScript/Node) adds "forwards-only governance" — linting rules apply only to new or changed endpoints, avoiding the paradox of forcing retroactive changes that would themselves be breaking. **Spectral** (by Stoplight) handles static linting of individual specs for style and structure, but cannot detect breaking changes since it examines only a single file.

What constitutes a breaking change in REST is well-defined: removing endpoints or response fields, changing field types, adding required request parameters, removing enum values from responses, narrowing allowed parameter ranges, or changing authentication requirements. Tools like oasdiff classify changes by severity — **ERR** for definite breaks, **WARN** for potential breaks, **INFO** for safe changes.

A robust CI pipeline layers these tools: Spectral lints the spec for style violations, then oasdiff compares the PR's spec against the base branch to detect breaking changes. The recommended GitHub Actions workflow:

```yaml
steps:
  - run: npx @stoplight/spectral-cli lint openapi.yaml --fail-severity error
  - uses: oasdiff/oasdiff-action/breaking@v0.0.37
    with:
      base: 'origin/${{ github.base_ref }}:openapi.yaml'
      revision: 'HEAD:openapi.yaml'
```

For intentional breaking changes, oasdiff supports ignore files listing specific errors to suppress. It also recognizes `x-extensible-enum` (Zalando's convention) — allowing new response enum values without flagging breaks, since clients are expected to handle unknown values with fallback logic. APIs can be tagged with stability levels (`draft`, `alpha`, `beta`, `stable`), and breaking changes are only blocked for `beta` and `stable` endpoints.

---

## GraphQL schema checks leverage production traffic data

GraphQL's type system enables precise breaking change detection. **graphql-inspector** (open-source, by The Guild) compares two schemas and categorizes every change as breaking, dangerous, or safe. **Apollo GraphOS schema checks** go further: they validate proposed changes against **historical client operation data**, answering not just "is this a breaking change?" but "will this break any client that actually uses this field?"

Apollo's approach runs several checks in sequence: composition validation (is the schema valid?), operations checks (do any active client queries reference removed/changed fields?), linter checks (naming conventions and best practices), and custom checks (enterprise). The operations check examines up to **10,000 distinct operations** over a configurable time window, with thresholds for minimum operation counts. This traffic-aware validation means removing a field that no client has queried in 30 days can pass checks even though it's technically breaking.

For **Apollo Federation**, `rover subgraph check` validates that a subgraph schema change composes successfully with all other registered subgraphs before creating a supergraph. Composition failures — missing `@key` directives, type conflicts between subgraphs, incompatible field types — are caught at build time. The `@override` directive enables zero-downtime field migration between subgraphs, and **progressive @override** (Federation 2.7+) supports canary-style traffic splitting during migrations.

The **field deprecation workflow** in GraphQL is well-supported: apply `@deprecated(reason: "...")`, monitor usage via Apollo Studio Insights or GraphQL Hive, wait until usage drops to zero, run schema checks to confirm safety, then remove. graphql-inspector's `suppressRemovalOfDeprecatedField` rule downgrades deprecated field removal from "breaking" to "dangerous," enabling a controlled deprecation pipeline. For CI override, applying a PR label like `approved-breaking-change` bypasses the breaking change gate.

**GraphQL Code Generator** (graphql-codegen) by The Guild generates TypeScript types, React hooks, and typed document nodes from schemas and operations. When a schema field is removed, codegen produces a TypeScript compilation error in any component using that field — **schema breaks become compile errors**. The newer **gql.tada** achieves this without a codegen step, using TypeScript template literal types for zero-build-step inference, though it requires TypeScript 5.0+.

---

## Protobuf wire compatibility demands field number discipline

Protobuf's binary encoding uses **field numbers, not names**, as stable identifiers on the wire. This design decision is both its greatest strength and its most dangerous foot-gun. Reusing a field number after deletion causes silent data corruption — the wire format provides no mechanism to detect that a field was encoded with one definition and decoded with another. The `reserved` keyword exists specifically to prevent this:

```protobuf
message Order {
  string id = 1;
  reserved 4;         // Was 'notes' - never reuse
  reserved "notes";   // Prevent name reuse too
  string shipping_method = 5;
}
```

**Buf** (buf.build) is the industry-standard Protobuf toolchain, superseding protoc, protolock, and Uber's prototool. Its `buf breaking` command checks **53 breaking change rules** across four categories of increasing strictness: `WIRE` (binary wire only), `WIRE_JSON` (binary + JSON encoding), `PACKAGE` (generated source code), and `FILE` (strictest — protects everything). The typical CI setup:

```yaml
- uses: bufbuild/buf-breaking-action@v1
  with:
    against: 'https://github.com/acme/weather.git#branch=main'
```

Safe Protobuf changes include adding new fields, enum values, services, or methods — old readers simply ignore unknown fields. Conditionally safe changes include type widening (`int32` → `int64`, though values may truncate in the reverse direction) and field renames (safe for binary but **breaks JSON encoding** unless `json_name` is set). Breaking changes include changing field numbers, incompatible type swaps (`int32` → `sint32` uses different encoding), removing fields without reserving, and changing RPC signatures.

Google's API Design Guide mandates the **major version in the package name** (`myservice.v1`), with no minor/patch versions exposed. The **Buf Schema Registry (BSR)** serves as a centralized registry for proto definitions — teams consume generated SDKs via `go get buf.build/gen/...` or `npm install`, eliminating manual proto distribution. **Connect** (connect-go, connect-es) modernizes gRPC with HTTP/1.1 support, curl-debuggable JSON, and ~80% smaller TypeScript bundles than grpc-web.

For code generation, the ecosystem offers strong options per language: **Protobuf-ES** + Connect-ES for TypeScript (modern, ESM-first, tree-shakeable), **tonic** for Rust (via build.rs or buf generate), and standard **protoc-gen-go** + connect-go for Go. Buf's `managed mode` keeps language-specific options out of .proto files entirely, setting `go_package`, `java_package`, and similar options via configuration.

---

## Kafka schema registry compatibility modes govern event evolution

The Confluent Schema Registry enforces compatibility rules per subject (typically `<topic>-key` and `<topic>-value`). The **BACKWARD** mode (default) guarantees that new consumers can read data written by old producers — critical for topics with long retention where consumers may rewind to the beginning. **FORWARD** mode guarantees old consumers can read new data. **FULL** mode provides both guarantees simultaneously but is restrictively narrow.

The practical implications of each mode determine deployment ordering:

Under **BACKWARD** compatibility, you may add fields with defaults and remove optional fields. You must upgrade consumers first, then producers. Under **FORWARD**, you may add fields freely (old readers ignore them) and delete fields that have defaults. Producers upgrade first. Under **FULL**, only adding or removing optional fields with defaults is permitted, but deployment order doesn't matter. The **TRANSITIVE** variants (BACKWARD_TRANSITIVE, FULL_TRANSITIVE) check against all previous versions rather than just the latest — essential for **long-retention topics** where consumers might encounter very old schemas.

What breaks BACKWARD compatibility specifically: removing a field that has no default value, adding a required field without a default, incompatible type changes (e.g., `int` → `string`), and renaming fields (treated as delete + add in Avro). Avro handles evolution through **reader/writer schema resolution** — each message carries its writer schema ID, and the consumer's reader schema resolves differences by matching field names, applying defaults for missing fields, and ignoring unknown fields. Protobuf uses numeric field tags for the same purpose but requires `BACKWARD_TRANSITIVE` in the registry because adding new message types is not forward-compatible.

**Schema migration strategies** for incompatible changes include topic versioning (create `orders-v2` alongside `orders-v1`), dual-write patterns (producers write to both topics during migration), and migration services (Kafka Streams or Flink jobs that transform v1 messages to v2). The critical production practice: **disable auto-registration** (`auto.register.schemas=false`) and gate schema registration through CI pipelines using the Schema Registry Maven plugin or REST API compatibility checks.

---

## Database schema is an implicit contract through CDC

Even when microservices "own" their databases, the schema becomes a public contract the moment CDC pipelines expose internal table structures to downstream consumers. Column additions, removals, type changes, and renames all propagate through Debezium to Kafka topics and onward to analytics systems, search indexes, and data warehouses. **A column rename in your PostgreSQL table is a breaking change for every Debezium consumer downstream.**

The **outbox pattern** solves this by decoupling the internal data model from the external event schema. Instead of capturing raw table changes, the application writes explicitly crafted events to an outbox table with a public schema. Debezium's Outbox Event Router SMT captures only these events, routing them to topics based on aggregate type. The outbox payload becomes the contract — versioned, compatibility-checked, and independent of internal tables. Treat outbox event schemas identically to Kafka schemas: register them in Schema Registry, enforce BACKWARD compatibility, and never remove or rename fields without a migration plan.

For raw CDC without the outbox pattern, the **expand-and-contract pattern** is essential for zero-downtime breaking changes. Phase 1 (expand): add new columns alongside old ones with triggers for dual-write. Phase 2 (migrate): backfill data and update application code. Phase 3 (contract): drop old columns after all consumers have migrated. During the expand phase, Debezium emits both old and new columns, giving consumers time to switch. Tools like **Atlas** and **pgroll** automate this pattern, with pgroll providing versioned schema views and database-level dual writes via triggers.

**Debezium schema handling varies by database**: MySQL reads DDL from the binlog and publishes explicit schema change events, while PostgreSQL's logical decoding does NOT capture DDL — schema changes only appear in subsequent data events. Key safeguards include a stream processing layer (Flink/Kafka Streams) that transforms raw CDC events into clean data contracts, and SMTs that rename or reshape fields to shield consumers from internal changes.

---

## API versioning lifecycle from release to sunset

The versioning strategy depends on your API's audience and change velocity. **URL path versioning** (`/v1/users`) is most popular for public APIs due to visibility and simplicity — used by Twilio and SendGrid. **Date-based header versioning** (`X-GitHub-Api-Version: 2022-11-28`) provides finer-grained control — GitHub supports previous versions for **at least 24 months**. **Stripe's hybrid approach** pins users to a version at first use and has maintained backward compatibility with over 100 versions since 2011 using an internal transformation system.

The deprecation lifecycle follows a predictable sequence: announce deprecation, add `Deprecation` and `Sunset` HTTP headers (per RFC 9745 and RFC 8594), publish migration guides, monitor usage, optionally run brownout periods (temporary errors to test client readiness), then remove the endpoint returning `410 Gone`. The headers provide machine-readable signals:

```http
Deprecation: @1719705599
Sunset: Sat, 30 Jun 2026 23:59:59 GMT
Link: </api/v2/users>; rel="successor-version"
```

**Usage monitoring** drives deprecation decisions. Track requests per version, unique consumers per deprecated endpoint, and last-request timestamps per consumer. Build alerts when usage drops below a threshold (e.g., <1% of total traffic) to trigger the sunset process. API gateways (Kong, AWS API Gateway) or observability platforms (Datadog, Grafana) provide these metrics.

---

## SDK generation creates compile-time safety nets

Generated SDKs transform runtime API failures into **compile-time type errors**. For TypeScript, **openapi-typescript** generates pure type definitions from OpenAPI specs with zero runtime overhead. Its companion library `openapi-fetch` wraps `fetch` with full type inference — URL typos, missing parameters, and wrong body shapes become compiler errors. For multi-language SDK generation, **openapi-generator** supports 50+ languages with template customization.

The CI workflow for keeping SDKs in sync: detect spec changes on merge to main, run breaking change checks, regenerate SDK code, and open an automated PR (or publish directly to package registries). For protobuf, `buf generate` replaces manual `protoc` invocation with declarative `buf.gen.yaml` configuration, parallel compilation, managed mode for language options, and remote plugin support via the BSR.

GraphQL codegen follows the same pattern — `graphql-codegen` with the client preset generates `TypedDocumentNode` types and fragment-based component types. When a schema field is removed, any component using that field fails TypeScript compilation. The watch mode (`graphql-codegen --watch`) regenerates types on schema changes during development. **Commit generated files** to version control so PR diffs clearly show how schema changes affect frontend types.

---

## Backward compatibility testing as a CI pipeline architecture

A complete compatibility enforcement pipeline combines multiple gates in sequence. For PR pipelines: lint the API spec (Spectral/buf lint), check for breaking changes (oasdiff/buf breaking/graphql-inspector), run consumer contract tests (Pact), and execute `can-i-deploy` against staging and production environments. For main branch pipelines: publish contracts to the broker, verify against all deployed consumer versions, deploy to staging, record the deployment, then repeat for production.

**Cross-version compatibility matrix testing** operates at multiple levels. The Pact Matrix automatically tracks which consumer/provider version pairs have been verified. For Protobuf, explicit backward compatibility tests marshal data with v1 schemas and unmarshal with v2 schemas (and vice versa). Schema Registry's compatibility check API validates new schemas before registration. The `can-i-deploy` tool with `--all prod` checks compatibility against every version currently deployed in production.

The most sophisticated approach is the **compatibility-driven version orchestrator** pattern: API definitions stored in separate Git repos as subprojects, CI monitors definition changes, executes backward compatibility checks, runs contract tests, and triggers dependent service builds. This creates a dependency graph where no service can deploy a breaking change without explicit approval from all affected consumers.

---

## Enforcement patterns that work in production

The most effective organizations combine automated gates with lightweight governance. **Stripe's model** — a brief change document submitted to a mailing list for company-wide visibility, combined with automated version transformation modules — balances speed with safety. The critical enforcement layers, from innermost to outermost:

- **Design-time**: Spectral lints OpenAPI specs, buf lint checks proto files, IDE plugins provide real-time feedback
- **PR-time**: oasdiff/buf breaking/graphql-inspector blocks merging of breaking changes; Pact contract tests verify consumer expectations
- **Pre-deploy**: `can-i-deploy` gates every deployment against the compatibility matrix; Schema Registry rejects incompatible Kafka schemas
- **Runtime**: Sunset/Deprecation headers signal upcoming removals; usage monitoring tracks deprecated endpoint consumption; Apollo schema checks validate against production traffic

The key organizational principle is **federated governance with automated tooling**: a central platform team provides the linters, CI actions, and registries, while individual teams own their contracts and API evolution. The platform makes the right thing easy and the wrong thing hard — breaking changes require explicit override labels, ignore-file entries, or approval workflows rather than being silently permitted.

For a polyglot stack specifically, the unified enforcement checklist includes: Spectral + oasdiff for REST, graphql-inspector or Apollo checks for GraphQL, buf breaking for Protobuf, Schema Registry compatibility for Kafka, Pact contracts across all HTTP-based protocols, and `can-i-deploy` as the universal deployment gate. Each tool addresses its protocol's specific semantics while the Pact Broker provides a cross-protocol view of system-wide compatibility.

## Conclusion

The fundamental insight across all protocols is that **backward compatibility is a deployment-ordering problem**. BACKWARD compatibility in Kafka means upgrading consumers first. Adding fields to Protobuf is safe because old readers ignore unknown tags. Removing a REST response field breaks clients who depend on it. Every tool and pattern described here exists to answer a single question before deployment: "will this change break anything that's currently running?"

The most impactful pattern is making breaking change detection a **PR-blocking CI gate** rather than a post-deployment discovery. oasdiff catches REST breaks in 300+ categories. Buf catches proto breaks across wire, JSON, and source-code dimensions. Apollo schema checks catch GraphQL breaks against real traffic. Schema Registry catches event schema breaks before producers can publish. When combined with Pact's `can-i-deploy` as the final deployment gate, these tools create a defense-in-depth system where breaking changes must be explicitly approved rather than accidentally shipped. The remaining gap — database schema changes affecting CDC consumers — is best addressed through the outbox pattern, which transforms an implicit contract into an explicit, versionable, compatibility-checkable event schema.