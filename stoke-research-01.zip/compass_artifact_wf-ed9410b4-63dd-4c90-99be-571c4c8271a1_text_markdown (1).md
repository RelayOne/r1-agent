# Claude Code concurrent reliability: a production field guide

**Running 5–10 concurrent Claude Code CLI processes is feasible but demands specific isolation measures to prevent silent failures.** The primary risk is not the Anthropic API itself but Claude Code's local filesystem architecture, which assumes single-instance usage and creates race conditions on shared config files. With proper configuration — particularly `--setting-sources local`, per-agent `CLAUDE_CONFIG_DIR`, API key auth, and disabled auto-updates — tested concurrency jumps from **72% success to 100% at 10 simultaneous agents**. Without these measures, `result: null` failures, config corruption, and session stalls will silently degrade your QA-audit pipeline.

The core architecture issue is simple: every Claude Code instance reads and writes to `~/.claude/`, and multiple concurrent processes doing this without file locking causes JSON corruption, snapshot deletion, and authentication failures. Anthropic has fixed some of these race conditions (v2.1.47, v2.1.59, v2.1.61) but the fundamental single-writer assumption persists in several code paths.

---

## Known failure modes and their mitigations

The table below catalogs every documented failure mode relevant to concurrent Claude Code operation, drawn from GitHub issues, changelogs, and community reports.

| # | Failure mode | Root cause | Silent? | Detection method | Mitigation |
|---|---|---|---|---|---|
| 1 | **`result: null` with `error_during_execution`** | Config file contention when loading user/project settings concurrently | **Yes** — `is_error: false` despite null result | Check JSON output for `result: null` or `subtype: "error_during_execution"` | `--setting-sources local` eliminates it entirely (Issue #24990) |
| 2 | **`.claude.json` corruption** | Concurrent writes without atomic operations or file locking; 38ms race window | Partially — produces `.corrupted.*` backup files | Monitor for `.claude.json.corrupted.*` files accumulating | Fixed in **v2.1.61**; also use per-agent `CLAUDE_CONFIG_DIR` |
| 3 | **Shell snapshot deletion** | Instance B's cleanup deletes Instance A's snapshot from shared `~/.claude/shell-snapshots/` | **Yes** — causes "No such file" errors mid-execution | Monitor stderr for ENOENT on snapshot files | Per-agent `CLAUDE_CONFIG_DIR` or `HOME` |
| 4 | **OAuth token refresh 404** | Single-use refresh tokens shared via `.credentials.json`; concurrent refresh consumes token twice | **Yes** — unrecoverable, session dies silently | Monitor for `not_found_error` in logs | Use `ANTHROPIC_API_KEY` instead of OAuth (fully bypasses) |
| 5 | **Rate limit cascade termination** | Shared AbortController in Claude Code's Task tool kills all subagents when one gets 429'd | **Yes** — all parallel work aborted | External process monitoring; check exit codes | Ensure adequate API tier; use external process orchestration, not Claude's internal Task tool |
| 6 | **Session permanently stuck on rate limit** | Retry/backoff logic lacks maximum ceiling or health check | **Yes** — session hangs indefinitely | Timeout monitoring per agent | External watchdog with kill-and-restart logic (Issue #26699) |
| 7 | **Plan file cross-contamination** | Multiple sessions in same directory share `.claude/plans/` | **Yes** — wrong plan applied silently | Diff plan files before/after execution | Use `--worktree` or separate working directories per agent |
| 8 | **Auto-update version downgrade** | 8+ concurrent instances race on version symlink in `~/.local/bin/claude` | Partially — version mismatch errors may appear | Check `claude --version` per agent | `DISABLE_AUTOUPDATER=1` (Issue #14100) |
| 9 | **History lock file contention** | `history.jsonl.lock` stale locks block other instances | No — produces EBADF errors | Monitor for lock-related errors | Per-agent `CLAUDE_CONFIG_DIR`; clean stale locks before batch runs |
| 10 | **Memory exhaustion silent crash** | Unbounded command output in parallel Bash tool calls | **Yes** — process terminates with no error | External process liveness monitoring | Set `--max-turns`; limit command output in agent prompts |
| 11 | **MCP OAuth race condition** | MCP servers using OAuth (Slack, Notion) have separate token refresh race | Partially — MCP connection fails | Monitor MCP connection status | Fixed in **v2.1.59** for MCP specifically; prefer API-key-based MCP servers |

---

## Safe concurrency limits depend on isolation level

Empirical data from GitHub benchmarks, Anthropic's own engineering projects, and community reports establishes clear concurrency thresholds tied to isolation configuration.

**For read-only auditor agents** (your 5 concurrent auditors), the risk profile is lower because they don't write to the codebase, but they still contend on Claude Code's internal config files. With `--setting-sources local` and per-agent `CLAUDE_CONFIG_DIR`, **5 concurrent auditors is well within safe limits** — the tested threshold is 10 concurrent with 100% success at this isolation level.

**For fix agents that write to the codebase** (your 2–5 concurrent fixers), git-level conflicts add a second failure dimension. Each fix agent must operate in an isolated git worktree or separate directory. Use `--worktree agent-$ID` (available since v2.1.49) to give each agent its own branch and working tree. **5 concurrent fix agents is achievable** with worktree isolation, but requires careful merge orchestration afterward.

| Isolation level | Max safe auditors | Max safe fixers | Evidence |
|---|---|---|---|
| Default CLI (no isolation) | **2** | **1** | Issue #24990: 72% success at 10-way; #13352: 2 sessions block each other |
| `--setting-sources local` only | **10** | **3–5** (with separate dirs) | Issue #24990: 50/50 success at 10-way |
| Full isolation (per-agent config + worktree) | **10–16** | **5–10** | Anthropic's C compiler project: 16 Docker agents over 2 weeks |
| Container/VM isolation per agent | **20+** | **20+** | Multiple HN orchestrator reports; Anthropic internal usage |

**Recommended for your system**: Full isolation (Tier 3 config below) supports your 5 auditors + 5 fixers comfortably. This matches the proven 10-way concurrent threshold.

---

## The minimal configuration checklist for safe concurrent operation

Every concurrent Claude Code invocation in your system should use this configuration. The environment variables and flags address specific, documented failure modes.

**Per-agent launch template:**

```bash
CLAUDE_CONFIG_DIR="/tmp/claude-agent-${AGENT_ID}" \
ANTHROPIC_API_KEY="sk-ant-..." \
DISABLE_AUTOUPDATER=1 \
DISABLE_TELEMETRY=1 \
DISABLE_ERROR_REPORTING=1 \
claude -p \
  --setting-sources local \
  --output-format json \
  --max-turns 50 \
  --dangerously-skip-permissions \
  "your prompt here"
```

For **fix agents**, add worktree isolation:

```bash
claude -p \
  --setting-sources local \
  --worktree "fix-agent-${AGENT_ID}" \
  --output-format json \
  --max-turns 50 \
  --dangerously-skip-permissions \
  "your prompt here"
```

**Pre-flight checklist** (run before each batch):

- **Create per-agent config directories**: `mkdir -p /tmp/claude-agent-{1..10}` before launching agents, to avoid mkdir race conditions
- **Clean stale locks**: `rm -f ~/.claude/*.lock ~/.claude/shell-snapshots/*` if using shared config
- **Pin Claude Code version**: Install a specific version and set `DISABLE_AUTOUPDATER=1` to prevent mid-run version changes
- **Verify API tier**: Confirm your organization is on **Tier 3 (2,000 RPM)** minimum for 10 concurrent agents; Tier 2's 1,000 RPM may suffice for 5 agents with moderate prompt sizes
- **Validate JSON output**: Every agent result must be parsed; reject any response where `result` is `null` or `subtype` is `"error_during_execution"`
- **Set external timeouts**: Claude Code's internal retry logic can hang indefinitely — implement a hard timeout per agent (e.g., 10 minutes for auditors, 20 minutes for fixers)

**Why each setting matters:**

| Setting | Failure mode it prevents |
|---|---|
| `CLAUDE_CONFIG_DIR` per agent | `.claude.json` corruption, shell snapshot deletion, history lock contention |
| `ANTHROPIC_API_KEY` | OAuth token refresh 404 race condition |
| `DISABLE_AUTOUPDATER=1` | Version downgrade race with concurrent instances |
| `DISABLE_TELEMETRY=1` | Statsig cache write contention |
| `--setting-sources local` | `result: null` from settings file contention (the single most impactful fix) |
| `--worktree` | Plan file cross-contamination, git conflicts between fix agents |
| `--max-turns` | Runaway agents consuming unbounded tokens |
| `--output-format json` | Enables programmatic result validation |

---

## API rate limits share a single organizational pool

All Claude Code processes using the same `ANTHROPIC_API_KEY` draw from one shared rate limit pool. Limits are **per-organization, per-model class**, enforced across three dimensions: requests per minute (RPM), input tokens per minute (ITPM), and output tokens per minute (OTPM). A token-bucket algorithm provides continuous replenishment, meaning a 60 RPM limit is actually enforced as roughly 1 request/second — bursts trigger 429s even if you're under the per-minute cap.

When rate-limited, the API returns **HTTP 429** with a `retry-after` header (seconds to wait) and detailed `anthropic-ratelimit-*` headers showing remaining capacity. Claude Code's CLI adds its own retry layer on top of the SDK's default 2 retries: **up to 10 attempts with exponential backoff**. However, two critical bugs affect this retry logic: a session can get **permanently stuck** on rate limits with no auto-recovery (Issue #26699), and in Claude Code's internal Task tool, a single 429 can **cascade-terminate all parallel subagents** via a shared AbortController (Issue #6594).

For 10 concurrent agents, **Tier 3 (2,000 RPM, 800K ITPM)** is the minimum viable tier. Tier 1's 50 RPM would be exhausted almost instantly. Cached input tokens do not count toward ITPM limits, so implementing prompt caching for shared system prompts across auditor agents could effectively multiply your throughput by 3–5×.

Anthropic offers a **Priority Tier** (committed spend via sales) that provides prioritized request routing and **99.5% uptime target**, but this is an organization-level commitment — there is no per-request priority header that would let your VP Eng auditor take precedence over a lower-priority fix agent. The only way to achieve differential priority is to use **separate organizations** with separate API keys and tier levels, or implement client-side queuing logic that gates agent launches based on priority.

---

## API key auth fully solves the OAuth race — with three caveats

Setting `ANTHROPIC_API_KEY` **completely bypasses the OAuth refresh token lifecycle** for main API authentication. API keys are long-lived, don't require refresh cycles, and don't read or write `~/.claude/.credentials.json`. This eliminates the concurrent token refresh 404 bug (Issue #24317, still open as of March 2026) at its root.

Three edge cases remain:

- **MCP server OAuth is separate.** If your agents use MCP servers that authenticate via OAuth (Slack, Notion, Atlassian integrations), those tokens have their own refresh race condition independent of `ANTHROPIC_API_KEY`. The MCP-specific race was fixed in v2.1.59, but prefer MCP servers using API key auth where possible.
- **Headless Linux interactive mode quirk.** On headless Linux VMs, interactive mode (`claude` without `-p`) may require a prior OAuth login even when `ANTHROPIC_API_KEY` is set (Issue #27900). Since your system uses `claude -p` (print/headless mode), this doesn't apply — `-p` mode works with just the API key.
- **Settings sync and telemetry.** Some non-API features (the "Help improve Claude" setting sync) may still touch OAuth code paths. Disabled by `DISABLE_TELEMETRY=1` and `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1`.

For your use case — headless `claude -p` with `ANTHROPIC_API_KEY` and telemetry disabled — **the OAuth race condition is fully mitigated**.

---

## Open bugs and unresolved risks at scale

Several issues remain open on GitHub that could cause silent failures in a production concurrent system, even with all recommended mitigations applied:

**High severity (could cause missed findings or broken fixes):**

- **Issue #26699 — Session permanently stuck on rate limit.** A single agent can enter a non-recovering retry loop after a transient rate limit. No fix shipped. **Mitigation**: External watchdog process that kills agents exceeding a time threshold.
- **Issue #6116 — `error_during_execution` with no debug info.** ~10% of scripted runs return this subtype with no indication of what failed, even when all work completed. **Mitigation**: Treat any non-success result as a failure requiring retry.
- **Issue #24317 — Core OAuth race condition.** Still open, but fully avoided with API key auth.
- **Issue #27311 — Plan file overwrite across sessions.** No fix. **Mitigation**: `--worktree` or separate directories.

**Medium severity (operational degradation):**

- **Issue #18280 — Memory allocation thrashing.** Multiple sessions cause sustained high CPU via mmap/munmap churn. No fix. **Mitigation**: Monitor system resources; consider container memory limits.
- **Issue #14100 — Auto-update version downgrade.** Fixed by `DISABLE_AUTOUPDATER=1`.
- The fundamental **single-writer assumption** in Claude Code's config file handling (Issue #28922, reported 8 times since June 2025, all closed without root-cause fix) means new concurrency-related config corruption bugs may appear in future versions.

**The bottom line for your QA-audit system**: With the full isolation configuration above, your 5 auditors + 5 fixers operate within proven safe limits. The residual risks — stuck sessions and unexplained `error_during_execution` — require external monitoring and retry logic. No Claude Code configuration alone can guarantee zero silent failures, so **every agent result must be validated programmatically**, and any `result: null` or `error_during_execution` must trigger an automatic retry or alert.

## Conclusion

Claude Code's concurrent reliability has improved substantially through 2025–2026 (v2.1.47 fixed streaming interleave, v2.1.59 fixed MCP OAuth races, v2.1.61 fixed config corruption), but it remains a tool architecturally designed for single-instance usage with concurrency bolted on through isolation flags rather than built-in coordination. The three non-negotiable measures are **`--setting-sources local`** (eliminates the most common silent failure), **per-agent `CLAUDE_CONFIG_DIR`** (eliminates all shared filesystem contention), and **`ANTHROPIC_API_KEY` auth** (eliminates the OAuth race entirely). With these in place plus external timeout monitoring, 10 concurrent agents achieves 100% success in available benchmarks. The remaining risk is Claude Code's retry logic hanging on transient API errors — solve this with external process supervision, not Claude Code configuration.