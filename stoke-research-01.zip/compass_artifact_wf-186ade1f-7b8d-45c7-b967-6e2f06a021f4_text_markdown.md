# Trail of Bits' Claude Code skills: a complete anatomy

Trail of Bits has built the most sophisticated open-source Claude Code skills ecosystem in production, encoding the security expertise of an elite audit firm into **38 plugins containing 201+ skills, 84 agents, and 125 scripts**. Their repository at `github.com/trailofbits/skills` — created January 14, 2026 and now at ~4,200 stars — represents a deliberate strategy to make security expertise compound as reusable code. On optimal engagements, their AI-augmented auditors now find **200 bugs per week**, up from roughly 15, with ~20% of all bugs reported to clients initially discovered by AI. This analysis covers every plugin they ship, their authoring standards, meta-skills for iterating on quality, their testing-handbook generator pipeline, and their philosophical approach to LLM-augmented security.

---

## All 38 plugins and what each one does

The repository organizes plugins under a `plugins/` directory. Each plugin follows a consistent structure: `.claude-plugin/plugin.json` for metadata, plus optional `skills/`, `commands/`, `agents/`, `hooks/`, and `scripts/` directories. The repo also supports OpenAI Codex discovery via a `.codex/skills/` sidecar tree.

### Smart contract security (2 plugins)

| Plugin | Description |
|--------|-------------|
| **building-secure-contracts** | Comprehensive smart contract security toolkit based on Trail of Bits' framework; includes vulnerability scanners for 6 blockchains (Solidity, Algorand, Cairo, Cosmos, Solana, Substrate) and 5 development guideline assistants across 11 skill directories |
| **entry-point-analyzer** | Identifies state-changing entry points in smart contracts for security auditing; detects externally callable functions that modify state, categorizes by access level, generates structured audit reports |

### Code auditing (9 plugins)

| Plugin | Description |
|--------|-------------|
| **agentic-actions-auditor** | Audits GitHub Actions workflow YAML files for security vulnerabilities in AI agent integrations (Claude Code Action, Gemini CLI, OpenAI Codex, GitHub AI Inference); checks 9 categories including expression injection, CLI data fetch, PR target + checkout |
| **audit-context-building** | Builds deep architectural context through ultra-granular line-by-line code analysis before vulnerability hunting; applies First Principles, 5 Whys, and 5 Hows at micro scale |
| **differential-review** | Security-focused differential review of code changes with git history analysis, blast radius estimation, and Five Whys deep context analysis across 7 phases |
| **fp-check** | Systematic false positive verification for security bugs with mandatory gate reviews; multi-phase process covering data flow analysis, exploitability verification, impact assessment, and PoC creation |
| **insecure-defaults** | Detects insecure default configurations including hardcoded credentials, fallback secrets, weak authentication defaults, fail-open security patterns, and dangerous production values |
| **sharp-edges** | Identifies error-prone APIs, dangerous configurations, and footgun designs that enable security mistakes |
| **static-analysis** | Static analysis toolkit orchestrating CodeQL, Semgrep, and SARIF parsing; walks Claude through building CodeQL databases, creating data extension models, selecting rulesets, and processing results |
| **supply-chain-risk-auditor** | Audits supply-chain threat landscape of project dependencies for exploitation or takeover risk |
| **variant-analysis** | Finds similar vulnerabilities across codebases using a 5-step process: characterize root cause → create detection patterns → sweep codebase with CodeQL/ripgrep → validate candidates → document findings |

### Static analysis tools (3 plugins)

| Plugin | Description |
|--------|-------------|
| **semgrep-rule-creator** | Creates and refines custom Semgrep rules for detecting bug patterns and security vulnerabilities |
| **semgrep-rule-variant-creator** | Ports existing Semgrep rules to new target languages with applicability analysis and test-driven validation |
| **yara-authoring** | YARA-X detection rule authoring with linting, atom analysis, and best practices; targets YARA-X (Rust-based successor to legacy YARA); includes `yara_lint.py` and `atom_analyzer.py` scripts |

### Verification and testing (5 plugins)

| Plugin | Description |
|--------|-------------|
| **constant-time-analysis** | Detects compiler-induced timing side-channels in cryptographic code; trophy: found real timing side-channel in ECDSA verification (RustCrypto/signatures) |
| **mutation-testing** | Configures mewt/muton mutation testing campaigns — scopes targets, tunes timeouts, optimizes long-running runs |
| **property-based-testing** | Property-based testing guidance for multiple languages and smart contracts; detects patterns like serialization pairs, parsers, normalization |
| **spec-to-code-compliance** | Specification-to-code compliance checker for blockchain audits with evidence-based alignment analysis |
| **zeroize-audit** | Detects missing or compiler-eliminated zeroization of secrets in C/C++ and Rust with assembly and control-flow analysis |

### Specialized tools (4 plugins)

| Plugin | Description |
|--------|-------------|
| **burpsuite-project-parser** | Searches and extracts data from Burp Suite project files (.burp) for security analysis |
| **dwarf-expert** | Teaches how to interact with and understand the DWARF debugging format using dwarfdump, readelf, and pyelftools rather than dumping the spec |
| **firebase-apk-scanner** | Scans Android APKs for Firebase security misconfigurations including open databases, storage buckets, authentication issues, and exposed cloud functions |
| **dimensional-analysis** | Annotates codebases with dimensional analysis comments documenting units, dimensions, and decimal scaling; achieves **93% recall** vs 50% for baseline prompts in real audit findings |

### Code graph and analysis (1 plugin)

| Plugin | Description |
|--------|-------------|
| **trailmark** | Builds multi-language source code graphs for attack surface mapping, blast radius, taint propagation, complexity hotspots; generates Mermaid diagrams; runs mutation testing triage, generates test vectors, extracts crypto protocol flows, converts Mermaid to ProVerif models, projects SARIF/weAudit findings onto graphs |

### Testing handbook (1 plugin)

| Plugin | Description |
|--------|-------------|
| **testing-handbook-skills** | Meta-skill that generates Claude Code skills from the Trail of Bits Application Security Testing Handbook (appsec.guide); covers fuzzers, static analysis, sanitizers, coverage; includes generation templates for tool-skills, fuzzer-skills, technique-skills, and domain-skills |

### Development (8 plugins)

| Plugin | Description |
|--------|-------------|
| **ask-questions-if-underspecified** | Clarifies ambiguous requirements by asking questions before implementing; only activates when invoked explicitly |
| **devcontainer-setup** | Creates pre-configured devcontainers with Claude Code and language-specific tooling |
| **gh-cli** | Intercepts GitHub URL fetches and curl/wget commands, redirecting to authenticated `gh` CLI; includes PreToolUse hooks and session-scoped temp directories |
| **git-cleanup** | Safely analyzes and cleans up local git branches and worktrees by categorizing as merged, squash-merged, superseded, or active |
| **modern-python** | Modern Python best practices with uv, ruff, ty, and pytest for new projects, scripts, or migration from legacy tools |
| **second-opinion** | Runs code reviews using external LLM CLIs (OpenAI Codex, Google Gemini) on uncommitted changes, branch diffs, or specific commits; bundles Codex's built-in MCP server |
| **skill-improver** | Automatically reviews and fixes Claude Code skills through iterative refinement until they meet quality standards |
| **workflow-skill-design** | Teaches design patterns for workflow-based Claude Code skills and provides a review agent for auditing existing skills |

### Infrastructure and tools (3 plugins)

| Plugin | Description |
|--------|-------------|
| **claude-in-chrome-troubleshooting** | Diagnoses and fixes Claude in Chrome MCP extension connectivity issues |
| **debug-buttercup** | Debugs Buttercup Kubernetes deployments |
| **seatbelt-sandboxer** | Generates minimal macOS Seatbelt sandbox configurations for applications |

### Other (2 plugins)

| Plugin | Description |
|--------|-------------|
| **culture-index** | Interprets Culture Index survey results for individuals and teams |
| **let-fate-decide** | Draws Tarot cards using cryptographic randomness to add entropy to vague or underspecified planning |

---

## CLAUDE.md: the house standards that define skill quality

The CLAUDE.md file opens with an explicit statement: **"These are Trail of Bits house standards on top of Anthropic's requirements."** The document encodes a philosophy that skills are passive knowledge — "A skill never *does* anything on its own — it changes how Claude thinks." This distinction drives every convention they enforce.

**Core authoring principles.** Skills must provide behavioral guidance over reference dumps. The canonical example is their DWARF skill: rather than pasting the entire DWARF specification, it teaches Claude how to use `dwarfdump`, `readelf`, and `pyelftools` to look up what it needs, plus judgment about when each tool is appropriate. Skills must explain *why*, not just *what* — including trade-offs, decision criteria, and judgment calls. They must document anti-patterns *with explanations* for why something is wrong, not merely that it's wrong. And critically, skills should provide guidance Claude doesn't already have rather than duplicating reference material.

**Frontmatter requirements.** Every SKILL.md begins with YAML frontmatter requiring a `name` (kebab-case, max 64 characters, gerund form preferred like `analyzing-contracts` rather than `contract-analyzer`) and a `description` in third-person voice. The description is called out as **the single most important line** because skills compete with 100+ others for activation. Good descriptions include trigger phrases ("Use when auditing Solidity" not just "Smart contract tool") and are specific ("Detects reentrancy vulnerabilities" not "Helps with security"). An optional `allowed-tools` field restricts which tools (Read, Write, Edit, Bash, Grep, Glob, Task) the skill can access.

**Required sections.** Every SKILL.md must include a "When to Use" section listing specific concrete scenarios with keywords/patterns that should activate the skill, plus a "When NOT to Use" section listing scenarios where another approach is better, preventing false positive invocations. Security skills additionally require a "Rationalizations to Reject" section — a distinctive pattern that explicitly lists rationalizations Claude should reject, such as "This code is internal-only" (rebuttal: internal attackers exist) or "The compiler will optimize it" (rebuttal: never rely on compiler optimizations for security).

**Size and structure constraints.** SKILL.md files should stay **under 500 lines** (some guidance says under 2,000 words). Content exceeding that threshold gets split into supporting `references/` files. A critical structural rule: reference chains are limited to **one level deep** — SKILL.md can link to files, but those files shouldn't chain to more files. Directory nesting is fine (`references/guides/topic.md`), but the restriction applies to reference chains themselves.

**Plugin directory conventions.** Component directories (`skills/`, `commands/`, `agents/`, `hooks/`) must sit at the plugin root, not inside `.claude-plugin/`. Only `plugin.json` belongs in `.claude-plugin/`. For dual Codex/Claude support, any plugin with `skills/<name>/SKILL.md` must also remain reachable through `.codex/skills/<name>`.

---

## How skill-reviewer and skill-improver iterate on quality

Trail of Bits implements a **review → fix → re-review** methodology using two complementary tools that form an automated quality improvement loop.

**The skill-reviewer** is a specialized subagent within the `plugin-dev` plugin (from Claude's official marketplace). It validates generated or existing skills against both Anthropic's best practices and Trail of Bits house standards. The reviewer checks description formatting (third-person voice), activation triggers, specificity, valid YAML frontmatter, required sections (When to Use, When NOT to Use), line count under 500, and cross-references to ensure they point to existing skills only. It enforces that skills provide behavioral guidance rather than reference dumps and that they don't duplicate knowledge Claude already possesses. The reviewer is invoked via the `plugin-dev` plugin's `/skill-development` command.

**The skill-improver** (`plugins/skill-improver`) wraps the skill-reviewer in an iterative refinement loop. When invoked via `/skill-improver ./plugins/my-plugin/skills/my-skill`, it resolves the skill path, creates a session state file, delegates to the skill-reviewer to identify quality issues, **automatically fixes** those issues, then re-invokes the reviewer to validate fixes. This loop repeats until the quality bar is met (signaled by a `<skill-improvement-complete>` tag) or the maximum iteration limit is reached (default: 20, configurable via `--max-iterations`). A stop hook drives the loop automatically without manual intervention. Multiple sessions can run simultaneously on different skills using unique session IDs, and changes are preserved even if manually stopped. The skill-improver requires `plugin-dev` to be installed, as it depends on the skill-reviewer agent.

**Five tests before submission.** Beyond automated review, skills must pass five validation tests: trigger testing (does the description cause activation at the right times?), workflow testing (do step-by-step instructions work?), script testing (do all scripts run successfully with `uv run`?), reference testing (do all referenced files exist and load correctly?), and path testing (does `{baseDir}` resolve correctly across systems?).

**Three-tier learning ladder.** The repository provides example skills at three complexity levels for contributors to study: `ask-questions-if-underspecified` (basic — simple skill, minimal structure), `constant-time-analysis` (intermediate — full sections including Rationalizations to Reject), and `culture-index` (advanced — commands, agents, skills, hooks, multiple workflows, and scripts). The guidance: "When in doubt, copy one of these and adapt it."

---

## Progressive disclosure, triggers, and gotchas in practice

Trail of Bits has developed a distinctive documentation architecture that balances information density with cognitive load management.

**Progressive disclosure follows a strict pattern.** The SKILL.md file serves as a Quick Start entry point containing core instructions. Advanced usage and detailed patterns move to `references/ADVANCED.md`. Complete API documentation goes to `references/API.md`. The critical constraint is the **one-level-deep rule**: SKILL.md links to reference files, but those files never chain to further files. This prevents Claude from falling down reference rabbit holes while ensuring detailed content remains accessible.

**Trigger descriptions are competition-aware.** Because skills compete with 100+ others for activation, descriptions must function as precise activation signals. The constant-time-analysis skill demonstrates best practice: "Detects timing side-channel vulnerabilities in cryptographic code. Use when implementing or reviewing crypto code, encountering division on secrets, secret-dependent branches, or constant-time programming questions." Each trigger phrase maps to specific user behaviors or code patterns rather than abstract categories.

**The "Rationalizations to Reject" pattern is Trail of Bits' most distinctive contribution** to skill documentation. For security skills, this section pre-empts the common failure mode where an LLM rationalizes away genuine findings. By listing specific rationalizations alongside their rebuttals ("This code is internal-only" → "Internal attackers exist"), skills maintain analytical rigor during audits. This pattern emerges from their observation that LLMs naturally tend toward agreeable, dismissive analysis when confronted with ambiguous security signals.

**Prescriptiveness scales with risk.** Trail of Bits explicitly calibrates how rigid their workflow instructions are based on task fragility. Security audits, cryptographic implementations, and compliance checks receive strict step-by-step enforcement. Code exploration, documentation, and refactoring get flexible guidance with room for judgment calls. This is documented as a conscious trade-off: strict mode has a higher false positive rate but catches more edge cases.

---

## The testing-handbook-skills generator pipeline

The `testing-handbook-skills` plugin is a meta-skill that converts Trail of Bits' Application Security Testing Handbook (published at appsec.guide) into Claude Code skills. It implements a **5-phase generation pipeline** that solves several non-obvious problems in automated skill creation.

**Phase 0 (Setup)** locates the handbook by checking `./testing-handbook`, `../testing-handbook`, `~/testing-handbook`, then asking the user, and finally cloning from GitHub as a last resort. **Phase 1 (Discovery)** reads a `discovery.md` methodology file, scans the handbook at `{handbook_path}/content/docs/`, classifies sections into four types (Tool, Fuzzer, Technique, Domain), and builds a candidate list. **Phase 2 (Planning)** generates a plan showing which skills will be created or updated and presents it for user approval.

**Phase 3 (Two-Pass Generation)** is architecturally interesting because it solves the **forward reference problem**. Pass 1 generates all skills in parallel but skips "Related Skills" sections. Pass 2 reads all generated skill names, determines relationships based on handbook structure, updates each SKILL.md with correct cross-references, and validates that all references resolve. This two-pass approach prevents circular dependencies and broken links that would occur if skills were generated with cross-references in a single pass.

**Phase 4 (Testing)** runs `validate-skills.py`, which checks valid YAML frontmatter, required sections, line count under 500, cross-references to existing skills only, and no broken internal links. The script supports `--skill` for single-skill validation and `--json` for CI output. **Phase 5 (Finalize)** updates the README, refreshes the cross-reference graph, and captures self-improvement notes that feed back into template enhancements and discovery logic updates.

**Four skill templates** handle different content types. Tool skills (for Semgrep, CodeQL) cover Installation, Configuration, Patterns, and CI Integration. Fuzzer skills (for libFuzzer, AFL++, cargo-fuzz) cover Setup, Harness, Corpus, Options, and Sanitizers. Technique skills (for harness writing, coverage analysis) cover Methodology, Patterns, Best Practices, and Examples. Domain skills (for Wycheproof, constant-time testing) cover Domain Context, Tools, Test Suites, and Validation. The generator has pre-produced **16 skills**: 6 for fuzzers (libFuzzer, AFL++, libAFL, cargo-fuzz, Atheris, Ruzzy), 6 for techniques (Harness Writing, Address Sanitizer, Coverage Analysis, Fuzzing Dictionary, Fuzzing Obstacles, OSS-Fuzz), 2 for static analysis (Semgrep, CodeQL), and 2 for domain-specific testing (Wycheproof, Constant-Time Testing).

---

## Audit-context-building: line-by-line analysis before bug hunting

The `audit-context-building` plugin encodes Trail of Bits' methodology for the pre-vulnerability-hunting phase of security audits. Its core principle: **never hunt for bugs until you deeply understand what the code is supposed to do**. The skill is explicitly a pure context-building tool that does not generate findings or hunt for vulnerabilities.

**The analysis methodology follows six structured phases.** Initial Orientation maps modules, entrypoints, actors, and storage. Ultra-Granular Function Analysis performs line-by-line semantic analysis with cross-function flow tracking. State Flow Analysis maps reads and writes of each state variable and derives multi-function and multi-module invariants. End-to-End Flow Tracking identifies flows (deposit, withdraw, lifecycle, upgrades), tracks state transforms across flows, and records assumptions. Actor Model maps actors to entrypoints to behaviors, identifies untrusted input paths, and tracks privilege changes. Risk Assessment flags functions with many assumptions, high branching logic, multi-step dependencies, and coupled state changes.

**The analytical framework combines three reasoning tools at micro scale.** First Principles analysis breaks each function down to its fundamental assumptions. Five Whys recursively questions why each design decision was made. Five Hows explores how each mechanism achieves its stated goal. These are applied block-by-block — not at the architectural level, but at the code level — producing what Trail of Bits calls an "ultra-granular" analysis.

**Anti-hallucination safeguards are built into the quality checklist.** Every claim must include line number citations. Vague statements are explicitly forbidden. All assertions must be evidence-based. The analysis is considered complete only when all checklist items are satisfied and no unresolved "unclear" items remain. The checklist enforces minimum thresholds for invariants discovered, assumptions documented, risk factors identified, and First Principles applied.

**Activation triggers are carefully scoped.** The skill auto-invokes on phrases like "analyze code," "understand codebase," and "audit" — but explicitly does *not* activate for "find bugs," "security analysis," or "audit code," because those are vulnerability-hunting phrases that should trigger different skills. This distinction prevents the context-building skill from being misused as a bug-finding tool.

---

## The skills-curated repository and supply chain safety

Trail of Bits maintains a separate `trailofbits/skills-curated` repository for vetted third-party Claude Code plugins. Its creation was motivated by a real problem: **"published skills have been found with backdoors and malicious hooks, and the ecosystem has no built-in quality gate."**

The curation criteria center on code review rigor. Every PR gets reviewed, and maintainers read every line of hooks and scripts — the two highest-risk components since hooks execute automatically and scripts run arbitrary code. The repository maintains a canonical list of approved marketplaces, including `trailofbits/skills-internal` (private), Anthropic's official plugins, `obra/superpowers`, `EveryInc/compound-engineering-plugin`, `ghostsecurity/skills`, and `openai/skills`. A `scripts/convert_openai_skills.py` auto-converts skills from OpenAI's format, ensuring portability with no MCP or OpenAI API dependencies.

Trail of Bits operates **three tiers** of skill repositories: the public `trailofbits/skills` for their own open-source plugins, the private `trailofbits/skills-internal` for proprietary workflows used on client engagements, and `trailofbits/skills-curated` for approved third-party contributions.

---

## Philosophy from blog posts and conference talks

The definitive statement of Trail of Bits' skill development philosophy comes from CEO Dan Guido's talk at the [un]prompted AI security conference on March 4, 2026, later adapted as a blog post titled "How we made Trail of Bits AI-native (so far)."

**The central thesis: "Our security expertise compounds as code."** Every engagement the firm completes generates reusable skills and workflows that make the next engagement faster. This creates an exponential advantage: the 94 plugins, 201 skills, and 84 agents represent encoded expertise from hundreds of professional security audits. A senior auditor writing a `constant-time-analysis` skill isn't being replaced — they're "becoming more permanent" because their expertise is now encoded and reusable.

**The dimensional-analysis blog post (March 25, 2026) articulates their most nuanced technical insight.** Author Benjamin Samuels explicitly critiques the "wave of security analysis skills" that take a simple approach — priming an LLM with vulnerability classes and telling it to find bugs. Trail of Bits calls these "low-quality" with poor precision, recall, and determinism. Their alternative: **use the LLM as a vocabulary-building and categorization machine** that directly annotates codebases, then detect mismatches mechanically. The dimensional-analysis plugin demonstrates this: it annotates code with units, dimensions, and decimal scaling information, then checks for mismatches deterministically. This achieves **93% recall** versus 50% for naive LLM prompting.

**Four psychological barriers to AI adoption** shaped their organizational approach: self-enhancing bias ("I'm already good enough"), identity threat ("AI will replace me"), intolerance for imperfection ("it makes mistakes"), and opacity/trust ("I can't verify its work"). They overcame these through mandatory hackathons (engineers must work in bypass permissions mode), an AI Maturity Matrix treating AI proficiency as a professional capability on par with using Git, and an identity reframe positioning engineers as the ones who "make the AI dangerous."

**The MCP security blog series (April–July 2025) provides context** for their security-first approach to skill ecosystems. Posts documented attacks including prompt injection via MCP servers before activation ("jumping the line"), ANSI terminal code deception, and insecure credential storage — ultimately leading them to build `mcp-context-protector` and adopt rigorous curation practices for their skills marketplace.

## Conclusion

Trail of Bits' skills repository represents a rare case of an organization treating LLM skill development with the same engineering rigor they apply to security auditing itself. Three insights stand out. First, their **"Rationalizations to Reject" pattern** is a genuinely novel contribution to prompt engineering for security — pre-empting the LLM's natural tendency to rationalize away findings. Second, the **testing-handbook generator's two-pass architecture** solves the forward reference problem in automated skill creation, a challenge most skill authors handle manually. Third, their philosophical stance that LLMs should be used for **categorization and annotation rather than direct vulnerability identification** — exemplified by dimensional-analysis achieving 93% recall versus 50% for naive approaches — represents a more durable architecture than the "just ask the LLM to find bugs" approach that dominates the current landscape. The broader lesson: encoding expertise as behavioral guidance rather than reference dumps produces measurably better outcomes than treating LLMs as search engines for vulnerability databases.