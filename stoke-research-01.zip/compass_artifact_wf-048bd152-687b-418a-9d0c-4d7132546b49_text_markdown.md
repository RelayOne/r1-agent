# Database connection pooling, management, and failure patterns

**Connection pooling is the single most impactful optimization for database-backed services at scale.** A raw PostgreSQL connection costs ~440ms to establish cross-region (TCP + TLS 1.3 + auth = 5.5 round trips), consumes ~10MB of memory on the server, and spawns a dedicated OS process. Without pooling, a service handling 1,000 requests/second would spend more time connecting than querying. This report covers the complete landscape of connection management across PostgreSQL (via PgBouncer), MongoDB, and Redis/Valkey, with specific configuration examples for Go (pgx, go-redis, mongo-go-driver) and TypeScript/Node.js (node-postgres, ioredis, mongoose) drivers.

---

## PgBouncer: transaction mode is the sweet spot, but it breaks things

PgBouncer operates in three pooling modes, each with a different multiplexing strategy. **Transaction mode** assigns a server connection only for the duration of a transaction, then returns it to the pool — enabling 100 database connections to serve 5,000+ clients. Session mode holds a connection for the entire client session (1:1 proxy, minimal benefit). Statement mode releases after every single statement and disallows multi-statement transactions entirely.

Transaction mode is the production default for stateless web/API workloads, but it breaks any feature that depends on session state:

**Prepared statements** are scoped to a PostgreSQL backend process. In transaction mode, each transaction may land on a different connection, causing `prepared statement "X" does not exist` errors. Since PgBouncer 1.21+, setting `max_prepared_statements = 200` enables protocol-level prepared statement interception — PgBouncer renames and transparently re-prepares statements on each server connection. This only works for protocol-level prepared statements (what pgx and libpq use), not SQL-level `PREPARE ... AS`. For pgx specifically, set `default_query_exec_mode=simple_protocol` as an alternative. In node-postgres, pass `{ prepare: false }`.

**SET commands** modify session state that vanishes when the connection returns to the pool. The fix: use `SET LOCAL` inside a transaction, which scopes the change to that transaction only. PgBouncer tracks and restores a small set of startup parameters (`client_encoding`, `datestyle`, `timezone`, `standard_conforming_strings`, `application_name`) but notably **not** `search_path` by default.

**Advisory locks** via `pg_advisory_lock()` persist at session level, meaning they remain held on the server connection after your transaction ends and another client inherits that connection. Use `pg_advisory_xact_lock()` instead — it releases at transaction end. **LISTEN/NOTIFY** requires a persistent connection; run a separate session-mode pool on a different port for this. **Temporary tables** with `ON COMMIT PRESERVE ROWS` break; only `ON COMMIT DROP` works. **WITH HOLD cursors**, **large objects**, and `currval()` across transactions all fail.

### Essential PgBouncer configuration

A production `pgbouncer.ini` should configure these key settings:

```ini
[databases]
myapp = host=10.0.1.10 port=5432 dbname=myapp pool_size=30
myapp_ro = host=10.0.1.11 port=5432 dbname=myapp pool_size=20
myapp_session = host=10.0.1.10 port=5432 dbname=myapp pool_mode=session pool_size=5

[pgbouncer]
pool_mode = transaction
default_pool_size = 25
min_pool_size = 5
reserve_pool_size = 5
reserve_pool_timeout = 3
max_client_conn = 5000
max_db_connections = 100
server_idle_timeout = 300
server_lifetime = 3600
query_wait_timeout = 60
idle_transaction_timeout = 30
max_prepared_statements = 200
auth_type = scram-sha-256
auth_user = pgbouncer_auth
auth_query = SELECT * FROM pgbouncer.user_lookup($1)
```

The `max_client_conn` controls connections to PgBouncer (lightweight, ~2KB each), while `default_pool_size` controls connections to PostgreSQL (expensive, ~10MB each). The multiplexing ratio is `max_client_conn / pool_size`. For auth passthrough, create a `SECURITY DEFINER` function that queries `pg_shadow` and grant execute to a dedicated `pgbouncer_auth` user — this avoids maintaining `userlist.txt` for every database user. **SCRAM-SHA-256 is fully supported since PgBouncer 1.14+** (current stable: 1.25.1).

### Monitoring PgBouncer: the metrics that matter

Connect to the admin console (`psql -p 6432 pgbouncer`) and run `SHOW POOLS`. The critical fields: **`cl_waiting`** (clients queuing for a server connection — this should be 0), **`sv_active`** (server connections paired with clients), **`sv_idle`** (connections available), and **`maxwait`** (longest current wait time).

| Alert condition | Severity | Meaning |
|---|---|---|
| `cl_waiting > 0` sustained >30s | Warning | Pool saturated |
| `cl_waiting > 10` sustained >2m | Critical | Severe exhaustion |
| `maxwait > 5s` | Warning | Clients waiting too long |
| `avg_wait_time > 100ms` | Warning | Pool likely undersized |
| `sv_active == pool_size` with `cl_waiting > 0` | Critical | Fully consumed |

High `cl_waiting` with high `sv_active` means queries are too slow. High `cl_waiting` with low `sv_active` means PgBouncer cannot create connections fast enough — check PostgreSQL `max_connections` or network issues.

---

## PgCat versus PgBouncer: more features, less battle-testing

PgCat is a Rust-based (Tokio async runtime) PostgreSQL pooler created by Lev Kokotov at PostgresML. Its architecture is **multi-threaded** (default 4 worker threads), fundamentally different from PgBouncer's single-threaded model. PgCat adds features PgBouncer lacks entirely: **built-in read/write query splitting**, load balancing across replicas (random or least-outstanding-connections), automatic replica failover with health checks, sharding support (via SQL comments, SET commands, or automatic query parsing), query mirroring, and native Prometheus metrics at `/metrics`.

PgCat's prepared statement handling in transaction mode was a key differentiator — it caches and remaps prepared statements with globally unique names, claiming **30% performance improvement** in production. PgBouncer 1.21+ has since added its own protocol-level prepared statement support, narrowing the gap.

**Performance comparison** tells a nuanced story. At low connection counts (<50), PgBouncer wins on latency and throughput. At high connection counts (>100), PgCat's multi-threading gives it an edge — Tembo benchmarks showed PgCat peaking at **59K TPS versus PgBouncer's 44K TPS**, with PgCat achieving **2× throughput at 750+ clients**. Instacart's production comparison (1.5M queries over 12 hours) showed negligible difference: p50 latency within 10μs, p99 within 1ms. Memory usage: PgBouncer ~12MB for 1,000 connections versus PgCat ~28MB.

**The case against PgCat today**: it has not reached a formal 1.0 release (latest: 0.2.5 as of November 2024). Documentation is sparse (rated 2/5 versus PgBouncer's 5/5 at pgconf.eu 2024). Client-side SCRAM-SHA-256 authentication is not supported (MD5 only for clients). Most critically, PgCat's original creator has left to build **PgDog** (Y Combinator W25), raising long-term maintenance questions. Stick with PgBouncer unless you specifically need built-in read/write splitting, load balancing, or sharding at the proxy layer.

Other alternatives worth monitoring: **Odyssey** (Yandex, C99, multi-threaded, strong prepared statement support, stability concerns), **Supavisor** (Supabase, Elixir, designed for millions of connections in serverless, but 80–160% higher latency), and **PgDog** (Rust, very early stage, from PgCat's creator).

---

## The pool sizing formula: smaller pools perform better

The canonical formula from the PostgreSQL wiki, popularized by HikariCP: **`connections = (cpu_cores × 2) + effective_spindle_count`**. For SSDs, effective spindle count is 1, simplifying to `cpu_cores × 2 + 1`. An 8-core database server with SSD needs only **17 active connections** for optimal throughput.

This is grounded in queueing theory (Little's Law). The `× 2` multiplier accounts for I/O wait — while one thread waits on disk, another uses the CPU. More connections than this causes context switching overhead that degrades throughput. Oracle's Real-World Performance group demonstrated a **50× improvement** by reducing a pool from 2,048 to 96 connections.

For multi-instance deployments, the math is straightforward: if you have N application instances each with pool size P, **total = N × P** must not exceed `max_connections - superuser_reserved_connections` (default 3). With PgBouncer in front, each application connects to PgBouncer with a larger pool, while PgBouncer maintains the smaller optimal pool to PostgreSQL.

**Real-world calculation**: 8-core DB, 4 app instances, SSD:
- Formula result: (8 × 2) + 1 = 17 connections to PostgreSQL
- Per-instance pool: 17 / 4 ≈ 4 connections each
- With PgBouncer: set `default_pool_size = 20`, `max_client_conn = 5000`, each app instance gets a pool of 50 to PgBouncer

PostgreSQL's default `max_connections` is 100. **Increasing it beyond 200–300 hurts performance** because each connection is a forked OS process consuming ~10MB RAM, and `GetSnapshotData()` must scan all processes at transaction start. Citus Data research showed a single active connection slowed by **>2× with 5,000 concurrent idle connections**. The recommended approach: keep `max_connections` low and pool aggressively.

### The pool locking anti-pattern

When connections in a pool wait on other connections from the same pool, deadlock occurs. HikariCP's deadlock avoidance formula: `pool_size = Tn × (Cm - 1) + 1`, where Tn is max threads and Cm is max simultaneous connections per thread. Three threads each needing 4 connections → pool size = 3 × (4-1) + 1 = **10**. In pgx, this manifests when `defer rows.Close()` keeps a connection checked out while another query in the same function needs a new connection from a full pool.

---

## Pool exhaustion: what happens and how to detect it

When the pool is full, behavior varies by driver. In **Go with pgx**, `pool.Acquire(ctx)` blocks until a connection is available or the context deadline expires, returning `context.DeadlineExceeded`. In **Go with database/sql**, queries block similarly, but if `SetMaxOpenConns(0)` (the default, unlimited), new connections are created without limit until PostgreSQL returns `pq: sorry, too many clients already`. In **Node.js with node-postgres**, `pool.connect()` queues requests in FIFO; if `connectionTimeoutMillis` is set, it throws `timeout exceeded when trying to connect` — if unset, **it hangs indefinitely**. In **Prisma**, exhaustion throws error P2024: `Timed out fetching a new connection from the connection pool`.

Export these metrics to Prometheus for every service:

```yaml
# pgx pool
pgx_pool_acquired_conns        # Gauge — currently checked out
pgx_pool_max_conns              # Gauge — pool capacity
pgx_pool_empty_acquire_total    # Counter — acquires that had to wait
pgx_pool_canceled_acquire_total # Counter — acquires that timed out

# database/sql
go_sql_in_use_connections       # Gauge
go_sql_wait_count_total         # Counter
go_sql_wait_duration_seconds    # Counter

# node-postgres
pg_pool_waiting_count           # Gauge — requests queued
```

**Alert when `waiting > 0` for a sustained period** — a pool waiting queue that stays above zero is a fire that hasn't started burning yet. Alert when utilization (`acquired / max`) exceeds **80% for 5 minutes**. Alert on acquire latency P99 exceeding 500ms.

---

## MongoDB connection pools scale per topology member

MongoClient maintains a **separate connection pool per server** in the topology. The default `maxPoolSize` is **100 connections per server**. For a 3-member replica set, total potential connections per client = 100 × 3 = **300** (plus 6 monitoring sockets, 2 per member). With 20 application instances, that's potentially 6,000+ connections to the cluster.

Connection creation is rate-limited by `maxConnecting` (default: **2 concurrent** connection attempts per pool), which mitigates thundering herd during failovers. The pool starts in a "paused" state and is marked "ready" after monitors successfully check each server.

### Failover storms and SDAM behavior

During a primary election (median time: **~12 seconds** with default settings), the driver marks the old primary as "unknown," clears its connection pool, and accelerates heartbeat checks. All pending operations fail with retryable errors. The `serverSelectionTimeoutMS` (default: 30 seconds) determines how long the driver waits to find a suitable server before returning an error to the application.

Retryable writes (enabled by default since MongoDB 4.2 drivers) provide at-most-once semantics using server-side transaction IDs. Retryable reads (default since 6.0 drivers) retry once on network errors. During failover, the driver updates its topology, re-selects a server, and retries — all transparently.

**Critical best practice**: use a **single MongoClient per application process**. Each additional client multiplies connections. Configure pool sizing for multi-instance deployments:

```
maxPoolSize = (server_connection_limit / (num_instances × num_topology_members)) × 0.8
```

Atlas tier limits: **M10: 350**, M20: 700, M30: 2,000, M40: 4,000 connections.

### Driver configuration examples

**Go (mongo-go-driver v2)**:
```go
clientOpts := options.Client().
    ApplyURI("mongodb+srv://cluster0.example.mongodb.net/mydb").
    SetMaxPoolSize(50).
    SetMinPoolSize(10).
    SetMaxConnIdleTime(30 * time.Second).
    SetServerSelectionTimeout(30 * time.Second).
    SetRetryWrites(true).
    SetReadPreference(readpref.SecondaryPreferred())
client, err := mongo.Connect(clientOpts)
```

**Node.js/TypeScript**:
```typescript
const client = new MongoClient(uri, {
  maxPoolSize: 50,
  minPoolSize: 10,
  maxIdleTimeMS: 30000,
  waitQueueTimeoutMS: 5000,
  serverSelectionTimeoutMS: 30000,
  retryWrites: true,
  w: 'majority',
});
```

Monitor `db.serverStatus().connections` — alert when `current / (current + available)` exceeds **80%** or `rejected > 0`.

---

## Redis needs fewer connections than you think

Redis processes commands on a **single thread** via an event loop. More connections do not increase throughput — they queue. The default `maxclients` is **10,000**, each consuming ~10KB for the client structure. go-redis defaults to `10 × runtime.GOMAXPROCS` connections (80 on an 8-core machine), which is almost always sufficient.

**Pipelining is the real throughput multiplier.** A single connection sending 1,000 commands individually at 1ms RTT takes ~1 second. Pipelined: ~10–20ms. redis-benchmark with `-P 16` typically shows **5–10× throughput improvement**. Cross-datacenter (50ms RTT), pipelining delivers **50–100× improvement**. Always prefer pipelining over adding connections.

```go
// Go pipelining with go-redis
pipe := rdb.Pipeline()
incr := pipe.Incr(ctx, "counter")
pipe.Expire(ctx, "counter", time.Hour)
_, err := pipe.Exec(ctx)
```

```typescript
// Node.js pipelining with ioredis
const pipeline = redis.pipeline();
for (let i = 0; i < 1000; i++) {
  pipeline.set(`key:${i}`, `value:${i}`);
}
await pipeline.exec();
```

Optimal batch size: **100–1,000 commands** per pipeline. In Cluster mode, all keys in a pipeline must hash to the same slot.

### Sentinel and Cluster connection handling

For **Sentinel**, clients discover the current primary via `SENTINEL get-master-addr-by-name`. During failover, Sentinel-aware clients (go-redis `NewFailoverClient`, ioredis with `sentinels` option) subscribe to `+switch-master` and automatically reconnect. Commands sent during failover are **queued and replayed** in ioredis when `enableOfflineQueue: true` (default).

For **Redis Cluster**, smart clients maintain a connection pool **per node** (go-redis `PoolSize` applies per-node). Slot routing uses `CRC16(key) MOD 16384`. **MOVED** redirections trigger a topology refresh; **ASK** redirections are temporary (during migration). Both go-redis and ioredis handle redirections transparently.

### Redis versus Valkey

Valkey forked Redis 7.2.4 in March 2024 after Redis's license change to SSPL/RSALv2. Governed by the Linux Foundation, Valkey is **wire-compatible at the Redis 7.2 level** — all existing clients work by changing only the hostname. Performance has diverged: Valkey 8.1's aggressive I/O threading delivers **999.8K RPS versus Redis 8.0's 729.4K** on the same hardware (Momento benchmark), with **60%+ better p99 latency on GET operations**. Valkey 8.0 redesigned its hash table to save ~20 bytes per key. For connection management, behavior is identical — same Sentinel, same Cluster, same RESP protocol. Migration from Redis ≤7.2 is a drop-in replacement; Redis 7.4+ data files are NOT compatible with Valkey.

---

## Connection leak detection across drivers

A connection leak occurs when a connection is checked out from a pool but never returned. The pool gradually fills; new requests timeout; the application hangs. The fix always follows the same principle: **ensure cleanup runs on every code path, including error paths.**

### Go leak patterns and fixes

**pgx — the `defer rows.Close()` rule**:
```go
// ❌ LEAK: missing close
rows, err := pool.Query(ctx, "SELECT * FROM users")
if err != nil { return err }
for rows.Next() { /* ... */ }
// Connection never released

// ✅ CORRECT
rows, err := pool.Query(ctx, "SELECT * FROM users")
if err != nil { return err }
defer rows.Close()
for rows.Next() { /* ... */ }
```

For `pgxpool.Acquire()`, use `defer conn.Release()` — never `defer conn.Conn().Close(ctx)` (which destroys rather than returns). Best: use `pgx.CollectRows()` which handles closing automatically.

**database/sql pitfalls**: `db.Query()` for non-SELECT statements (INSERT/UPDATE/DELETE) returns rows that hold a connection — use `db.Exec()` instead. For transactions, always `defer tx.Rollback()` immediately after `Begin()` — it's a no-op after `Commit()`.

### Node.js leak patterns and fixes

```typescript
// ❌ LEAK: no release on error path
const client = await pool.connect();
const result = await client.query('SELECT ...'); // if this throws...
client.release(); // ...this never runs

// ✅ CORRECT: try/finally
const client = await pool.connect();
try {
  return await client.query('SELECT ...');
} finally {
  client.release();
}

// ✅ BEST: pool.query() auto-releases
const result = await pool.query('SELECT ...');
```

The node-postgres docs explicitly warn: *"If you don't release the client your application will leak them and eventually your pool will be empty forever."* Only use `pool.connect()` when you need transactions.

### Detecting leaks in production

Monitor `pool.Stat().AcquiredConns()` (pgx) or `db.Stats().InUse` (database/sql) or `pool.waitingCount` (node-postgres) over time. If the in-use count monotonically increases without corresponding traffic growth, you have a leak. Implement checkout duration tracking — capture a stack trace at acquire time and log a warning if a connection hasn't been released within 30 seconds:

```typescript
// Node.js leak detector
const originalConnect = pool.connect.bind(pool);
pool.connect = async () => {
  const stack = new Error('Acquired here').stack;
  const client = await originalConnect();
  const timer = setTimeout(() => {
    console.warn(`Potential leak!\n${stack}`);
  }, 30000);
  const origRelease = client.release.bind(client);
  client.release = (destroy) => { clearTimeout(timer); origRelease(destroy); };
  return client;
};
```

### Go context cancellation behavior

When a context is cancelled mid-query in pgx, the connection may be **destroyed rather than returned to the pool** because the connection state is uncertain. This is safe but means cancelled queries cause connection churn. In database/sql with `BeginTx`, context cancellation triggers `Tx.Rollback()` followed by connection discard. Always `defer cancel()` on context creation to prevent goroutine leaks.

---

## Cloud-specific connection patterns

### Cloud SQL Auth Proxy

The Auth Proxy is a transparent sidecar that handles TLS 1.3 encryption and IAM authentication to Cloud SQL. It is **not a connection pooler** — each app connection through the proxy creates one connection to Cloud SQL (1:1 mapping). Pooling happens at the application level (pgx pool, PgBouncer, etc.). Run one proxy per application process; in Kubernetes, deploy as a sidecar container. Watch for CPU starvation — insufficient pod CPU limits can push query latency from <10ms to 100ms+. Google has introduced separate **Managed Connection Pooling** for Enterprise Plus edition on port 6432.

### Cloudflare Hyperdrive

Hyperdrive eliminates the **7 round-trips** (TCP + TLS + auth) required for each new database connection from Workers by maintaining a pool of persistent connections near the origin database. The Worker connects to Hyperdrive locally (same server, no network hop), and only 1 round-trip crosses regions. Performance: without Hyperdrive ~1,200–1,500ms; with Hyperdrive pooling alone **~500ms** (60% reduction); with query caching **~320ms** (75% faster). Operates in transaction mode — SET statements don't persist between transactions. Supports PostgreSQL and MySQL.

### Fly.io internal DNS

Fly.io's `.internal` DNS enables service discovery within an organization's private IPv6 network. Query `mydb.internal` to get AAAA records for all running instances; `iad.mydb.internal` for region-specific resolution. For multi-region database patterns, use the `fly-replay` response header to redirect write requests to the primary region: `fly-replay: region=<primary_region>`.

---

## Connection resilience: failover, validation, and circuit breakers

### Reconnection strategies

pgxpool automatically replaces dead connections — when a connection fails, the pool destroys it and creates a new one on next acquire. The `HealthCheckPeriod` (default 1 minute) runs background health checks on idle connections. go-redis has `MaxRetries` (default 3) with exponential backoff (8ms–512ms). ioredis provides a configurable `retryStrategy` function with built-in offline command queuing. node-postgres's `pg.Pool` removes broken connections and creates new ones on next acquire, but has **no built-in retry logic** — implement it at the application level.

### Handling failover

For PostgreSQL, multi-host connection strings with `target_session_attrs=read-write` enable automatic primary discovery:
```
postgres://host1:5432,host2:5432/mydb?target_session_attrs=read-write
```
The client tries each host sequentially, running `pg_is_in_recovery()` to find the primary. pg_auto_failover demonstrated **<2 seconds total impact** with decorrelated jitter retry, p99 reconnection at 209ms.

### Connection validation

pgx's `BeforeAcquire` hook can validate connections before use (`return c.Ping(ctx) == nil`), but ping-on-every-acquire adds ~0.5–1ms per query. Better: use `HealthCheckPeriod` for background validation, and `MaxConnLifetime` to periodically recycle connections. For database/sql, `SetConnMaxLifetime(time.Hour)` naturally replaces stale connections without explicit pings.

### Circuit breaker pattern

Without a circuit breaker, a downed database causes all requests to pile up waiting for connection timeouts (30–60s), exhausting thread pools and cascading failures. A circuit breaker **fails fast**:

```go
// Go with gobreaker
cb := gobreaker.NewCircuitBreaker[[]byte](gobreaker.Settings{
    Name:        "db-breaker",
    MaxRequests: 3,                   // max in half-open state
    Timeout:     30 * time.Second,    // open → half-open delay
    ReadyToTrip: func(counts gobreaker.Counts) bool {
        return counts.ConsecutiveFailures > 5
    },
})
result, err := cb.Execute(func() ([]byte, error) {
    return queryDatabase()
})
```

```typescript
// Node.js with opossum
const breaker = new CircuitBreaker(queryDatabase, {
  timeout: 3000,
  errorThresholdPercentage: 50,
  resetTimeout: 30000,
});
breaker.fallback(() => cachedData);
```

Wrap database operations (not individual connections) in the circuit breaker. Prisma notably does **not** automatically retry on connection failure — application-level retry logic or middleware is required.

---

## Connection overhead: why pooling is non-negotiable

### The cost of a new connection

**TCP handshake**: 1.5 RTT (SYN → SYN-ACK → ACK). Same datacenter: 0.1–0.5ms. Cross-region: 10–50ms. Cross-continent: 50–200ms.

**TLS 1.3 handshake**: 1 RTT (versus 2 RTT for TLS 1.2). At 80ms RTT, TLS 1.3 saves 80ms per connection versus TLS 1.2.

**PostgreSQL authentication**: ~3 RTT (StartupMessage, SCRAM challenge/response, ReadyForQuery).

**Total**: ~5.5 RTT before the first query. At 80ms cross-region RTT, that's **440ms per new connection**. Wikimedia found that without connection pooling, **70% of CPU was spent on TLS handshakes** at 4,500 req/s. After adding a connection-reusing sidecar, CPU dropped from 2.5 cores to 0.8 cores — a **46% throughput gain**.

### PostgreSQL's per-connection memory footprint

Each connection is a **separate OS process** (postmaster forks). The commonly cited **~10MB per connection** includes: base process overhead (~1–2MB private memory), catalog caches, temp_buffers (default 8MB, allocated on demand), and shared memory mapped per process. AWS RDS measurements show 100 idle connections consuming ~1,004MB. The `work_mem` setting (default 4MB) is allocated **per sort/hash operation** — a query with 4 sort nodes at 64MB work_mem burns 256MB from a single connection.

This is why `max_connections` beyond 200–300 degrades performance: 1,000 connections × 10MB = 10GB base overhead, plus context switching across that many OS processes, plus `ProcArrayLock` contention at every transaction start/end. Benchmark evidence consistently shows PostgreSQL throughput peaks at **200–300 active connections** on commodity hardware, then declines.

| Server size | Recommended max_connections | Optimal active (formula) |
|---|---|---|
| 4 cores, 8GB RAM | 50–100 | ~9 |
| 16 cores, 64GB RAM | 100–200 | ~33 |
| 64 cores, 256GB RAM | 200–500 | ~129 |

Set `TCP_NODELAY` on all database connections — without it, Nagle's algorithm can delay small query packets by **40ms+**. All major drivers enable this by default, but verify in custom dialer configurations.

---

## Conclusion

The core insight across all three databases is the same: **fewer, well-managed connections outperform many poorly-managed ones**. PostgreSQL's process-per-connection model makes this especially acute — PgBouncer in transaction mode with a pool of 20–30 connections can outperform 500 direct connections. MongoDB's per-topology-member pooling means total connections multiply fast across instances; a single MongoClient singleton and `maxPoolSize` tuned to deployment size are essential. Redis's single-threaded model means pipelining 100–1,000 commands on a few connections beats hundreds of individual-command connections.

Three practices prevent the majority of connection-related incidents: always `defer` cleanup (rows.Close, conn.Release, client.release) on every code path including errors; export pool utilization metrics and alert when waiting > 0 or utilization > 80%; and set `MaxConnLifetime` to recycle connections and prevent stale-connection cascades after failovers. Circuit breakers around database operations prevent connection pool exhaustion from cascading into full service outages. These patterns apply universally across Go and TypeScript, across all three databases, and across cloud deployment models.