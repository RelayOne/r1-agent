# Production GraphQL federation for Go multi-service architectures

**Federated GraphQL at scale demands mastery across schema composition, team coordination, performance engineering, security, and operational observability.** This guide covers all ten critical dimensions for teams building Go subgraphs (gqlgen) serving React and React Native clients through a federated gateway. Every pattern, configuration, and anti-pattern here reflects production-grade knowledge drawn from organizations running federation at scale — Netflix (200+ subgraphs), Expedia, Shopify, PayPal, and others. The architecture assumes Apollo Federation 2 as the baseline specification, with open-source alternatives compared throughout.

---

## 1. Apollo Federation 2 directives and entity resolution in Go

Federation 2 subgraphs opt in via an explicit `@link` directive on the schema, importing only the directives they need:

```graphql
extend schema
  @link(url: "https://specs.apollo.dev/federation/v2.3",
    import: ["@key", "@shareable", "@external", "@requires", "@provides"])
```

**`@key(fields: FieldSet!)`** declares an entity's unique identity for cross-subgraph resolution. Multiple `@key` directives are allowed for alternative keys. Key fields are automatically `@shareable`. Setting `resolvable: false` marks an entity reference without requiring an entity resolver — useful when a subgraph returns entity keys but doesn't resolve them.

**`@shareable`** explicitly permits multiple subgraphs to resolve the same field. Federation 2 defaults to single-source-of-truth per field. Applying `@shareable` at the type level makes all fields shareable. The critical anti-pattern here is marking everything `@shareable` to suppress composition errors — this defeats the safety guarantees Federation 2 was designed to provide.

**`@external`** declares a field defined in another subgraph. While Federation 2 removed the requirement for `@external` on key fields (a major simplification from v1), it remains mandatory for fields used in `@requires` and `@provides` selection sets.

**`@requires(fields: FieldSet!)`** declares that a field needs data from another subgraph before resolution. The router fetches required fields and includes them in the entity representation sent to the resolver. Since v2.1.2, field arguments are supported: `@requires(fields: "weight(units: \"KILOGRAMS\")")`.

**`@provides(fields: FieldSet!)`** declares that a subgraph can resolve another subgraph's field for a specific query path, enabling the router to skip an extra round-trip. **`@override(from: String!)`** enables zero-downtime field migration between subgraphs. Federation v2.7+ adds progressive `@override` with percentage-based traffic shifting for canary-style migration.

Additional directives include **`@inaccessible`** (hides definitions from the client-facing API while keeping them available for inter-subgraph communication), **`@tag`** (metadata for Apollo Contracts — exposing different graph slices), **`@interfaceObject`** (v2.3+, contributing fields to interfaces from subgraphs that don't know all implementations), and **`@authenticated`/`@requiresScopes`/`@policy`** (v2.5+, authorization directives evaluated at the router).

### Entity resolution across subgraphs

The router generates a query plan determining which subgraphs to call and in what order. For cross-subgraph entity resolution, it sends an `_entities` query with representations — JSON objects containing `__typename` plus key fields:

```graphql
query {
  _entities(representations: [
    { __typename: "Product", id: "123" },
    { __typename: "Product", id: "456" }
  ]) {
    ... on Product { name price }
  }
}
```

### gqlgen federation configuration

Configure `gqlgen.yml` for Federation 2 with batch resolution and computed requires:

```yaml
federation:
  filename: graph/federation.go
  package: graph
  version: 2
  options:
    computed_requires: true
    entity_resolver_multi: true
```

gqlgen auto-generates entity resolver stubs in `entity.resolvers.go`. For a `Product` type with `@key(fields: "id")`, you implement `FindProductByID`. With `entity_resolver_multi: true`, gqlgen generates batch resolvers that receive all representations at once:

```go
func (r *entityResolver) FindManyProductsByID(
    ctx context.Context, reps []*generated.ManyProductsByIDInput,
) ([]*model.Product, error) {
    ids := make([]string, len(reps))
    for i, r := range reps { ids[i] = r.ID }
    products, err := r.productRepo.GetByIDs(ctx, ids)
    // Output order MUST match input order
    return products, err
}
```

For `@requires`, the `computed_requires: true` option generates resolvers with a `federationRequires map[string]interface{}` parameter containing the externally-fetched data.

### Common composition errors

| Error | Cause | Fix |
|-------|-------|-----|
| Non-shareable field in multiple subgraphs | Two subgraphs define same field without `@shareable` | Add `@shareable` or consolidate ownership |
| Missing `@external` on `@requires` fields | Fields in `@requires` not declared `@external` | Add `@external` |
| `@provides` without subfields | Providing composite type without listing subfields | Specify all subfields |
| ENUM_MISMATCH | Enum values differ across subgraphs | Align enum definitions |

### Migration from Federation 1

Federation 2 removes the originating/extending subgraph distinction — all subgraph type definitions are peers. The `extend` keyword is no longer required. Key changes: `@external` is not needed on `@key` fields, fields default to single-source-of-truth (use `@shareable` to opt in to multi-resolution), and `@override` enables zero-downtime field migration. **Apollo Router v1.60+ drops Federation 1 support entirely** due to the native query planner, which delivers **10x median improvement** in query planning time.

---

## 2. Open-source alternatives that work with Go subgraphs

### WunderGraph Cosmo is the strongest open-source contender

**WunderGraph Cosmo** (Apache 2.0) is the most feature-complete open-source alternative to Apollo GraphOS. Its router is written in **Go** using the MIT-licensed `graphql-go-tools` engine, making Go subgraphs first-class citizens. Cosmo is a drop-in replacement compatible with Apollo Federation v1 and v2 subgraph specs. It includes a schema registry, composition checks, analytics, tracing, and a Studio UI. Key differentiators include custom Go module extensibility, Event-Driven Federated Subscriptions (EDFS) via Kafka/NATS/SQS, **DataLoader 3.0** for breadth-first entity loading (up to 5x gains on nested entities), and Cosmo Connect for integrating REST/gRPC/SOAP without rewriting in GraphQL. Production adopters include **eBay, SoundCloud, FanDuel, Roche, Shutterstock, and StockX**.

**GraphQL Hive** (MIT) from The Guild offers both a JavaScript gateway and a Rust-based router with full Federation v1/v2 support. Wealthsimple migrated from Apollo Router to Hive Gateway with **less than 30% resource usage**. The Hive Router achieves ~1,830 RPS at p95 ~48ms. Hive's schema registry supports conditional breaking changes using real production usage data.

**Grafbase** (MPL-2.0) is a Rust-powered gateway claiming **~40% faster** response times than Apollo Router, with WebAssembly extensibility for custom auth and data sources. It's newer with less public production adoption.

**GraphQL Mesh** (MIT) excels at composing heterogeneous sources — REST, gRPC, SOAP, databases — into a unified GraphQL schema. It's not federation per se but serves the same unification goal. Go services integrate via HTTP or gRPC handlers.

**Hasura** uses its own Remote Schemas and Remote Joins approach rather than standard Federation directives. It excels at rapid GraphQL API generation over databases with built-in RBAC and real-time subscriptions, but doesn't produce Federation-compatible subgraphs.

| Feature | WunderGraph Cosmo | Hive | Grafbase | Apollo Router |
|---------|-------------------|------|----------|---------------|
| License | Apache 2.0 | MIT | MPL-2.0 | Elastic v2 |
| Gateway language | Go | JS or Rust | Rust | Rust |
| Go extensibility | Native Go modules | No | WASM | Rhai/Rust plugins |
| Self-hosted platform | Full | Full | Gateway only | Router only |
| Non-GraphQL sources | REST/gRPC/SOAP | Via Mesh | WASM extensions | Connectors |

**Decision framework:** Choose Cosmo for maximum Go-native control and Apache 2.0 licensing. Choose Hive for MIT licensing and flexible JS/Rust runtime options. Choose Grafbase for raw performance priority. Choose Apollo Router for the deepest ecosystem integration with GraphOS.

---

## 3. Schema governance that catches breaking changes before production

Schema governance prevents breaking changes from reaching clients. The production workflow combines automated CI checks, schema linting, and human review.

### Breaking change detection

**Apollo Schema Checks** via `rover subgraph check` validates three things: composition success (build check), client impact (operation check against recent traffic), and naming conventions (linter check). Run this on every pull request:

```yaml
# GitHub Actions
- name: Run Schema Check
  run: rover subgraph check my-supergraph@prod --schema ./schema.graphql --name accounts
```

**graphql-inspector** (open-source, The Guild) classifies changes as breaking, non-breaking, or dangerous. Its `suppressRemovalOfDeprecatedField` rule treats deprecated field removal as dangerous rather than breaking — essential for managed deprecation.

### Schema linting with graphql-eslint

The `graphql-eslint` package provides **50+ rules** including `naming-convention` (PascalCase types, camelCase fields, SCREAMING_SNAKE_CASE enums), `input-name` (enforce `Input` suffix), `require-description`, `require-deprecation-reason`, `relay-connection-types`, and `no-scalar-result-type-on-mutation`. Use the `flat/schema-recommended` config as a baseline.

### Naming conventions

Production conventions crystallized across Shopify, GitHub, and Apollo: **PascalCase** for types, **camelCase** for fields and arguments, **SCREAMING_SNAKE_CASE** for enum values. Input types follow `{Action}{Entity}Input` (e.g., `CreateUserInput`). Mutation payloads follow `{Action}{Entity}Payload` with a `userErrors` field. Query fields omit verb prefixes — `user(id: ID!)` not `getUser(id: ID!)`. Pagination uses the Relay connection specification (`UserConnection`, `UserEdge`, `PageInfo`).

### Deprecation workflow

The four-step process: **add** replacement fields (additive, non-breaking), **deprecate** old fields with `@deprecated(reason: "Use X instead. Removal: YYYY-MM-DD")`, **monitor** usage via GraphOS Studio or Hive until it drops to zero, then **remove**. Apollo Schema Checks will flag removal as breaking if any client used the field within the observation window (typically 7–90 days). The `require-deprecation-date` graphql-eslint rule enforces sunset dates.

### CI/CD pipeline

The full pipeline: on PR, run graphql-eslint lint + `rover subgraph check` (composition + operation checks). On merge to main, deploy the application code first, then `rover subgraph publish` to register the new schema. For local development, `rover supergraph compose --config supergraph.yaml` validates composition without cloud access.

---

## 4. Subgraph boundaries align with bounded contexts, not backend services

### One team, one subgraph

The foundational principle is that **each subgraph encapsulates a distinct business domain owned by a specific team**. This aligns with Conway's Law and DDD bounded contexts. WunderGraph emphasizes a critical insight: think of the federated graph **top-down, not bottom-up**. Teams building subgraphs in isolation leads to inconsistencies; a centralized gatekeeper creates bottlenecks. The graph should be treated as a shared product with collaborative design guidelines and isolated implementation.

### Entity ownership in Federation 2

Federation 2 eliminated the originating/extending distinction. Two models exist: **single-subgraph ownership** (one subgraph defines the canonical `@key`, others extend with fields — best for clear domain lines) and **shared ownership** (multiple subgraphs collaboratively contribute fields — better for large enterprises). The `@override(from: "SubgraphName")` directive enables zero-downtime field migration with progressive percentage-based traffic shifting (v2.7+).

Cross-subgraph dependencies become explicit through directives: `@requires` declares that a field needs external data (the router fetches it first), `@provides` optimizes by declaring a subgraph can resolve another's field in specific paths, and `@external` marks foreign fields. Every coupling type becomes manageable when explicit and toxic when implicit.

### Seven anti-patterns to avoid

**Monolith subgraph** — keeping the entire schema in one subgraph defeats federation's purpose. **Nano-services** — creating a subgraph per type causes excessive network hops and operational overhead. **Circular dependencies** — subgraph A depending on B depending on A creates complex query plans. **Shared databases** — multiple subgraphs reading the same tables creates a distributed monolith. **Bottom-up design** — each team designing in isolation produces inconsistent schemas. **Client-specific types** — separate "web" and "mobile" types duplicate domain logic. **Overusing `@shareable`** — making every field resolvable by multiple subgraphs obscures ownership.

### Real-world: Netflix's 200+ subgraphs

Netflix's Studio Edge runs **150+ subgraphs, 3,000+ types, and 2,800 queries/mutations** powering 50–60 internal apps. They built the DGS Framework (Spring Boot) to abstract federation complexity, started with willing early adopters rather than mandating adoption, and tackled their most complex use case (homepage) first to de-risk the project. Authorization rules are delegated to subgraph owners, ensuring single implementation per rule.

---

## 5. Performance engineering from query plan to response cache

### Query planning stays under 1ms with caching

Apollo Router's Rust-based query planner adds **~0.5ms overhead** at 10,000 queries/sec (vs. 3–5ms for the Node.js Gateway). Plans are cached in an in-memory LRU (default 512 entries) with optional Redis distribution. On schema reload, the router **precomputes** plans for the most-used queries before switching traffic:

```yaml
supergraph:
  query_planning:
    warmed_up_queries: 100
    cache:
      in_memory:
        limit: 512
      redis:
        urls: ["redis://${env.REDIS_URL}"]
        ttl: 24h
```

### Entity resolution waterfalls and how to flatten them

Cross-subgraph entity lookups create sequential waterfall dependencies: fetch products → resolve reviews → resolve reviewers. Each hop adds a network round-trip. Mitigation strategies: use `@requires` to fetch dependent data in one hop, use `@shareable` for denormalization to avoid cross-subgraph lookups, and flatten entity hierarchies in schema design.

### Batch entity resolution eliminates N+1 in gqlgen

The router already batches all entity lookups into a single `_entities` call per subgraph. Inside gqlgen, enable `entity_resolver_multi: true` to receive all representations at once — this is simpler than DataLoader because the router already handles batching. For field-level N+1 within a subgraph, use **`vikstrous/dataloadgen`** as request-scoped middleware:

```go
func Middleware(db *sql.DB, next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        ldrs := &Loaders{
            UserLoader: dataloadgen.NewLoader(
                (&userReader{db: db}).getUsers,
                dataloadgen.WithWait(2*time.Millisecond),
            ),
        }
        ctx := context.WithValue(r.Context(), loadersKey, ldrs)
        next.ServeHTTP(w, r.WithContext(ctx))
    })
}
```

### Response caching and persisted queries

Apollo Router caches subgraph responses at the entity and root-field level in Redis. Use `@cacheControl` directives in schemas to set TTLs per type and field. **Automatic Persisted Queries (APQ)** reduce bandwidth by sending SHA256 hashes instead of full query strings — enabled by default. **Persisted Query Lists (PQL)** restrict the router to pre-registered operations, combining security with cache warming. For mobile clients, generate manifests and publish to GraphOS for ID-only mode (most restrictive).

### Demand control with cost annotations

```yaml
demand_control:
  enabled: true
  mode: enforce
  strategy:
    static_estimated:
      max: 1000
      list_size: 10
```

Schema-level `@cost(weight: 3)` and `@listSize(slicingArguments: ["first"])` directives (v2.9+) provide fine-grained cost estimation. Per-subgraph cost limits (v2.12.0+) protect low-capacity backends without failing entire requests.

### gqlgen performance tuning

Key `gqlgen.yml` settings: `omit_slice_element_pointers: true` (use `[]User` instead of `[]*User`), `struct_fields_always_pointers: false`, and `resolvers_always_return_pointers: false` reduce allocations significantly. gqlgen executes field resolvers concurrently in goroutines by default. For large schemas, `skip_validation: true` saves 1–4 minutes on code generation.

---

## 6. Defense-in-depth authorization from gateway to resolver

### Authenticate at the gateway, authorize at both layers

Authentication (token validation) happens **once** at the gateway. Coarse-grained authorization (scope checks, role requirements) enforces at the gateway via Federation 2 directives. Fine-grained, data-dependent authorization (ownership checks, relationship-based access) enforces at the subgraph where domain context exists.

### Apollo Federation 2 authorization directives

**`@authenticated`** marks fields requiring a valid JWT. The router removes these fields from the query plan for unauthenticated requests — subgraphs never see them. **`@requiresScopes`** restricts access based on OAuth2 scopes with AND/OR logic: `scopes: [["read:email", "read:users"]]` means both required; `scopes: [["admin"], ["superadmin"]]` means either suffices. **`@policy`** handles complex authorization via external policy engines (OPA, Casbin) through coprocessors.

Router JWT configuration:

```yaml
authentication:
  router:
    jwt:
      jwks:
        - url: https://your-idp.com/.well-known/jwks.json
          poll_interval: 60s
      header_name: Authorization
      header_value_prefix: Bearer

headers:
  all:
    request:
      - propagate:
          named: Authorization
      - propagate:
          named: X-Tenant-ID
```

### gqlgen directive-based authorization

Define a custom `@auth` directive and implement it in Go:

```go
func directiveRoot() generated.DirectiveRoot {
    return generated.DirectiveRoot{
        Auth: func(ctx context.Context, obj interface{}, next graphql.Resolver, roles []string) (interface{}, error) {
            user := auth.ForContext(ctx)
            if user == nil {
                return nil, fmt.Errorf("access denied: not authenticated")
            }
            if len(roles) > 0 && !user.HasAnyRole(roles) {
                return nil, fmt.Errorf("access denied: insufficient permissions")
            }
            return next(ctx)
        },
    }
}
```

### Multi-tenant isolation

Two approaches: **transport-based** (tenant ID in JWT/headers, schema-agnostic — simpler but invisible to tooling) and **schema-based** (tenant as a first-class entity with `@key`, all queries scoped through it — more visible but more complex). Both require database-level enforcement: use PostgreSQL Row-Level Security or always filter by `tenant_id` in every query.

---

## 7. Federated subscriptions use HTTP multipart, not WebSockets

Apollo Router handles subscriptions by decomposing them into a subscription for the root field (sent to the owning subgraph) plus follow-up entity queries to other subgraphs on each event. **Clients communicate via HTTP multipart streaming** (not WebSocket), eliminating traditional WebSocket scaling challenges. Apollo Client for Web, iOS, and Kotlin support this natively.

Between router and subgraphs, two modes exist. **Passthrough mode** uses WebSocket connections (`graphql_ws` protocol). **Callback mode** (GA since Router v1.37) eliminates persistent connections entirely — subgraphs push events via HTTP to the router. Callback mode is ideal for serverless architectures. Both modes can be mixed per-subgraph.

```yaml
subscription:
  enabled: true
  mode:
    passthrough:
      all:
        path: /ws
        protocol: graphql_ws
```

gqlgen's subscription support uses channel-based resolvers. The resolver returns a `<-chan *YourType`, sends events via the channel, and cleans up when `ctx.Done()` signals client disconnection. For federation, gqlgen subgraphs typically use WebSocket passthrough mode with the Apollo Router.

**Scalability:** Without deduplication, 1M client subscriptions equals 1M backend WebSocket connections. The router deduplicates identical subscriptions into single backend connections. HTTP callback mode eliminates persistent connections entirely. **Subscription support in self-hosted Apollo Router requires a GraphOS Enterprise plan.**

---

## 8. Error handling through typed unions, not string messages

### The errors array vs. typed union pattern

GraphQL returns errors in a top-level `errors` array with `message`, `locations`, `path`, and `extensions`. The `extensions` map is the sanctioned place for machine-readable codes (`UNAUTHENTICATED`, `BAD_USER_INPUT`, `FORBIDDEN`, `NOT_FOUND`, `INTERNAL_SERVER_ERROR`). GraphQL uniquely supports **partial responses** — both `data` and `errors` in the same response, with failing fields set to `null`.

For business logic errors, the **union/Result pattern** is superior to string-based errors:

```graphql
union CreateUserResult = CreateUserSuccess | UserNameTaken | PasswordTooShort

type CreateUserSuccess { user: User! }
type UserNameTaken implements UserError { message: String!; suggestion: String! }
type PasswordTooShort implements UserError { message: String!; minimumLength: Int! }

type Mutation {
  createUser(input: CreateUserInput!): CreateUserResult!
}
```

This makes errors **typed, discoverable via introspection, and non-null** (no ambiguity about what `null` means). Clients handle each error type specifically while falling back to the common interface for unknown error types.

### Null bubbling is federation's hidden danger

When a non-null field returns `null` due to error, GraphQL propagates null to the nearest nullable parent. In federation, if SubgraphB can't resolve a non-null entity field, the **entire entity** nullifies — potentially cascading to nullify large response sections. **Make entity fields from external subgraphs nullable** unless you have very strong SLAs from the owning subgraph.

### gqlgen error masking

Always implement a custom `ErrorPresenter` to prevent internal details from leaking:

```go
server.SetErrorPresenter(func(ctx context.Context, e error) *gqlerror.Error {
    var typedErr *TypedError
    if errors.As(e, &typedErr) {
        return &gqlerror.Error{
            Message: typedErr.UserMessage(),
            Extensions: map[string]interface{}{"code": typedErr.Code()},
        }
    }
    log.WithError(e).Error("unexpected GraphQL error")
    return &gqlerror.Error{
        Message: "Internal server error",
        Extensions: map[string]interface{}{"code": "INTERNAL_SERVER_ERROR"},
    }
})
```

The Apollo Router's `include_subgraph_errors: { all: false }` configuration hides raw subgraph error details from clients by default. WunderGraph Cosmo offers granular control: `omit_extensions`, `omit_locations`, and `attach_service_name` options.

---

## 9. Observability requires traces for fields, metrics for operations

### Per-subgraph latency with OpenTelemetry

Apollo Router exports standard OpenTelemetry metrics and traces. The `http.client.request.duration` histogram tracks subgraph fetch latency; `apollo.router.overhead` isolates router processing time. Configure OTLP export:

```yaml
telemetry:
  exporters:
    tracing:
      otlp:
        enabled: true
        endpoint: http://otel-collector:4317
        protocol: grpc
    metrics:
      otlp:
        enabled: true
        endpoint: http://otel-collector:4317
  instrumentation:
    spans:
      subgraph:
        attributes:
          subgraph.name:
            subgraph_name: true
```

For gqlgen subgraphs, **`otelgqlgen`** middleware adds tracing for all resolvers:

```go
srv := handler.NewDefaultServer(schema)
srv.Use(otelgqlgen.Middleware())
```

### Cardinality is the primary monitoring challenge

Per-field metrics in a schema with 500 fields × 1,000 operation names × 10 subgraphs produces **5 million unique metric series**. The Apollo Router OTel SDK caps at 2,000 unique attribute combinations per metric per batch. Mitigation: use **traces** (sampled, low-cardinality) for field-level and resolver-level debugging; use **metrics** (aggregated) only for operation-level and subgraph-level monitoring. Set `field_level_instrumentation_sampler: 0.01` for high-traffic APIs. Never use user IDs or full query text as metric labels. Monitor cardinality overflow with `apollo_router_telemetry_metrics_cardinality_overflow`.

### Apollo Studio alternatives

**GraphQL Hive** (MIT, self-hostable) provides schema registry, conditional breaking changes using real usage data, deprecated field tracking, and operation monitoring. **Stellate** provides edge caching across 60+ global data centers with per-operation analytics and automatic mutation invalidation (~150ms globally). **Grafana + Prometheus** enables fully custom dashboards. The pre-built Grafana dashboard ID `16188` covers Apollo GraphQL metrics. Track four core Prometheus metrics: `graphql_request_total`, `graphql_request_duration_seconds`, `graphql_errors_total`, and `graphql_field_execution_duration_seconds`.

### Operation naming enforcement

Named operations are essential for observability, caching, debugging, and security. Enforce via `@graphql-eslint/no-anonymous-operations` in CI and custom Apollo Server plugins or router configuration that reject anonymous operations.

---

## 10. GraphQL and REST coexist through the strangler fig pattern

### Incremental migration, never big-bang

The strangler fig pattern places a GraphQL gateway as a facade in front of the legacy REST monolith. All client calls pass through it. Define a GraphQL schema matching existing data structures, start with one domain, extract subgraphs domain-by-domain, and decommission the monolith when all domains are migrated. Netflix followed exactly this path: public OpenAPI → monolithic Falcor → GraphQL shim → federated GraphQL, validating each step with **replay testing** (comparing old and new system responses).

### Shared service layer in Go

Run gqlgen alongside REST handlers using Chi or Gin router, with both calling into the same service layer:

```go
router := chi.NewRouter()
router.Use(auth.Middleware())

// GraphQL
srv := handler.NewDefaultServer(graph.NewExecutableSchema(cfg))
router.Handle("/graphql", srv)

// REST (same service layer)
router.Route("/api/v1", func(r chi.Router) {
    r.Get("/users/{id}", api.MakeGetUserHandler(userService))
})
```

Both GraphQL resolvers and REST handlers call `UserService.GetByID()` — business logic lives in one place.

### Automatic REST generation from GraphQL

**sofa-api** (The Guild) converts GraphQL queries to GET endpoints and mutations to POST endpoints, auto-generating OpenAPI/Swagger documentation. **GraphQL2REST** (Sisense) uses a manifest file to map REST routes to GraphQL operations with custom parameter and error code mapping. Both approaches maintain a single codebase while serving both API styles.

### Versioning: evolution vs. explicit versions

GraphQL's philosophy is continuous evolution — add new fields, deprecate old ones with `@deprecated`, monitor usage, remove when usage reaches zero. REST requires explicit version bumps (`/v1/`, `/v2/`). **Shopify is the notable exception**, using URL-versioned GraphQL endpoints (`/admin/api/2024-04/graphql.json`) with 3-month cycles and 9-month support windows — practical for large public APIs with many external consumers.

The **BFF (Backend for Frontend) pattern** is GraphQL's natural habitat: one endpoint serves web, mobile, and IoT clients with different data needs through different queries against the same schema. Start with a BFF, evolve to a monolithic GraphQL server, then consider Federation as the graph grows beyond a single team's ownership capacity.

---

## Conclusion

Building federated GraphQL at scale with Go subgraphs is a systems engineering challenge that spans schema design, team coordination, runtime performance, and operational maturity. **Three decisions will shape your architecture more than any others:** the choice between Apollo Router (deepest ecosystem) and WunderGraph Cosmo (best Go-native open-source alternative), the rigor of your schema governance CI pipeline (automated composition checks and breaking change detection are non-negotiable), and your entity boundary design (align with DDD bounded contexts, not backend services).

The most common failure mode is not technical — it's organizational. Netflix and Expedia both emphasize that federation succeeds when the graph is treated as a shared product with top-down design guidelines and bottom-up implementation. Invest in developer experience (schema linting, clear naming conventions, deprecation workflows) before scaling to dozens of subgraphs. Start with a monolithic GraphQL server, prove value with early adopters, then federate when multiple teams need independent deployment. The technology is mature; the challenge is governance.