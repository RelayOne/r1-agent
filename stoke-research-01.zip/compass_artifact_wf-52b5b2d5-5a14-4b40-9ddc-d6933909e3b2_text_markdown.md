# Production correctness failures: the comprehensive enforcement reference

**Every year, floating-point rounding errors destroy stock indices, integer overflows ground aircraft, DST transitions fire alarms at the wrong hour, and Unicode normalization mismatches corrupt databases.** These bugs share a common trait: they pass all unit tests, survive code review, and detonate only in production with real international users, real money, and real edge-case dates. This reference catalogs every documented failure pattern across numerical correctness, time/date handling, Unicode processing, serialization boundaries, and data integrity — with specific linter rules, CI checks, and enforcement strategies to catch each class of bug before it ships.

No existing SKILL.md, .cursorrules file, or AI agent instruction set encodes these patterns. The ecosystem of published agent skills focuses on workflow automation, framework usage, and style. This document fills that gap.

---

## Floating-point money has destroyed hundreds of millions of dollars

The canonical production incidents form a progression from rounding bias to overflow to conversion error, each illustrating a distinct failure mode that recurs in modern systems.

**The Vancouver Stock Exchange (1982–1983)** lost 52% of its index to truncation bias. The electronic index, initialized at 1,000.000, was recalculated after each of ~3,000 daily transactions. Each result was *truncated* to 3 decimal places instead of *rounded*. The average downward bias of ~0.0005 per transaction accumulated to ~1.5 points/day. After 22 months the index read **524.811** when its true value was **~1,098.892**. Fixed over a weekend in November 1983, the index jumped overnight by 574 points. This is the textbook case of salami slicing — systematic rounding in one direction accumulating to material error.

**The Patriot missile failure (February 25, 1991)** killed 28 soldiers at Dhahran. The system's clock counted 1/10-second ticks as integers, then multiplied by 0.1 using a 24-bit fixed-point register. Since 0.1 in binary is non-terminating (`0.0001100110011...`), the chopped representation introduced **~9.5 × 10⁻⁸ seconds of error per tick**. After 100 hours of continuous operation: 0.3433 seconds of drift. A Scud missile at 1,676 m/s covers **~687 meters** in that time — far exceeding the 137-meter tracking threshold. A partial software patch corrected some conversion calls but not all, making the error *worse* through inconsistent precision. The fix arrived one day too late.

**Ariane 5 Flight 501 (June 4, 1996)** was destroyed by a 64-bit to 16-bit integer conversion overflow. The Inertial Reference System, reused from Ariane 4, converted a horizontal velocity bias from 64-bit float to 16-bit signed integer (max 32,767). Ariane 5's faster trajectory exceeded this range within 37 seconds. Engineers had protected 4 of 7 critical variables but left 3 unprotected to meet an 80% CPU budget. Both redundant IRS units ran identical software and failed simultaneously. Cost: **~€500 million**.

**Knight Capital (August 1, 2012)** lost $440 million in 45 minutes — not from floating-point error specifically, but from a deployment failure that reactivated dead code. A repurposed flag bit on 1 of 8 servers triggered a deprecated "Power Peg" algorithm that sent orders indefinitely without recording fills. The firm acquired **$7.65 billion in unwanted positions** before Goldman Sachs bought them at fire-sale prices. Knight was acquired by GETCO within months.

### IEEE 754 edge cases that actually bite

The `0.1 + 0.2 = 0.30000000000000004` problem is well-known but often dismissed as academic. It becomes material in these specific scenarios:

**JSON serialization above 2⁵³.** `Number.MAX_SAFE_INTEGER` is 9,007,199,254,740,991. Beyond this, consecutive integers become indistinguishable: `9007199254740992 === 9007199254740993` evaluates to `true`. Twitter and Discord both discovered this when their snowflake IDs exceeded 2⁵³, forcing both APIs to return `id_str` (string) alongside `id` (number). Any API returning 64-bit database IDs through JSON must serialize them as strings.

**Rounding strategy mismatches** cause silent discrepancies between systems. IEEE 754 defaults to round-half-to-even (banker's rounding), but language defaults diverge:

| Language | `round()` default | Implication |
|----------|-------------------|-------------|
| Python 3 | Half-to-even | `round(2.5) = 2`, `round(3.5) = 4` |
| Java `Math.round()` | Half-up (toward +∞) | `Math.round(2.5) = 3` |
| JavaScript `Math.round()` | Half-away-from-zero | `Math.round(-0.5) = 0` (toward +∞) |
| Go `math.Round()` | Half-away-from-zero | `math.Round(2.5) = 3` |
| C# `Math.Round()` | Half-to-even | Same as Python |

**Accumulation drift** from naive summation loses precision proportional to N. Summing 0.1 ten thousand times yields 999.9999999999831, not 1000.0. Kahan compensated summation maintains a running error term, reducing total error from O(N) to O(1). **Epsilon comparison** (`abs(a-b) < ε`) fails for both very large numbers (where relative error matters) and very small numbers near zero. No single epsilon works universally.

### Enforceable rules for money calculations

- **Never use float/double for money.** Store as integer minor units (cents) or use decimal types.
- **Always construct decimals from strings:** `Decimal("0.1")` not `Decimal(0.1)`. Every major language's decimal type silently inherits float imprecision from float-argument constructors.
- **Explicitly specify rounding mode** at every operation that may round. Java's `BigDecimal.divide()` throws `ArithmeticException` without explicit rounding — this is correct behavior.
- **Round as late as possible** in calculation chains. Document which rounding method is used and why.
- **Serialize monetary values as strings in JSON**, never as bare numbers.

---

## Decimal library selection determines your precision ceiling

### Go: three libraries, three philosophies

**shopspring/decimal** is the most widely used Go decimal library. It uses `big.Int` coefficient + `int32` exponent, is immutable (all methods return new values), and supports arbitrary precision with a default division precision of 16 digits. Thread-safe due to immutability. **Gotcha:** panics on division by zero rather than returning an error. `NewFromFloat(0.1)` inherits float64's approximation.

**cockroachdb/apd** was built because shopspring produced incorrect results, panics, and non-terminating operations that consumed 100% CPU. It implements the General Decimal Arithmetic specification with condition flags (Inexact, Rounded, Overflow) and traps. Mutable API (like `big.Int`). CockroachDB needed Postgres-compatible results. **~13× slower** than shopspring at 100-digit precision due to GDA compliance overhead, but provides stronger correctness guarantees.

**govalues/decimal** fits in a single `uint64` + scale + sign with zero heap allocations, but is limited to **19 significant digits**. Sufficient for USD amounts up to ~$92 quadrillion with cents. Fuzz-tested against both shopspring and cockroachdb/apd. Best for performance-critical financial code within its precision range.

### Rust: rust_decimal mirrors C# System.Decimal

The `rust_decimal` crate stores a **96-bit unsigned mantissa + 32-bit flags** (scale 0–28, sign bit) = 128 bits total, supporting ~28–29 significant digits. `Copy + Send + Sync`. The `dec!()` macro parses at compile time: `dec!(0.1)` is exact. **Critical serde gotcha:** default JSON serialization emits a float-like number that can lose precision. Enable `serde-with-str` or `serde-with-arbitrary-precision` for safety. For >28 digits, use the `bigdecimal` crate (arbitrary precision via `num-bigint`) or `rug` (GMP/MPFR bindings).

### JavaScript: big.js for math, dinero.js for money objects

All three decimal libraries (big.js, bignumber.js, decimal.js) are by the same author. **big.js** (5.9 KB minified, 2.7 KB gzipped) uses decimal-places precision — correct for financial use. **decimal.js** (~20 KB) uses significant-digits precision, which silently truncates large financial values: `Decimal('22222222222222222222').div(2)` with 10 significant digits = `11111111110000000000`. **Never use decimal.js for money.**

**dinero.js v2** implements Martin Fowler's Money pattern: integer minor units + currency metadata. Its `allocate()` method correctly distributes remainders (e.g., $10.00 ÷ 3 = [$3.34, $3.33, $3.33]). Supports all ISO 4217 currencies including non-decimal ones. **JSON serialization gotcha:** all these libraries produce objects, not primitives. `JSON.stringify` requires custom serializers.

### Python and Java: stdlib is sufficient but has traps

Python's `decimal.Decimal` uses a C implementation (`libmpdec`) with 28-digit default precision and thread-local contexts. **The critical trap:** `Decimal(0.1)` produces `Decimal('0.1000000000000000055511151231257827021181583404541015625')` — always use `Decimal("0.1")`.

Java's `BigDecimal` has three traps. First: `new BigDecimal(0.1)` inherits float approximation; use `new BigDecimal("0.1")` or `BigDecimal.valueOf(0.1)`. Second: `equals()` checks both value *and* scale, so `new BigDecimal("2.0").equals(new BigDecimal("2.00"))` is **false** — use `compareTo()` for numeric equality. Third: division without explicit scale and `RoundingMode` throws `ArithmeticException` for non-terminating results like 1/3. All three traps are sources of production bugs.

---

## Time is political, not physical: every assumption breaks somewhere

### DST transitions create impossible and ambiguous times

During spring forward, **2:00–2:59 AM does not exist**. During fall back, **1:00–1:59 AM occurs twice**. These aren't edge cases — they affect every DST-observing timezone twice per year, hitting billions of users.

**Apple's recurring alarm bug** has manifested in iOS/watchOS nearly every year since 2010. In 2010, Australian users' recurring alarms fired one hour early after DST started. In 2025, Apple Watch alarms set between 2:00–2:59 AM during the March 9 spring-forward displayed one hour late. The bug corrected itself the next day. iPhone medication reminders have been reported one hour late after DST transitions — a safety-critical failure for time-sensitive medications.

**Cron jobs in the 2 AM danger zone** behave unpredictably. During spring forward, traditional Unix cron **skips** jobs scheduled 2:00–2:59 AM. During fall back, jobs scheduled 1:00–1:59 AM may **run twice**. A documented Kubernetes CronJob bug (issue #121594, October 2023) caused jobs to run twice during fall-back in Europe/Berlin. One Medium post describes a CronJob that spawned **1,000+ duplicate instances** during a DST transition, costing $5,000 in cloud compute. **Rule: schedule system cron jobs in UTC, never in local time. Avoid 1:00–3:00 AM local for any DST-observing zone.**

### Countries change timezone rules with as little as one day of notice

| Country | Change | Notice Given |
|---------|--------|-------------|
| Haiti | Cancelled DST for 2016 | **1 day** before scheduled start |
| North Korea | Created UTC+8:30 | **8 days** |
| Azerbaijan | Cancelled DST permanently | **10 days** |
| Turkey | Abolished DST, stayed on UTC+3 | ~3 weeks |
| Morocco | Adjusts clocks for Ramadan (shifts ~11 days/year) | Weeks, but unpredictable |
| Samoa | Skipped December 30, 2011 entirely | ~6 months |
| Russia | Changed timezone policy **three times** (2011, 2014, 2016) | Varied |

The IANA timezone database (tzdata) is the authoritative source, but updates must propagate through OS packages (days–weeks), JVM timezone data (weeks–months without manual TZUpdater), Docker base images (potentially **months** if images aren't rebuilt), and mobile OS updates (weeks–months). A documented Turkey incident: after the 2016 DST abolishment, a Java application in a Docker container showed time one hour behind because the JRE's tzdata was stale, even though the host OS was correct.

**Enforcement:** Mount `/usr/share/zoneinfo` into containers or refresh base images on every IANA release. Run `pip install --upgrade tzdata` periodically for Python. Alert on upstream IANA releases. Never hardcode UTC offsets — **store IANA timezone names** (e.g., `Asia/Karachi`, not `UTC+5`).

### Leap seconds have caused kernel panics and service outages

The 2012 Linux kernel leap second bug (June 30) triggered a **race condition in timekeeping code** that drove servers to 100% CPU via futex spin loops. Reddit, Mozilla, LinkedIn, Yelp, FourSquare, and Qantas (via the Amadeus reservation system) all went down. The workaround was rebooting servers. The fix landed in kernel 3.5.

The **Cloudflare 2017 incident** is particularly instructive. Their RRDNS software measured resolver performance using `time.Now()` subtraction. During the leap second, the wall clock appeared to go backward, producing a negative duration that was fed into a weighted-selection algorithm expecting ≥0, causing a panic. Impact lasted from 00:00 to 06:45 UTC on January 1, 2017. **This incident directly led to Go 1.9 adding monotonic clock support to `time.Now()`** — one of the most consequential production-bug-driven language changes in recent history.

Google, AWS, and Meta all use **leap smearing** — spreading the extra second over hours (Google/AWS: 24-hour linear smear; Meta: 17-hour quadratic smear). The **27th General Conference on Weights and Measures voted in November 2022 to abolish leap seconds by or before 2035**, with the 28th CGPM (2026) expected to finalize the new tolerance limit.

**Enforcement:** Use monotonic clocks for all duration measurement. In Go, `time.Now()` already includes a monotonic reading since 1.9 — but `time.Parse()` and `time.Date()` do not. Never use wall-clock subtraction for elapsed time in any language.

---

## Calendar arithmetic is inherently lossy and non-reversible

### "Add one month to January 31" has no correct answer

| Library | Jan 31 + 1 month | Behavior |
|---------|-------------------|----------|
| Java `LocalDate.plusMonths()` | Feb 28/29 | Clamps to last valid day |
| Python `dateutil.relativedelta` | Feb 28 | Clamps to last valid day |
| JavaScript `Date.setMonth()` | **March 3** | Silently rolls into next month |
| moment.js `.add(1, 'month')` | Feb 28 | Clamps |
| date-fns `addMonths()` | Feb 28 | Clamps |
| Temporal API `PlainDate.add()` | Feb 28 (default) | `overflow: "constrain"` clamps; `overflow: "reject"` throws |

JavaScript's native `Date` is the outlier — rolling overflow into the next month is widely considered a design flaw. The critical insight is that **month addition is not reversible**: Jan 31 + 1 month = Feb 28, but Feb 28 + 1 month = Mar 28, not Mar 31. `P1M ≠ P30D` in ISO 8601 durations: P1M from January 15 is 31 days; P1M from February 15 is 28 or 29 days.

### YYYY vs yyyy is the new Y2K

Java's `DateTimeFormatter` pattern `YYYY` means *week-based year*, not calendar year. `yyyy` means calendar year. They're identical for ~358 days/year and **diverge only in the last ~7 days of December and first ~7 days of January** — making the bug nearly undetectable in testing. December 31, 2019 formatted with `YYYY` returns "2020". The UK Government Digital Service documented fixing this bug in production. The Bouncy Castle cryptographic library shipped it. **The bug is also locale-dependent** — YYYY uses different week definitions in US vs ISO locales, so a developer testing in one locale may never see the failure.

Google's **Error-Prone** static analysis tool catches this with the `MisusedWeekYear` check. IntelliJ IDEA highlights it. **This should be an enforced lint rule in every Java/Kotlin project.**

---

## Unicode correctness failures corrupt data and enable attacks

### String length is a meaningless concept without specifying the unit

The family emoji 👨‍👩‍👧‍👦 is **1 grapheme cluster** but **7 codepoints** (4 emoji + 3 ZWJ), **11 UTF-16 code units** (JavaScript `.length` returns 11), and **25 UTF-8 bytes** (Go `len()` returns 25). Truncating at any byte offset can produce invalid UTF-8. Twitter evolved its character-counting algorithm through multiple iterations to handle this correctly, eventually using NFC normalization and weighting emoji as 2 characters.

### NFC vs NFD normalization causes silent comparison failures

The character é exists as both U+00E9 (NFC, composed) and U+0065 U+0301 (NFD, decomposed). macOS HFS+ returned NFD-normalized filenames; APFS preserves the original form but uses normalized hashes for lookups. Cross-platform bugs are rampant: Git diff discrepancies, CI "file not found" errors, and S3 key mismatches when one system normalizes and another doesn't. **W3C recommends NFC for interchange.** Normalize all text to NFC at application boundaries before database insertion.

### The Turkish İ problem breaks SSL, process launching, and permission checks

In Turkish locale, `"I".toLowerCase()` returns `"ı"` (U+0131, dotless i), not `"i"`. This has broken: **Java SSL handshake** (cipher suite name mismatch), **Java `Runtime.exec()`** (process spawning failure), **Apache Spark** (Hive metastore failures from "serdeınfo"), **GraalVM** (enum lookup failure from "ACQUİRE"), **Atlassian Confluence** (permission check failures), and **Minecraft** (texture loading broken for Turkish users). **Always use `Locale.ROOT` (Java), `CultureInfo.InvariantCulture` (C#), or explicit locale-independent case conversion for non-display strings.**

### Trojan Source attacks hide malicious code in plain sight

CVE-2021-42574 exploits Unicode bidirectional override characters (U+202A–U+202E, U+2066–U+2069) embedded in source code comments and string literals. Code appears benign to human reviewers but executes differently. GCC 12 added `-Wbidi-chars`, Rust 1.56.0 added compiler warnings, and GitHub now shows a dialog when bidi characters appear in repository code. The Go linter **bidichk** and gosec rule **G116** catch this.

### Zero-width and homoglyph attacks bypass string equality

Zero-width space (U+200B), zero-width joiner (U+200D), and zero-width non-joiner (U+200C) create strings that appear identical but differ in byte representation. Username squatting, password bypasses, email phishing filter evasion (the "Shy Z-WASP" technique), and LLM prompt injection all exploit invisible characters. The **GlassWorm campaign (October 2025)** affected 35,800+ VS Code extension installations by hiding loader code with invisible Unicode.

Homoglyph attacks use visually identical characters from different scripts (Cyrillic а vs Latin a). Unicode TR39 defines a skeleton algorithm mapping ~6,565 confusable characters. Browsers now show Punycode for mixed-script domains after the 2017 `аррӏе.com` (all-Cyrillic) incident. **ICU's `USpoofChecker`** is the canonical confusable detection implementation.

### MySQL utf8 is not UTF-8

MySQL's `utf8` charset (aliased to `utf8mb3`) supports only **3 bytes per character** — a broken subset that cannot store emoji, many CJK characters, or any codepoint above U+FFFF. `utf8mb4`, introduced in MySQL 5.5.3 (2010), supports full 4-byte UTF-8. MySQL 8.0 changed the default to `utf8mb4`. **Attempting to insert emoji into a `utf8` column produces `ERROR 1366: Incorrect string value`**. The VARCHAR(255) index limit under utf8mb4 is 191 characters (191 × 4 = 764 < InnoDB's 767-byte limit). Rails, Prisma, and WordPress have all shipped production bugs from this mismatch.

---

## Serialization boundaries silently corrupt data in transit

### JSON has no integer type and JavaScript loses precision above 2⁵³

RFC 8259 defines numbers as arbitrary-precision decimal strings, but the I-JSON profile (RFC 7493) recommends staying within IEEE 754 double range. In practice, **`JSON.parse('{"id": 9007199254740993}')` silently rounds to `9007199254740992`** — precision loss with zero errors.

Twitter returns `id_str` alongside `id`. Discord returns all snowflake IDs as strings. Proto3's canonical JSON encoding serializes all `int64`/`uint64` fields as **quoted strings** — confusing but correct. Prisma's BigInt fields throw `TypeError: Do not know how to serialize a BigInt` with `JSON.stringify` unless you define a custom serializer. **Any system exchanging 64-bit integers via JSON must use string encoding.**

### Protobuf field number reuse causes silent data corruption

Field numbers are the wire-format identity. Reusing a deleted field number means old serialized data with the original type gets deserialized as the new type — **silently producing garbage**. A documented buf.build example: reusing a `cost` field number after changing currency semantics caused a system to interpret 990 (thousandths of USD) as $990 instead of $0.99. **Always use `reserved` for deleted field numbers and names. Use `buf breaking` in CI to detect field reuse.**

### Avro schema evolution requires defaults for new fields

Adding a field without a default value breaks backward compatibility — old data lacking the field cannot be read. Union type ordering matters: `["null", "string"]` with `default: null` works; `["string", "null"]` with `default: null` fails because null doesn't match the first branch. Defaults are only used when *reading* old data, not at write time — a common source of confusion.

---

## Integer overflow has grounded aircraft and crashed websites

### Every language handles overflow differently

**Go** silently wraps — no checked arithmetic in the standard library. **Rust** panics in debug mode, wraps in release — with explicit `checked_add()`, `saturating_add()`, `wrapping_add()`, and `overflowing_add()` methods for intentional behavior. **JavaScript** has no integers above 2⁵³; precision silently degrades. **C/C++ signed overflow is undefined behavior** — compilers can optimize away overflow checks entirely (e.g., `if (x + 1 > x)` may be elided). C23 mandates two's complement but overflow remains UB. **Java** silently wraps by default; `Math.addExact()` throws `ArithmeticException` (Java 8+). **Python** native ints have arbitrary precision, but **numpy integers wrap silently**.

### Production incidents span aviation to entertainment

**Boeing 787 (2015 FAA Airworthiness Directive):** A signed 32-bit counter in Generator Control Units incremented at 100 Hz overflows after **248.55 days** of continuous power (2³¹ ÷ 100 ÷ 86400 = 248.55). All four GCUs could enter failsafe simultaneously, causing **total loss of AC power**. Interim fix: power-cycle every 120 days. Similar: Airbus A350 had a 149-hour overflow; Windows 95 hung after 49.7 days.

**YouTube/Gangnam Style (December 2014):** PSY's video exceeded 2,147,483,647 views (2³¹ − 1). Google upgraded to 64-bit. **Unix 2038 problem:** `time_t` as signed 32-bit overflows at 03:14:07 UTC, January 19, 2038. Linux kernel 5.6+ uses 64-bit `time_t` on 32-bit systems, but embedded devices, databases, and IoT systems remain vulnerable.

---

## The linter and CI enforcement landscape has critical gaps

### What exists today

**Rust (Clippy)** has the strongest numeric lint coverage:

- `float_cmp` / `float_cmp_const` — warns on float equality checks (Deny by default)
- `cast_possible_truncation` — warns on potentially truncating casts like `u64 as u8`
- `cast_sign_loss` / `cast_possible_wrap` — warns on sign/wrap-losing casts
- `cast_precision_loss` — warns on int→float precision loss
- `arithmetic_side_effects` — warns on any arithmetic that could overflow (restriction lint, must opt in)
- `as_conversions` — forbids all `as` casts (restriction lint)
- `float_arithmetic` — forbids all floating-point arithmetic (for financial modules)

**Go (golangci-lint)** has gosec G115 (integer overflow in type conversions) and G116 (bidi Unicode attacks), plus `durationcheck` for `time.Duration` mistakes and `bidichk` for Trojan Source. **However, G115 generated massive false-positive complaints** (Docker/Moby issue #48358 showed hundreds of hits), partially fixed in v1.61.0.

**JavaScript (ESLint)** has `no-loss-of-precision` (in `eslint:recommended`) and the niche `eslint-plugin-big-number-rules` which can auto-fix `0.1 + 0.2` to `BigNumber.sum(0.1, 0.2)`. No mainstream plugin prevents float usage for money calculations.

**C/C++** has UBSan (`-fsanitize=signed-integer-overflow`, `-fsanitize=unsigned-integer-overflow`), `-fwrapv` (force wrapping), `-ftrapv` (trap on overflow), and C23's `<stdckdint.h>` with `ckd_add()`, `ckd_sub()`, `ckd_mul()`.

**Java** has Google's Error-Prone (`MisusedWeekYear`, `FloatingPointLiteralPrecision`), SpotBugs (`ICAST_INTEGER_MULTIPLY_CAST_TO_LONG`), and `Math.addExact()` / `Math.multiplyExact()` for checked arithmetic.

**SonarQube** rule S1244 warns on float equality checks across C, C#, and Objective-C. **Semgrep** supports custom `metavariable-comparison` rules for numeric checks. **CodeQL** has demonstrated integer-overflow-to-malloc queries that found CVEs in libcurl and json-c.

### What's missing: the enforcement gap

The following failure patterns **have no automated enforcement in any major tool**:

- No linter prevents float usage for money in JavaScript/TypeScript
- No linter catches hardcoded 2-decimal-place currency assumptions
- No linter catches `new Date()` misuse or timezone-naive date comparisons
- No linter catches locale-naive string sorting
- No CI rule validates database collation consistency with application code
- No linter catches name-field length/format assumptions (requiring first+last name, minimum lengths)
- No SKILL.md or agent instruction set encodes any of these patterns
- The "Falsehoods Programmers Believe About" series remains **entirely educational** — none have been converted to enforceable lint rules

---

## The Falsehoods series identifies bugs that tooling doesn't catch

The canonical "Falsehoods Programmers Believe About Names" (Patrick McKenzie) and "Falsehoods About Time" (Noah Sussman) have spawned dozens of domain-specific lists, curated in the `awesome-falsehood` repository. The most actionable have corresponding libraries:

- **Phone numbers → Google's libphonenumber** — parses, validates, and formats international numbers; includes its own `FALSEHOODS.md` with 25+ false assumptions; used by Android since 4.0
- **Addresses → Google's libaddressinput** — handles international address formats
- **Unicode/locale → ICU** (International Components for Unicode) — locale-sensitive collation (UCA-compliant), number/date formatting, text boundary analysis, normalization
- **Locale data → CLDR** (Common Locale Data Repository) — defines number formats, date formats, currency minor units, plural rules, and sort order for 100+ locales; used by ICU, Java, .NET, and all browsers' `Intl` API

---

## Currency, concurrency, and locale: the remaining production killers

### Not all currencies have two decimal places

**JPY has 0 decimals** (¥500, not ¥500.00). **BHD, KWD, OMR have 3** (0.001 dinar). **MGA and MRU are non-decimal** (5:1 subdivision ratio). Some payment processors deviate from ISO 4217 — Adyen treats ISK as 2 decimals despite the standard specifying 0. JavaScript's `Intl.NumberFormat` automatically handles minor units per ISO 4217 using CLDR data. **Hardcoding 2 decimal places will corrupt transactions in ~30 currencies.**

### Locale-dependent number parsing is a silent data corruption vector

The string "1.234" parses as 1.234 in English but represents 1234 in German (where period is the grouping separator). Indian numbering uses non-uniform grouping: 1,00,000 (one lakh). No built-in parser in any major language handles locale-dependent number parsing correctly without explicit locale specification. **Always require explicit locale when parsing human-formatted numbers. Never parse without knowing the source locale.**

### Idempotency and locking must be used together

Idempotency keys (Stripe's pattern: client-generated UUID per operation, server caches result for 24 hours) prevent duplicate processing from retries. Database locks (`SELECT ... FOR UPDATE`, optimistic versioning, serializable isolation) prevent race conditions between concurrent operations. A documented WooCommerce/Stripe bug (issue #2339) charged customers 3 times because idempotency keys were only set for `/charges`, not `/payment_intents`. **Neither mechanism alone is sufficient. Both are required for correctness in financial systems.**

The classic race condition: two concurrent withdrawals both read balance=1000, both pass validation, both write their result. Final balance reflects only one withdrawal. Solutions: pessimistic locking (`SELECT ... FOR UPDATE`), optimistic locking (version column), atomic conditional updates (`UPDATE SET balance = balance - 300 WHERE balance >= 300`), or serializable isolation. When transferring between accounts, **always acquire locks in consistent order** (e.g., lower account ID first) to prevent deadlocks.

---

## Enforcement checklist for a SKILL.md system

This section maps each failure class to specific, enforceable rules suitable for AI coding agent instructions, CI checks, and code review automation.

### Numerical correctness enforcement

- **FLOAT_MONEY**: Ban `float`/`double`/`f64`/`Number` for monetary values. Require decimal types or integer minor units. → Clippy `float_arithmetic` (restriction), custom Semgrep rule for JS/TS/Go/Python.
- **DECIMAL_FROM_STRING**: Ban decimal construction from float literals. → Custom lint: flag `Decimal(0.1)`, `new BigDecimal(0.1)`, `NewFromFloat()`, `Decimal::from_f64()`.
- **EXPLICIT_ROUNDING**: Require explicit `RoundingMode` on all division and monetary rounding operations. → SpotBugs for Java; custom rule for other languages.
- **JSON_BIGINT**: Require string serialization for any integer field that may exceed 2⁵³. → Custom ESLint rule; `buf breaking` for protobuf.
- **INTEGER_OVERFLOW**: Enable checked arithmetic in release builds. → Rust: `overflow-checks = true` in Cargo.toml. C/C++: UBSan in CI. Go: gosec G115. Java: prefer `Math.addExact()`.
- **CURRENCY_DECIMALS**: Ban hardcoded decimal-place assumptions. Require ISO 4217 lookup for minor units. → Custom Semgrep rule.

### Temporal correctness enforcement

- **UTC_STORAGE**: Store all instants as UTC. Store IANA timezone name separately for display conversion. → Custom lint: flag `new Date()` comparisons without timezone context.
- **MONOTONIC_DURATION**: Use monotonic clock for duration measurement. → Flag `time.Now()` subtraction in pre-Go-1.9 patterns; flag `System.currentTimeMillis()` for duration in Java.
- **NO_CRON_2AM**: Warn on cron schedules in the 1:00–3:00 AM local time range for DST-observing zones. → Custom CI check for Kubernetes CronJob manifests.
- **YYYY_LINT**: Ban `YYYY` in date format patterns unless paired with `ww` for ISO week dates. → Error-Prone `MisusedWeekYear` for Java; custom rule for other languages.
- **TZDATA_FRESHNESS**: CI check that container base images contain tzdata updated within 90 days. → Custom Dockerfile lint.

### Unicode/text correctness enforcement

- **NFC_NORMALIZE**: Normalize all user-input text to NFC at application boundaries. → Custom middleware/validator.
- **GRAPHEME_TRUNCATION**: Ban byte-offset or codepoint-offset string truncation. Require grapheme-cluster-aware truncation. → Custom lint for `str.slice()`, `str[:N]`, `str[..N]`.
- **TURKISH_I**: Ban locale-sensitive case conversion on non-display strings. Require `Locale.ROOT`, `CultureInfo.InvariantCulture`, or equivalent. → Custom Semgrep rule for `.toLowerCase()` without locale argument.
- **BIDI_CHECK**: Reject source code containing bidirectional override characters. → gosec G116, GCC `-Wbidi-chars`, GitHub's built-in detection, `bidichk` linter.
- **HOMOGLYPH_CHECK**: Apply TR39 confusable detection to usernames and identifiers. → ICU `USpoofChecker`, `confusable_homoglyphs` (Python).
- **UTF8MB4**: Require `utf8mb4` for all MySQL charsets. Ban `utf8`/`utf8mb3`. → Custom SQL migration lint.
- **ZERO_WIDTH_STRIP**: Strip zero-width characters from user-input strings used for identity (usernames, emails, passwords). → Custom input sanitizer with allowlist.

### Serialization boundary enforcement

- **PROTO_RESERVED**: Require `reserved` declarations for deleted protobuf field numbers. → `buf breaking` in CI.
- **AVRO_DEFAULTS**: Require default values on all new Avro fields. → Schema registry compatibility checks.
- **IDEMPOTENCY_KEY**: Require idempotency keys on all mutating financial API endpoints. → Custom API spec validator.
- **CONCURRENT_MONEY**: Require row-level locking or atomic conditional updates for balance modifications. → Code review checklist; custom CodeQL query for unprotected read-then-write patterns.

---

## Conclusion: the meta-pattern is boundary crossing

Every failure documented here occurs at a **boundary**: between binary and decimal representation, between time zones, between Unicode normalization forms, between serialization formats, between concurrent transactions. The meta-rule for production correctness is: **every time data crosses a boundary — between systems, between types, between locales, between serialization formats, or between threads — validate that the semantics survived the crossing.** No existing tool enforces this systematically. The SKILL.md system described here would be the first to encode these patterns as machine-enforceable rules, catching the class of bugs that unit tests miss and international users discover.