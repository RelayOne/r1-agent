# Production Rust engineering: a deep reference guide

Rust's production ecosystem has matured dramatically through 2024-2025, with battle-tested patterns emerging from companies processing trillions of requests monthly. **This guide distills the deepest Rust-specific engineering knowledge across async runtimes, error handling, performance optimization, unsafe code auditing, testing, deployment, and real-world production lessons** — specifically tuned for engineers building performance-critical components like parsers, crypto systems, and VM management alongside Go services. The patterns here reflect hard-won knowledge from Cloudflare (Pingora, 40M req/s), Discord (eliminating GC latency spikes), AWS (Firecracker, <125ms VM boot), and dozens of other production deployments.

---

## 1. Tokio async runtime: configuration, cancellation, and structured concurrency

### Runtime flavors and worker tuning

Tokio offers two runtime flavors with distinct tradeoffs. **Multi-thread** (`new_multi_thread()`) is the default under `#[tokio::main]`, spawning worker threads equal to CPU core count and using work-stealing across per-worker local queues (max 256 tasks each) plus a shared global queue. **Current-thread** (`new_current_thread()`) runs single-threaded, ideal for CLI tools, tests, and embedded contexts where tasks needn't be `Send`.

```toml
# Typical production Tokio configuration
[dependencies]
tokio = { version = "1", features = ["full"] }
```

```rust
let rt = tokio::runtime::Builder::new_multi_thread()
    .worker_threads(4)               // default: num CPU cores
    .max_blocking_threads(512)        // default: 512
    .thread_keep_alive(Duration::from_secs(60))
    .enable_all()
    .build()
    .unwrap();
```

For CPU-heavy analytics alongside I/O (common in parser/crypto workloads), InfluxData's pattern of **separate runtimes for CPU vs I/O** prevents compute tasks from starving the I/O event loop. The `TOKIO_WORKER_THREADS` environment variable overrides worker count at deployment time without recompilation.

### spawn vs spawn_blocking: the 10-100µs rule

Alice Ryhl's canonical guidance: **async code should never spend more than 10-100 microseconds without reaching an `.await`**. This is the fundamental decision criterion:

- **`tokio::spawn`**: For async futures. Tasks run on worker threads, migrate between workers at `.await` points. Requires `Send + 'static`.
- **`tokio::task::spawn_blocking`**: Runs closures on a separate, dynamically-grown thread pool (up to 512 threads). Use for filesystem I/O, blocking database drivers (Diesel), and synchronous FFI calls. **Not ideal for CPU-intensive work** — the pool grows unboundedly. Use Rayon instead for CPU parallelism.
- **Rayon + oneshot channel**: The correct bridge for CPU-heavy work in async contexts:

```rust
async fn parallel_sum(nums: Vec<i32>) -> i32 {
    let (tx, rx) = tokio::sync::oneshot::channel();
    rayon::spawn(move || { let _ = tx.send(nums.iter().sum()); });
    rx.await.expect("Panic in rayon::spawn")
}
```

**Critical pitfall**: `spawn_blocking` tasks **cannot be aborted** once started. Calling `.abort()` on a `spawn_blocking` JoinHandle has no effect. And if a `spawn_blocking` task depends on another `spawn_blocking` task completing (via channel or `block_on`), you can deadlock when the pool saturates.

### Async cancellation safety: the hardest problem in async Rust

In Rust, cancelling a future means dropping it. Any future can be cancelled at any `.await` point. This creates the **cancel-safety problem**, thoroughly documented by Oxide Computer's RFD 400 and Rain Jhaveri-Sontag's RustConf 2025 talk.

A future is **cancel-safe** if dropping it loses no data and violates no invariants. Cancel-**unsafe** examples include `tokio::sync::mpsc::Sender::send(msg)` — if the future is dropped mid-send, **the message is lost forever**. The classic trap:

```rust
// BUG: if timeout fires, msg is lost forever!
let msg = next_message();
match timeout(Duration::from_secs(5), tx.send(msg)).await {
    Ok(Ok(_)) => println!("sent"),
    Err(_) => println!("timed out — msg is gone"),
}
```

Oxide discovered their serial console proxy used `tokio::select!` with 4 futures, only 1 of which was cancel-safe. **The compiler provides zero help** — cancel-safety is a documentation-level property, not a type-level one. Rules for writing cancel-safe futures: shared state must not be invalid across `.await` points; prefer self-contained futures; if a future consumes owned data, it is generally not cancel-safe.

For `tokio::select!`, use `biased;` to prioritize shutdown signals, and prefer stream merging (`tokio_stream::StreamExt::merge`) as a cancel-safe alternative to `loop { select! { ... } }`.

### Structured concurrency with JoinSet and TaskTracker

**`JoinSet`** collects spawned tasks with the same return type. When dropped, **all tasks are immediately aborted** — providing automatic cleanup. `join_next().await` is cancel-safe and returns results in completion order.

**`TaskTracker`** (from `tokio_util`) tracks task lifetimes without collecting return values — analogous to Go's `WaitGroup`. Unlike JoinSet, it does NOT abort tasks on drop. Combined with `CancellationToken`, it forms the **idiomatic Tokio graceful shutdown pattern**:

```rust
let tracker = TaskTracker::new();
let token = CancellationToken::new();

for i in 0..10 {
    let token = token.clone();
    tracker.spawn(async move {
        tokio::select! {
            _ = token.cancelled() => { /* cleanup */ },
            _ = do_work(i) => {},
        }
    });
}

token.cancel();
tracker.close();
tracker.wait().await; // blocks until all tasks finish
```

Use **JoinSet** when you need return values or auto-abort. Use **TaskTracker + CancellationToken** for long-lived services needing graceful shutdown.

---

## 2. Error handling: thiserror for libraries, anyhow for applications, snafu for scale

### The decision framework

The canonical framing from dtolnay: use **thiserror** when you care about designing dedicated error types so callers receive exactly the information you choose. Use **anyhow** when you don't care what error type functions return. Luca Palmieri refines this: reason about **intent** — if callers should behave differently based on failure mode, use enum errors; if they'll just propagate or report, use opaque errors.

| Crate | Purpose | Best for | Key feature |
|-------|---------|----------|-------------|
| **thiserror** | Derive macro for custom error types | Libraries | Structured enums, `#[from]`/`#[source]`, zero API footprint |
| **anyhow** | Type-erased error wrapper | Applications | Wraps any `Error + Send + Sync + 'static`, guaranteed backtrace |
| **eyre** | Fork of anyhow with customizable reports | Applications with rich diagnostics | Swappable `EyreHandler`, SpanTrace support via `color-eyre` |
| **snafu** | Context-driven error framework | Large systems, monorepos | Context selectors solve the "two variants from same source type" problem |

**`thiserror` key constraint**: `#[from]` generates `From<T>` impls, meaning only **one variant per source error type** is allowed. This is precisely why snafu exists — its context selectors let multiple variants wrap the same underlying error with different context.

### Production patterns

For library crates, use thiserror with `#[non_exhaustive]` for forward compatibility:

```rust
#[derive(Debug, thiserror::Error)]
#[non_exhaustive]
pub enum DatabaseError {
    #[error("connection failed")]
    Connection(#[from] ConnectionError),
    #[error("query failed: {0}")]
    Query(String),
    #[error("record not found")]
    NotFound,
}
```

For application crates, anyhow with `.context()` provides excellent ergonomics:

```rust
async fn handle_request(id: u64) -> anyhow::Result<Response> {
    let record = db.get(id).await.context("failed to fetch user record")?;
    Ok(format_response(record))
}
```

**GreptimeDB's "Stacked Error" pattern** uses snafu with `snafu::Location` for cheap virtual stack traces (~100K binary overhead vs ~700MB for full debug symbols). Iroh moved from anyhow to snafu for their library crate, scoping error enums to **functions** (e.g., `ConnectError`, `ParseError`) rather than modules.

### Backtrace state in 2025

Backtrace propagation through the `Error` trait remains **unstabilized** (rust-lang/rust#99301). **anyhow** captures backtraces automatically on stable when `RUST_BACKTRACE=1`. **snafu** provides its own `Backtrace` type via `backtrace-rs` for stable Rust. thiserror's backtrace support requires nightly. For production services on stable Rust, anyhow at the application level or snafu with its `Backtrace` type are the practical choices.

---

## 3. Ownership pitfalls that trip up AI code generators and humans alike

### The unnecessary clone epidemic

AI code generators (Cursor at 72% first-try compile rate, Copilot at 58%, Windsurf at 51%) frequently insert `.clone()` to satisfy the borrow checker rather than fixing ownership design. This is the **#1 performance anti-pattern** in AI-generated Rust. Fixes: accept `&str` instead of `String`, use `mem::take()` for owned values in enums, run `cargo clippy` which detects many unnecessary clones.

### Arc<Mutex<T>> and its alternatives

`Arc<Mutex<HashMap<K,V>>>` is "easy mode" concurrency but causes coarse-grained locking. Alternatives ranked by use case:

- **DashMap**: Sharded concurrent HashMap, allowing simultaneous access to different keys
- **parking_lot::Mutex**: Drop-in std replacement, **1.5-5x faster**, only 1 byte, no poisoning
- **tokio::sync::Mutex**: Required when holding locks across `.await` points (std guards aren't `Send`)
- **Channels (mpsc, crossbeam)**: Actor-like message passing, avoids shared state entirely
- **Atomics**: Lock-free counters and flags

**Critical async trap** (documented by fasterthanli.me): holding a `parking_lot::RwLock` guard in a `match` scrutinee persists the guard through the entire match arm, including `.await` points, causing subtle deadlocks. The `await_holding_lock` clippy lint helps detect this.

### Cow<'_, str> for conditional allocation

`Cow` (Clone-on-Write) is ideal when a function usually returns borrowed data but occasionally must allocate. The canonical example: string transformations that are usually no-ops:

```rust
fn remove_whitespace(input: &str) -> Cow<'_, str> {
    if input.contains(' ') {
        Cow::Owned(input.replace(' ', "")) // Allocates only when needed
    } else {
        Cow::Borrowed(input) // Zero allocation
    }
}
```

Use cases include `Path::to_string_lossy()`, HTML escaping, FFI boundaries, and zero-copy parsing/deserialization.

### Pin, Unpin, and self-referential structs

**Pin exists because async blocks compile into self-referential state machines.** If moved after polling, internal pointers become dangling. Most types auto-implement `Unpin` (safe to move even when pinned). Futures from async blocks are `!Unpin`. Use `pin-project` or `pin-project-lite` for field projection instead of manual unsafe. For self-referential structs, **ouroboros** (proc-macro) and **self_cell** (declarative macro, no proc-macro) are the two main solutions — both heap-allocate and pin the owner.

---

## 4. Testing: property-based, fuzzing, mutation, and benchmark infrastructure

### Property-based testing with proptest

Proptest generates random inputs via `Strategy` objects, tests that properties hold, and shrinks to minimal failing cases. Failed cases persist to `proptest-regressions/` for regression testing. Strategy composition is its key advantage over QuickCheck — you get per-value shrinking, regex-based generation, and unlimited strategies per type:

```rust
proptest! {
    #[test]
    fn roundtrip_parse(s in "[a-z]{1,10}") {
        let parsed = parse(&s);
        prop_assert_eq!(s, render(&parsed));
    }
}
```

### Fuzzing with cargo-fuzz

Built on LLVM's libFuzzer, `cargo-fuzz` requires nightly. Use the `Arbitrary` trait for structured fuzzing inputs. **Key flags**: `--sanitizer none` for 2x speedup when no unsafe code is present. For OSS-Fuzz integration, `--cfg fuzzing` is set automatically — use `#[cfg(not(fuzzing))]` to disable crypto verification during fuzzing.

### Mutation testing with cargo-mutants

cargo-mutants replaces function bodies with dummy returns (e.g., `fn foo() -> String` → `String::new()`) and checks if tests catch the mutation. **Missed mutants reveal test gaps**. Recent features (2024-2025) include `--in-diff` for PR-scoped mutation testing, `--sharding` for CI distribution, and Nextest support. It emits GitHub Actions annotations automatically.

### Benchmarking with Criterion

Criterion provides statistical benchmarking with bootstrap resampling, outlier detection, and regression comparison. **Critical CI note**: don't rely on Criterion in virtualized CI (GitHub Actions) — use **Iai** (Cachegrind-based instruction counting) for deterministic CI benchmarks.

### Test organization patterns

- **rstest** provides fixtures and parameterized tests with `#[fixture]`, `#[case]`, and `#[values]` for cartesian products
- **mockall** is the clear feature leader for mocking with argument matchers, sequencing, and static method support
- Integration tests go in `tests/` with shared utilities in `tests/common/mod.rs` (using `mod.rs` naming prevents Cargo from treating it as a test file)
- Use the **test builder pattern** (`TestApp::spawn()`) for complex integration test setup

---

## 5. Unsafe code: auditing, MIRI, and the verification stack

### Documentation contracts

The Rust standard library's Safety Comments Policy establishes two patterns. Unsafe **functions** document preconditions in a `# Safety` doc section. Unsafe **blocks** use `// SAFETY:` comments explaining why each invariant holds. Document: alignment requirements, validity of pointed-to data, provenance/aliasing guarantees, lifetime bounds, and type invariants (e.g., UTF-8 for `str`).

The `unsafe_op_in_unsafe_fn` lint (active in std) requires each unsafe operation inside an unsafe function to have its own `unsafe` block with its own SAFETY comment — dramatically improving auditability.

### Trail of Bits audit methodology

Trail of Bits approaches each `unsafe` block as a **contract boundary**, checking alignment, validity, provenance/aliasing, and lifetime invariants. Their open-source tools include **Siderophile** (finds highest-risk functions by callgraph analysis), **Dylint** (custom project-specific lints beyond Clippy), and **test-fuzz** (automated fuzzing harness generation). In their 47-engineer-week Arbitrum Stylus audit, they specifically flagged ownership issues around `ManuallyDrop` in FFI return types and recommended `repr(C)` for FFI-crossing types.

### The verification stack

| Tool | Catches | Speed | FFI |
|------|---------|-------|-----|
| **MIRI** | All de-facto UB in deterministic programs | 10-100x slower | No |
| **cargo-careful** | Alignment, zeroed/uninit panics, bounds | ~2-3x slower | Yes |
| **AddressSanitizer** | OOB, use-after-free, double-free | ~2x slower | Yes |
| **ThreadSanitizer** | Data races | ~5-15x slower | Yes |
| **Loom** | Exhaustive concurrency testing | Varies | No |
| **Kani** | Model checking / formal verification | Slow | Partial |

MIRI, described in Ralf Jung's 2026 POPL paper as "the first tool that can find all de-facto Undefined Behavior in deterministic Rust programs," detects Stacked/Tree Borrows violations, pointer provenance issues, invalid values, and data races. **cargo-careful** (also by Ralf Jung) is lighter-weight — it builds the standard library with debug assertions and is fully FFI-compatible. Use `#![forbid(unsafe_code)]` in application crates; isolate unsafe in dedicated, well-audited library crates. **cargo-geiger** scans the dependency tree for unsafe usage.

### Notable 2024-2025 vulnerabilities

**CVE-2025-68260** was the first CVE in Rust code in the Linux kernel (`rust_binder`). The **`cve-rs`** crate (RUSTSEC-2025-0028) demonstrated memory vulnerabilities in safe Rust by exploiting a known compiler soundness bug. Common RustSec advisory patterns include missing `Send`/`Sync` bounds enabling data races and incorrect lifetime bounds enabling use-after-free.

---

## 6. Performance: from release profiles to zero-copy parsing and PGO

### Release profile configuration

**Maximum performance:**
```toml
[profile.release]
opt-level = 3
lto = "fat"           # Full cross-crate LTO
codegen-units = 1     # Single codegen unit = best optimization
panic = "abort"       # No unwinding overhead
strip = true          # Remove symbols
```

**Minimum binary size** uses `opt-level = "z"` instead. The difference between `"fat"` and `"thin"` LTO is ~80% of the optimization benefit at ~50% of the build time. Setting `codegen-units = 1` (default is 16) allows maximum cross-module optimization at the cost of build parallelism. `panic = "abort"` eliminates unwind tables for a **5-10% binary size reduction** but disables `catch_unwind`.

### Profile-guided optimization delivers 10-20% improvement

PGO is underused but delivers significant wins for CPU-bound code. **`cargo-pgo`** simplifies the workflow:

```bash
cargo pgo build                    # Instrumented build
./target/.../myprogram workload    # Run representative workloads
cargo pgo optimize                 # Merges profiles + optimized build
```

For crypto and parser workloads, PGO combined with `RUSTFLAGS="-C target-cpu=native"` enables CPU-specific instructions (AVX2, etc.) and branch prediction optimization. BOLT (post-link optimization) can stack with PGO for additional gains.

### Zero-copy parsing and allocation-free hot paths

**winnow** (fork of nom, 0.7) and **nom** (7.1) return slices into original input buffers without allocation. winnow uses `Fn(&mut I) -> O` (mutable reference) vs nom's `Fn(I) -> (I, O)` — the mutable reference approach produces smaller `Result::Ok` values that fit in CPU registers.

For allocation-free hot paths: reuse buffers with `.clear()` between iterations, use `Vec::with_capacity()` for pre-allocation, pass `&mut Vec<u8>` instead of returning new allocations, and use **SmallVec** when most instances fit a known size but occasional overflow is acceptable. SmallVec adds branch overhead on `.push()`, so measure before adopting — the standard `Vec` with buffer reuse is often better.

### Profiling with flamegraph and DHAT

**cargo-flamegraph** uses perf (Linux) or DTrace (macOS). Requires `debug = true` in release profile for meaningful stack traces. Look for wide plateaus at the top of flamegraphs. **samply** provides an interactive UI via Firefox Profiler.

**dhat-rs** enables heap profiling with zero-allocation assertions in tests:

```rust
#[cfg(feature = "dhat-heap")]
#[global_allocator]
static ALLOC: dhat::Alloc = dhat::Alloc;
```

SIMD remains partially unstable: `std::simd` (portable_simd) requires nightly. On stable, use the `wide` crate or `pulp`/`macerator` for runtime dispatch. As of Rust 1.87, `std::arch` intrinsics are mostly safe.

---

## 7. How Cloudflare, Discord, Figma, AWS, and others run Rust in production

### Cloudflare's Pingora: 70% less CPU than NGINX

Pingora, open-sourced February 2024, handles **over 40 million requests per second** across Cloudflare's global network. It uses Rust's async multithreading (vs NGINX's multiprocess model) with shared connection pools via atomic reference counters. Results: **70% less CPU, 67% less memory**, 80ms TTFB reduction, and connection reuse improved from 87.1% to **99.92%** for a major customer. Their `trie-hard` crate optimized a hot-path header-clearing function from 3.65µs to 0.93µs, freeing over 500 CPU cores.

### Discord: eliminating GC latency spikes

Discord rewrote their Read States service from Go to Rust, eliminating **periodic latency spikes every ~2 minutes** caused by Go's garbage collector scanning millions of LRU cache entries. The Rust version immediately matched Go's baseline, then after profiling beat Go on every metric. Key insight: Rust's ownership model freed memory immediately on LRU eviction vs waiting for GC. They switched from HashMap to BTreeMap for better cache behavior.

### AWS Firecracker: <125ms microVM boot in 50K lines of Rust

Firecracker powers AWS Lambda and Fargate, handling **trillions of Lambda executions monthly**. It achieves <125ms boot time and <5 MiB memory per microVM with a minimalist device model (only 5-6 emulated devices vs QEMU's hundreds). The entire VMM is ~50,000 lines of Rust — a **96% code reduction** vs QEMU. Rust was chosen for thread and memory safety in a security-critical context. This is directly relevant to Firecracker VM management workloads.

### Figma: order-of-magnitude improvement in multiplayer

Figma rewrote their multiplayer server from TypeScript to Rust, achieving **10x server-side editing performance improvement**. They hit GC-related latency spikes identical to Discord's experience. Recent 2024 optimizations used pointer stuffing (embedding field IDs in unused pointer bits) for **20% faster deserialization** and **20% memory savings**.

### 1Password: 63% Rust shared core across every platform

1Password uses Rust as a cross-platform shared core compiling to native binaries (ARM, x86-64) and WebAssembly. About **63% of the 1Password core** is Rust. They created open-source crates including **typeshare** (type generation across Rust/Swift/Kotlin/TypeScript), **passkey-rs** (WebAuthn), and **zeroizing-alloc** (secure heap zeroing). Windows crashes "quickly fell" after Rust adoption.

### Google Android: 1000x reduction in memory-safety vulnerability density

Memory safety vulnerabilities in Android dropped from **223 in 2019 to <50 in 2024**. Rust code has a **1000x lower memory-safety vulnerability density** than C/C++. Rust changes have **4x lower rollback rate** and **25% less time in code review** than C++. Android now has **5 million lines of Rust** with approximately one near-memory-safety issue.

---

## 8. Cross-compilation: musl, containers, and cargo-chef layer caching

### Static binaries with musl

musl produces fully statically-linked binaries with zero dynamic dependencies — ideal for scratch/distroless containers. The musl default allocator is significantly **slower in multi-threaded contexts**; fix by using mimalloc or jemalloc as a global allocator. OpenSSL doesn't static-link easily with musl — prefer rustls via Cargo features.

```bash
rustup target add x86_64-unknown-linux-musl
cargo build --release --target x86_64-unknown-linux-musl
```

For cross-architecture builds, the **`cross`** tool (drop-in Cargo replacement using Docker containers with pre-installed toolchains) supports dozens of targets. **`cargo-zigbuild`** uses Zig's bundled C compiler as a simpler alternative for basic cross-compilation.

### Container images: distroless over scratch

| Image | Size | Recommendation |
|-------|------|----------------|
| `scratch` | 0 MB | Missing CA certs and tzdata |
| `gcr.io/distroless/static-debian12` | ~2 MB | **Recommended** — includes CA certs, tzdata, non-root user |
| `alpine:3.19` | ~7 MB | When you need a shell for debugging |
| `gcr.io/distroless/cc-debian12` | ~20 MB | For dynamically-linked binaries |

### cargo-chef eliminates dependency rebuild pain

cargo-chef separates dependency compilation from source compilation. The `recipe.json` only changes when `Cargo.toml`/`Cargo.lock` change, enabling Docker layer caching of dependency builds. **Up to 5x speedup** on commercial codebases (~14k lines, ~500 deps: Docker builds from ~10min to ~2min):

```dockerfile
FROM lukemathwalker/cargo-chef:latest-rust-1 AS chef
WORKDIR /app

FROM chef AS planner
COPY . .
RUN cargo chef prepare --recipe-path recipe.json

FROM chef AS builder
COPY --from=planner /app/recipe.json recipe.json
RUN cargo chef cook --release --recipe-path recipe.json  # Cached layer!
COPY . .
RUN cargo build --release --bin app

FROM gcr.io/distroless/static-debian12:nonroot
COPY --from=builder /app/target/release/app /
ENTRYPOINT ["/app"]
```

---

## 9. Cargo workspace patterns for monorepo management

### Workspace dependency inheritance

Stabilized in Rust 1.64, workspace dependency inheritance centralizes versions in root `Cargo.toml`. Members use `{ workspace = true }` and can **add** features but cannot remove workspace-defined features. **`cargo-autoinherit`** (Mainmatter, March 2024) can automatically migrate existing workspaces.

```toml
# Root Cargo.toml
[workspace.dependencies]
serde = { version = "1.0", features = ["derive"] }
tokio = { version = "1", features = ["full"] }

# Member Cargo.toml
[dependencies]
serde = { workspace = true }
tokio = { workspace = true }
sqlx = { workspace = true, features = ["migrate"] }  # Adds features
```

### Feature unification and the hakari solution

Cargo **unifies features** across workspace members during builds. If crate A enables `serde/derive` and crate B uses `serde` without it, both get `derive` during workspace builds — masking missing declarations. **cargo-hakari** solves the related recompilation problem by creating a workspace-hack crate that depends on the union of all feature sets, preventing feature-set-mismatch rebuilds. On moderately large workspaces, individual commands become **1.1x to 100x faster**.

### Workspace-level lints

Stable since Rust 1.74, `[workspace.lints]` centralizes lint configuration. Use the `priority` field when overriding group lints:

```toml
[workspace.lints.clippy]
pedantic = { level = "warn", priority = -1 }
all = { level = "warn", priority = -1 }
unwrap_used = "deny"
module_name_repetitions = "allow"  # Override pedantic
```

Members opt in with `[lints] workspace = true`.

### Build time optimization

Use **mold** linker on Linux (2-5x faster linking), optimize dependencies even in dev (`[profile.dev.package."*"] opt-level = 2`), use **sccache** for shared compilation cache, and minimize crate graph depth for better parallelization. Set `incremental = true` for dev builds.

---

## 10. AI rules files, Clippy configuration, and anti-patterns for production Rust

### Community CLAUDE.md and AGENTS.md templates

Several high-quality community templates encode Rust best practices for AI code generation:

- **minimaxir/CLAUDE.md** (127 stars): Specifies `axum` for HTTP, `thiserror` for errors, `tokio::task::spawn_blocking` for CPU-bound work, 100-char line limit, and never `.unwrap()` in library code
- **actionbook/rust-skills** (768 stars): Meta-routing system through skill files covering ownership, concurrency, etc. Default config: `edition = "2024"`, `clippy::all` and `clippy::pedantic` at warn level
- **openai/codex AGENTS.md** (67.8k stars): Enforces `collapsible_if`, `uninlined_format_args`, `redundant_closure_for_method_calls`. **Explicitly warns against boolean parameters** — prefer enums and named methods
- **rust-lang/crates.io AGENTS.md**: Uses `#[expect(...)]` over `#[allow(...)]`, `cargo insta accept` for snapshot tests
- **tyrchen/cursor-rust-rules**: Most comprehensive Cursor rules collection with modular architecture covering axum, SQLx, concurrency, observability, CLI, and DDD patterns

### Production Clippy configuration

**clippy::pedantic** is production-ready — Clippy itself is linted with it. Expect to use `#[allow(..)]` for false positives. **clippy::nursery** should be cherry-picked. **clippy::restriction should NEVER be enabled as a group** — lints contradict each other. Cherry-pick restriction lints that add value:

```toml
[workspace.lints.clippy]
pedantic = { level = "warn", priority = -1 }
all = { level = "warn", priority = -1 }

# Pedantic lints to disable (commonly too noisy)
module_name_repetitions = "allow"
must_use_candidate = "allow"
missing_errors_doc = "allow"

# Restriction lints worth enabling
unwrap_used = "warn"
todo = "warn"
dbg_macro = "warn"
print_stdout = "warn"        # Use tracing/log instead
print_stderr = "warn"
unimplemented = "warn"
```

Configure `clippy.toml` at project root for thresholds: `cognitive-complexity-threshold = 30`, `msrv = "1.75"`, `avoid-breaking-exported-api = false`.

### Critical anti-patterns to encode in rules files

**Performance killers**: excessive `.clone()` (the #1 issue), blocking I/O in async code, locking mutexes too broadly, collecting iterators into `Vec` unnecessarily.

**Error handling mistakes**: `.unwrap()` in production paths (use `?` operator), `From` when you need `TryFrom`, swallowing errors with `_ => {}` catch-all arms, using `anyhow` in library code.

**API design smells**: boolean parameters ("boolean blindness" — use enums instead), `..Default::default()` hiding new fields silently, accepting `String` when `&str` suffices, more than 5 function parameters without a config struct.

**Defensive patterns** (from corrode.dev): use slice pattern matching instead of index access (`match users.as_slice() { [] => ..., [user] => ... }`), destructure structs in trait impls to get compiler errors on new fields, use temporary mutability (`let mut x = ...; x.sort(); let x = x;`).

---

## Conclusion: key principles for production Rust alongside Go services

The overarching lesson from every production Rust deployment is that **Rust's compile-time guarantees convert runtime errors into build failures** — but only if you lean into the type system rather than fighting it with clones, unwraps, and Arc<Mutex<T>>. For engineers building performance-critical parsers, crypto systems, and VM management alongside Go services, the highest-leverage patterns are:

**Start small and measure**. Target hot paths — isolated, performance-critical components where Rust's zero-cost abstractions and lack of GC deliver the greatest ROI. Discord's Read States, Figma's multiplayer, and Cloudflare's Pingora all validate this approach.

**Invest in the verification stack**. Run MIRI and cargo-careful in CI for any crate containing unsafe code. Use `#![forbid(unsafe_code)]` in application crates. Run cargo-audit and cargo-geiger regularly. For parser and crypto workloads specifically, cargo-fuzz with structured inputs via `Arbitrary` catches edge cases that unit tests miss.

**Treat cancellation safety as a first-class concern**. In async code, every `.await` point is a potential cancellation site. Audit every future used in `tokio::select!` for cancel safety. Prefer `TaskTracker + CancellationToken` for graceful shutdown patterns.

**Optimize the build-deploy pipeline early**. Use cargo-chef for Docker layer caching, mold linker for development builds, workspace dependency inheritance for version consistency, and cargo-hakari for large workspaces. Target musl for distroless containers. These investments compound across every development cycle and CI run.

**Encode standards in machine-readable rules**. CLAUDE.md, AGENTS.md, and .cursorrules files prevent AI code generators from producing the most common anti-patterns — unnecessary clones, unwraps in library code, boolean parameters, blocking I/O in async contexts. The best Rust teams make their standards executable through workspace-level Clippy lints, `#[expect(...)]` over `#[allow(...)]`, and CI that runs `cargo clippy --workspace --all-targets -- -D warnings`.