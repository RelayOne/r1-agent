# Authentication and authorization for production multi-tenant SaaS

**Every serious SaaS breach traces back to the same root causes: misconfigured OAuth flows, overprivileged tokens, missing authorization checks, or leaked API keys.** This guide covers the full spectrum of identity and access management — from OAuth token refresh race conditions to Zanzibar-style authorization, from passkey adoption to CI/CD enforcement — with concrete patterns for multi-tenant production systems. The landscape shifted significantly in 2025–2026: OAuth 2.1 and RFC 9700 formalized long-overdue security requirements, passkeys crossed mainstream adoption thresholds, and the TypeScript auth ecosystem consolidated around Better Auth after Auth.js and Lucia both exited active development.

---

## 1. OAuth 2.0 and OIDC will bite you in production

The OAuth specification is deceptively simple. Production deployments expose edge cases that the RFCs mention only in passing — race conditions, revocation gaps, and redirect validation failures that have caused real breaches at scale.

### Token refresh race conditions

When two browser tabs detect an expired access token simultaneously, both attempt to use the same refresh token. With rotation enabled, the first request succeeds and invalidates the old refresh token. The second tab's request then fails — and if reuse detection is strict, the authorization server interprets this as potential theft and **revokes the entire token family**, logging out the legitimate user.

The solution is a **refresh token grace period** (typically 30 seconds) during which a recently-rotated refresh token can still be reused without triggering theft detection. Auth0's refresh token family model groups all descended tokens together; any reuse of an old token outside the grace window revokes all tokens in the family. Client-side, implement a mutex/lock so only one tab performs the refresh at a time — other tabs queue behind it and receive the new token. Proactive background refresh at 80% of the access token TTL further reduces collision probability.

### PKCE, state, and redirect_uri

**PKCE is now mandatory for all clients.** RFC 9700 (January 2025) strongly recommends it, and the OAuth 2.1 draft requires authorization servers to reject requests missing a `code_challenge`. Without PKCE, authorization codes traveling through the front channel can be captured via Referer headers, browser history, or malicious extensions — even with TLS. The `state` parameter remains essential for CSRF prevention: generate a cryptographically random value bound to the session, and reject callbacks where it's missing or mismatched.

Redirect URI validation demands **exact string matching only** — OAuth 2.1 mandates this. Wildcard or pattern-based redirect URIs have caused real breaches: Secureworks discovered Azure multi-tenant apps with redirect URIs pointing to unregistered subdomains that attackers could claim, stealing authorization codes. Keycloak's CVE-2023-6927 allowed wildcard URI bypass via path confusion. Research in 2023 found that 6 of 16 major identity providers were vulnerable to path confusion in redirect validation.

### Token revocation propagation

The fundamental problem: **JWTs are stateless, so they remain valid until expiration regardless of revocation**. Short-lived access tokens (5–15 minutes per RFC 9700) limit the damage window. For critical operations, add token introspection (RFC 7662) as a real-time check. Microsoft's Continuous Access Evaluation pushes revocation events to resource servers for near-instant invalidation. The hybrid approach — short JWTs for most requests, introspection for sensitive operations — balances performance and security.

**Common pitfalls that cause incidents:** storing tokens in localStorage (any XSS exfiltrates them), not validating `iss` and `aud` claims (enables cross-tenant token confusion), using ID tokens as access tokens (skips audience validation), and continuing to use the deprecated implicit flow (tokens in URL fragments leak via browser history and Referer headers).

---

## 2. JWTs are not a silver bullet

### Opaque tokens externally, JWTs internally

The **Phantom Token pattern** gives you the best of both worlds. Issue opaque tokens to clients — they can be revoked instantly and reveal no PII. At the API gateway, introspect the opaque token to receive a JWT, then forward it to internal microservices for stateless validation. Curity publishes NGINX and Kong plugins for this. The gateway can cache the JWT keyed by opaque token hash, eliminating repeated introspection calls.

For algorithm selection, **ES256 (ECDSA P-256) is the recommended default** for new systems. Its 64-byte signatures are 4× smaller than RS256's 256-byte signatures, reducing token bloat. EdDSA (Ed25519) offers even faster signing — 62× faster than RSA-2048 — but has narrower HSM support. **Never use HS256 in multi-party scenarios**: the same key signs and verifies, meaning any service that validates tokens can also forge them. The algorithm confusion attack (changing `alg` from RS256 to HS256 and signing with the public key) has compromised multiple JWT libraries. Always whitelist allowed algorithms in verification code.

### Size budgets and key rotation

JWT size bloat is a real operational problem. Embedding extensive role arrays, group memberships, or tenant metadata pushes tokens past HTTP header limits (nginx defaults to ~8KB). Hasura users experienced connection failures with JWTs around 3.6KB. **Set a hard size budget of 2KB** — include only `sub`, `iss`, `aud`, `exp`, `iat`, `jti`, `scope`, and `tenant_id`. Look up rich authorization data server-side using the `sub` claim.

Key rotation requires overlapping validity windows. Publish the new public key in the JWKS endpoint alongside the old key, activate it for signing, and remove the old key only after `retirement_time + max_token_lifespan + safety_buffer`. Every JWT must carry a `kid` header so validators select the correct key. Cache JWKS responses with jitter on refresh intervals, use single-flight/mutex patterns to prevent stampedes, and maintain a last-known-good JWKS in persistent storage for resilience when the endpoint is down.

### Where tokens live

For web SPAs, the **Backend-for-Frontend (BFF) pattern** is the IETF's recommended highest-security architecture. The BFF handles all OAuth interactions as a confidential client, stores tokens server-side, and issues HttpOnly/Secure/SameSite=Strict session cookies to the browser. Tokens never reach JavaScript. For mobile apps, use Authorization headers with tokens in platform-native secure storage (iOS Keychain, Android Keystore), and consider DPoP (RFC 9449) to bind tokens cryptographically to the device.

---

## 3. Sessions are simpler than tokens — until they aren't

**Always regenerate the session ID after authentication.** Session fixation attacks exploit the gap between anonymous and authenticated sessions — an attacker sets a known session ID, the victim authenticates, and the attacker inherits the authenticated session. Every major framework provides regeneration: `req.session.regenerate()` in Express, `session_regenerate_id(true)` in PHP, `request.session.cycle_key()` in Django.

For multi-tenant SaaS, **Redis is the optimal session store**: sub-millisecond reads, native TTL support via `EXPIRE`, and straightforward clustering. Benchmarks show 3–10× faster session reads than PostgreSQL at 10K concurrent users. Encrypted cookies eliminate server storage but cannot be revoked without a blocklist and are limited to ~4KB. Use the `__Host-` cookie prefix for shared-domain multi-tenant deployments — it forbids the `Domain` attribute, ensuring cookies are scoped to the exact host and preventing a compromised tenant subdomain from reading another tenant's cookies.

Session revocation propagation creates a tension between performance and security. The recommended pattern: **short-lived access tokens (5–15 minutes) verified locally, long-lived refresh tokens validated server-side**. Invalidating the refresh token takes effect within one access token lifetime. For detected breaches requiring instant revocation, maintain a lightweight Redis blocklist checked only for high-privilege operations.

Build a session management UI showing device type (parsed from User-Agent), IP address, approximate location via GeoIP, and last-active timestamp — following the patterns GitHub and Google have established. Concurrent session limits should be configurable per tenant, defaulting to 3–5 active sessions with oldest-session eviction on new login.

---

## 4. MFA has evolved beyond one-time codes

### Passkeys are production-ready

The numbers are definitive: **Google reports 800M+ accounts using passkeys with 2.5B+ sign-ins**, Amazon has 175M+ customers with passkeys enabled (described as "6× faster than passwords"), and the FIDO Alliance reports 15B+ online accounts can leverage passkeys. BankID Norway moved half the Norwegian population to passkeys through silent app updates.

Passkeys eliminate entire attack categories. Domain-bound signatures prevent real-time phishing proxies like Evilginx. No shared secret crosses the wire — the private key stays in the device's secure enclave. Synced passkeys (via iCloud Keychain, Google Password Manager, or third-party managers like 1Password) achieve AAL2 under **NIST SP 800-63-4** (finalized July 2025). The FIDO Credential Exchange Format enables secure passkey export/import between providers, addressing vendor lock-in concerns.

### TOTP and SMS in context

TOTP (RFC 6238) remains widely deployed but requires careful implementation. **Rate-limit attempts to 3–5 per 30-second window** — the 6-digit code space (1M possibilities) is brute-forceable without limits. Enforce one-time use per time window, tolerate ±1 time step for clock drift, and stick to SHA-1/6-digit/30-second defaults for authenticator app compatibility.

SMS MFA is now formally classified as a **"restricted authenticator"** by NIST SP 800-63-4 — the only method in this explicit restricted category. SIM swapping succeeds in 80% of attempts (Group-IB data), SS7 protocol vulnerabilities enable SMS interception across telecom networks, and real-time phishing proxies capture codes instantly. Microsoft's Director of Identity Security stated SMS blocks only 76% of targeted attacks versus 100% for hardware keys. Offer SMS only as a transitional fallback while migrating users to phishing-resistant methods.

### MFA fatigue is a solved problem

After the 2022 Uber breach (Lapsus$ used MFA fatigue against a contractor), the industry converged on **number matching** — users must enter a 2-digit number from the login screen into their authenticator app. Microsoft's data shows number matching plus contextual information **eliminated MFA fatigue attacks entirely** in live customer environments. It's now mandatory for Microsoft Entra, Okta, and Duo.

For multi-tenant SaaS, make MFA policies configurable per tenant. Provide a 7–14 day grace period for existing users when a tenant admin enables MFA, with no grace period for new users. Maintain break-glass emergency access accounts excluded from MFA policies but heavily monitored. Service accounts that cannot perform interactive MFA should use client credentials flow, mTLS, or API keys with compensating controls.

---

## 5. Service-to-service auth in a multi-cloud world

### mTLS and workload identity

Service meshes have made mTLS nearly free to deploy. Istio automatically provisions and rotates X.509 certificates with configurable TTL (default 24 hours). Benchmarks show baseline mTLS adds only **~3% latency at p99** — the performance concern is largely a myth at this point. Istio's Ambient Mesh mode (sidecar-less, using per-node ztunnel agents) reduces resource overhead by up to 92% compared to traditional sidecars.

All three major clouds now provide **workload identity** that eliminates long-lived credentials:

- **GCP Workload Identity Federation** exchanges external OIDC/SAML tokens for short-lived GCP tokens via STS. GCP is aggressively disabling long-lived service account keys via organization policy constraints.
- **AWS EKS Pod Identity** (replacing IRSA) eliminates per-cluster OIDC provider setup and IAM trust policy size limits. IAM Roles Anywhere extends this to on-premises workloads.
- **Azure AD Workload Identity for AKS** uses federated identity credentials on Azure AD app registrations to trust Kubernetes ServiceAccount tokens.

For cross-cloud authentication, configure each cloud's STS to trust the other's OIDC provider. A GKE pod can obtain a GCP OIDC JWT, present it to AWS STS via `AssumeRoleWithWebIdentity`, and receive temporary AWS credentials — all without any long-lived secrets.

### SPIFFE/SPIRE for vendor neutrality

SPIFFE (a CNCF graduated project) provides platform-agnostic workload identity via URIs like `spiffe://trust-domain/path`. SPIRE agents perform node and workload attestation, issuing short-lived X.509-SVIDs (default 1-hour TTL) for mTLS. A financial services company with 200+ microservices on AKS reported reducing security incidents from 3–4 per quarter to near-zero after SPIFFE/SPIRE deployment. Trust domains can federate across organizations without sharing keys.

---

## 6. Authorization requires the right model for your complexity

### Start with RBAC, add ReBAC when sharing matters

**RBAC** is the correct starting point for multi-tenant SaaS: users get tenant-scoped roles (Owner, Admin, Editor, Viewer). But RBAC breaks down when users need to share individual resources — "role explosion" creates unmaintainable hierarchies like `editor-region-eu-dept-marketing-project-alpha`.

**ReBAC** (Relationship-Based Access Control) models permissions as graph relationships: `user:alice → owner → document:doc1`. Authorization becomes a graph traversal question. Google's Zanzibar system handles **10M+ checks per second at <10ms p95** with 2+ trillion ACLs. OWASP now recommends ReBAC as the method for building correct authorization systems — Broken Access Control is their #1 vulnerability.

**SpiceDB** (by AuthZed) is the most mature open-source Zanzibar implementation, achieving **5ms p95 latency** and used by OpenAI and Workday. Its caveated relationships combine ReBAC with ABAC conditions. **OpenFGA** (Auth0/Okta, CNCF Incubating) offers a developer-friendly alternative with strong momentum. For AWS-centric architectures, **Cedar** — Amazon's policy language with formal verification — benchmarks at **42–60× faster than Rego** with sub-millisecond evaluation.

### The new enemy problem

When Alice removes Bob from a document and then adds sensitive content, stale cached permissions could still grant Bob access. Zanzibar solves this with **zookies** (consistency tokens): every permission write returns a token encoding a global timestamp, which subsequent checks include to guarantee they reflect all permission changes up to that point. SpiceDB implements this as ZedTokens. This is a security property, not just a performance optimization — any authorization system without a consistency model is vulnerable.

For **OPA** (CNCF graduated, used by 50%+ of Fortune 100): deploy as a sidecar for sub-millisecond evaluation with ~50MB footprint. Use bundle-based policy distribution via signed tar archives from S3/GCS. OPA Gatekeeper handles Kubernetes admission control with ConstraintTemplate patterns. The tradeoff: Rego is more expressive but error-prone; Cedar is safer but less flexible.

**The recommended layered approach**: RBAC for basic tenant access → ReBAC (SpiceDB/OpenFGA) for resource sharing → ABAC/OPA for contextual constraints (time, location, device trust, data classification).

---

## 7. API key management follows the Stripe playbook

Generate API keys with **at least 256 bits of entropy** using `crypto.randomBytes(32)` (Node.js) or `secrets.token_urlsafe(32)` (Python). Never use `Math.random()` — it's not cryptographically secure.

**Hash with SHA-256, not bcrypt.** API keys already have sufficient entropy (256 bits of randomness), making brute-force infeasible regardless of hash speed. Bcrypt's deliberate slowness becomes a CPU bottleneck at scale. Show the raw key exactly once at creation, store only the hash, and maintain a non-secret prefix for identification.

Adopt Stripe's prefix convention: `sk_live_` for production secret keys, `sk_test_` for test keys, `pk_live_` for publishable keys. Prefixes enable instant identification in logs and error messages, power secret scanning regex patterns, route test vs. production traffic, and trigger pre-commit hook rejections. GitHub's secret scanning program detects leaked keys by prefix pattern.

For **rotation without downtime**, support multiple active keys simultaneously with a 7–30 day grace period. AWS allows two active access keys per IAM user specifically for this purpose. GitHub fine-grained PATs support mandatory expiration with organization-configurable maximum lifetime policies.

Implement **per-key rate limiting** using the sliding window counter algorithm (best accuracy-to-memory ratio) with Redis as the centralized state store. Wrap read-check-update operations in Lua scripts for atomicity. Return standard headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`, and `Retry-After` with 429 responses. Never transmit keys in query parameters — they appear in server logs, browser history, and proxy logs.

---

## 8. Impersonation and delegation are not the same thing

RFC 8693 defines the critical distinction. **Impersonation** means Service A acts AS User B — the resulting token is indistinguishable from a normal user token, with no `act` claim. **Delegation** means Service A acts ON BEHALF of User B — both identities are present via the `act` claim, creating a proper audit trail.

For multi-tenant SaaS support workflows, delegation is almost always correct. Every action during impersonation **must** log both the admin identity and the impersonated user, with timestamp, action, and IP address. Display a prominent colored banner ("You are viewing as [user]") with one-click revert. Zendesk's implementation prevents admins from assuming the identity of administrators or supervisors — only downward impersonation is allowed.

The **confused deputy problem** arises when a service with delegated authority cannot distinguish between legitimate and attacker-initiated requests. AWS's ExternalId parameter in cross-account role assumption specifically prevents this: each customer includes a unique identifier in the trust policy that the SaaS vendor must provide when assuming the role. Microsoft's On-Behalf-Of flow propagates user identity through service chains using `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer`, ensuring downstream services always know who initiated the request.

For JWT-based impersonation, use the `act` claim: `{"sub": "user123", "act": {"sub": "admin456"}}`. Issue short-lived tokens (1 hour maximum, preferably shorter) that auto-expire. Never allow impersonation to grant capabilities beyond what the target user has — use the intersection of both permission sets, not the union.

---

## 9. The TypeScript auth ecosystem consolidated in 2025

The auth library landscape shifted dramatically. **Lucia Auth was deprecated in March 2025** — its creator concluded the database adapter model was fundamentally limiting, making everything "clunky and fragile." The lucia-auth.com site now serves only as a learning resource for implementing sessions from scratch. **Auth.js (NextAuth) was absorbed by Better Auth in September 2025** after its main contributor quit in January 2025 and v5 spent 3+ years in beta without reaching a stable release. The authjs.dev site now shows "© Better Auth Inc."

**Better Auth** has emerged as the dominant open-source option with **27,600+ GitHub stars**, $5M in funding from Peak XV and Y Combinator, and support for 20+ frameworks. It provides first-class multi-tenant support via its organization plugin (roles, invitations, member management), SSO (SAML + OIDC), TOTP, passkeys, and API keys — all via a modular plugin system. It stores data in your database with Prisma, Drizzle, or Kysely integration. The tradeoff: it's younger and less battle-tested at massive scale than commercial solutions, and CVE-2025-61928 (severity 9.3, unauthenticated API key creation) was a serious early vulnerability, fixed in v1.3.26+.

**Clerk** provides the fastest time-to-production with pre-built React components (`<SignIn>`, `<OrganizationSwitcher>`, etc.) and deep Next.js integration — Vercel's official templates all use Clerk. Pricing starts free for 50,000 monthly retained users, then $0.02/MRU on the $25/month Pro plan. The enhanced B2B add-on ($100/month) unlocks unlimited organization members and enterprise SSO linking. Limitations include vendor lock-in (migrating away takes an estimated 40–80 developer hours), SAML-only enterprise SSO (no OIDC), no SCIM provisioning, and audit logs still listed as "Coming Soon."

**WorkOS** targets enterprise B2B SaaS with best-in-class SSO, SCIM, directory sync, and an Admin Portal for self-serve customer onboarding. Its **1M free MAUs** (100× Clerk's free tier) lets you scale without auth costs. Enterprise SSO costs $125/connection/month with volume discounts. At **$30M ARR** with 1,000+ customers, it's proven at scale. The limitation: SSO connection pricing can exceed the cost of lower-tier SaaS plans, and it's US-only for data residency.

| Scenario | Recommendation |
|----------|---------------|
| Early-stage startup, own your data | **Better Auth** (free, self-hosted, TypeScript-first) |
| Rapid prototyping with Next.js | **Clerk** (pre-built UI, fastest integration) |
| Enterprise B2B selling to companies requiring SSO/SCIM | **WorkOS** (Admin Portal, directory sync, 1M free MAUs) |
| Growth-stage needing cost predictability | **Better Auth + Infrastructure tier** (no per-MAU costs) |

---

## 10. Encoding auth enforcement into your development workflow

### SKILL.md and AI agent rules

SKILL.md (published by Anthropic at agentskills.io, December 2025) is an open standard for encoding development patterns into AI coding assistants. It works across Claude Code, OpenAI Codex, and GitHub Copilot. Sentry's production security review SKILL.md routes to reference files for authorization, authentication, CSRF, and injection patterns — reporting only high-confidence exploitable findings.

The universal auth rules encoded across all platforms: always check authentication before authorization, never trust client-side auth state, validate JWT signatures with explicit algorithm whitelists, default deny (require explicit `AllowAnonymous`), store passwords with bcrypt/Argon2, use HttpOnly/Secure/SameSite cookies, and set security headers (HSTS, CSP, X-Frame-Options). Place these rules in `.claude/skills/` for Claude Code, `.cursor/rules/` for Cursor, and `.github/copilot-instructions.md` for Copilot.

### CI/CD enforcement pipeline

A production auth enforcement pipeline layers four tools:

- **Semgrep** for static analysis: detect routes missing auth decorators, hardcoded credentials, and JWT validation bypass patterns. Its AI mode can identify complex business logic flaws like IDORs by enumerating routes and checking for missing safeguards. Run in `semgrep ci` mode for diff-aware PR scanning.
- **TruffleHog + Gitleaks** for secret scanning: TruffleHog validates whether detected secrets are live (800+ secret types), while Gitleaks provides fast pre-commit hooks. Start in `allow_failure` mode, tune rules, then enforce. Via Transportation's pattern: automated Slack alerts to the developer who committed the secret, with monthly audits of `gitleaks:allow` exceptions.
- **Checkov/tfsec** for infrastructure-as-code: catch overly permissive IAM policies, unencrypted storage, and public access to private resources in Terraform/CloudFormation before deployment.
- **OWASP ZAP** for DAST: API scanning against OpenAPI specs in staging detects authentication bypasses, missing security headers, and injection vulnerabilities.

### The default-deny architecture pattern

The most impactful engineering pattern is **deny by default at the framework level**. FastEndpoints (.NET) exemplifies this: endpoints are secure by default, requiring explicit `AllowAnonymous()` to permit unauthenticated access. Implement this in Express with global auth middleware and an explicit allowlist of public endpoints. In Next.js, use `middleware.ts` with route matching. Write a Semgrep rule that flags any new route handler missing an auth decorator — this catches the most common authorization vulnerability (OWASP #1: Broken Access Control) at the PR level.

Complement this with **automated permission matrix testing**: for each role × each endpoint, assert the expected HTTP status code. Run these tests on every PR. Add nightly DAST scans against staging and continuous monitoring for auth anomalies — failed login spikes, tokens used from impossible-travel IP addresses, and concurrent sessions from geographically distant locations.

---

## Conclusion

The central insight across all ten domains is that **auth failures are architectural, not implementational**. Token refresh race conditions aren't fixed by better code — they require grace periods in the authorization server. JWT revocation isn't solved by shorter TTLs alone — it requires the Phantom Token pattern or a hybrid introspection approach. Authorization at scale isn't achieved by sprinkling `if` statements through application code — it requires a dedicated policy engine with a consistency model.

For multi-tenant SaaS in 2026, the recommended architecture stack is: **Better Auth or WorkOS** for identity (depending on self-hosted vs. managed preference), the **BFF pattern** for web clients, **short-lived JWTs with ES256 signatures** for access tokens, **Redis-backed sessions** with `__Host-` prefixed cookies, **passkeys as the primary MFA** with TOTP as fallback, **SpiceDB or OpenFGA** for relationship-based authorization layered over tenant-scoped RBAC, **workload identity federation** for service-to-service auth (no long-lived keys), **SHA-256-hashed API keys** with Stripe-style prefixes, and **Semgrep + TruffleHog + OWASP ZAP** in CI/CD with deny-by-default middleware enforced via SKILL.md rules. The new enemy problem, the confused deputy problem, and MFA fatigue are all solved problems — but only if you implement the solutions deliberately.