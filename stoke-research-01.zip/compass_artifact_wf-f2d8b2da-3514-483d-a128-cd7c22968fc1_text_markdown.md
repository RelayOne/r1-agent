# Building NitroGraph on Hedera: A complete DLT infrastructure guide

**Hedera Hashgraph offers the most enterprise-ready foundation for an AI agent commerce protocol like NitroGraph, combining deterministic 3–5 second finality, fixed USD-denominated fees (~$0.0001 per transfer), and native protocol-level services that eliminate smart contract overhead for core token and messaging operations.** This matters because AI agents executing autonomous commerce need predictable costs, guaranteed ordering, and compliance-ready infrastructure — properties uniquely bundled in Hedera's architecture. The network processes over 70 billion cumulative transactions with a 31+ member Governing Council of Fortune 500 companies running consensus nodes, and HBAR earned formal digital commodity classification from the SEC and CFTC in March 2026. What follows is a deep technical guide across all ten dimensions needed to architect NitroGraph on Hedera.

---

## 1. Hedera's native service primitives eliminate smart contract complexity

Unlike Ethereum-family chains where every token operation requires deploying and auditing smart contracts, Hedera provides **three native protocol-level services** that NitroGraph can leverage directly.

### Hashgraph Consensus Service (HCS)

HCS functions as a decentralized, aBFT-secured message bus — effectively a **"decentralized Kafka"** providing tamper-proof timestamps and ordering without storing application data on-chain. Each HCS topic accepts messages up to **1,024 bytes**, assigns a consensus timestamp and monotonically increasing sequence number, and produces a running hash of all prior messages. Topics can be public (anyone submits) or private (requiring a submit key signature). HIP-991 (2024–2025) added custom fees to topics, enabling topic creators to charge per-message in HBAR or HTS tokens.

For NitroGraph, HCS provides the **agent message ordering backbone** — every agent interaction, service request, bid, and fulfillment can be published to dedicated topics, receiving a fair, consensus-ordered timestamp with no MEV risk. The fee is **$0.0008 per message** (increased from $0.0001 in January 2026), making high-volume agent-to-agent messaging economically viable.

### Hashgraph Token Service (HTS)

HTS creates and manages tokens at the protocol level with **seven configurable keys** that provide granular compliance control:

- **Admin Key** — update or delete the token; can modify other keys
- **Supply Key** — mint and burn tokens (required for supply changes)
- **Freeze Key** — freeze/unfreeze specific accounts from transacting
- **Wipe Key** — clawback tokens from accounts (for fraud recovery, court orders)
- **KYC Key** — grant or revoke KYC status, controlling who can hold the token
- **Pause Key** — halt all operations for the token globally
- **Fee Schedule Key** — modify custom fee schedules post-creation

Token creation costs **$1.00** ($2.00 with custom fees). Transfers cost **$0.001**, minting fungible tokens costs $0.001, and NFT minting costs $0.02 per serial. Up to **10 custom fees** can be attached per token — fixed fees (flat amount per transfer), fractional fees (percentage of transferred amount for fungible tokens), and royalty fees (percentage of exchanged value for NFTs with a fallback fixed fee).

### Smart contracts, scheduled transactions, and HBAR transfers

Hedera runs the **Hyperledger Besu EVM** (Cancun-compatible), supporting Solidity contracts deployable via standard Ethereum tooling. System contracts at address **0x167** expose HTS operations directly to Solidity, so contracts can create tokens, mint, burn, and transfer without wrapping. The per-transaction gas limit is **15 million gas**, and HIP-1249 (2025–2026) replaces gas-based throttling with an ops-per-second model, eliminating the legacy 80% minimum charge rule.

Scheduled transactions enable **multi-sig workflows and deferred execution**. HIP-423 extends the expiration window to **up to 2 months**, and the `wait_for_expiry` flag lets transactions wait until a specific time even after collecting all signatures — ideal for NitroGraph's escrow and settlement patterns. HBAR transfers via `TransferTransaction` cost just **$0.0001** and support atomic multi-party transfers combining HBAR and multiple token transfers in a single transaction.

---

## 2. SDK patterns and the transaction lifecycle

The primary SDK is `@hashgraph/sdk` for JavaScript/TypeScript (migrating to `@hiero-ledger/sdk` under the Linux Foundation's Hiero project). Current versions are in the **v2.70–v2.82 dual-publishing range**, with v2.83+ exclusively under `@hiero-ledger/sdk`. SDKs are also available in **Go, Java, Rust, Python, C++, and Swift**.

The transaction lifecycle follows a consistent pattern: **build → freeze → sign → execute → getReceipt**. Building constructs the transaction object with parameters. Freezing locks the transaction body (required before additional signatures). Signing adds operator and any additional key signatures. Executing submits to a consensus node. Getting the receipt (free) confirms success or failure; getting the record ($0.0001) provides detailed execution data including contract results.

```javascript
const client = Client.forTestnet();
client.setOperator(AccountId.fromString("0.0.1234"), PrivateKey.fromString("302..."));

const tx = new TransferTransaction()
  .addHbarTransfer(sender, Hbar.fromTinybars(-100))
  .addHbarTransfer(receiver, Hbar.fromTinybars(100));
const signedTx = await tx.freezeWith(client).sign(additionalKey);
const response = await signedTx.execute(client);
const receipt = await response.getReceipt(client); // FREE
```

**Critical deprecation notice**: `AccountBalanceQuery` is being **removed entirely in July 2026**. All balance queries should migrate to the Mirror Node REST API. For production applications, Hedera explicitly recommends using mirror nodes for all data queries rather than SDK queries against consensus nodes.

---

## 3. Mirror node architecture provides the read layer

Hedera separates write operations (consensus nodes) from read operations (mirror nodes). Consensus nodes process state-changing transactions and ensure finality. Mirror nodes receive transaction records, index them, and expose them for querying with a typical delay of **seconds** (near-real-time, not instantaneous).

### REST API endpoints

The public mirror node base URLs are:
- **Mainnet**: `https://mainnet.mirrornode.hedera.com/`
- **Testnet**: `https://testnet.mirrornode.hedera.com/`

Key endpoints include `/api/v1/transactions`, `/api/v1/topics/{id}/messages`, `/api/v1/tokens/{id}`, `/api/v1/accounts/{id}`, `/api/v1/contracts/{id}/results`, `/api/v1/balances`, and `/api/v1/schedules`. Rate limiting on public endpoints is **50 requests per second per IP** with no authentication required. Interactive Swagger documentation is available at `/api/v1/docs/`.

### gRPC streaming for real-time HCS

For real-time topic message subscriptions, the SDK's `TopicMessageQuery` uses **gRPC streaming** to mirror nodes at `mainnet.mirrornode.hedera.com:443` (TLS required). This is the primary mechanism for NitroGraph to subscribe to agent service advertisements, DID document updates, and transaction confirmations in real time.

A September 2024 change limits Hedera-operated mirror node results to a **60-day window** for certain endpoints without explicit timestamp parameters. Full historical data requires third-party providers like Arkhia, Hgraph, or Validation Cloud. **Block Nodes** are planned for 2026 to replace centralized cloud storage with decentralized data access using cryptographic proofs.

---

## 4. Enterprise adoption spans Fortune 500 companies and regulated finance

Hedera's enterprise traction is anchored by its Governing Council — now **34 members** (target 39) including Google, IBM, Dell, Boeing, FedEx, Deutsche Telekom, Standard Bank, LG, Shinhan Bank, Chainlink Labs, and Nomura Holdings. Each member runs a consensus node and participates in governance decisions with equal voting rights, modeled after **Visa's original 1968 governance structure**.

### Real-world deployments

**Avery Dennison's atma.io** managed over **28 billion unique items** across apparel, retail, food, and healthcare using HCS for tamper-proof supply chain logging and HTS for carbon emissions tokenization, though Messari reported in Q1 2025 that atma.io ceased using HCS, causing a notable decline in consensus message volume. **Hyundai/Kia** launched SCEMS, an AI-enabled blockchain system on Hedera managing carbon emissions across their entire supply chain. **Lloyds Banking Group, Abrdn, and Archax** completed the UK's first FX trades using tokenized real-world assets as collateral on Hedera. **Deloitte** built the FEMA "Close As You Go" grants management solution on Hedera for disaster recovery reimbursements.

The DIFC Courts in the UAE use Hedera for digital notary and wills services. Morocco's Ministry of Education deployed student digital identity wallets. EQTY Lab partnered with Intel and NVIDIA for **verifiable compute** — using TEEs on NVIDIA Blackwell GPUs with attestations anchored on HCS, achieving **400,000x performance improvement** for cryptographic AI governance certificates. Network statistics show **~575,000–708,000 daily transactions** and ~8.87 million total registered accounts as of mid-2025, with **37.5% of circulating HBAR staked**.

---

## 5. Token economics implementation on Hedera enables compliant programmable money

### Treasury and supply management

Every HTS token designates a **treasury account** that holds the initial supply and receives all minted tokens. Burning removes tokens from the treasury and reduces total supply, while wiping removes tokens from holder accounts (also reducing supply). Token supply can be **FINITE** (hard cap set at creation) or **INFINITE** (unlimited minting with supply key). Without a supply key, supply is permanently fixed at the initial amount — this immutability is a strong compliance signal.

### Token association and frictionless airdrops

Hedera requires accounts to **explicitly associate** with tokens before receiving them — a deliberate anti-spam mechanism that costs **$0.05 per association**. Accounts can set `maxAutoAssociations` (including `-1` for unlimited). HIP-904 introduced **frictionless airdrops**: senders can deliver tokens to unassociated accounts, creating pending airdrops that recipients claim via `TokenClaimAirdrop` ($0.001) or senders cancel. This is critical for NitroGraph's token distribution to new agent participants.

### KYC/AML integration points

The KYC key workflow enables **compliant token ecosystems**: tokens created with a KYC key default all associated accounts to KYC-revoked status. The issuer grants KYC via `TokenGrantKycTransaction` ($0.001), and only KYC-approved accounts can transact. Combined with the freeze key (for compliance holds and sanctions enforcement) and the wipe key (for clawbacks under court orders), this creates a compliance toolkit compatible with Reg D, MiCA, and MiFID II — all enforced at the **protocol level** rather than application level.

### Complete fee reference

| Operation | Cost (USD) |
|-----------|-----------|
| HBAR transfer | $0.0001 |
| Account creation | $0.05 |
| HCS topic creation | $0.01 |
| HCS message submit | $0.0008 |
| Token creation | $1.00 |
| Token transfer | $0.001 |
| Token association | $0.05 |
| NFT mint (per serial) | $0.02 |
| Token airdrop (no prior association) | $0.10 |
| Contract creation | $1.00 |
| Schedule creation | $0.01 |
| Transaction receipt | FREE |

All fees are denominated in USD and paid in HBAR at the current exchange rate, providing **complete cost predictability** — a critical property for AI agents that must calculate operational costs programmatically.

---

## 6. Regulatory structuring follows the Swiss Foundation + DevCo playbook

### The standard blockchain entity model

The dominant legal structure for DLT projects separates a **non-profit foundation** (holding IP, treasury, and governance) from a commercial **development company** (handling paid engineering and go-to-market). The Swiss Stiftung is the gold standard — Ethereum, Solana, Cardano, Polkadot, Tezos, and DFINITY all use Swiss foundations. Switzerland's advantages include FINMA's technology-neutral regulatory approach, the 2021 Blockchain Act recognizing ledger-based securities, zero capital gains tax for private investors, and binding advance tax rulings.

FINMA classifies tokens into **payment tokens** (AML requirements, no securities regulation), **utility tokens** (no FINMA approval needed if fully functional at issuance), and **asset tokens** (securities subject to prospectus requirements). A critical 2024 Federal Administrative Court decision confirmed that **pre-functional utility tokens are treated as securities**, reinforcing the substance-over-form principle.

### Bermuda, Cayman, and alternative jurisdictions

**Bermuda's Digital Asset Business Act (DABA)** offers three license tiers (Test, Modified, Full) with no income, corporate, or capital gains tax, FATF-compliant AML, and a head-office substance requirement. **Cayman Islands foundation companies** are the most popular DAO legal wrapper globally, with flexible governance, tax neutrality, and 24-hour incorporation. The **Marshall Islands DAO LLC** (DAO Act 2022) offers purpose-built DAO entities with no mandatory directors and fully on-chain governance, at lower cost than Cayman or Swiss structures.

### Hedera's distinctive governance model

Hedera itself uses a **Delaware LLC** (not a Swiss foundation), with a multi-member LLC Agreement governing the Council. Swirlds Inc. (founded by Leemon Baird and Mance Harmon) originally held the hashgraph IP, which the Council purchased in January 2022 for **292,682,667 HBAR (~$76.3M)**. The development arm, Swirlds Labs, rebranded to **Hashgraph** in July 2024. The LLC structure provides a **no-fork guarantee** — technically and legally preventing network splits, a key enterprise trust signal.

### MiCA and the US token taxonomy

The EU's **MiCA regulation** became fully applicable December 30, 2024, categorizing tokens as asset-referenced tokens, e-money tokens, or utility tokens, and requiring CASP licensing for exchanges, custodians, and advisors (minimum capital €50,000–€150,000 with EU-wide passporting). Over **€540 million in fines** have been issued since implementation, with 50+ firms losing licenses.

In the US, the **March 17, 2026 SEC-CFTC joint interpretive release** established a five-category token taxonomy, naming 16 specific tokens as **digital commodities** (including HBAR, BTC, ETH, SOL, AVAX, ADA, and XRP). This is currently an administrative interpretation — the CLARITY Act must pass Congress to codify it permanently.

---

## 7. How Hedera compares to Ethereum L2s, Solana, and Avalanche for enterprise

### Performance and finality are Hedera's strongest suit

| Metric | Hedera | Ethereum L2s | Solana | Avalanche |
|--------|--------|-------------|--------|-----------|
| **Sustained TPS** | ~4 (current), 10,000 capacity | 300–1,000 (per L2) | ~957–1,400 user TPS | ~4,500 (C-Chain) |
| **Finality** | **3–5s deterministic** | Seconds soft; 7-day hard (optimistic) | ~2.5s probabilistic | **Sub-1s deterministic** |
| **Transfer cost** | **$0.0001 (fixed)** | $0.001–$0.01 | $0.00025 | $0.01–$0.02 |
| **Fee model** | Fixed USD-denominated | Variable (EIP-1559) | Base + priority | Dynamic gas |
| **Token classification** | Digital commodity | ETH commodity; L2 tokens unclear | Improving; ETF approved | Similar to other L1s |

Hedera's **deterministic finality** means once confirmed, transactions are mathematically final with zero reorganization risk — the strongest theoretical BFT guarantee (aBFT). Solana offers the highest raw throughput but with probabilistic finality. Ethereum L2s inherit Ethereum's security but optimistic rollups impose a **7-day challenge window** for withdrawals. Avalanche achieves sub-second finality via Snowman consensus and offers unmatched flexibility through **Evergreen subnets** with chain-level KYC/KYB permissioning.

### Enterprise suitability scorecard

For NitroGraph specifically, Hedera wins on **cost predictability** (fixed USD fees critical for agent cost calculations), **regulatory clarity** (HBAR commodity classification), **native services** (HCS for agent messaging, HTS for tokens without smart contracts), and **governance trust** (Fortune 500 Council). Avalanche is the strongest alternative for jurisdiction-specific compliance via Evergreen subnets. Solana dominates for consumer-scale payment rails (Visa, Shopify, Stripe integrations). Ethereum L2s offer the largest developer ecosystem and deepest DeFi liquidity.

A hybrid strategy is increasingly common in 2025–2026: **Hedera for core orchestration and compliance** plus **Solana or Ethereum L2s for high-throughput consumer interactions**.

---

## 8. Decentralized identifiers give AI agents verifiable on-chain identity

### The did:hedera method

The Hedera DID method (`did:hedera`) maps DIDs to **HCS topics** where DID Document lifecycle events are published as consensus-ordered messages. The identifier format is:

```
did:hedera:<network>:<base58-public-key>_<topic-id>
```

All CRUD operations — create, update, revoke, deactivate — are submitted as signed HCS messages to the DID's dedicated topic. Resolution works by replaying all topic messages via a mirror node and reconstructing the current DID Document state. Identity artifacts **flow through** Hedera rather than being stored on consensus nodes, enabling throughput of **10,000–100,000+ identity operations per second**.

**HIP-1219 (v2.0, under development)** shifts control authority to the DID Document's `controller` property rather than the embedded public key, enabling multi-controller scenarios and simplified key rotation. **HIP-19** allows associating DIDs with Hedera entities (accounts, topics, tokens) via the entity memo field, enabling verifiable credentials to be issued to on-chain entities.

### Verifiable credentials and agent identity

Verifiable credentials on Hedera use a hash-based approach: the issuer signs credentials off-chain and submits a **hash** to a dedicated VC topic via HCS (never the credential content itself, which may contain PII). Revocation is handled by publishing revocation messages to the same topic, with the `HcsVcTransaction` API supporting ISSUE, SUSPEND, RESUME, and REVOKE status types. An advanced **AnonCreds implementation** uses HCS-1 for privacy-preserving ZKP-based credentials.

For NitroGraph, each AI agent can receive a `did:hedera` DID by generating a keypair, creating a private HCS topic, registering via HCS message, and receiving verifiable credentials attesting to capabilities, certifications, and authorization levels. The **Hedera Agent Kit V3** provides plugins for agents to autonomously manage DID documents, publish HCS messages, and execute smart contracts.

---

## 9. ADSP design patterns for agent discovery and commerce on Hedera

### Lessons from existing agent protocols

Three blockchain-native agent protocols provide architectural precedent. **Fetch.ai's Almanac Registry** is an on-chain smart contract directory where agents register endpoints, supported protocols, and capabilities, with FET token fees as an anti-Sybil mechanism. **SingularityNET** uses an Ethereum registry contract storing organizations and services with IPFS-hosted metadata, and a **Multi-Party Escrow (MPE)** system for scalable micropayments via unidirectional payment channels. **Autonolas (Olas)** represents components, agents, and services as **ERC-721 NFTs** with composability tracking and a Proof of Active Agent staking mechanism where agents must demonstrate useful activity to earn rewards.

### Recommended ADSP architecture for NitroGraph on Hedera

The optimal design uses a **hybrid approach** across Hedera's native services:

- **Discovery Layer**: HCS topics for agent service advertisements (real-time, $0.0008/message) plus a smart contract agent identity registry (ERC-721 per agent linking to metadata). A mirror-node-backed indexer aggregates data for fast search.
- **Identity Layer**: `did:hedera` DIDs for each agent with VCs for capability attestations, stored on private HCS topics.
- **Trust Layer**: HTS fungible reputation tokens earned per successful service completion and burned on slashing events. Smart contracts enforce staking bonds and slashing conditions.
- **Payment Layer**: Direct HBAR micropayments per request (viable at $0.0001 per transfer). Smart contract escrow for high-value SLA-bound interactions. Scheduled transactions for batch settlements.
- **Communication Layer**: Google A2A protocol for agent-to-agent calls, HCS topics for async messaging and audit trails, with NLIP compatibility for natural-language interactions.

### Capability advertisement schema

Agent advertisements published to HCS discovery topics should contain the agent DID, capability list with input/output schemas, service endpoints (A2A, MCP, gRPC), pricing model (per-request HBAR amount), SLA parameters (max latency, availability percentage, stake bond), reputation token ID, and registration timestamp. This schema should align with **OpenConvAI (HCS-10)** — the emerging standard built by Hashgraph Online with 72,000+ agents registered across 14+ protocols.

### SLA enforcement and price discovery

Smart contract escrow is the primary enforcement mechanism: clients deposit HBAR before service requests, funds release on successful completion (verified by oracle or client attestation), and timeout/failure returns funds. Agents stake HTS tokens as performance bonds with slashing for SLA violations. Price discovery can use posted prices (simplest), FIPA-style contract-net protocol (client issues call-for-proposals via HCS, agents bid), or dynamic pricing based on HCS heartbeat messages indicating load.

---

## 10. The developer ecosystem is maturing rapidly under Hiero and AI Studio

### The Hiero migration to Linux Foundation

In September 2024, Hedera donated its **entire codebase** to Linux Foundation Decentralized Trust as project **"Hiero"** — the first L1 public DLT to do so. Hiero **graduated** from LFDT in September 2025, earning its highest recognition. All SDKs are transitioning: JavaScript from `@hashgraph/sdk` to `@hiero-ledger/sdk` (dual publishing through v2.82, exclusive from v2.83), Go from `hashgraph/hedera-sdk-go` to `hiero-ledger/hiero-sdk-go`, with Rust (`hiero-sdk` crate), Python (`hiero-sdk-python` on PyPI), C++, and Swift SDKs also under the Hiero umbrella.

### Hedera AI Studio and Agent Kit

Launched in May 2025, **Hedera AI Studio** is an open-source modular toolkit built by Hashgraph Online, Eliza Labs, Hashgraph, and the Hedera Foundation. The **Hedera Agent Kit V3** (July 2025) provides JavaScript and Python SDKs with plugin architecture supporting account management, token operations, consensus messaging, and EVM contract interaction. It integrates with **LangChain, Vercel AI SDK, ElizaOS, and MCP Server**. The `create-hedera-agent` CLI scaffolds new agent projects. The Developer Portal now includes an **Agent Lab** and **Agent Builder** for browser-based agent development.

**OpenConvAI (HCS-10)** provides a protocol for decentralized AI agent discovery and communication on HCS, with registration in a guarded registry, secure communication topics, and fee mechanisms. The standards SDK (`@hashgraphonline/standards-sdk`) includes 11 LangChain tools.

### EVM tooling and testing infrastructure

The **JSON-RPC Relay** translates standard Ethereum calls to Hedera, enabling **Hardhat, Foundry, MetaMask, ethers.js, and web3.js** workflows. Hashio endpoints (`testnet.hashio.io/api`, chain ID 296) provide free development access; production apps should use commercial relays or self-hosted instances. **Solo** (formerly Hedera Local Node) provides Kubernetes-based local development with consensus node, mirror node, and relay in Docker containers (requires 12 GB RAM).

Contract verification uses **Sourcify** at `verify.hashscan.io`, accessible via the HashScan UI, Hardhat plugin (`hashscan-verify`), or Foundry CLI. HashScan at `hashscan.io` serves as the primary block explorer. The **Hedera Foundation** (rebranded from HBAR Foundation in 2025) runs milestone-based grants through the Thrive 2025 program, and hackathons including the Hello Future Trilogy ($550K total) and Hedera Africa Hackathon ($1M+ pool) drive ecosystem growth.

The DeFi ecosystem is led by **SaucerSwap** (DEX, ~$77.6M TVL), **Stader Labs** (liquid staking, ~$125M TVL), **Bonzo Finance** (Aave V2 fork, ~$32.4M TVL), and **HashPack** (wallet serving ~95% of monthly active users). Cross-chain connectivity comes via **Chainlink** (CCIP, Data Feeds, Proof of Reserve live) and **Axelar Network** (60+ blockchain connections).

---

## Conclusion: Hedera's architecture maps naturally to NitroGraph's requirements

Hedera's design philosophy — native protocol services, fixed fees, deterministic finality, and enterprise governance — aligns remarkably well with an AI agent commerce orchestration protocol. **HCS provides the ordered message bus** for agent discovery, bidding, and coordination at $0.0008 per message. **HTS provides programmable, compliance-ready tokens** with KYC/freeze/wipe keys at the protocol level. **Smart contracts handle escrow and SLA enforcement** with full EVM compatibility. The `did:hedera` method gives agents verifiable decentralized identity, and the emerging HCS-10/OpenConvAI standard already provides agent registry infrastructure with 72,000+ registered agents.

The key architectural insight is that NitroGraph should treat HCS as its **nervous system** (ordering all agent interactions), HTS as its **circulatory system** (moving value and reputation), and smart contracts as its **immune system** (enforcing SLAs and resolving disputes). Mirror nodes provide the read layer for discovery, and `did:hedera` provides the identity layer for trust. HBAR's commodity classification, the Council's Fortune 500 governance, and fixed USD-denominated fees create an environment where enterprise counterparties can engage with measurably lower regulatory and operational risk than on any competing platform.

The primary trade-offs are a **smaller developer ecosystem** than Ethereum or Solana, current network usage well below theoretical capacity (suggesting the ecosystem is still early), and the ongoing Hiero migration requiring attention to SDK namespace changes. For NitroGraph's purposes, these are manageable risks against the structural advantages Hedera provides for enterprise-grade agent commerce.