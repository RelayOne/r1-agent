# Chaos engineering: a complete guide to breaking systems before they break you

**Every production outage reveals the same truth: teams tested for success but never verified failure.** Chaos engineering inverts this paradigm by deliberately injecting controlled failures — network partitions, broker crashes, connection pool exhaustion — to prove that systems degrade gracefully rather than catastrophically. Netflix pioneered the discipline after a 2008 database corruption incident, Google formalized it as DiRT (Disaster Recovery Testing), and Amazon embedded it into its GameDay culture. Today, a mature ecosystem of open-source and commercial tools — Chaos Mesh, LitmusChaos, Gremlin, Toxiproxy — makes systematic resilience verification accessible to any team running distributed services. This report covers the full landscape: tool selection, failure injection techniques, game day practices, data-layer and message-queue testing, cascading failure prevention, and the critical role of observability in making chaos experiments meaningful.

---

## The chaos tooling landscape in 2026

Five tools dominate the chaos engineering space, each occupying a distinct niche. The choice depends on your infrastructure, budget, and organizational maturity.

**Chaos Mesh** is the most actively developed Kubernetes-native option. A CNCF Incubating project originally created by PingCAP to test TiDB, it boasts **~7,600 GitHub stars**, 100+ contributors, and its latest release (v2.8.2, March 2026) demonstrates consistent momentum. Chaos Mesh defines experiments as Kubernetes Custom Resources — `NetworkChaos`, `PodChaos`, `StressChaos`, `IOChaos`, `DNSChaos`, `JVMChaos` — giving teams declarative, version-controlled fault injection. Its built-in dashboard and GitHub Actions integration (`chaos-mesh/chaos-mesh-action`) make it strong for both ad-hoc experiments and CI/CD pipelines. It is entirely free and open-source under Apache 2.0.

**LitmusChaos** takes a similar Kubernetes-native approach with **~5,300 stars** and CNCF Incubating status. Its differentiators include ChaosHub (a public marketplace of pre-built experiments), resilience probes for automated health verification, and a resiliency scoring system. Harness offers an enterprise SaaS version with AI-driven experiment recommendations. LitmusChaos excels at CI/CD integration and provides richer experiment orchestration than Chaos Mesh, though its learning curve is steeper.

**Gremlin** is the leading commercial platform, founded in 2016 by engineers who built failure injection systems at Amazon and Netflix. It supports **bare metal, VMs, containers, Kubernetes, and serverless** (including AWS Lambda via Failure Flags), making it the most versatile for heterogeneous environments. Gremlin provides reliability scores, GameDay management, automated test suites, and dependency discovery. Pricing is custom-quote only with no free tier — previous per-agent models have been replaced by an all-inclusive platform fee. For Cloud Run and serverless platforms, Gremlin's Failure Flags feature injects faults at the application level, bypassing infrastructure constraints.

**Toxiproxy**, created by Shopify, takes a fundamentally different approach. Rather than orchestrating infrastructure chaos, it operates as a **TCP proxy** between your application and its dependencies, enabling precise manipulation of individual connections. With **~11,900 GitHub stars** and client libraries for Java, Go, Python, .NET, Ruby, and Node.js, it is the most widely adopted tool for integration testing. Toxiproxy supports latency injection, bandwidth limiting, connection timeout, connection reset, slow close, and packet slicing. It has no Kubernetes awareness — it's a development and CI/CD tool, not a production chaos platform. Completely free under MIT license.

**Chaos Monkey**, Netflix's iconic tool with **~16,300 stars**, remains historically significant but functionally limited. It performs only one action — randomly terminating VM instances — and requires Spinnaker for deployment. The project receives minimal maintenance, with its last release (v2.1.3) focused on MySQL 8.0 compatibility. The broader Simian Army has been archived. Teams starting fresh should choose Chaos Mesh or LitmusChaos instead.

| Tool | Kubernetes | Serverless | Pricing | CNCF Status | GitHub Stars |
|------|-----------|------------|---------|-------------|-------------|
| Chaos Mesh | Native (CRDs) | No | Free/OSS | Incubating | ~7,600 |
| LitmusChaos | Native (CRDs) | Limited | Free/OSS + Enterprise | Incubating | ~5,300 |
| Gremlin | Agent-based | Yes (Failure Flags) | Custom quote | N/A | N/A (closed) |
| Toxiproxy | Manual setup | N/A | Free/OSS | N/A | ~11,900 |
| Chaos Monkey | Via Spinnaker | No | Free/OSS | N/A | ~16,300 |

---

## Eight categories of failure injection and how they work

Every failure injection technique maps to a specific OS-level or network-level mechanism. Understanding the underlying implementation matters because it determines blast radius, precision, and cleanup reliability.

**Network partition simulation** uses `iptables` rules or Linux Traffic Control (`tc`) to drop packets between specific endpoints. Chaos Mesh's `NetworkChaos` with `action: partition` creates bidirectional network isolation between pods selected by label. Gremlin's "blackhole" attack achieves the same by dropping all traffic to specified hosts or ports. For testing, Toxiproxy can simply disable a proxy to simulate a complete connection failure. The key verification: does your service detect the partition and fail over, or does it hang indefinitely?

**Latency injection** relies on `tc qdisc netem` to add configurable delays to network interfaces. Chaos Mesh supports latency with jitter (`delay.latency: "100ms"`, `delay.jitter: "50ms"`), and Istio's VirtualService fault injection can add delays at the service mesh layer without kernel modification. Toxiproxy's `latency` toxic adds delay to individual TCP connections. Start with **100ms** to test timeout configurations, then escalate to **2s** and **5s** to verify circuit breakers trip correctly.

**Dependency failure** combines several techniques: Toxiproxy disabling a proxy (complete outage), Istio returning HTTP 503 for a percentage of requests, or Chaos Mesh killing pods of a downstream service. The critical test is whether your service returns a degraded response (cached data, default values) rather than propagating the error upstream.

**Disk full simulation** uses `fallocate` or `dd` to consume disk space, or Chaos Mesh's `IOChaos` to inject I/O errors. This is critical for databases and logging systems — a full disk can cause PostgreSQL WAL corruption or Kafka broker crashes. Verify that your monitoring alerts fire before **95%** capacity and that services handle write failures gracefully.

**OOM simulation** uses `stress-ng` or cgroup memory limits to exhaust available memory. Chaos Mesh's `StressChaos` with `memorySize` targets specific containers. The test validates whether Kubernetes OOM-kills the right container, whether the pod restarts correctly, and whether upstream services handle the temporary unavailability.

**Clock skew simulation** manipulates system time using `clock_settime` or container-level time namespaces. Chaos Mesh's `TimeChaos` shifts time for specific containers without affecting the host. This reveals bugs in certificate validation, token expiration, cache TTLs, and scheduled job execution. TLS certificate expiration testing specifically requires advancing clocks past certificate `notAfter` dates to verify that services handle expired certificates without crashing.

**DNS failure simulation** intercepts DNS resolution to return errors or incorrect addresses. Chaos Mesh's `DNSChaos` returns random IPs or errors for targeted domains. This tests whether services cache DNS results appropriately and whether they retry DNS resolution with exponential backoff.

---

## How Netflix, Amazon, and Google run game days

The three companies that defined chaos engineering each developed distinct approaches to organized failure testing, but their core methodology converges on the same pattern: **hypothesis → controlled injection → observation → learning**.

**Netflix** evolved from Chaos Monkey (random instance termination, 2011) to the FIT (Failure Injection Testing) platform, which enables targeted fault injection across their entire microservices architecture. FIT allowed Netflix engineers to inject failures as a self-service capability — any team could simulate dependency failures without coordinating with infrastructure. The critical evolution was **Chaos Kong**, which simulates the loss of an entire AWS region. Netflix runs Chaos Kong exercises regularly, verifying that their traffic can seamlessly redirect to alternative regions. The key insight from Netflix's decade of practice: **automated, continuous chaos experiments replaced periodic game days**. Their reliability improved from three nines to **four nines (99.99% uptime)** after systematic FIT adoption across all critical streaming teams.

**Amazon's GameDay** program, created by Jesse Robbins (internally titled "Master of Disaster"), draws from firefighter training methodology. The approach operates on the principle that teams don't prepare for disasters — they react to them. AWS GameDays are structured exercises where teams face simulated outages in their own services. AWS also offers the **Fault Injection Simulator (FIS)**, a managed service supporting experiments on EC2, ECS, EKS, RDS, and Lambda. FIS integrates with CloudWatch alarms as stop conditions, automatically halting experiments that exceed safety thresholds. Goldman Sachs published a detailed case study of running chaos tests on AWS: they use ephemeral VPC environments provisioned via IaC, short-lived access tokens for fault injection, and automatic teardown — results are uploaded as audit trails.

**Google's DiRT** (Disaster Recovery Testing) program, created by Kripa Krishnan, takes the most aggressive approach. Google engineers **physically enter data centers and do "terrible things to the machines"** — unplugging hardware, disrupting network links — to test how their internal systems respond. A small team plans and executes DiRT to avoid customer harm, but engineers experience it as a real outage. Google's SRE book codifies the framework: define scope, gather results, analyze gaps. Facebook runs a similar program called **Storm**, and Dropbox operates **DRT**.

A practical game day template requires these components:

- **Hypothesis**: "If Service X becomes unavailable, the customer-facing feature Y will degrade to cached data within Z seconds"
- **Steady-state metrics**: Error rate, p99 latency, throughput, business KPIs (orders/minute, stream starts)
- **Blast radius controls**: Percentage of traffic affected, specific user segments, single availability zone
- **Abort criteria**: If error rate exceeds 5%, latency exceeds 10s, or any business metric drops below threshold — automatically halt and revert
- **Communication plan**: Who is informed, how to escalate, war room logistics
- **Post-experiment analysis**: What happened vs. hypothesis, observability gaps discovered, action items with owners and deadlines

---

## Verifying graceful degradation systematically

The central question chaos engineering must answer for every service: **when dependency X fails, does this service degrade gracefully or catastrophically?** Systematic verification requires mapping all dependencies, testing each failure mode independently, and validating user-facing behavior.

**Circuit breaker testing** with Resilience4j (the modern replacement for Netflix Hystrix) follows a precise state-machine verification pattern. Configure a circuit breaker with a `failureRateThreshold` of 50%, a `slidingWindowSize` of 10 calls, and a `waitDurationInOpenState` of 10 seconds. Then inject failures into the downstream service and verify three transitions: **Closed → Open** (after threshold breached), **Open → Half-Open** (after wait duration), and **Half-Open → Closed** (after successful probe requests). The test must also verify that the **fallback method** returns an acceptable degraded response — cached data, a queued operation, or a friendly error message.

```java
@CircuitBreaker(name = "paymentService", fallbackMethod = "paymentFallback")
public PaymentResponse processPayment(PaymentRequest request) {
    return restTemplate.postForObject(
        "http://payment-gateway/api/payments", request, PaymentResponse.class);
}

private PaymentResponse paymentFallback(PaymentRequest request, Throwable t) {
    return PaymentResponse.builder()
        .status("PENDING")
        .message("Payment queued for processing")
        .build();
}
```

**Istio fault injection** enables service mesh–level testing without modifying application code. A VirtualService can inject 500ms delays into 50% of requests to a specific service, or return HTTP 503 for 10% of traffic. This tests the entire chain — application timeout handling, circuit breaker behavior, and load balancer health checks — in a production-like environment.

**Dependency failure matrix** testing requires enumerating every external dependency (databases, caches, APIs, message queues) and testing each failure mode: complete outage, high latency (500ms, 2s, 10s), intermittent errors (10%, 50%), and degraded throughput. For each cell in the matrix, document the expected user-facing behavior and verify it with automated tests. The most common finding: **timeout configurations are wrong**. Services configured with 30-second timeouts on dependencies that should respond in 100ms will hang for 30 seconds during outages instead of failing fast.

---

## Toxiproxy patterns that make integration tests resilient

Toxiproxy's power lies in its ability to make network failure modes a first-class concern in your test suite. Rather than hoping your application handles connection failures correctly, you prove it with every test run.

The architecture is straightforward: Toxiproxy sits between your application and each dependency as a TCP proxy. Your application connects to Toxiproxy's listen address instead of the real service. You then programmatically add "toxics" — latency, bandwidth limits, connection resets — to simulate failure conditions.

**Testcontainers integration** is the modern standard for Java and Go projects. The Testcontainers Toxiproxy module spins up a Toxiproxy container alongside your test dependencies:

```java
var toxiproxy = new ToxiproxyContainer(
    DockerImageName.parse("ghcr.io/shopify/toxiproxy:2.12.0"));
toxiproxy.start();
```

In Go, the pattern for testing latency tolerance looks like:

```go
func TestSlowConnection(t *testing.T) {
    proxy, _ := client.Proxy("upstream_api")
    proxy.AddToxic("latency", "latency", "upstream", 1.0, 
        toxiproxy.Attributes{"latency": 3000})
    defer proxy.RemoveToxic("latency")
    
    start := time.Now()
    resp, _ := http.Get("http://" + proxy.Listen)
    if time.Since(start) < 3000*time.Millisecond {
        t.Fatal("request completed sooner than expected")
    }
}
```

The Strimzi Kafka test container integrates Toxiproxy directly, allowing chaos testing of Kafka connections — injecting latency to specific brokers, simulating bandwidth limitations during large batch operations, or cutting connectivity to trigger consumer rebalances.

The key toxics for integration testing cover five critical scenarios: **latency** (add 1-5s delay to test timeout handling), **timeout** (stop all data flow and close connection to test circuit breakers), **reset_peer** (send TCP RST to test connection retry logic), **bandwidth** (limit to 1KB/s to test streaming and large-payload handling), and **slicer** (break TCP data into tiny fragments to test reassembly). Each toxic can be applied upstream (request) or downstream (response) and configured with a toxicity percentage for partial failure simulation.

For Docker Compose test environments, configure Toxiproxy with a JSON config file mounted at startup:

```json
[
  {"name": "mysql", "listen": "[::]:3306", "upstream": "mysql:3306", "enabled": true, "toxics": []},
  {"name": "redis", "listen": "[::]:6379", "upstream": "redis:6379", "enabled": true, "toxics": []}
]
```

---

## Embedding chaos into every CI/CD pipeline

Chaos experiments deliver the most value when they run **automatically with every deployment**, not as occasional manual exercises. The goal is resilience regression testing: proving that new code doesn't break existing failure-handling logic.

**Chaos Mesh with GitHub Actions** provides the most streamlined CI/CD integration. The official `chaos-mesh/chaos-mesh-action` sets up a Kind cluster, installs Chaos Mesh, and runs experiments defined as YAML manifests:

```yaml
name: Chaos Testing Pipeline
on: [push]
jobs:
  chaos-test:
    runs-on: ubuntu-latest
    steps:
      - uses: helm/kind-action@v1.0.0-rc.1
      - uses: actions/checkout@v2
      - name: Deploy application
        run: kubectl apply -f k8s/
      - name: Run chaos experiment
        uses: chaos-mesh/chaos-mesh-action@master
        env:
          CFG_BASE64: <base64-encoded-chaos-config>
      - name: Validate recovery
        run: curl -f http://myapp.com/health || exit 1
```

**Measuring MTTR automatically** requires instrumenting the chaos pipeline to record timestamps: when the fault was injected, when alerts fired (detection time), and when health checks passed again (recovery time). Store these metrics over time to track MTTR trends. Goldman Sachs's approach is exemplary: they run chaos experiments in ephemeral AWS VPC environments provisioned via Infrastructure as Code, using short-lived access tokens. Test failures break the pipeline, preventing unresilient code from reaching production. Results are uploaded as audit trails for compliance.

**LitmusChaos integrates with CI/CD** through its ChaosEngine CRD and a REST API that triggers experiments programmatically. Harness Chaos Engineering extends this with native CI/CD pipeline stages — chaos experiments run as deployment gates, and failed resilience checks block promotion to production.

**AWS Fault Injection Simulator** can be triggered from CodePipeline, enabling automated failover testing of RDS clusters, EC2 termination, and EKS pod deletion as part of deployment verification. The key practice: run chaos experiments against **ephemeral environments** that mirror production topology, using namespace isolation in Kubernetes or dedicated VPCs in AWS.

---

## Kafka resilience under every failure mode

Kafka's distributed architecture creates specific failure scenarios that require targeted testing strategies. Three scenarios deserve the most attention because they occur frequently in production and their handling determines whether your event pipeline loses or duplicates data.

**Broker failure during mid-batch produce** is the most consequential scenario. With `acks=1`, the leader acknowledges before replication completes — if the leader dies immediately after acknowledging, **the message is lost**. With `acks=all`, the producer waits for all in-sync replicas to acknowledge, preventing data loss as long as at least one ISR survives. Enable `enable.idempotence=true` (default since Kafka 3.0) to prevent duplicates during retries: each producer receives a unique Producer ID, and each message gets a monotonically increasing sequence number. Brokers reject duplicate sequence numbers. Set `max.in.flight.requests.per.connection` to **≤ 5** — Kafka guarantees ordering with idempotent producers up to this limit. To test: use Gremlin or Chaos Mesh to kill a broker pod while producing at high throughput. Verify that with `acks=all` and idempotency enabled, **zero messages are lost and zero duplicates appear**.

**Consumer group rebalance under failure** is the most operationally disruptive Kafka event. The legacy eager rebalancing protocol triggers a **"stop the world" pause** — all consumers stop processing while partitions are revoked and reassigned. The modern `CooperativeStickyAssignor` (default since Kafka 3.0) performs incremental rebalancing: only affected partitions move, and unaffected consumers continue processing. To test: kill consumer pods during active processing and measure consumer lag spike duration. Key configurations: `session.timeout.ms` (45s default — how long before a dead consumer is detected), `max.poll.interval.ms` (5 minutes — maximum processing time between polls), and `group.instance.id` (enables static membership so brief restarts don't trigger rebalance). In Kubernetes, always set `group.instance.id` to prevent rebalance storms during rolling deployments.

**Partition leader election during load** tests Kafka's core availability mechanism. When a leader broker fails, the controller detects the failure via ZooKeeper session timeout (18s default) or KRaft heartbeat, then elects a new leader from the ISR. Gremlin's Kafka chaos experiments show that with a 3-broker cluster, **leader election completes in approximately 10 seconds**, during which producers experience `NOT_LEADER_FOR_PARTITION` errors and must retry. With `retries=MAX_INT` (default) and proper `delivery.timeout.ms`, producers buffer and retry automatically. Steadybit's Kafka extension enables precise testing: trigger leader elections for specific partitions while monitoring lag, throughput, and ISR state transitions.

---

## Database failure patterns that every team must test

Database failures are the most consequential infrastructure events because they directly threaten data integrity. Four scenarios expose the most common gaps in application resilience.

**Replica failover testing** with Patroni-managed PostgreSQL on Kubernetes is well-documented. Patroni acquires a leader lock in the DCS (Kubernetes API, etcd, or Consul) with a **30-second TTL**. If the primary cannot refresh its lock — due to network partition, pod crash, or resource starvation — the lock expires and a replica is promoted. Chaos Mesh testing with a `NetworkChaos` partition manifest targeting the primary pod consistently triggers failover **within 23 seconds** of partition onset. The critical application-side verification: does your connection pool (HikariCP, PgBouncer) detect the failover and reconnect to the new primary? Aurora PostgreSQL failover involves DNS endpoint updates with a 5-second TTL, but client-side caching can delay recognition. Test with `aws:rds:failover-db-cluster` via AWS FIS.

**Connection pool exhaustion** under load is the silent killer of application availability. HikariCP defaults to **10 maximum connections** and a **30-second connection timeout**. When all connections are active and a new request arrives, it blocks for up to 30 seconds before throwing `SQLTransientConnectionException`. The cascading effect: requests queue up, consume threads, response times spike from milliseconds to 30+ seconds, and the application effectively freezes. To test: set `maximumPoolSize` to 5, introduce `SELECT pg_sleep(10)` on a dependency, and verify that your application returns HTTP 503 (Service Unavailable) rather than hanging. Enable HikariCP's `leakDetectionThreshold` (set to 60 seconds) to identify connections that are borrowed but never returned. Monitor `hikaricp_connections_pending` — any non-zero value indicates saturation is approaching.

**PostgreSQL transaction ID wraparound** is the most catastrophic database failure mode most teams have never tested. PostgreSQL uses **32-bit transaction IDs** that wrap around every ~4 billion transactions. Without regular VACUUM to "freeze" old row versions, rows can appear to vanish. PostgreSQL has multiple safety layers: autovacuum triggers anti-wraparound vacuum when `age(relfrozenxid)` exceeds 200 million, a failsafe vacuum activates at 1.6 billion, warnings appear at 40 million transactions before the limit, and the database enters **read-only mode** at 1 million transactions remaining. To simulate: use `pg_resetwal -x 2000027648` to advance the XID counter near the danger zone, or the `xid_wraparound` extension to consume XIDs rapidly. Monitor with `SELECT datname, age(datfrozenxid) FROM pg_database ORDER BY 2 DESC`.

**Migration lock conflicts** under load test whether DDL operations (schema changes) block application queries. PostgreSQL DDL acquires `AccessExclusiveLock`, blocking all concurrent access to the table. Under write-heavy workloads, long-running transactions can prevent the DDL lock from being acquired, creating a queue of blocked queries. Set `lock_timeout` and `statement_timeout` to prevent indefinite waits, and use online migration tools like `pg-osc` or `pt-online-schema-change` for MySQL.

---

## Why one slow service can take down everything

Cascading failures are the primary risk in microservices architectures. A single slow dependency can exhaust thread pools, connection pools, and memory across every upstream service, creating a system-wide outage from a localized issue.

**The mechanism is predictable**: Service A calls Service B with a 30-second timeout. Service B is slow. Service A's threads block for 30 seconds per request. Under load, all threads are consumed waiting for Service B. Service A can no longer process any requests — including those that don't depend on Service B. Service A's callers experience the same pattern, propagating the failure upstream.

**Timeout hierarchy correctness** is the first line of defense. Every downstream timeout must be shorter than the upstream timeout: if Service C has a 5-second timeout, Service B's timeout on C must be shorter than B's own timeout from A. gRPC's deadline propagation handles this automatically — a deadline set at the edge propagates through every hop, automatically shortening at each level. For HTTP, this requires manual coordination. Test by injecting 10-second latency into a leaf service and verifying that the edge service returns within its configured timeout, not 10 seconds later.

**Load shedding verification** proves that services reject excess traffic rather than degrading under unbounded load. The pattern: when request queues exceed a threshold, return **HTTP 429 (Too Many Requests)** or **HTTP 503 (Service Unavailable)** immediately rather than accepting requests that will timeout. Envoy and Istio provide configurable rate limiting and circuit breaking at the mesh layer. Test by generating traffic 3x above normal capacity and verifying that excess requests receive immediate rejections while in-limit requests complete normally.

**Retry storm prevention** requires exponential backoff with jitter and retry budgets. Without these controls, retries during a partial outage create an amplification effect — if each service retries 3 times, a 3-tier architecture amplifies failures by 27x. Envoy's retry budgets limit the percentage of requests that can be retries (typically 20%), preventing amplification. The bulkhead pattern isolates dependencies with separate thread pools or connection pools, ensuring that a slow dependency can only exhaust its allocated resources.

```python
@dataclass
class ResilienceConfig:
    cb_failure_threshold: int = 5      # Circuit breaker trips after 5 failures
    cb_timeout: float = 30.0           # 30s before testing recovery
    bh_max_concurrent: int = 10        # Bulkhead: max 10 concurrent calls
    timeout: float = 10.0              # Per-call timeout
    retry_max_attempts: int = 3        # Max 3 retries
    retry_base_delay: float = 1.0      # 1s base delay with jitter
```

---

## Observability is the experiment — not just the measurement

The most valuable outcome of chaos experiments is not confirming that services recover. It is **validating that your observability stack correctly detects, alerts, and enables diagnosis of the failure**. If your monitoring doesn't fire an alert during a controlled experiment, it won't fire during a real incident.

**Alert validation during chaos** answers three questions: Do alerts fire? How quickly? Do they reach the right team? Before every chaos experiment, document which alerts should trigger and within what time window. After injecting failure, measure **alert latency** — the time between fault injection and PagerDuty/OpsGenie notification. If your SLO-based alerting takes 15 minutes to detect a failure that impacts users in 30 seconds, you have a detection gap. Alert fatigue is equally dangerous: if injecting a single pod failure generates 47 alerts across 12 dashboards, responders will miss the signal in the noise. Target **SLO-based alerts** ("error budget 50% consumed") rather than threshold alerts ("CPU > 80%").

**Runbook verification** during chaos experiments exposes a pervasive problem: runbooks are outdated. Goldman Sachs's chaos program specifically tests whether documented escalation contacts and remediation steps match current reality. The practice: during a game day, don't tell the responding engineer what was injected. Hand them the runbook and observe whether they can diagnose and resolve the issue using only the documented procedures. Every gap becomes an action item to update the runbook.

**Distributed tracing under failure** must maintain correlation across service boundaries even when services are failing. Tag chaos experiments in your logs, traces, and metrics so you can correlate failures with system behavior. OpenTelemetry provides the instrumentation standard — ensure that trace context propagates through retry attempts, circuit breaker fallbacks, and queue-based communication. The key test: given only your Grafana dashboards, Jaeger traces, and log aggregation, can an on-call engineer identify the root cause within 5 minutes? If not, your observability has gaps that the chaos experiment just revealed.

**The observability-chaos feedback loop** is the highest-value practice: every chaos experiment generates observability improvements. Netflix uses chaos experiments to continuously refine their monitoring. The pattern is: inject failure → discover that logs lack error context → add structured error fields → re-run experiment → verify improved diagnosis time. New Relic runs weekly chaos experiments in pre-production specifically to validate their monitoring infrastructure, tracking error rates, throughput, and response times across the full stack during simulated Aurora PostgreSQL failovers.

---

## Conclusion

Chaos engineering succeeds when it becomes **a continuous practice embedded in the development lifecycle**, not an annual event. The tools have matured — Chaos Mesh and LitmusChaos provide free, Kubernetes-native experiment orchestration; Toxiproxy makes network failure testing a standard part of integration suites; and Gremlin offers enterprise-grade reliability management for heterogeneous environments. The methodology is proven across Netflix, Google, Amazon, Goldman Sachs, and thousands of smaller organizations.

Three insights emerge from this analysis that most teams undervalue. First, **timeout hierarchy correctness** is the single most impactful resilience configuration — misconfigured timeouts cause more cascading failures than any other factor. Second, **database failure testing** — particularly connection pool exhaustion and failover behavior — reveals gaps in nearly every application because teams test query correctness but never connection lifecycle under failure. Third, **observability validation** is the meta-experiment: if your chaos tests don't also test your alerts, runbooks, and dashboards, you're only solving half the problem.

The goal is not to break systems. The goal is to **build justified confidence** that when real failures occur — and they will — your services degrade gracefully, your alerts fire promptly, your runbooks guide correct action, and your users experience degraded functionality rather than complete outage.