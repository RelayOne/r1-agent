# Secrets management across GCP, Cloudflare, and Fly.io

**Your three-platform stack has an asymmetric identity story: GCP offers full workload identity, Fly.io provides native OIDC tokens enabling keyless cloud access, but Cloudflare Workers lack any workload identity — making them the critical gap in a credential-free architecture.** The optimal unified strategy uses a central secrets hub (Infisical or GCP Secret Manager) that auto-syncs to platform-native stores, workload identity federation wherever possible, and tightly scoped static credentials only where unavoidable. This report covers all ten dimensions of secrets management in depth and concludes with a concrete architecture for your stack.

---

## 1. Secrets managers: six platforms compared

The market splits cleanly into three tiers: **cloud-native managers** (GCP Secret Manager, AWS Secrets Manager, Azure Key Vault) that are cheap, simple, and single-cloud; **Vault** as the most powerful but complex option; and **developer-focused platforms** (Infisical, Doppler) that prioritize multi-cloud sync and developer experience.

**Dynamic secrets are the key differentiator.** Only Vault offers comprehensive on-demand credential generation across **22+ backends** (databases, cloud IAM, PKI, SSH). Infisical added dynamic secrets for PostgreSQL, MySQL, and RabbitMQ but restricts them to Enterprise tier. GCP and AWS Secret Manager support rotation (generating new versions on a schedule) but not true on-demand ephemeral credentials. Azure Key Vault and Doppler lack dynamic secrets entirely.

| Dimension | Vault | GCP SM | AWS SM | Azure KV | Infisical | Doppler |
|---|---|---|---|---|---|---|
| Self-hosted | ✅ (BSL) | ❌ | ❌ | ❌ | ✅ (MIT) | ❌ |
| Pricing | ~$4,800/mo (HCP) | ~$31/mo (100 secrets) | ~$43/mo (100 secrets) | Per-operation | $18/identity/mo | $21/user/mo |
| Multi-cloud | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Dynamic secrets | ⭐⭐⭐⭐⭐ | ❌ | Limited | ❌ | ⭐⭐⭐ (Enterprise) | ❌ |
| Setup complexity | High | Low | Low | Low-Medium | Low | Very low |
| CF Workers sync | Via API | Via API | Via API | Via API | ✅ Native | CLI-based |
| Fly.io sync | Via API | Via API | Via API | Via API | ✅ Native | ✅ Native |

**For your GCP + Cloudflare + Fly.io stack**, Infisical stands out because it offers **native sync integrations with all three platforms** — auto-pushing secret changes to GCP Secret Manager, Cloudflare Workers secrets, and Fly.io app secrets. Doppler offers native Fly.io sync but requires CLI-based sync for Workers. Vault is overkill unless you need dynamic database credentials at scale. GCP Secret Manager is the cheapest option (~$2/month for small deployments) but requires custom sync scripts for non-GCP platforms.

IBM acquired HashiCorp in February 2025 for $6.4B. HCP Vault Secrets (the lightweight SaaS product) was **sunsetted in mid-2025**, leaving only the expensive HCP Vault Dedicated. **OpenBao**, the MPL-2.0 fork backed by the Linux Foundation, reached v2.5.2 by March 2026 with features like namespaces (formerly Enterprise-only) and horizontal read scalability — a viable free alternative for teams comfortable self-hosting.

---

## 2. Zero-downtime rotation: the dual-credential window

Every credential rotation must follow the **dual-acceptance window pattern**: generate new credential → deploy to target system (both old and new valid) → verify new credential works → revoke old credential. Skipping this sequence guarantees authentication failures.

**AWS Secrets Manager automates this via a four-step Lambda function**: `createSecret` (generate and store as `AWSPENDING`) → `setSecret` (update the target, e.g., database password) → `testSecret` (verify the new credential authenticates) → `finishSecret` (promote `AWSPENDING` to `AWSCURRENT`). Pre-built Lambda functions exist for RDS, Aurora, Redshift, and DocumentDB. The **alternating-users strategy** creates two database users (`appuser` and `appuser_clone`) and rotates their passwords alternately — the un-rotated user always has valid credentials, providing a zero-downtime guarantee.

**GCP Secret Manager uses Pub/Sub-driven rotation.** Configure a `rotation_period` on the secret; GCP publishes `SECRET_ROTATE` messages to a Pub/Sub topic; a Cloud Function subscribes, generates new credentials, updates the target system, and creates a new secret version. More assembly required than AWS, but fully flexible.

**Vault eliminates rotation entirely for databases** through dynamic secrets. Instead of rotating passwords on existing users, Vault creates brand-new database users on-demand with TTLs as short as one hour. When the lease expires, Vault drops the user. Each application instance gets unique credentials, enabling per-instance audit trails and individual revocation. Vault supports PostgreSQL, MySQL, MongoDB, Oracle, MSSQL, Redis, Elasticsearch, Snowflake, and more.

For **TLS certificates**, cert-manager in Kubernetes automates the entire lifecycle via ACME/Let's Encrypt. Certificates renew **30 days before expiry** (configurable via `renewBefore`). Ingress controllers like NGINX and Envoy watch for Secret changes and reload certificates without restart. Set `rotationPolicy: Always` to rotate both certificate and private key simultaneously.

**Connection pool invalidation during database credential rotation** is the hardest operational problem. Three strategies work in combination: set `maxLifetime` on connections shorter than the rotation interval (HikariCP defaults to 30 minutes), enable pre-ping health checks (`pool_pre_ping=True` in SQLAlchemy), and implement error-triggered credential re-fetch. The best solution is using a **credential proxy** like Cloud SQL Auth Proxy, which abstracts all credential management from the application — the app connects to `localhost` and the proxy handles authentication, token refresh, and TLS.

---

## 3. Eliminating secrets from CI/CD pipelines

**OIDC federation is the single highest-impact security improvement for CI/CD.** GitHub Actions, GitLab CI, and CircleCI can all exchange platform-issued OIDC tokens for short-lived cloud credentials, completely eliminating stored cloud keys.

For GCP, the flow works like this: GitHub Actions requests an OIDC JWT from `https://token.actions.githubusercontent.com` → the workflow sends this JWT to a GCP Workload Identity Pool → GCP validates the token, checks attribute conditions, and returns a short-lived access token via STS. Configuration requires creating a workload identity pool, an OIDC provider with attribute mapping, and an IAM binding that restricts which repositories can impersonate which service accounts. The `google-github-actions/auth@v2` action handles the exchange automatically. **Critical security requirement**: always set attribute conditions (e.g., `assertion.repository_owner == 'my-org'`) — without them, any GitHub repository could authenticate.

```yaml
permissions:
  id-token: write  # Required for OIDC token generation
steps:
  - uses: google-github-actions/auth@v2
    with:
      workload_identity_provider: "projects/PROJECT/locations/global/workloadIdentityPools/pool/providers/github"
      service_account: "github-sa@project.iam.gserviceaccount.com"
```

**GitHub Actions secrets have real limitations**: 100 secrets per scope (organization, repository, environment), 48 KB size limit, and automatic log masking that fails on encoded or transformed values. Environment-scoped secrets with required reviewers and branch restrictions are essential for production — they gate who can trigger deployments.

**Build-time secret injection is dangerous.** Docker `ARG` and `ENV` instructions bake secrets into image layers, extractable via `docker history --no-trunc`. Use BuildKit's `RUN --mount=type=secret` instead — the secret is available only during that specific RUN instruction and never persists in any layer. Runtime injection (environment variables at container start, mounted volumes) is strictly preferred because secrets never touch the image artifact.

---

## 4. How applications should access secrets

**Environment variables are the simplest but least secure pattern.** They're visible via `/proc/PID/environ`, inherited by child processes, logged in crash dumps, and exposed by `docker inspect`. OWASP explicitly recommends against them for sensitive values: "Environment variables are generally accessible to all processes and may be included in logs or system dumps."

**Mounted files on tmpfs are more secure.** Kubernetes Secrets mounted as volumes use RAM-backed storage (never written to disk), support POSIX file permissions, and can be updated without pod restart (within 30-60 seconds of kubelet sync — but not for `subPath` mounts). Volume-mounted secrets don't appear in process environment or container inspection.

**Direct API calls to a secrets manager** provide the best security properties: always-fresh values, fine-grained audit trails, and access to dynamic secrets. The tradeoff is availability dependency and **~50ms latency per call**. Implement caching with TTLs (AWS SDK defaults to 1 hour) and circuit breakers that fall back to cached values during outages. AWS provides official caching libraries for Java, Python, .NET, Go, and Ruby.

**The Vault Agent sidecar pattern bridges the gap** between API-based security and file-based simplicity. Vault Agent runs alongside the application, handles authentication automatically, renders secrets into local files via templates, and keeps them current. In Kubernetes, the Vault Agent Injector mutates pod specs to add init and sidecar containers, configured entirely through annotations:

```yaml
annotations:
  vault.hashicorp.com/agent-inject: "true"
  vault.hashicorp.com/role: "myapp-role"
  vault.hashicorp.com/agent-inject-secret-db: "secret/data/db/creds"
```

For **secret change notifications**, GCP Secret Manager publishes events to Pub/Sub (up to 10 topics per secret), enabling push-based cache invalidation. AWS routes events through EventBridge via CloudTrail. For Kubernetes, the Secrets Store CSI Driver polls external stores every 2 minutes and updates mounted volumes automatically.

---

## 5. Catching secrets before they ship

**A layered detection strategy combines speed with depth**: Gitleaks as a pre-commit hook (millisecond-scale on staged files, regex-based) plus TruffleHog in CI (800+ detectors with active verification against live APIs). An academic study found Gitleaks achieves **88% recall** while TruffleHog's verified mode dramatically reduces false positives by confirming whether detected credentials are actually valid.

Gitleaks configuration lives in `.gitleaks.toml`. Suppress false positives via global allowlists (path and regex exclusions), per-rule allowlists, and inline `gitleaks:allow` comments. detect-secrets (by Yelp) introduces the **baseline concept** — scan the entire codebase, create a `.secrets.baseline` file of known findings, then only flag new secrets in subsequent scans. This is ideal for legacy codebases with existing committed secrets.

**Scanning only current files is insufficient.** A secret committed and later removed still exists in git history, extractable via `git log -p`. Run `gitleaks detect --source /path/to/repo` for full history scanning, or `trufflehog git file:///path/to/repo --only-verified` for verified-only results. For CI, scan only the PR diff for speed: `trufflehog git file://. --since-commit=$BASE_SHA --fail`.

**The cardinal rule of secret remediation: rotate first, clean history second.** Once pushed, assume the secret is compromised — even in a private repo. The full flow: detect → **rotate immediately** → check audit logs for malicious use → optionally remove from history using BFG Repo Cleaner or `git filter-repo` → re-scan to verify → add pre-commit hooks to prevent recurrence. GitGuardian's 2026 report found **64% of secrets discovered in 2022 were still active four years later**, underscoring the remediation gap.

GitHub Advanced Security's secret scanning covers **400+ secret types** with push protection that blocks pushes containing detected secrets. The partner program automatically notifies service providers (AWS, Stripe, Slack) who can revoke exposed tokens. GitGuardian extends this to multi-VCS environments (GitLab, Bitbucket), Slack, Jira, and Docker images.

---

## 6. Database credentials: from static passwords to ephemeral users

**Vault's database secrets engine is the gold standard for eliminating static database credentials.** Configure a privileged connection, define roles with SQL templates and TTLs, and applications request fresh credentials on each startup:

```
vault write database/roles/readonly \
  db_name=my-postgresql \
  creation_statements="CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' \
    VALID UNTIL '{{expiration}}'; GRANT SELECT ON ALL TABLES IN SCHEMA public TO \"{{name}}\";" \
  default_ttl="1h" max_ttl="24h"
```

Each `vault read database/creds/readonly` call creates a unique database user. When the lease expires, Vault drops the user. Compromised credentials can be individually revoked without affecting other instances.

**GCP Cloud SQL IAM authentication** eliminates passwords entirely by using **OAuth 2.0 access tokens** (1-hour lifetime). The Cloud SQL Auth Proxy handles token refresh automatically with the `--auto-iam-authn` flag. Applications connect to `localhost`; the proxy manages TLS, authorization, and credential lifecycle transparently. In Kubernetes, deploy the proxy as an init container with `restartPolicy: Always`.

**AWS RDS IAM authentication** generates 15-minute authentication tokens via `aws rds generate-db-auth-token`. The token authenticates the initial connection only — established sessions persist beyond token expiry. AWS recommends connection pooling or **RDS Proxy** for high-connection-rate workloads (IAM auth adds overhead, with a recommended limit of 200 new connections/second).

**Store connection components as separate secrets** (host, port, user, password, database name) rather than monolithic connection strings. This enables rotating passwords without touching other components, grants finer-grained access control (some services need only the host, not the password), and simplifies debugging. Construct the connection string in application code at runtime.

---

## 7. API key lifecycle: generation through revocation

**Generate keys with at least 256 bits of entropy** using cryptographically secure sources: `crypto.randomBytes(32)` (Node.js), `secrets.token_urlsafe(32)` (Python), or `crypto/rand.Read` (Go). Never use `Math.random()` or language-level `random` modules.

**Hash keys with SHA-256 before storage — never store plaintext.** Unlike passwords, API keys have high entropy, making bcrypt's intentional slowness unnecessary. The pattern: generate raw key → compute `SHA-256(raw_key)` → store only the hash → show the key to the user exactly once → on each request, hash the incoming key and compare. Stripe pioneered this approach and remains the industry model.

**Key prefixes enable instant identification and leak detection.** Stripe uses `sk_live_`, `sk_test_`, `pk_live_`, `pk_test_`. GitHub uses `ghp_` (personal access tokens), `gho_` (OAuth tokens), `ghs_` (server-to-server tokens), embedding a CRC32 checksum in the last 6 characters that reduces secret scanning false positive rates to ~0.5%. Design your own scheme: `{service}_{type}_{environment}_` with `_` as separator (enables double-click selection of the full token).

**Per-key permission scoping limits blast radius.** GitHub's fine-grained PATs set permissions per-repository with granular categories (`actions: write`, `metadata: read`). Implement OAuth-style scope strings stored alongside the key hash: `{"key_hash": "abc...", "scopes": ["read:users", "write:payments"]}`. Enforce mandatory expiration — keys without `expires_at` timestamps are a persistent liability.

**Revocation propagation in distributed systems** is fundamentally a cache invalidation problem. Use **short TTL caches (60-300 seconds)** on key validation to bound the maximum window during which a revoked key remains functional. For critical systems, validate against the authoritative store on every request with no caching. Push revocation events via Redis Pub/Sub or Kafka for active invalidation across gateway instances.

Rate limiting should be **per-key and tier-based**, implemented with Redis using sliding window or token bucket algorithms. Return standard headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`. Use Lua scripts for atomic read-modify-write operations to prevent race conditions in distributed deployments.

---

## 8. Workload identity: your stack's biggest asymmetry

### SPIFFE/SPIRE for cross-platform identity

SPIFFE (a CNCF graduated project) provides a universal identity framework: every workload gets a **SPIFFE ID** (`spiffe://trust-domain/workload-path`) and a short-lived **SVID** (X.509 certificate or JWT) that proves its identity. SPIRE implements this through two-phase attestation: **node attestation** (proving the host's identity via platform-specific evidence like AWS instance metadata or Kubernetes tokens) followed by **workload attestation** (verifying the process's properties — namespace, service account, container image). Use SPIFFE/SPIRE when you need a uniform identity layer across heterogeneous infrastructure; use cloud-native identity for single-cloud deployments.

### GCP Workload Identity Federation

For GKE, Workload Identity maps Kubernetes service accounts to GCP service accounts through a metadata server that exchanges K8s JWTs for short-lived federated access tokens. **No keys to manage, no secrets to rotate.** For external workloads, Workload Identity Federation accepts OIDC, SAML, AWS, and X.509 tokens from external identity providers, validates them against configured attribute conditions, and issues short-lived GCP access tokens.

### The platform-by-platform reality for your stack

**GCP (GKE/Cloud Run/Cloud Functions)**: Full workload identity. Zero static credentials needed. This is the gold standard.

**Fly.io has native OIDC token issuance** — a critical finding. Fly Machines can request OIDC tokens via a local Unix socket (`POST /.fly/api → http://localhost/v1/tokens/oidc`). Tokens include `sub` in the format `org:app:machine`, are valid for 15 minutes, and support custom audiences. For AWS, Fly.io's init process handles everything automatically: set `AWS_ROLE_ARN` as an environment variable and the platform configures `AWS_WEB_IDENTITY_TOKEN_FILE` transparently. **For GCP, you can achieve keyless access**: create a GCP Workload Identity Pool with an OIDC provider pointing at `https://oidc.fly.io/<ORG_SLUG>`, map attributes, and use executable-sourced credentials with a small helper binary that calls the Fly.io OIDC endpoint.

**Cloudflare Workers have no native workload identity** — this is the most significant gap. Workers cannot issue OIDC tokens, have no metadata server, and run in V8 isolates without filesystem or Unix socket access. A community feature request for "Automatic JWT OIDC Tokens in Workers" exists but remains unimplemented. Current options for GCP access require static credentials:

- **Service account key in Worker secret**: Store GCP SA key JSON, sign JWTs using Web Crypto API, exchange for OAuth tokens. Most common pattern but involves static credentials.
- **Credential vending machine**: Deploy a token broker on Cloud Run or Fly.io (with workload identity), issue short-lived GCP tokens to Workers over HTTPS. Eliminates static GCP credentials in Workers but adds infrastructure.
- **Cloudflare Secrets Store** (beta, launched April 2025): Account-level centralized secrets with RBAC and audit logging, but still stores static values — it doesn't solve the identity problem.

| Platform | Native OIDC | GCP Keyless Access | Effort |
|---|---|---|---|
| GKE | ✅ Automatic | ✅ Automatic | Trivial |
| Fly.io | ✅ Via `/.fly/api` | ✅ Via WIF + helper binary | Moderate |
| Cloudflare Workers | ❌ None | ❌ Requires static SA key or vending machine | High |

---

## 9. Developer environments: from .env sprawl to centralized vaults

The `.env` file pattern remains ubiquitous but dangerous. Commit `.env.example` with placeholders as documentation, add `.env` to `.gitignore` before the first commit, and use pre-commit hooks to catch accidental commits. GitGuardian found that **64% of secrets discovered in 2022 remained active and exploitable in 2026** — credential sprawl via Slack messages, Confluence pages, and local files is the primary vector.

**Team vault solutions eliminate .env file sharing entirely.** 1Password's CLI (`op run --env-file=.env`) resolves secret references (`op://vault/item/field`) at runtime, injecting values as environment variables for the subprocess only. Bitwarden Secrets Manager (separate from the password manager) offers machine accounts with SDKs in 9+ languages. Infisical CLI (`infisical run -- npm start`) and Doppler CLI (`doppler run -- npm start`) provide similar injection with the advantage of environment switching (`--env=staging`). Doppler uniquely supports `--watch` for auto-restarting on secret changes.

**direnv bridges local development and secrets managers** elegantly. The `.envrc` file (a shell script) executes on directory entry and unloads on exit, with a security gate (`direnv allow`) preventing unauthorized execution. Patterns that work well:

```bash
# .envrc — fetch secrets from 1Password
export DB_PASSWORD=$(op read "op://dev/database/password")
export API_KEY=$(op read "op://dev/api-service/key")
```

```bash
# .envrc — fetch from Doppler
direnv_load doppler run -- direnv dump
```

The `op` CLI adds ~1 second latency per call, acceptable because direnv only runs on directory change. For multiple secrets, use `op inject` (single call) rather than multiple `op read` calls.

**Best practice for credential tiers**: personal credentials for staging and above (individual audit trails, isolated blast radius), shared credentials for truly isolated local development only. The ideal is dynamic credentials — each developer gets unique, short-lived database access via Vault's database secrets engine.

---

## 10. When secrets breach: detection through recovery

**Detection starts with automated scanning.** GitHub secret scanning covers 400+ secret types with push protection that blocks pushes before they reach the repository. GitGuardian monitors public GitHub continuously (3+ billion commits scanned since 2018) with a mean-time-to-detect of seconds. AWS automatically emails account owners when IAM keys are publicly exposed and generates `AWS_RISK_CREDENTIALS_EXPOSED` health events.

**The response sequence is non-negotiable: rotate before investigating.** Automated bots scan public repositories continuously and can exploit exposed credentials within minutes. The full procedure: detect → assess scope (≤5 minutes) → **rotate immediately** → deploy new credentials → verify systems function → then investigate audit logs. Never delay rotation for investigation.

**Blast radius assessment requires answering five questions**: What did this credential access? What was the exposure window? Was it actually used by an attacker (check Cloud Audit Logs, CloudTrail for anomalous IPs or unusual API calls)? What data could have been exfiltrated? And critically — **did the attacker create persistence mechanisms?** MITRE ATT&CK T1098.001 documents how attackers add additional access keys or service principal secrets as backdoors. Rotating the compromised credential alone is insufficient; check for attacker-created credentials.

**Post-incident review should be blameless and systemic.** Ask why a static key existed instead of workload identity, why rotation wasn't automated, why pre-commit hooks weren't in place. Track four metrics: time to detect, time to rotate, blast radius, and recurrence rate. GDPR requires supervisory authority notification within **72 hours** of awareness; CCPA requires consumer notification within **30 days** (as of SB 446, January 2026).

---

## Your unified architecture: Infisical hub with workload identity at the edges

For a deployment spanning GCP, Cloudflare Workers, and Fly.io, the recommended architecture uses **Infisical as the central management plane** syncing to platform-native stores, with **workload identity federation** eliminating static credentials wherever the platform supports it.

### How secrets flow

```
Infisical (Central Source of Truth)
  ├─ Auto-sync → GCP Secret Manager → consumed by GKE/Cloud Run/Functions via Workload Identity
  ├─ Auto-sync → Cloudflare Workers secrets → consumed via env.SECRET_NAME (zero latency)
  └─ Auto-sync → Fly.io app secrets → consumed via process.env (injected at boot)
```

Changing a secret in Infisical propagates automatically to all three platforms. Infisical provides versioning, RBAC, audit logs, and approval workflows in a single pane. Self-hosted on GCP (Cloud Run or GKE), the total cost is **~$7-17/month** including GCP Secret Manager.

### Credential-free connections

- **GKE/Cloud Run/Functions → GCP resources**: Workload Identity Federation. Zero credentials.
- **Fly.io → GCP resources**: Fly.io OIDC tokens + GCP Workload Identity Federation. **Zero static credentials** with a small Go helper binary.
- **GitHub Actions → GCP**: OIDC federation via `google-github-actions/auth@v2`. Zero credentials.
- **Fly.io → AWS resources**: Set `AWS_ROLE_ARN` environment variable; Fly.io init handles OIDC exchange automatically.

### Where static credentials remain unavoidable

Only **four bootstrap credentials** are needed for the entire system:

- **Infisical → Cloudflare**: A scoped Cloudflare API token (Workers secrets write permission only)
- **Infisical → Fly.io**: A Fly.io access token
- **Infisical → GCP**: A GCP service account key (or WIF if Infisical runs on GCP infrastructure)
- **Cloudflare Workers → GCP** (if Workers need direct GCP API access): A GCP service account key in Worker secrets, with OAuth token caching (1-hour TTL) to minimize auth overhead

Automate rotation of these four credentials on a 90-day cycle via a GitHub Actions workflow using GCP Workload Identity Federation (the CI pipeline itself needs no static credentials). Monitor service account key age in Cloud Audit Logs and alert when any bootstrap credential exceeds its rotation threshold.

### The Cloudflare Workers workaround

For Workers that need GCP resource access, two patterns in order of preference:

1. **Credential vending machine** (preferred): Deploy a lightweight token broker on Cloud Run (with Workload Identity). Workers call the broker over HTTPS, authenticated via a shared secret in the Secrets Store. The broker issues short-lived GCP access tokens. Blast radius: only the shared secret is static; GCP tokens expire in 1 hour.

2. **Static service account key with caching**: Store GCP SA key JSON as a Worker secret. Sign JWTs with Web Crypto API, exchange for OAuth tokens, cache in the Workers Cache API for up to 1 hour. Simpler but requires key rotation automation.

### What to implement first

The highest-impact changes in priority order: migrate all CI/CD cloud authentication to OIDC federation (eliminates the most commonly leaked credential type), configure Fly.io → GCP access via OIDC + Workload Identity Federation (eliminates a static service account key), deploy pre-commit hooks with Gitleaks plus TruffleHog in CI, and set up Infisical (or Doppler) as the central sync hub. Together, these reduce your static credential surface from potentially dozens of keys to four tightly scoped bootstrap tokens — and position you to eliminate even those as Cloudflare's identity story matures.