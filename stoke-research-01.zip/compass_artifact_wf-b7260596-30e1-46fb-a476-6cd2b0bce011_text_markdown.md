# Kafka and event-driven architecture: the definitive operational reference

**Apache Kafka and event-driven systems fail in predictable, well-documented ways — and nearly every failure traces back to misconfigured timeouts, ignored ordering constraints, or missing idempotency.** This reference distills the deepest operational knowledge across consumer rebalancing, exactly-once semantics, schema evolution, partition design, dead letter queues, the outbox and saga patterns, event sourcing, backpressure, and tooling — all scoped to Go and TypeScript services backed by PostgreSQL. Every section includes specific configurations, failure scenarios, and code patterns ready for encoding into AI coding agent rules.

---

## 1. Consumer group rebalancing: the silent availability killer

Rebalancing is Kafka's mechanism for distributing partitions across consumers. Misconfigured rebalancing is the **#1 cause of Kafka consumer outages**, frequently producing cascading failures that compound rather than resolve.

### Rebalancing strategies and when each breaks

**Eager rebalancing** (RangeAssignor, RoundRobinAssignor, StickyAssignor) forces every consumer to stop, revoke all partitions, and rejoin through a JoinGroup→SyncGroup barrier. A single slow consumer blocks the entire group. With 100+ consumers, this produces **45+ minute outages** where throughput drops to zero. One documented production incident involved 25 simultaneous pod restarts triggering a rebalance storm that caused a 45-minute total processing blackout.

**Cooperative sticky rebalancing** (CooperativeStickyAssignor, available since Kafka 2.4, default in 3.0+) uses a two-phase incremental protocol. Phase 1 identifies only the partitions that must move and revokes them. Phase 2 reassigns revoked partitions. Unaffected consumers never stop processing. The critical upgrade path requires a **two-bounce rolling restart** — first add CooperativeStickyAssignor alongside the old assignor, restart all consumers, then remove the old assignor and restart again. Mixing eager and cooperative protocols in the same group causes undefined behavior.

**Static membership** (`group.instance.id`, KIP-345) assigns a persistent identity to each consumer. When a static member disconnects and reconnects within `session.timeout.ms`, it silently rejoins with the same partition assignment — no rebalance. This is essential for Kubernetes environments where pod restarts are routine.

**KIP-848 server-side rebalancing** reached GA in Kafka 4.0 (March 2025) and will become the default in Kafka 5.0. It moves rebalance logic from clients to the broker-side group coordinator using a new `ConsumerGroupHeartbeat` API. There is no JoinGroup/SyncGroup barrier. Performance claims include **up to 20x faster rebalances** — a group with 10 consumers adding 900 partitions completes in 5 seconds instead of 103. Enable it with `group.protocol=consumer`. Known limitations: client-side assignors not yet supported (KAFKA-18327), rack-aware strategies incomplete (KAFKA-17747), and Kafka Streams support is in progress via KIP-1071.

### The three critical timeouts

| Parameter | Controls | Default | Thread |
|-----------|----------|---------|--------|
| `session.timeout.ms` | Broker detects dead consumer (no heartbeats) | 45s (Kafka 3.0+) | Heartbeat thread |
| `heartbeat.interval.ms` | Heartbeat frequency | 3s | Heartbeat thread |
| `max.poll.interval.ms` | Max time between poll() calls before consumer is kicked | 300s (5 min) | Application thread |

The most dangerous misconfiguration is when `max.poll.records × per_record_processing_time > max.poll.interval.ms`. The consumer appears healthy (heartbeats continue) but gets kicked for slow processing, triggering a rebalance that redistributes load to remaining consumers, which then also exceed their poll intervals — a classic **rebalance storm**.

### Tuning recommendations by workload

**Low-latency (< 100ms per record):**
```properties
session.timeout.ms=10000
heartbeat.interval.ms=3000
max.poll.interval.ms=30000
max.poll.records=100
partition.assignment.strategy=org.apache.kafka.clients.consumer.CooperativeStickyAssignor
```

**Batch processing (seconds per batch):**
```properties
session.timeout.ms=45000
heartbeat.interval.ms=10000
max.poll.interval.ms=600000
max.poll.records=500
```

**Kubernetes rolling deployments:**
```properties
group.instance.id=${HOSTNAME}
session.timeout.ms=300000
heartbeat.interval.ms=10000
```

### Preventing rebalance storms

Never scale out during an active rebalance — wait for the group to stabilize. Limit concurrent pod restarts to 1–2 at a time using PodDisruptionBudgets. Always use CooperativeStickyAssignor minimum, or KIP-848 on Kafka 4.0+. Reduce `max.poll.records` to ensure `poll()` completes within `max.poll.interval.ms`. Monitor `kafka.consumer:type=consumer-coordinator-metrics,name=rebalance-rate-per-hour` and consumer lag as primary health indicators.

---

## 2. Exactly-once semantics: precision costs and zombie fencing

Kafka's exactly-once semantics (EOS) builds on three layers: idempotent producers, transactional APIs, and `read_committed` consumer isolation. **EOS only covers Kafka-to-Kafka pipelines** — for database writes, you need the outbox pattern plus consumer-side idempotency.

### The implementation stack

**Idempotent producers** (enabled by default since Kafka 3.0) assign each producer a Producer ID (PID) and sequence numbers per partition. Brokers reject duplicate batches. Overhead is negligible — a few extra bytes per batch. The limitation is that idempotency is per-partition, per-session. Producer restarts reset the PID.

**Transactional producers** add cross-partition atomicity. The lifecycle: `initTransactions()` performs zombie fencing by bumping the epoch, `beginTransaction()` starts a local transaction, `send()` produces within it, `sendOffsetsToTransaction(offsets, consumer.groupMetadata())` atomically links consumer offsets, and `commitTransaction()` executes a two-phase commit through the transaction coordinator. The coordinator writes to `__transaction_state` (default: 50 partitions, replication factor 3).

**Consumer `isolation.level=read_committed`** filters aborted and in-progress transaction records using the Last Stable Offset (LSO). Read-committed consumers may lag behind read-uncommitted by the duration of open transactions. Monitor LSO lag — long-running transactions block all read-committed consumers.

### Performance overhead and decision framework

Idempotent producer overhead is essentially zero. Transactional overhead ranges from **3–20%** depending on batch size and commit frequency — **3% at 100ms commit intervals** with 1KB messages per Confluent benchmarks. The overhead amortizes across messages in a transaction, so larger batches reduce the proportional cost. Kafka Streams EOS v2 (`processing.guarantee=exactly_once_v2`, requiring broker 2.5+) uses one producer per thread instead of per task, dramatically improving resource efficiency.

**Use EOS for** Kafka-to-Kafka pipelines where duplicates are intolerable (financial calculations, inventory counts, account balances). **Use at-least-once plus idempotency for** external system writes, high-throughput scenarios where 3–5% overhead matters, and when downstream operations are naturally idempotent (upserts, last-writer-wins). The outbox pattern (Section 6) is the correct mechanism for atomic database-and-Kafka writes.

### Zombie fencing mechanics

When `initTransactions()` is called, the transaction coordinator increments the epoch for that `transactional.id`. Any producer with the same ID but an older epoch is a zombie — its writes are rejected with `ProducerFencedException`. The critical requirement: use the **same transactional.id for the same input partition** (e.g., `"myapp-" + inputTopic + "-" + partition`). Different transactional.ids across workers processing the same partition means fencing cannot work.

Handle `ProducerFencedException` as **fatal** — close the producer and create a new instance. Handle `KafkaException` as abortable — call `abortTransaction()` and retry. If `transactional.id.expiration.ms` (default 7 days) expires, the producer is fenced on next send; for infrequent producers, increase this value.

### Go transactional producer (confluent-kafka-go)

```go
producer, _ := kafka.NewProducer(&kafka.ConfigMap{
    "bootstrap.servers": "kafka:9092",
    "transactional.id":  "my-go-txn-producer",
    "enable.idempotence": true,
})
defer producer.Close()
producer.InitTransactions(nil)

consumer, _ := kafka.NewConsumer(&kafka.ConfigMap{
    "bootstrap.servers":  "kafka:9092",
    "group.id":           "my-go-group",
    "enable.auto.commit": false,
    "isolation.level":    "read_committed",
})

// Consume-transform-produce loop
producer.BeginTransaction()
producer.Produce(&kafka.Message{
    TopicPartition: kafka.TopicPartition{Topic: &outputTopic, Partition: kafka.PartitionAny},
    Value:          transformedValue,
}, nil)
consumerMetadata, _ := consumer.GetConsumerGroupMetadata()
producer.SendOffsetsToTransaction(nil, offsets, consumerMetadata)
err := producer.CommitTransaction(nil)
if err != nil {
    kafkaErr := err.(kafka.Error)
    if kafkaErr.IsFatal() { /* close and recreate */ }
    if kafkaErr.TxnRequiresAbort() { producer.AbortTransaction(nil) }
}
```

Note: `segmentio/kafka-go` has limited transaction support as of 2025 — for EOS in Go, **confluent-kafka-go is required**.

### TypeScript transactional producer (KafkaJS / confluent-kafka-javascript)

```typescript
const producer = kafka.producer({
  transactionalId: 'my-ts-txn-producer',
  maxInFlightRequests: 1,
  idempotent: true,
});
await producer.connect();

const transaction = await producer.transaction();
try {
  await transaction.send({ topic: 'output-topic', messages: [{ value: transformed }] });
  await transaction.sendOffsets({
    consumerGroupId: 'eos-group',
    topics: [{ topic: batch.topic, partitions: [{ partition: batch.partition, offset: nextOffset }] }],
  });
  await transaction.commit();
} catch (e) {
  await transaction.abort();
  throw e;
}
```

---

## 3. Schema registry: compatibility modes and format trade-offs

Schema management determines whether deployments succeed or break consumers silently. The Confluent Schema Registry enforces compatibility at registration time, but only if you configure it correctly.

### Avro vs Protobuf vs JSON Schema

**Avro** offers the best schema evolution flexibility — writer and reader schemas can differ, with Avro resolution rules translating between them. Type widening (`int→long→float→double`) and field renaming via `aliases` are supported. Payloads are the most compact (no field tags, position-based encoding). Best for data pipelines and Kafka-centric architectures.

**Protobuf** provides the strongest typing and code generation ecosystem. Evolution works through stable field numbers — adding optional fields is safe, removed fields must use `reserved`. **Renaming fields is safe** because the wire format uses numbers, not names. For Go, `protoc-gen-go` provides first-class support. For TypeScript, `ts-proto` or `buf` generate idiomatic code. Clear Street reported that migrating from Avro to Protobuf on Kafka dropped network usage from **32–64 KB/s to 10–12 KB/s** while improving development velocity.

**JSON Schema** is the simplest to adopt but the least efficient — text-based encoding, no formal resolution mechanism, and the weakest evolution guarantees. Use it for human-readable debugging, configuration events, or when performance is not critical.

### Compatibility modes and what breaks

| Mode | Rule | Allowed changes | Breaks when |
|------|------|----------------|-------------|
| **BACKWARD** (default) | New schema reads old data | Delete fields; add optional fields with defaults | Adding required field without default |
| **BACKWARD_TRANSITIVE** | New reads all previous | Same, checked against all versions | Any break with any prior version |
| **FORWARD** | Old schema reads new data | Add fields; delete optional fields with defaults | Deleting required field without default |
| **FORWARD_TRANSITIVE** | All previous read new data | Same, against all versions | Break with any prior version |
| **FULL** | Both backward and forward | Only add/delete optional fields with defaults | Any change not both-way compatible |
| **FULL_TRANSITIVE** | Full with all versions | Same, against all versions | Break with any version in either direction |
| **NONE** | No checks | Anything | Nothing — dangerous in production |

For Protobuf specifically, Confluent recommends **BACKWARD_TRANSITIVE** because adding new message types is not forward-compatible.

### Breaking changes by format

**Avro**: Removing a field without a default breaks backward compatibility. Adding a field without a default breaks backward compatibility. Changing a field type incompatibly (e.g., `string→int`) always breaks. Removing an enum symbol breaks. Type widening and reordering fields are safe.

**Protobuf golden rule: never change field numbers.** Reusing a reserved field number causes old messages to parse into wrong fields. Use `reserved` declarations for removed fields and names. Renaming fields is safe (wire format ignores names). Adding fields is safe. Compatible type changes (`int32→int64`) are safe if values fit.

**JSON Schema**: Removing or adding `required` properties breaks. Changing property types breaks. Making validation stricter breaks. Adding optional properties and making validation looser are safe.

### Subject naming strategies

**TopicNameStrategy** (default) creates one subject per topic (`{topic}-value`). Use when each topic carries a single event type. **RecordNameStrategy** creates one subject per record type — the same schema applies across all topics. Use for event-sourcing patterns with multiple event types per topic. **TopicRecordNameStrategy** creates subjects per topic-and-record combination — use when you need multiple event types per topic with independent evolution per topic. Configure in producers:

```go
// Go (confluent-kafka-go)
"value.subject.name.strategy": "io.confluent.kafka.serializers.subject.RecordNameStrategy"
```

### Schema registry HA

Deploy 3+ instances behind a load balancer. Only the leader writes to the `_schemas` Kafka topic; all instances serve reads from their local cache. Client-side schema caching uses an LRU cache with no TTL needed (schemas are immutable once registered). If the registry goes down temporarily, cached schemas allow continued operation for known IDs. The `_schemas` topic must be compacted with `min.insync.replicas=2` and `replication.factor=3`.

---

## 4. Partition key design: avoiding hot partitions and understanding compaction

### Hot partition anti-patterns

Customer ID as partition key with Zipfian distribution is the most common failure — a few enterprise customers generate **80%+ of traffic**, concentrating load on 1–2 partitions while others idle. Timestamps as keys concentrate all current writes on a single partition. Country codes create 3–4 hot partitions out of 12. Binary flags (`true`/`false`) create only 2 effective partitions regardless of partition count.

Detect skew by monitoring per-partition lag variance. If any partition's lag deviates more than **20% from the mean**, investigate. Use `kafka-consumer-groups.sh --describe` and check the LAG column across partitions.

### Murmur2 partitioner and cross-language compatibility

The default Java partitioner uses `Utils.toPositive(Utils.murmur2(keyBytes)) % numPartitions`. **Critical cross-language issue**: librdkafka (used by confluent-kafka-go, Python, .NET) defaults to CRC32, not Murmur2. The same key produces different partition assignments across languages. Fix by setting `partitioner=murmur2_random` in librdkafka-based clients:

```go
config := &kafka.ConfigMap{
    "bootstrap.servers": "localhost:9092",
    "partitioner":       "murmur2_random", // CRITICAL for Java compatibility
}
```

### Mitigation strategies

**Key salting** spreads hot keys across multiple partitions by appending a deterministic suffix: `fmt.Sprintf("%s:%d", key, hash(key) % numSalts)`. The trade-off is that salting breaks per-key ordering — downstream consumers must merge salted partitions if ordering matters.

**Compound keys** increase cardinality while preserving meaningful ordering: `"region:customerId"` orders by customer within region. Use only the prefix for partitioning if per-entity ordering is required.

**Null keys** trigger round-robin (pre-2.4) or sticky partitioning (2.4+, batching multiple null-key messages to the same partition before switching). Never use null keys when ordering matters.

### Partition count planning

Partitions can increase but **never decrease** without creating a new topic and migrating data. Increasing partitions also breaks existing key→partition mappings. Start with **6–12 partitions** per topic for moderate workloads. Keep roughly 100 partitions per broker. Over-provision by 1.5–2x expected needs. The formula: `partitions = max(target_throughput / per_partition_producer_throughput, target_throughput / per_partition_consumer_throughput)`.

### Log cleanup policies

**`compact`** keeps only the latest value per key. Tombstones (key + null value) signal deletion and are retained for `delete.retention.ms` (default 24h). The active segment is never compacted. Compaction is not instantaneous — multiple records per key may exist at any time. Set `min.cleanable.dirty.ratio=0.5`, `min.compaction.lag.ms=3600000` (1h buffer for consumers), and `max.compaction.lag.ms=86400000` (force within 24h). Topics without keys cannot be compacted.

**`delete`** removes segments older than `retention.ms` (default 7 days) or exceeding `retention.bytes`. **`compact,delete`** compacts first, then deletes based on retention — useful for TTL-bounded state or GDPR compliance.

---

## 5. Dead letter queues: taxonomy, metadata, and retry chains

### DLQ topology and naming

Use per-topic DLQ naming: `{topic}.dlq`. For automated retry chains (Uber's production pattern), create tiered retry topics with increasing delays:

- `{topic}.retry.1` → 10-second delay
- `{topic}.retry.2` → 10-minute delay
- `{topic}.retry.3` → 1-hour delay
- `{topic}.dlq` → manual intervention only

Each retry level uses a blocking consumer sleep to enforce the delay. Classify errors immediately: **permanent errors** (deserialization failures, business validation, schema mismatches) go directly to DLQ with no retries. **Transient errors** (network timeouts, database downtime, rate limiting) enter the retry chain with exponential backoff plus jitter: `delay = min(base × 2^attempt, maxDelay) × (0.5 + random() × 0.5)`.

### DLQ metadata schema

Preserve all context using Kafka headers so the original message value remains unmodified:

```
Headers:
  dlq.original.topic:        "orders"
  dlq.original.partition:    "3"
  dlq.original.offset:       "12345"
  dlq.original.timestamp:    "1706123456789"
  dlq.error.reason:          "VALIDATION_ERROR"
  dlq.error.message:         "Invalid customer ID: -1"
  dlq.error.type:            "PERMANENT"
  dlq.retry.count:           "3"
  dlq.consumer.group:        "order-processor"
  dlq.correlation.id:        "trace-abc-123"
Key:   (original key, unchanged)
Value: (original value, unchanged)
```

### Poison message detection

The most dangerous poison messages crash consumers on processing. Track the offset being processed; on restart, if the same offset causes a crash again, increment a crash counter. After N crashes (typically 3), skip the message to DLQ. Implement with an external crash counter stored in Redis or PostgreSQL.

### Alerting thresholds

Alert when DLQ ingestion rate exceeds **5% of main topic volume**. Alert when DLQ has unprocessed messages for more than 30 minutes. Alert when a single error type dominates more than 50% of DLQ entries (indicates a systemic issue, not individual message problems). Monitor DLQ message age — stale DLQ messages represent unresolved data quality issues.

### Go DLQ implementation

The `ricardo-ch/go-kafka` library provides built-in DLQ support with auto-created dead letter topics, configurable `ConsumerMaxRetries`, `DurationBeforeRetry`, and `ExponentialBackoff`. The `uber-go/kafka-client` provides `NewRetryDLQMultiplexer(retryTopic, dlqTopic, threshold)` for routing based on retry count. For custom implementations with sarama or kafka-go:

```go
func processWithDLQ(msg *kafka.Message, maxRetries int) {
    for attempt := 0; attempt < maxRetries; attempt++ {
        err := processMessage(msg)
        if err == nil { commitOffset(msg); return }
        if isPermanentError(err) { sendToDLQ(msg, err); commitOffset(msg); return }
        time.Sleep(time.Duration(math.Pow(2, float64(attempt))) * time.Second)
    }
    sendToDLQ(msg, lastErr)
    commitOffset(msg)
}
```

### TypeScript DLQ implementation

Use `kafkajs-dlq` for KafkaJS or build custom with confluent-kafka-javascript:

```typescript
const processWithDLQ = async (message: KafkaMessage, maxRetries = 3) => {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      await processMessage(message);
      return;
    } catch (err) {
      if (isPermanentError(err)) { await sendToDLQ(message, err); return; }
      await sleep(Math.min(1000 * Math.pow(2, attempt), 30000));
    }
  }
  await sendToDLQ(message, lastErr);
};
```

---

## 6. The outbox pattern: atomic database-and-Kafka writes

The outbox pattern is the **only correct way** to atomically commit a database write and publish a Kafka event. Write the business data and an outbox row in the same PostgreSQL transaction, then relay the outbox row to Kafka separately.

### Outbox table schema

```sql
CREATE TABLE outbox_events (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sequence_id     BIGSERIAL NOT NULL,
    aggregate_type  VARCHAR(255) NOT NULL,       -- routes to Kafka topic
    aggregate_id    VARCHAR(255) NOT NULL,        -- becomes Kafka message key
    event_type      VARCHAR(255) NOT NULL,
    payload         JSONB NOT NULL,
    headers         JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    published_at    TIMESTAMPTZ
);

CREATE INDEX idx_outbox_unpublished
    ON outbox_events (sequence_id)
    WHERE published_at IS NULL;
```

Use `clock_timestamp()` instead of `NOW()` — `NOW()` returns the same value for all statements within a transaction, causing ordering ambiguity. Use `sequence_id` (BIGSERIAL) for reliable ordering, not timestamps.

### CDC vs polling: choosing the relay mechanism

**Debezium CDC** reads the PostgreSQL WAL and streams changes to Kafka with **~10–50ms latency**, zero table-level database load, and perfect transaction commit ordering. Configure with `plugin.name=pgoutput`, `slot.name=outbox_slot`, and the Outbox Event Router SMT to route `aggregate_type` to Kafka topics and `aggregate_id` to message keys. The critical risk is **WAL bloat** — replication slots retain all WAL segments until Debezium catches up. Set `heartbeat.interval.ms=10000` with a heartbeat query to prevent unbounded growth on idle databases. Monitor `pg_replication_slots` for `restart_lsn` drift.

**Polling** uses `SELECT ... FOR UPDATE SKIP LOCKED` to claim unpublished rows:

```sql
BEGIN;
SELECT id, aggregate_type, aggregate_id, event_type, payload
FROM outbox_events
WHERE published_at IS NULL
ORDER BY sequence_id ASC
LIMIT 100
FOR UPDATE SKIP LOCKED;
-- Publish to Kafka...
UPDATE outbox_events SET published_at = NOW() WHERE id = ANY($1);
COMMIT;
```

Polling is simpler to operate (no Kafka Connect cluster, no WAL configuration) but has 1–5 second latency floor and creates constant database load. Martin Kleppmann has noted that polling has fundamentally poor ordering semantics — concurrent transactions can commit in different order than their sequence numbers, potentially causing the relay to miss messages. CDC solves this inherently.

**Choose CDC** for high-throughput (> 1,000 events/sec), strict ordering requirements, or when database load is a concern. **Choose polling** for simpler systems, teams without CDC operational experience, or when 1–5 second eventual consistency is acceptable.

### Outbox cleanup

Partition the outbox table by date range for efficient cleanup via `DROP PARTITION` instead of DELETE statements, which cause vacuum pressure. One fintech company discovered their outbox table reached **2 billion rows** without cleanup, causing severe performance degradation. For CDC: INSERT and DELETE the outbox row in the same transaction — Debezium captures the INSERT from WAL, and the table stays permanently empty.

---

## 7. Saga patterns: orchestration, compensation, and Temporal

### Orchestration vs choreography decision framework

**Use orchestration** when workflows have more than 3–4 steps, conditional branching, global timeout policies, or when on-call engineers need dashboard-level visibility. The orchestrator explicitly drives the workflow, issues commands, waits for responses, and triggers compensation on failure. **Use choreography** for 2–3 step linear flows with maximum throughput requirements where different teams own different services. Most production systems at scale adopt a **hybrid** — orchestration for complex business-critical workflows (payments, orders), choreography for high-throughput loosely-coupled flows (notifications, analytics).

### Compensation logic: not rollbacks

Compensating transactions are new forward transactions that semantically undo business effects. Three categories: **compensable transactions** (can be undone — reserve inventory → release inventory), **pivot transactions** (point of no return — after this, forward recovery only), and **retryable transactions** (steps after the pivot that must eventually succeed via retry).

Every compensation must be **idempotent and retryable**. Use idempotency keys scoped to each saga step, checked against a processed-events store. For non-reversible actions, use a **two-phase API** (reserve, then confirm/cancel with auto-cancel timeout) or register the compensation before executing the action (in case the action succeeds but confirmation is lost).

### Saga state persistence in PostgreSQL

```sql
CREATE TABLE saga_instances (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    saga_type       VARCHAR(255) NOT NULL,
    current_state   VARCHAR(100) NOT NULL DEFAULT 'INITIAL',
    payload         JSONB NOT NULL DEFAULT '{}',
    version         INTEGER NOT NULL DEFAULT 0,    -- optimistic concurrency
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    timeout_at      TIMESTAMPTZ
);

CREATE TABLE saga_log (
    id              BIGSERIAL PRIMARY KEY,
    saga_id         UUID NOT NULL REFERENCES saga_instances(id),
    step_name       VARCHAR(255) NOT NULL,
    action_type     VARCHAR(50) NOT NULL,
    status          VARCHAR(50) NOT NULL,
    error_message   TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

Use optimistic concurrency via the `version` column: `UPDATE saga_instances SET current_state = $1, version = version + 1 WHERE id = $2 AND version = $3`. Zero rows affected means concurrent modification — reload and retry. Run a background sweeper every 30 seconds to detect orphaned sagas: `SELECT * FROM saga_instances WHERE current_state NOT IN ('COMPLETED','FAILED') AND timeout_at < now()`.

### Temporal.io as saga orchestrator

Temporal eliminates explicit state persistence by providing **durable execution** — workflow function state (local variables, execution point) is transparently persisted. If a worker crashes, Temporal reschedules on another worker and replays event history to rebuild exact state.

```go
func OrderWorkflow(ctx workflow.Context, order OrderDetails) (string, error) {
    var compensations []func(workflow.Context) error
    actOpts := workflow.ActivityOptions{
        StartToCloseTimeout: 30 * time.Second,
        RetryPolicy: &temporal.RetryPolicy{MaximumAttempts: 3},
    }
    ctx = workflow.WithActivityOptions(ctx, actOpts)

    var reserveResult ReserveResult
    err := workflow.ExecuteActivity(ctx, activities.ReserveInventory, order).Get(ctx, &reserveResult)
    if err != nil { return "", err }
    compensations = append(compensations, func(ctx workflow.Context) error {
        return workflow.ExecuteActivity(ctx, activities.ReleaseInventory, reserveResult).Get(ctx, nil)
    })

    err = workflow.ExecuteActivity(ctx, activities.ProcessPayment, order).Get(ctx, nil)
    if err != nil {
        for i := len(compensations) - 1; i >= 0; i-- { compensations[i](ctx) }
        return "", err
    }
    return "completed", nil
}
```

Temporal provides built-in retry policies (`InitialInterval`, `BackoffCoefficient`, `MaximumAttempts`), activity timeouts (`StartToCloseTimeout`, `ScheduleToCloseTimeout`), and polyglot support (Go, TypeScript, Java, Python).

---

## 8. Event sourcing on PostgreSQL: operational reality

### Event store table design

```sql
CREATE TABLE events (
    id              BIGSERIAL PRIMARY KEY,
    aggregate_id    UUID NOT NULL,
    aggregate_type  VARCHAR(255) NOT NULL,
    event_type      VARCHAR(255) NOT NULL,
    event_data      JSONB NOT NULL,
    metadata        JSONB DEFAULT '{}',
    version         INTEGER NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT unique_aggregate_version
        UNIQUE (aggregate_type, aggregate_id, version)
);

CREATE INDEX idx_events_aggregate ON events (aggregate_type, aggregate_id, version);
CREATE INDEX idx_events_type_created ON events (event_type, created_at);
```

The `UNIQUE (aggregate_type, aggregate_id, version)` constraint provides **optimistic concurrency control** without application logic. Two concurrent writes with the same version cause a unique constraint violation — catch it and retry. The `metadata` column should include `correlation_id`, `causation_id`, `user_id`, and `schema_version`.

PostgreSQL can atomically write events across multiple aggregates in a single transaction — a unique advantage over dedicated event stores like EventStoreDB.

### Snapshot strategies

Snapshots make sense when replay exceeds **100ms** for hot aggregates. Common thresholds: every 100–1,000 events. Use an async background process ("chaser") that monitors streams and creates snapshots when thresholds are reached. Store snapshots in a separate table with `(aggregate_type, aggregate_id)` as the primary key. Version the snapshot format with a `schema_version` field — old snapshots with mismatched versions are discarded, triggering full replay. Snapshots are never the source of truth; the event stream is.

### Projection rebuild: the operational pain point

Projection rebuild times grow non-linearly with database size. A single-threaded consumer handles thousands of events/second; rebuilding 10M events at ~5,000–10,000 events/second takes **15–30 minutes**. Speed up rebuilds with parallel processing by aggregate ID (partitions processed in parallel, events within a partition sequential), batch inserts during catch-up (switch to left-fold when live), and blue/green deployment (build new projections side-by-side, switch traffic when caught up). Return HTTP 503 during initial provisioning.

### Schema evolution via upcasting

Never modify stored events. Use **upcasting** — middleware between deserialization and application logic that transforms old events to the current schema version. Chain upcasters: V1→V2→V3. Application code only handles the latest version:

```typescript
const v1ToV2: Upcaster<OrderPlacedV1, OrderPlacedV2> = {
    fromVersion: 1, toVersion: 2,
    upcast(v1) {
        return { orderId: v1.orderId, subtotal: v1.amount * 0.9,
                 tax: v1.amount * 0.1, currency: 'USD' };
    }
};
```

Prefer additive changes (add optional/nullable fields) over removals or renames. Store `schema_version` in event metadata to route through the appropriate upcaster chain.

### CQRS read model consistency

The core problem: projections build asynchronously, creating a read-your-own-writes gap. Strategies ranked by effectiveness: **return command result directly** (construct the read model from command data, not from the projection — eliminates the gap for the writing user), **synchronous projection within transaction** (when PostgreSQL serves as both event store and read model, update the projection in the same transaction), **read from primary after write** (direct queries to the write database for a short window after commands), and **client-side polling** (show "Processing..." and poll for completion).

Monitor **projection lag** — the gap between latest event sequence and each projection's processed sequence. Alert when lag exceeds your consistency SLA (e.g., > 5 seconds).

---

## 9. Backpressure: the slowest component controls throughput

In Kafka consumer pipelines, there is no direct backpressure signal from consumer to producer. Backpressure manifests as **consumer lag** — the growing offset difference between production and consumption. If lag grows past the retention period, data is lost silently.

### Consumer pause/resume

`KafkaConsumer.pause(partitions)` stops returning records from paused partitions while heartbeats continue and the consumer stays in the group. Pause when buffers are full, DB connection pools are exhausted, or circuit breakers are open. **Critical**: paused partitions are reset on rebalance — you must re-pause after new assignments. Continue calling `poll()` while paused to maintain heartbeats.

The production-proven pattern: a poller thread polls Kafka with a short interval (50ms), feeding bounded per-partition work queues. When a queue is full, selectively pause that partition. When the queue drains, resume it. This prevents rebalance storms from the poll-then-process-then-timeout loop.

### Database write batching

PostgreSQL batch write throughput varies dramatically by method:

| Method | Relative throughput |
|--------|-------------------|
| Single INSERT | 1x (baseline) |
| Multi-row INSERT with UNNEST | 15–20x |
| COPY (text) | 50–100x |
| COPY (binary) | 100x+ |

At batch size 1,000, INSERT with UNNEST is competitive with COPY. At 100,000+, binary COPY is unbeatable. COPY generates **1.7x less WAL** than INSERT for equivalent data. Use a hybrid flush strategy: flush on whichever trigger fires first — `min(count=5000, time=2s, size=1MB)`.

### max.poll.records tuning

Default: 500. The critical constraint: `max.poll.records × max_processing_time_per_record < max.poll.interval.ms`. For fast processing (< 1ms/record), increase to 1,000–2,000. For slow/IO-bound processing (10–100ms/record), decrease to 50–100. Co-tune with `fetch.min.bytes` (increase to 16,384+ for throughput) and `fetch.max.wait.ms`.

### Go channel-based backpressure

Bounded channels provide implicit backpressure — the sender blocks when the channel is full:

```go
type WorkerPool struct {
    jobs chan Job
    wg   sync.WaitGroup
}

func NewWorkerPool(numWorkers, queueSize int) *WorkerPool {
    wp := &WorkerPool{jobs: make(chan Job, queueSize)}
    for i := 0; i < numWorkers; i++ {
        wp.wg.Add(1)
        go func() { defer wp.wg.Done(); for job := range wp.jobs { process(job) } }()
    }
    return wp
}

func (wp *WorkerPool) Submit(ctx context.Context, job Job) error {
    select {
    case wp.jobs <- job: return nil
    case <-ctx.Done(): return ctx.Err()
    }
}
```

Size CPU-bound buffers at `runtime.NumCPU()` (1:1 with workers). Size IO-bound buffers at `numWorkers × 5`. For graceful shutdown, close the jobs channel and use `sync.WaitGroup` with a context deadline.

### TypeScript async queue pattern

Use `p-queue` for concurrency-limited async work:

```typescript
import PQueue from 'p-queue';
const queue = new PQueue({ concurrency: 5, intervalCap: 100, interval: 1000 });

queue.on('add', () => {
  if (queue.size > 100) consumer.pause(consumer.assignments());
});
queue.on('completed', () => {
  if (queue.size < 50) consumer.resume(consumer.assignments());
});
```

For Node.js streams, `pipeline()` handles backpressure automatically. Check `writable.write()` return value — if `false`, wait for the `'drain'` event.

---

## 10. Tooling, libraries, and health checks for production correctness

### Go Kafka library comparison (2025–2026)

**`segmentio/kafka-go`** is recommended for new pure-Go projects — idiomatic API with context support, no CGo dependency, clean Reader/Writer high-level API. **`confluent-kafka-go`** is recommended when maximum feature coverage or EOS is required — wraps librdkafka (C), requires CGo (complicates cross-compilation and Alpine builds), but has the best performance and Kafka feature parity. **`IBM/sarama`** (formerly Shopify/sarama, v1.45.0+) remains actively maintained with the best mock testing support, but has no Go context support and historically more bugs.

### TypeScript Kafka library comparison (2025–2026)

**KafkaJS is no longer actively maintained** — last release February 2023, with an open call for maintainers. **Do not use for new projects.** Migrate to **`@confluentinc/kafka-javascript`** (GA released 2024), which wraps librdkafka with a KafkaJS-compatible API. Migration involves changing the import and wrapping configs in a `kafkaJS: {}` block. For environments where native dependencies are unacceptable, evaluate `@platformatic/kafka` (pure JS, claims to outperform KafkaJS).

### Consumer lag monitoring stack

Deploy **Burrow** (LinkedIn) for intelligent lag analysis — it evaluates lag as a sliding window, classifying consumer state as OK/WARNING/ERR/STOP based on whether the consumer is making forward progress, not just whether lag exceeds a threshold. Complement with **kafka-lag-exporter** for Prometheus integration, exposing `kafka_consumergroup_lag_seconds` (estimated time behind). Alert when lag increases continuously for 15+ minutes or approaches the retention period.

### Kubernetes health check patterns

Naive TCP checks on port 9092 miss stuck consumers, silently growing lag, and downstream failures. Use smart probes:

**Liveness**: Retrieve the current offset from Kafka (fails = connectivity issue → restart). Check if the committed offset changed since the last probe (unchanged = consumer stuck → restart).

**Readiness**: Verify active broker connections, group membership with partition assignments, no active rebalancing, and downstream dependency reachability.

```yaml
livenessProbe:
  httpGet: { path: /health/live, port: 8080 }
  initialDelaySeconds: 60       # Allow consumer to join group
  periodSeconds: 60             # Must exceed batch processing time
  failureThreshold: 3
startupProbe:
  httpGet: { path: /health/started, port: 8080 }
  failureThreshold: 30
  periodSeconds: 10
```

Each replica must only track offsets for partitions it currently owns — rebuild the offset map on rebalance events.

### Testing with Testcontainers

Use Testcontainers for integration tests with real Kafka:

```go
// Go
kafkaContainer, _ := kafka.Run(ctx, "confluentinc/confluent-local:7.5.0",
    kafka.WithClusterID("test-cluster"))
brokers, _ := kafkaContainer.Brokers(ctx)
```

For faster startup, use the Redpanda module (`docker.redpanda.com/redpandadata/redpanda`) — no JVM required, sub-second container startup. No embedded Kafka is available for KafkaJS/TypeScript — Testcontainers is the only reliable option.

### AsyncAPI for event documentation

AsyncAPI 3.0.0 provides machine-readable specifications for event-driven APIs including Kafka-specific bindings (partitions, replicas, topic configuration, group IDs, schema registry URLs). Use it to document topic schemas, generate payload models via Modelina (Go, TypeScript, Python), and validate messages at runtime with `asyncapi-validator`. Integrate schema compatibility checks into CI/CD using `confluent schema-registry:test-compatibility` or AsyncAPI validation.

---

## Conclusion: patterns that compound into system reliability

The deepest insight across all ten topics is that **every failure pattern traces to broken atomicity guarantees or violated ordering assumptions**. The outbox pattern exists because dual-writes to Kafka and PostgreSQL are never atomic without it. DLQs exist because poison messages and transient failures are inevitable. Saga compensations exist because distributed transactions cannot roll back. Consumer rebalancing storms exist because timeout arithmetic is violated under load.

The most impactful rules for AI coding agents to enforce: always use the outbox pattern for database-to-Kafka writes (never produce directly after a DB commit), always classify errors as permanent or transient before retry, always set `group.instance.id` in containerized environments, always use `CooperativeStickyAssignor` or KIP-848, never change partition counts on keyed topics, always implement consumer-side idempotency regardless of upstream guarantees, and always use `clock_timestamp()` instead of `NOW()` in outbox tables. These are not best practices — they are **invariants** whose violation produces predictable, documented production failures.