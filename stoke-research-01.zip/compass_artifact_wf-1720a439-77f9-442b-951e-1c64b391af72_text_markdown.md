# AI coding agent skills and rules for ecommerce payment systems

Building an ecommerce platform that handles Stripe, Hedera crypto, x402 micropayments, and agent-to-agent commerce requires a precise engineering foundation. The open source ecosystem now offers **dozens of SKILL.md files, cursor rules, state machine definitions, and published engineering guides** specifically designed to encode payment system correctness into AI coding agents. This report maps the entire landscape — from Stripe's official agent toolkit to the emerging stack of agent payment protocols — providing concrete repositories, documentation URLs, and implementation patterns for each layer of the system.

The agentic commerce space has accelerated dramatically since mid-2025. Protocols like x402 have processed **over 50 million transactions**, Stripe and OpenAI co-launched the Agentic Commerce Protocol powering ChatGPT's Instant Checkout, and Google's AP2 protocol has attracted 60+ partners including Visa, Mastercard, and PayPal. For a Canadian-based business selling internationally, the tax compliance landscape adds complexity across GST/HST/PST, US economic nexus rules, and EU VAT OSS — but modern tax APIs from Stripe Tax and Avalara now handle this programmatically.

---

## 1. Stripe SKILL.md files and AI agent rules repositories

The richest source of Stripe-specific AI agent configuration is the **official `stripe/ai` repository** (github.com/stripe/ai, ~1,400 stars). It serves as a one-stop shop containing SKILL.md files covering API selection guidance (Checkout Sessions vs. PaymentIntents), Connect platform setup with Accounts v2, billing and subscription patterns, and Treasury financial accounts. It tracks the latest API version (2026-03-25.dahlia) and includes an MCP server at `@stripe/mcp` for direct agent integration. The companion `stripe/upgrade-stripe` skill handles SDK and API version migrations.

**Hookdeck's `webhook-skills` repository** (github.com/hookdeck/webhook-skills) provides provider-specific SKILL.md files following the Agent Skills specification, including `stripe-webhooks/SKILL.md` with signature verification code, event handling patterns, and runnable examples for Express, Next.js, and FastAPI. It works with Claude Code, Cursor, VS Code Copilot, and other AI agents.

**Finsilabs' `awesome-ecommerce-skills`** (github.com/finsilabs/awesome-ecommerce-skills) contains **178 skills** across the ecommerce stack, including `skills/payments-checkout/stripe-integration/SKILL.md` with guidance on why Stripe Checkout (hosted) beats custom forms for PCI compliance, PaymentIntents API code with SCA/3D Secure, webhook handlers for order fulfillment, and Stripe Tax configuration. It includes 8 headless-specific skills for Shopify Hydrogen, Medusa, and Saleor.

Additional repositories worth integrating into your agent's knowledge base:

- **`wrsmith108/stripe-mcp-skill`** — Claude Code skill with SKILL.md plus separate `docs/webhooks.md` and `docs/testing.md` covering webhook security and testing patterns
- **`wshobson/agents`** — 129 skills across 27 plugins, including `stripe-integration`, `paypal-integration`, `pci-compliance`, and `billing-automation` skills
- **`Yuyz0112/public-api-skills`** — Auto-generated SKILL.md from Stripe's OpenAPI specification via `openapi-to-skills`
- **`ComposioHQ/awesome-agent-clis`** — Stripe CLI skill for webhook testing, event triggering, and API log tailing
- **`VoltAgent/awesome-agent-skills`** — Curated directory listing official skills from Stripe, Anthropic, Google Labs, and Cloudflare
- **`RayFernando1337/llm-cursor-rules`** — Contains `nextjs14-clerk-convex-stripe.md` with Stripe integration rules for a Next.js + Clerk + Convex stack, covering webhook handling in `convex/http.ts`
- **`PatrickJS/awesome-cursorrules`** (~38,500 stars) — The largest .cursorrules collection; while no dedicated Stripe file exists, it includes rules for frameworks commonly paired with Stripe
- **cursor.directory** — Community directory listing 29 `.mdc` rules including "Stripe key exposure" prevention

---

## 2. The x402 protocol has processed 50 million+ transactions since May 2025

x402 revives the long-dormant HTTP 402 "Payment Required" status code for instant, programmable micropayments. Developed by **Coinbase's Development Platform team** and launched May 6, 2025, it has grown into a production-grade protocol with **50 million+ transactions** processed across Base, Polygon, Solana, and Ethereum.

The protocol flow is elegantly simple. A client requests a resource; the server responds with HTTP 402 plus a `PAYMENT-REQUIRED` header containing a base64-encoded PaymentRequired object. The client creates a PaymentPayload, signs it, and resends the request with a `PAYMENT-SIGNATURE` header. A Facilitator service handles verification and settlement. The design is **stateless** (each request self-contained), **chain-agnostic**, and **extensible** via payment schemes like `exact` for fixed payments and `upto` for metered usage. Primary settlement currency is USDC.

**Key resources:**

- **Specification site:** x402.org with whitepaper at x402.org/x402-whitepaper.pdf
- **GitHub monorepo:** github.com/coinbase/x402 (Apache 2.0, 5.4k stars, 1.1k forks)
- **npm packages:** `@x402/core`, `@x402/evm`, `@x402/svm`, `@x402/axios`, `@x402/fetch`, `@x402/express`, `@x402/hono`, `@x402/next`, `@x402/paywall`
- **Language SDKs:** TypeScript (core), Python, Go, Java
- **Coinbase docs:** docs.cdp.coinbase.com/x402/welcome

Server-side integration is minimal — essentially one middleware call configuring which routes require payment. Coinbase provides a hosted Facilitator with **1,000 free transactions/month**. In September 2025, Coinbase and Cloudflare co-launched the **x402 Foundation** with members including Visa, Google, and others to provide neutral governance.

Major builders include **Cloudflare** (co-founder of the Foundation), **AWS** (reference architecture with Amazon Bedrock AgentCore), **Stripe** (integrated x402 on Base in February 2026), **Google** (A2A x402 extension), **Solana** (dedicated deployment chain with docs at solana.com/x402), **Firecrawl** (per-call search/scrape endpoints), and **World** (AgentKit for human identity verification). For a Hedera-based system, the chain-agnostic design means HBAR or USDC-on-Hedera support would require implementing a Hedera-specific payment scheme — a tractable extension of the existing EVM and SVM modules.

---

## 3. Agent-to-agent payment protocols form a complementary stack, not competing standards

The agent payment landscape has crystallized into **distinct, composable layers** rather than competing monoliths. Understanding where each protocol sits is critical for architectural decisions.

**Google A2A (Agent2Agent)** — github.com/a2aproject/A2A — is the agent communication layer. Version 0.3 was donated to the Linux Foundation in June 2025 with 150+ partner organizations. A2A enables agents on different frameworks (LangGraph, CrewAI, ADK) to collaborate via JSON-RPC messaging and AgentCard discovery. It does **not handle payments directly** — that's delegated to AP2 and x402 extensions.

**Google AP2 (Agent Payments Protocol)** — ap2-protocol.org, github.com/google-agentic-commerce/AP2 — is the authorization and trust layer. V0.1 published September 2025 with **60+ partners** including Adyen, American Express, Coinbase, Mastercard, PayPal, Revolut, and Worldpay. AP2 uses Verifiable Digital Credentials to create **Intent Mandates** ("spend up to $10/day on news subscriptions") and **Cart Mandates** (explicit authorization for a specific purchase). It's payment-method agnostic — cards today with a roadmap for UPI, PIX, and digital currencies. The A2A x402 extension bridges AP2 authorization to x402 crypto execution.

**Stripe/OpenAI Agentic Commerce Protocol (ACP)** — agenticcommerce.dev, docs.stripe.com/agentic-commerce/protocol — is the checkout and merchant integration layer. Released September 2025 and **already in production** powering ChatGPT's Instant Checkout. Uses **Shared Payment Tokens (SPTs)** — scoped to specific merchants and cart totals, time-limited, revocable, and powered by Stripe Radar for fraud detection. Partners include Shopify (1M+ merchants), Etsy, Salesforce, Microsoft Copilot, Anthropic, and Perplexity.

**Stripe/Tempo Machine Payments Protocol (MPP)** — docs.stripe.com/payments/machine/mpp — launched on mainnet March 18, 2026 with 100+ integrated services. Co-authored with Tempo (L1 blockchain backed by Paradigm, $500M raised). MPP adds **session-based billing** where agents pre-authorize spending and stream micropayments. Supports crypto (Tempo blockchain, ~500ms finality), fiat (cards via Stripe SPTs), and **Bitcoin Lightning** (via Lightspark). Core payment HTTP authentication scheme submitted to IETF for standardization. Partners include Visa, Anthropic, OpenAI, Mastercard, DoorDash, Nubank, and Revolut.

**Coinbase AgentKit** — github.com/coinbase/agentkit — gives AI agents crypto wallets and onchain capabilities. Production since November 2024. Framework-agnostic, supporting fee-free USDC transfers, token swaps, and smart contract interactions. **Agentic Wallets** (launched February 2026) provide the first wallet infrastructure designed specifically for AI agents with autonomous spending, programmable guardrails, and enclave-isolated private keys. Quick start: `npm create onchain-agent@latest`.

**NitroGraph Agent Commerce Protocol** — docs.nitrograph.com — is a specialized L1 blockchain for AI agent economics with Agent Identity NFTs, RFQ-based negotiation, protocol-level escrow, and reputation scoring. Currently in **private alpha on testnet**. The project referenced as "ADSP" is actually a separate effort — the Agent Discovery Service Protocol from AgentNetworkProtocol (agentnetworkprotocol.com), focused on agent discovery via `.well-known/agent-descriptions`.

| Layer | Protocol | Status | Creator |
|-------|----------|--------|---------|
| Agent communication | A2A | Production (Linux Foundation) | Google |
| Authorization and trust | AP2 | v0.1 pilot | Google + 60 partners |
| Checkout and commerce | ACP | Production (ChatGPT) | Stripe + OpenAI |
| Payment execution (crypto) | x402 | Production (50M+ txns) | Coinbase |
| Payment execution (multi-rail) | MPP | Mainnet (March 2026) | Stripe + Tempo |
| Agent wallets | AgentKit | Production | Coinbase |
| Agent economy | NitroGraph ACP | Private alpha | NitroGraph |

---

## 4. Ecommerce state machines from six open source platforms define the canonical patterns

The most production-hardened state machine definitions come from open source ecommerce platforms that have processed billions of dollars in transactions.

**Vendure** (docs.vendure.io) implements the clearest FSM with explicit states and guard conditions. The `DefaultOrderProcess` defines: AddingItems → ArrangingPayment → PaymentAuthorized → PaymentSettled → PartiallyShipped → Shipped → PartiallyDelivered → Delivered, with Cancelled accessible from multiple states. The **ArrangingPayment state locks all modifications** to maintain price integrity — a critical guard condition. Custom OrderProcess definitions can extend or override defaults.

**Sylius** (sylius.com) takes a multi-dimensional approach with **separate state machines** for checkout, payment, and shipping. The checkout machine flows through cart → addressed → shipping_selected → payment_selected → completed, with skip states for digital goods (shipping_skipped, payment_skipped). Payment tracks cart → awaiting_payment → partially_paid → paid → cancelled. Shipping tracks cart → new → ready → partially_shipped → shipped. Guards and callbacks restrict transitions and trigger side effects.

**Saleor** (docs.saleor.io) defines the OrderStatus enum: DRAFT → UNCONFIRMED → UNFULFILLED → PARTIALLY_FULFILLED → FULFILLED, with branches to PARTIALLY_RETURNED → RETURNED, plus CANCELLED and EXPIRED terminal states. Notably, Saleor explicitly states that its **Transaction model is not a state machine** — payment state is tracked separately via `authorizeStatus` and `chargeStatus`.

**Medusa.js** (docs.medusajs.com) uses pending → processing → fulfilled → completed with workflow-based compensating transactions for rollbacks. Amounts are stored in **minor units** (e.g., `unit_price: 3000` for $30.00). Medusa's event-driven architecture fires `order.placed`, `fulfillment.created`, and `fulfillment.shipped` events.

**XState implementations** on GitHub (github.com/jacobparis/stripe-machine-example, github.com/drewrawitz/xstate-checkout) demonstrate type-safe state machine definitions with guards, context, actions, and — critically — **state persistence and restoration** for shopping carts that survive browser sessions.

Guard conditions found across all systems encode critical business rules: cannot cancel after shipment, cannot fulfill without payment confirmation, cannot modify cart after entering payment flow, orders expire after configurable timeout, and return windows enforce time limits. These guards translate directly into SKILL.md rules for AI coding agents — any agent generating ecommerce code should enforce these transition constraints.

---

## 5. Financial calculation rules every AI agent must enforce

The foundational rule is absolute: **never use floating-point types for monetary values**. The IEEE 754 binary representation cannot exactly represent most decimal fractions — `0.1 + 0.2` evaluates to `0.30000000000000004` in JavaScript. Errors compound across thousands of transactions, tax calculations, and currency conversions, creating audit failures and legal exposure.

**Martin Fowler's Money pattern** (martinfowler.com/eaaCatalog/money.html) established the canonical approach: a Money class pairing an amount (integer or BigDecimal) with a CurrencyUnit, where all arithmetic operations enforce currency compatibility and the `allocate()` method distributes amounts across ratios without losing cents. Splitting $10.00 three ways yields $3.34, $3.33, $3.33 — not $3.33 × 3 = $9.99. This pattern has implementations in every major language.

**Dinero.js** (github.com/dinerojs/dinero.js, dinerojs.com) is the premier JavaScript/TypeScript implementation. It stores amounts in minor units (1999 = $19.99), is immutable (every operation returns a new object), supports ISO 4217 currencies with compile-time safety, and offers pluggable precision with `bigint` for large amounts. For cryptocurrency precision (18 decimals for ETH, 8 for HBAR), Dinero.js recommends **big.js** on its FAQ page. The `toSnapshot()` method serializes amount + currency + scale for database persistence.

Currency precision varies significantly by ISO 4217: **JPY has 0 decimal places**, most currencies use 2, BHD/KWD/OMR use 3, BTC uses 8, and ETH uses 18. Payment processors sometimes diverge from ISO standards — Adyen requires 2 decimals for ISK despite ISO specifying 0. This means your system needs a currency-specific precision lookup, not hardcoded assumptions.

**Banker's rounding (round half to even)** eliminates systematic upward bias. When the digit after the rounding point is exactly 5, it rounds to the nearest even number: 2.5 → 2, 3.5 → 4. This is the IEEE 754 default, used by Alipay+, Python's `round()`, and most banking systems. However, jurisdiction-specific tax calculations may require different rounding — always document and test rounding rules per calculation step.

Essential rules for any AI coding agent generating financial code:

- Use integer minor units or BigDecimal — never `float` or `double`
- Always pair amounts with ISO 4217 currency codes
- Use banker's rounding for aggregations; document jurisdiction-specific exceptions
- Implement Fowler's `allocate()` for splitting amounts
- Serialize monetary integers as strings in JSON (JavaScript's Float64 overflows Int64)
- Use `NUMERIC`/`DECIMAL` column types in databases, never `FLOAT`/`REAL`
- Handle cryptocurrency with BigInt (up to 18 decimal places)
- Store exchange rates with timestamps — rates are time-dependent

---

## 6. Canadian multi-jurisdiction tax requires Stripe Tax or Avalara with careful nexus tracking

A Canadian business selling internationally faces **three distinct tax regimes**, each with its own registration thresholds, rates, and filing requirements.

**Domestically**, Canada layers federal GST (5%) with provincial taxes that vary dramatically. Five provinces use harmonized HST (13-15%), while British Columbia charges 7% PST (threshold: CAD $10,000/12 months for remote sellers), Saskatchewan and Manitoba charge 6-7% PST with **no threshold** — a single transaction triggers obligation — and Quebec charges 9.975% QST. Sales are destination-based (taxed at customer's location). Alberta and the territories have no provincial tax.

**For US sales**, post-Wayfair economic nexus rules mean 45+ states can require tax collection based on **$100,000 in annual sales or 200 transactions** (though many states are dropping the transaction threshold — Illinois removed it January 1, 2026). Canadian sellers must obtain a US EIN before registering in states. Amazon FBA inventory in US warehouses creates physical nexus. States can audit 3-6 years back with penalties of 10-30% plus interest.

**For EU sales**, the Non-Union One Stop Shop (OSS) system requires registration from the **first B2C sale** to an EU consumer — there is no threshold. Register in one EU member state (Ireland is popular for English-speaking businesses), file quarterly VAT returns through a single portal, and charge VAT at the customer's country rate (17-27%). Two pieces of location evidence are required (billing address, IP, payment info). Records must be kept 10 years.

**Stripe Tax** (docs.stripe.com/tax/supported-countries/canada) offers the tightest integration for Stripe-based platforms. It monitors thresholds for every Canadian province, automatically calculates correct federal + provincial combinations, zero-rates exports, and covers 130+ countries. Integration is a one-line toggle in Checkout or full API access for custom flows. Filing partners include Taxually, Marosa, and Hands-off Sales Tax.

**Avalara AvaTax** provides the most comprehensive international coverage with 1,200+ integrations, cross-border customs calculations, and exemption certificate management. It's steeper to implement but handles edge cases like digital services classifications and fiscal representative requirements in France, Spain, and Italy. Entry-level pricing is accessible but rises with add-ons — registration fees run $349 per state.

**TaxJar** (now owned by Stripe) excels for US-focused businesses with 20ms average API response times and a 99.99% uptime SLA, but is less robust for Canadian GST/HST/PST and EU VAT. For a Canadian seller targeting international markets, **Stripe Tax is the pragmatic choice** if already on Stripe; Avalara is the enterprise alternative for complex multi-platform setups.

---

## 7. Affiliate tracking has shifted to server-side postback as the primary attribution method

Open source affiliate tracking projects on GitHub include **Refferq** (Next.js/Prisma/PostgreSQL with admin dashboard and affiliate approval workflow), **Weferral** (Node.js with auto-tracking and email automation), **Raider** (Rust/MySQL, self-service dashboard), and **Traffic Source** (SQLite with Stripe conversion polling and cookieless tracking, self-hostable on a $4 VPS). The GitHub topic `affiliate-tracking` aggregates additional projects including Laravel referral packages and Web3 referral platforms.

Commercial self-hosted options like **Rewardful** (rewardful.com) integrate directly with Stripe and support first-touch and last-touch attribution with cross-domain tracking. **FirstPromoter** offers Stripe/Paddle/Recurly integration with GDPR-compliant consent checkboxes. **Post Affiliate Pro** provides native server-to-server tracking, cookie-less alternatives, and built-in fraud detection.

The attribution model choice has significant revenue implications. **Last-click** (100% credit to final affiliate before conversion) is the industry standard used by Amazon Associates, ShareASale, and CJ Affiliate — simpler but undervalues content creators. **First-click** rewards discovery and protects against commission hijacking by coupon sites. Multi-touch models (linear, time-decay, position-based) distribute credit across touchpoints but add complexity.

Cookie consent compliance is non-negotiable. Under the ePrivacy Directive, affiliate tracking cookies are **not "strictly necessary"** and require explicit consent before placement. When cookies are declined, commission is simply not recorded — the affiliate loses attribution for that conversion. The solution is **server-to-server (S2S) postback tracking**, now the backbone of modern affiliate systems. A click generates a unique ID stored server-side; conversion triggers a postback with that ID. No browser dependency means immunity to ad blockers, Safari ITP, and cookie clearing. The recommended 2026 approach layers S2S postback as primary, first-party cookies with consent as secondary, coupon code attribution as tertiary, and AI probabilistic models as fallback.

Fraud prevention requires a multi-layered defense. Common attacks include cookie stuffing, click injection, attribution theft via last-minute redirects, and coupon code leaking. Detection red flags include click-through rates above 5% (industry average is 1-2%), conversions within seconds of clicks, traffic from data centers or VPNs, and high refund rates from specific affiliates. Prevention combines vetting (manual application review, never auto-approve), monitoring (real-time alerts for anomalous patterns), technical controls (IP risk scoring, device fingerprinting), payout holds for new affiliates, and tools like IPQS, Anura, and Stripe Radar.

---

## 8. Stripe, Shopify, and Square engineering guides encode payment correctness patterns

**Stripe's** most influential engineering post, "Designing Robust and Predictable APIs with Idempotency" (stripe.com/blog/idempotency), establishes three principles: handle failures **consistently** (always retry), **safely** (use idempotency keys), and **responsibly** (exponential backoff with random jitter). Idempotency keys are UUID v4 strings sent as headers on POST requests; Stripe saves the result of the first execution and replays it on retry. API v2 extends this to 30-day key windows (up from 24 hours) and supports both POST and DELETE idempotency. The webhook best practices documentation (stripe.com/docs/webhooks/best-practices) mandates signature verification via `Stripe-Signature` header, idempotent event handling by logging processed event IDs, selective event subscription, and **asynchronous processing** — return 2xx immediately, then process via queues.

The Stripe Dev Blog has published a series on resilient patterns: "Building resilient webhook handlers in AWS" covers dead letter queues for failed events; "From naive webhooks to durable sync" details queue-based reconciliation at scale; and "Building a mental model for Stripe payments" frames the PaymentIntent lifecycle as a state machine (checkout → tokenization → authorization → capture → settlement).

**Shopify Engineering's** "10 Tips for Building Resilient Payment Systems" (shopify.engineering/building-resilient-payment-systems) is the definitive practitioner's guide. Key insights include: lower all timeouts aggressively (start with 1s open, 5s read/write instead of default 60s), install **fine-grained circuit breakers** using Shopify's open source Semian library with per-country identifiers to prevent cascading failures, apply Little's Law for capacity planning (capacity = throughput × latency), and use correlation IDs through all distributed system layers. Shopify's "Commerce Payments Protocol" post details authorization-and-capture patterns using escrow smart contracts, while the Universal Commerce Protocol (co-developed with Google) defines how AI agents connect and transact with merchants using JSON-RPC 2.0 state management and PCIv4 compliance through sandboxing.

**Square's** engineering documentation introduces a unique pattern: **CancelPaymentByIdempotencyKey** — the ability to cancel a payment using its idempotency key when the request status is unknown. This solves a specific distributed systems problem where network failures leave payment state ambiguous. Square also uses **object versioning** for optimistic concurrency on Customer and Order objects, enabling multiple transactions without interference.

## Conclusion

The open source ecosystem for AI coding agent configuration in ecommerce has matured rapidly. The **`stripe/ai` repository** and **`hookdeck/webhook-skills`** provide the authoritative SKILL.md files for payment integration, while platforms like Vendure and Sylius offer battle-tested state machine definitions that should be encoded as agent rules. The agent payment protocol stack has settled into complementary layers — AP2 for authorization, ACP for checkout, x402 and MPP for execution — rather than competing standards, meaning an ecommerce platform can integrate multiple protocols serving different use cases.

For a Canadian business specifically, the combination of **Stripe Tax for automated multi-jurisdiction calculation**, **Dinero.js for financial precision** (with BigInt for HBAR's 8-decimal precision), **server-side S2S postback for affiliate attribution**, and the **Vendure/Sylius state machine patterns** as agent-enforced rules provides a comprehensive foundation. The x402 protocol's chain-agnostic design makes Hedera integration architecturally feasible by implementing a Hedera-specific payment scheme module. And Shopify Engineering's guidance on circuit breakers, correlation IDs, and aggressive timeout tuning applies directly to any payment system operating at scale.