# Auto-detecting project maturity to calibrate engineering rigor

**Software projects fail in two symmetric ways: too much process too early kills velocity; too little process too late kills reliability.** The Startup Genome Report found that **74% of high-growth startup failures stem from premature scaling** — advancing infrastructure, process, or team structure ahead of validated customer demand. Yet under-engineering exacts its own toll: HealthCare.gov's 2013 launch catastrophe and Twitter's iconic "Fail Whale" both trace to insufficient engineering rigor at critical growth stages. A system that automatically detects project maturity and calibrates verification depth accordingly would solve both failure modes. This report synthesizes published frameworks, quantitative thresholds, and real-world company journeys into a concrete blueprint for building such a system.

---

## The six stages of software project maturity

Multiple frameworks converge on a consistent lifecycle progression, though they slice it differently. Morgan Brown's 5-phase startup lifecycle, the Startup Genome's Marmer Stages, and Karl Hughes' technical maturity model all describe the same arc: chaotic exploration → validated prototype → product-market fit → disciplined growth → optimization at scale. For the purposes of automatic detection and rigor calibration, six stages provide the right granularity.

**Stage 1 — Prototype** represents pure exploration. Code is disposable, written to test hypotheses. One to two contributors push directly to main. There are no tests, no CI, no formal process. The Startup Genome data shows that **80% of successful startups focus on discovering the problem space** at this stage, not polishing engineering. CodeKraft's AbdulFattaah Popoola warns explicitly: "The most common leadership trap is superimposing the best practices of a mature product on a nimble startup."

**Stage 2 — MVP** shifts focus to validating demand with real users. A small team (2–5 people) introduces basic version control discipline, critical-path tests, and simple deployment. Brittany Laughlin's USV framework identifies **15 employees** as the first organizational breakpoint where ad-hoc coordination starts failing.

**Stage 3 — Product-market fit** marks the transition from searching to building. Code review becomes mandatory. CI/CD pipelines run automated tests. Monitoring and error tracking are non-negotiable. The exploration-to-settlement transition that Jake Spracher describes is the key inflection: "Startups may frequently find themselves in the exploration phase, but this is no excuse to cut corners when building for the long haul."

**Stage 4 — Growth** demands systematic engineering. DORA metrics, observability, incident response, and security scanning enter the picture. Laughlin's framework places the next breakpoints at **30, 50, and 75 employees**, each requiring new organizational structure. Coupa's engineering team observed that "as teams grow, communication and process become critical" — decisions can no longer happen over a quick meeting.

**Stage 5 — Scale** introduces platform engineering, developer portals (Spotify's Backstage), golden paths, chaos engineering (Netflix's Simian Army), and compliance frameworks. **Stage 6 — Mature/Enterprise** represents continuous optimization with full DevSecOps, SLO-based operations, and quantitative process management analogous to CMMI Levels 4–5.

---

## Quantitative signals that reveal project maturity automatically

The most promising approach for automatic maturity detection combines signals across four observable dimensions: git metadata, code quality artifacts, infrastructure configuration, and dependency management. Each provides independent evidence that, combined, creates a reliable composite classifier.

**Git metadata signals** are the richest source for automated detection. LinearB's benchmark study of **8.1 million PRs across 4,800 engineering teams** provides validated thresholds. Commit velocity maps to maturity: prototype-stage projects show irregular bursts from 1–2 contributors; MVP-stage projects show **3–5 commits per day per developer** with 2–5 unique contributors; growth-stage projects show 5–20 contributors with structured PR workflows. The DORA metrics provide the clearest stage boundaries for deployment behavior — elite teams deploy on-demand (multiple times daily) while low-performing teams deploy monthly to semi-annually.

PR review patterns are particularly diagnostic. Projects with no pull requests signal prototype stage. PRs without review indicate MVP. Required single-reviewer PRs suggest growth. **Multiple required reviewers with automated checks** mark mature systems. LinearB's data shows elite teams maintain PR sizes under **85 lines of code changed** with review times under **6 hours** and rework rates below **3%**. Branch strategy sophistication follows a clear progression: direct pushes to main → feature branches → gitflow → trunk-based development with feature flags.

**Code quality artifacts** provide complementary signals. Google's internal coverage standards define **60% as "acceptable," 75% as "commendable," and 90% as "exemplary"** — but the landmark Inozemtseva & Holmes study (ICSE 2014, awarded Most Influential Paper at ICSE 2024) demonstrated that coverage correlates weakly with test effectiveness when controlling for suite size. Coverage is therefore a necessary but insufficient maturity indicator. SonarQube's technical debt ratio provides a more robust signal: the ratio of estimated remediation time to estimated development time, rated A (0–5%) through E (51–100%). Projects scoring A on technical debt ratio with 70%+ coverage and enforced linting rules are definitionally beyond the MVP stage.

The presence and sophistication of configuration files serve as reliable binary signals: Does a `.eslintrc` or equivalent exist? Is TypeScript configured in strict mode? Does a `sonar-project.properties` file exist? Are pre-commit hooks configured? Each artifact's presence shifts the maturity probability distribution.

**Infrastructure configuration** is directly observable from repository contents. The presence of CI/CD configuration files (`.github/workflows/`, `.gitlab-ci.yml`, `Jenkinsfile`) and their complexity — number of stages, presence of deployment steps, security scanning jobs — maps cleanly to the Continuous Delivery Maturity Model's five levels. Port.io already implements this approach in production, scanning repositories for CI pipelines, test files, linter configuration, lockfiles, and contributing guides to generate automated maturity scorecards.

**Dependency health** rounds out the signal set. Lockfile presence and enforcement, automated update tooling (Dependabot/Renovate configuration), security scanning integration, and dependency freshness all contribute. The "dependency drift" concept — measuring how far behind dependencies lag from their latest versions — can be compiled into a single A–F grade. OpenSSF Scorecard provides **18 automated security checks** scored 0–10 each, covering code review enforcement, branch protection, CI tests, SAST presence, pinned dependencies, and vulnerability management.

---

## A concrete scoring system for automatic maturity classification

Combining all signals into a weighted composite score enables automatic stage classification. The following framework balances signal reliability against detection difficulty.

| Signal Category | Weight | Prototype (0–20) | MVP (21–40) | Growth (41–70) | Mature (71–100) |
|---|---|---|---|---|---|
| **Git activity** | 15% | <50 commits, 1–2 contributors | 50–500 commits, 2–5 contributors | 500–5K commits, 5–20 contributors | 5K+ commits, 20+ contributors |
| **PR/review process** | 15% | No PRs; direct push | PRs exist, optional review | Required reviews, 1–2 reviewers | 2+ reviewers, automated checks, CODEOWNERS |
| **Test coverage** | 15% | 0–10% | 10–40% | 40–80% | 80%+ with quality gates |
| **CI/CD sophistication** | 15% | No CI config | Basic CI (lint + test) | Full CI/CD with staging | CI/CD + canary/blue-green + automated rollback |
| **Documentation** | 10% | README only (or none) | README + basic API docs | + architecture docs, ADRs, runbooks | Comprehensive doc suite, C4 diagrams |
| **Security posture** | 10% | None | Secrets in env vars, basic input validation | SAST in pipeline, OWASP Top 10 | SAST + DAST + compliance certs + pen test reports |
| **Dependency management** | 10% | No lockfile | Lockfile present | + automated updates (Dependabot/Renovate) | + SBOM + vulnerability scanning + health scoring |
| **Monitoring/observability** | 10% | None | Basic error tracking (Sentry) | APM + alerting + structured logging | Full observability + SLOs + distributed tracing |

High-confidence signals that are easily automated and have low false-positive rates include CI/CD configuration file presence and complexity, test file count and coverage percentage, number of unique contributors, PR review activity patterns, deployment frequency, and presence of documentation and security artifacts. Medium-confidence signals like lines of code, dependency count, and branch strategy complexity provide useful supplementary evidence. User count, revenue, and SLA commitments are valuable but typically unavailable from repository inspection alone.

---

## What engineering practices belong at each stage

The central insight from both the research literature and company retrospectives is that engineering practices should be **pulled by pain, not pushed by aspiration**. Molly Graham's Minimum Viable Process framework prescribes adding process "only when feeling pain" — the smallest, most lightweight intervention that addresses an observed problem. Spotify operationalized this as "Minimum Viable Bureaucracy." The following matrix synthesizes guidance from Stripe, Airbnb, Netflix, Spotify, the Startup Genome, and published engineering maturity frameworks.

**At prototype stage**, the minimum viable process is version control, a single deployment mechanism (even manual), and basic crash reporting. Comprehensive test suites, complex CI/CD pipelines, formal code review, microservices architecture, and detailed documentation are actively harmful — they consume time better spent validating hypotheses. Karl Hughes puts it directly: "Non-technical founders should get as far as they reasonably can on their MVPs before investing in engineering resources."

**At MVP stage**, three additions become essential: basic automated tests for critical paths (payments, authentication), a simple CI pipeline running lint and tests on push, and pull requests even if informally reviewed. Airbnb's testing transformation began precisely here — a small group started submitting PRs, and the practice spread organically due to visible benefits. TheVentureCity's startup CTO guide pushes back on the "we don't need that yet" mentality for CI/CD and backups, noting these processes "will make your life easier" even at early stages.

**At growth stage**, the mandatory additions include required code review on all changes, automated testing across major features (60–80% coverage), full CI/CD with staging environments, security scanning in the pipeline, on-call rotation, and standardized development environments. Airbnb invested in parallelized test execution at this stage, reducing build times from over one hour to six minutes — a infrastructure investment that made testing culturally viable. Netflix adopted "you build it, you run it" service ownership at this point.

**At scale/mature stage**, the full engineering stack materializes: chaos engineering (Netflix), developer portals and golden paths (Spotify), API review processes (Stripe), comprehensive observability with SLO-based alerting, formal incident management with blameless postmortems, platform engineering teams, and compliance frameworks. Stripe's approach at scale is instructive: **"Build systems where the easiest path is the safest, most reliable one"** — making it hard to disable health checks, skip deployment verification, or override sensible defaults. This "pit of success" philosophy converts process compliance from overhead into default behavior.

---

## How leading companies evolved their engineering practices

The trajectories of Stripe, Airbnb, Spotify, and Netflix illustrate these principles in practice and reveal common patterns in when specific practices were adopted.

**Stripe** started with engineers participating in all aspects of product development — no Product Manager role existed initially. As the team grew from dozens to hundreds, they introduced engineering levels, review forums, and quarterly Developer Experience surveys. Their most distinctive practice — **mandatory API review for every change modifying Stripe's public API** — emerged from the recognition that API design errors are irreversible at scale. Stripe's migration of 3.7 million lines of JavaScript from Flow to TypeScript in a single PR, and their adoption of Sorbet (typed Ruby) across a 15-million-line codebase, demonstrate how type safety becomes a maturity investment at scale. Their observability stack now processes **~300 million metrics with 40,000 alerts** across roughly 7,000 employees.

**Airbnb's** testing journey is the canonical case study in building engineering culture retroactively. Their early codebase had minimal tests, and most new code shipped untested. The transformation was driven by three simultaneous strategies: leading by example (including tests with all PRs), education (engineering meetings on testing practices), and leveraging new hires (revamped testing bootcamp). The infrastructure investment was critical — standardizing development environments with Vagrant and Chef, implementing parallelized CI, and integrating CI with GitHub's commit status API. The result: **a culture where untested code changes are quickly identified and corrected**, proving that "it's never too late to start prioritizing testing."

**Spotify** evolved from standard Scrum to its famous Squad/Tribe/Chapter/Guild model, then evolved beyond that model as it grew. The most relevant engineering maturity lesson is their migration from a fragmented developer ecosystem to **Backstage** (their internal developer portal, later open-sourced) and **Golden Paths** — standardized documentation for how to develop software at Spotify. At their current scale, they execute approximately **3,000 production deployments per day**. Their "Minimum Viable Bureaucracy" concept and cross-pollination approach (de facto standards emerge when enough teams adopt a tool) directly support maturity-calibrated governance.

**Netflix** provides the definitive case for chaos engineering as a maturity practice. A 2008 database corruption causing a 3-day outage sparked a seven-year migration from monolith to microservices. They created Chaos Monkey, the Simian Army, and pioneered the "paved road" concept — supported frameworks and tools that make the correct engineering choice the easy one. Their incident management evolved from a centralized CORE team handling 90% of incidents to a democratized model where all engineers can declare and manage incidents.

---

## Security maturity without over-engineering for prototypes

OWASP SAMM and BSIMM represent complementary approaches to security maturity. **OWASP SAMM** is prescriptive and open-source, defining 5 business functions, 15 security practices, and 3 maturity levels (0–3) per practice. **BSIMM** is descriptive and commercial, documenting what 121+ organizations actually do across 4 domains and 128 activities. For a maturity-calibrated system, SAMM's structure is more actionable because it tells you what to do at each level rather than just what others are doing.

The **Minimum Viable Secure Product (MVSP)** framework, created by Google, Salesforce, Slack, and Okta (with CISA joining the working group), provides the practical baseline. It defines the absolute minimum security controls for enterprise readiness across business controls (vulnerability disclosure, annual testing, incident handling with **72-hour breach notification**), application design controls (SSO, HTTPS-only, security headers, encryption), implementation controls (data flow diagrams, OWASP Top 10 training, **90-day vulnerability fix SLA**), and operational controls (RBAC, MFA). Startups not mature enough for SOC 2 or PCI DSS use MVSP as their target.

A staged security approach maps cleanly to project maturity. At prototype stage, use secure-by-default frameworks (Django, Rails, Next.js handle CSRF and XSS automatically) and platform-delegated security (AWS Cognito, Stripe, Cloudflare). At MVP, add input validation, parameterized queries, secrets management, and basic dependency scanning. At growth, achieve OWASP Top 10 compliance, integrate SAST into CI, and conduct basic penetration testing. At scale, pursue SOC 2/ISO 27001, implement bug bounty programs, deploy DAST, and practice formal threat modeling. The key principle: **prioritize by probability × impact** — leaked API keys (high probability, high impact) demand immediate attention even at MVP stage; APT defense (low probability, high impact) can wait for scale.

---

## Technical debt as a calibrated maturity signal

SonarQube's technical debt ratio — remediation cost divided by estimated development cost (at a default rate of 30 minutes per line) — provides the most standardized quantitative metric. Its rating grid maps directly to maturity expectations: **an A rating (0–5% debt ratio) characterizes mature systems**, while D–E ratings (21–100%) are expected and acceptable at prototype stage. CodeClimate (now Qlty) offers a complementary maintainability score based on 10 specific checks: argument count, complex boolean logic, file length, code duplication, method count and length, nested control flow, and cyclomatic complexity.

The critical insight from research is that **quality metrics are primarily quality signals, not maturity signals per se**. A prototype with a 30% debt ratio is healthy; a production system with the same ratio has a problem. The maturity classification must consider the trajectory and combination of metrics, not absolute values. SIG (Software Improvement Group) found that issue resolution and enhancements are **2× faster in systems with above-average maintainability**, providing the economic case for debt reduction as projects mature.

Other tools contribute to the measurement ecosystem. CAST focuses on structural quality across five health factors aligned with ISO 25010. NDepend computes technical debt in developer-time and introduces the "Annual Interest" concept — the estimated time lost per year due to existing debt. Structure101 targets architectural complexity, measuring cyclic dependencies and structural excess. For automatic maturity detection, the most actionable approach is tracking the debt ratio's trend relative to the project's detected stage — a rising debt ratio in a growth-stage project signals that engineering rigor has not kept pace with development velocity.

---

## The danger of premature process and when rigor becomes counterproductive

The Startup Genome Report's data is unambiguous: startups that scale prematurely write **3.4× more code in the discovery phase** than successful peers. They outsource **4–5× as much** product development. And critically, **no startup in the dataset that scaled prematurely passed the 100,000-user mark**. Premature scaling means advancing any dimension — team, product, infrastructure, or process — ahead of validated customer demand.

Boeing's Enterprise Software Engineering identified a complementary anti-pattern they call "reified prototyping": prototype code built for capability demonstrations that evolves into production systems without the engineering rigor required for safety-critical programs, resulting in expensive re-engineering. This illustrates the symmetric danger — both premature rigor and insufficient rigor at the wrong stage create costly problems.

Facebook's trajectory captures the optimal calibration pattern. "Move fast and break things" was the right engineering philosophy during discovery and early growth, enabling rapid hypothesis testing and iteration. But as technical debt accumulated and the user base grew, Facebook shifted to **"Move fast with stable infrastructure"**, introducing rigorous code review, comprehensive testing, and infrastructure investment. The philosophy changed because the maturity stage changed.

Neal Ford's concept of **architectural fitness functions** — from "Building Evolutionary Architectures" — provides the right technical mechanism for progressive rigor enforcement. Fitness functions are automated guardrails that assess architectural characteristics. The key calibration insight: "In early exploration phases, defining architectural rules too soon can slow progress or artificially constrain thinking. Guardrails should be broad. As teams move from exploring concepts to refining solutions and scaling them, the rules can become more specific." A maturity-detection system should activate progressively more stringent fitness functions as project signals indicate increasing maturity.

---

## Concrete design principles for a maturity-calibrated verification system

Building "Stoke's wizard" — a system that detects project maturity and calibrates engineering rigor automatically — requires several design principles derived from this research.

First, **never decrease maturity level without explicit override**. Once a project crosses into growth-stage practices, automatically relaxing requirements risks regression. Second, **default to the lowest viable process level** and surface recommendations (not mandates) to increase rigor when signals cross thresholds. Third, **make rigor increases opt-in for non-critical areas but mandatory for security and data integrity** when user or revenue signals cross critical thresholds. Fourth, **allow per-dimension calibration** — a project with mature security practices but MVP-level documentation is a valid and common state.

The implementation should observe repository signals (git metadata, file presence, CI configuration, coverage reports, DORA metrics), classify maturity using the weighted composite scoring framework, prescribe appropriate rigor through fitness functions, and enforce through CI/CD pipeline gates that adjust based on detected maturity. The system should track maturity trajectory over time and flag projects where engineering rigor has fallen behind the growth in complexity, contributors, or users.

## Conclusion

The research reveals three non-obvious insights for building an automatic maturity-calibration system. First, **the most reliable maturity signals are structural, not behavioral** — the presence and sophistication of CI configuration files, test suites, documentation artifacts, and security scanning tools are more consistently diagnostic than commit velocity or deployment frequency, which vary widely based on team culture and product type. Second, the appropriate rigor threshold is not a function of what best practices exist, but of **what pain the project is currently experiencing or about to experience** — Molly Graham's "add process only when feeling pain" principle, validated by the Startup Genome data, should be the system's philosophical foundation. Third, the most effective maturity enforcement mechanism is not gates and mandates but **pit-of-success design** — Stripe's approach of making the safest path the easiest path, Netflix's "paved roads," and Spotify's "golden paths" all demonstrate that calibrated defaults outperform calibrated rules. A maturity detection system should progressively tighten defaults rather than progressively add enforcement, making mature engineering practices the path of least resistance as projects grow.