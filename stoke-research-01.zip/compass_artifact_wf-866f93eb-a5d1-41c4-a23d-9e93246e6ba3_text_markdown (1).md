# Claude 4.6 migration audit for QA-audit-loop systems

**Claude Opus 4.6 and Sonnet 4.6 represent substantial quality upgrades over 4.5 across nearly every dimension relevant to code review — but come with several breaking API changes that require careful migration work.** The models dropped the date-suffix naming convention, deprecated prefilling and manual extended thinking, and introduced adaptive thinking as the default reasoning mode. No Haiku 4.6 exists yet, so the audit tier stays on `claude-haiku-4-5-20251001`. All three 4.5 models remain active through at least late 2026, giving ample runway for a staged migration.

---

## 1. Exact API model strings and Haiku status

The 4.6 generation breaks from the date-suffixed naming convention used by 4.5 models. The official API identifiers are simply **`claude-opus-4-6`** and **`claude-sonnet-4-6`** — no `YYYYMMDD` suffix appears in any official Anthropic documentation. On cloud providers, the identifiers are `anthropic.claude-opus-4-6-v1` (AWS Bedrock), `claude-opus-4-6` (GCP Vertex AI), and equivalent patterns for Sonnet. One third-party source (AIML API) lists `claude-sonnet-4-6-20260218` as an enum value, but this is not confirmed in Anthropic's docs and should not be relied upon.

**Claude Haiku 4.6 does not exist.** The official models page lists exactly three current-generation models: Opus 4.6, Sonnet 4.6, and Haiku 4.5. The latest Haiku remains **`claude-haiku-4-5-20251001`** (alias `claude-haiku-4-5`). For the qa-audit-loop system, the Haiku tier stays as-is.

| Current system model | Migration target | Status |
|---|---|---|
| `claude-opus-4-5-20251101` | `claude-opus-4-6` | Direct upgrade available |
| `claude-sonnet-4-5-20250929` | `claude-sonnet-4-6` | Direct upgrade available |
| `claude-haiku-4-5-20251001` | `claude-haiku-4-5-20251001` | No change — still latest Haiku |

Release dates: Opus 4.6 launched **February 5, 2026**; Sonnet 4.6 launched **February 17, 2026**.

---

## 2. Capability improvements most relevant to code review

The quality gains from 4.5 to 4.6 are significant across all dimensions relevant to a qa-audit-loop system. The improvements are not incremental — several benchmarks show generational leaps.

**Coding and code analysis.** Opus 4.6 scores **65.4%** on Terminal-Bench 2.0 (agentic coding), up from 59.8% on Opus 4.5. SWE-bench Verified hovers around **79.9–80.2%** (within margin of error vs Opus 4.5's ~80.8–80.9%). Sonnet 4.6 reaches **79.6%** on SWE-bench Verified, up from 77.2%. Anthropic specifically highlights better "code review and debugging skills to catch its own mistakes," and Cognition's CEO noted "Sonnet 4.6 has meaningfully closed the gap with Opus on bug detection." Sonnet 4.6 reads context before modifying code more effectively and consolidates shared logic rather than duplicating it.

**Instruction following.** Anthropic's own internal evaluations show users rated Sonnet 4.6 "meaningfully better at instruction following" than both Sonnet 4.5 and Opus 4.5. Harvey (legal AI) praised its precision at delivering structured comparisons. In Claude Code, users preferred Sonnet 4.6 over Sonnet 4.5 roughly **70% of the time** and over Opus 4.5 **59% of the time**.

**Tool use reliability.** τ2-bench scores improved modestly — Opus 4.6 reaches **91.5% Retail / 99.0% Telecom** vs 91.2%/98.2% for Opus 4.5. However, **MCP Atlas** (tool use at scale) shows a slight regression: Opus 4.6 scores 59.5% vs Opus 4.5's 62.3%, recovering to 62.7% only at `max` effort. This is worth monitoring in multi-tool qa-audit scenarios.

**Structured output and JSON.** The `output_format` parameter has been renamed to `output_config.format` (old parameter deprecated but still functional). Structured outputs are now GA with no beta header. No specific JSON compliance benchmarks comparing 4.6 vs 4.5 were published, but the removal of prefilling on Opus 4.6 means workflows relying on `{"` prefills to force JSON must migrate to explicit structured output schemas.

**Long-context handling.** This is the most dramatic improvement. On MRCR v2 (8-needle, 1M variant), Opus 4.6 scores **76%** versus Sonnet 4.5's **18.5%** — Anthropic calls this "a qualitative shift." The model "holds and tracks information over hundreds of thousands of tokens with less drift, picks up buried details that even Opus 4.5 would miss." Box CTO reported outperforming Sonnet 4.5 "by 15 percentage points across real enterprise documents."

**Hallucination reduction.** Sonnet 4.6 shows "fewer false claims of success, fewer hallucinations, and more consistent follow-through on multi-step tasks." Anthropic claims "zero hallucinated links in computer use evals" for Sonnet 4.6 vs "about one in three" previously. However, Sonnet 4.6's system card reveals "over-eager behavior" — occasionally composing content using made-up information. No specific hallucination rate numbers were published.

**Agentic performance.** The biggest leaps are here. On GDPval-AA (economically valuable knowledge work), Opus 4.6 scores **1606 Elo** vs Opus 4.5's 1416 (+190 Elo). ARC-AGI-2 jumps from **37.6% to 68.8%** for Opus and from **13.6% to 58.3%** for Sonnet. NBIM reported that across 40 cybersecurity investigations, Opus 4.6 "produced the best results 38 of 40 times in blind ranking against Claude 4.5 models."

---

## 3. Known regressions that affect code review pipelines

Community feedback reveals real regressions, though many are specific to Claude Code's integration layer rather than the API itself.

**Token consumption is 5–10× higher.** This is the most widely reported issue. Opus 4.6 consumes dramatically more tokens than 4.5 for equivalent tasks, driven by deeper thinking and excessive subagent spawning. Reddit users report 6–8% of session quota per prompt (vs ~4% on 4.5). Anthropic later changed Claude Code's default for Opus 4.6 from `high` to `medium` effort to mitigate this.

**Excessive subagent spawning.** Opus 4.6 repeatedly delegates to subagents (Task tool) for work that should be done directly, re-reading files already in context and burning tokens without benefit. Multiple GitHub issues document this pattern (#27645, #28797).

**Thinking loops.** The model gets stuck in circular patterns — re-reading files, spawning unnecessary subagents, entering plan-mode after implementation was already approved. Tasks that took one turn on 4.5 can take 5–8 turns on 4.6 (#28469, #24585).

**Context compaction losing rules.** When compaction triggers (which happens more frequently with 4.6's higher token consumption), CLAUDE.md rules — including safety-critical production rules — can be forgotten. "Architectural reasoning evaporated" after compaction in long sessions (#25067, #28469).

**Sonnet 4.6 hallucinated function names on launch day.** Reported in agent workflows but described as transient and apparently fixed quickly.

**No dedicated regressions in JSON schema compliance or structured output** have been reported beyond the prefilling removal. Standard JSON parsers handle the slightly different string escaping in tool call arguments without issue.

**Code review specifically.** Devin reports "increased bug catching rates" and Windsurf calls it "noticeably better on tasks requiring careful exploration like debugging." However, Sonnet 4.6 "occasionally loses coherence when refactoring large files — might rename a function in one section but miss a reference 200 lines later." The SWE-bench score for Opus 4.6 shows a tiny regression vs 4.5 (within margin of error).

---

## 4. Deprecation timeline gives ample migration runway

None of the 4.5 models are deprecated yet. All remain **Active** with tentative retirement dates approximately 12 months after release. Anthropic guarantees at least 60 days notice before retirement.

| Model | Current status | Retirement not before |
|---|---|---|
| `claude-opus-4-5-20251101` | Active | **November 24, 2026** |
| `claude-sonnet-4-5-20250929` | Active | **September 29, 2026** |
| `claude-haiku-4-5-20251001` | Active | **October 15, 2026** |
| `claude-opus-4-6` | Active | February 5, 2027 |
| `claude-sonnet-4-6` | Active | February 17, 2027 |

This means the current system has **6–8 months** before any forced migration. A phased rollout — migrating Sonnet first (lower risk, large quality gains), then Opus (higher impact, more behavioral changes), while keeping Haiku pinned — is viable without time pressure.

---

## 5. Prompt caching works but has migration-relevant changes

Prompt caching is fully supported on both 4.6 models and the core mechanism is unchanged. However, several details matter for migration.

**Minimum cacheable token thresholds differ by model.** Opus 4.6 requires **4,096 tokens** minimum (same as Opus 4.5). One source reports Sonnet 4.6's minimum increased to **2,048 tokens** (up from 1,024 on Sonnet 4.5) — prompts under this threshold silently skip caching. Verify this against your actual prompt sizes.

**Cache TTL options** remain 5-minute default (1.25× write cost) and 1-hour (2× write cost, now GA without beta header). Up to **4 explicit cache breakpoints** per request. Cache reads cost 10% of base input price. One-hour TTL is recommended for extended thinking tasks that often exceed 5 minutes.

**Switching thinking modes breaks message cache.** Moving between adaptive and enabled/disabled thinking invalidates previously cached message content. System prompts and tool definitions remain cached regardless. This means if you toggle thinking modes across requests in the audit loop, expect cache misses.

**Prefilling removal affects cache coherence.** Workflows that used prefilled assistant messages to maintain cache-friendly conversation patterns must be restructured.

**Pricing for 4.6 caching:** Opus 4.6 input is **$5/MTok** with cache writes at $6.25/MTok (5-min) or $10/MTok (1-hour) and reads at $0.50/MTok. Sonnet 4.6 input is **$3/MTok** with cache writes at $3.75/MTok or $6/MTok and reads at $0.30/MTok.

---

## 6. `allowedTools` restrictions have known bugs

Multiple documented bugs affect tool restriction behavior, and these are **not 4.6-specific** — they affect the Claude Code and Agent SDK tooling layer across model versions.

**Built-in tools bypass `allowedTools` in the Agent SDK.** Setting `allowedTools: ['Read', 'Glob', 'Grep']` does not prevent Claude from using Edit to modify files — a security issue for read-only audit agents (Agent SDK TypeScript #115). Similarly, `--allowedTools Read` combined with `--permission-mode bypassPermissions` does not restrict the Bash tool (Claude Code #12232).

**Skill frontmatter `allowed-tools` is not enforced.** Claude can use any tool regardless of skill-level permissions, breaking orchestration-style skills that delegate to sub-agents (Claude Code #18837).

**claude-code-action merges rather than restricts.** When `track_progress: true`, the action adds 18 write tools that override user `--allowedTools` restrictions. A read-only code review agent may unknowingly have full write access (claude-code-action #860).

These bugs are infrastructure-level, not model-level. No reports indicate that the 4.6 models themselves handle tool restrictions differently from 4.5 at the API level. The issues lie in how Claude Code and the Agent SDK enforce restrictions.

---

## 7. New capabilities directly relevant to code review quality

**Multi-file reasoning is substantially improved.** The 1M context window (beta) allows injecting entire codebases directly into prompts. Agent teams (research preview) enable multiple agents working on different parts of a codebase in parallel, coordinating via a "Mailbox Protocol." Asana's CTO described the ability to "navigate a large codebase and identify the right changes" as "state-of-the-art."

**Code review and diff understanding.** Opus 4.6 has "better code review and debugging skills to catch its own mistakes." Root cause analysis for complex software failures is highlighted as a strength. However, no standalone diff/patch understanding benchmark was published — improvements are inferred from SWE-bench and agentic coding results rather than measured directly.

**JSON output schemas** benefit from structured outputs being GA. The migration from `output_format` to `output_config.format` is backwards-compatible during the transition period. Schema complexity is limited to **24 optional parameters** across all strict tools in a single request.

**New tool features** include dynamic filtering for web search/fetch (Claude writes code to filter results before they enter context), code execution free with web tools, and programmatic tool calling (now GA). Fine-grained tool streaming is GA without beta headers.

**Extended thinking improvements** center on adaptive thinking — Claude dynamically calibrates reasoning depth to query complexity. The new `max` effort level on Opus 4.6 provides the highest capability for complex audit tasks. Interleaved thinking (reasoning between tool calls) is automatic with adaptive thinking.

---

## 8. Context window sizes enable new architectural options

| Model | Standard input | Beta input (1M) | Max output |
|---|---|---|---|
| **Claude Opus 4.6** | 200K tokens | **1M tokens** | **128K tokens** |
| **Claude Sonnet 4.6** | 200K tokens | **1M tokens** | 64K tokens |
| Claude Haiku 4.5 | 200K tokens | N/A | 64K tokens |

The 1M context window requires the beta header **`context-1m-2025-08-07`** and is available to organizations in **usage tier 4** or with custom rate limits. When input exceeds 200K tokens, all tokens (input and output) are charged at premium long-context rates.

Opus 4.6 doubled max output from 64K to **128K tokens** — significant for audit systems generating detailed code review reports. SDKs require streaming for large `max_tokens` values.

**Architectural implication:** The 1M context window combined with MRCR v2 scores of 76% means injecting more code directly into prompts is now viable for Opus 4.6. This reduces reliance on agents reading files at the cost of higher per-request token spend. For a qa-audit-loop, a hybrid approach — injecting critical files directly while letting agents discover peripheral files — likely optimizes both quality and cost.

---

## 9. Extended thinking is overhauled with adaptive mode

**Adaptive thinking (`thinking: {type: "adaptive"}`)** is the recommended mode for both 4.6 models and replaces manual extended thinking. Claude dynamically decides when and how deeply to think based on query complexity. Interleaved thinking — reasoning between tool calls — is automatically enabled with no beta header.

**Manual extended thinking (`thinking: {type: "enabled", budget_tokens: N}`)** is deprecated on both Opus 4.6 and Sonnet 4.6. It still functions but will be removed in a future release.

**The effort parameter is now GA** with four levels: `low`, `medium`, `high` (default), and `max`. The `max` level is available on Opus 4.6 only and provides the highest capability. Sonnet 4.6 introduces the effort parameter to the Sonnet family for the first time, defaulting to `high` — this may increase latency compared to Sonnet 4.5 unless tuned down.

**Migration action required:** Replace `thinking: {type: "enabled", budget_tokens: N}` with `thinking: {type: "adaptive"}` and select an appropriate effort level. Remove the `interleaved-thinking-2025-05-14` beta header (safely ignored on Opus 4.6, still supported but unnecessary on Sonnet 4.6). Note that Opus 4.6 does **not support prefilling assistant messages** — any prefill returns a 400 error.

**Practical concern:** At default `high` effort, Opus 4.6 can "overthink" simpler tasks, consuming excessive tokens. For a qa-audit-loop with mixed-complexity steps, consider using `medium` effort for straightforward checks and `high` or `max` for deep analysis passes.

---

## 10. Multi-agent orchestration behavior has changed significantly

Opus 4.6 exhibits a **strong predilection for spawning subagents** — the model aggressively delegates to the Task tool even for work that should be done directly. This is well-documented across GitHub issues and is the primary behavioral change affecting multi-agent orchestration.

**Subagent permission inheritance is broken** in Claude Code v2.1.56+. Subagents no longer inherit the parent session's permission mode, causing every tool call to trigger a user permission prompt even when the parent auto-approved. This is tagged as a regression (#28584).

**Output token cap affects pipelines.** `CLAUDE_CODE_MAX_OUTPUT_TOKENS` has no effect on Opus 4.6 — the model is always capped at 32K in Claude Code despite supporting 128K via the API. Combined with default thinking token allocation, only ~769 tokens may remain for actual output (#29488).

**Agent teams** (research preview) represent a new capability: multiple Claude agents working in parallel, each with its own context window up to 1M tokens, coordinating autonomously via shared task lists. This requires `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`. Each agent can be assigned a specific model via `model: sonnet`, `model: opus`, `model: haiku`, or `model: inherit`.

**For the qa-audit-loop system specifically:** If using Claude Code as a subprocess, add explicit system prompt guidance about when subagents are and aren't warranted to prevent excessive delegation. Consider setting `CLAUDE_CODE_SUBAGENT_MODEL` to control which model subagents use. The compaction API (beta) provides server-side context summarization for long-running audit sessions, but monitor for rule loss after compaction events.

---

## Conclusion: migration recommendation for quality-only considerations

The quality case for migrating to 4.6 is strong. **Sonnet 4.6 is the clearest win** — it closes the gap with Opus 4.5 on code review tasks, improves instruction following dramatically (+357 Elo on GDPval-AA), and shows fewer hallucinations, all at the same price. Migrate the Sonnet tier first with minimal risk.

**Opus 4.6 delivers the highest absolute quality** for complex, multi-file code analysis — the long-context improvements alone (76% vs 18.5% on MRCR v2) are transformative for reviewing large codebases. However, the token consumption increase (5–10×), excessive subagent spawning, and thinking loops require tuning the effort parameter (start at `medium`) and adding explicit behavioral guidance in system prompts.

Five breaking changes require code updates before migration: prefilling removal (400 error), `output_format` → `output_config.format`, manual extended thinking deprecation, tool version updates, and Sonnet 4.6's higher minimum cache threshold (likely 2,048 tokens). The `allowedTools` bugs are infrastructure-level and affect all model versions equally.

With 4.5 retirement dates no earlier than September–November 2026, a phased approach is prudent: migrate Sonnet now, validate audit quality metrics, then migrate Opus with effort tuning, and keep Haiku 4.5 pinned until a 4.6 Haiku is announced.