# Production AI integration patterns for application developers

**The core challenge for application developers building AI-powered SaaS in 2025–2026 isn't model training—it's orchestration.** Integrating multiple LLM providers, managing rate limits across subscription pools, ensuring safety, controlling costs, and shipping reliable AI features requires a distinct engineering discipline now called "AI Engineering." This report covers the complete stack: from API integration through observability to deployment, with practical patterns for a Go-based orchestrator managing multiple AI subscriptions.

The landscape has consolidated around several key architectural decisions: use an **AI Gateway** as your central control plane, enforce **structured outputs** from day one, implement **two-layer caching** (exact + semantic) to cut costs 25–73%, version prompts like code with CI/CD evaluation gates, and roll out AI features gradually behind feature flags with automated quality and cost monitoring. What follows is a comprehensive reference across all ten integration areas.

---

## 1. LLM API integration requires provider-specific SDKs but converging patterns

All three major providers—Anthropic, OpenAI, and Google—now offer official Go SDKs alongside Python and TypeScript. The patterns have converged: every SDK supports streaming via Server-Sent Events, retry with exponential backoff, and structured output extraction, though the mechanisms differ.

**Anthropic (Claude)** ships `github.com/anthropics/anthropic-sdk-go` (GA, requires Go 1.23+), Python SDK v0.89.0, and TypeScript `@anthropic-ai/sdk`. Default retry is **2 retries** with exponential backoff on 429, 500+, and connection errors. Timeouts default to 10 minutes but should be tuned shorter. In Go, use `context.WithTimeout` for per-request control and `option.WithMaxRetries(5)` to adjust retries. Streaming emits `message_start`, `content_block_delta`, and `message_stop` events. Anthropic uses **tool-based structured output**—define a JSON schema as a "tool," force the model to use it via `tool_choice`, then extract from `tool_use` content blocks. The `Instructor` library wraps this for type-safe Pydantic/Zod validation. Every response includes `usage.input_tokens` and `usage.output_tokens`, plus cache-specific token counts.

**OpenAI** provides `github.com/openai/openai-go` (beta), Python v2.30.0, and TypeScript v6.33.0. OpenAI is migrating from Chat Completions to the **Responses API** (`/v1/responses`), with the Assistants API sunsetting August 2026. OpenAI offers **native Structured Outputs** enforced at the token generation level via context-free grammars—**100% schema adherence guaranteed**. Use `response_format` with a JSON Schema or `strict: true` in tool definitions. SDK helpers like `zodResponseFormat()` in TypeScript auto-convert schemas and deserialize responses. Always check `message.refusal` before parsing. Cost tracking uses the `/v1/organization/usage` endpoint for programmatic spend queries.

**Google (Gemini)** ships `google.golang.org/genai` (Go), `google-genai` (Python), and `@google/genai` (TypeScript). The older SDKs are deprecated. Gemini supports full JSON Schema via `response_mime_type: "application/json"` with `response_json_schema`. A notable feature: Gemini offers **OpenAI SDK compatibility**—change `base_url` to `https://generativelanguage.googleapis.com/v1beta/openai/` and use the OpenAI client directly.

**Production best practices across all providers:** always use streaming for long outputs to reduce timeout risk; pin model snapshots in production (e.g., `claude-sonnet-4-5-20250929` not `claude-sonnet-4-5`); reuse client instances for connection pooling; track request IDs from response headers for debugging; tag every request with `user_id` and `feature_name` for cost attribution.

```go
// Go pattern: context-based timeout with retry
ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
defer cancel()

msg, err := client.Messages.New(ctx,
    anthropic.MessageNewParams{
        Model:     anthropic.ModelClaudeSonnet4_5,
        MaxTokens: 1024,
        Messages:  messages,
    },
    option.WithMaxRetries(3),
)
// Extract cost: msg.Usage.InputTokens, msg.Usage.OutputTokens
```

---

## 2. RAG systems combine five components that each need tuning

A production RAG pipeline has five stages: embedding, storage, chunking, retrieval with re-ranking, and hybrid search. Getting each right determines whether your AI feature answers questions accurately or hallucinates.

**Embedding models in 2025–2026** span a wide quality-cost spectrum. OpenAI's **text-embedding-3-small** at **$0.02/million tokens** offers the best cost-to-performance ratio for most use cases (MTEB ~62). For higher quality, **Voyage-3-large** ($0.06/MTok) and Cohere Embed v4 ($0.12/MTok, with **128K token context**—unique for embedding entire documents without chunking) are strong options. The open-source leader is **Qwen3-Embedding-8B** (MTEB 70.58, Apache 2.0, 32K context), though it requires GPU hosting. For production self-hosting, **BGE-M3** (MIT license, 1024 dims) uniquely generates both dense and sparse vectors in one pass, enabling hybrid search from a single model. Use HuggingFace's `text-embeddings-inference` (Rust-based) for deployment. OpenAI's Matryoshka dimension reduction lets you shrink `text-embedding-3-large` from 3072 to 1024 dimensions with only ~2% quality loss, saving 3x on vector storage.

**Vector storage** choice depends on your existing infrastructure. **pgvector** is ideal if you're already on Postgres and have fewer than 10M vectors—use HNSW indexing (`CREATE INDEX USING hnsw`) for >95% recall. The **pgvectorscale** extension adds StreamingDiskANN indexes achieving 471 QPS at 99% recall on 50M vectors. For performance-critical workloads with heavy metadata filtering, **Qdrant** (Rust-based, predictable p99 latency) excels with its ACORN algorithm for filtered HNSW. **Pinecone Serverless** offers zero-ops managed hosting scaling to billions of vectors but carries vendor lock-in and proprietary sparse encoding. **Weaviate** leads in native hybrid search with built-in BM25F + vector fusion. Use **Chroma** only for local prototyping.

**Chunking** should start with `RecursiveCharacterTextSplitter` at **512 tokens with 50–75 token overlap** (10–15%). This iterates through separators (`\n\n` → `\n` → `. ` → ` `) preserving document structure. For factoid Q&A, shrink to 256 tokens; for complex analytical queries, expand to 1024. NVIDIA research found 15% overlap optimal. Newer approaches include Anthropic's **Contextual Retrieval** (prepending LLM-generated context summaries to each chunk before embedding) and semantic chunking (detecting topic boundaries via embedding similarity between consecutive sentences).

**Re-ranking** is the highest-ROI addition to most RAG systems, typically improving precision **10–25%**. The production pattern is two-stage: retrieve broadly (top-50 via vector search for recall), then rank precisely (re-ranker selects top-5 for precision). **Cohere Rerank v3.5** costs $2/1000 searches and supports 100+ languages. For self-hosted, **FlashRank** delivers 15–30ms latency for 50 candidates—best latency/quality tradeoff. The open-source **mxbai-rerank-large-v2** (Apache 2.0, 1.5B params) claims SOTA on BEIR. Re-ranking helps most with noisy retrieval and complex queries; it adds little when retrieving only 3 documents or when embeddings already produce clean results.

**Hybrid search** combines vector similarity (semantic understanding) with BM25 keyword matching (exact term precision). Neither alone suffices—queries containing product codes, error IDs, or legal citations need keyword precision, while paraphrased questions need semantic matching. **Reciprocal Rank Fusion (RRF)** merges results: `RRF_score(d) = Σ 1/(60 + rank_i(d))`. It operates on ranks not raw scores, avoiding the incompatible-scale problem. Weaviate offers best-in-class native hybrid search; Qdrant supports it via named vectors (v1.9+); pgvector requires the **ParadeDB** extension for BM25. The full production pipeline: Query → Hybrid Search (BM25 + Vector, RRF, top-50) → Re-ranking (top-5) → LLM Generation.

**Measure retrieval quality** with RAGAS (reference-free, lightweight) and DeepEval (Pytest-like, self-explaining metrics, CI/CD integration). Track Precision@K, Recall@K, MRR, and NDCG. Common failure modes: missing context (recall problem), context poisoning (precision problem), lost-in-the-middle (LLMs miss info buried in long contexts), and query-document vocabulary mismatch (fix with hybrid search).

---

## 3. Prompts should be versioned, tested, and deployed like code

The shift from "prompt engineering" to "prompt engineering as code" means treating prompts with the same rigor as application logic: version control, automated testing, CI/CD gates, and A/B testing.

**Templating** has converged on double-curly-brace syntax (`{{variable}}`) for maximum tool compatibility. Promptfoo uses Nunjucks (JavaScript Jinja2 equivalent) with filters, conditionals, and loops. Langfuse uses Mustache-style `{{variable}}`. Store prompts as separate files in a `prompts/` directory, not inline in code. For Go applications, Go's `text/template` package maps naturally to this pattern.

**Promptfoo** (acquired by OpenAI, March 2026, remains MIT-licensed, ~19.4K GitHub stars) is the standard for prompt evaluation. Install via `npm install -g promptfoo` or `pip install promptfoo`. Configure with `promptfooconfig.yaml` defining prompts, providers, and test cases with assertions. Assertion types span deterministic checks (`contains`, `regex`, `javascript`, `cost`, `latency`) and model-assisted evaluation (`llm-rubric`, `similar` via embedding cosine similarity, `g-eval`). Promptfoo runs matrix testing across prompt × model × test case combinations, integrates with CI/CD via exit codes, and supports red-teaming with automated vulnerability scanning.

```yaml
# promptfooconfig.yaml
prompts:
  - file://prompts/support_agent.txt
providers:
  - anthropic:messages:claude-sonnet-4-5
tests:
  - vars: { query: "How do I return a product?" }
    assert:
      - type: contains
        value: "return policy"
      - type: llm-rubric
        value: "Response is helpful and professional"
      - type: cost
        threshold: 0.01
      - type: latency
        threshold: 3000
```

**Prompt versioning** tools include Langfuse (centralized version control with "production"/"staging" labels, server+client caching), Braintrust (content-addressable version IDs, GitHub Action for CI/CD), and PromptLayer ("Git for prompts" with visual registry and A/B testing, $49/mo). Humanloop shut down September 2025; Pezzo offers a fully open-source alternative (Apache 2.0).

**The CI/CD workflow for prompts** follows: developer changes prompt → PR triggers eval pipeline → Promptfoo/Braintrust runs test suite → quality gate checks accuracy ≥ threshold, cost ≤ budget, latency ≤ limit → PR blocked on failure → on merge, prompt promoted to production. Braintrust's GitHub Action posts detailed eval comparison on PRs and blocks merges when quality drops.

**Prompt cost optimization** techniques yield **60–80% reductions**: tighten language (15–35% token reduction), use structured JSON output instead of verbose prose, leverage Anthropic's explicit `cache_control` for **90% cost reduction** on cached input tokens, apply semantic caching for similar queries, route simple tasks to cheap models, compress prompts with LLMLingua (up to 20x), summarize conversation history instead of sending full chat (20–40% token reduction), and set explicit `max_tokens` on output since output tokens cost 2–5x more than input.

---

## 4. AI observability tracks tokens, latency, quality, and cost per feature

Monitoring AI calls in production requires purpose-built tooling because traditional APM doesn't capture token usage, prompt versions, or output quality.

**Langfuse** (MIT license, acquired by ClickHouse, 24K+ GitHub stars) is the leading open-source platform. It provides hierarchical tracing with spans for generations, retrievals, and tool calls; auto-calculates cost per model; supports LLM-as-a-Judge evaluations; and includes prompt management with version control. Self-hosting is free with no caps. Integration is minimal:

```python
from langfuse.decorators import observe, langfuse_context

@observe(as_type="generation")
def call_llm(prompt: str, user_id: str):
    langfuse_context.update_current_trace(
        user_id=user_id,
        metadata={"feature": "document_qa"}
    )
    response = client.chat.completions.create(...)
    return response.choices[0].message.content
```

Cloud pricing ranges from free (50K units/mo) to $199/mo (Pro). TypeScript and Python SDKs available, plus OpenTelemetry integration for framework-agnostic instrumentation.

**Helicone** takes a proxy-based approach—change one line (the base URL) for instant observability. Built in Rust with **8ms P50 latency**, it auto-logs cost, latency, tokens, and model for every request. Includes built-in caching (20–30% cost reduction), prompt versioning, and session traces. Free for 100K requests/mo; Pro is $25/mo.

**Portkey** (Gartner Cool Vendor 2025) is a full AI gateway + control plane processing **2+ trillion tokens/day** with <1ms gateway latency. It connects to 1,600+ LLMs and provides routing, guardrails, prompt management, and caching alongside observability. The gateway is now open-source.

**Braintrust** differentiates by connecting evaluation directly to observability—used by Notion, Stripe, Zapier, and Vercel. Its "Loop" AI agent auto-generates better prompts and scorers. Brainstore (purpose-built database) delivers **80x faster queries** than traditional DBs for AI logs. Free tier includes 1M spans and 10K scores.

**LangSmith** offers the deepest LangChain integration with trace capture of every step: prompt construction, LLM call, tool execution, output parsing. Production traces convert to test datasets with one click. Pricing starts free (5K traces/mo) to $39/seat/mo (Plus).

**Metrics to instrument:** input/output tokens per request and per feature; cost per request with daily/weekly rollups; P50/P95/P99 latency and time-to-first-token for streaming; LLM-as-judge quality scores; hallucination rates (faithfulness, contradictions); user feedback signals; error and rate-limit-hit rates by provider.

**Hallucination detection** in production uses multiple approaches: LLM-as-Judge evaluating faithfulness against provided context (most common), NLI-based token classification with models like DeBERTa (HaluGate achieves 76–162ms overhead), self-consistency checks across multiple sampled responses (SelfCheckGPT), and RAGAS faithfulness scoring for RAG pipelines.

---

## 5. Rate limit management across subscription pools needs a custom pool manager

Managing **7 Claude Max subscriptions + 1 ChatGPT Pro subscription** requires a pool manager that tracks per-subscription capacity, queues requests by priority, and routes to the least-loaded subscription.

**Anthropic** enforces rate limits across three dimensions: RPM (requests/minute), ITPM (input tokens/minute), and OTPM (output tokens/minute). Crucially, **cached input tokens don't count toward ITPM**, so prompt caching with 80% hit rate effectively gives 5x throughput. Tier 4 (requiring $400+ credits) allows 4,000 RPM and 2M ITPM for Sonnet models. Anthropic officially uses **token bucket** replenishment—capacity continuously refills rather than resetting at fixed intervals.

**OpenAI** measures RPM and TPM (total tokens/minute, input+output combined). Limits are per-organization and per-model—all API keys under one org share pools. Tier 5 ($1,000+ lifetime spend) unlocks 15,000 RPM and 40M TPM. Rolling 60-second and 24-hour windows apply; there's no midnight reset.

**The token bucket algorithm** is the right choice for AI rate limiting because it handles natural burst patterns and matches how providers enforce limits. Go's standard `golang.org/x/time/rate` package implements it cleanly:

```go
// Per-subscription rate limiters
type Subscription struct {
    ID        string
    Provider  string
    APIKey    string
    Limiter   *rate.Limiter  // golang.org/x/time/rate
    RPMUsed   atomic.Int64
    TPMUsed   atomic.Int64
    Health    atomic.Value   // float64 health score
}

// Pool selects best subscription by remaining capacity × health
func (p *Pool) SelectBest(estimatedTokens int) *Subscription {
    var best *Subscription
    bestScore := -1.0
    for _, sub := range p.subscriptions {
        remaining := 1.0 - float64(sub.RPMUsed.Load())/float64(sub.rpmLimit)
        tokenRoom := 1.0 - float64(sub.TPMUsed.Load())/float64(sub.tpmLimit)
        score := remaining * tokenRoom * sub.Health.Load().(float64)
        if score > bestScore {
            bestScore = score
            best = sub
        }
    }
    return best
}
```

**Priority-based routing** uses Go's `container/heap` for a 3-tier priority queue: Priority 1 (critical user-facing requests) routes to the least-loaded subscription; Priority 2 (standard) uses round-robin; Priority 3 (background/batch) consumes spare capacity. On 429 from any subscription, immediately route to the next available and mark the exhausted one with a cooldown timer from the `retry-after` header.

**Pre-emptive rate limiting** parses response headers (`anthropic-ratelimit-requests-remaining`, `x-ratelimit-remaining-tokens`) after each call to update subscription state. When remaining capacity drops below 10%, proactively route to other subscriptions rather than waiting for a 429. This avoids the latency penalty of failed requests.

**Gateway solutions** for pool management include Bifrost (open-source, Go-based, weighted load balancing with automatic failover), Portkey (load balancing with nested fallback strategies), and LiteLLM (multi-provider proxy with Redis for distributed state). For the 7+1 subscription scenario, a custom Go pool manager gives the most control, using `golang.org/x/time/rate` per-key limiters combined with health-score-based routing.

---

## 6. AI safety requires defense-in-depth because no single layer is sufficient

Prompt injection remains the #1 vulnerability in the OWASP LLM Top 10 for 2025. Joint research from OpenAI, Anthropic, and Google DeepMind tested 12 published defenses and **bypassed all with >90% success rate**. The consensus is defense-in-depth: multiple layers each raising the bar.

**Input validation** starts with content filtering via **LlamaGuard 3** (Meta, open-source), which classifies inputs into 14 harm categories and runs on a single GPU or via API at ~$0.00002/request. Enforce strict input length limits, strip manipulative phrases ("ignore previous instructions"), and wrap user content in delimiters (`<user_msg>...</user_msg>`) to separate from system instructions. Rate-limit based on prompt semantics, not just volume.

**Output validation** means never trusting raw LLM output. Use OpenAI's native Structured Outputs (100% schema adherence via CFG enforcement), Anthropic's tool-based extraction with Pydantic/Zod validation through the Instructor library, or Guardrails AI validators. Validate at three levels: syntactic (valid JSON), structural (correct fields and types), semantic (values make sense). Run outputs through safety classifiers and PII detectors before returning to users. Apply output encoding to prevent XSS from LLM-generated content.

**PII detection and redaction** uses **Microsoft Presidio** (v2.2.361, open-source) with a two-component architecture: the Analyzer detects PII using NER, regex, and rule-based logic across 30+ entity types, and the Anonymizer replaces, redacts, hashes, masks, or encrypts detected PII. The production pattern is "redact-then-send": detect PII, anonymize before sending to LLM, store the original↔anonymized mapping, then de-anonymize the response. Presidio supports custom `PatternRecognizer` instances with regex + context words for domain-specific PII like customer IDs. Alternative tools include Google Cloud DLP API (150+ info types), AWS Comprehend, and Azure AI Language PII.

**Prompt injection prevention** requires multiple layers since no single defense works. Effective strategies: harden system prompts with explicit role boundaries and "sandwich defense" (reiterate rules after user content); classify inputs with dedicated prompt injection detectors (LlamaGuard, PromptGuard); use an **LLM-as-Critic** to evaluate primary model output (improved detection precision by 21%); embed canary tokens to detect system prompt leakage; enforce least privilege for tool access; require human approval for high-risk operations. Google DeepMind's CaMeL framework uses capability-based access control inspired by software security.

**Guardrails frameworks** complement each other. **Guardrails AI** handles input/output validation with chainable validators from its Hub (toxic language, competitor mentions, PII, regex). **NeMo Guardrails** (NVIDIA, Apache 2.0, 5,926+ stars) provides state-machine conversational control using the **Colang** language for defining flows and safety rules, with parallel guardrail execution adding only ~0.5s latency. **Rebuff** (Protect AI) uses multi-layered detection: heuristics → LLM analysis → VectorDB similarity → canary tokens. **LLM Guard** offers fine-tuned BERT-based scanners for both input and output. The production pipeline chains them: User Input → LlamaGuard + Rebuff + PII scan → Prompt Hardening → LLM → Content filter + Schema validation + PII check → Application.

---

## 7. Two-layer caching cuts AI costs 25–73% with minimal complexity

Caching is the single highest-ROI optimization for AI-powered SaaS. A two-layer approach—exact match first, then semantic similarity—captures both identical and paraphrased queries.

**Exact match caching** hashes the full request (model + system prompt + messages + temperature + max_tokens + org_id) with SHA-256 and checks Redis. It's fast (~2ms lookup), simple to implement, and catches 10–25% of requests depending on the application type. Classification pipelines see the highest hit rates (15–25%); code assistants the lowest (5–8%). Exclude request IDs and timestamps from cache keys. Use exact caching for deterministic queries (temperature=0) and structured data extraction.

**Semantic caching** converts queries to vector embeddings, searches for cached queries with cosine similarity above a threshold, and returns cached responses for similar-enough questions. Research demonstrates **61.6–68.8% cache hit rates** with **97%+ accuracy** of returned cached responses. The critical hyperparameter is the similarity threshold: start at **0.95** (catches paraphrases, low false positives) and tune per query type. A threshold of 0.85 produces incorrect hits (e.g., "How to return an item?" matching "How much does return shipping cost?"). Redis Stack with vector similarity search via **RedisVL SemanticCache** provides a production-ready implementation:

```python
from redisvl.extensions.llmcache import SemanticCache

llmcache = SemanticCache(
    name="llmcache",
    redis_url="redis://localhost:6379",
    distance_threshold=0.1  # lower = stricter
)
llmcache.store(prompt="What is the capital of France?", response="Paris")
# Returns cached response for "What's France's capital city?"
response = llmcache.check(prompt="What's France's capital city?")
```

**The two-layer architecture** flows: request arrives → compute SHA-256 hash → exact match check in Redis (HIT → return in ~2ms) → on MISS, generate embedding, search vector store for similarity ≥ 0.95 (HIT → return in ~50ms) → on MISS, forward to LLM → store response in both exact and semantic caches → return with `X-Cache: HIT/MISS` header.

**Real production numbers** confirm the economics. For 500K requests/month at $0.012 average cost: no cache costs $6,000/month; exact match only (10% hit rate) saves $600; exact + semantic (25% hit rate) saves $1,500. A VentureBeat case study reported exact match capturing 18% of redundant calls, semantic caching increasing total hit rate to 67%, **reducing LLM API costs by 73%** with a 0.8% false-positive rate. Even 10% hit rate pays for cache infrastructure 20x over. Anything above 60% hit rate suggests you may not need an LLM at all for that workload.

**Cache invalidation** uses TTL as the primary mechanism (FAQ responses: 24h, content generation: 1h, data analysis: 15min). Include prompt version in cache keys so prompt changes automatically invalidate entries. Add random jitter to TTLs to prevent cache stampede. For event-based invalidation (document updated, product name changed), exact match caches support targeted key deletion; semantic caches typically require broader flush strategies.

**Gateway solutions with built-in caching:** Bifrost (open-source, dual-layer exact + semantic), Helicone (proxy-based, 20–30% cost reduction), Kong AI Gateway (semantic caching, enterprise), LiteLLM (Redis semantic caching mode).

**What NOT to cache:** personalized responses dependent on user-specific data, time-sensitive queries, creative generation with high temperature (>0.7), multi-turn conversations with changing context, and endpoints with fewer than 1,000 requests/day (engineering overhead exceeds savings).

---

## 8. Multi-model routing matches task complexity to model cost

Using a single frontier model for everything wastes 50–90% of spend. **70% of typical SaaS AI workload is routine** (classification, extraction, simple Q&A) that a cheap model handles equally well.

The routing strategy maps task complexity to model tier: classification and simple tasks use budget models (Claude Haiku 4.5, GPT-5 nano at **$0.05–0.25/MTok**), standard generation uses mid-tier (Claude Sonnet 4.5, GPT-5 mini), and complex reasoning uses frontier models (Claude Opus 4.6, GPT-5.2 at **$1.75–25/MTok**). For agentic workflows, model selection per step matters enormously—100 steps at 1% per-step error rate yields only 37% correct execution probability.

**LiteLLM** (open-source, 470K+ PyPI downloads) provides a unified `litellm.completion()` interface for 100+ providers with an OpenAI-compatible proxy server. It supports load balancing strategies (`simple-shuffle`, `least-busy`, `usage-based-routing`, `latency-based-routing`), typed fallback chains (general, context-window, content-policy), spend tracking with budget enforcement, and Redis for distributed state. Best for self-hosted environments needing full control. **OpenRouter** (managed SaaS, $40M raised at $500M valuation, 600+ models) offers drop-in OpenAI SDK compatibility with one API key, an Auto Router selecting from 33 models based on prompt analysis (`model: "openrouter/auto"`), and ~25–40ms added latency with a 5–5.5% platform fee. **Martian** uses interpretability-based routing—predicting model performance without running it—with cost threshold APIs. **Unify.ai** trains neural network routers on live benchmarks with adjustable quality/cost/latency sliders and custom router training on your data.

**Model fallback chains** trigger on errors (429, 500, timeout, context window exceeded). LiteLLM's YAML config makes this declarative:

```yaml
model_list:
  - model_name: primary
    litellm_params:
      model: anthropic/claude-sonnet-4-5-20250929
  - model_name: fallback
    litellm_params:
      model: openai/gpt-4.1
router_settings:
  fallbacks:
    - primary: [fallback]
  context_window_fallbacks:
    - primary: [large-context-model]
```

**A/B testing models** uses feature flags to randomly assign traffic percentages, with LiteLLM's `weight` parameter on deployments for weighted distribution. Shadow testing sends production requests to both models, returns the primary result, and logs both for offline comparison via observability tools (Langfuse traces, Braintrust evals).

---

## 9. AI feature flags need quality and cost gates beyond boolean toggles

AI features fail differently from traditional features—subtly. Engagement may rise while conversion drops. Response quality degrades for specific input distributions. These problems surface only with real traffic, making gradual rollouts with automated quality monitoring essential.

**The rollout pattern:** deploy behind a flag at 0% → enable for 1–5% (internal/beta users) → monitor AI-specific metrics (hallucination rate, relevance, cost per interaction) → pause deliberately at each step (the **5–50% range** is where most production AI issues surface) → expand only when all metrics are healthy → clean up flag at 100%. Use **object-valued flags** (not boolean) to control model version, temperature, max_tokens, and prompt version simultaneously.

**Quality gates** use automated evaluation before expanding rollout. Run LLM-as-Judge on a sample of production traces at each percentage, with minimum passing thresholds. Binary pass/fail judgments correlate better with actual quality than granular scales (validated across 30+ companies). Tools like Opik (Comet) provide online evaluation rules for continuous monitoring. Key metrics: hallucination rate < 5%, relevance score > 0.8, latency P95 < target, cost per interaction within budget.

**Cost monitoring gates** implement graduated alerts: green (baseline), yellow (2σ above rolling average), red (runaway spending). Three triggers to configure: single request exceeds 3x median token count, hourly spend crosses ceiling, agent makes >5 external tool calls per session. Enforcement options range from downgrading to a cheaper model tier, queueing requests, serving cached responses, to blocking access entirely. Implement hierarchical budgets: global caps → team → feature → user.

**User feedback** follows the thumbs-up/down pattern standard across ChatGPT and Claude. On thumbs-down, show structured follow-up categories ("Not accurate," "Poor quality," "Doesn't match prompt") plus optional free text. Track implicit signals too: correction rates, override patterns, task abandonment, retry frequency, copy-to-clipboard actions. Feed both explicit and implicit feedback into evaluation datasets. DSPy can optimize prompts algorithmically based on aggregated evaluation metrics.

**Feature flag platforms:** **LaunchDarkly** now offers dedicated **AI Configs** (GA) with AI Model Flags (JSON controlling modelID, temperature, max_tokens) and AI Prompt Flags for segment-targeted prompt iterations. Its Release Guardian auto-detects errors and triggers rollback. **Unleash** (open-source, Apache 2.0, 18M+ Docker downloads) provides gradual rollouts and kill switches with custom strategy support. **OpenFeature** (CNCF) provides a vendor-agnostic API—adopt this to swap backends (LaunchDarkly ↔ Unleash) without refactoring application code.

---

## 10. Established patterns and conventions anchor the AI engineering discipline

The architectural patterns, configuration conventions, and engineering practices for AI integration have matured into a recognizable discipline by 2026.

**The AI Gateway pattern** has emerged as the most important architectural decision. Analogous to API gateways for microservices, it provides a centralized control plane for all AI interactions: unified endpoint, authentication, rate limiting, token budgeting, failover, semantic caching, cost analytics, and prompt validation. **Bifrost** (open-source, Go-based, 11µs overhead at 5K RPS) leads for self-hosted deployments. Even if using one provider today, the abstraction layer prevents vendor lock-in as models rapidly evolve.

**Configuration file conventions** have proliferated, with a universal standard emerging. Every major AI coding tool now reads markdown config files from repositories:

- **AGENTS.md** — the emerging universal standard, backed by the Linux Foundation's Agentic AI Foundation, supported by Claude Code, Cursor, GitHub Copilot, and Codex. Structure: Project Overview → Build & Test → Code Guidelines → Architecture → Conventions.
- **CLAUDE.md** — Anthropic's format for Claude Code, auto-generated via `/init`, supports hierarchical directory placement and `.local.md` variants for personal settings.
- **SKILL.md** — open standard for reusable agent skills with YAML frontmatter + Markdown. Progressive disclosure: agents load only name+description at startup, activating full content on demand. Works across Claude Code, OpenAI Codex, Gemini CLI, Cursor, and Aider.
- `.cursor/rules/` (Cursor), `.github/copilot-instructions.md` (Copilot), `GEMINI.md` (Gemini CLI) for tool-specific configuration.

**SKILL.md best practices:** the `description` field is the most important (it's semantic matching, not a tagline); include scope boundaries ("Do NOT use for frontend code"); add a "Gotchas" section (highest ROI); use imperative steps with explicit inputs and outputs; keep each skill focused on one job; update when stack changes.

**Go-specific patterns** for AI integration leverage the language's strengths: `context.Context` everywhere for cancellation, timeouts, and tracing; channels (`<-chan ChatCompletionChunk`) for streaming; typed sentinel errors with `errors.Is`/`errors.As`; functional options (`openai.New(WithAPIKey("..."), WithTimeout(30*time.Second))`); interface-based provider abstraction for swappability. Key Go libraries include **LangChainGo** (`tmc/langchaingo`, 850+ importers), **Google ADK Go** (`google/adk-go`, v1.0, multi-agent with OpenTelemetry), **Eino** (ByteDance's framework with circuit breakers), and **any-llm-go** (Mozilla AI, single interface for 8+ providers, "feels like Go, not Go wearing Python's clothes").

**Martin Fowler's "Harness Engineering"** concept frames the emerging discipline: an AI agent = Model + Harness, where the harness consists of **guides** (feed-forward controls: AGENTS.md, SKILL.md, architecture descriptions) and **sensors** (feedback controls: tests, linters, type checkers, LLM-as-judge). Two execution types interact: Computational (deterministic, fast) and Inferential (semantic, LLM-based).

**Critical anti-patterns to avoid:** "vibe-checking" instead of proper evaluation (use golden response datasets and LLM-as-Judge); silent confabulation in RAG without forced source citation; overloading single prompts instead of breaking into atomic pieces; over-indexing on frameworks ("at its core, an LLM call is just an HTTP request"); using frontier models for simple tasks (40x cost premium); giving agents too much autonomy without supervised steps; tightly coupling to one provider without gateway abstraction.

---

## Conclusion: the integration stack as a coherent system

The ten areas covered here aren't independent—they form an interconnected system. The **AI Gateway** (area 10) serves as the architectural backbone, implementing **rate limit management** (area 5), **multi-model routing** (area 8), and **caching** (area 7) in one layer. **Observability** (area 4) instruments every call flowing through the gateway, enabling **cost monitoring gates** in **feature flags** (area 9) and feeding data to **prompt testing** (area 3). **RAG** (area 2) and **safety** (area 6) sit in the application layer, with structured outputs from **API integration** (area 1) ensuring type-safe pipelines end-to-end.

Three insights stand out from this research. First, **evaluation-driven development** has replaced manual testing—write evals before building features, run them in CI/CD, and gate deployments on quality thresholds. Second, the **cost optimization stack** compounds: model routing (50–90% savings on routine tasks) × prompt caching (90% on repeated prefixes) × semantic caching (25–73% on similar queries) × batching (50% on non-urgent work) can reduce total AI spend by an order of magnitude. Third, the shift toward **AGENTS.md and SKILL.md** as universal standards signals that AI integration patterns are maturing from ad-hoc experimentation into repeatable engineering—the same trajectory that web APIs, containerization, and CI/CD followed in prior decades.