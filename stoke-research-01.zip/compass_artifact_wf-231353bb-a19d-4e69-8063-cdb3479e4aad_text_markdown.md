# MCP server implementation patterns for AI tool development

**MCP has become the universal standard for connecting AI models to external tools**, with native support from every major provider — Anthropic, OpenAI, Google, Microsoft, and AWS — and adoption across all leading AI coding tools. The protocol uses JSON-RPC 2.0 over stdio or Streamable HTTP, with a mature Go ecosystem offering two production-ready SDKs. Transport overhead is negligible (**<10ms per call**), but the real performance cost lies in token inflation from tool schemas, which can balloon context usage by 2x–30x. For teams building custom AI coding harnesses, MCP provides genuine value as an internal tool interface when tools need to be reusable across agents, but direct function calls remain simpler for small prototypes with few tools.

## The Go SDK landscape has consolidated around two strong options

Two Go libraries dominate the MCP ecosystem. The **official SDK** (`modelcontextprotocol/go-sdk`, ~3,800 stars) reached v1.3.0 in February 2026, built in collaboration with Google. The **community SDK** (`mark3labs/mcp-go`, ~8,200 stars) predates it and inspired much of the official design. Both support the latest spec version (2025-11-25) and offer idiomatic Go APIs.

The official SDK uses generics for typed tool handlers, auto-inferring input schemas from Go structs via `jsonschema` tags:

```go
server := mcp.NewServer(&mcp.Implementation{Name: "my-server", Version: "v1.0.0"}, nil)
mcp.AddTool(server, &mcp.Tool{Name: "greet", Description: "say hi"}, func(ctx context.Context, req *mcp.CallToolRequest, input struct {
    Name string `json:"name" jsonschema:"the name to greet"`
}) (*mcp.CallToolResult, struct{ Greeting string }, error) {
    return nil, struct{ Greeting string }{"Hi " + input.Name}, nil
})
server.Run(context.Background(), &mcp.StdioTransport{})
```

The `mark3labs/mcp-go` library uses a builder pattern with explicit parameter helpers — `mcp.WithString()`, `mcp.WithNumber()`, `mcp.Required()` — and provides richer transport support including stdio, SSE, Streamable HTTP, and an in-process transport ideal for testing. It also supports session management, request hooks for telemetry, per-session tool filtering, and async task-augmented tools. Both SDKs also offer `metoro-io/mcp-golang` (struct-based, low boilerplate) and `ThinkInAIXYZ/go-mcp` (web framework integration via `http.Handler`) as alternatives, though these have smaller communities.

A minimal from-scratch implementation requires only a `bufio.Scanner` reading newline-delimited JSON from stdin, a method dispatcher routing `initialize`, `tools/list`, and `tools/call`, and JSON-encoded responses written to stdout. The core protocol is simple enough that **~80 lines of Go** can handle the full lifecycle. However, production implementations need proper request ID handling (IDs can be strings or numbers), notification detection (no `id` field means no response), input schema validation, cancellation support, and pagination for tool lists.

## The JSON-RPC protocol flow follows a strict three-phase handshake

Every MCP session begins with capability negotiation. The client sends an `initialize` request declaring its `protocolVersion` and capabilities (roots, sampling). The server responds with its own capabilities (tools, resources) and server info. The client then sends an `initialized` notification (no `id`, no response expected) to signal readiness.

After initialization, the client discovers tools via `tools/list`, which returns an array of tool definitions each containing a `name`, `description`, and `inputSchema` (JSON Schema). Tool invocation uses `tools/call` with the tool name and arguments, returning a `content` array of typed items (`text`, `image`, `resource_link`) plus an `isError` boolean. Tool execution errors are returned as successful JSON-RPC responses with `isError: true` — protocol-level errors (method not found, parse error) use standard JSON-RPC error codes.

There is **no explicit shutdown method** in MCP. For stdio transport, the client closes stdin/stdout or terminates the server process. For Streamable HTTP, the client sends a DELETE request to terminate the session. The spec defines additional methods including `ping` (health check), `notifications/tools/list_changed` (dynamic tool updates), `cancelled` (cancel in-progress work), `sampling/createMessage` (server requests LLM completions from the client), and `elicitation/create` (server requests user input).

The specification has evolved through four versions: **2024-11-05** (initial release with stdio + SSE), **2025-03-26** (Streamable HTTP replacing SSE, OAuth 2.1, tool annotations), **2025-06-18** (structured outputs, elicitation), and the current **2025-11-25** (tasks for async operations, extensions framework, icons, OpenID Connect Discovery). The protocol was donated to the **Agentic AI Foundation** under the Linux Foundation in December 2025, co-founded by Anthropic, Block, and OpenAI.

## Architecture patterns favor single-responsibility servers with client-side aggregation

The MCP specification explicitly recommends **focused, single-purpose servers** over monolithic ones. A filesystem server, a GitHub server, and a database server should each be separate processes rather than bundled into one. This maps directly to how hosts like Claude Code manage connections — each configured server gets its own MCP client instance, and the AI model sees a unified tool list aggregated across all connected servers.

Tools, resources, and prompts serve distinct roles in the architecture. **Tools** are model-controlled (the AI decides when to call them), **resources** are application-controlled (the client app decides how to use data), and **prompts** are user-controlled (exposed through slash commands or menus). For most use cases — especially documentation serving and coding assistance — tools are the right primitive because the model needs autonomous discovery and invocation capability.

Composability works at three levels. **Client-side aggregation** is the default: Claude Code's `.mcp.json` file lists multiple servers, and the host creates one client per server, merging tool lists transparently. **Server-side composition** uses patterns like FastMCP's `mount()` to combine sub-servers with namespacing (tool `get_data` becomes `weather_get_data` and `calendar_get_data`). **Aggregator gateways** like MetaMCP and ToolHive provide a single endpoint that proxies to multiple backend servers with conflict resolution strategies (prefix, priority, or manual override).

A critical consideration is **tool pollution**. Benchmarks across six LLMs found accuracy degradation as tool counts grew from 25 to 150 — GPT-4o dropped from **81.7% to 73.3%** accuracy. Claude Code addresses this with Tool Search, which defers tool definition loading and searches on demand, improving Opus 4 tool selection accuracy from 49% to 74% and reducing context consumption by roughly 95%.

## Transport latency is negligible but token inflation is the real cost

The two supported transports are **stdio** (local, subprocess-based, sub-millisecond per message) and **Streamable HTTP** (remote, single-endpoint, supports both JSON responses and SSE streaming). SSE as a standalone transport was deprecated in the March 2025 spec revision. Stdio adds roughly **4–9ms startup latency** from process spawn to ready state, with negligible per-message overhead. Streamable HTTP adds standard HTTP overhead but enables remote access, multi-client scenarios, and serverless deployment.

Published benchmarks from TM Dev Lab (the most rigorous MCP performance study found) tested 15 implementations across 39.9 million requests. Over Streamable HTTP with I/O-bound workloads:

- **Rust (rmcp)**: 5.09ms avg latency, 4,845 RPS, 10.9 MB memory
- **Go (mcp-go)**: ~6ms avg latency, 3,616 RPS, 23.9 MB memory  
- **Java (Quarkus)**: 4.04ms avg latency, 4,739 RPS, 194.5 MB memory
- **Node.js**: ~400 RPS with notably higher latency
- **Python (FastMCP)**: 259 RPS, ~19x slower than Rust

Microsoft's analysis found MCP is approximately **15–25% slower than direct REST** due to JSON-RPC overhead, with serialization adding 10–15% under concurrent load. However, multiple sources converge on the same conclusion: **80% of wall-clock time lives in the backend**, and transport overhead is dwarfed by LLM inference time.

The real performance bottleneck is **semantic latency** — token inflation from loading tool schemas into context. An academic study found MCP-enabled usage patterns cause **2x to 30x token inflation** compared to baseline chat. Tasks requiring ~1,000 tokens via clean REST interfaces ballooned to ~20,000 tokens through MCP tool definitions. Anthropic's proposed mitigation — presenting MCP servers as code APIs rather than direct tool calls — achieved a **98.7% token reduction** in one example by having agents write code that calls tools programmatically with progressive disclosure.

## When MCP makes sense for custom agentic harnesses

For a custom AI coding harness that isn't using Claude Code CLI, MCP provides genuine value in specific scenarios. Use MCP when building production systems with reusable tools across multiple agents, when vendor flexibility matters (swap Claude for GPT without rewriting integrations), when ecosystem compatibility is needed (thousands of community MCP servers for GitHub, databases, cloud services), and when long-term maintainability matters (tools independently versioned and deployed).

Use direct function calls when building small prototypes with 2–3 tools, when deterministic low-latency operations are critical (real-time analytics, financial transactions), when tools are tightly coupled to one specific application, and when minimal overhead is the priority. Direct function calling is roughly 20 lines of code versus a full MCP server setup.

Framework integration is mature. LangChain wraps MCP server tools as `StructuredTool` objects for orchestration. LlamaIndex has first-class support via `llama-index-tools-mcp` for both consuming and serving MCP. OpenAI's Agent SDK supports MCP natively with `MCPServerStdio`, `MCPServerSse`, and `MCPServerStreamableHttp` classes. The relationship is complementary: **MCP is the standardized connection layer, frameworks handle orchestration and retrieval**.

## The security model relies on implementation, not protocol enforcement

MCP defines four security principles — user consent, data privacy, tool safety, and LLM sampling controls — but explicitly states that **the protocol itself cannot enforce these at the wire level**. Implementation responsibility falls entirely on hosts and servers. This is both a flexibility feature and a significant risk — an Invariant Labs audit found **43% of early MCP servers contained command injection vulnerabilities**.

Per-tool authorization does not exist at the protocol level. The November 2025 spec introduced Step-Up Authorization Flow for requesting additional OAuth scopes at runtime, but granular tool-level permissions must be implemented in application code. The authorization specification uses OAuth 2.1 with PKCE, separating MCP servers (resource servers) from authorization servers, with three client registration approaches: pre-registration, Client ID Metadata Documents (CIMD, recommended), and Dynamic Client Registration (legacy fallback).

Critical security patterns include strict JSON Schema validation with `additionalProperties: false`, parameterized commands instead of shell concatenation, treating all LLM-originated inputs as untrusted, per-tool outbound network allowlists, containerized execution with least-privilege access, and mandatory human-in-the-loop approval for tool calls. Claude Code enforces write access restricted to the working directory, requires manual approval for suspicious bash commands, and provides organization-level MCP server allowlists. Tool description pinning with cryptographic hashes prevents "tool poisoning" attacks where malicious actors modify tool descriptions to manipulate model behavior.

## Context7 leads the documentation-serving MCP ecosystem

Context7, built by Upstash, is the dominant documentation MCP server with **51,400 GitHub stars** and coverage of **9,000+ libraries and frameworks**. It exposes two tools: `resolve-library-id` (maps a library name to a Context7 ID) and `query-docs` (retrieves version-specific documentation chunks filtered by topic with configurable token limits). Configuration is a single line: `claude mcp add context7 -- npx -y @upstash/context7-mcp`. A remote Streamable HTTP endpoint at `https://mcp.context7.com/mcp` enables team-wide access without local setup.

The broader documentation MCP ecosystem includes **mcpdoc** (LangChain, serves `llms.txt` files with domain-based security restrictions), **LLMDoc** (BM25 + DuckDB full-text search with pagination), **AWS Knowledge MCP Server** (free access to AWS documentation via Bedrock), and **kb-mcp-server** (txtai-powered semantic search with knowledge graph capabilities). Custom documentation servers are straightforward to build with any MCP SDK — define search and retrieval tools, index content with embeddings or keyword search, and deploy via stdio locally or Streamable HTTP for teams.

For team knowledge sharing, Claude Code supports three MCP server scopes: local (private), project (`.mcp.json` committed to git, shared with team), and user (personal across projects). Remote HTTP MCP servers are the recommended pattern for centralized team knowledge bases. Tool output exceeding **10,000 tokens** triggers a warning in Claude Code, so documentation servers should return focused, relevant chunks rather than entire documents.

## Testing relies on the MCP Inspector and in-memory client patterns

The **MCP Inspector** is the official interactive testing tool — a React web UI connected to a Node.js proxy that bridges to MCP servers via stdio, SSE, or Streamable HTTP. It supports tool discovery, invocation with custom parameters, resource browsing, and raw JSON-RPC message inspection. A CLI mode (`npx @modelcontextprotocol/inspector --cli`) enables scripted testing for CI/CD pipelines.

For automated testing, the recommended pattern is **in-memory testing** using SDK client bindings. FastMCP (Python) provides pytest fixtures wrapping servers in Client instances. In Go, table-driven tests with test fixtures encapsulating mocked engines and configurations are the standard pattern. The `mark3labs/mcp-go` library includes an in-process transport specifically designed for testing without subprocess overhead.

Dedicated testing frameworks have emerged: `@haakco/mcp-testing-framework` (automated test generation, coverage analysis, performance benchmarking), `@mcp-testing/server-tester` (Playwright-based deterministic tests plus LLM-as-judge evaluation), and `L-Qun/mcp-testing-framework` (multi-model evaluation testing how different LLMs interpret tool definitions). Protocol conformance testing should verify JSON-RPC lifecycle compliance, error code handling, capability negotiation, and input schema validation. Beyond technical tests, **behavioral testing** — verifying that AI models can actually discover, understand, and correctly invoke tools — is equally critical.

## Every major AI provider and coding tool now supports MCP

MCP achieved universal adoption in roughly 12 months. The compatibility matrix as of early 2026:

| Provider | MCP Support | Key Details |
|----------|-------------|-------------|
| **Claude** (Desktop, Code, API) | Full, native | Creator of MCP. Tool Search, programmatic calling, Desktop Extensions |
| **OpenAI** (ChatGPT, Agents SDK, Codex) | Full | Read/write MCP in ChatGPT for all paid plans. Native SDK support |
| **Google** (Gemini API, CLI, Code Assist) | Full | Managed MCP servers for BigQuery, Maps, GCE. Tools-only (no resources/prompts yet) |
| **Microsoft** (Copilot, Windows, VS Code) | Full | MCP foundational to Windows 11 "agentic OS" architecture |
| **AWS** (Bedrock, Kiro, Strands) | Full | Contributing to spec (authorization, human-in-the-loop) |

All major AI coding tools support MCP clients: **Cursor** (tools + resources since v1.6), **Windsurf** (built-in MCP Plugin Store), **VS Code + GitHub Copilot** (GA since July 2025), **Cline** (autonomous coding with MCP), **Zed** (early adopter, native support), **Continue.dev** (open-source, VS Code + JetBrains), and **Gemini CLI**. JetBrains native support remains the notable absence, though GitHub Copilot MCP works in JetBrains via preview.

MCP is model-agnostic by design — any LLM with tool/function calling can work with MCP servers through an MCP client. The protocol's donation to the Agentic AI Foundation under the Linux Foundation in December 2025 cemented its vendor-neutral status. Complementary protocols include Google's A2A (agent-to-agent communication) and IBM's ACP (multi-agent memory and long-running tasks), but neither competes directly with MCP's tool integration role. With **97 million monthly SDK downloads** and over 10,000 active servers, MCP has effectively won the AI-tool integration standard.

## Conclusion

The MCP ecosystem has matured rapidly from Anthropic's November 2024 launch to universal industry adoption. For Go developers, the choice between the official SDK and `mark3labs/mcp-go` comes down to preference — the official SDK offers generics-based typing and Google backing, while mcp-go has broader community adoption and richer transport support. The protocol's real performance concern isn't transport latency (sub-10ms) but token inflation from tool schemas — architectural patterns like code execution and Tool Search provide 95–99% reductions. Security remains an implementation responsibility rather than a protocol guarantee, making input validation, sandboxing, and human-in-the-loop approval essential. For custom AI coding harnesses, MCP provides strongest value when tools need to be reusable, vendor-neutral, and ecosystem-compatible — the overhead is justified when building for production scale rather than quick prototypes.