# Production search infrastructure: a complete architecture guide

**The most consequential decision in search infrastructure is knowing when to leave PostgreSQL.** For datasets under one million records with basic keyword needs, Postgres full-text search eliminates an entire class of operational complexity — no sync pipelines, no separate clusters, no consistency lag. Beyond that threshold, or when users expect typo tolerance, faceted navigation, and sub-50ms responses, a dedicated search engine becomes necessary. The modern production stack increasingly converges on hybrid search (BM25 + vectors), CDC-driven index sync, and tiered observability — patterns this guide covers across ten critical dimensions.

---

## 1. Choosing the right search engine for your scale

The search engine decision hinges on five factors: dataset size, feature requirements, operational capacity, latency expectations, and budget. Each option occupies a distinct niche.

**PostgreSQL full-text search** uses `tsvector`/`tsquery` with GIN indexes to deliver keyword search with zero additional infrastructure. Its `ts_rank` function scores by term frequency only — it lacks BM25's inverse document frequency component, meaning it cannot weight rare terms higher. Performance degrades as datasets grow: a 50ms query on 10K rows becomes multi-second on 10M rows. Postgres FTS works well when search is a secondary feature, your dataset is under **~1M records**, and you need basic boolean queries. The `pg_trgm` extension adds fuzzy matching, and ParadeDB's `pg_search` extension brings BM25 scoring via Tantivy, extending Postgres viability into the low millions.

**Elasticsearch/OpenSearch** is the production workhorse for complex search at scale. Built on Lucene with native BM25 ranking, distributed sharding, and sophisticated aggregations, it handles billions of documents across petabytes of data. The cost is operational complexity: JVM heap tuning (set to 50% of RAM, capped at **31GB** for compressed OOPs), shard management (target **10–50GB per shard**), and minimum three-node clusters for high availability. Multiple enterprises report Elasticsearch becoming their largest software expense as clusters grow — production costs range from $1,500/month for small teams to $100,000+/month at enterprise scale.

**Typesense** (C++, in-memory) offers Elasticsearch-caliber instant search with dramatically simpler operations. Its Raft-based clustering provides genuine HA without distributed systems expertise. Benchmarks show **11ms average search time** on 2.2M documents and **28ms on 28M documents**. The key differentiator: query-time configuration — sort fields, search fields, and facets are all defined at search time from a single index, unlike Algolia and Meilisearch which require duplicate indexes per sort order. Best for datasets fitting in RAM on a single node (up to hundreds of millions of documents).

**Meilisearch** (Rust, single binary) prioritizes developer experience with zero-config typo tolerance and sub-50ms responses. The limitation is its single-node Community Edition — no multi-node clustering for HA without the Enterprise license. Heavy RAM usage during indexing and a practical ceiling of low millions of documents make it ideal for documentation sites, CMS search, and MVPs.

**Algolia** delivers the fastest time-to-market with built-in analytics, A/B testing, and personalization. Pricing scales linearly with usage: a mid-size ecommerce site (50K products, 100K monthly searches) costs **$500–$1,500/month**. The 10KB max record size and 128GB max index size impose hard ceilings. Choose Algolia when your team lacks search engineering expertise and budget allows per-search pricing.

| Criterion | PostgreSQL FTS | Elasticsearch | Typesense | Meilisearch | Algolia |
|---|---|---|---|---|---|
| Dataset ceiling | ~1–5M records | Billions | Hundreds of millions | Low millions | 128GB index |
| Setup time | Minutes | Days–weeks | Hours | Hours | Hours |
| Data sync needed | No | Yes | Yes | Yes | Yes |
| Operational staff | No | Yes | No | No | No |
| BM25 ranking | No (TF only) | Yes | Yes | Yes | Yes |
| HA support | Via Postgres replication | Native clustering | Raft consensus | Enterprise only | Managed |

---

## 2. Keeping search indexes synchronized with your database

The fundamental principle: **search indexes are derived data**. Your primary database remains the source of truth. Accept eventual consistency for search and design accordingly.

**The canonical CDC pipeline** uses Debezium reading your database's transaction log (WAL for Postgres, binlog for MySQL), publishing events to Kafka topics, then sinking into Elasticsearch via Kafka Connect. This achieves **50–200ms propagation latency** from database commit to searchable document. The `ExtractNewRecordState` SMT unwraps Debezium's envelope format into clean documents suitable for direct indexing. Configure `behavior.on.null.values: delete` on the sink connector to handle DELETE events properly.

**The outbox pattern** solves the dual-write problem by writing both data and an outbox event in a single database transaction. A relay process (polling or CDC-based) publishes unsent events to Kafka. Shopify uses polling with a one-second interval for simplicity. CDC-based relay offers lower latency for high-throughput systems but adds operational complexity. Start with polling unless you need sub-second propagation at thousands of events per second.

```sql
CREATE TABLE outbox (
  id UUID PRIMARY KEY,
  aggregate_type VARCHAR(255),
  aggregate_id VARCHAR(255),
  event_type VARCHAR(255),
  payload JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  processed_at TIMESTAMP NULL
);
```

**Hybrid indexing** is the production-proven approach: use real-time CDC for critical fields (inventory, pricing, availability) and batch reindexing for stable fields (descriptions, category metadata). During batch loads, increase `refresh_interval` to 30s or disable it entirely (`-1`), then reset to 1s afterward — this dramatically improves throughput. For read-your-writes scenarios, use `refresh=wait_for` on critical writes rather than forcing global refreshes.

**Index schema design** defaults to denormalization. Elasticsearch has no JOINs — store related data together in flat documents. Use `keyword` type for filtering and aggregations, `text` type only for full-text search fields. Map numeric IDs as `keyword` unless range queries are needed. Set `dynamic: "strict"` in production mappings to prevent mapping explosions from unexpected fields. Use the `nested` type only when you need independent querying of array objects (each nested object creates a separate hidden Lucene document, making queries up to **20x slower** than flat structures).

---

## 3. Tuning relevance beyond BM25 defaults

BM25's default parameters (**k1=1.2, b=0.75**) work well for most corpora, and Elastic's own guidance is that tuning these should not be your first step. Research by Trotman et al. found no clear evidence that parameter tuning systematically improves results. Instead, invest in this priority order: synonym expansion, analyzer configuration, field boosting, then BM25 parameter tuning.

**Field boosting** is the highest-leverage relevance lever. A match in the title carries more signal than one buried in a description:

```json
{
  "multi_match": {
    "query": "wireless headphones",
    "fields": ["title^3", "tags^2", "description"]
  }
}
```

Common boost ratios: **title 3–10x**, tags/categories 2–5x, summary 1.5–2x, body 1x. These are effectively regression coefficients — you can log per-field BM25 scores, use click data as labels, and solve a regression problem to find optimal weights.

**Function score queries** combine text relevance with business signals. The critical insight: use `boost_mode: "multiply"` so business signals scale proportionally with text relevance, rather than additive mode which can override relevance entirely. A production ecommerce pattern combines featured-product boosts, popularity via `field_value_factor` with `log1p` modifier (dampens runaway scores from extremely popular items), and recency via Gaussian decay functions.

**Search analytics** drives continuous improvement. Track zero-result rate (target **under 5%**), click-through rate (target **over 30–40%**), mean click position (target **under 3.0**), and search exit rate (target **under 25%**). One retailer discovered 8% of "linen" searches returned zero results despite 50+ matching products tagged as "flax" — synonym mapping reduced zero results by 80%. For A/B testing search changes, **interleaving** (blending control and treatment results in a single list) requires only ~6% of traditional A/B test traffic and achieves up to 50x faster statistical significance, as demonstrated by Airbnb's search team.

**Learning to Rank** becomes worthwhile when manual tuning plateaus and you have sufficient training data. Deploy LTR as a second-stage re-ranker: BM25 retrieves the top 100 candidates quickly, then an XGBoost/LambdaMART model re-ranks using features like per-field BM25 scores, click-through rates, document age, and business signals. Elasticsearch 8.13+ integrates LTR natively via the `rescore` API. XGBoost's `lambdarank_unbiased` parameter helps debias click-based training data affected by position bias.

---

## 4. Building autocomplete that feels instant

Three implementation approaches exist, each with distinct tradeoffs. **Edge n-grams** tokenize text into prefix subsequences at index time ("database" → ["da", "dat", "data", "datab", …]), enabling fast inverted-index lookups that support matching words in any order. Configure with `min_gram: 2` and `max_gram: 10`. The critical rule: **use different analyzers for index and search time** — apply edge n-grams only at index time, and use a simple `lowercase` analyzer at search time to prevent over-matching.

The **completion suggester** uses an in-memory Finite State Transducer for sub-millisecond prefix lookups. It supports weighted suggestions and fuzzy matching but is limited to prefix-only matching and consumes significant memory. Best for bounded suggestion sets like product names or movie titles. Elasticsearch's `search_as_you_type` field type automates edge n-gram + shingle configuration without custom analyzer setup, offering a convenient middle ground.

**Debounce at 200–300ms** on the frontend. Without debouncing, typing "headphones" fires 10 API calls; with 300ms debounce, it fires 1–2. Combine with `AbortController` to cancel in-flight requests when new input arrives, and an LRU cache for previous prefix responses (helps with backspace/corrections). Don't fire searches for single-character inputs — they're too broad and expensive. REST is preferred over WebSocket for autocomplete since it's stateless, HTTP-cacheable, and CDN-compatible.

**Popular query suggestions** should be rebuilt from analytics logs every 24 hours. Filter out zero-result queries, apply minimum frequency thresholds, deduplicate case/plural variations, and always maintain a banned-expressions list. A French retailer (Castorama) learned this the hard way: allowing any repeated query to become a suggestion resulted in inappropriate content flooding their autocomplete, forcing them to shut down their website for weeks.

---

## 5. Faceted navigation that works for users and search engines

The core technical challenge in faceted search is computing accurate facet counts when filters are active. When a user selects "Brand: Apple," naive aggregations only show counts for Apple — all other brands show zero. The solution is the **n+1 pattern**: each facet aggregation applies all active filters except its own, using `global` aggregations with nested filter aggregations. This produces correct counts but query complexity grows with active filters.

For variable product attributes (brand, color, size), use a **nested field mapping** with `facet_name`/`facet_value` pairs. This avoids changing the index mapping when new attributes are added. Standard UX uses **disjunction (OR) within** facet groups (Red OR Blue shows both) and **conjunction (AND) across** groups (Red AND Nike shows only red Nike products).

**SEO for faceted pages** demands a tiered strategy. Tier 1: high-value filter combinations with genuine search demand (e.g., "Nike running shoes men") get clean URLs, unique titles, self-canonicals, and sitemap inclusion. Tier 2: moderate combinations get `noindex, follow` plus canonical tags pointing to the parent category. Tier 3: low-value combinations (sort orders, multi-select within same facet, 3+ simultaneous filters) are blocked entirely via `robots.txt` or rendered as AJAX/fragment URLs. Google's updated guidance (December 2025) recommends URL fragments (`#color=red`) as the cleanest crawl-budget solution since Googlebot ignores everything after `#`. Never include filter combination URLs in XML sitemaps, and return HTTP 404 for filter combinations with zero results.

---

## 6. Performance engineering for sub-second search

**Shard sizing** is the single most impactful performance decision in Elasticsearch. Target **10–50GB per primary shard**. Below 10GB, you get "shard explosion" — excessive JVM heap pressure and slow cluster state updates. Above 100GB, individual shard operations become too expensive. A healthcare provider reduced query latency by **65%** simply by consolidating from 6 shards to 2 for a 30GB index. Limit total shards to ~20 per GB of heap memory.

**Elasticsearch's three cache layers** work together: the node query cache (10% of heap) caches filter-context results as bitsets, the shard request cache (1–2% of heap) caches aggregation responses, and field data cache loads values for sorting. The highest-leverage optimization: use `filter` context instead of `query` context for non-scoring clauses — filter results are cacheable and skip score computation, yielding **2–5x speedups**.

**Latency budgets** should be defined as SLOs: p50 under 100ms, p95 under 500ms, p99 under 1 second. Enable Elasticsearch slow logs to catch problematic queries (`index.search.slowlog.threshold.query.warn: 500ms`). Common p99 spike causes include JVM GC pauses, segment merging during heavy indexing, cold filesystem cache, and deep pagination. Replace `from/size` pagination with `search_after` beyond page 100.

For scaling, Holidu's production system runs **30–100+ nodes** with custom autoscaling that adjusts replica shard counts based on CPU metrics. The pattern: keep primary shard count semi-static and scale read capacity by adding/removing replica shards. JVM heap should be set to 50% of system RAM (maximum 31GB), with the remaining RAM serving as OS filesystem cache for Lucene — this split is critical and non-negotiable.

---

## 7. When and how to add vector and semantic search

**Hybrid search combining BM25 + vectors is now the production standard**, delivering **20–30% better relevance** than either approach alone. Vector search fails on acronyms, product codes, SKUs, and exact technical terms; keyword search fails on synonyms, semantic intent, and paraphrasing. Combining them covers both failure modes.

**Reciprocal Rank Fusion (RRF)** is the preferred fusion method: `RRF(d) = Σ 1/(k + rank)` where k is typically 60. It ignores raw scores entirely (which are incomparable across retrievers) and focuses on rank positions. Elasticsearch 8.12+ supports RRF natively via the `rrf` retriever API. For PostgreSQL, combine `pgvector` cosine similarity with `tsvector` BM25 scoring using application-level rank fusion.

**pgvector** works well for under **5–10 million vectors** when you want a unified stack. Use HNSW indexes (not IVFFlat — HNSW handles data drift without rebuilding). Beyond 10M vectors, consider dedicated vector databases: **Pinecone** for zero-ops managed search, **Qdrant** for self-hosted with RBAC and multitenancy, **Weaviate** for flexible hybrid queries. One startup cut costs by 60% migrating latency-insensitive workloads from Pinecone to pgvector while keeping Pinecone for real-time search.

For embedding models, **768 dimensions handles most tasks**. OpenAI's text-embedding-3-large supports Matryoshka representation learning — generate at 3072 dimensions but truncate to 512 or 768 with 97–99% accuracy retention. For multilingual needs, Cohere's embed-v4 outperforms OpenAI by 15–20% on non-Latin scripts. Domain-specific fine-tuning yields **+10–30% improvement** — a pharmaceutical team saw 67% improvement using PubMedBERT over general-purpose models.

**Cross-encoder re-ranking** adds a precision layer: retrieve top 50 candidates with BM25/vector search, then re-rank with a cross-encoder that scores each query-document pair jointly. The `cross-encoder/ms-marco-MiniLM-L-6-v2` model processes 100 pairs in ~740ms, making it viable for production with small reranking windows. Keep the window at 20–50 documents for acceptable latency.

---

## 8. Securing search results and protecting user privacy

**Document-level security (DLS)** ensures users only see results they're authorized to access. The pattern: embed access control metadata in every indexed document (an `_allow_access_control` array of group IDs, user emails, or role names), then create Elasticsearch roles with DLS query filters that match against these fields. DLS queries execute as additional filters on every search request — keep them simple (`term`/`terms` queries) to minimize performance impact. Multiple roles combine with OR logic.

**PII must be scrubbed at ingestion time**, before it enters the search index. Replace personal identifiers with anonymous placeholders ("My name is Sarah Chen" → "My name is [NAME_1]") and store entity mappings separately for authorized reconstruction. Use regex-based pattern matching in ingest pipelines for emails, SSNs, and credit card numbers. Never place raw PII in search query logs.

For **GDPR/CCPA compliance**, anonymize query logs by hashing or removing user identifiers. Set retention policies — aggregate after 30 days, delete raw logs after 90. Under GDPR, search query logs containing PII constitute data transfer to a third-party processor if using external search services, requiring Data Processing Agreements. Implement consent management and only track search analytics when the user opts in, especially in EU jurisdictions.

Secure search APIs with OAuth 2.0/JWT authentication, RBAC for endpoint access, and rate limiting by user/token (not just IP). Use parameterized queries exclusively — never concatenate user input into search queries. Place search APIs behind an API gateway with WAF capability and enforce TLS 1.2+ everywhere.

---

## 9. Making multi-language search work in production

The index architecture decision depends on language count. For **2–3 languages**, use multi-field mappings where each language gets a sub-field with its own analyzer (`title.en`, `title.fr`, `title.de`) in a single index — simple but costly since every document is analyzed N times. For **4+ languages**, use a single index with an ingest pipeline that routes content to the correct language field based on metadata. For **large-scale systems** with clearly separated language content, index-per-language (`products_en`, `products_fr`) gives clean separation.

**Language-specific analyzers** are essential — the standard analyzer produces poor results for non-English text. Elasticsearch ships analyzers for 36+ languages, each configuring appropriate stemming, stop words, and tokenization. Use **light stemmers** (`light_french`, `light_german`) for human-facing search — they stem less aggressively than standard stemmers, producing fewer false matches. Porter2 (Snowball English) is recommended over original Porter; Martin Porter himself called Porter "significantly worse."

**CJK languages** present a fundamental challenge: no word boundaries. The default CJK bigram tokenizer produces many false positives — "Tokyo" (東京) matches "Kyoto" (京都) since they share a character. Production systems require dictionary-based tokenizers: **kuromoji** for Japanese, **nori** for Korean, **smartcn** for Chinese. These need user dictionaries for domain-specific terms and CJK width normalization to fold full-width ASCII variants to standard Latin.

For **transliteration**, the ICU analysis plugin's `icu_transform` filter converts any script to Latin (`你好` → "ni hao", `здравствуйте` → "zdravstvujte"). Index a transliterated sub-field alongside the original to let users search in Latin characters and match non-Latin content. Modern **multilingual embedding models** (like `multilingual-e5-base`) enable true cross-language search by encoding meaning into a shared vector space, where a German query can find English documents through vector similarity.

---

## 10. Observability that drives search quality improvements

Effective search observability tracks four metric categories: latency, relevance, engagement, and conversion. Without these, you're optimizing blind.

**Latency monitoring** should capture p50, p95, and p99 — not averages, which hide tail latencies that disproportionately impact user experience. Alert on p99 exceeding 1 second sustained over 5 minutes. Separately instrument embedding generation time (100–500ms for cold GPU starts), search engine query time, and post-processing/reranking time. Elasticsearch's slow query log identifies problematic queries for targeted optimization.

**Zero-result rate** is the most actionable relevance metric. Target under 5%. Segment zero-result queries by frequency — high-volume zero results represent the biggest opportunity. Build weekly reports showing top zero-result queries, categorize as vocabulary mismatches (product exists but is tagged differently) versus genuine catalog gaps, and feed findings into synonym dictionaries and content tagging. Leading ecommerce teams treat zero-result reduction as a KPI alongside cart abandonment.

**Click-through rate** requires instrumenting both search events and click events with a shared `search_id`. Log the query, returned results, clicked document ID, and click position. Key metrics: overall CTR (target >30%), no-click rate, click position distribution (are users clicking result #1 or scrolling to #5+?), and per-query CTR for identifying specific queries needing relevance work. Search users typically convert **2–3x higher** than non-search users, making search quality directly revenue-impactful.

Build a **search funnel dashboard** tracking the progression from search → results shown → result clicked → page viewed → conversion. Connect events via session ID and search ID, calculate step conversion rates, and segment by device, query type, and user cohort. Teams implementing systematic funnel tracking see **20–35% conversion improvements within 90 days**. Use GA4 Funnel Exploration for quick setup, or build a custom pipeline with event streaming into a data warehouse for deeper analysis.

---

## Conclusion

The search infrastructure landscape in 2026 has settled into clear patterns. **Start with PostgreSQL FTS** for simple use cases and graduate to a dedicated engine when you need typo tolerance, facets, or sub-50ms responses at scale. **Typesense** has emerged as the pragmatic middle ground between Postgres simplicity and Elasticsearch power. **Hybrid BM25 + vector search** is no longer experimental — it's the production default, delivering measurable relevance gains. The highest-leverage investments are not in engine selection but in the surrounding infrastructure: CDC pipelines for reliable sync, search analytics for continuous relevance improvement, and proper observability to make search quality visible. The most impactful single metric to track is zero-result rate — it directly reveals where your search fails users and where synonyms, better tagging, or content additions will have immediate effect.