# Automating compliance detection from code signals to technical controls

**No existing tool automatically detects which compliance frameworks apply to a software project by analyzing its codebase** — this is the single biggest gap in the compliance tooling market and the core opportunity for Stoke's compliance wizard. Current platforms like Vanta, Drata, and Secureframe assume you already know your frameworks; they enforce compliance but don't discover it. A system that scans package dependencies, database schemas, environment variables, infrastructure configs, and locale files to recommend applicable frameworks would be genuinely novel. For a Victoria, BC-based company building SaaS products across pet affiliate platforms, AI governance tools, and content management systems, the framework matrix could include **PIPEDA/BC PIPA, CASL, GDPR, PCI DSS, SOC 2, and potentially COPPA** — depending entirely on signals detectable from each project's code and configuration.

This report covers all ten research areas in depth, organized around a practical implementation architecture: first the detection logic, then framework-specific rules, then the tooling ecosystem, and finally the machine-readable control mapping system that ties everything together.

---

## Dependency scanning reveals framework applicability with high confidence

The foundation of automated compliance detection is **mapping project signals to regulatory triggers**. These signals fall into five analyzable categories, each scannable from a project's repository without runtime data.

**Package dependencies** provide the highest-confidence signals. Scanning manifest files (`package.json`, `Gemfile`, `requirements.txt`, `go.mod`, `pom.xml`, `composer.json`, `Cargo.toml`) for specific SDKs creates direct regulatory links. The presence of `stripe`, `braintree`, or `@adyen/api-library` triggers PCI DSS evaluation. FHIR client libraries (`hapi-fhir`, `fhirclient`), HL7 parsers (`python-hl7`), or DICOM libraries (`pydicom`) trigger HIPAA. Email-sending SDKs (`sendgrid`, `mailgun`, `nodemailer`) combined with Canadian targeting trigger CASL assessment. Educational platform integrations (`canvasapi`, LTI libraries) trigger FERPA. Financial APIs (`plaid`, `alpaca-trade-api`) trigger SOX/GLBA evaluation.

**Data model and schema analysis** provides the second-highest signal confidence. Database migration files, ORM definitions (Prisma schemas, Django models, Sequelize), and API schemas (OpenAPI/GraphQL) can be scanned for field-name patterns. Fields like `patient`, `diagnosis`, `icd_code`, or `medical_record` indicate healthcare data and HIPAA applicability. Fields like `credit_card`, `card_number`, or `cvv` indicate direct cardholder data handling and PCI DSS scope. Fields like `student_id`, `transcript`, `enrollment`, or `gpa` indicate education records and FERPA. Fields like `express_consent`, `implied_consent`, and `unsubscribe` suggest CASL-aware email systems.

**Configuration and environment variables** reveal service integrations. Scanning `.env` and `.env.example` files for patterns like `STRIPE_SECRET_KEY`, `EPIC_CLIENT_ID`, `PLAID_CLIENT_ID`, `FHIR_SERVER_URL`, or `CANVAS_API_TOKEN` maps directly to regulatory domains. Infrastructure configuration files (Terraform `.tf`, CloudFormation templates, Kubernetes manifests) reveal deployment regions — `eu-west-1` or `eu-central-1` deployments combined with other EU-targeting signals trigger GDPR assessment.

**User geography indicators** include locale directories (`i18n/`), translation files for EU languages, GeoIP library usage, currency handling code (EUR support), and timezone configurations. For a Canadian company, French language support alone does not trigger GDPR — it's native to Quebec. But French combined with German, EUR pricing, and `.eu` domain registration creates strong cumulative evidence of EU targeting.

**Domain and DNS configuration** provides additional context: country-code TLDs (`.eu`, `.de`, `.health`, `.edu`), SSL certificate configurations, and CDN deployment patterns all contribute to the framework detection scoring model.

---

## PIPEDA vs BC PIPA: a decision tree for Victoria-based companies

For Stoke's home base in Victoria, BC, the jurisdictional question centers on whether **BC PIPA or federal PIPEDA** governs each project. BC PIPA is one of three provincial private-sector privacy laws (alongside Alberta PIPA and Quebec's Law 25) deemed "substantially similar" to PIPEDA by federal order-in-council.

The decision logic is straightforward and fully automatable. First, check if the organization is a **federal work, undertaking, or business** (FWUB) — banks, telecoms, ISPs, airlines, railways, broadcasters always fall under PIPEDA regardless of province. Second, check if personal information **crosses provincial or international borders** — any cross-border data transfer triggers PIPEDA even in BC. Third, if neither condition applies and the organization operates within BC, **BC PIPA governs**. Fourth, verify the activity is commercial in nature — PIPEDA defines "commercial activity" as any transaction, act, or conduct of a commercial character, including selling, bartering, or leasing products, goods, or services.

For a SaaS company in Victoria serving customers across Canada and internationally, **PIPEDA will almost certainly apply** because customer data crosses provincial and international borders. BC PIPA may apply concurrently for employee information and purely intra-provincial activities.

**Bill C-27 is dead.** Parliament prorogued in January 2025, killing the Digital Charter Implementation Act. A snap federal election followed in April 2025, and by June 2025 the government confirmed C-27 would not return in its original form. PIPEDA remains the operative federal law. New privacy legislation is expected in 2026, likely featuring penalties up to **5% of global revenue or C$25 million**, stronger individual rights, and children's privacy protections. In the interim, organizations are treating Quebec's Law 25 and GDPR as practical compliance baselines.

PIPEDA's cross-border data transfer model differs fundamentally from GDPR's. PIPEDA **does not prohibit** transfers to any country and uses no adequacy determination system. Instead, it employs an "organization-to-organization" accountability model: the transferring organization remains accountable for data in the processor's hands and must use contractual means to ensure a comparable level of protection. Organizations must disclose in their privacy policy that data may be transferred to foreign jurisdictions and may be accessible to foreign authorities. Quebec's Law 25 adds stricter requirements, including mandatory privacy impact assessments before any transfer outside Quebec.

Key technical requirements under PIPEDA include express consent for sensitive information, implied consent for routine operations, breach notification for incidents creating a **"real risk of significant harm"** reported "as soon as feasible" to the OPC and affected individuals, and mandatory breach record-keeping for **24 months** covering all breaches regardless of severity threshold.

---

## CASL turns email infrastructure into a compliance trigger

Canada's Anti-Spam Legislation applies the moment a software project sends **commercial electronic messages (CEMs)** — and the definition is broader than most developers expect. A CEM is any electronic message where, considering its content, hyperlinks, and contact information, it would be reasonable to conclude that one purpose is encouraging participation in commercial activity. Critically, **a request for consent is itself a CEM** — you cannot email someone asking for permission unless you already have consent or qualify for an exemption.

The automated detection logic for CASL starts with identifying email/messaging infrastructure in the codebase. High-confidence triggers include email-sending services (SendGrid, Postmark, Mailgun, Amazon SES, SparkPost), marketing automation tools (Mailchimp, HubSpot, Klaviyo, ActiveCampaign, Constant Contact), SMS services (Twilio, Vonage, Plivo), and push notification frameworks (Firebase Cloud Messaging, Apple Push Notification Service, OneSignal). The presence of any of these combined with Canadian user targeting should flag CASL assessment.

The transactional vs. commercial distinction is the critical classification problem. Under CASL, if **any purpose** of a message is to encourage commercial activity, the entire message becomes a CEM — this is stricter than US CAN-SPAM, which permits secondary commercial content in transactional messages. An order confirmation with a "You might also like..." product recommendation section could be reclassified as a CEM. Detection heuristics should flag messages triggered by user actions (purchases, password resets, account changes) as likely transactional, while messages containing promotional offers, product recommendations, newsletter content, abandoned cart nudges, or re-engagement campaigns are almost certainly CEMs requiring full CASL compliance.

CASL consent operates on two tiers. **Express consent** requires a positive opt-in action (pre-checked boxes are prohibited), must include a clear purpose description, sender identification with mailing address, and a statement that consent can be withdrawn at any time. Express consent has no expiry. **Implied consent** exists only in narrow scenarios: an existing business relationship grants **2 years** from the last transaction, an inquiry grants **6 months**, and conspicuously published business email addresses allow relevant contact without fixed expiry.

Organizations must maintain timestamped consent records for **3 years after the relationship ends** and process unsubscribe requests within **10 business days**. Unsubscribe mechanisms must remain functional for at least **60 days** after message delivery. Penalties reach **$10 million per violation for organizations** and $1 million for individuals. The Federal Court of Appeal unanimously upheld CASL as constitutional in 2020, and the Supreme Court declined leave to appeal.

---

## PCI DSS scope depends on how payment integration is architected

PCI DSS applies to any entity that stores, processes, or transmits cardholder data or sensitive authentication data. For SaaS applications, the critical question is not whether payment processing exists but **how it's implemented** — this determines whether the project faces 22 requirements (SAQ A) or 300+ (SAQ D).

Automated scope detection follows a two-phase approach. Phase one scans dependency manifests for payment SDK packages — `stripe`, `@stripe/stripe-js`, `braintree`, `adyen-web`, `square`, `@paypal/checkout-server-sdk` across all package ecosystems. Phase two classifies the integration type by analyzing how the SDK is used in code. If the code imports `@stripe/stripe-js` and uses `Elements` or `CardElement` components, card data never touches merchant servers — this is **SAQ A eligible** with roughly 22 requirements. If code passes tokenized payment methods (`pm_xxx`, `tok_xxx`) to Stripe's server-side API, that's also SAQ A. But if code passes raw card numbers (e.g., `card[number]`) to any payment API, that's **SAQ D** with the full 300+ requirement set.

The scope reduction hierarchy is consistent across providers. Stripe Checkout (full redirect), Braintree Hosted Fields and Drop-in UI, Adyen Drop-in Components, and Square Web Payments SDK all achieve SAQ A eligibility by keeping card data entirely within the provider's PCI-compliant infrastructure. Direct POST scripts on the merchant's payment page push the assessment to SAQ A-EP (~191 requirements), because the merchant's website could affect payment page security even though card data doesn't touch merchant servers.

**PCI DSS v4.0.1 is now the sole active standard**, with all 64 new requirements mandatory since March 31, 2025. The most impactful changes for SaaS projects include MFA mandatory for all CDE access (not just administrators), minimum password length increased from 7 to **12 characters**, web application firewalls now mandatory (manual review option removed), payment page script management and integrity monitoring (Requirements 6.4.3 and 11.6.1), anti-phishing controls (DMARC, SPF, DKIM), and automated log review mechanisms. Code repositories are now **explicitly in PCI scope** per the Requirement 6 overview, meaning source code management practices must meet PCI standards.

---

## SOC 2 readiness can be assessed through infrastructure and code signals

SOC 2 Type II is the market standard for B2B SaaS companies, requiring demonstration that security controls work consistently over a 3–12 month observation period. The Security criteria (CC1–CC9) are mandatory for all SOC 2 audits; Availability, Processing Integrity, Confidentiality, and Privacy are optional. Most B2B SaaS companies select **Security plus Availability**, adding Confidentiality if handling sensitive client data.

An automated gap analysis system can detect existing controls across five layers. For **CI/CD audit trails** (mapping to CC8 Change Management), scan for `.github/workflows/` directories, branch protection rules requiring PR reviews, deployment approval stages, and separation of dev/staging/prod environments. For **access logging** (CC6, CC7), verify CloudTrail enabled in AWS, audit log configurations in Azure/GCP, centralized logging via SIEM integrations (Splunk, DataDog, ELK Stack), and structured application logging libraries. For **encryption** (CC6.1, CC6.7), check for KMS key configurations in Terraform, RDS/S3 encryption settings, TLS certificate configurations, HSTS headers, and secrets management integrations (HashiCorp Vault, AWS Secrets Manager). For **vulnerability scanning** (CC7.1), detect `.snyk` files, `.github/dependabot.yml`, OWASP ZAP or Trivy steps in CI pipelines, and CodeQL workflow configurations. For **incident response** (CC7.3–CC7.5), look for PagerDuty/OpsGenie integrations, post-mortem templates, runbook documents, and incident response plan files.

**AWS Config conformance packs** provide pre-built SOC 2 control checks for infrastructure — the `Operational-Best-Practices-For-SOC-2` pack contains dozens of managed rules mapped directly to SOC 2 criteria. Steampipe/Powerpipe can run SOC 2 compliance benchmarks against cloud accounts. Open Policy Agent policies can enforce SOC 2 requirements as CI/CD pipeline gates.

First-year SOC 2 costs for a small startup range from **$25,000 to $50,000** total (audit fees $10K–$25K, compliance platform $5K–$12K/year, penetration test $15K–$20K). Compliance automation platforms reduce this timeline by approximately 50% and can get a startup audit-ready in **3–4 months** with strong existing security posture.

---

## GDPR catches Canadian companies through targeting and monitoring tests

GDPR's extraterritorial reach under Article 3(2) applies to a Canadian company through two independent tests. The **targeting test** (Article 3(2)(a)) asks whether the company offers goods or services to EU data subjects. The **monitoring test** (Article 3(2)(b)) asks whether the company monitors behavior of individuals in the EU.

For targeting, the EDPB's Guidelines 3/2018 are explicit about what doesn't suffice alone: mere website accessibility from the EU, available contact details, or use of the controller's own native language. For a Victoria-based company, French language support targets Quebec, not France, and **does not independently trigger GDPR**. However, factors analyzed "jointly in an analysis in concreto" create cumulative evidence. Strong indicators include EU language support beyond the controller's native language (German, Italian, Dutch, Polish), EUR currency display or acceptance, EU country-code TLDs, EU shipping destinations, and EU-targeted advertising campaigns. An automated system should assign confidence scores to each signal and trigger GDPR assessment when cumulative evidence exceeds a threshold.

For monitoring, setting analytics or marketing cookies for EU visitors, behavioral advertising targeting EU users, cross-device tracking, geolocation collection, and any profiling of EU individuals all constitute monitoring. The EDPB takes a broad view — tracking through any technology involving personal data can qualify.

**Canada holds GDPR adequacy status**, confirmed in the European Commission's January 2024 review — but only for commercial organizations subject to PIPEDA. This means EU-to-Canada data transfers are permitted freely without Standard Contractual Clauses for PIPEDA-covered activities. However, adequacy does not cover provincial government bodies, employee data outside PIPEDA scope, or onward transfers from Canada to non-adequate countries like the US.

When GDPR applies, technical measures include consent management platforms blocking non-essential cookies before consent, DSAR handling within **1 month** (extendable by 2 months), right-to-erasure implementation across all systems including backups and third-party processors, data portability in machine-readable formats (CSV, JSON, XML), DPIAs for high-risk processing, records of processing activities, breach notification within **72 hours**, and appointment of an EU representative under Article 27. Penalties reach **€20 million or 4% of global annual turnover**.

---

## Children's data triggers cascade across three jurisdictions

Detecting whether an application processes children's data requires analyzing content signals, age verification mechanisms, and platform metadata across COPPA (US), the UK Age Appropriate Design Code, and Canadian OPC guidance — each with different age thresholds and trigger mechanisms.

**COPPA's 2025 Final Rule amendments** (effective June 23, 2025, compliance deadline April 22, 2026) expanded the "directed to children" test with three new factors: marketing materials targeting children, third-party reviews indicating a child audience, and ages of users on comparable services. The rule expanded "personal information" to include **biometric identifiers** (fingerprints, facial patterns, voiceprints, gait patterns) and government-issued identifiers. A mandatory written information security program is now required, with designated coordinator, annual risk assessments, and safeguard testing. Separate parental consent is required for third-party disclosures and targeted advertising — these cannot be bundled with general consent. Civil penalties reach **$53,088 per violation**.

Detection signals for children's content span multiple categories. Content analysis can flag educational topics (math, reading, phonics for K-12), games with child-oriented mechanics (dress-up, coloring, sticker rewards), and simple language (Flesch-Kincaid below grade 6). Technical signals include age gate implementations (date-of-birth fields, "Are you over 13?" prompts), parental consent flows (parent email verification, credit card micro-charges), COPPA Safe Harbor seals (kidSAFE, PRIVO, CARU, ESRB), and app store metadata (Apple's "Made for Kids" flag, Google Play's "Designed for Families" program). Dependencies like PRIVO SDK, SuperAwesome/Kids Web Services, Google Classroom API, or Clever SDK indicate child-oriented functionality.

The **UK Age Appropriate Design Code** operates on a much broader trigger than COPPA: it applies to all information society services "likely to be accessed by children" under **18** — not just those directed at children. This means virtually any consumer-facing service must assess whether children might use it. The code requires highest privacy settings by default, profiling and geolocation off by default, and prohibits nudge techniques encouraging children to weaken privacy protections.

**Canadian children's privacy** under PIPEDA follows OPC guidance rather than statute: children under 13 generally require parental consent, ages 13 to provincial age of majority require adapted consent processes, and children's information is treated as particularly sensitive. The OPC's ongoing exploratory consultation on a Children's Privacy Code is examining privacy-protective defaults, geolocation restrictions, and deceptive design pattern prohibitions.

---

## Industry detection combines domain analysis with dependency fingerprinting

Industry-specific compliance requirements layer on top of general frameworks, and detection relies on combining multiple signal types into confidence scores.

**Healthcare (HIPAA)** detection triggers on FHIR client libraries, HL7 parsers, DICOM libraries, healthcare API integrations (Epic, Cerner/Oracle Health, athenahealth), and data model keywords including `patient`, `diagnosis`, `prescription`, `icd_code`, `cpt_code`, `npi`, `vital_signs`, and `lab_result`. HIPAA's Technical Safeguards require access control with unique user identification, audit controls recording all ePHI access, integrity mechanisms protecting against improper alteration, and transmission security with encryption. The 18 PHI identifiers — from names and geographic data to IP addresses and biometric identifiers — define what makes health data "protected." Cloud providers offer BAAs through self-service portals: AWS via Artifact (130+ eligible services), Azure through Microsoft Product Terms, and GCP through the Cloud console. **HIPAA breach notification requires individual notification within 60 days** of discovery; breaches affecting 500+ individuals require immediate media notification.

**Financial services** detection triggers on Plaid, Yodlee, Bloomberg API, Alpaca, and Interactive Brokers integrations, plus data model keywords like `account_balance`, `ledger`, `wire_transfer`, `routing_number`, `swift_code`, and `kyc`. SOX IT controls require segregation of duties, change management logging, and audit trails for financial data. The GLBA Safeguards Rule (updated) mandates a written information security program, designated qualified individual, encryption at rest and in transit, MFA for accessing customer information, and continuous monitoring or annual penetration testing. For Canadian financial institutions, **OSFI Guideline B-13** (effective January 2024) covers technology strategy, SDLC, data management, IAM, and incident response across 17 principles, with penalties of **$10,000–$500,000 CAD per violation**.

**Education (FERPA)** detection triggers on LMS integrations (Canvas API, Blackboard, Moodle, Google Classroom), Ed-Fi data standard implementations, LTI libraries, and keywords including `student_id`, `grade`, `enrollment`, `transcript`, `registrar`, and `academic_record`. FERPA applies to all schools receiving US Department of Education funding and requires consent before disclosing PII from education records, with exceptions for school officials, transfers, judicial orders, and emergencies.

---

## Commercial and open-source tools leave framework detection unsolved

The compliance-as-code ecosystem divides into commercial automation platforms and open-source scanning tools, with a clear gap at the framework detection layer.

**Vanta** leads in integration breadth with 375+ connections, running **1,200+ automated tests hourly** against cloud infrastructure. It supports 35+ frameworks including SOC 2, ISO 27001, HIPAA, GDPR, PCI DSS, and FedRAMP. Pricing starts around $10,000/year for a single framework. **Drata** differentiates with a developer-friendly "Compliance-as-Code" feature translating requirements into code-driven workflows, supporting 300+ integrations and automating 80%+ of evidence collection. **Secureframe** offers the lowest entry price (~$5,000–$7,500/year) with AI-powered policy creation and custom integration APIs. **Thoropass** uniquely combines software with in-house CPA firm audit capability, claiming 60% faster audit delivery. **Sprinto** claims 99% automated control checks with entity-based compliance graph mapping across 35+ frameworks.

All commercial platforms follow the same model: you select your frameworks, connect your infrastructure, and they monitor controls and collect evidence. **None of them analyze your project to recommend which frameworks apply.** This is the gap Stoke's compliance wizard would fill.

On the open-source side, **Prowler** provides the most comprehensive framework-to-control mapping across AWS, Azure, GCP, and Kubernetes, with built-in support for CIS, PCI DSS, HIPAA, GDPR, SOC 2, NIST 800-53, and custom frameworks. Running `prowler aws --compliance hipaa_aws` filters to only HIPAA-relevant checks. **Checkov** (by Palo Alto/Bridgecrew) scans IaC templates (Terraform, CloudFormation, Kubernetes, Helm, Dockerfile) for security misconfigurations with graph-based analysis. **Chef InSpec** uses a human-readable Ruby DSL for compliance testing with pre-built CIS and DISA STIG profiles. **Cloud Custodian** (CNCF Incubating) provides a YAML-based policy engine for real-time cloud resource management across 500+ resource types. **Trivy** (which absorbed tfsec) scans containers, IaC, git repos, and secrets detection in a single binary with 1,000+ checks.

**OSCAL (Open Security Controls Assessment Language)** by NIST provides the formal standard for machine-readable compliance documentation. Its layered architecture — Catalog (control definitions), Profile (baseline selections), Component Definition, System Security Plan, Assessment Plan/Results, and POA&M — enables interoperable compliance artifacts across tools. NIST SP 800-53 catalogs and FedRAMP baselines are already available in OSCAL format (XML, JSON, YAML).

**Open Policy Agent (OPA)** with Rego provides the most flexible policy-as-code engine for expressing compliance rules. A CNCF graduated project, OPA evaluates structured JSON/YAML data against declarative policies and integrates with Kubernetes (via Gatekeeper), Terraform (via conftest), Envoy/Istio, and CI/CD pipelines. The **ComplianceAsCode project** (formerly SCAP Security Guide) generates security content in SCAP, Ansible, Bash, and Chef InSpec formats with profiles for PCI DSS, CIS benchmarks, DISA STIGs, and HIPAA.

---

## A unified control matrix eliminates redundant implementation work

The highest-value output of an automated compliance system is mapping framework requirements to shared technical controls, so implementing one control satisfies multiple frameworks simultaneously. The cross-framework matrix reveals significant overlap.

**Encryption at rest (AES-256)** satisfies HIPAA (§164.312(a)(2)(iv) — effectively mandatory per 2026 Security Rule update requiring FIPS 140-2 Level 2+ validation), PCI DSS (Requirement 3.5), GDPR (Article 32(1)(a) as appropriate technical measure), GLBA (updated Safeguards Rule), and is best practice for SOX, FERPA, and OSFI B-13. **Encryption in transit (TLS 1.2+)** is required across HIPAA, PCI DSS, GDPR, and GLBA, with preferred cipher suites being ECDHE-RSA-AES256-GCM-SHA384 and AES-128-GCM-SHA256 for TLS 1.2, and TLS13-AES-256-GCM-SHA384 for TLS 1.3.

**MFA** is now required for all CDE access under PCI DSS v4.0 (Requirement 8.4.2), required under the GLBA Safeguards Rule, strongly recommended under HIPAA, expected under OSFI B-13, and constitutes an "appropriate technical measure" under GDPR. Implementing MFA universally satisfies all six frameworks simultaneously. **RBAC with least-privilege access** is explicitly required by HIPAA (minimum necessary standard), PCI DSS (Requirement 7), GDPR (data protection by design), SOX (segregation of duties), GLBA, and OSFI B-13.

**Audit log retention** is where framework requirements diverge most, requiring the "maximum of applicable frameworks" approach. PCI DSS requires **12 months** with 3 months immediately available. HIPAA requires **6 years** from creation or last effective date. SOX requires **7 years** for audit workpapers. GDPR has no fixed period but requires proportionality. NIS 2 requires **18 months** for security incident logs. When building for multiple frameworks, default to the longest applicable period.

**Breach notification timelines** span from GDPR's **72 hours** to supervisory authority, to GLBA's **30 days** to FTC, PIPEDA's "as soon as feasible" for RROSH incidents, HIPAA's **60 days** from discovery, and PCI DSS's card-brand-dependent timelines. An incident response system must track all applicable deadlines simultaneously.

These mappings can be expressed in machine-readable YAML linking framework references to technical controls and detection methods:

```yaml
compliance_rule:
  id: "CTRL-ENC-001"
  name: "Encryption at Rest"
  frameworks:
    - framework: "HIPAA"
      reference: "45 CFR 164.312(a)(2)(iv)"
      requirement_level: "required"
    - framework: "PCI_DSS_v4"
      reference: "Requirement 3.5"
      requirement_level: "required"
    - framework: "GDPR"
      reference: "Article 32(1)(a)"
      requirement_level: "recommended"
  technical_control:
    algorithm: "AES-256"
    scope: ["database", "file_storage", "backup"]
  detection_methods:
    - method: "terraform_scan"
      check: "aws_s3_bucket.server_side_encryption_configuration exists"
    - method: "cloud_api"
      aws: "s3:GetBucketEncryption"
```

OSCAL provides the formal standard for these mappings. Its Catalog layer defines controls, Profile layer customizes baselines, Component Definition maps implementation, and Assessment layers verify compliance — all in interoperable XML/JSON/YAML. Integrating OSCAL catalogs as the canonical control source would enable Stoke's detection engine to follow a standards-based pipeline: detected project signals → OSCAL controls → framework requirements → gap analysis → remediation guidance.

---

## Conclusion: building the detection-to-control pipeline

The automated compliance wizard for Stoke should follow a three-stage architecture. **Stage one** scans project artifacts — dependency manifests, schema files, environment variables, locale configurations, infrastructure-as-code, and domain registrations — assigning weighted confidence scores to each detected signal. **Stage two** maps cumulative signal scores to framework applicability using decision trees: PIPEDA triggers for any cross-border Canadian commercial activity, CASL triggers when email infrastructure plus Canadian targeting is detected, PCI DSS scope level derives from payment integration architecture classification (SAQ A vs A-EP vs D), GDPR triggers on cumulative EU-targeting evidence, and COPPA triggers on children's content signals combined with US audience reach. **Stage three** generates the technical control checklist by cross-referencing all applicable frameworks against the unified control matrix, selecting the strictest requirement when frameworks overlap (e.g., 7-year log retention if SOX applies, MFA everywhere if PCI DSS applies).

The key implementation insight is that **no public, maintained database maps software packages to regulatory implications**. Creating this database — "stripe → payment processing → PCI DSS," "hapi-fhir → health data → HIPAA," "sendgrid + .ca → email messaging → CASL" — would be foundational infrastructure for the compliance wizard and potentially valuable as an open-source contribution. Expressing these rules in OPA/Rego for enforcement and OSCAL for documentation creates a standards-based system that can interoperate with the existing compliance tooling ecosystem while filling the framework detection gap that no current tool addresses.