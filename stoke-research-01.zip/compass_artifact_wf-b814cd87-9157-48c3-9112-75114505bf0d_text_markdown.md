# Building an agentic tool-use loop with the Anthropic Messages API

**The Anthropic Messages API implements tool use through a stateless request-response loop:** you send tool definitions in the `tools` array, Claude responds with `tool_use` content blocks (stop_reason `"tool_use"`), you execute the tools and return `tool_result` blocks in the next user message, and you repeat until Claude responds with stop_reason `"end_turn"`. Every piece of conversation state — including all prior tool_use/tool_result pairs — must be sent in the `messages` array on every request. This guide covers the exact schemas, streaming mechanics, caching strategies, extended thinking integration, error handling, built-in tool definitions, and cost tracking you need to implement this loop in Go.

---

## 1. The complete request-response cycle for tool calling

### Tool definition schema

Each tool in the `tools` array requires `name`, `description`, and `input_schema` (a standard JSON Schema object):

```json
{
  "name": "read_file",
  "description": "Read contents of a file at the given path",
  "input_schema": {
    "type": "object",
    "properties": {
      "path": {"type": "string", "description": "Absolute file path to read"},
      "line_range": {
        "type": "array",
        "items": {"type": "integer"},
        "description": "Optional [start, end] line range (1-indexed)"
      }
    },
    "required": ["path"]
  }
}
```

Tool names must match `^[a-zA-Z0-9_-]{1,64}$`. Optional fields include `cache_control` (for prompt caching), `strict: true` (for schema enforcement), and `input_examples` (example inputs).

### Assistant response with tool_use blocks

When Claude decides to call a tool, the response contains one or more `tool_use` content blocks and sets `stop_reason` to `"tool_use"`:

```json
{
  "id": "msg_01XAbCDeFgHiJkLm",
  "type": "message",
  "role": "assistant",
  "model": "claude-sonnet-4-5-20250929",
  "stop_reason": "tool_use",
  "content": [
    {
      "type": "text",
      "text": "I'll read that file for you."
    },
    {
      "type": "tool_use",
      "id": "toolu_01A09q90qw90lq917835lq9",
      "name": "read_file",
      "input": {"path": "/src/main.go"}
    }
  ],
  "usage": {"input_tokens": 450, "output_tokens": 52}
}
```

The **`id` field** (e.g., `"toolu_01A09q..."`) is critical — you must match it when returning results. Claude may emit text before tool_use blocks, and may request **multiple tools in parallel** within a single response.

### Returning tool results

Tool results go in a `user` message with `tool_result` content blocks. Every `tool_use` block must receive a corresponding `tool_result`:

```json
{
  "role": "user",
  "content": [
    {
      "type": "tool_result",
      "tool_use_id": "toolu_01A09q90qw90lq917835lq9",
      "content": "package main\n\nimport \"fmt\"\n\nfunc main() {\n    fmt.Println(\"hello\")\n}"
    }
  ]
}
```

The `content` field accepts a plain string, an array of content blocks (`text`, `image`, `document`), or can be omitted entirely for tools with no meaningful output. For errors, set `"is_error": true` alongside a descriptive error message.

For **parallel tool calls**, all results go in a single user message, with `tool_result` blocks first and any additional text after:

```json
{
  "role": "user",
  "content": [
    {"type": "tool_result", "tool_use_id": "toolu_01", "content": "result 1"},
    {"type": "tool_result", "tool_use_id": "toolu_02", "content": "result 2"},
    {"type": "text", "text": "Optional user commentary after results"}
  ]
}
```

### The tool_choice parameter

| Value | JSON | Behavior |
|---|---|---|
| auto (default) | `{"type": "auto"}` | Claude decides whether to use tools |
| any | `{"type": "any"}` | Claude must use at least one tool |
| specific tool | `{"type": "tool", "name": "read_file"}` | Claude must use the named tool |
| none | `{"type": "none"}` | Tools are disabled |

Add `"disable_parallel_tool_use": true` to prevent Claude from calling multiple tools simultaneously. When using extended thinking, only `"auto"` and `"none"` are supported.

---

## 2. Multi-turn state management and the agentic loop structure

The Messages API is **stateless** — you must send the entire conversation history on every request. The `messages` array grows with each tool-use turn following a strict alternating user/assistant pattern:

```json
{
  "model": "claude-sonnet-4-5-20250929",
  "max_tokens": 8192,
  "system": "You are a coding assistant with access to the filesystem.",
  "tools": [/* tool definitions */],
  "messages": [
    {"role": "user", "content": "Fix the bug in main.go"},
    {"role": "assistant", "content": [
      {"type": "text", "text": "Let me read the file first."},
      {"type": "tool_use", "id": "toolu_01", "name": "read_file",
       "input": {"path": "/src/main.go"}}
    ]},
    {"role": "user", "content": [
      {"type": "tool_result", "tool_use_id": "toolu_01",
       "content": "package main\n\nfunc main() {\n    fmt.Println(\"hello\")\n}"}
    ]},
    {"role": "assistant", "content": [
      {"type": "text", "text": "I see the issue — missing import. Let me fix it."},
      {"type": "tool_use", "id": "toolu_02", "name": "write_file",
       "input": {"path": "/src/main.go", "content": "package main\n\nimport \"fmt\"\n\nfunc main() {\n    fmt.Println(\"hello\")\n}"}}
    ]},
    {"role": "user", "content": [
      {"type": "tool_result", "tool_use_id": "toolu_02", "content": "File written successfully."}
    ]}
  ]
}
```

### The core loop in Go pseudocode

```go
for turn := 0; turn < maxTurns; turn++ {
    resp := client.CreateMessage(model, system, tools, messages)
    
    // Append assistant response to messages
    messages = append(messages, Message{Role: "assistant", Content: resp.Content})
    
    if resp.StopReason != "tool_use" {
        break  // "end_turn", "max_tokens", "stop_sequence", or "refusal"
    }
    
    // Execute each tool_use block, collect results
    var results []ContentBlock
    for _, block := range resp.Content {
        if block.Type == "tool_use" {
            result := executeTool(block.Name, block.Input)
            results = append(results, ToolResult{
                ToolUseID: block.ID,
                Content:   result,
            })
        }
    }
    messages = append(messages, Message{Role: "user", Content: results})
}
```

### Stop reason values

| Value | Meaning | Action |
|---|---|---|
| `"end_turn"` | Claude finished naturally | Exit loop, display response |
| `"tool_use"` | Claude wants tool calls executed | Process tool_use blocks, continue loop |
| `"max_tokens"` | Hit max_tokens limit | May have truncated tool_use blocks — retry with higher limit |
| `"stop_sequence"` | Hit a custom stop sequence | Exit loop |
| `"pause_turn"` | Server tool iteration limit | Re-send conversation to continue |
| `"refusal"` | Claude refused to proceed | Exit loop, handle refusal |

### Context window strategies

Current context windows are **200K tokens** for most Claude 4.x models and **1M tokens** for Claude Opus 4.6 and Sonnet 4.6. When approaching limits in an agentic loop:

- **Proactive monitoring**: Use the `POST /v1/messages/count_tokens` endpoint before each turn to check remaining capacity
- **Tool result clearing**: Enable the `context-management-2025-06-27` beta header to auto-clear old tool results
- **Client-side truncation**: Drop the oldest conversation turns while preserving the system prompt and recent context
- **Server-side compaction**: Available in beta on Opus 4.6 via `compact_20260112`, which automatically summarizes older conversation turns

---

## 3. Streaming tool_use responses over SSE

Streaming works with tool use and is essential for responsive UIs. Set `"stream": true` in the request. The SSE event sequence for a response containing both text and a tool call:

```
event: message_start
data: {"type":"message_start","message":{"id":"msg_01...","role":"assistant",
       "content":[],"stop_reason":null,"usage":{"input_tokens":472,"output_tokens":2}}}

event: content_block_start
data: {"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}

event: content_block_delta
data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"Let me check"}}

event: content_block_delta
data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":" that file."}}

event: content_block_stop
data: {"type":"content_block_stop","index":0}

event: content_block_start
data: {"type":"content_block_start","index":1,
       "content_block":{"type":"tool_use","id":"toolu_01T1x...","name":"read_file","input":{}}}

event: content_block_delta
data: {"type":"content_block_delta","index":1,
       "delta":{"type":"input_json_delta","partial_json":""}}

event: content_block_delta
data: {"type":"content_block_delta","index":1,
       "delta":{"type":"input_json_delta","partial_json":"{\"path\":"}}

event: content_block_delta
data: {"type":"content_block_delta","index":1,
       "delta":{"type":"input_json_delta","partial_json":" \"/src/main"}}

event: content_block_delta
data: {"type":"content_block_delta","index":1,
       "delta":{"type":"input_json_delta","partial_json":".go\"}"}}

event: content_block_stop
data: {"type":"content_block_stop","index":1}

event: message_delta
data: {"type":"message_delta","delta":{"stop_reason":"tool_use"},
       "usage":{"output_tokens":89}}

event: message_stop
data: {"type":"message_stop"}
```

**Key implementation details for Go:**

- **Text blocks** arrive as `text_delta` events with incremental text strings — concatenate and display immediately
- **Tool_use blocks** arrive as `input_json_delta` events with `partial_json` strings — **accumulate these into a buffer** and parse the complete JSON only after the `content_block_stop` event
- The `content_block_start` event for tool_use includes the `id` and `name` but an empty `input: {}`
- Models emit **one complete key-value pair at a time** in the JSON deltas, so expect pauses between delta events
- The `message_delta` event carries the final `stop_reason` and cumulative `usage` — check this to know whether to enter the tool execution phase
- Text content typically streams before tool_use blocks in the same response

---

## 4. Tool definition token overhead and how to minimize it

### Fixed overhead per request

When any tools are present with `tool_choice: "auto"`, Anthropic injects **~346 tokens** of system prompt overhead (for Claude 4.x models). This is a fixed cost regardless of how many tools you define.

### Per-tool costs

Each tool's `name`, `description`, and `input_schema` are serialized into the prompt and billed as input tokens. Built-in tools have fixed overhead: the **bash tool adds ~245 tokens**, the **text editor adds ~700 tokens**, and the **computer use tool adds ~735 tokens** per definition.

### Minimization strategies for 10–15 coding tools

Use the `POST /v1/messages/count_tokens` endpoint to measure exact overhead for your specific tool set. Then apply these strategies:

- **Cache tool definitions** by placing `cache_control` on the last tool in the array — subsequent requests read tools from cache at **10% of base input price** ($0.30/MTok instead of $3/MTok for Sonnet)
- **Write concise descriptions** — every word in `description` and every schema property costs tokens on every request
- **Omit optional schema properties** where Claude can infer intent from the name
- **Use tool search** (`tool_search_tool`) for large tool sets — tools load on-demand rather than all upfront
- Claude 4+ models include **token-efficient tool use** by default (no beta header needed)

---

## 5. Extended thinking integration with the tool loop

Extended thinking lets Claude reason before acting. Enable it with the `thinking` parameter:

```json
{
  "model": "claude-sonnet-4-5-20250929",
  "max_tokens": 16000,
  "thinking": {"type": "enabled", "budget_tokens": 10000},
  "tools": [/* tools */],
  "messages": [/* messages */]
}
```

### How thinking blocks appear alongside tool calls

Claude produces `thinking` → `text` → `tool_use` blocks in a single response:

```json
{
  "content": [
    {
      "type": "thinking",
      "thinking": "The user wants to fix a bug. I should first read the file to understand the issue...",
      "signature": "EqQBCgIYAhIM1gbcDa9GJwZA2b3h..."
    },
    {"type": "text", "text": "Let me examine the file."},
    {"type": "tool_use", "id": "toolu_01XYZ", "name": "read_file",
     "input": {"path": "/src/main.go"}}
  ],
  "stop_reason": "tool_use"
}
```

### Critical rules for preserving thinking blocks

**You must pass thinking blocks back unmodified** when sending tool results. The `signature` field is an encrypted verification hash — do not modify, reorder, or selectively include thinking blocks:

```json
{
  "messages": [
    {"role": "user", "content": "Fix the bug in main.go"},
    {"role": "assistant", "content": [
      {"type": "thinking", "thinking": "The user wants...", "signature": "EqQB..."},
      {"type": "tool_use", "id": "toolu_01XYZ", "name": "read_file",
       "input": {"path": "/src/main.go"}}
    ]},
    {"role": "user", "content": [
      {"type": "tool_result", "tool_use_id": "toolu_01XYZ",
       "content": "package main\n..."}
    ]}
  ]
}
```

**Interleaved thinking** (reasoning between consecutive tool calls) is available on Claude 4.x models via the `interleaved-thinking-2025-05-14` beta header, and is automatic on Opus 4.6/Sonnet 4.6 with adaptive thinking. With interleaved thinking, `budget_tokens` can exceed `max_tokens` because it becomes the total budget across all thinking blocks in one turn.

The `tool_choice` restriction is important: **only `"auto"` and `"none"` are supported** when extended thinking is enabled. Using `"any"` or `"tool"` will return an API error.

---

## 6. Prompt caching strategy for agentic tool loops

Prompt caching can cut costs dramatically in multi-turn tool loops. The cache follows the hierarchy **tools → system → messages**, and a cache breakpoint caches everything before it.

### Recommended caching structure

Use **automatic caching** at the request level combined with explicit breakpoints on stable content:

```json
{
  "model": "claude-sonnet-4-5-20250929",
  "max_tokens": 8192,
  "cache_control": {"type": "ephemeral"},
  "system": [
    {
      "type": "text",
      "text": "You are an expert coding assistant...",
      "cache_control": {"type": "ephemeral"}
    }
  ],
  "tools": [
    {"name": "read_file", "description": "...", "input_schema": {/* ... */}},
    {"name": "write_file", "description": "...", "input_schema": {/* ... */},
     "cache_control": {"type": "ephemeral"}}
  ],
  "messages": [/* conversation */]
}
```

**How this works across turns:** The explicit breakpoints on system and the last tool keep tool definitions cached at 0.1x cost. The top-level `cache_control` automatically places a breakpoint on the last message, so the growing conversation history is incrementally cached — each new turn reads previous turns from cache and only pays full price for the new content.

### Cache math for an agentic coding session

With **Sonnet 4.5** ($3/MTok input, $0.30/MTok cache read, $3.75/MTok cache write):

- **Turn 1**: 15K tokens written to cache → $0.056
- **Turn 2**: 15K read from cache + 2K new → $0.004 (read) + $0.008 (write) = $0.012
- **Turn 10**: 30K read from cache + 2K new → $0.009 + $0.008 = $0.017

Without caching, turn 10 would cost $0.096 for 32K input tokens. **Caching saves ~82% on input costs** for longer conversations.

### Key constraints

- Minimum cacheable size: **1,024 tokens** for Sonnet 4.5/4, **4,096 tokens** for Opus 4.5
- Maximum **4 explicit breakpoints** per request (automatic caching uses one slot)
- Cache entries last **5 minutes** by default (refreshed on hit), or **1 hour** with `"ttl": "1h"` at 2x write cost
- Modifying tool definitions invalidates the entire cache chain
- Thinking blocks cannot have explicit `cache_control` but are cached alongside other content in tool-use turns

---

## 7. Error handling in the tool loop

### Returning errors via is_error

When tool execution fails, return a `tool_result` with `"is_error": true`. You **must always return a tool_result** for every tool_use — omitting it causes a 400 API error:

```json
{
  "type": "tool_result",
  "tool_use_id": "toolu_01A09q90qw90lq917835lq9",
  "content": "Error: ENOENT: no such file or directory '/src/missing.go'",
  "is_error": true
}
```

Claude will either retry with corrections (typically **2–3 attempts**), try an alternative approach, or inform the user. To prevent infinite retries, include actionable guidance in the error message:

```json
{
  "type": "tool_result",
  "tool_use_id": "toolu_01ABC",
  "content": "Error: File '/etc/shadow' cannot be read (permission denied). Do NOT retry. Inform the user that this file requires elevated permissions.",
  "is_error": true
}
```

### Defensive loop patterns

```go
maxTurns := 25  // Hard limit on total API calls
consecutiveErrors := 0
maxConsecutiveErrors := 3

for turn := 0; turn < maxTurns; turn++ {
    resp := callAPI(messages)
    if resp.StopReason != "tool_use" { break }
    
    hasError := false
    for _, block := range resp.Content {
        if block.Type == "tool_use" {
            result, err := executeTool(block)
            if err != nil {
                hasError = true
                // Return descriptive error
                results = append(results, ToolResult{
                    ToolUseID: block.ID,
                    Content:   fmt.Sprintf("Error: %v. Try a different approach.", err),
                    IsError:   true,
                })
            }
        }
    }
    
    if hasError { consecutiveErrors++ } else { consecutiveErrors = 0 }
    if consecutiveErrors >= maxConsecutiveErrors {
        // Force exit — inject guidance message
        break
    }
}
```

**Handle `max_tokens` truncation**: If `stop_reason` is `"max_tokens"` and the last content block is an incomplete `tool_use`, the JSON input may be truncated. Retry with a higher `max_tokens` value rather than trying to parse the partial block.

---

## 8. Anthropic's built-in bash and text editor tools

Anthropic provides **trained-in client tools** that Claude calls more reliably than equivalent user-defined tools. They use a `type` field with a version string instead of `input_schema`:

### Bash tool

```json
{"type": "bash_20250124", "name": "bash"}
```

That is the complete definition — no `description` or `input_schema`. Claude sends `{"command": "ls -la"}` in the `tool_use` input. Returns stdout/stderr as the tool result string. Adds **~245 input tokens** overhead. Supports a `"restart": true` parameter to reset the bash session.

### Text editor tool

```json
{"type": "text_editor_20250728", "name": "str_replace_based_edit_tool"}
```

Adds **~700 input tokens** overhead. Supports five commands via the `command` field in tool_use input:

- **`view`**: Read a file or list a directory. Parameters: `path`, optional `view_range: [start, end]`
- **`create`**: Create a new file. Parameters: `path`, `file_text`
- **`str_replace`**: Replace an exact string match. Parameters: `path`, `old_str`, `new_str`
- **`insert`**: Insert text after a line number. Parameters: `path`, `insert_line`, `insert_text`
- **`undo_edit`**: Only available in older versions (20250124, 20241022), removed in Claude 4's 20250429+

**Version notes**: For Claude 4 models, the tool name is `"str_replace_based_edit_tool"`. For Claude 3.7/3.5, it was `"str_replace_editor"`. The latest version `text_editor_20250728` adds an optional `max_characters` parameter.

### Can you replicate these with custom tools?

Yes, but with caveats. You can define equivalent user-defined tools with your own `input_schema` and descriptions, then implement the execution layer yourself. However, **Claude is specifically trained on the built-in tool signatures** and will call them more reliably, with fewer formatting errors, than equivalents you define yourself. For a coding harness, using the built-in bash and text_editor tools with your own execution backend is the recommended approach.

### All three together in a request

```json
{
  "tools": [
    {"type": "bash_20250124", "name": "bash"},
    {"type": "text_editor_20250728", "name": "str_replace_based_edit_tool"},
    {"name": "run_tests", "description": "Run the test suite",
     "input_schema": {"type": "object", "properties": {
       "filter": {"type": "string"}
     }}}
  ]
}
```

Anthropic-defined and user-defined tools coexist in the same `tools` array. The execution model is identical — both produce `tool_use` blocks and expect `tool_result` blocks.

---

## 9. Token usage tracking and cost computation

### The usage object

Every API response includes a `usage` object with these fields:

```json
{
  "usage": {
    "input_tokens": 50,
    "output_tokens": 89,
    "cache_creation_input_tokens": 15000,
    "cache_read_input_tokens": 0,
    "server_tool_use": {
      "web_search_requests": 0
    }
  }
}
```

**The critical formula for total input tokens processed:**

```
total_input = input_tokens + cache_creation_input_tokens + cache_read_input_tokens
```

When caching is active, `input_tokens` only represents tokens **after the last cache breakpoint**. The `cache_creation_input_tokens` and `cache_read_input_tokens` represent the cached prefix.

### Accumulating costs across an agentic conversation

Sum usage fields from every API call in the loop. In Go:

```go
type CostTracker struct {
    InputTokens           int
    OutputTokens          int
    CacheWriteTokens      int
    CacheReadTokens       int
}

func (c *CostTracker) Add(usage Usage) {
    c.InputTokens += usage.InputTokens
    c.OutputTokens += usage.OutputTokens
    c.CacheWriteTokens += usage.CacheCreationInputTokens
    c.CacheReadTokens += usage.CacheReadInputTokens
}

func (c *CostTracker) TotalCostUSD(model string) float64 {
    // Sonnet 4.5 pricing (per token)
    inputPrice := 3.0 / 1_000_000
    outputPrice := 15.0 / 1_000_000
    cacheWritePrice := 3.75 / 1_000_000
    cacheReadPrice := 0.30 / 1_000_000

    return float64(c.InputTokens)*inputPrice +
           float64(c.OutputTokens)*outputPrice +
           float64(c.CacheWriteTokens)*cacheWritePrice +
           float64(c.CacheReadTokens)*cacheReadPrice
}
```

### Current pricing reference

| Model | Input $/MTok | Output $/MTok | Cache Write | Cache Read |
|---|---|---|---|---|
| Claude Sonnet 4.5/4.6/4 | $3 | $15 | $3.75 | $0.30 |
| Claude Opus 4.5/4.6 | $5 | $25 | $6.25 | $0.50 |
| Claude Opus 4/4.1 | $15 | $75 | $18.75 | $1.50 |
| Claude Haiku 4.5 | $1 | $5 | $1.25 | $0.10 |

Extended thinking tokens are billed as output tokens. The `output_tokens` field includes thinking tokens, and you pay for the full reasoning even when summaries are displayed. When streaming, the cumulative `usage` in the `message_delta` event gives the final token counts for that turn.

---

## Conclusion

The Anthropic tool-use loop is architecturally simple but has important details that determine reliability and cost. The **stateless messages array** means your Go harness owns conversation state entirely — you control truncation, caching, and loop termination. Three decisions matter most for production quality: using **prompt caching** (automatic + explicit breakpoints on tools and system) to cut input costs by 80%+ on long conversations, using **Anthropic's built-in bash and text_editor tools** rather than reimplementing their schemas for higher call reliability, and implementing **defensive loop bounds** with both a max-turns counter and consecutive-error tracking to prevent runaway tool loops. Extended thinking with interleaved reasoning is the highest-quality mode for complex coding tasks but requires careful handling of thinking block signatures across turns. For context management at scale, the token counting endpoint enables proactive monitoring, and the new compaction features on Opus 4.6 provide server-side summarization for effectively infinite conversations.