# AI coding agents can enforce UI/UX completeness — here's the full toolkit

**Every "shipped but broken" UI shares the same root cause: someone forgot a state.** A growing ecosystem of AI agent skill files, linting tools, visual testing infrastructure, and CI enforcement patterns now makes it possible to prevent this systematically. This report catalogs the complete landscape — from SKILL.md files that teach AI agents to handle empty states, to ESLint plugins that ban hardcoded hex colors, to screen reader automation that catches what no pixel-diff ever will. The goal: a comprehensive reference for building a SKILL.md that ensures AI coding agents never ship a feature without handling every possible state and making every function reachable.

---

## AI agent skill files now encode UI state completeness as law

The most mature enforcement mechanism is the **SKILL.md file** — a structured instruction set that AI coding agents (Claude Code, Cursor, Copilot, Windsurf) read before generating any code. Several high-quality examples exist on GitHub, each approaching UI completeness differently.

**ChrisWiles/claude-code-showcase** (`react-ui-patterns/SKILL.md`, 5.1k stars) enforces a strict decision tree: error state → loading state (only when no cached data exists) → empty state → success state. Its golden rules include "never show stale UI" and "always surface errors." Every component must pass a checklist: error state handled, loading state shown only without data, empty state provided for collections, buttons disabled during async operations, all mutations have `onError` handlers, and all user actions produce feedback.

**nextlevelbuilder/ui-ux-pro-max-skill** (49.3k stars, 659 lines) is the most comprehensive, organizing **10 priority levels** across accessibility, touch interaction, performance, forms, animation, and data visualization. Priority 1 (Critical) enforces **4.5:1 color contrast**, visible focus rings, and `prefers-reduced-motion` respect. Priority 3 (High) mandates skeleton screens over spinners for operations exceeding 1 second, offline state messaging, and network fallback modes. Priority 8 covers empty states with "helpful message and action," submit feedback with loading-then-success/error flow, and error recovery paths. Each rule includes an anti-patterns table showing what to reject.

**shadcn-ui's official SKILL.md** takes a composition-first approach: "Empty states use `Empty`. Don't build custom empty state markup." It mandates `AvatarFallback` for every Avatar, `Skeleton` for loading, and `Alert` for error callouts. The file references sub-rules for forms (`rules/forms.md`) and composition patterns.

**Garry Tan's gstack** (`plan-design-review/SKILL.md`) dispatches a Claude design subagent to evaluate information hierarchy and flag missing states: loading, empty, error, and success. It classifies pages as marketing, app UI, or hybrid, then applies different violation rules — marketing pages need "brand-first hierarchy" and "full-bleed hero," while app UIs need "calm surface hierarchy" and "dense but readable" layouts.

For **.cursorrules files**, the ecosystem is less UI-state-focused. RunPod's openv `.cursorrules` requires "handle loading and error states consistently across queries." The **cursor.directory** community maintains rules under `/rules/ui` and `/rules/ux` categories, covering inline validation, responsive design, and progressive disclosure. **.windsurfrules** files tend to focus on development workflow rather than UI completeness, though `obviousworks/vibe-coding-ai-rules` includes ErrorBoundary patterns. **Copilot instructions** (`.github/copilot-instructions.md`) files commonly require "gracefully handling null, undefined, and empty states" and "implementing fallback UI states."

---

## The taste-skill fights AI's statistical convergence toward generic design

The **taste-skill** by Leon Lin (5.5k stars, [github.com/Leonxlnx/taste-skill](https://github.com/Leonxlnx/taste-skill)) is the most opinionated design enforcement system available. Its core thesis: LLMs have probability biases toward specific UI clichés, and taste-skill proactively overrides these defaults.

It ships **7 specialized variants**: the main taste-skill (layout, typography, color, spacing, motion), redesign-skill (6-category audit for existing projects), soft-skill (premium fonts, whitespace, depth, spring animations), output-skill (prevents placeholder comments and half-finished code), minimalist-skill (Notion/Linear-inspired editorial style), brutalist-skill (Swiss typographic + CRT aesthetics), and stitch-skill (Google Stitch-compatible rules).

The system's innovation is a **3-dial parameterization**: `DESIGN_VARIANCE` (1=symmetry, 10=artsy chaos), `MOTION_INTENSITY` (1=static, 10=cinematic), and `VISUAL_DENSITY` (1=airy, 10=packed data). Default is (8, 6, 4). AI adapts dynamically based on user prompts.

Its anti-slop rules are extensive and specific. **The Lila Ban** prohibits AI purple/blue aesthetics — no purple button glows, no neon gradients. **Inter font is banned** for premium or creative contexts; replacements include Geist, Outfit, Cabinet Grotesk, or Satoshi. The **Anti-Center Bias** bans centered hero sections when layout variance exceeds 4, forcing split-screen or asymmetric layouts. **Anti-Card Overuse** bans generic card containers at high visual density, requiring `border-t`, `divide-y`, or negative space instead.

Content rules ban fake data patterns ("99.99%", "50%") in favor of organic numbers ("47.2%"), ban startup slop names ("Acme", "Nexus", "SmartFlow"), ban filler words ("Elevate", "Seamless", "Unleash"), and enforce an **anti-emoji policy** across all code, markup, and text. For UI states specifically, taste-skill requires skeletal loaders matching layout sizes (no generic circular spinners), "beautifully composed" empty states indicating how to populate data, clear inline error reporting, and tactile feedback on interactions (`-translate-y-[1px]` or `scale-[0.98]` on `:active`).

---

## Vercel and Anthropic represent two philosophies of AI design enforcement

**Vercel's web-design-guidelines** is an auditing skill — it reviews existing code against **100+ rules across 7 sections**, fetched dynamically from `vercel-labs/web-interface-guidelines`. The rules are engineering-precise and checkable:

- **Interactions** (~25 rules): All flows keyboard-operable per WAI-ARIA, visible focus rings via `:focus-visible`, hit targets ≥24px (44px on mobile), input font ≥16px on mobile to prevent iOS auto-zoom, loading buttons that show indicator while keeping original label, **minimum loading-state duration of 150–300ms** show-delay with 300–500ms minimum visible time to avoid flicker, URL as state for shareability, and "no dead zones" — every interactive-looking element must actually be interactive.
- **Content** (~20 rules): **"All states designed: empty, sparse, dense, and error"**, stable skeletons that mirror final content exactly, redundant status cues beyond color alone, icons with text labels, semantics before ARIA.
- **Forms** (~17 rules): Enter submits when focused on single text input, labels on every control, never block typing, don't pre-disable submit buttons, error placement next to fields with focus on first error, `autocomplete` attributes set correctly.
- **Performance** (~14 rules): Track re-renders, throttle when profiling, virtualize large lists, no image-caused CLS, preconnect to origins.

**Vercel's react-best-practices** is a separate **69-rule performance optimization framework** prioritized by impact. Critical rules include eliminating async waterfalls (`Promise.all()` for independent operations, `Suspense` for streaming), bundle size optimization (direct imports over barrel files, `next/dynamic` for heavy components, deferring analytics after hydration), and server-side patterns (React.cache() for deduplication, minimal client component serialization).

**Anthropic's frontend-design skill** ([github.com/anthropics/skills](https://github.com/anthropics/skills), 84.2k stars, 277k+ installs) takes the opposite approach — it's generative rather than auditing, focused on **aesthetic distinctiveness** rather than compliance. Before writing any code, Claude must define purpose, tone (choosing from options like "brutally minimal," "maximalist chaos," "retro-futuristic," or "luxury/refined"), constraints, and "what makes this UNFORGETTABLE."

The skill explicitly bans Inter, Roboto, Arial, system fonts, and Space Grotesk ("overused by AI"). It rejects "purple gradients on white backgrounds" and "cookie-cutter design." Its diversity mandate states "no design should be the same — vary between light and dark themes, different fonts, different aesthetics." A community analysis by Justin Wetch found that the directive to "NEVER converge on common choices across generations" is technically impossible since Claude has no cross-conversation memory; his revision won **75% of blind A/B comparisons** across Haiku, Sonnet, and Opus models.

The philosophical split is clear: Vercel enforces engineering correctness (accessibility, keyboard navigation, performance), while Anthropic enforces creative distinctiveness (typography, color, layout asymmetry). A complete SKILL.md needs both.

---

## Design system enforcement has mature tooling from Atlassian to Shopify

The most production-hardened approach to UI consistency is **programmatic design token enforcement** — ESLint and Stylelint plugins that make raw CSS values a build error.

**Atlassian's `@atlaskit/eslint-plugin-design-system`** is the gold standard with **30+ rules**: `ensure-design-token-usage` flags hardcoded colors and spacing with auto-fix, `prefer-primitives` enforces Box/Stack/Inline over raw divs, `no-html-button` and `no-html-anchor` force design system components, `no-physical-properties` enforces CSS logical properties for RTL support, and `no-unsafe-style-overrides` prevents overriding component internals. Token lifecycle management is built in: active → deprecated (minor) → soft-deleted (next minor) → deleted (major), with auto-fixers that update entire codebases via `eslint --fix`.

**Shopify's stylelint-polaris** provides **40+ rules across 10 categories** measuring design system coverage. It blocks hex colors, named colors, hardcoded spacing/border/typography values, and hardcoded animation durations. Z-index values must come from Polaris tokens. Private `--pc-*` component tokens cannot be referenced externally. When developers must diverge, they must provide a justification comment: `/* stylelint-disable-next-line -- reason */`.

**IBM's stylelint-plugin-carbon-tokens** validates against `@carbon/themes`, `@carbon/colors`, `@carbon/layout`, `@carbon/type`, and `@carbon/motion` with auto-fixes for 1:1 mappings (e.g., `16px` → `$spacing-05`). **MetaMask's `@metamask/eslint-plugin-design-tokens`** enforces `color-no-hex`, deployed initially as `"warn"` then tightened to `"error"` for new code. **Salesforce's `@salesforce-ux/eslint-plugin-slds`** handles token migration from `--lwc` to `--slds` tokens.

**Style Dictionary** (Amazon) is the build system that transforms design tokens from JSON source to any platform — CSS, SCSS, iOS Swift, Android Kotlin. **Tokens Studio for Figma** syncs tokens directly to Git repositories, triggering GitHub Actions that run `token-transformer` → Style Dictionary → auto-create PR. This creates a zero-developer pipeline where designers can update tokens autonomously.

The recommended CI enforcement is layered: pre-commit hooks run ESLint + Stylelint on staged files, PR-level linting enforces zero-warning tolerance, token validation checks JSON structure and naming conventions, and Chromatic runs visual regression testing. Phased rollout starts with `"warn"` to collect data, then `"error"` for new code, then full enforcement.

---

## Accessibility automation operates in layers, each catching different defects

No single tool catches all accessibility issues — **automated tools detect 30–57% of WCAG violations**. The defense-in-depth approach layers static analysis, unit tests, browser tests, and screen reader automation.

**eslint-plugin-jsx-a11y** catches issues at write-time through static AST analysis: missing alt text, invalid ARIA attributes, non-interactive element misuse, missing form labels. Its `strict` preset escalates 5 rules from warn to error. Configuration supports component mapping so custom components like `CustomButton` are validated as `button`.

**axe-core with Playwright** (`@axe-core/playwright`) runs accessibility scans in real browsers where color contrast rules actually work. The recommended pattern uses a reusable test fixture:

```typescript
export const test = base.extend<AxeFixture>({
  makeAxeBuilder: async ({ page }, use) => {
    const makeAxeBuilder = () =>
      new AxeBuilder({ page })
        .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
        .exclude('#commonly-reused-element-with-known-issue');
    await use(makeAxeBuilder);
  },
});
```

**Playwright's built-in ARIA snapshot testing** (`toMatchAriaSnapshot()`) compares the accessibility tree against a YAML template — catching structural regressions like missing headings, unlabeled inputs, or broken navigation hierarchy. This is distinct from axe-core: it verifies the *structure* of what assistive technology sees, not WCAG rule compliance.

**Guidepup** tests what users actually *hear* by driving real VoiceOver (macOS) or NVDA (Windows). Its `@guidepup/virtual-screen-reader` package provides a unit-test-friendly simulation that verifies spoken phrase sequences without OS-level dependencies. For CI, the `guidepup/setup-action` GitHub Action handles OS permissions.

**Pa11y-CI** scans URLs against WCAG standards using both HTML CodeSniffer and axe-core runners. It supports actions (fill fields, click buttons, wait for navigation) and threshold-based gating. **GitHub's official accessibility-scanner action** finds gaps, files issues, and auto-assigns Copilot for fix suggestions.

A comprehensive CI workflow runs **5 parallel jobs**: ESLint a11y rules (static), jest-axe component tests (JSDOM), Playwright + axe-core E2E tests (real browser), Pa11y URL scanning, and Lighthouse accessibility score gating (minimum 0.9).

---

## Visual regression testing needs different strategies for AI-generated UI

The fundamental challenge with AI-generated UI is **non-determinism**. Each tool handles this differently.

**Applitools Eyes** is the strongest option for AI-generated content because its Visual AI compares at a perceptual level, not pixel-by-pixel. Its **Layout match level** ignores content changes but catches layout shifts — ideal when AI-generated text varies but structure should be stable. The **Dynamic match level** automatically handles dates, transaction IDs, and user-specific content. Match levels can be mixed across different regions of the same page.

**Percy's Visual Review Agent** (launched late 2025) uses AI to analyze diffs: drawing bounding boxes around meaningful changes, generating human-readable summaries, and filtering ~40% of changes that are rendering noise. Its `percyCSS` option hides truly dynamic elements during snapshots.

**Chromatic** uses a proprietary anti-flake algorithm rather than configurable thresholds. Every Storybook story automatically becomes a visual test. **TurboSnap** limits testing to stories affected by code changes, reducing snapshot usage by 60–90%.

**Playwright's built-in visual comparisons** offer the most control for open-source teams. Three threshold parameters — `threshold` (color difference 0–1), `maxDiffPixels` (absolute count), and `maxDiffPixelRatio` (percentage) — can be configured per test. A `stylePath` CSS file can hide dynamic regions during capture. Critical caveat: baselines must be generated in the exact same environment (OS, browser version, headless mode) as CI.

**BackstopJS** provides per-scenario `misMatchThreshold` (percentage), `hideSelectors`, `removeSelectors`, `readySelector`, and `onReadyScript` for pre-capture Puppeteer manipulation. Docker containers ensure consistent rendering across environments.

For AI-generated UI specifically, the recommended pattern is **deterministic seeding**: mock AI service responses with fixed outputs for visual testing, then evaluate AI quality separately through semantic tests. Store "golden" AI outputs as test fixtures. Use Applitools Layout mode or higher Playwright thresholds for structural verification while accepting content variability.

---

## Analytics enforcement prevents the "shipped but unmeasured" anti-pattern

The most concrete real-world "no merge without analytics" implementation is **GitLab's Analytics Instrumentation Review**. When any merge request touches internal analytics code, it automatically receives `~analytics instrumentation` and `~analytics instrumentation::review pending` labels. A reviewer verifies event definitions exist, tracking parameters contain no sensitive data, metric YAML definitions are correct, and no deprecated methods are used. Approval relabels to `~"analytics instrumentation::approved"`.

**`eslint-plugin-segment-ember-actions`** is a real ESLint plugin that generates errors for action handler functions without `analytics.track()` calls — turning analytics instrumentation into a linting rule that blocks CI.

For **rage click detection**, FullStory leads with 5 automatic frustration signals (rage clicks, dead clicks, error clicks, thrashed cursor, frustrated sessions) plus client-side **Ragehooks** via `CustomEvent` API for real-time reactions. PostHog emits `$rageclick` events automatically with autocapture (3+ clicks within 3 seconds without mouse movement). LogRocket's Galileo AI categorizes issues by severity score. Microsoft Clarity offers unlimited free rage click detection.

**Dead feature detection** combines static analysis tools like Python's `deadcode` or Java's Sonargraph with runtime monitoring. Emerge Tools' **Reaper** (iOS) tracks which percentage of sessions actually use each class via Objective-C `+initialize` method instrumentation. Uber's **Piranha** specifically deletes dead feature flag code — addressing the common problem of disabled flags leaving large unreachable code branches.

---

## Form completeness requires validation timing, keyboard navigation, and autofill awareness

Research on **inline validation timing** reveals a nuanced consensus. Luke Wroblewski's original research showed on-blur validation speeds form completion. The "Reward Early, Punish Late" pattern (Mihael Konjević) is widely recommended: show success indicators immediately on valid input, show errors only after the user leaves the field, but when correcting an existing error, validate immediately to provide instant feedback. Contrarian UX Movement research (77 and 90 participants) found pre-submission inline validation caused *more* errors — users ignored messages and continued filling. **Vitaly Friedman's synthesis**: validate empty fields only on submit, validate non-empty fields earliest on blur, never assume field completion order.

**Autocomplete attributes** are critical for accessibility — WCAG 1.3.5 "Identify Input Purpose" requires them. Section grouping (`autocomplete="shipping street-address"` vs. `autocomplete="billing street-address"`) handles multiple address forms. Browsers may ignore `autocomplete="off"` on login fields to support password managers. React requires the camelCase `autoComplete` in JSX.

For **multi-step forms**, the recommended architecture chains React Hook Form + Zod + Zustand: per-step Zod schemas for validation, Zustand store with `persist` middleware for localStorage survival, and auto-focus on the first focusable element when each step activates. ARIA live regions should announce step changes for screen readers.

**Keyboard navigation** requires semantic HTML (natively keyboard-accessible), logical focus order matching visual layout, visible focus indicators (never `outline: none`), `tabindex="0"` for custom focusable elements (never `tabindex > 0`), and support for standard key patterns: Tab/Shift+Tab for navigation, Enter/Space for activation, Arrow keys for radio groups and dropdowns, Escape for closing overlays. Roughly **15–20% of WCAG violations** on typical websites are keyboard accessibility failures.

---

## i18n enforcement catches hardcoded strings, missing translations, and layout breakage

**eslint-plugin-i18next** (`no-literal-string` rule) is the primary linting tool, flagging any literal string in JSX: `<div>hello world</div>` errors, while `<div>{t('HELLO_KEY')}</div>` passes. Smart defaults allow UPPER_CASE constants, TypeScript type members, and configurable ignore patterns for `data-testid`, `className`, and console calls. For Vue, `@intlify/eslint-plugin-vue-i18n` adds `no-dynamic-keys` and `no-unused-keys`.

**Pseudo-localization** is the most underused testing technique. The `pseudo-localization` npm package (inspired by Netflix/Firefox) transforms English text with accent marks and padding to simulate translation expansion. The `pseudo-l10n` package generates pseudo-locale files with configurable **40% expansion** and RTL variants. Android offers built-in pseudolocales: `EN (XA)` for accented expansion and `AR (XB)` for RTL simulation. Detection is intuitive: missing bracket markers (`⟦⟧`) reveal untranslated strings, truncated end markers reveal overflow, and split brackets reveal string concatenation problems. Organizations report pseudo-localization **reduces localization rework by 40–60%**.

**ICU MessageFormat** handles pluralization across languages with dramatically different rules — English has 2 forms, Polish has 4, Arabic has 6. The critical mistake is using `=1` instead of `one`: some locales treat 11, 21, 31 as matching the `one` category. The `other` category must always be present as a fallback. Libraries include `@formatjs/intl` (React), `vue-i18n v10`, `@messageformat/core`, and i18next with the ICU module.

For **CI enforcement**, `@lingual/i18n-check` validates translation file completeness across JSON and YAML, checking for missing keys, invalid types, unused keys, and undefined keys. **Tongues** (Go-based) offers a GitHub Action with auto-fix mode that adds `"TODO: Translate"` placeholders and commits changes. A comprehensive CI pipeline runs 4 parallel jobs: ESLint i18n linting, translation completeness checking, pseudo-localization visual regression, and RTL visual regression testing.

**RTL testing automation** uses Playwright projects configured with `locale: 'ar-EG'` and explicit `dir="rtl"` attribute setting, capturing screenshots for comparison against LTR baselines. CSS logical properties (`margin-inline-start` instead of `margin-left`) enable automatic RTL adaptation — Atlassian's `no-physical-properties` ESLint rule enforces this at the linting level.

---

## Conclusion: what a comprehensive SKILL.md must contain

The research reveals a clear architecture for total UI/UX enforcement. A complete AI coding agent SKILL.md must combine aesthetic rules (taste-skill's anti-slop patterns, Anthropic's distinctiveness mandate), engineering compliance (Vercel's 100+ checkable rules), and automated gates (ESLint, Stylelint, axe-core, visual regression, i18n checking).

The most impactful patterns that emerged are not the obvious ones. **Minimum loading-state duration** (Vercel's 150–300ms show-delay to prevent flicker) is rarely implemented but dramatically improves perceived quality. **Pseudo-localization** catches more i18n bugs per engineering hour than any other technique. The **"Reward Early, Punish Late"** validation timing pattern resolves a decades-long UX debate with a simple heuristic. **Layout match level** visual testing (Applitools) solves the non-determinism problem of AI-generated UI by testing structure rather than content.

The missing piece across all existing skills is **journey completeness** — ensuring every feature is not just well-designed in isolation but reachable, testable, and measurable in context. No current SKILL.md integrates analytics enforcement (GitLab's pattern), dead feature detection (Uber's Piranha), rage click monitoring, and funnel tracking into the agent's generation rules. The next generation of AI coding agent skills will need to enforce not just "does this component handle all states" but "can a user actually discover and complete this feature end-to-end."