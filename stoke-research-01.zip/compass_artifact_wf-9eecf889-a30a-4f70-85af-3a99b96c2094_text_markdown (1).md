# Claude Code JSON output reliability for CI/CD pipelines

**Claude Code's JSON output is unreliable by default for automated pipelines, but a combination of the `--json-schema` flag, file-based output strategies, and careful configuration can bring failure rates below 2%.** The single biggest risk is output truncation — caused by a CLI buffering bug that silently cuts JSON at fixed character boundaries (4K–16K chars) and a 32K-token output cap that interacts badly with extended thinking. At least 19 distinct failure modes have been reported on GitHub, with truncation, Unicode corruption, and stdout contamination being the most frequent. The good news: Claude Code now ships a `--json-schema` flag with constrained decoding, and the Agent SDK offers guaranteed schema compliance — but both require deliberate configuration that isn't the default.

---

## Ranked failure modes: truncation dominates

The following failure modes are ranked by frequency of GitHub reports, community mentions, and severity of impact on CI/CD pipelines.

**Tier 1 — Critical, frequently reported:**

1. **CLI JSON truncation at fixed character positions.** When responses exceed ~4K–16K characters, the SDK's readline interface in `sdk.mjs` splits stdout writes at buffer boundaries (4000, 6000, 8000, 10000, 12000, 16000 chars), producing `SyntaxError: Unterminated string in JSON`. This affects the `@anthropic-ai/claude-code` SDK and any CLI consumer. Reported in issue #2904 with 12+ upvotes. *Mitigation: Use file-based output or the Agent SDK; keep stdout JSON under 4K characters.*

2. **32K output token cap ignoring environment overrides.** Claude Code enforces a **32,768-token output ceiling** per turn regardless of `CLAUDE_CODE_MAX_OUTPUT_TOKENS` settings. Critically, when extended thinking is enabled, `MAX_THINKING_TOKENS` defaults to **31,999**, leaving only ~769 tokens for actual output — virtually guaranteeing truncation. Seven separate issues filed (#29488, #24159, #24055, #12319, #6158, #10738, #10041). *Mitigation: Set `export MAX_THINKING_TOKENS=4000` to recover ~28K tokens for output. For Bedrock users, the cap may be as low as 4,096 tokens.*

3. **Invalid Unicode surrogates breaking JSON serialization.** Tool outputs containing binary data or orphaned Unicode surrogates cause API 400 errors: `"no low surrogate in string"`. Six separate issues filed across all platforms (#1939, #2066, #4519, #5440, #6297, #15027). *Mitigation: Sanitize tool inputs; avoid processing binary files in agentic sessions.*

**Tier 2 — High impact, moderately reported:**

4. **Sandbox debug messages corrupting stdout JSON stream.** On Linux, `[SandboxDebug]` messages leak to stdout even with `--debug-to-stderr`, producing `SyntaxError: Unexpected token 'S'` (issue #12007). *Mitigation: Parse JSON defensively; filter non-JSON lines before parsing.*

5. **Empty or missing result field in stream-json mode.** The final `subtype: success` message sometimes has an empty `result` field, or the result event never arrives, causing processes to hang indefinitely (issues #8126, #7124, #1920). *Mitigation: Implement timeouts; parse intermediate `type=message` events as fallback.*

6. **CLI process hangs after emitting result event.** The process never exits after sending the final result in stream-json mode (issue #25629). *Mitigation: Kill the process with a timeout after receiving the result event: `setTimeout(() => process.kill(pid, 'SIGKILL'), 30000)`.*

**Tier 3 — Medium impact, intermittent:**

7. **`--json-schema` not populating `structured_output` on Vertex AI** (issue #18536). The result JSON lacks the expected field; output is returned as markdown inside `result` instead.

8. **`error_during_execution` with no debugging information** — ~10% of headless runs end with this subtype despite apparent success (issue #6116). Community estimates put overall silent failure rate at **~8% of CI/CD executions**.

9. **Concurrent session corruption** of `.claude.json` due to non-atomic file writes (issues #28847, #28813). Fixed in v2.1.61 with atomic writes, but older versions are vulnerable.

10. **Markdown code fences wrapping JSON in hook responses** (issue #22750), and markdown links in commit messages breaking JSONL serialization in claude-code-action (issue #753, marked P1).

---

## The `--output-format json` flag: what it actually produces

The `--output-format json` flag wraps Claude's response in a metadata envelope. The schema is:

```json
{
  "type": "result",
  "subtype": "success",
  "result": "The agent's text response here",
  "structured_output": { ... },
  "session_id": "session-uuid",
  "total_cost_usd": 0.042,
  "duration_ms": 3200,
  "num_turns": 1,
  "is_error": false,
  "usage": { "input_tokens": 4, "output_tokens": 85 }
}
```

**The `result` field is only present when `subtype` is `"success"`.** On `error_max_turns`, `error_max_budget_usd`, `error_during_execution`, or `error_max_structured_output_retries`, the field is absent — there is no partial output. The official documentation states: *"The result field is only present on the success variant, so always check the subtype before reading it."*

When combined with `--json-schema`, a `structured_output` field contains validated JSON conforming to the provided schema. This uses constrained decoding at the token generation level, meaning the model is grammatically prevented from emitting non-conforming tokens. However, if `stop_reason` is `max_tokens`, the output **may still not match the schema** because generation was interrupted.

Three output formats exist: `text` (default), `json` (single metadata object), and `stream-json` (newline-delimited JSON with real-time events). For CI/CD, `json` is recommended over `stream-json` due to the latter's multiple known failure modes (missing results, process hangs, stdout contamination).

---

## Output token limits create a hard ceiling on JSON size

The underlying API models support generous output limits — **Claude Sonnet 4/4.5/4.6 supports 64K output tokens, and Claude Opus 4.6 supports 128K** — but Claude Code imposes its own constraints:

| Layer | Limit | Notes |
|-------|-------|-------|
| Claude Code default per turn | **32,768 tokens** | Hard cap regardless of env var settings |
| With extended thinking (default) | **~769 tokens for output** | `MAX_THINKING_TOKENS` defaults to 31,999 out of 32K budget |
| With `MAX_THINKING_TOKENS=4000` | **~28,768 tokens for output** | Recommended setting |
| Bedrock deployments | **4,096 tokens** (some configs) | Dramatically lower |
| MCP tool outputs | **25,000 tokens** hard max | Per individual tool call |

A typical JSON finding block with full descriptions runs **50–100 tokens per finding**. At ~28K available output tokens (with thinking tuned down), you can fit roughly **280–560 findings** — more than enough for most QA audits. But the default configuration with extended thinking leaves room for only **7–15 findings** before truncation occurs. This makes `MAX_THINKING_TOKENS` configuration the single most impactful reliability lever.

When truncation occurs, the API returns `stop_reason: "max_tokens"`. In the Claude Code JSON envelope, this means the `result` field contains a truncated string that may be invalid JSON if Claude was mid-generation. **There is no automatic retry or repair — the truncated output is returned as-is.**

---

## Structured output: the `--json-schema` flag and Agent SDK

Claude Code now supports two mechanisms for schema-enforced JSON output, both using constrained decoding:

**CLI: `--json-schema` flag** (shipped, documented at code.claude.com/docs/en/headless). This accepts inline JSON schema or a file path and returns validated output in `structured_output`:

```bash
claude -p "Audit this codebase for security issues" \
  --output-format json \
  --json-schema '{"type":"object","properties":{"findings":{"type":"array","items":{"type":"object","properties":{"severity":{"type":"string","enum":["critical","high","medium","low"]},"description":{"type":"string"}},"required":["severity","description"]}}},"required":["findings"]}' \
  | jq '.structured_output'
```

**Agent SDK: `outputFormat` option** (TypeScript and Python). The SDK wraps schema validation with automatic retries. If the model fails to produce valid output after multiple attempts, it returns `subtype: "error_max_structured_output_retries"` rather than invalid JSON. This is the most reliable path:

```typescript
for await (const message of query({
  prompt: 'Run QA audit on this project',
  options: {
    outputFormat: { type: 'json_schema', schema: auditSchema }
  }
})) {
  if (message.type === 'result' && message.structured_output) {
    // Guaranteed to match schema if subtype is "success"
  }
}
```

Schema complexity limits apply: maximum **20 strict tools per request**, **24 optional parameters** across all schemas, and a **180-second grammar compilation timeout**. Keep schemas focused and avoid deeply nested optional structures.

**The legacy "result tool pattern"** (defining a fake tool with your desired schema and forcing it via `tool_choice`) still works at the API level but is unnecessary with native structured outputs. It's less reliable because it doesn't use constrained decoding.

---

## File-based output bypasses the truncation bug entirely

The CLI's JSON truncation at buffer boundaries is specific to **stdout piping** — it does not affect files written by Claude Code's Write/Edit tools. One user confirmed in issue #14694: *"If I ask Claude to write the response to a .md file then it shows all of the text — but it does not all appear in the reply within my terminal."*

**Recommended file-based pattern for CI/CD:**

```bash
claude -p "Analyze this codebase. Write your complete findings as valid JSON to /tmp/audit-results.json. The JSON must contain a 'findings' array and a 'verdict' field." \
  --allowedTools 'Read,Write,Bash(cat:*)' \
  --output-format json \
  --max-turns 10 \
  --dangerously-skip-permissions

# Validate and use the file output (not stdout)
if jq empty /tmp/audit-results.json 2>/dev/null; then
  cat /tmp/audit-results.json
else
  echo "Invalid JSON in output file" && exit 1
fi
```

**Tradeoffs of file-based output:**

- Files written via the **Write/Edit tools** are tracked by Claude Code's checkpoint system and survive tool-call-level failures. Files written via **Bash commands** (`echo > file`) are not checkpointed.
- If a session crashes *during* a Write tool call, the file may be partially written. If the Write tool completes but the session crashes afterward, the file persists intact.
- File-based output is less composable with Unix pipes but more reliable for large payloads.
- Combining file-based output with `--output-format json` gives you both the metadata envelope (session_id, cost, usage) and the full JSON payload in the file.

---

## When `max_turns` is reached, there is no partial output

If an agent building toward a JSON response hits the `max_turns` limit, Claude Code returns:

```json
{
  "type": "result",
  "subtype": "error_max_turns",
  "is_error": false,
  "num_turns": 3,
  "session_id": "session-uuid",
  "total_cost_usd": 0.057
}
```

**The `result` field is absent** — not empty, not partial, but missing entirely. The same applies to `error_max_budget_usd`. This means if your agent needs multiple tool calls to gather data before emitting JSON, and it runs out of turns, you get nothing. Note that `max_turns` counts **tool-use turns only** — a final text-only response doesn't count.

*Mitigation: Set `max_turns` generously for complex tasks (10–20). Use `session_id` to resume interrupted sessions: `claude -p "Continue and output the JSON" --resume <session_id>`. For the file-based strategy, partial files from completed Write tool calls persist even if the session hits turn limits afterward.*

---

## Recommended architecture for a CI/CD QA-audit pipeline

Based on all findings, here is the recommended architecture ranked by reliability:

**Tier 1 — Highest reliability (use for production):**

Use the **Agent SDK with structured outputs** (`outputFormat: { type: 'json_schema', schema }`) wrapped in a thin orchestrator. This gives you constrained decoding, automatic retries on schema validation failure, typed error handling (`CLIJSONDecodeError`), and the `structured_output` field with guaranteed schema compliance when `subtype` is `"success"`. Combine with `MAX_THINKING_TOKENS=4000` and generous `max_turns`.

**Tier 2 — Good reliability (simpler to implement):**

Use the **CLI with `--json-schema` plus file-based output** as a defense-in-depth strategy. Instruct the agent to write JSON to a file *and* use `--json-schema` for the stdout envelope. Validate both. Set `--timeout 600000` for complex tasks. Always check `subtype` before reading `result` or `structured_output`.

**Tier 3 — Acceptable with guardrails:**

Use the **CLI with `--output-format json`** and prompt engineering alone. Keep JSON payloads under **4,000 characters** to stay below truncation boundaries. Use explicit JSON schemas in the prompt. Implement retry loops with `jq` validation. Accept ~8% failure rate and handle it with retries.

**Configuration checklist for any tier:**

- `export MAX_THINKING_TOKENS=4000` — prevents thinking from consuming output budget
- `--max-turns 15` — generous but bounded for complex audits
- `--max-budget-usd 2.0` — cost guardrail
- `--allowedTools 'Read,Write,Grep,Glob,Bash(cat:*,jq:*)'` — minimal permissions
- `--timeout 600000` — 10 minutes for complex tasks
- Always validate exit code *and* JSON content (exit 0 does not guarantee valid output)
- Always check `subtype` before accessing `result` or `structured_output`
- Quote all `-p` prompts (35% of CI/CD support tickets stem from unquoted prompts)
- Never run concurrent Claude Code instances sharing the same working directory

**Prompt engineering pattern for maximizing JSON completeness:**

```
You are a QA audit agent. After completing your analysis, you MUST output your findings as valid JSON.

CRITICAL RULES:
1. Write your complete JSON findings to the file /tmp/qa-results.json using the Write tool
2. Keep each finding description under 100 words to stay within output limits
3. If you have many findings, prioritize by severity and include the top 25

Required JSON schema:
{
  "verdict": "pass" | "fail" | "warn",
  "findings": [{"id": string, "severity": "critical"|"high"|"medium"|"low", "description": string, "file": string, "line": number}],
  "summary": string
}
```

This prompt pattern combines file-based output (for reliability), explicit schema definition (for format compliance), size guidance (to avoid truncation), and prioritization instructions (to handle large codebases within token limits). Pair this with the `--json-schema` flag for the stdout envelope as a second validation layer.

## Conclusion

The core insight is that **Claude Code's default configuration is actively hostile to large JSON output** — extended thinking consumes 97.6% of the output budget, and the CLI has a known buffer-splitting bug that corrupts stdout JSON at predictable character boundaries. These aren't edge cases; they're the default behavior. The path to reliability requires three deliberate interventions: tuning `MAX_THINKING_TOKENS` down from 31,999 to ~4,000, using either the `--json-schema` flag or Agent SDK for constrained decoding, and directing large JSON payloads to files rather than stdout. With all three, the failure mode shifts from "silent truncation" to "explicit error with retry opportunity" — a fundamentally different risk profile for a CI/CD pipeline. The Agent SDK's structured output path with automatic schema validation retries is the strongest option available today, converting what would be a parsing failure into a typed `error_max_structured_output_retries` that your pipeline can handle gracefully.