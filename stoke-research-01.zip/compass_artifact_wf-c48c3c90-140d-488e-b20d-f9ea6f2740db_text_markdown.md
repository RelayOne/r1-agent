# Microservice communication patterns for Cloud Run, Workers, Go, and TypeScript

**You need an API gateway but not a service mesh.** For a stack spanning GCP Cloud Run and Cloudflare Workers with Go and TypeScript services communicating via REST, gRPC, GraphQL, and Kafka, a traditional service mesh is architecturally misaligned — Cloud Run is serverless (no sidecars), Workers run V8 isolates on Cloudflare's edge (completely outside any mesh's reach), and no single mesh can span both platforms. Instead, a two-tier API gateway architecture — Cloudflare at the edge for security/routing, a lightweight Go gateway on Cloud Run for internal orchestration — combined with application-level resilience patterns and OpenTelemetry for observability delivers roughly 80% of mesh value at 10% of the complexity. What follows is a decision framework across all ten architectural dimensions, grounded in 2025-2026 production patterns.

---

## 1. Sync, async, and everything in between

The foundational decision in microservice communication is choosing between temporal coupling (caller waits for response) and temporal decoupling (caller fires and moves on). Neither is universally superior — the right choice depends on three axes: **coupling tolerance**, **latency requirements**, and **failure handling needs**.

**Direct gRPC** is the default for internal service-to-service calls where the caller needs an immediate response. It delivers **3–7x throughput over REST** with ~40% less CPU, binary protobuf serialization compresses payloads dramatically (62 bytes JSON → 9 bytes protobuf), and strong typing via .proto files catches integration errors at compile time. Use gRPC for payment validation, user authentication, inventory checks — anything on the synchronous critical path. On Cloud Run, deploy with `--use-http2` and run h2c (HTTP/2 cleartext) servers since Cloud Run terminates TLS at the edge. **Cloudflare Workers cannot run gRPC** natively (no HTTP/2 server support in the V8 runtime), so the Workers-to-Cloud-Run boundary must use REST or the Connect protocol.

**REST/HTTP** remains correct for public-facing APIs (maximum client compatibility), simple CRUD where performance isn't critical, and communication from Workers to other services. Keep REST for your external contract; use gRPC behind the gateway.

**Kafka events** are the right choice when multiple services must react to the same state change, you need an audit trail or event replay, or temporal decoupling is essential. **Kafka 4.0** (released March 2025) removed ZooKeeper entirely — KRaft is the exclusive metadata manager, and the new KIP-848 consumer group protocol delivers dramatically faster rebalances with incremental partition assignment. For Go, use `segmentio/kafka-go` or `confluent-kafka-go`; KafkaJS maintenance has slowed on the TypeScript side, so evaluate `@confluentinc/kafka-javascript`. A critical gotcha: **don't run Kafka consumers as Cloud Run services that scale to zero** — consumer rebalancing on scale-up is slow. Run consumers on GKE or dedicated compute, or use Cloud Pub/Sub push subscriptions to Cloud Run instead.

**Google Cloud Tasks vs Cloud Pub/Sub** maps to a clean distinction: Cloud Tasks means *explicit invocation* (you specify the target, control dispatch rate, schedule future work), while Pub/Sub means *implicit invocation* (fan-out to subscribers the publisher doesn't know about). Use Cloud Tasks for sending emails, processing images, and rate-limited dispatch. Use Pub/Sub for event broadcasting.

**NATS JetStream** deserves consideration for sub-millisecond latency messaging at moderate scale. It's a single **17MB Go binary** with no external dependencies, delivering 200K–400K messages/sec with persistence. The operational simplicity versus Kafka is substantial, but the ecosystem is thinner and client libraries are less battle-tested.

The decision framework distills to five questions: Does the caller need an immediate response? → Sync (gRPC or REST). Is this internal service-to-service? → Prefer gRPC. Do multiple services need to react? → Kafka or Pub/Sub events. Does the sender control dispatch rate/timing? → Cloud Tasks. Is operational simplicity paramount at moderate scale? → NATS JetStream.

---

## 2. A two-tier API gateway is the right architecture

For the Cloud Run + Cloudflare Workers stack, the optimal gateway architecture uses **two tiers**: Cloudflare handles edge concerns (DDoS protection, JWT validation, schema validation, rate limiting) while a lightweight gateway on Cloud Run handles internal routing, API composition, and service orchestration.

**Cloudflare API Gateway** (part of API Shield) provides ML-powered API discovery, OpenAPI schema validation, built-in JWT validation at the edge, per-endpoint rate limiting, mTLS, and anomaly detection — all running on 330+ global edge locations. It integrates deeply with Workers, which can serve as both BFF logic and request transformation layers. The limitation is that it's **Enterprise-only for full features** and focused on security rather than full API management (no API composition or complex routing logic built in). Use it as the security perimeter, not the sole gateway.

**For the internal gateway tier**, a custom Go gateway on Cloud Run is the best fit for this stack. The core pattern — middleware chain wrapping `httputil.ReverseProxy` — is approximately 200 lines of code and gives you full control over routing, auth augmentation, request composition, and observability. Use **chi** or **Echo** for the router, Redis with Lua scripts for distributed rate limiting (sliding window counter algorithm is the best default: low memory, near-exact accuracy, no boundary bursts), and standard middleware ordering: Tracing → Auth → Rate Limiting → Logging → Metrics → Reverse Proxy.

Among off-the-shelf gateways, the comparison for this stack is clear:

**Kong Gateway** (v3.9, June 2025) delivers the highest raw throughput (~170K+ QPS at 16 connections) with 70+ plugins, but its most valuable features (OIDC, advanced analytics, GUI) are Enterprise-only, route propagation is slow (~3 seconds), and it requires PostgreSQL tuning in traditional mode. **Envoy Gateway** (v1.7, GA since March 2024) is the top choice for Kubernetes-native deployments — it includes OIDC, rate limiting, and JWT validation all in the OSS tier, with millisecond route propagation — but it requires GKE, making it a poor fit for Cloud Run. **Traefik** (v3.2) offers the simplest operations as a single Go binary with auto-discovery, but its distributed rate limiting and OIDC are gated behind the commercial Hub product. 

For GCP-native options, **Cloud Armor** (WAF + DDoS at Google's network edge) should complement any gateway by sitting in front of the Global External Application Load Balancer. Apigee is overkill unless you're monetizing APIs as products. The simpler GCP API Gateway works for basic serverless APIs but lacks native rate limiting and CORS handling.

The production recommendation: Cloudflare API Shield and Workers (Tier 1, edge) → Cloud Run custom Go gateway or direct routing to services (Tier 2, origin) → Cloud Armor behind Global LB for additional WAF. This avoids the operational overhead of managing gateway clusters while leveraging both platforms' strengths.

---

## 3. Why a service mesh doesn't fit this stack

**A traditional service mesh is not justified** for Cloud Run + Cloudflare Workers. The reasoning is structural, not about scale.

Cloud Run is serverless — there's no Kubernetes cluster to attach sidecar proxies to. GCP's **Cloud Service Mesh integration with Cloud Run is Pre-GA** as of early 2026, with limited support and a critical limitation: mTLS between GKE and Cloud Run workloads is not automatic in Preview mode. Cloudflare Workers are V8 isolates on Cloudflare's edge network — completely outside any mesh's reach. No sidecar, no ztunnel, no eBPF is possible. Since your architecture spans two platforms, no single mesh can cover it.

That said, understanding the mesh landscape matters for future decisions. **Istio 1.29** (March 2026) has matured significantly with Ambient Mesh now stable since v1.24. The sidecar-less architecture splits the data plane into a Rust-based **ztunnel** (per-node, ~0.06 vCPU and ~12MB for L3/L4 mTLS) and optional **waypoint proxies** (Envoy-based, for L7 features), achieving up to **70% CPU/memory savings** versus the sidecar model. **Linkerd** moved stable releases behind a paywall in February 2024 (free for organizations under 50 employees; paid per-cluster for larger ones) — its Rust micro-proxy still leads performance benchmarks at **163ms faster than Istio sidecar at p99** and 11.2ms faster than Ambient at 2000 RPS, but the licensing change creates operational risk for open-source-first teams. **Cilium** graduated CNCF in October 2023 and is collapsing the CNI/mesh distinction with eBPF-native L3/L4 processing in kernel space — if GKE Dataplane V2 already uses Cilium as your CNI, you may not need a separate mesh at all.

The expert consensus on when mesh is justified: **under 5 services, never; 5–15 services, evaluate case-by-case; 20+ services across multiple teams, clear value**. Regulatory pressure (PCI-DSS, SOC2) where mTLS everywhere is a compliance checkbox tilts the calculus. But **60% of KubeCon 2024 attendees** cited complexity as preventing adoption (up from 25% in 2021), and industry sentiment has shifted firmly from "you must have a mesh" to "most teams don't need one."

For your stack, the 80% alternative looks like: **Cloud Run's built-in TLS + GCP IAM with OIDC identity tokens** for service identity and mTLS equivalent; **OpenTelemetry** for distributed tracing and metrics; **Cloud Run native traffic splitting** for canary deployments; **application-level resilience** (gobreaker, cockatiel) for retries and circuit breaking; and **GCP Cloud Load Balancing** for L7 traffic management.

---

## 4. gRPC in production: ConnectRPC is the modern default

**ConnectRPC from Buf has effectively replaced gRPC-Web** and is the recommended approach for new projects in 2025-2026, especially when browser clients are involved. Connect supports three wire protocols simultaneously — its own Connect protocol (HTTP/1.1 compatible, curl-able, uses standard JSON), gRPC, and gRPC-Web — from a single server. **Buf internally replaced grpc-web with connect-es entirely**, achieving an 80% bundle size reduction.

For the proto management pipeline, **Buf CLI is the industry standard**, replacing `protoc` for most workflows. `buf lint` enforces style rules, `buf breaking` detects breaking changes in CI against git branches, `buf generate` replaces complex protoc invocations with YAML config, and the **Buf Schema Registry (BSR)** provides dependency management, auto-generated documentation, and generated SDKs consumable via `go get` and `npm install`. Proto file organization should follow the 1-1-1 rule (one service per file) with package versioning (`company.product.v1`). Never reuse field numbers — use `reserved` for removed fields.

For code generation, the recommended stack is:
- **Go**: `protoc-gen-connect-go` for ConnectRPC handlers/clients (stable, ~5,800+ known importers), or `protoc-gen-go-grpc` for traditional gRPC
- **TypeScript**: `@connectrpc/connect` with `@connectrpc/connect-node` (server) and `@connectrpc/connect-web` (browser) — the modern standard. **ts-proto + nice-grpc** remains viable for teams committed to the traditional gRPC stack (ts-proto v2.x was recently rewritten).

**gRPC load balancing** is the most common production footgun. HTTP/2 multiplexes many requests over a single persistent connection, so L4 (TCP) load balancers distribute *connections*, not *requests* — one backend gets thousands of RPCs while others sit idle. Solutions: Envoy as L7 proxy (de facto standard), client-side load balancing with Kubernetes headless services (`grpc.WithDefaultServiceConfig('{"loadBalancingPolicy":"round_robin"}')`), or proxyless gRPC with xDS protocol. **Cloud Run handles this correctly** — its managed load balancer maintains separate connections between clients and instances, counting each stream as one concurrent request.

**Deadline propagation** is non-negotiable: gRPC does not set a deadline by default, meaning calls can wait forever. Always use `context.WithTimeout` in Go, propagate the context to downstream calls, and reserve processing buffer time. Dropbox enforces deadlines in every service definition and credits it with eliminating many reliability issues. On Cloud Run, the platform's request timeout (default 5 minutes, max 60 minutes) is the backstop, but explicit deadlines should be far shorter.

For streaming patterns, all four types (unary, server, client, bidirectional) work on Cloud Run, but streams are pinned to a single backend for their lifetime and cannot be load-balanced once started. Set `MaxConnectionAge` and `MaxConnectionAgeGrace` on servers to force periodic reconnection for better load distribution. Keepalive pings are essential — Cloud Run's load balancer can close idle connections.

---

## 5. Service discovery across two platforms requires pragmatism

No native cross-platform discovery mechanism spans Cloud Run and Cloudflare Workers. The pragmatic approach uses **environment variable injection** with service URLs and platform-native mechanisms for intra-platform communication.

**Cloud Run service discovery** relies on permanent `*.run.app` URLs with project-specific hashes, retrievable via `gcloud run services describe SERVICE --format='value(status.url)'`. For internal traffic, set ingress to `internal` and route through VPC using **Direct VPC egress** (GA in 2025) — this avoids the latency and cost of the legacy Serverless VPC Access connector. Service-to-service authentication uses **IAM identity tokens**: the metadata server at `http://metadata.google.internal` provides JWTs that Cloud Run validates automatically. The unofficial `runsd` tool by Ahmet Alp Balkan provides drop-in DNS service discovery for Cloud Run (resolve services as `http://SERVICE_NAME`), but it remains unofficial.

**Cloudflare Workers Service Bindings** are the primary mechanism for worker-to-worker communication — they allow one Worker to call another **without going through a public URL**, with near-zero latency and no network overhead. The recommended mode is **RPC** (extend `WorkerEntrypoint`, expose public methods, call via `await env.BINDING_NAME.myMethod(arg1)`) rather than HTTP-style `fetch()`. Critically, service bindings use a **shared compute thread** model — Cloudflare charges a single billable duration across the call chain, unlike AWS Lambda's per-instance billing. Target Workers can have their public routes disabled, making them accessible only via bindings.

For **cross-platform communication** (Workers calling Cloud Run or vice versa), the patterns are: Workers call Cloud Run via authenticated HTTPS URLs using `fetch()`; Cloud Run calls Workers via their `*.workers.dev` URLs or custom domains; or use the Cloudflare Workers edge gateway to route requests to Cloud Run backends. Store service URLs in environment variables (Cloud Run's `--set-env-vars` and Workers' `wrangler.toml [vars]`), with Secret Manager integration for sensitive values.

---

## 6. Distributed tracing with OpenTelemetry is now mature enough

**OpenTelemetry's Go and TypeScript SDKs reached production stability in 2025**, with traces and metrics stable (v1) and logs approaching stability. The major development for Cloudflare Workers is **automatic tracing** (open beta): Cloudflare instruments every I/O operation at the `workerd` runtime level — fetch calls, KV reads, R2 operations, Durable Object invocations — following OpenTelemetry standards with OTLP-compliant trace export, requiring zero code changes. Configure with `observability.traces.enabled = true` in wrangler config.

**W3C Trace Context** (`traceparent` and `tracestate` headers) is the default propagation format. For trace context across transports: HTTP uses the standard `traceparent` header; gRPC propagates through metadata (use `otelgrpc` interceptors in Go, `@opentelemetry/instrumentation-grpc` in Node.js); and Kafka uses message headers — OpenTelemetry injects `traceparent` into Kafka message headers on the producer side and extracts on the consumer side, creating linked producer and consumer spans. The async nature of Kafka means consumer spans are children of producer spans with a time gap (message queue dwell time), which is expected behavior.

The **TypeScript OTel SDK 2.0** shipped March 2025 with significant breaking changes focused on optimization (better tree-shaking, cleaner API, dropped Node.js 14/16). The Go SDK's 2025 roadmap priorities include logs API stabilization, file-based YAML configuration, and SDK self-observability metrics. The OTel Collector is expected to reach **v1.0 stable** in 2025.

For tracing backends, **Grafana Tempo** is the strongest choice for cost-conscious teams (object storage backend, no indexing maintenance, TraceQL for structural queries) and integrates naturally into the LGTM stack. **Google Cloud Trace** is the path of least resistance for Cloud Run (native integration, automatic export). **Honeycomb** offers the best developer experience with AI-powered analysis but is SaaS-only. Red Hat deprecated Jaeger on OpenShift in favor of Tempo in 2025 — a strong signal of Tempo's trajectory.

**Sampling strategy**: Use head-based sampling (`TraceIdRatioBased` with `ParentBased`) for most services — it's simple, deterministic, and consistent across the call chain. Deploy tail-based sampling in the OTel Collector for critical paths where you must capture all errors and slow requests regardless of sample rate. Tail-based requires buffering full traces in memory (allocate ≥4GB RAM to Collector nodes).

---

## 7. Circuit breakers: gobreaker for Go, cockatiel for TypeScript

The circuit breaker is a state machine with three states: **closed** (requests flow normally, failures counted), **open** (requests immediately rejected, downstream service recovers), and **half-open** (limited probe requests test recovery). The key production consideration is choosing between consecutive failure counting (trip after N failures — simpler) and sampling/sliding window (trip when failure rate exceeds threshold — more nuanced).

**sony/gobreaker** is the production standard for Go, now with generic type parameters in v2:

```go
cb := gobreaker.NewCircuitBreaker[[]byte](gobreaker.Settings{
    Name:        "payment-api",
    MaxRequests: 5,              // max probes in half-open
    Interval:    30 * time.Second,
    Timeout:     60 * time.Second,
    ReadyToTrip: func(counts gobreaker.Counts) bool {
        return counts.ConsecutiveFailures > 3
    },
})
```

Key v2 features: `IsExcluded` for ignoring context cancellations, `BucketPeriod` for rolling windows, and `OnStateChange` callbacks for alerting. For gradual recovery instead of binary open/closed, **schigh/circuit** offers probabilistic throttling with exponential, sigmoid, or linear+jitter estimation functions.

**cockatiel** is the recommended TypeScript library, inspired by .NET Polly, with composable policies:

```typescript
const breaker = circuitBreaker(handleAll, {
    halfOpenAfter: 10_000,
    breaker: new SamplingBreaker({ threshold: 0.2, duration: 30_000 }),
});
const resilient = wrap(retry(handleAll, { maxAttempts: 3 }), breaker);
```

cockatiel's `wrap()` function composes retry, circuit breaker, timeout, bulkhead, and fallback policies declaratively. **opossum** (Red Hat-supported, 70K+ weekly npm downloads) is the alternative with richer event handling and Prometheus integration via `opossum-prometheus`.

**Production gotchas**: Place the circuit breaker *outside* retries (`wrap(retryPolicy, breakerPolicy)`) so retries happen inside the breaker — otherwise retry amplification (3 retries × 3 service layers = 27 downstream requests) defeats the breaker's purpose. Address thundering herd on half-open with **jittered cooldowns** (30s ± 5s random variation) and `MaxRequests` limiting concurrent probes. Use per-endpoint breakers rather than per-service when services mix critical and non-critical methods. Alert on every state transition via OpenTelemetry or Prometheus.

---

## 8. Bulkheads and connection pool isolation

The bulkhead pattern isolates failure domains so that a slow or failing dependency cannot exhaust shared resources and cascade to healthy paths. Without bulkheads, a slow payment service can consume all goroutines/connection slots in a shared pool, starving inventory and shipping calls.

In **Go**, the idiomatic implementation uses buffered channels as semaphores with context-aware timeouts:

```go
type Bulkhead struct {
    sem     chan struct{}
    timeout time.Duration
}
func (b *Bulkhead) Execute(ctx context.Context, fn func() error) error {
    select {
    case b.sem <- struct{}{}:
        defer func() { <-b.sem }()
        return fn()
    case <-ctx.Done():
        return ErrBulkheadFull
    }
}
```

The critical companion pattern is **separate HTTP clients per dependency**, each with independent `http.Transport` settings (`MaxIdleConns`, `MaxIdleConnsPerHost`). This provides double isolation: the bulkhead limits goroutines waiting, and separate connection pools prevent interference. For sizing, start at **~2x expected peak concurrent requests** per dependency and tune from there.

In **TypeScript/Node.js**, cockatiel provides a bulkhead policy (`bulkhead(5, 10)` for 5 concurrent execution slots and 10 queue slots), and separate `http.Agent` instances with independent `maxSockets` per dependency achieve connection pool isolation. Since Node.js is single-threaded, bulkheads primarily limit concurrent async operations; use `worker_threads` for CPU-bound isolation.

Combine bulkheads with circuit breakers for defense-in-depth: **check the circuit breaker first** (fail fast if open), then apply the bulkhead (limit concurrency if closed). Monitor bulkhead rejection counts — a rising rejection rate means the bulkhead is doing its job.

---

## 9. Anti-corruption layers protect your domain model

The anti-corruption layer (ACL) from Domain-Driven Design prevents external models — third-party APIs, legacy systems, other bounded contexts — from corrupting your internal domain. It comprises three components: a **facade** (simplified interface exposing only what your domain needs), an **adapter** (protocol-level concerns like HTTP clients, retry logic, auth), and a **translator/mapper** (converts between external and internal models).

In **Go**, implicit interface satisfaction makes the ACL pattern elegant. Define a port interface in your domain package (`UserRepository`), implement it in an adapter package that wraps the external client, and use a translator to map external DTOs to domain objects. The adapter satisfies the interface without importing the domain package, keeping coupling minimal.

In **TypeScript**, **Zod at boundaries** is a 2025 best practice: define a Zod schema for the external API response, parse incoming data through it at the ACL boundary (`LegacyUserSchema.parse(response.data)`), and let `z.infer<>` generate compile-time types from the runtime schema. This catches schema drift immediately when an external API changes — the Zod parse throws before corrupted data reaches your domain.

**Contract testing with Pact** validates ACLs in CI/CD. Consumer tests define expected interactions, generating Pact contract files published to a broker. Providers verify against contracts, and the `can-i-deploy` gate prevents incompatible deployments. **Bi-directional testing** (PactFlow, 2025) simplifies this — providers publish their OpenAPI spec, and PactFlow compares it against consumer pacts automatically.

Place ACLs as **libraries within the consuming service** for domain-level translation (lower latency, simpler deployment) and as **dedicated microservices** for protocol bridging shared by many consumers. Keep business logic out of the ACL — it should only translate and map.

---

## 10. Choreography for simple flows, orchestration for complex sagas

The consensus in 2025 is unambiguous: use **event-driven choreography for simple 1–2 step reactions** (user registered → send welcome email) and **centralized orchestration for complex multi-step workflows** (order processing with payment, inventory reservation, shipping, and compensating refunds on failure).

**Temporal.io** is the dominant orchestration platform, raised a **$300M Series D at $5B valuation**, and handles **150,000+ actions/second** in production for OpenAI, NVIDIA, Block, and ADP. Temporal's programming model uses deterministic Workflow functions (the process definition) and Activity functions (side-effecting operations), with the server recording a complete Event History that enables replay on any Worker after crashes. The TypeScript and Go SDKs are both production-stable. **Run Temporal Workers as Cloud Run services** connecting to Temporal Cloud — workers can scale to zero, and you avoid hosting the server yourself. The #1 learning curve challenge is **determinism**: never use `Date.now()`, `Math.random()`, or make API calls directly in Workflow code.

**Restate** (created by the Apache Flink team, built in Rust) is the lightweight alternative gaining traction — positioned on ThoughtWorks Technology Radar as "Assess." It eliminates the separate server cluster: a single binary acts as a message broker with durable execution. The programming model is simpler — no strict Workflow/Activity separation, just `ctx.run()` for durable steps. It supports Kafka integration natively and works well with serverless.

**Inngest** is purpose-built for serverless environments like Cloud Run and Cloudflare Workers — functions are triggered via events over HTTPS with zero infrastructure to manage. Its step function model (`step.run()`) creates durable steps with automatic retry. This is the best fit for **Cloudflare Workers workflows** specifically, since it calls functions via HTTP rather than requiring persistent connections.

For debugging choreographed workflows (where you don't have Temporal's built-in visibility): assign correlation IDs at the start and propagate through all events via W3C Trace Context headers, use Kafka as an event store for replay, deploy OpenTelemetry distributed tracing across the chain, and consider process mining tools like Camunda Optimize for reconstructing business process flows from event logs.

---

## Concrete recommendations for your stack

The architectural decisions crystallize into a clear set of choices for Cloud Run + Cloudflare Workers with Go and TypeScript:

- **Communication**: gRPC (via ConnectRPC) for Go-to-Go internal calls on Cloud Run. REST for Workers-to-Cloud-Run and public APIs. Kafka for event streaming with replay needs. Cloud Pub/Sub for simple event fan-out. Cloud Tasks for rate-limited task dispatch.
- **API Gateway**: Cloudflare API Shield + Workers at the edge, custom Go gateway or direct routing on Cloud Run, Cloud Armor for WAF.
- **Service Mesh**: Skip it. Use platform-native auth (GCP IAM + Cloudflare Access), OpenTelemetry for observability, and application-level resilience.
- **Proto management**: Buf CLI + BSR for schema management, ConnectRPC for code generation and server/client libraries.
- **Service discovery**: Environment variables with service URLs for cross-platform. Service Bindings (RPC mode) for Worker-to-Worker. GCP IAM identity tokens for Cloud Run-to-Cloud Run.
- **Tracing**: OpenTelemetry SDKs in Go and TypeScript. Cloudflare automatic tracing for Workers. Grafana Tempo or Google Cloud Trace as backend. W3C Trace Context propagation across HTTP, gRPC metadata, and Kafka headers.
- **Resilience**: sony/gobreaker + channel-based bulkheads in Go. cockatiel (circuit breaker + bulkhead + retry composition) in TypeScript. Separate HTTP clients per dependency on both sides.
- **Workflow orchestration**: Temporal Cloud for complex sagas (Workers on Cloud Run). Inngest for serverless-native orchestration on Cloudflare Workers. Event choreography via Kafka/Pub/Sub for simple reactions.
- **Anti-corruption layers**: Go interfaces with struct mappers. Zod validation at TypeScript boundaries. Pact contract tests in CI/CD.

This architecture scales from a handful of services to dozens without requiring a platform migration, keeps operational complexity proportional to actual needs, and leverages each platform's native strengths rather than fighting them with infrastructure abstractions designed for different environments.