# Building information-dense UIs that actually perform

**The highest-quality data-heavy products — Airtable, Linear, Stripe, Notion — share a remarkably consistent set of implementation patterns.** They use DOM-based row virtualization (not canvas), fixed row heights with density presets, `position: sticky` for frozen columns with dynamic box-shadows, and independent scroll containers for Kanban columns. This report details the specific visual treatments, CSS values, and architectural decisions that make these interfaces feel fast at 10,000+ rows, 50+ dashboard widgets, and 100+ cards per Kanban column. Every specification below comes from product teardowns, engineering blog posts, design system documentation, and library APIs.

---

## Virtualized tables: how Airtable, Notion, and Linear handle 10,000+ rows

### Scroll performance and virtualization strategy

All three products use **DOM-based windowing** — only visible rows plus a small buffer exist in the DOM at any time. None use canvas rendering (Google Sheets does, but that requires reimplementing text selection, accessibility, and input handling from scratch).

**Airtable** uses row and column virtualization with native browser scrollbars. The scrollbar thumb shrinks to reflect total dataset size — scrolling through 50,000 records produces a tiny thumb. Total record count appears in a **persistent footer summary bar** at the bottom of the grid, not as "Showing X of Y" inline. When filters are active, the footer shows filtered count vs. total. Airtable's hard limit is 50,000 records per base on Pro plans, and performance degrades notably with grouping, formula fields referencing `NOW()`/`TODAY()`, and complex rollups.

**Notion** treats every database row as a page and every cell as a block, creating a heavier data footprint. To compensate, Notion deployed **SQLite via WebAssembly** for client-side caching in browsers, yielding a **20% improvement in page navigation times** (50% on desktop). Their architecture relies on WebSocket-based real-time sync backed by Postgres across 480 logical shards. Notion's own documentation advises minimizing visible properties and avoiding complex sorts on formula/rollup columns for databases exceeding 1,000 items.

**Linear** takes the most radical approach: it **syncs the entire workspace to IndexedDB on the client**, then runs all queries locally. This achieves sub-100ms response times for most operations — benchmarked at **3.7× faster than Jira** and **2.3× faster than Asana**. The tradeoff is acknowledged scaling pressure on larger workspaces, which Linear has been addressing with architectural changes since 2021.

A detailed case study from Basedash illustrates the production path: they started with `react-window`, switched to **TanStack Virtual** (`@tanstack/react-virtual`) for full control over HTML structure (essential for sticky columns and resize handles), and abandoned native `<table>` elements for `<div>`-based layouts. Their critical performance fix was **stopping direct `style` prop passing to cell components** — wrapping cells in a positioned `<div>` container instead, which prevented re-renders on every scroll tick and delivered a **4–5× improvement** in load time.

### Inline editing: click-to-edit vs. always-editable

Airtable uses a **two-step activation model**. Single-click selects a cell (highlighted with a **blue border outline**); double-click or typing enters edit mode. The row itself never changes height — Airtable enforces **four fixed row height presets** (Short, Medium, Tall, Extra Tall). Long text overflows within the cell boundary during edit. Pressing `Space` opens a full expanded record modal for complex editing (rich text, attachments, comments).

Notion takes the opposite approach: cells are **immediately editable on click** with no separate selection state. Clicking a select property instantly opens the dropdown picker; clicking a date opens the calendar. Tab moves between cells, Return moves down. Every row is a full page — hovering reveals an "Open" button for a side-panel peek preview, and `⤡` goes full-page. Notion also provides a **fill handle** (blue circle at cell bottom-right, drag to copy values) and multi-row batch editing via checkbox selection.

The Cloudscape Design System (AWS) documents a third pattern worth noting: cells show an **edit icon on hover**, clicking transforms the value into an input with explicit **dismiss (✗) and confirm (✓)** buttons, and a temporary success icon appears after saving.

### Column type rendering: pills, dates, checkboxes, relations, avatars

**Select/multi-select tags** render as colored pill elements in both Airtable and Notion. Airtable's color palette uses named tokens like `blueLight2`, `cyanLight2`, `tealLight2` (with light and dark variants) and supports up to **10,000 options** per multi-select field. Pills truncate with `text-overflow: ellipsis` when they exceed cell width; at Tall/Extra Tall row heights, multiple pills wrap to additional lines. Notion's tags support conditional coloring that can apply to entire rows or individual cells, with inline editing offering search, drag-handle reordering, color picker, and delete.

**Dates** display as absolute formatted strings ("Jan 15, 2025") in both products. Notion's date picker adds end-date range toggle, time toggle, reminder settings, and timezone. Neither product shows relative dates ("3 days ago") inline in table view.

**Checkboxes** are directly togglable in both products — single click toggles without entering edit mode. The click target is the checkbox itself, typically rendered at **16–20px**.

**Relation links** differ significantly. Airtable renders linked records as **gray pills** (not colored — a longstanding user complaint), showing the primary field value. Notion renders relations as clickable page references inline. In Airtable's Interface Designer, linked records can alternatively render as "Card" format.

**User avatars** appear as **circular thumbnails** (~20–24px at short row height) in Airtable, stacking horizontally for multiple collaborators. Notion shows user names/avatars inline with an @-mention picker.

### Filtering at scale: what happens with 5+ active conditions

Airtable opens filters as a **floating dropdown panel** from the toolbar (not a sidebar). Conditions connect with **AND/OR conjunctions** — click the conjunction text to toggle. The system supports up to **three levels of nested condition groups** (group → subgroup → sub-subgroup), which is essential for complex queries. Each condition has a six-dot drag handle for reordering. The Filter toolbar button shows a **count badge** (e.g., "Filter (3)"), and filtered column headers receive a subtle background color change. When many conditions exist, the panel scrolls vertically.

Across the industry, analysis of 19+ SaaS products reveals a clear scaling pattern: **chip/pill filter bars work for ≤5 filters** but become cluttered beyond that. Products handling complex filtering graduate to structured panels with nesting (Airtable), collapsible sidebar panels (Stripe), or advanced query builder interfaces.

### Grouped rows: collapsible headers with count badges

Airtable's "Group by" creates **full-width header rows** spanning all columns, displaying the grouped field value (with the matching select option color for select fields), a **record count in parentheses** (e.g., "In Progress (12)"), and a **chevron toggle** (▶/▼) for collapse/expand. Subgroups are visually indented from parent groups. Right-click offers "Collapse all," and Interface Designer supports "Collapse groups by default." Summary calculations (count, sum, avg, min, max) appear in the footer bar. AG Grid (v29.3+) adds **sticky group rows** — the group header stays visible while scrolling through its children, a pattern not yet common in most products.

### Horizontal scroll: the frozen column boundary

Airtable's **primary field (first column) is always frozen** and cannot be unfrozen. Additional columns freeze by dragging a **thick blue vertical separator bar** that appears on hover. Only contiguous leftmost columns can be frozen.

The CSS implementation is remarkably consistent across the industry. `position: sticky` with `left: 0` handles the pinning, with a mandatory **opaque background** to prevent content showing through. Z-index layering follows a strict order: regular cells at `auto`, sticky column cells at `z-index: 1`, sticky header row at `z-index: 2`, and the corner intersection cell at `z-index: 3`.

MUI X DataGrid Pro offers three separator visual modes: `"border"` (simple line), `"shadow"` (appears only during horizontal scroll), and `"border-and-shadow"` (default combining both). The dynamic shadow — only appearing when content scrolls behind frozen columns — is the most polished production pattern.

---

## Dashboard design: metric cards, grids, and real-time indicators

### Metric card anatomy across Stripe, Databox, Geckoboard, and HubSpot

The information hierarchy within metric cards is consistent across all four products, following a strict top-to-bottom visual weight order:

1. **Label** — smallest text at **12–14px**, `font-weight: 500`, muted color (`#6B7280`), positioned at top for context
2. **Hero number** — dominant element at **28–36px** (Stripe uses ~32px), `font-weight: 600–700`, primary text color
3. **Trend delta** — **12–14px** with directional arrow (▲/▼), green `#10B981` for positive / red `#EF4444` for negative, plus comparison period label in muted gray
4. **Sparkline** (optional) — inline area chart, typically **60–120px wide × 24–40px tall**

Stripe's dashboard runs on React + TypeScript with a fully tokenized design system supporting light, dark, and "darker" modes. Their real-time analytics are powered by Apache Pinot with updates processing in under one minute. Databox calls widgets "Datablocks" with 20+ visualization types, where font auto-scales when resizing widgets. Geckoboard optimizes for TV display — their Number widget focuses on large primary numbers with optional goal comparison and RAG (Red/Amber/Green) status indicators.

For chart tooltip interactions, **Recharts** (the dominant React charting library) renders tooltips as floating HTML elements (not SVG). The default cursor renders a vertical crosshair line for line charts and a rectangle highlight for bar charts. Tooltip positioning uses an `offset` prop (~5px default) with collision detection via `TooltipBoundingBox`. The `shared={true}` prop shows data for all series at a given x-coordinate — the standard for multi-series charts. A common pattern for active-bar highlighting dims non-hovered bars to `rgba(136,132,216,0.3)` while keeping the focused bar at full opacity.

### Grid systems: react-grid-layout dominates

**react-grid-layout** (1.8M+ weekly npm downloads) powers Grafana, Metabase, Kibana, Monday.com, and AWS CloudFront dashboards. Its default configuration uses a **12-column grid** with **30px row height**, **10px margins** (horizontal and vertical), and **20px container padding**. A layout item is defined as `{ i: 'widget-id', x: 0, y: 0, w: 4, h: 3, minW: 2, maxW: 12 }`.

Common widget sizes in grid units:

- Small metric card: **3×2** (quarter-width)
- Medium chart: **6×4** (half-width)
- Large chart: **12×6** (full-width)
- Wide table: **12×4** or **12×8**

Drag activation requires **3px of movement** (preventing accidental drags on click). Resize handles default to the bottom-right corner (`'se'`), supporting all eight compass positions. The library uses CSS transforms for smooth drag animation.

**gridstack.js** offers an alternative with 60px default cell height, 20px vertical margins, and CSS variable-based column widths (`width: (100% / columns) × widgetWidth`). A notable feature is `staticGrid: true`, which adds a `.grid-stack-static` CSS class disabling all interaction — the cleanest view/edit mode toggle.

Rubrik's dashboard case study documents **36 size combinations** (9 widths × 4 heights) per widget type, with data-responsive behavior across four common screen resolutions — at small widget sizes, infographics take priority over legends.

### Data freshness: timestamps, pulses, and skeletons

The established pattern uses four visual states:

- **Live/real-time**: **8px green dot** (`background: #10B981`) with a CSS pulse animation (`animation: pulse 2s infinite`) plus "Live" label. Stripe's billing analytics updates in under one minute using this pattern.
- **Recent/fresh**: No special indicator — this is the default, implicit state
- **Stale/warning**: Amber indicator, timestamp text turns amber, optional "Data may be outdated" banner
- **Error/unavailable**: Red indicator with "Unable to refresh" message and retry button

Timestamps typically appear in card footers using relative format for frequently updating data ("2 min ago") and absolute format for daily/batch refreshes ("Data as of Mar 7, 2026"). Value change animations use **200–400ms smooth transitions** for KPI number updates, **300–600ms** for chart trend animations, and **100–150ms** for control feedback. Loading skeletons during refresh use a shimmer gradient: `background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%)` with `animation: shimmer 1.5s infinite`.

### Edit mode vs. view mode: what changes visually

Entering edit mode triggers a consistent set of visual changes across dashboard products. Widgets gain **dashed borders** (`border: 2px dashed #94A3B8`), visible **drag handles** (six-dot grip icon `⋮⋮` at top of each widget), and **resize handles** (10×10px squares at corners, typically bottom-right). The actively dragged widget gets an elevated shadow (`box-shadow: 0 12px 28px rgba(0,0,0,0.2)`) and slight opacity reduction (`opacity: 0.9`). Drop target placeholders render as dashed-outline rectangles with a tinted fill (`background: #3B82F6; opacity: 0.15`).

Rubrik's implementation replaces the standard masthead with a narrower edit-mode toolbar (Save, Exit, Undo/Redo, Restore to Default) to maximize canvas area. Their widget library opens as a **tray from the left edge** on cursor hover, collapsing automatically when a widget is dragged out. gridstack.js provides the cleanest toggle: `grid.setStatic(false)` enables editing, `grid.setStatic(true)` locks the view, with `alwaysShowResizeHandle: true` for touch-friendly edit mode.

---

## Kanban at scale: columns, cards, and drag performance with 100+ items

### Handling 100+ cards per column

**Linear** uses **independent per-column vertical scroll** — each column is a separate scroll container, with the board itself scrolling horizontally via `Shift + scroll`, trackpad gesture, or click-and-drag on empty space. Column headers are sticky ("The grouping header will remain sticky as you scroll down"). Card count or total estimate appears beside each column header, toggleable between the two. For very long columns, Linear provides keyboard shortcuts (`Option/Alt + Shift + Up/Down`) to move items to top/bottom without dragging through hundreds of cards.

**Asana** similarly scrolls columns independently, shows task count next to column names, and allows users to choose which custom fields display on board cards. Asana lacks formal swimlane support and density modes — compact card display has been a popular community feature request.

For production implementations requiring true virtualization within Kanban columns, **Syncfusion's Kanban** provides `enableVirtualization={true}` with a `cardHeight` property for fixed-height calculation, rendering only visible cards plus buffer. **react-kanban-kit** (built on Atlassian's pragmatic-drag-and-drop) enables virtualization by default and includes `loadMore` callbacks triggered when scroll position nears the column bottom (`scrollTop + clientHeight >= scrollHeight - 100`).

### Card density: compact, comfortable, and detailed

Linear controls card information density through toggleable **display properties** rather than named density modes. Available properties include issue ID, priority icon, status icon, labels (colored pills), project, cycle, dates, assignee avatar, estimate, link count, and time-in-status. Descriptions are never shown on cards — users press `Space` while hovering to peek at details.

Across major products, card heights cluster into three tiers:

| Density | Height | Content |
|---------|--------|---------|
| **Compact** | 48–64px | Title only, or title + priority icon + assignee avatar on one line |
| **Comfortable** | 80–120px | Title (1–2 lines) + assignee + priority + 1–2 labels + due date |
| **Detailed** | 140–200px | Title + description preview + assignee + labels + due date + estimate + project |

Labels render as colored pills at `border-radius: 4px` (compact) or `9999px` (fully rounded), **height 20–24px**, **font-size 11–12px**. When labels overflow, a "+N" indicator shows the count of hidden labels. Linear uses an **LCH (Lightness, Chroma, Hue) color space** for label colors, ensuring perceptual uniformity across light and dark themes.

### Swimlanes: sub-grouping with sticky headers

Linear implements swimlanes through its **sub-grouping** feature in Display Options. Available sub-grouping dimensions include teams, cycles, assignee, priority, label, project health, and SLA status. Swimlane headers remain **sticky during vertical scroll** (stacking below column headers), and lanes can be collapsed/expanded with the `T` keyboard shortcut. Dragging issues between swimlanes automatically adopts the target lane's properties.

Jira offers the most flexible swimlane configuration: Stories (parent per lane), JQL queries (custom filter per lane), Assignees, Epics, or Projects. Swimlane headers show issue counts, can be individually collapsed, and hide automatically when empty. Critically, Jira prevents dragging between swimlanes when the lane criteria would require changing issue properties — items move between columns (status) within a lane, but not between lanes.

### Visual cues: how products signal overdue, blocked, and stale

**Overdue items** consistently use **red** across products — red text on dates, red badges, clock or warning-triangle icons. The common pattern places the visual cue directly adjacent to the due date field on the card.

**Blocked items** use more varied treatment. Azure DevOps applies **orange card background** for blocked tasks and **dark red background** for blocked bugs, driven by a boolean "Blocked" field toggleable directly on the board. Common patterns include a red/orange left border stripe on the card, a "Blocked" tag rendered as a colored pill, or a stop-sign icon.

**Stale/idle items** have no standardized built-in treatment in any major product. Linear's "time in status" display property is the closest — teams typically implement staleness through custom views filtered by "Updated > X days ago" or by applying gray/faded opacity to untouched items.

Linear's priority system uses five distinct icons: **Urgent** (orange-red filled icon), **High** (orange), **Medium** (yellow-amber), **Low** (blue-gray), and **No Priority** (muted gray). Their SLA indicators use a fire/flame icon that transitions through **gray → yellow → orange → red** as deadlines approach, with notifications sent 24 hours before breach. Jira recently redesigned priority icons to use **distinct geometric shapes** (not just colors) for accessibility — each level is distinguishable in grayscale.

### Column scroll with 50+ cards: sticky headers and scroll shadows

The production pattern uses `position: sticky; top: 0` on column headers with an opaque background and `z-index: 10`. The column body gets `overflow-y: auto` with `max-height: calc(100vh - var(--header-height) - var(--toolbar-height))`.

Four scroll shadow techniques exist in production:

- **CSS scroll-driven animations** (Chrome 115+): bind `box-shadow` to `animation-timeline: scroll(self block)`, creating shadows that grow proportionally to scroll position
- **IntersectionObserver pattern** (cross-browser): a sentinel `<div>` at the column top triggers a `.scrolled` class on the header when it leaves the viewport, adding `box-shadow: 0 2px 4px rgba(0,0,0,0.1)`
- **Pure CSS cover technique** (Lea Verou): a shadow is always present, hidden by a `position: sticky` cover element that slides away on scroll
- **Pseudo-element with JS class**: a `::after` on the sticky header with `background: linear-gradient(to bottom, rgba(0,0,0,0.1), transparent)` and `opacity` toggled by scroll state

### Drag-and-drop libraries: performance at scale

**@hello-pangea/dnd** (~1.7M weekly downloads, the maintained fork of react-beautiful-dnd) integrates with virtual lists out of the box and recommends virtualization at 500+ items. **dnd-kit** is lighter and more flexible but requires manual virtualization integration. **Atlassian's pragmatic-drag-and-drop** uses the native HTML Drag and Drop API with a modular architecture — the smallest bundle size and best raw performance, explicitly designed for virtualized lists ("Create any virtual experience you want!").

Performance at scale diverges sharply: react-beautiful-dnd hits "severe performance issues" at 1,000+ items (documented in GitHub issue #667), while @hello-pangea/dnd and pragmatic-drag-and-drop handle 1,000+ items smoothly when paired with virtualization.

---

## Synthesis: concrete CSS rules and implementation techniques

### Table row heights and typography

Use Carbon Design System's battle-tested row height scale — these values work across products and should never grow dynamically mid-table:

```css
/* Row density presets — pick one per view, never mix */
--row-height-xs: 24px;   /* Maximum density */
--row-height-sm: 32px;   /* Dense data tables */
--row-height-md: 40px;   /* Default balanced */
--row-height-lg: 48px;   /* Comfortable reading */
--row-height-xl: 64px;   /* Two-line content rows */
```

Typography for data tables should use **14px body text** at `font-weight: 400` and **14px column headers** at `font-weight: 600`. Cell padding is **16px** left and right. Always apply `font-variant-numeric: tabular-nums` (or `font-feature-settings: "lnum", "tnum"`) to any column containing numbers — this ensures decimal alignment across rows. Right-align numeric columns; left-align text; never center-align data columns. Use **Inter**, **SF Pro**, or **Roboto** — all have excellent tabular figures.

```css
.data-table {
  font-variant-numeric: lining-nums tabular-nums;
  font-family: 'Inter', system-ui, sans-serif;
  line-height: 1.4;
  border-collapse: separate;
  border-spacing: 0;
}
.data-table th {
  font-size: 14px;
  font-weight: 600;
  padding: 0 16px;
  text-align: left;
}
.data-table td {
  font-size: 14px;
  font-weight: 400;
  padding: 0 16px;
}
.data-table td.numeric {
  text-align: right;
  font-variant-numeric: tabular-nums;
}
```

### Virtualization performance CSS

```css
/* Position rows with transform, never top/left */
.virtual-row {
  position: absolute;
  width: 100%;
  transform: translateY(var(--row-offset));
  contain: layout style paint;
}

/* content-visibility for off-screen sections (not individual virtualized rows) */
.off-screen-section {
  content-visibility: auto;
  contain-intrinsic-size: auto 500px;
}
```

Apply `will-change: transform` **only during active scroll** via a JS class toggle — permanent application causes GPU memory bloat ("layer explosion"). Disable `pointer-events` during scroll for dramatic FPS improvement:

```js
let scrollTimer;
container.addEventListener('scroll', () => {
  document.body.classList.add('is-scrolling');
  clearTimeout(scrollTimer);
  scrollTimer = setTimeout(() => {
    document.body.classList.remove('is-scrolling');
  }, 150);
}, { passive: true });
```

```css
body.is-scrolling * { pointer-events: none; }
```

Recommended overscan values: **1 row** for react-window (start low, increment only if blank flashes appear), **10 rows** for AG Grid and react-virtualized. TanStack Virtual's overscan works in item counts; start at 3–5.

### Fixed column shadow and sticky positioning

```css
/* Frozen column boundary — dynamic shadow appears only during scroll */
.sticky-col-last {
  position: sticky;
  left: var(--frozen-width);
  z-index: 1;
  background: var(--surface);
}
.sticky-col-last::after {
  content: '';
  position: absolute;
  top: 0;
  right: -8px;
  width: 8px;
  height: 100%;
  background: linear-gradient(to right, rgba(0,0,0,0.08), transparent);
  opacity: 0;
  transition: opacity 0.15s;
  pointer-events: none;
}
.table-container.is-scrolled-x .sticky-col-last::after {
  opacity: 1;
}

/* Z-index stacking — never deviate from this order */
/* Regular cells:           z-index: auto */
/* Sticky column cells:     z-index: 1    */
/* Sticky header row:       z-index: 2    */
/* Corner (header+column):  z-index: 3    */

/* Use box-shadow instead of border on sticky elements */
thead th {
  box-shadow: inset 0 -1px 0 var(--border-color);
}
```

### Status color tokens

```css
:root {
  /* Error / Overdue */
  --status-error:    #DC2626;  /* red-600, text/icons */
  --status-error-bg: #FEF2F2;  /* red-50, backgrounds */

  /* Warning / At risk */
  --status-warning:    #D97706;  /* amber-600 */
  --status-warning-bg: #FFFBEB;  /* amber-50 */

  /* Success / On track */
  --status-success:    #16A34A;  /* green-600 */
  --status-success-bg: #F0FDF4;  /* green-50 */

  /* Info / In progress */
  --status-info:    #2563EB;  /* blue-600 */
  --status-info-bg: #EFF6FF;  /* blue-50 */

  /* Blocked / Paused */
  --status-blocked:    #9333EA;  /* purple-600 */
  --status-blocked-bg: #FAF5FF;  /* purple-50 */

  /* Neutral / Backlog */
  --status-neutral:    #4B5563;  /* gray-600 */
  --status-neutral-bg: #F9FAFB;  /* gray-50 */
}
```

Use dark shades (600–900) for text on light backgrounds; light shades (50–200) for pill/badge backgrounds. Minimum **4.5:1** contrast ratio for normal text (WCAG AA). Never rely solely on color — always pair with an icon or text label.

### Dashboard metric card and grid rules

```css
.metric-card .hero-number {
  font-size: 32px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
  line-height: 1.2;
  color: var(--text-primary);
}
.metric-card .label {
  font-size: 12px;
  font-weight: 400;
  color: var(--text-secondary);
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
.metric-card .delta {
  font-size: 14px;
  font-weight: 500;
}
.metric-card .delta.positive { color: var(--status-success); }
.metric-card .delta.negative { color: var(--status-error); }

/* Dashboard grid — 12-column, 30px row height, 10px gutters */
/* react-grid-layout defaults work well for most dashboards */
.dashboard-grid {
  --grid-cols: 12;
  --row-height: 30px;
  --grid-gap: 10px;
  --container-padding: 20px;
}

/* Minimum widget sizes: 280px wide, 200px tall for charts */
/* Sparklines in cards: 60–120px wide × 24–40px tall */
```

### Kanban column and card dimensions

```css
.board {
  display: flex;
  gap: 12px;
  overflow-x: auto;
  height: calc(100vh - var(--top-offset));
  padding: 16px;
}
.column {
  flex: 0 0 280px;       /* 260–320px range */
  min-width: 260px;
  max-width: 320px;
  display: flex;
  flex-direction: column;
  background: var(--surface-secondary);
  border-radius: 8px;
  padding: 12px;
}
.column-header {
  position: sticky;
  top: 0;
  z-index: 2;
  background: var(--surface-secondary);
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding-bottom: 12px;
}
.column-body {
  flex: 1;
  overflow-y: auto;
  padding: 0 0 8px;
}
.card {
  padding: 10px 12px;
  margin-bottom: 8px;
  border-radius: 6px;
  background: var(--surface);
  border: 1px solid var(--border-subtle);
  box-shadow: 0 1px 3px rgba(0,0,0,0.08);
  cursor: grab;
  transition: box-shadow 150ms ease, border-color 150ms ease;
}
.card:hover {
  box-shadow: 0 4px 8px rgba(0,0,0,0.12);
  border-color: var(--border-hover);
}
.card.dragging {
  opacity: 0.4;
  cursor: grabbing;
}
.drop-placeholder {
  border: 2px dashed #CBD5E1;
  border-radius: 6px;
  background: #F1F5F9;
}
```

## Conclusion: the patterns that actually matter

Three architectural decisions define whether a data-dense UI feels fast or sluggish. First, **fixed row/card heights eliminate layout thrashing** — Airtable's four presets, Carbon's five-tier scale, and Linear's toggleable property approach all enforce this constraint. Products that allow dynamic row expansion during editing (like early Notion database views) pay a measurable performance penalty.

Second, **the virtualization library choice matters less than how you use it**. TanStack Virtual, react-window, and react-virtuoso all perform well — the critical detail is avoiding style-prop re-renders on cells and using `transform: translateY()` instead of `top` for GPU-accelerated positioning. The Basedash case study's 4–5× improvement came from a single architectural fix, not a library swap.

Third, **visual density is a product decision, not a CSS problem**. The best products (Linear, Airtable) give users explicit density controls while enforcing strict internal constraints — fixed heights, truncation with overflow indicators, and progressive disclosure via expand/peek interactions. The worst data-dense UIs try to show everything at once. The best ones show the minimum needed for scanning and provide fast paths to detail.

For drag-and-drop at scale, Atlassian's pragmatic-drag-and-drop is the strongest choice for new projects — smallest bundle, native API performance, and explicit virtualization support. For dashboard grids, react-grid-layout's 12-column default with 30px row height and 10px gutters is production-proven at Grafana, Metabase, and Kibana scale. For tables, TanStack Virtual paired with TanStack Table gives the most control, but requires abandoning native `<table>` elements and building custom focus management — a non-trivial investment that every production implementation eventually makes.