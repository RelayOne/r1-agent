# Semantic deduplication of SAST findings: a four-stage local pipeline

**No major SAST tool performs root-cause clustering today—every tool from Semgrep to CodeQL treats each finding as independent.** The gap is real, and filling it locally requires a layered strategy: cheap deterministic heuristics first, embeddings for semantic matching, and an optional LLM pass for genuinely ambiguous cases. A four-stage pipeline (exact hash → heuristic rules → embedding clustering → LLM confirmation) can eliminate **90–95% of root-cause duplicates** while running entirely offline. The research below consolidates findings from tool internals, academic literature, and production dedup systems to specify exact algorithms, thresholds, and tradeoffs.

## No SAST tool clusters by root cause

Every major tool—Semgrep, CodeQL, SonarQube, Snyk, and GitHub Code Scanning—treats deduplication as an *identity tracking* problem (recognizing the same finding across successive scans), not a *root-cause clustering* problem (grouping findings that share an underlying fix). Understanding how they fingerprint reveals what your pipeline must build on top of.

**Semgrep** uses a `match_based_id` fingerprint hashing `(file_path, rule_id, pattern_with_metavariable_values)` plus an index suffix for multiple matches. Because it hashes the abstracted pattern rather than raw matched code, it survives line shifts when code is added around the match. But two taint sinks from the same source produce two separate fingerprints—no clustering.

**CodeQL** generates a `primaryLocationLineHash` by hashing the whitespace-normalized content of the flagged line. When the same taint source flows to 5 sinks, CodeQL reports 5 independent alerts. Its result-grouping feature only collapses results at the *same location* with the *same message template*—not related findings at different locations.

**SonarQube** uses a three-tier matching algorithm: (1) same rule + same line-content hash, (2) same rule + same line number + same message, (3) same rule with block-movement detection. This is the most sophisticated *tracking* system, including file-rename detection, but still treats each rule violation as independent.

**Snyk Code** stands out with an AST min-hash fingerprint combined with file-position similarity scoring and confidence weighting. This handles code refactoring across files better than any competitor. But each unique data-flow path remains a separate vulnerability.

**GitHub Code Scanning** deduplicates SARIF results using `ruleId + filepath + partialFingerprints.primaryLocationLineHash`. Cross-tool dedup does not exist—different SARIF categories (one per tool) are tracked independently. The fingerprinting algorithm from `github/codeql-action/src/fingerprints.ts` is open source and straightforward to replicate locally.

The takeaway: your pipeline must build root-cause clustering as a new layer on top of the per-finding fingerprints these tools already provide.

## Academic research validates embedding-based clustering

The academic literature strongly supports the approach of embedding-based similarity for grouping static analysis findings, with several directly relevant results.

**Schneider et al. (2022)** is the single most relevant paper. In "Semantic Similarity-Based Clustering of Findings From Security Testing Tools" (ICNLSP 2022), the authors scanned OWASP JuiceShop with 7 SAST and 2 DAST tools, created human-annotated duplicate clusters, and compared SBERT, LSI, and WordNet similarity. **SBERT significantly outperformed both alternatives**, with best F1 at cosine similarity thresholds between **0.65–0.80**. This directly validates the embedding-clustering approach for your use case.

**Lee et al. (VMCAI 2012, extended in TOPLAS)** developed *sound* non-statistical clustering using defect-model dependencies: if a "dominant" alarm in a cluster is false, all dependent alarms are guaranteed false too. This is the theoretically ideal approach but requires access to the analyzer's internal abstract state—not feasible when consuming SARIF output from external tools.

**Kremenek & Engler's Z-Ranking (SAS 2003, FSE 2004)** pioneered grouping related error reports and using within-group statistics to rank them. Their correlation exploitation paper at FSE 2004 showed that when multiple reports share a common cause, if one is confirmed true, related ones are also likely true. This supports using rule_id grouping as a high-confidence clustering signal.

**GPTrace (ICSE 2026)** used LLM embeddings with HDBSCAN clustering to deduplicate crash reports by root cause, outperforming all prior methods (TraceSim, ReBucket) on 341,952 inputs across 61 ground-truth labels. This validates the embedding + HDBSCAN pipeline specifically for security-adjacent dedup.

Other relevant work includes Hanam et al. (MSR 2014) on code-pattern feature vectors for alert classification, SAST-Genius (2025) achieving **89.5% precision** with fine-tuned Llama 3 for SAST triage, and the NASCAR dataset (Nature Scientific Data, 2025) providing 224,000+ labeled static analysis warnings for training. The Muske & Serebrenik survey (ACM CSUR 2022) catalogs 130 studies on alarm postprocessing across six approach categories, confirming that clustering, ranking, and pruning are complementary techniques best used in combination.

## The four-stage pipeline: exact → heuristic → embedding → LLM

The optimal architecture is a funnel where each stage is progressively more expensive but catches progressively subtler duplicates. No single technique achieves satisfactory performance alone—this is confirmed by both Schneider et al.'s academic findings and production systems like DefectDojo and Aikido Security.

### Stage 1: Exact-hash dedup (milliseconds, eliminates ~40–50%)

Compute a canonical hash excluding line numbers:

```python
dedup_key = sha256(normalize(rule_id) + "|" + normalize(file_path) + "|" + normalize(cwe))
```

**Deliberately omit line numbers.** DefectDojo's documentation is explicit about this: including line numbers makes tracking "very weak" because adding code above a vulnerability shifts its line number, creating a false "new" finding. Match on `(rule_id, file_path, CWE, severity)`. This single step, running in O(n) time, eliminates the majority of trivially identical findings—same rule firing on the same file at slightly different offsets.

For cross-scan tracking (separate from root-cause clustering), store Semgrep's `match_based_id` or compute a `primaryLocationLineHash` using GitHub's open-source algorithm as a secondary fingerprint.

### Stage 2: Heuristic rule-based clustering (milliseconds, eliminates ~25–35% more)

Apply these rules in priority order to the remaining findings. Each rule has been validated in production systems:

**Rule R1 — Same rule, same file (confidence ~90%):** When the same SAST rule triggers multiple times in one file, cluster all matches. This catches the "weak JWT secret defined on line 15 and used insecurely on line 87" pattern directly. DefectDojo configures this as the default for most scanners.

**Rule R2 — Same source variable and same sink function (confidence ~98%):** If two findings reference the same source expression (e.g., `request.params["id"]`) and the same sink function (e.g., `db.execute()`), they almost certainly share a root cause regardless of which lines or even files they appear in. Parse source/sink from SARIF `codeFlows` when available. This is the highest-precision heuristic at **>95% accuracy** but depends on structured tool output.

**Rule R3 — Same CWE + same file + description Jaccard ≥ 0.7 (confidence ~80%):** Compute Jaccard similarity on word sets from finding descriptions after stripping boilerplate remediation text. The **0.7 threshold** is well-supported: SourcererCC uses it as default for code clone detection, and multiple duplicate-detection benchmarks converge on this range. Use the overlap coefficient (`|A∩B| / min(|A|, |B|)`) at **≥0.8** as an alternative when descriptions vary significantly in length.

**Rule R4 — Code snippet token similarity ≥ 0.8 (confidence ~85%):** Normalize variable names and literals in the flagged code snippets, tokenize, and compute Jaccard similarity. This catches the "same SQL injection pattern repeated across 5 controllers" case when the code structure is identical but variable names differ.

**Rule R5 — Cross-file same pattern (confidence ~75%, flag for review):** Same rule category + Levenshtein ratio ≥ 0.85 on normalized code snippets across different files. Flag rather than auto-merge, since different files may represent genuinely independent issues requiring separate fixes.

Use **CWE as a blocking key** (only compare findings within the same CWE group) rather than as a similarity signal. CWE is too coarse for clustering—grouping everything under CWE-20 (Improper Input Validation) would merge XSS with SQL injection—but it's an excellent way to reduce the O(n²) comparison space.

### Stage 3: Embedding similarity clustering (seconds, catches ~10–15% more)

For findings that survive heuristic dedup, compute dense vector embeddings and cluster.

**Model choice: BGE-small-en-v1.5** is the recommended primary model. At **~130MB on disk** and **33M parameters**, it achieves an **MTEB score of 62.17**—significantly outperforming all-MiniLM-L6-v2's ~56 while remaining in the same size and speed class. It produces 384-dimensional embeddings and runs comfortably on CPU at ~40–100 sentences/second single-threaded. If speed is the overriding constraint (>10,000 findings per run), drop down to **all-MiniLM-L6-v2** at ~80MB and ~22M parameters, which was trained on Stack Exchange data including security Q&A and handles domain vocabulary well.

**Do not use CodeBERT or GraphCodeBERT** for this task. They are masked language models producing token-level embeddings, not sentence embeddings optimized via contrastive learning. Mean-pooling their outputs produces substantially worse similarity scores than purpose-built sentence transformers. They are 5× larger and 5× slower on CPU for inferior results on natural-language finding descriptions.

**TF-IDF is useful only as a complement**, not a replacement. It fails entirely on semantic equivalence ("SQL injection" vs. "unsanitized database query" → zero similarity) and suffers from short-text sparsity with 50–200 word descriptions. A weighted combination works well:

```python
final_sim = 0.8 * cosine_sim(bge_embed_a, bge_embed_b) + 0.2 * tfidf_cosine_sim(a, b)
```

The TF-IDF term captures exact CWE identifiers and tool-specific vocabulary that neural models may underweight.

**Clustering algorithm: HDBSCAN** with `min_cluster_size=2` and `metric='cosine'`. HDBSCAN does not require specifying the number of clusters a priori, handles variable-density clusters (some vulnerability types generate many findings, others few), and explicitly identifies noise points that don't belong to any cluster. It is now built into scikit-learn ≥1.3. Optional: apply UMAP dimensionality reduction (384→15–30 dims) before clustering for speed on large finding sets.

**Threshold guidance from Schneider et al.:** Auto-cluster at cosine similarity **≥0.85**. Flag as candidates at **≥0.70**. Above 0.85, false positives are rare (~5%); below 0.65, false merges become unacceptable. Start at 0.80 and tune based on a few manual reviews.

**Embedding input format:** Concatenate structured fields for maximum signal:
```python
text = f"{finding.rule_id}: {finding.title}. {finding.description}. File: {finding.file_path}. Code: {finding.code_snippet[:200]}"
```

### Stage 4: LLM confirmation for ambiguous pairs (seconds per batch, ~5% of findings)

For candidate pairs in the **0.70–0.85 cosine similarity** range that heuristics couldn't confidently resolve, use a local LLM for pairwise or small-batch confirmation.

**Model: Llama 3.2 8B or Mistral 7B** via Ollama. The 128K context window of Llama 3.2 easily accommodates batches of 10–15 findings. At Q4 quantization, these require ~4–5GB disk and 8–10GB RAM. Research from the Bank of England (2025) and requirements-classification studies show 7B–8B models match GPT-4 on binary classification tasks with appropriate few-shot prompting—differences are "not statistically significant."

**Prompting strategy:** Use a two-step chain-of-thought pattern validated by MatchGPT and Amazon's ZSDQI research:

```
SYSTEM: You are a senior security engineer performing root-cause triage.
Two findings share a root cause if fixing ONE code change would resolve BOTH.
Same CWE in different files with no shared dependency = DIFFERENT root causes.

For each pair, reason step-by-step: (1) Are they in the same or related code?
(2) Do they share a source variable, sink function, or data flow path?
(3) Would a single fix resolve both? Then output your verdict.

OUTPUT FORMAT (use function calling / grammar-constrained generation):
{"verdict": "SAME_ROOT_CAUSE" | "DIFFERENT" | "UNCERTAIN", "confidence": 0.0-1.0, "reasoning": "..."}
```

**Batch 10–15 findings max** per prompt. Elastic's entity resolution pipeline found a 30% JSON parsing error rate with larger batches when using free-form generation—mitigated by using grammar-constrained output (llama.cpp GBNF grammars or Outlines). Set temperature=0 for determinism.

**Conservative merging:** Auto-merge only at confidence ≥0.85. Flag 0.60–0.85 for human review. Below 0.60, keep separate. This prevents the primary LLM failure mode—over-grouping findings that share surface similarity (same CWE) but are actually distinct issues requiring separate fixes.

## LLM synthesis vs. algorithmic dedup: when each wins

Pushing dedup entirely into the VP Eng synthesizer prompt is tempting but has concrete drawbacks. **Algorithmic dedup is 100% deterministic, runs in milliseconds, and produces an auditable trail** of exactly which rule and threshold triggered each merge. LLM-based dedup is non-deterministic (same findings may group differently on re-run), adds seconds of latency per batch, and produces "LLM says so" explanations that are difficult to audit.

LLMs add genuine value in three specific scenarios that algorithms cannot handle: **cross-scanner normalization** (Semgrep says "hardcoded credential," Snyk says "embedded secret in source"—same finding, completely different vocabulary), **architectural root-cause reasoning** (multiple findings across files all stemming from one missing input validation function), and **natural-language equivalence** ("insecure direct object reference" vs. "IDOR" vs. "broken access control on resource ID"). For everything else, algorithmic methods are faster, cheaper, and more reliable.

The known LLM failure modes are well-documented. **Over-grouping** is the most dangerous: the LLM sees two SQL injection findings and merges them even though they're in different endpoints requiring different fixes. Mitigation: require the LLM to cite specific shared code artifacts (file, function, variable) and reject any group where findings don't share at least one concrete attribute. **Hallucination** manifests as the LLM inventing plausible-sounding relationships ("both relate to authentication"). Mitigation: post-validate that grouped findings actually reference overlapping code paths. **Inconsistency** is inherent to LLMs even at temperature=0. Mitigation: cache grouping decisions and only re-run for new findings; use embedding clustering (deterministic) as the primary method and LLM prompting only for edge cases.

For your qa-audit pipeline specifically, the most practical approach is to let the algorithmic stages (1+2) handle the clear-cut cases deterministically, use embeddings (stage 3) for semantic matching, and reserve LLM calls for the VP Eng synthesizer's *reporting* phase rather than the dedup phase. The synthesizer can merge findings it recognizes as related during report generation without needing a separate dedup step—effectively making dedup a byproduct of intelligent summarization rather than a preprocessing stage.

## Concrete implementation specification

The complete pipeline, designed for the qa-audit-loop.sh context:

```
Input: SARIF findings from SAST tools (Semgrep, CodeQL, etc.)
│
├── Stage 1: Exact Hash (Python dict lookup, O(n))
│   Key: sha256(rule_id | file_path | cwe | severity)
│   Omit line number. First occurrence becomes cluster representative.
│   Expected reduction: ~40-50% of findings
│
├── Stage 2: Heuristic Rules (Python, O(n) with CWE blocking)
│   R1: same rule_id + same file → auto-cluster
│   R2: same source_var + same sink_func → auto-cluster  
│   R3: same CWE + same file + Jaccard(descriptions) ≥ 0.7 → auto-cluster
│   R4: same rule_category + token_jaccard(code) ≥ 0.8 → auto-cluster
│   R5: same rule + levenshtein(code) ≥ 0.85 cross-file → flag for review
│   Expected reduction: ~25-35% of remaining findings
│
├── Stage 3: Embedding Clustering (sentence-transformers + HDBSCAN)
│   Model: BGE-small-en-v1.5 (~130MB, CPU)
│   Embed: rule_id + title + description + file_path + code_snippet
│   Cluster: HDBSCAN(min_cluster_size=2, metric='cosine')
│   Auto-merge: cosine_sim ≥ 0.85
│   Flag for review: cosine_sim 0.70-0.85
│   Expected reduction: ~10-15% of remaining findings
│
├── Stage 4 (optional): LLM Confirmation
│   Model: Llama 3.2 8B via Ollama (Q4, ~5GB)
│   Only for: flagged pairs from stages 2-3
│   Batch: 10-15 findings per prompt
│   Grammar-constrained JSON output
│   Auto-merge: confidence ≥ 0.85; flag: 0.60-0.85; keep separate: <0.60
│   Expected reduction: ~3-5% of remaining findings
│
Output: Clustered findings, each cluster = one root cause
        Representative finding selected per cluster
        Cluster metadata: member count, confidence, merge reason
```

**Dependencies (all local, no API calls):** Python 3.10+, `sentence-transformers` (for BGE-small), `scikit-learn` ≥1.3 (for HDBSCAN), `ollama` (optional, for Stage 4). Total additional disk: ~130MB for embedding model, ~5GB if using local LLM. Stage 1+2 require zero additional dependencies.

**Expected total performance across all four stages:**

| Stage | Cumulative duplicates caught | Latency (100 findings) | Dependencies |
|-------|------------------------------|----------------------|--------------|
| Stage 1: Exact hash | ~40–50% | <100ms | None (stdlib) |
| + Stage 2: Heuristics | ~70–80% | <200ms | None (stdlib) |
| + Stage 3: Embeddings | ~85–90% | 2–5 seconds | sentence-transformers |
| + Stage 4: LLM | ~92–95% | 10–30 seconds | ollama |

**Graceful degradation:** Each stage is independent. If sentence-transformers is unavailable, stages 1+2 still catch 70–80% of duplicates. If ollama is unavailable, stages 1–3 catch 85–90%. The pipeline should never block on an optional stage—fall back silently.

## Conclusion

The core insight from this research is that **root-cause clustering is an unsolved problem in commercial SAST tooling**—no vendor does it. But the academic evidence (especially Schneider et al. 2022 and GPTrace 2026) shows it's tractable with off-the-shelf components. The four-stage funnel exploits the Pareto distribution of duplicate types: trivial duplicates (same rule, same file) are 40–50% of the problem and cost nothing to catch; semantic duplicates (different wording, same vulnerability) require embeddings; and genuinely ambiguous cases requiring architectural reasoning are rare enough (5–10%) that local LLM latency is acceptable.

The critical design decision is **erring toward under-merging**. Accidentally hiding a distinct vulnerability behind a false cluster is worse than showing two findings that might be the same. Set auto-merge thresholds conservatively (Jaccard ≥0.7, cosine ≥0.85, LLM confidence ≥0.85) and flag borderline cases rather than silently merging them. Build a feedback loop: log every dedup decision, let humans override, and use overrides to tune thresholds over time. The pipeline that catches 85% of duplicates reliably is more valuable than one that catches 95% while occasionally merging distinct vulnerabilities.