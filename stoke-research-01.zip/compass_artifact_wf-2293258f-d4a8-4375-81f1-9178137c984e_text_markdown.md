# React and Vite production engineering in 2025–2026

**The React ecosystem has consolidated around a remarkably clear production stack.** React 19.2 is stable with the React Compiler shipping v1.0, Vite 8 replaced both esbuild and Rollup with Rust-based Rolldown for 10–30× faster builds, and the community has converged on TanStack Query + Zustand + Tailwind CSS + shadcn/ui as the dominant combination. Server Components remain production-viable only in Next.js, the React Compiler eliminates most manual memoization, and runtime CSS-in-JS is effectively dead for new projects. This report covers all ten areas of deep production engineering knowledge for teams running React + Vite with TanStack Query, Zustand, and Tailwind CSS.

---

## React 19 shipped, but Server Components remain a Next.js story

React **19.0.0 went stable on December 5, 2024**, with subsequent releases bringing significant features: 19.1.0 (March 2025) added Owner Stacks for debugging, and **19.2.0 (October 1, 2025)** introduced the `<Activity />` component, `useEffectEvent`, Partial Pre-rendering, Performance Tracks in Chrome DevTools, and batched Suspense boundary reveals. The State of React 2025 survey shows **48% of developers using React 19 daily**, with 41% still on React 18.

The new hooks are all stable and production-ready. **`useActionState`** manages form action lifecycle (pending, success, error) in a single hook, replacing three separate `useState` calls. **`useOptimistic`** provides instant UI feedback during async operations with automatic rollback on failure. **`useFormStatus`** lets design system submit buttons read parent form state without prop drilling. The **`use()` API** breaks traditional hook rules by working inside conditionals and loops, reading Promises and Context directly during render. In React 19.2, **`useEffectEvent`** finally solves the longstanding frustration of `useEffect` dependency arrays triggering unnecessary re-runs when non-reactive values change.

React Server Components tell a more nuanced story. Only **~29% of developers have used RSC**, making it the third most disliked new feature despite strong theoretical benefits. The critical fact: **Next.js remains the only framework with production-grade RSC support.** React Router v7 offers experimental RSC primitives requiring manual assembly. TanStack Start v1.0 (March 2026) shipped without RSC support, though it's actively in development. Waku and RedwoodJS Bighorn remain experimental. Vite has no native RSC support. React's documentation explicitly warns that RSC implementation APIs for bundlers "do not follow semver and may break between minors in React 19.x."

For teams on the user's stack (React + Vite without Next.js), the practical RSC guidance is straightforward: **RSC is not available to you today.** Focus instead on the hybrid pattern that has emerged as the 2025 best practice — TanStack Query for server state management with streaming where your framework supports it, and React 19's new hooks for form handling and optimistic updates.

**Security note**: December 2025 patches (CVE-2025-55183, CVE-2025-55184, CVE-2025-67779) fixed DoS and source code exposure vulnerabilities in Server Functions affecting all React 19.0.0–19.2.3. Even apps not explicitly using Server Functions may be vulnerable. **Upgrade to 19.0.4, 19.1.5, or 19.2.4 immediately.**

When RSC is available, the decision criteria are clear: use Server Components for anything that doesn't need `useState`, `useEffect`, or browser APIs — data display, SEO content, heavy library imports. Add `'use client'` only when interactivity demands it. The "donut pattern" (server component wraps client component, passing server-fetched data as props) and Suspense boundaries as architectural seams for streaming are the canonical patterns.

---

## The state management question is settled

The community has converged on a **"right tool for each state category"** model rather than one library for everything. The dominant production combination is **TanStack Query for server state + Zustand for client state + nuqs for URL state + React's built-in hooks for local state.**

**TanStack Query v5.96.2** (~12M weekly npm downloads) is the server state standard. Version 5 brought stable Suspense support via dedicated `useSuspenseQuery` hooks, a simplified single-object API, and is roughly 20% smaller than v4. Key v5 changes include renaming `loading` to `pending` (`isLoading` → `isPending`), replacing `cacheTime` with `gcTime`, and removing `onError`/`onSuccess` callbacks from `useQuery` (side effects now belong in `useEffect`). The optimistic update pattern simplified dramatically — `useMutation` now exposes `variables` directly, letting you show optimistic UI without manually updating the cache via `onMutate`. For caching, structure query keys hierarchically (`['users', 'list']`, `['users', userId]`) and use partial key matching for cascading invalidation with `queryClient.invalidateQueries`.

**Zustand v5.0.12** (~20.4M weekly downloads, **~1KB gzipped**) is the default client state library. It requires no providers, supports Redux DevTools via middleware, and composes with `immer`, `persist`, and `subscribeWithSelector` middleware. The critical Zustand practice is **always using selectors** — `useStore(state => state.count)` prevents unnecessary re-renders. Design stores by domain (auth, cart, UI) and keep them focused.

**Jotai v2.19.0** (~2M weekly downloads) is the alternative when fine-grained reactivity matters. Where Zustand is top-down (single store, like Redux), Jotai is bottom-up (independent atoms, like Recoil). Prefer Jotai for complex interdependent derived state, real-time apps where minimizing re-renders is critical, or when you want first-class Suspense integration. Both Zustand and Jotai are created by the same developer (Daishi Kato).

**Valtio v2.1.7** offers a proxy-based approach where mutations are direct (`state.count++`) and components automatically subscribe to only the properties they read. It's best for teams with OOP backgrounds or state manipulated heavily outside React (WebSocket handlers, timers).

**Redux Toolkit v2.11.2** is still justified for large enterprise apps requiring strict unidirectional data flow, time-travel debugging, action logging for audit trails, or multi-team codebases needing rigid conventions. RTK 2.0 added `combineSlices` for lazy-loading reducers and RTK Query infinite queries. For most new projects, though, TanStack Query + Zustand has replaced Redux as the lighter default.

**nuqs v2.8.9** (~1.7M weekly downloads, **growing 545% year-over-year**) is the URL state management breakout. It provides a `useState`-like API (`useQueryState`) that syncs with URL query parameters, with built-in parsers, history control, debouncing, and Zod validation. Use nuqs for filters, sorting, pagination, search, tabs — any state users should be able to share via URL or that should survive page refresh. The `createLoader` utility enables type-safe `searchParams` parsing in server components.

A key expert insight from Nadia Makarevich: roughly 80% of what teams previously managed in Redux was actually server state (now handled by TanStack Query), with URL state and local component state covering most of the rest. Many production apps need surprisingly little dedicated client state management.

---

## The React Compiler changes the performance conversation

**React Compiler v1.0 shipped as stable on October 7, 2025**, after years of development (first explored in 2017 via Prepack, demoed in 2021, beta in October 2024). It is a **build-time Babel plugin** that automatically memoizes components and hooks by lowering JSX into a High-Level Intermediate Representation using Control Flow Graph analysis, then performing data-flow and mutability analysis across multiple compiler passes. It can memoize conditionally after early returns — something manual `useMemo`/`useCallback` cannot do.

The production results are significant. **Meta's Quest Store saw up to 12% faster initial loads, with certain interactions 2.5× faster and neutral memory impact.** Early adopters report 25–40% fewer re-renders without code changes. The compiler supports React 17+ (via `react-compiler-runtime` package), works on both React and React Native, and integrates with Next.js 15.3.1+ (SWC support), Vite (via `vite-plugin-react` with Babel), and Expo SDK 54+ (enabled by default).

Install it today: `npm install --save-dev --save-exact babel-plugin-react-compiler@latest`.

**With the compiler shipping, manual memoization guidance changes.** For new code, rely on the compiler and reserve `useMemo`/`useCallback` for cases where you need precise control — third-party APIs relying on referential equality (DnD, map, chart libraries), explicit Effect dependency pinning, or hand-tuned hot paths in massive lists. Leave existing `React.memo`/`useMemo`/`useCallback` in place rather than removing it (removal can alter compilation output). The compiler also ships lint rules via `eslint-plugin-react-hooks` that detect Rules of React violations.

**For the measurement-first approach that still matters**, use React DevTools Profiler on production builds (dev mode is 50–70% slower). Key metrics: `actualDuration` (render time with memoization) vs. `baseDuration` (worst case). React 19.2's Performance Tracks provide native Chrome DevTools integration showing Scheduler, Components, and Server tracks with color intensity reflecting render duration. Target components re-rendering unnecessarily above **16ms** (one frame at 60fps).

**TanStack Virtual v3.13.23** (~9.6M weekly downloads) is the recommended virtualization library. It's headless, framework-agnostic, and TypeScript-native. For React 19, set `useFlushSync: false` to avoid the `flushSync` warning. Alternatives: react-virtuoso for dynamic heights with minimal configuration, react-window for smallest bundle with fixed-height items.

Code splitting with `React.lazy` + `Suspense` remains the primary bundle reduction strategy. Split by routes (primary) and heavy features (secondary). Ideal split threshold: **30KB+** chunks — smaller splits add HTTP overhead that exceeds savings. In Vite, dynamic `import()` calls automatically trigger code splitting. Always wrap lazy components in both `<Suspense>` and Error Boundaries for network failure handling.

The production performance hierarchy, ranked by impact:

- Enable React Compiler (single biggest win, zero code changes)
- Route-based code splitting with React.lazy + Suspense
- Virtualize lists over 1,000 items
- Server Components if framework supports them
- Image optimization (lazy loading, WebP/AVIF, explicit dimensions)
- Proper state colocation (state near where it's used)
- After profiling: React.memo on expensive leaf components, useMemo for >1ms computations, useTransition for non-urgent updates

---

## Vite 8 and the Rolldown revolution

**Vite 8.0.5 is the latest stable release** (8.0 shipped March 12, 2026), representing the most significant architectural change since Vite 2. **Rolldown, a Rust-based bundler, replaces both esbuild and Rollup as a single unified tool**, delivering **10–30× faster builds** matching esbuild performance. Real-world benchmarks: GitLab's build dropped from 2.5 minutes to 40 seconds with 100× less memory; Excalidraw went from 22.9s to 1.4s. Vite now downloads **65 million times per week**.

The key migration items for production Vite configurations:

**Chunk splitting** evolves in Vite 8. The familiar `manualChunks` in `rollupOptions` still works but is deprecated in Rolldown. The replacement is `advancedChunks`, offering Webpack-like granular control:

```javascript
build: {
  rollupOptions: {
    output: {
      advancedChunks: {
        groups: [
          { name: 'vendor', test: /\/react(?:-dom)?/ },
          { name: 'router', test: /react-router/ },
        ]
      }
    }
  }
}
```

For Vite 6/7 projects still on Rollup, the `manualChunks` object syntax works well: separate `react`/`react-dom` into a vendor chunk (rarely changes, excellent caching), UI libraries into their own chunk, and let dynamic `import()` handle route splitting. The deprecated `splitVendorChunkPlugin` should be replaced with direct `manualChunks` configuration.

**Tree-shaking verification** matters because silent failures are common. Use `rollup-plugin-visualizer` to generate treemap reports showing exactly what's in your bundle. Common tree-shaking killers: CommonJS modules (use `lodash-es` not `lodash`), barrel file re-exports, side effects in module scope (console logs, IIFEs, global assignments), and Babel transpiling ES modules to CJS. Set `"sideEffects": false` in your `package.json` (always listing CSS files as exceptions: `"sideEffects": ["**/*.css"]`).

**Environment variables** follow strict rules: only `VITE_`-prefixed variables are exposed to client code via `import.meta.env`, and they're **statically replaced at build time** — they cannot change at runtime. For runtime configuration, serve a `config.js` from your server or inject `window.__CONFIG__` in HTML. Use `.env.[mode]` files for environment-specific values and `loadEnv()` in `vite.config.ts` since env files aren't available during config evaluation.

**Proxy configuration** is dev-only — `server.proxy` does not apply in production. Use `changeOrigin: true` for most API proxies and relative paths (`/api/users`) in frontend code. For production, configure proxying at the hosting layer.

**Essential Vite plugins**: `@vitejs/plugin-react-swc` (faster than Babel-based plugin), `rollup-plugin-visualizer` (bundle analysis), `vite-plugin-compression` (gzip/brotli), `vite-plugin-pwa` (service workers). The official Vite plugin registry launched at `registry.vite.dev` in 2026.

Additional Vite 8 features worth noting: built-in `resolve.tsconfigPaths: true` (no more `vite-tsconfig-paths` plugin), Lightning CSS for CSS minification by default, Oxc minifier for JS, browser console forwarding to dev terminal, and an experimental Full Bundle Mode that bundles during development (3× faster dev startup, 10× fewer network requests).

---

## Testing stack: Vitest, Playwright, and MSW v2 define the era

The production testing stack has consolidated around **Vitest 4.0** (October 2025) as test runner, **React Testing Library v16.3.2** for component tests, **MSW v2.12.14** for API mocking, **Playwright v1.59.1** for E2E, and **Storybook 8.5** for component catalog.

**Vitest 4.0** graduated Browser Mode from experimental to stable, added built-in visual regression testing via `toMatchScreenshot()`, and introduced schema matching with Zod/Valibot. It's **~66% faster cold start** than Jest, with **~380ms watch mode** (vs Jest's ~3.4s) thanks to HMR-based dependency tracking. Vitest shares your `vite.config.ts`, eliminating separate configuration. The State of JS 2024 showed Vitest overtaking Jest in developer satisfaction. Jest remains necessary only for React Native.

**MSW v2** overhauled its API to embrace web standards. The old `rest.get('/api', (req, res, ctx) => res(ctx.json({...})))` becomes `http.get('/api', () => HttpResponse.json({...}))` — using standard `Request`/`Response` objects. Import `http` and `HttpResponse` from `msw`, use `setupServer` from `msw/node` for tests and `setupWorker` from `msw/browser` for development. The same handlers work across Vitest, Storybook, Playwright, and browser development. For RSC testing, MSW now offers experimental `setupRemoteServer()` with `remote.boundary()` for test isolation.

**Playwright overtook Cypress in npm downloads in early 2024** and is the community standard for new projects. It's ~35–45% faster per action, offers free built-in parallelism (Cypress requires paid Cloud), and supports Chromium, Firefox, and WebKit. Cypress retains advantages in debugging experience (time-travel UI) and simplicity for JavaScript-centric teams.

Testing TanStack Query components requires a **fresh `QueryClient` per test** with `retry: false` and `gcTime: Infinity` to prevent slow retries and premature garbage collection. The maintainer (TkDodo) recommends MSW for API mocking over mocking `useQuery` directly.

**For forms**, React Hook Form v7.72.1 (~40M weekly downloads) is the unambiguous community standard. Formik v2.4.9 is in maintenance mode with declining downloads. The gold standard integration is **React Hook Form + Zod** (via `@hookform/resolvers` v5.1.1+), with Zod v4 (stable July 2025) delivering **14× faster string parsing** and a new `@zod/mini` package at ~1.9KB. The shadcn/ui Form component uses this exact stack, cementing it as the default. For server action patterns in Remix/Next.js, **Conform v1.17.1** is a growing alternative purpose-built for progressive enhancement.

For accessibility, always test with real screen readers (no automated tool catches more than 30–50% of issues). Use `eslint-plugin-jsx-a11y` for static analysis, `vitest-axe` for automated checks in tests, and RTL's `getByRole` query priority (which inherently enforces accessible markup). Focus management after SPA navigation requires programmatically setting focus to the new page's `<h1>` with `tabIndex={-1}`. Use `aria-live="polite"` for status messages and `role="alert"` for errors. Radix UI, React Aria, and Ariakit all handle keyboard navigation and ARIA patterns correctly out of the box.

---

## Vercel codified React engineering into 69+ installable rules

Vercel published its React engineering knowledge as open-source **"Agent Skills"** in the `vercel-labs/agent-skills` repository (22.1k GitHub stars, 185k+ weekly installs). These are structured rule sets covering composition patterns, web interface guidelines, and React best practices — installable via `npx skills add vercel-labs/agent-skills`.

The **react-best-practices** skill contains **69+ rules across 8 priority categories**, with the top two marked CRITICAL:

**Priority 1 — Eliminating Waterfalls** (CRITICAL): Every sequential `await` adds full network latency. Rules include `async-parallel` (use `Promise.all()` for independent operations), `async-defer-await` (move `await` into branches where actually used), `async-cheap-condition-before-await` (check sync conditions before awaiting), and `async-suspense-boundaries` (use Suspense to stream content).

**Priority 2 — Bundle Size** (CRITICAL): Rules include `bundle-barrel-imports` (import directly, avoid barrel files — can add **200–800ms to cold starts**), `bundle-dynamic-imports` (use `next/dynamic` or `React.lazy` for heavy components), `bundle-defer-third-party` (load analytics after hydration), and `bundle-preload` (preload on hover/focus for perceived speed).

The **composition-patterns** skill defines 10+ named patterns across component architecture, state management, implementation patterns, and React 19 APIs. Key rules: `architecture-avoid-boolean-props` (each boolean doubles possible states — use composition instead), `architecture-compound-components` (structure complex components with shared context), and `state-decouple-implementation` (providers are the only place that knows how state is managed).

The **web-interface-guidelines** is a 100+ rule living document covering interactions, animations, layout, content, forms, and performance. Notable rules: hit targets ≥ **24px** (44px on mobile), mobile input font ≥ **16px** (prevents iOS auto-zoom), minimum loading state duration of **150–300ms show-delay** and **300–500ms minimum visible**, URL as state (use nuqs), deep-link everything, and optimistic updates with rollback on failure. The guidelines also mandate honoring `prefers-reduced-motion`, using only GPU-accelerated properties (`transform`, `opacity`), and never using `transition: all`.

Vercel's performance philosophy is hierarchical: **fix waterfalls before micro-optimizing useMemo.** Their blog post "How we made the Vercel Dashboard twice as fast" demonstrated concrete examples — chat pages scanning messages 8 times reduced to a single pass, sequential DB calls parallelized with `Promise.all()`.

---

## Bundle optimization and the modern design system stack

**Barrel files are the most impactful anti-pattern to eliminate.** Re-exporting everything from `index.ts` breaks tree-shaking, slows builds (Next.js benchmarks showed **28% faster builds** after optimization), and inflates bundles. The fix: import directly from source modules (`import { Button } from '@company/ui/Button'`), use the `exports` field in `package.json` for granular entry points, and in Next.js, leverage `optimizePackageImports` for automatic barrel-to-direct-import transformation.

For Vite bundle analysis, **`rollup-plugin-visualizer`** generates interactive treemaps with gzip and brotli size data. **`rollup-plugin-bundle-stats`** is superior for actionable insights — it automatically identifies duplicate code and packages. Enforce budgets in CI with **`size-limit`** (GitHub Action posts size changes as PR comments) or **`vite-plugin-bundlesize`** (fails builds if per-chunk limits are exceeded). Target: **<200KB gzipped JS on initial page load** (<100KB is excellent).

Dynamic imports for heavy libraries follow two patterns: `React.lazy()` + `Suspense` for components (charts, editors, maps), and on-demand `await import()` for utilities (load `fuse.js` only when search is triggered). Replace `moment.js` (~300KB, no tree-shaking) with `date-fns` (~20KB tree-shaken) or `dayjs` (~2KB). Always import specific lodash functions (`import debounce from 'lodash/debounce'`) or use `lodash-es`.

**For design systems, the 2025–2026 stack has crystallized.** Tailwind CSS v4.2 (v4.0 released January 22, 2025) is the **dominant styling solution** with ~12M weekly downloads. Version 4 replaced `tailwind.config.js` with CSS-first configuration via `@theme`, removed the `content` array in favor of automatic detection, integrated Lightning CSS (eliminating autoprefixer and postcss-import), and runs **3.5–5× faster** for full builds. Runtime CSS-in-JS (styled-components, Emotion) is effectively dead for new projects — styled-components entered maintenance mode in January 2024.

**shadcn/ui** (50,000+ GitHub stars, used by OpenAI, Adobe, Sonos) is not an npm package but a **copy-paste component distribution system**. You run `npx shadcn@latest add button` and the source code lands in your project's `components/ui/` directory. Components are built on **Radix UI** primitives (30+ WAI-ARIA compliant headless components) styled with Tailwind CSS. The October 2025 release added 7 new components (Spinner, Kbd, Button Group, Input Group, Field, Item, Empty), moved to OKLCH colors, and dropped `forwardRef` for React 19.

Design tokens belong as CSS custom properties organized in three tiers: primitives (`--blue-500`), semantic tokens (`--color-brand-primary: var(--blue-500)`), and component tokens (`--button-bg: var(--color-brand-primary)`). Tailwind v4's `@theme` directive maps directly to custom properties, and `@property` registration enables typed tokens with animation support. For multi-platform token distribution, Style Dictionary by Amazon transforms token definitions into CSS, SCSS, JS, iOS, and Android formats.

In a monorepo alongside React Native (matching the user's context), structure packages as `apps/` (web, mobile, docs) and `packages/` (ui, tokens, config, utils). Use **pnpm workspaces + Turborepo** for orchestration, **tsup** for component library builds, **Storybook** for documentation, and **Changesets** for versioning.

---

## Conclusion

The React + Vite production stack in 2025–2026 rewards teams that follow three principles. **First, enable the React Compiler immediately** — it delivers measurable performance gains (up to 12% faster loads, 2.5× faster interactions) with zero code changes and eliminates the majority of manual memoization decisions. **Second, adopt the "right tool for each state category" model**: TanStack Query v5 for server state, Zustand for the small amount of truly global client state, nuqs for URL state, and React's built-in hooks for everything local. **Third, upgrade to Vite 8** and its Rolldown bundler for 10–30× faster builds, then use `advancedChunks` for chunk splitting and `rollup-plugin-visualizer` to verify tree-shaking.

The most underappreciated insight from Vercel's published engineering standards is the priority hierarchy: **eliminate request waterfalls before optimizing bundle size, optimize bundle size before tuning server performance, tune server performance before micro-optimizing re-renders.** Most teams invert this, spending hours on `useMemo` while sequential `await` calls add hundreds of milliseconds to every page load.

For the user's specific stack (React + Vite, TanStack Query, Zustand, Tailwind CSS in a monorepo with React Native), the actionable next steps are: enable the React Compiler via Babel plugin, upgrade to Vite 8 with Rolldown, add nuqs for URL state management, adopt shadcn/ui + Radix primitives for accessible components, enforce bundle budgets with size-limit in CI, eliminate barrel files, and build your testing stack on Vitest 4 + RTL + MSW v2 + Playwright. RSC adoption should wait until Vite gains native support or TanStack Start ships RSC — the ecosystem isn't ready for non-Next.js RSC in production.