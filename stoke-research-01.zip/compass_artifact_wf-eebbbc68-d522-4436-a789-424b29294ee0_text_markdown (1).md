# Mobile UI patterns across six leading business apps

**The most effective mobile business apps treat phones as triage consoles, not miniature desktops.** Across HubSpot, Slack, Notion, Linear, Asana, and Intercom, a clear pattern emerges: apps that ruthlessly prioritize monitoring, quick actions, and contextual responses earn the highest user satisfaction, while those that try to replicate desktop complexity on small screens draw the harshest criticism. This report dissects the specific navigation structures, screen layouts, interaction patterns, and user feedback across all six apps to extract actionable design principles for a mobile business OS.

---

## Navigation: bottom tabs, depth, and gestures

### Bottom tab bars converge on 3–5 items

Every app studied uses bottom navigation, but the number of tabs and their contents reveal different philosophies about what matters most on mobile.

**Slack** reduced from 5 tabs to **3 core tabs** (Home, DMs, Activity) in its 2023–2024 redesign — the most aggressive simplification in this group. Secondary features like Threads, Unreads, Drafts, Later, and Huddles live as **horizontally scrollable tiles** at the top of the Home tab, which users can reorder and customize. A compose button sits in the header rather than a FAB.

**Asana** runs a **5-tab layout** (Home, My Tasks, Inbox, Search, Account) though it has A/B tested a stripped-down 3-tab variant. A persistent **+ Quick Add button** floats as a FAB for task creation from anywhere.

**Notion** uses **4 fixed items** (Home, Search, Inbox, New Page) — clean and consistent, with the rightmost compose icon always available for quick page creation.

**HubSpot** shows **5 tabs** (Home, Activity Feed, Tasks, Conversations, More) with a "More" overflow for Settings, Dashboards, and Marketing. CRM objects (Contacts, Deals, Companies) are **not in the tab bar** — they're buried behind a hamburger menu in the top-left corner, which is the single most-criticized navigation decision in HubSpot's mobile app.

**Linear** takes the most unconventional approach: a **customizable bottom toolbar** built with a frosted-glass material (their own "Liquid Glass" implementation). Default items include Inbox, My Issues, and a center-positioned issue composer, but users can pin specific projects, initiatives, and documents. The bar can **exceed 5 items**, deliberately breaking Apple's standard UITabBar convention.

**Intercom** barely has navigation at all — the admin app opens directly to inbox views (Me, Unassigned, Mentions) with no rich tab bar. This reflects its maintenance-mode status and narrow mobile scope.

### Deep navigation and how apps handle depth

All six apps use **stack-based navigation** (push new views, swipe-back or tap back to return), but they differ significantly in how quickly users can reach key content.

HubSpot requires **3–4 taps** to reach a CRM record: hamburger menu → sidebar → object type → record list → record. Users must also scroll through a left drawer containing Contacts, Companies, Deals, Tickets, Custom Objects, and Lists. The complaint that "I have to click the menu almost every time I use the app" appears repeatedly in reviews. Deal pipeline views do offer a helpful **board/list toggle** in the top-right corner with horizontal swiping between stages.

Slack surfaces most content within **1–2 taps** from the Home tab: conversations appear in a single scrollable list, and the pull-down gesture reveals recent conversations and search. The Activity tab consolidates all mentions, thread replies, and reactions in one feed. Settings live behind the profile picture (top-right) → Preferences.

Notion's depth problem is its **nested page hierarchy** — pages within pages within pages can create disorientation on mobile. Breadcrumbs at the top help, but UX studies found "multiple redundant pathways to the same content created confusion." The sidebar sections (Teamspaces, Shared, Private, Favorites) mirror desktop faithfully, which helps existing users but confuses new mobile-first users.

Linear keeps depth manageable: Teams → Backlog/Active Cycle/Triage → Individual issues. The customizable tab bar means users can **pin frequently visited projects** directly, eliminating drill-down for common workflows.

Asana buries Projects, Portfolios, and Goals on mobile — users must **scroll to the bottom of the Home screen** to find them, which multiple reviewers flag as counterintuitive.

### Gesture navigation patterns

| Gesture | Slack | Asana | Linear | HubSpot | Notion | Intercom |
|---------|-------|-------|--------|---------|--------|----------|
| **Swipe-to-action on list items** | Limited | ✅ Right=complete, Left=more actions | ✅ Left/right=delete/snooze (inbox) | ❌ None on records | ❌ Minimal | ❌ Minimal |
| **Pull-to-refresh** | Repurposed as search/recall | ✅ Standard | ✅ Standard | ✅ Standard | ✅ Standard | ✅ Standard |
| **Swipe back** | ✅ Returns to previous tab | ✅ iOS standard | ✅ iOS standard | ✅ iOS standard | ✅ iOS standard | ✅ iOS standard |
| **Board/kanban swipe** | N/A | ✅ Horizontal between columns | N/A | ✅ Between deal stages | N/A | N/A |

**Slack's pull-down gesture** is unique: rather than refreshing, pulling down from the Home tab opens a **search interface** showing recent conversations, with horizontal tabs for files, channels, people, and canvases. This is a power-user pattern that overloads a familiar gesture with different meaning.

**Asana's swipe-right-to-complete** triggers the app's signature celebration animations (unicorn, narwhal, phoenix) — a small delight detail that users consistently praise.

**Linear's inbox swipe gestures** (swipe to delete/snooze notifications) with subtle haptic feedback and rubber-band distortion effects reflect the team's attention to interaction polish.

---

## Key screens: what each app shows and how

### HubSpot's CRM record view prioritizes action over data

The mobile contact/deal record opens to a **top-heavy action layout**: the record name displays prominently at top, followed by quick-action icons (Call, Email, Text for contacts; Call for companies). Below that sits an activity quick-add row (Add Note, Add Task, Log Activity with options for Call, Email, Meeting, SMS, WhatsApp, LinkedIn, and Postal Mail).

The **activity timeline** dominates the middle of the screen — a chronological stream of all logged activities with a filter dropdown to toggle visibility by type (Notes, Emails, Calls, Tasks, Meetings). Filter selections persist across all records of that object type.

The **"About" section** shows contact properties. A February 2025 update introduced **"Tap to Edit"** on iOS, enabling inline property editing directly from the About tab — a significant improvement over the previous full-screen edit flow. However, the About section historically showed ALL properties, forcing endless scrolling. Users have long requested customizable mobile property layouts.

For deals and tickets, a **tappable stage/status pill** below the record name allows changing pipeline stage with a single tap — the single quickest action available on mobile. Associations (related Companies, Deals, Tickets) appear at the bottom for cross-navigation.

New records are created via a **"+ Create" FAB** in the bottom-right corner, which opens a slide-up panel with required fields (Amount, Close Date for deals; Email for contacts).

### Slack's chat experience optimizes for fast scanning

The **message list** presents each message with a circular avatar (left-aligned), bold sender name, gray timestamp, and message body. Rich content (images, files, link previews) renders inline. Unread messages get a highlighted "New" divider. Thread indicators below messages show reply count and participant avatars.

The **composer bar** is fixed at the bottom: a "+" button on the left opens attachments/shortcuts, the text field sits center with emoji and @mention icons, and a send button (paper plane) appears when text is entered. Formatting options (bold, italic, lists) surface when text is selected.

**Reactions** require a **long-press** on any message, which reveals a context menu with frequently used emoji for one-tap reactions plus a "+" for the full picker. This is slower than desktop (where hovering shows 3 quick-react emoji) and is a documented friction point.

**Thread navigation** opens a full-screen view sliding from the right, with the parent message at top, chronological replies, its own composer, and a "Also send to #channel" checkbox. Threads are also accessible from the dedicated Threads tile on the Home tab and from the Activity tab.

Slack's design team shared that mobile users open the app **15–20 times per day for 20–30 seconds per session** — the entire mobile experience is tuned for these micro-interactions.

### Linear and Asana's task lists take different density approaches

**Linear** displays issues as compact rows: **status icon** (colored circle for workflow state), **issue identifier** (team prefix + number like "ENG-123"), **title**, and configurable metadata (priority icons, assignee avatar, labels). Issues can be grouped by Status, Assignee, Project, Priority, Cycle, or a unique **AI-powered "Focus" grouping** that orders by likely work priority. The issue detail view opens full-screen with title, description, status, priority, assignee, labels, project, cycle, sub-issues, comments, and activity.

Linear's critical weakness: **description editing opens a separate modal** that doesn't auto-save. Users report data loss on spotty connections — "I've lost so much data because of this, especially when I have a spotty connection, like on the subway." Status, priority, and assignee changes work via contextual menus without leaving the list, which is well-executed.

**Asana** made a controversial design choice in December 2023: tasks now occupy **~3 lines** of vertical space (up from 1 line), showing completion checkbox + task name, due date + project name, and subtask indicator. The first 3 subtasks display inline with a "Show more" expander. While this provides more context per task, it **dramatically reduced visible task density** — the most criticized change in Asana's recent mobile history. Users reported "only a few tasks visible at a time" and "breaks my workflow."

Asana's task detail view supports **inline editing** for title and description (richer than Linear's approach), with overlay pickers for due dates and assignees. However, multi-select was lost in the redesign, and mobile filters are significantly more limited than web — you cannot group tasks by project in the My Tasks view, and custom project tabs/views are unavailable.

### Intercom's mobile inbox is functional but frozen

The conversation list shows items with **customer name/avatar, last message preview, and color-coded activity indicators** distinguishing user replies, admin replies, and internal notes — designed specifically for mobile triage. Conversations can be **closed without opening them** (reducing taps for obvious spam/resolved items).

The composer supports text replies, macros/saved replies (content only, not automation actions), Help Articles, images, and GIFs. An internal notes mode supports **@mentioning teammates**. However, you **cannot attach files, create hyperlinks, schedule meetings, or select specific text** — only copy entire message bodies. The app is officially in **maintenance mode** with no new features planned, making it essentially a legacy reference point rather than a design exemplar.

---

## Mobile-specific patterns: FABs, sheets, editing, widgets

### FAB usage splits between creation and navigation

Three of six apps use floating action buttons or FAB-equivalent patterns:

- **HubSpot**: "+ Create" FAB (bottom-right) → opens a speed-dial menu for creating Contacts, Companies, Deals, Tasks, Notes
- **Asana**: "+ Quick Add" FAB → creates tasks from any screen, with voice and image capture capabilities  
- **Linear**: Center tab in the bottom toolbar serves as a **dedicated issue composer** — functionally a FAB embedded in the navigation bar, described as having "an obsessive focus on speed"

Slack, Notion, and Intercom do **not** use FABs. Slack integrates compose into the header. Notion places page creation in its persistent bottom nav bar. Intercom's narrow scope doesn't warrant one.

The pattern that emerges: **FABs work best for single, clear creation actions** (create task, create record, file issue). Apps with more ambiguous primary actions (what would Slack's FAB do — new message? new channel? new huddle?) tend to avoid them.

### Bottom sheets versus full-screen modals follow a complexity threshold

**Bottom sheets** (partial overlays from the screen bottom) appear across all six apps for **lightweight, contextual interactions**: filter menus, action sheets, property pickers, snooze options, and share dialogs. Intercom's entire Messenger SDK launches as a native bottom sheet, allowing users to see their app context behind it.

**Full-screen modals** are reserved for **focused, multi-field tasks**: new message composition (Slack), record creation (HubSpot), issue description editing (Linear), page editing (Notion), and task creation forms (Asana).

The **decision boundary** appears to be around **3–5 fields or options**: fewer triggers a bottom sheet, more triggers a full-screen modal. Slack explicitly uses bottom sheets on Android and overflow menus on iOS for the same filter functions — a deliberate platform-differentiated approach.

### Editing patterns reveal a spectrum from inline to modal

| App | Editing approach | User reception |
|-----|-----------------|----------------|
| **Asana** | Inline for titles/descriptions in detail view | Positive — feels natural |
| **HubSpot** | "Tap to Edit" inline on iOS (2025); slide-up panels for creation | Improved — previously full-screen only |
| **Notion** | Always inline with above-keyboard toolbar | Mixed — powerful but accidental edits common |
| **Slack** | Inline composer; inline edit for sent messages | Positive — messaging is inherently inline |
| **Linear** | **Separate modal for descriptions**; inline for metadata | Negative — data loss, no auto-save |
| **Intercom** | Inline composer for replies | Neutral — limited but functional |

The clear lesson: **inline editing wins for single-field updates and metadata changes**, but complex rich-text editing still struggles on mobile regardless of approach. Notion's above-keyboard toolbar (with +, @, comment, image, indent/outdent, color options) is the most full-featured inline editing implementation but adds cognitive overhead versus desktop's slash commands.

### iOS widgets: present but underwhelming

| App | Widgets | What they show |
|-----|---------|---------------|
| **Slack** | 4 widgets (July 2024) | Catch Up (unread count), Status (quick-set), Status medium (preset statuses), Lock Screen launcher |
| **Notion** | 3 widget types | Single Page (quick access), Recent Pages, Favorites |
| **Asana** | Today View widget | Top 5 tasks due today; Android widget is more capable (configurable, scrollable, Quick Add) |
| **HubSpot** | 2 calling widgets | Recently Called Contacts, Call Tasks; Lock Screen support |
| **Linear** | ❌ None yet | Planned; community workarounds via Scriptable app |
| **Intercom** | ❌ None | Maintenance mode; unlikely to be developed |

Asana's iOS widget draws specific criticism: "just a dumb list in date order" — it cannot show My Tasks broadly, filtered views, or project-specific lists (though the Android version can). HubSpot's widgets are **calling-focused**, reflecting the app's mobile-first use case as a field sales tool. Slack's status widget enabling preset statuses directly from the home screen is the most **actionable** widget in the group — it changes app state without opening the app.

### Notification grouping remains a weak point

Slack uses **automatic iOS notification grouping** by workspace and conversation thread — the most sophisticated approach in this group. Individual notifications show workspace name, channel/DM name, sender, and message preview. Per-channel notification preferences (all messages, mentions only, or nothing) provide granular control.

HubSpot's email tracking notifications are notoriously spammy — one reviewer described getting "a notification every 2 seconds" when tracked emails are opened. Intercom's push notifications are reportedly **unreliable**, with settings resetting frequently. Linear offers a configurable **notification schedule** (e.g., 9–5 only) that prevents after-hours alerts — a simple but valuable feature no other app in this group offers.

---

## What works and what doesn't: user verdict

### Patterns that earn consistent praise

**Speed and responsiveness** dominate positive feedback. Linear's desktop speed ("everything feels instant") sets the bar, though its mobile app doesn't fully match. Slack's quick catch-up capability — "I can catch up on missed messages quickly and jump to conversations without feeling lost" — reflects good mobile optimization.

**Mobile-first features** earn outsized praise relative to their complexity. HubSpot's **business card scanner** (camera → OCR → CRM contact) and **Caller ID overlay** (CRM data on incoming calls) are the most-loved mobile features despite being simple utilities. Asana's **voice capture** (speak → auto-create task) and **celebration animations** on task completion generate similar enthusiasm. These features work because they **leverage phone hardware** (camera, microphone, caller system) rather than shrinking desktop screens.

**Opinionated simplicity** wins over flexibility. Linear's 4.9/5 App Store rating (highest in this group) correlates with its most opinionated design: fewer options, stronger defaults, less configuration. Users describe it as "a joy to use" precisely because it doesn't try to do everything.

### Patterns that draw criticism

**Desktop-parity gaps** are the **#1 complaint** across every single app. Missing features include: admin controls on Slack mobile, contact filtering on HubSpot mobile, project views on Asana mobile, inline editing on Linear mobile, workflow configuration on Intercom mobile, and editing capabilities on Notion mobile. The frustration isn't that features are missing — it's that users hit walls unexpectedly when they can't complete a task they started on mobile.

**Too many taps** to reach core functions is the #2 complaint, specifically targeting HubSpot (CRM records behind hamburger menu), Asana (projects buried at bottom of Home), and Slack (hidden menus in the redesign). The principle: **every tap beyond 2 to reach a primary action is a design failure on mobile**.

**Performance and offline gaps** create acute pain. Notion's mobile app loads slowly due to its web-wrapper architecture — "phones often have less RAM and CPU power, so large pages take longer to render." Linear has **zero offline support** on mobile (despite having it on desktop), causing data loss during subway commutes. The pattern: **mobile users are frequently on unreliable connections**, making offline capability not a nice-to-have but a core requirement.

**Notification overload** without intelligent prioritization plagues Slack ("notification overload — it's easy to feel constantly on") and HubSpot (email tracking spam). The root cause identified in a Slack mobile UX study: "a lack of prioritization for Slack notifications" — users couldn't distinguish signal from noise.

### The mobile behavior gap

Research confirms **desktop sessions are roughly twice as long as mobile** (Perficient), and "business and industry" is heavily desktop-dominant. What users actually do on mobile across all six apps:

- **Check status and updates** (all apps)
- **Respond quickly** to messages, tickets, and comments (Slack, Intercom, Asana)
- **Log quick actions** (HubSpot: calls/texts; Linear: file bugs; Asana: check off tasks)
- **Triage** (Intercom: assign conversations; Slack: scan @mentions; Asana: review what's due)
- **Reference information** (Notion: look up docs; HubSpot: view contact details)

What they do **not** do on mobile: configure workspaces, build reports, set up automations, manage permissions, create complex views, or do deep content creation. A Notion UX study crystallized this: "Desktop supports deep work sessions. Mobile users need fast, simple check-ins. Notion's mobile struggles stem from a mismatch between mobile user needs and desktop-based assumptions."

---

## The five mobile screens that matter most for a business OS

Based on the patterns, user behavior data, and feedback across all six apps, these are the five screens a mobile business OS must nail — along with specific layout and interaction recommendations.

### Screen 1: The smart home feed

**Purpose**: Answer "What needs my attention right now?" in under 5 seconds.

**Layout**: Full-screen scrollable feed with **three distinct sections**, each collapsible: (1) **Action Required** — items assigned to you with approaching deadlines, unread messages requiring response, stalled deals; (2) **Today's Schedule** — time-blocked meetings and tasks in chronological order; (3) **Recent Activity** — a lightweight stream of updates from followed projects, channels, and records.

**Components**: Each feed item should be a **card** showing: icon indicating type (task, message, deal, meeting), title (bold, truncated at 1 line), context line (project/channel name + timestamp), and an **inline action button** (reply, complete, snooze) visible without tapping into the item. Use Slack's tile approach for quick-access shortcuts (Unreads, Threads, Drafts) as a **horizontal scrollable bar** pinned below the header.

**Interactions**: Pull-to-refresh syncs data. Swipe right on any item to **snooze** (with time options as a bottom sheet). Swipe left to **dismiss/archive**. Tap to drill into full detail. The feed should be **algorithmically sorted by urgency**, not chronological — Linear's AI "Focus" grouping concept applied universally.

### Screen 2: The unified inbox

**Purpose**: Triage all inbound communications — messages, notifications, mentions, customer conversations — in one place.

**Layout**: Vertically scrollable list of conversation items, each showing: **avatar** (person or channel icon), **sender/source name** (bold), **preview text** (1 line, gray), **timestamp** (right-aligned), and a **colored left-border** indicating type (blue for message, orange for mention, red for urgent, green for task update). Intercom's color-coded activity indicators are the model here. **Filter chips** at the top allow toggling between All, Mentions, Threads, and Assigned.

**Components**: Unread items get a **dot indicator** and slightly bolder card treatment. Batch actions via multi-select (long-press to enter selection mode, then archive, snooze, or mark read). Individual items support **swipe-left for quick reply** (opens inline composer as bottom sheet) and **swipe-right for snooze/archive**.

**Interactions**: Tapping into a conversation opens a **full-screen thread view** with the message history and a fixed composer at the bottom (following Slack's pattern). The composer should support text, @mentions, emoji (quick-react row from long-press), and file attachments. A toggle between "Reply" and "Internal Note" modes follows Intercom's pattern. Back navigation via swipe-right or back arrow.

### Screen 3: The task/issue list

**Purpose**: See everything assigned to you, complete quick updates, and stay oriented on priorities.

**Layout**: This is where **information density matters most**. Each task should occupy **2 lines maximum** (Asana's expansion to 3 lines was universally criticized): Line 1 shows a **completion checkbox/status icon + task title** (truncated); Line 2 shows **due date** (color-coded: red=overdue, orange=today, gray=future) + **project/team badge** + **priority indicator** (Linear's colored dots) + **assignee avatar** (small, right-aligned).

**Components**: **Grouping controls** as a dropdown (by status, project, priority, due date). **Filter chips** for quick filtering (My Tasks, Overdue, Due Today, Starred). A **FAB** in the bottom-right for creating new tasks — following HubSpot and Asana's proven pattern. The FAB should support **voice input** (Asana's voice capture) and **image capture** for quick mobile-native task creation.

**Interactions**: Tap checkbox/status to **cycle through states** without opening the task (Linear's contextual status change). Swipe right to **mark complete** with a satisfying animation (Asana's celebration pattern). Swipe left for a **quick-action menu** (reassign, change priority, snooze). Tap the task to open a **detail view** with inline editing for all fields — not Linear's separate modal approach. Long-press for drag-to-reorder within sections.

### Screen 4: The record/entity detail view

**Purpose**: View and update a CRM record, project, or entity with the most relevant information front and center.

**Layout**: Follow HubSpot's proven structure but improve it. Top section: **Entity name** (large, bold) + **type badge** (Contact, Deal, Company, Ticket) + **stage/status pill** (tappable to change, following HubSpot's single-tap pipeline stage change). Below name: **Quick action row** — 3–4 circular icon buttons for the most common actions (Call, Email, Message, Log Activity). Below actions: **Tabbed content area** with 3 tabs: Activity (timeline), Details (properties), and Related (associations).

**Components**: The Activity tab should be a **reverse-chronological stream** with type filters (following HubSpot's persist-across-records filter). The Details tab should show only **5–8 priority properties** (not all properties — solving HubSpot's "endless scrolling" problem) with a "Show All" expander. Each property supports **tap-to-edit inline** (HubSpot's 2025 pattern). The Related tab shows associated entities as tappable cards for cross-navigation.

**Interactions**: The stage/status pill at the top is the **highest-value interaction** — a single tap to advance a deal stage or change a ticket status. Properties use inline editing with auto-save. The quick action row should use the phone's native capabilities: Call triggers the dialer with CRM logging, Email opens the composer with contact pre-filled, Message opens the conversation thread.

### Screen 5: The quick-capture/create screen

**Purpose**: Capture information instantly — the "don't lose the thought" screen that must load in under 1 second.

**Layout**: Triggered by the FAB or a dedicated tab. Opens as a **bottom sheet** (not full-screen) showing: a large text input field (auto-focused with keyboard open), a type selector row below (Task, Note, Contact, Deal — as icon+label chips), and a minimal set of **smart defaults** (assigned to you, due today, in your default project).

**Components**: The text field should support **natural language parsing** — typing "Call Sarah about renewal by Friday" should auto-suggest creating a task with assignee=Sarah, type=Call, due=Friday. Below the input: **attachment shortcuts** (camera, photo library, voice recording, document). At the bottom: a **"Create and add another"** checkbox and a prominent **Save button**.

**Interactions**: This screen must be **optimized for one-handed, one-thumb use**. All interactive elements in the bottom 60% of the screen (unlike HubSpot's hamburger menu in the unreachable top-left). Voice input via microphone icon for hands-free capture. The screen should dismiss with a downward swipe and provide a **toast confirmation** with an undo option. Crucially, this must work **offline** — saving locally and syncing when connectivity returns.

---

## Conclusion

The six apps studied reveal that mobile business UX has matured unevenly. **Linear and Slack lead in design craft** — Linear with its obsessive interaction polish (4.9/5 rating) and Slack with its research-backed architecture tuned for 20–30 second sessions. **HubSpot leads in mobile-native innovation** with hardware-leveraging features like business card scanning and caller ID. **Asana provides the richest gesture vocabulary** with swipe-to-complete and celebration animations. **Notion and Intercom represent cautionary extremes** — Notion's desktop-first architecture creates fundamental mobile performance problems, while Intercom's maintenance mode shows what happens when mobile investment stops entirely.

The unifying insight across all user feedback is that **the mobile penalty is real**: every app's mobile version is worse than its desktop version, and users know it. The path forward isn't desktop parity — it's **mobile advantage**. The five screens above succeed by leveraging what phones do better than desktops: always-available quick capture, location-aware context, hardware integration (camera, voice, caller ID), notification-driven triage, and one-thumb interactions for the 30-second sessions that define mobile business use.