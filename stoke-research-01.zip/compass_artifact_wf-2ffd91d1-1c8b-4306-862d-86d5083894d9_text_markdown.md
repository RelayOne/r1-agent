# Privacy compliance automation for a BC-based multi-tenant SaaS

**A greenfield SaaS company in Victoria, BC processing PII, financial, health, biometric, HR, and B2B data across Postgres, MongoDB, Redis, Kafka, S3, and Elasticsearch can now encode GDPR, CCPA, PIPEDA, BC PIPA, CASL, and ePrivacy requirements directly into AI coding agents, CI/CD pipelines, and automated enforcement systems using a maturing ecosystem of open-source tools and published engineering patterns.** The field has reached an inflection point: GitHub's official `awesome-copilot` repo ships a 283-line GDPR SKILL.md, Ethyca's Fides provides open-source DSR orchestration across polyglot persistence, and companies like Airbnb and Meta have published detailed privacy infrastructure blueprints. However, no single tool covers all surfaces—a layered approach combining 3–5 tools is standard practice, and CASL-specific automation remains a significant gap in the open-source ecosystem.

---

## 1. AI coding agent rule files now enforce privacy-by-design at the prompt level

The most comprehensive published privacy rule file is **GitHub's official `awesome-copilot` GDPR SKILL.md** (github.com/github/awesome-copilot), a 283-line, 15-section document that triggers on any code involving personal data, cookies, analytics, or encryption. It encodes specific patterns: add `RetentionExpiresAt` to every PII table, default optional data collection to OFF, mask sensitive values at the edge (`****1234`), anonymize IPs by masking the last octet, use UUIDs instead of sequential integers, and never log passwords, tokens, session IDs, card numbers, national IDs, or health data. It includes a PR review checklist that checks for PII column purpose and retention, column-level encryption, IP anonymization, and data export endpoint coverage.

Beyond GitHub's official offering, several other notable repositories exist. The **peixotorms/odinlayer-skills** GDPR Compliance Expert skill (installable via `npx skillfish add`) provides SQL schemas for consent logging, field-level encryption templates, and automated 72-hour breach notification workflows. The **davila7/claude-code-templates** repo includes a Data Privacy Compliance SKILL.md covering GDPR, CCPA, and HIPAA. The **tonynguyennvt/cursor-rules-awesome** ships a 4,800-line `.cursorrules` file covering nine compliance frameworks including GDPR, CCPA, and PCI-DSS.

For Cursor IDE specifically, **matank001/cursor-security-rules** (364 stars) provides `.mdc` files enforcing parameterized queries, SSRF prevention, and path traversal prevention. The **agentrulegen.com** platform offers copy-paste templates with explicit privacy rules like `"Never log email addresses, names, or other PII"` and `"User IDs in logs must be hashed: hashId(userId) from @/lib/privacy"`.

Research from Backslash Security confirmed that **none of the major AI models produce secure code by default**, but when security and privacy rules are embedded into prompts, all models consistently produce compliant code. The key gap: no single widely-adopted, standalone privacy-by-design standard exists yet. Privacy rules are fragmented across Copilot SKILL.md files, Cursor `.mdc` rules, and Claude Code SKILL.md templates. The ecosystem is rapidly evolving, with most repos created in 2025–2026.

**Recommended approach for a greenfield SaaS:** Fork the `awesome-copilot` GDPR SKILL.md as a baseline, extend it with CASL consent-checking rules and BC PIPA employee data patterns, and add project-specific rules like mandatory `tenant_id` in all queries and express consent requirements for health/biometric fields.

---

## 2. Open-source PII detection tools require a layered, multi-surface strategy

**Microsoft Presidio** is the dominant open-source framework for PII detection, with ~3,600 GitHub stars, MIT license, active maintenance, and **50+ built-in recognizers** covering financial data (credit cards, IBAN), personal identifiers (SSN, passport), and medical entities. Its modular architecture separates detection (presidio-analyzer) from de-identification (presidio-anonymizer), supporting spaCy, HuggingFace Transformers, Stanza, and Flair as NLP backends. A dedicated GitHub Action (`insightsengineering/presidio-action@v1`) scans PRs for PII, and Docker images are available at `mcr.microsoft.com/presidio-analyzer`.

For **source code secrets** (distinct from PII), **detect-secrets** by Yelp (~3,800 stars, Apache 2.0) uses Shannon entropy analysis and regex to catch API keys, passwords, and credentials at the pre-commit hook level. It creates a baseline of existing secrets and blocks new ones—but it does not detect names, SSNs, or emails. Pair it with **Gitleaks** (v8.18+) for broader coverage including PII patterns.

For **database column scanning**, **piicatcher** (Tokern, ~200 stars) scans PostgreSQL, MySQL, Snowflake, BigQuery, and other databases using regex pattern matching and spaCy NER against column names and sampled data. It natively integrates with **DataHub** and **Amundsen** to auto-tag PII columns in data catalogs.

For **JavaScript/TypeScript codebases**, three ESLint plugins are relevant:

- **eslint-plugin-pii** (~154K npm downloads): Detects hardcoded emails, birth dates, IP addresses, and phone numbers in code
- **eslint-plugin-no-secrets**: Shannon entropy analysis for high-entropy strings (API keys, tokens)
- **@logvault/eslint-plugin** (actively maintained, 2025–2026): The `logvault/no-pii-in-logs` rule prevents logging PII fields without transformation, accepting a configurable list of PII field names and required transformers

For **data catalogs with PII classification**, **OpenMetadata** (~5,500 stars, 84+ connectors) runs automated classification workflows powered by spaCy with configurable confidence levels, and is actively adding Presidio-based custom recognizers. **DataHub** (~10,000 stars) supports auto-classification but is currently limited to Snowflake for automated PII detection.

For **Kafka streams**, no dedicated open-source PII scanner exists. The recommended pattern is deploying Presidio as a REST microservice and calling it from a Kafka Streams application or consumer, or using Confluent's commercial PII Detection SMT for Kafka Connect.

**Recommended CI/CD pipeline integration:**

```yaml
# .github/workflows/privacy-scan.yml
steps:
  - uses: insightsengineering/presidio-action@v1     # PII in code/docs
  - uses: gitleaks/gitleaks-action@v2                 # Secrets detection
  - run: pip install detect-secrets && detect-secrets scan  # Baseline secrets
```

---

## 3. CASL compliance automation demands custom-built consent infrastructure

**No dedicated open-source CASL compliance library exists**—this is the largest tooling gap in the privacy ecosystem. The npm package `casl` is an unrelated authorization library. Engineering teams must build CASL automation from scratch or use Canadian commercial platforms.

Every Commercial Electronic Message (CEM) under CASL must satisfy three pillars: **consent** (express or implied before sending), **identification** (sender name, mailing address, and contact info), and **unsubscribe** (functional for ≥60 days after sending, processed within 10 business days). The critical technical distinction is that **express consent never expires** until withdrawn, while **implied consent expires after 2 years** from last purchase or 6 months from last inquiry—and each new transaction resets the clock.

A production consent tracking schema requires these fields at minimum:

```sql
CREATE TABLE consent_records (
    consent_id UUID PRIMARY KEY,
    contact_id UUID NOT NULL,
    consent_type VARCHAR(30) NOT NULL,  -- 'express', 'implied_transaction', 'implied_inquiry'
    consent_status VARCHAR(20) DEFAULT 'active',  -- 'active','expired','withdrawn'
    consent_date TIMESTAMP NOT NULL,
    expiry_date TIMESTAMP,              -- NULL for express (never expires)
    consent_source VARCHAR(255),        -- 'web_form:signup_page', 'purchase:order_123'
    consent_purpose TEXT NOT NULL,       -- Purpose stated at collection time
    proof_reference TEXT,               -- Screenshot URL, form submission ID
    ip_address INET,
    form_snapshot_url TEXT              -- Archived form copy
);
```

The daily automated expiration job must expire implied consents past their `expiry_date`, log expirations to an immutable audit trail, and send re-consent campaign emails 30/60/90 days before expiry. Pre-send validation must check: active consent exists → if implied, expiry > NOW() → no unsubscribe on file → determine jurisdiction (CASL vs. CAN-SPAM vs. GDPR) by GeoIP.

For **one-click unsubscribe**, RFC 8058 compliance requires `List-Unsubscribe` and `List-Unsubscribe-Post: List-Unsubscribe=One-Click` headers with valid DKIM signatures. Gmail and Yahoo mandate this for bulk senders (5,000+ daily emails) since 2024. The unsubscribe endpoint must process POST requests immediately—never process on GET (which link scanners may trigger accidentally).

**CASL enforcement cases reveal common technical failures.** CompuFinder (reduced from $1.1M to $200K) had broken unsubscribe links—one of two links produced an error—and no consent tracking system. nCrowd ($100K against CEO personally) had no consent validation dates, making it "impossible to verify" consent was obtained within the two-year window. **20% of CASL complainants still received emails 10+ days after unsubscribing**, indicating widespread unsubscribe processing failures across the industry.

Canadian commercial platforms with strong CASL features include **Envoke** (Ontario-based, auto-expiry tracking, 8 consent states, GeoIP jurisdiction detection), **itracMarketer** (visual consent form archiving), and **Cyberimpact** (monthly consent expiry reports).

---

## 4. GDPR data subject rights across polyglot persistence require orchestrated fan-out

The leading open-source tool for DSR automation is **Ethyca Fides** (github.com/ethyca/fides, 439 stars, Apache 2.0). Fides uses YAML-based dataset definitions where each field is annotated with a privacy taxonomy category (e.g., `user.contact.email`, `user.financial.bank_account`). Its execution engine traverses a dataset graph—starting from root identifiers like email, querying connected stores via pre-built connectors (Postgres, MongoDB, MySQL, Redis, S3, SaaS APIs), extracting foreign keys, and fanning out to subsequent stores. The React-based Privacy Center provides a self-service portal for data subjects.

For **right to erasure across the polyglot stack**, each technology requires a different approach:

**Postgres:** `DELETE FROM users WHERE user_id = ?` with cascading foreign keys, or soft delete with PII nullification (`SET deleted_at = NOW(), email = NULL, name = NULL`). Use `pg_partman` for time-based partition dropping, which is near-instantaneous compared to row-by-row deletion.

**MongoDB:** `db.collection.deleteMany({ userId: ObjectId("...") })` across all collections. Client-Side Field Level Encryption (CSFLE) enables crypto-shredding for MongoDB specifically.

**Redis:** `SCAN 0 MATCH user:12345:*` followed by `UNLINK` for async deletion. Redis data is typically transient, so short TTLs often suffice for compliance.

**Kafka (immutable logs):** The industry-standard approach is **crypto-shredding**—encrypt PII fields with per-user Data Encryption Keys (DEKs), store DEKs in a compacted key topic, and on erasure request, publish tombstone records for the user's DEK. Without the key, all encrypted data becomes permanently unreadable. Conduktor Gateway provides configuration-based crypto-shredding with HashiCorp Vault integration.

**S3:** Identify objects via metadata tags (`gdpr-subject-id: user123`), `DeleteObject` for each, and for versioned buckets, delete all versions. For KMS-encrypted objects, schedule KMS key deletion (7–30 day pending period in AWS).

**Elasticsearch:** `POST /index/_delete_by_query { "query": { "term": { "userId": "12345" } } }` followed by `_forcemerge?only_expunge_deletes=true` to reclaim disk space.

**For multi-tenant SaaS** where the tenant is the controller and the platform is the processor, DSARs are directed at the tenant. The platform must provide tenant-scoped APIs for data export, search, and deletion, along with self-service admin tools. Every query must enforce `tenant_id` scoping via PostgreSQL Row-Level Security or application-level filtering. The Data Processing Agreement must specify what DSAR assistance the platform provides and response timelines.

The **OpenDSR specification** (github.com/opengdpr/OpenDSR, founded by mParticle and LiveRamp) standardizes Controller-Processor DSR communication via REST APIs for creating, tracking, and completing requests.

---

## 5. Consent management requires both CMP integration and real script blocking

**Google Consent Mode v2** became mandatory in March 2024 for any site using Google services for EEA/UK users. It requires four consent signals: `ad_storage`, `analytics_storage`, `ad_user_data` (new in v2), and `ad_personalization` (new in v2). In **Basic mode**, tags are fully blocked until consent. In **Advanced mode**, tags load but send cookieless pings enabling Google's conversion modeling (requires 700+ daily ad clicks over 7 days for modeling threshold).

**IAB TCF v2.3** becomes mandatory February 28, 2026, making the `disclosedVendors` segment mandatory to resolve signaling ambiguity about which vendors were shown in the CMP UI. The `__tcfapi` JavaScript API provides programmatic consent retrieval, and the `iabtcf-es` TypeScript library enables server-side TC string decoding and validation.

For **real script blocking** (not cosmetic banners), the primary technique is **script type manipulation**: changing `type="text/javascript"` to `type="text/plain"` and moving `src` to `data-src`. Browsers only execute scripts with `type="text/javascript"` or no type attribute. On consent grant, the CMP restores the original type and src. Auto-blocking CMPs use **MutationObserver DOM interception**—a lightweight script loads first in `<head>`, intercepts all `<script>`, `<iframe>`, and `<img>` elements injected into DOM, and compares against a tracker database.

**Critical implementation detail:** the blocking script must be the very first `<script>` in `<head>`, must NOT have `async` or `defer` attributes, and performance optimization plugins that reorder scripts will break blocking. GTM Consent Mode alone is insufficient—it only controls tags within GTM; hardcoded scripts and plugin-injected scripts still execute uncontrolled.

The four major open-source cookie consent libraries that perform real blocking:

- **vanilla-cookieconsent** (orestbida/cookieconsent, ~5,200 stars, MIT): Zero dependencies, data-category attribute system, cookie auto-clearing on withdrawal. Most popular and flexible.
- **tarteaucitron.js** (~2,800 stars, GPL-3.0): French-origin (since 2013), 100+ pre-built service integrations, native Google Consent Mode v2 support since v1.17, service-based architecture with fallback placeholders.
- **Klaro** (~1,400 stars, BSD-3): React/Preact-based, per-service callbacks, works even with JS disabled.
- **Orejime** (~183 stars, BSD-3): Fork of Klaro focused on **accessibility** (WCAG/RGAA compliant, tested with screen readers). Best for government or accessibility-mandated deployments.

**None of these support IAB TCF natively**—TCF requires CMP registration with IAB Europe and Global Vendor List integration. For TCF, commercial CMPs (Cookiebot, OneTrust, Usercentrics) are necessary.

Performance impact is measurable: DebugBear testing shows INP (Interaction to Next Paint) at 75th percentile ranges from 26ms (Usercentrics) to 241ms (Cookiebot). Cookie banners can become the LCP element on mobile, and top-of-screen banners cause CLS. Best practices: use overlay positioning, geo-target banners to jurisdictions where legally required, and yield to the browser after the "Accept" click.

---

## 6. Privacy impact assessments are automatable from code scanning to approval gates

The most production-ready **open-source PIA tool** is **CNIL's PIA Software** (github.com/LINCnil/pia, 285 stars, Angular frontend + Rails backend). It implements the CNIL's step-by-step GDPR DPIA methodology with contextual knowledge bases, risk visualization, customizable templates, and PDF export in 14+ languages. The City of Amsterdam provides a Docker deployment (github.com/Amsterdam/pia-docker).

Published templates from regulators include: **ICO's DPIA template** (7-step Word document), **CNIL's detailed questionnaire-format templates**, the **OPC's PIA Guide** (aligned to PIPEDA's 10 Fair Information Principles), and **BC OIPC's private-sector PIA template and guidance** released on Data Privacy Day 2020 at oipc.bc.ca/documents/guidance-documents/2245.

For **engineering automation**, **TerraTrue** offers the strongest Jira integration: bi-directional sync creates privacy "launches" when Jira issues are created, screening questions auto-trigger full PIA workflows (e.g., "Will new types of data be collected?"), and completion posts back to Jira as labels. Features cannot deploy until PIAs are approved.

**Privado AI** provides an open-source code scanner that detects personal data flows by analyzing source code, auto-identifies data elements (email, location, financial, health), maps all third parties receiving data, and generates data flow diagrams from actual code. It syncs findings to OneTrust and TrustArc. **Relyance AI** (used by Coinbase, Notion, Canva) provides continuous code monitoring with "Data Journeys" tracing data from source code to cloud to AI models, and auto-fills DPIA/TIA/LIA templates from code analysis.

A PIA-as-code CI/CD gate pattern:

```yaml
privacy-review:
  stage: compliance
  script:
    - privado scan ./src --output json
    - python check_pia_status.py --project $CI_PROJECT_ID
  rules:
    - if: '$CI_MERGE_REQUEST_LABELS =~ /new-data-collection/'
    - if: '$CHANGED_FILES =~ /models\/.*\.py$/'
  allow_failure: false  # Block merge if PIA incomplete
```

Specific PIA requirements vary by data type: **health data processing** always mandates a DPIA under GDPR Article 35(3)(b), with consultation of affected data subjects encouraged. **Employee monitoring** requires DPIA because employees are vulnerable data subjects with power imbalances. **Financial profiling** triggers Article 35(3)(a) for systematic evaluation with legal effects. **Cross-border transfers** (Canada → US, Canada → EU) require documenting all flows, identifying legal transfer mechanisms, and conducting Transfer Impact Assessments for SCCs/BCR transfers.

---

## 7. BC PIPA creates unique obligations for employee data that exceed PIPEDA

BC PIPA applies to all **380,000+ provincially-regulated private sector organizations** in BC. For a Victoria SaaS company, BC PIPA governs intra-BC operations and employee data, while PIPEDA applies concurrently to interprovincial and international transactions. The company must comply with both simultaneously.

The most critical difference is **employee data consent**: BC PIPA allows collection, use, and disclosure of employee personal information **without consent** if reasonable for establishing, managing, or terminating employment (ss. 13, 16, 19)—but **advance notice is mandatory** including purposes. PIPEDA, by contrast, generally requires consent for employee data of federally-regulated employers.

**Employee monitoring under BC PIPA** faces a high bar. OIPC BC Investigation Report F15-01 (District of Saanich) found that keystroke logging, automated screenshots at 30-second intervals, and continuous activity tracking **clearly exceeded** authorized purposes. Order P12-01 (Schindler Elevator) allowed GPS tracking only for employee safety and billing in context-specific circumstances—continuous tracking outside work hours would not be authorized. Video surveillance is permitted only as a **last resort** after exploring less privacy-invasive alternatives.

For **biometric data**, BC PIPA applies a five-factor proportionality test: sensitivity of the biometric information, quality of employer protections, legitimacy of business objectives, availability of alternative methods, and proportionality of privacy loss versus business benefit. The 2020 Special Committee recommended defining biometric and medical data as sensitive categories requiring explicit consent, aligning BC PIPA closer to GDPR.

**BC PIPA is the only Canadian private-sector privacy law still lacking mandatory breach notification.** Under PIPEDA, breach notification has been mandatory since November 2018 with "real risk of significant harm" threshold, reporting to OPC "as soon as feasible," individual notification, and **24-month record-keeping of all breaches**. BC PIPA breach reporting remains voluntary, though OIPC BC strongly recommends it and the Commissioner has publicly called for legislative amendment.

The **AggregateIQ investigation** (P19-03) is directly relevant—a Victoria-based tech company found to have inadequate security measures while processing personal information of tens of millions across four continents. The **Clearview AI joint investigation** confirmed that provincial privacy laws apply to any organization collecting personal information of individuals within the province, regardless of where the organization is located.

For GDPR interaction, OIPC BC's March 2018 guidance document "Competitive Advantage: Compliance with PIPA and the GDPR" identifies key gaps: GDPR does not permit opt-out consent, adds rights to erasure and data portability not in PIPA, requires 72-hour breach notification, classifies health and biometric data as special categories requiring explicit consent, and mandates DPIAs for high-risk processing. Canada currently has EU adequacy status, meaning data transfers between BC and the EU face fewer restrictions.

**B2B contact information** (name, title, business address, business phone) is explicitly excluded from the definition of "personal information" under BC PIPA section 1, which simplifies compliance for B2B contact data.

---

## 8. Published engineering patterns from major companies provide battle-tested blueprints

**Shopify's "Deleting the Undeletable"** blog post describes their schematization platform processing tens of billions of Kafka events per day with **4,500+ active schemas**, each containing a `privacy_setting` section specifying data controller, data subject, and per-field privacy blocks. They obfuscate IP addresses to first two octets plus geo enrichment, reduce user agents to aggregate device/OS metadata, and tokenize PII before it enters the data warehouse. The key insight: make privacy-aware event schemas the default easy path while requiring tedious approvals for unstructured events.

**Stripe's Card Data Vault (CDV)** runs in a completely isolated AWS environment with a dedicated team—access restricted to a small number of specially trained engineers, reviewed quarterly. All card numbers are encrypted with **AES-256**, and PANs are tokenized internally so no Stripe service can obtain plaintext card numbers. Services can only request cards be sent to allowlisted providers.

**Airbnb's Data Protection Platform** is the most comprehensive published architecture, with five components: **Inspekt** (automated PII classification scanning data stores continuously), **Angmar** (secret detection with pre-commit Git hooks), **Cipher** (centralized encryption service using AWS KMS with "no more, no less" access policies), **Obliviate** (GDPR DSR orchestration), and **Madoka** (metadata system tracking security/privacy posture across all data assets via daily crawlers of GitHub, MySQL, S3, and Inspekt).

**Meta's Privacy Aware Infrastructure** represents the most sophisticated approach at scale. Their evolution from point checking (if-statement controls) → data lineage → **Information Flow Control via Policy Zones** provides runtime enforcement of purpose limitation. Policy Zones encapsulate, evaluate, and propagate privacy constraints for data both in transit and at rest, integrated with HHVM, Presto, and Spark. The system handles **trillions of user consent checks per hour** and multiple petabytes per hour through stream processing.

**Google's differential privacy libraries** (github.com/google/differential-privacy) are the most production-ready open-source DP option, with C++, Java, Go, and Python implementations. **Privacy on Beam** provides end-to-end DP for Apache Beam distributed processing with automatic per-user contribution bounding. **DP-Auditorium** audits DP guarantees via black-box access. Google's shuffler model—between local and central DP—powers a **3-billion-device deployment** across Google Home, Google Trends, and Google Maps.

**Apple's local differential privacy** implementation exclusively randomizes data on-device before transmission, with per-event epsilon values of 1 or 2, daily transmission limits, and immediate discarding of IP identifiers and cross-record associations at the server. Academic analysis found overall daily privacy loss of ε=16 across four applications.

Cross-cutting patterns from all companies: **data classification is foundational** (every company starts with automated discovery), **centralized encryption services** prevent teams from rolling their own crypto, **schema-level privacy annotations** encode requirements at development time, and privacy must be the **path of least resistance** for developers to achieve adoption.

---

## 9. Data retention across polyglot persistence needs a central orchestrator with store-specific adapters

The recommended architecture is a **central retention policy engine** with store-specific adapters, policy-as-code definitions (OPA/Rego or YAML), and event-driven deletion cascades via Kafka.

**PostgreSQL:** pg_partman is the primary mechanism for retention at scale. Configure `retention = '3 months'` with `retention_keep_table = false` to DROP partitions entirely—near-instantaneous compared to row-by-row DELETE. Use pg_cron for scheduling: `SELECT cron.schedule('partman-maintenance', '0 * * * *', 'SELECT partman.run_maintenance()')`. For non-partitioned tables, batched DELETEs with `pg_try_advisory_lock` prevent concurrent deletion conflicts.

**MongoDB:** Native TTL indexes auto-expire documents: `db.sessions.createIndex({ "createdAt": 1 }, { expireAfterSeconds: 2592000 })`. The TTL monitor runs approximately every 60 seconds. Partial TTL indexes can target only documents matching a filter (e.g., `state: 'TMP'`). Critical caveat: the field must be BSON Date type—strings formatted as dates are silently ignored.

**Redis:** Every key should have an explicit TTL via `EXPIRE` or `SET ... EX`. For GDPR deletion, use `SCAN 0 MATCH user:12345:*` followed by `UNLINK` (async deletion). Keyspace notifications (`CONFIG SET notify-keyspace-events Ex`) can trigger downstream deletion cascades, but Redis Pub/Sub is fire-and-forget—missed events during disconnection are lost.

**Kafka:** Short retention periods (≤28 days) auto-expire data within the GDPR response window. For longer-lived topics, **crypto-shredding** is the standard: encrypt PII fields with per-user DEKs using AES-128-GCM or AES-256-GCM, store Encrypted DEKs (EDEKs) in a compacted key topic, and on erasure, publish tombstone records for the user's EDEK. After compaction, the DEK is unrecoverable and all encrypted data becomes permanently unreadable. Kafka headers can carry PII classification metadata: `record.headers().add("pii-classification", "SENSITIVE".getBytes())`.

**S3:** Lifecycle policies with object tagging (e.g., `data-class: PII`, `retention-days: 90`) handle automated expiration. S3 Object Lock provides legal hold capability—in Compliance mode, nobody including root can delete until retention expires. Legal holds have no expiration and persist until explicitly removed. Object Lock **overrides** lifecycle expiration rules.

**Elasticsearch:** ILM policies define phase transitions (hot → warm → delete) with configurable retention periods. For targeted GDPR deletion, `_delete_by_query` removes specific user documents, followed by `_forcemerge?only_expunge_deletes=true` to reclaim space.

**Legal holds** must override all automated deletion. Every retention adapter must check a legal hold registry before deleting. The hold schema should include `hold_id`, `case_reference`, `status`, user scope, date range, and data types. S3 Object Lock provides native legal hold; for databases, add a `legal_hold BOOLEAN` column checked by retention jobs.

**Deletion audit trails** must record every deletion action without containing the deleted PII—only references (subject IDs, timestamps, record counts, store names). Store audit logs in an immutable, append-only system (S3 with Object Lock in Compliance mode). Hash each deletion record and chain hashes for tamper evidence.

For **data lineage**, **DataHub** (10,000+ stars, column-level lineage, 100+ connectors) is recommended as the foundation for lineage-driven deletion. The pattern: retention service queries DataHub API for all datasets containing a user's data, dispatches deletion to each store adapter, and generates a deletion certificate once all stores confirm.

---

## 10. Cross-regulation harmonization demands a highest-common-denominator baseline with jurisdiction-specific overlays

The recommended strategy is a **five-layer compliance architecture**: GDPR as the base layer (covers ~80% of all requirements), plus CCPA overlay (GPC detection, "Do Not Sell/Share," service provider classification), CASL overlay (express consent tracking with expiry for CEMs), PIPEDA/BC PIPA overlay (express consent for sensitive data, cross-border safeguards), and ePrivacy overlay (cookie consent with real blocking before non-essential cookies).

**Global Privacy Control (GPC)** signal detection is mandatory under CCPA/CPRA and Colorado/Connecticut laws. The signal operates at two layers: HTTP header (`Sec-GPC: 1`) and JavaScript API (`navigator.globalPrivacyControl`). Server-side detection in Express.js: `req.header('Sec-GPC') === "1"`. Host `.well-known/gpc.json` to declare support. California AG has explicitly stated ignoring GPC signals is a violation. Approximately **40 million users** now use GPC-enabled browsers.

For **multi-tenant privacy isolation**, a hybrid approach is recommended: shared database with PostgreSQL Row-Level Security for standard tenants, dedicated schema or database for enterprise/regulated tenants, and always database-per-tenant with per-tenant encryption keys for health/financial data. RLS implementation: `CREATE POLICY tenant_isolation_policy ON orders USING (tenant_id = current_setting('app.current_tenant')::uuid)` with `FORCE ROW LEVEL SECURITY` to enforce even for table owners.

The **CI/CD privacy gate pipeline** should include: Gitleaks for secret scanning, Presidio Action for PII pattern detection, Checkov with custom policies for IaC privacy scanning (encryption at rest, no public S3 buckets, TLS enforcement), database migration privacy checks (new tables have `tenant_id`, RLS policies exist), and PIA gate checks that block merges when new data categories are detected without an approved PIA.

For **payment data**, delegate to Stripe as a PCI-compliant sub-processor—client-side tokenization via Stripe Elements ensures sensitive card data never touches your servers, reducing PCI scope dramatically. Store only Stripe customer IDs and payment method tokens, never raw PANs. Document Stripe in your Record of Processing Activities and maintain a DPA.

For **health and biometric data**, all regulations converge on requiring express consent, enhanced encryption (AES-256 at rest, TLS 1.2+ in transit, field-level encryption for identifiers), access controls with MFA, and comprehensive audit logging. GDPR Article 9 explicitly classifies these as special category data requiring DPIA. PIPEDA mandates breach reporting for biometric data breaches, which almost always meet the "real risk of significant harm" threshold.

---

## Conclusion: building privacy engineering from scratch requires tooling choices, not just policies

A greenfield BC SaaS company has a significant advantage: the ability to embed privacy into the architecture from day one rather than retrofitting. The most impactful first moves are: **(1)** adopt Ethyca Fides for DSR orchestration and privacy taxonomy annotation of all data schemas, **(2)** deploy Microsoft Presidio in CI/CD via GitHub Actions alongside detect-secrets and Gitleaks for layered PII/secret scanning, **(3)** build a CASL consent tracking system with the schema design outlined above (no open-source shortcut exists), **(4)** implement crypto-shredding for Kafka using envelope encryption with per-user DEKs and HashiCorp Vault, and **(5)** fork GitHub's `awesome-copilot` GDPR SKILL.md as the baseline AI coding agent ruleset.

The ecosystem is maturing rapidly but remains fragmented. Meta's journey from point checking to information flow control confirms that **privacy enforcement must be architectural, not procedural**—runtime IFC scales where manual audits fail. Airbnb's five-component Data Protection Platform and Shopify's schema-level privacy annotations demonstrate that the companies succeeding at privacy engineering treat it as a first-class infrastructure concern on par with observability or security. For a company processing data across six regulatory jurisdictions and six persistence technologies, there is no shortcut: privacy must be a platform capability, not an afterthought layered on top.