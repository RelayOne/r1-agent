# Prompt caching economics for multi-turn agentic coding

**Prompt caching is the single largest cost lever in agentic coding, cutting input token costs by 41–90% when implemented correctly.** A typical 20-turn coding session on Claude Sonnet costs $0.50–$1.50 with effective caching versus $2.50+ without it. The economics hinge on a strict prefix-matching cache hierarchy — tools → system → messages — where any change at one level invalidates all subsequent levels. Mastering this hierarchy, combined with intelligent model routing and progressive context compaction, can reduce total agentic coding costs by up to 95%. This report synthesizes official Anthropic documentation, academic research, open-source tooling, and real-world usage data to provide a complete optimization playbook.

---

## 1. Anthropic's caching mechanics dictate every optimization decision

Anthropic's prompt caching stores pre-computed KV attention tensors from the prefill phase, allowing identical prompt prefixes to be reused across API requests. The economics are straightforward: **cache reads cost 10% of the base input price** (a 90% discount), while cache writes carry a 25% surcharge for the standard 5-minute TTL or a 100% surcharge for the 1-hour TTL. The cache breaks even after a single reuse at the 5-minute tier and after two reuses at the 1-hour tier.

**Current pricing per million tokens (April 2026):**

| Model | Base Input | Cache Write (5 min) | Cache Write (1 hr) | Cache Read | Output |
|-------|-----------|-------------------|-------------------|------------|--------|
| Opus 4.6/4.5 | $5.00 | $6.25 | $10.00 | $0.50 | $25.00 |
| Sonnet 4.6/4.5/4 | $3.00 | $3.75 | $6.00 | $0.30 | $15.00 |
| Haiku 4.5 | $1.00 | $1.25 | $2.00 | $0.10 | $5.00 |
| Haiku 3.5 | $0.80 | $1.00 | $1.60 | $0.08 | $4.00 |

The **minimum cacheable size varies by model**: 1,024 tokens for Sonnet 4.5/4 and Opus 4.1/4, 2,048 tokens for Sonnet 4.6 and Haiku 3.5/3, and 4,096 tokens for Opus 4.6/4.5 and Haiku 4.5. Content below these thresholds silently skips caching with no error. The default **5-minute TTL refreshes on every cache hit** at no additional cost, keeping heavily-used prefixes alive indefinitely during active sessions. You can specify 1-hour TTL with `"ttl": "1h"` in the `cache_control` object — useful for agentic workflows where sub-agents may take longer than 5 minutes between turns.

Each request supports **up to 4 cache breakpoints** via `cache_control: {"type": "ephemeral"}` markers. The cache processes content in a fixed hierarchy: tools → system → messages. Changes at any level invalidate that level and everything below it. Changing tools busts the entire cache. Changing the system prompt preserves the tools cache but invalidates system and messages. Changing `tool_choice`, toggling images, or non-deterministic JSON key ordering in tool definitions also trigger full invalidation. Extended thinking parameter changes invalidate message-level caches but preserve tools and system caches.

A critical nuance: the system checks up to **20 content blocks backward** from each explicit breakpoint for prefix matches. For prompts exceeding 20 blocks, additional breakpoints are necessary. Breakpoints themselves carry no cost — you only pay for actual cache writes and reads.

---

## 2. Cache-aligned prompt construction follows a strict layering pattern

The optimal architecture splits every API request into five layers, ordered from most stable to most dynamic. This exploits the prefix-matching mechanism to maximize reuse.

**Layer 1 — Tool definitions (cached, breakpoint 1).** All tool schemas, sorted deterministically by name. This layer changes least often and sits first in the cache hierarchy. A critical anti-pattern discovered in production: MCP's `listTools()` does not guarantee order, so unsorted tool arrays bust the cache on every turn. The fix is trivial — `tools.toSorted((a, b) => a.name.localeCompare(b.name))` — but missing it means zero cache hits.

**Layer 2 — Static system prompt (cached, breakpoint 2).** Base instructions, skill definitions, safety policies, few-shot examples, and provider-specific guidance. This content is identical across all turns and often across different tasks. Place `cache_control` on this block.

**Layer 3 — Dynamic system prompt (not cached).** Environment metadata (working directory, OS, timestamps), session-specific context. This content changes per-session and sits after the cached prefix, so it never invalidates the layers above.

**Layer 4 — Conversation history (incrementally cached, breakpoints 3–4).** Previous turns and tool results. Using automatic caching (top-level `cache_control`), the breakpoint advances forward as the conversation grows, incrementally caching the expanding history.

**Layer 5 — Current user message (never cached).** The task-specific input that changes every turn.

The academic paper "Building AI Coding Agents" (arXiv 2603.05344) describes a `PromptComposer` with a `compose_two_part()` method implementing exactly this split. Sections annotated as cacheable (base instructions, tool descriptions, safety policy) form the stable part with `cache_control`, while dynamic sections (environment metadata, session context) form the uncached suffix. This achieves roughly **88% reduction in input token cost** for the cached portion across a multi-turn session.

**Available open-source tooling** includes the `prompt-caching-mcp` npm package (by flightlesstux) which automatically injects cache breakpoints for Claude Code, Cursor, and MCP clients; Vercel's AI SDK with `addCacheControlToMessages()` for provider-agnostic caching; Spring AI with five built-in caching strategies (SYSTEM_ONLY, TOOLS_ONLY, AUTO, etc.); and LiteLLM which translates Anthropic's cache format across providers. No npm packages named "promptcache," "microcompact," or "ctxpack" by "Stoke" were found — "microcompact" exists only as Claude Code's internal compaction strategy, not as a published package.

---

## 3. Token economics reveal quadratic cost growth tamed by caching

A typical agentic coding session exhibits a distinctive cost pattern: **input tokens dominate overwhelmingly**, growing quadratically as the full conversation history is re-sent with each turn. Real-world Claude Code usage data shows **over 90% of all tokens are cache reads**, with cache writes at ~6% and actual uncached input and output tokens under 1% combined.

The ICLR 2026 paper "How Do Coding Agents Spend Your Money?" found that **60–80% of tokens go toward orientation** — reading files and understanding codebase structure — not solving the actual problem. A 1,000-line code file tokenizes into roughly 10,000+ tokens, and MCP tool metadata alone can consume 40–50% of the context window.

**Cost scaling by complexity tier:**

- Simple tool-calling agents: **5,000–15,000 tokens** per task (~$0.02–$0.05 on Sonnet)
- Standard coding tasks (10–20 turns): **100,000–500,000 tokens** (~$0.50–$1.50 with caching)
- Complex multi-agent workflows: **200,000–1,000,000+ tokens** ($1–$5+)
- SWE-bench style problems: **1–3.5 million tokens** average ($1–$10 depending on model)

For a concrete 20-turn session on Claude Sonnet 4.6, assume a 5,000-token system prompt cached from turn 1, with each turn adding ~3,000 tokens of tool results and assistant responses. By turn 20, the conversation history reaches ~60,000–100,000 tokens. Without caching, cumulative input tokens total roughly 630,000 at $3/MTok = $1.89 input plus ~$0.60 output = **~$2.50 total**. With effective caching reducing input costs by 70–80%, the same session costs **$0.50–$1.50**. An important threshold: if input exceeds **200,000 tokens**, Anthropic doubles the input price ($3→$6/MTok for Sonnet), making compaction essential before crossing this boundary.

SWE-bench cost data provides useful benchmarks: Claude Opus 4.5 costs **$1.15 per problem**, Claude Sonnet 4.5 costs **$0.98**, while efficient models like MiniMax M2.5 achieve comparable accuracy at **$0.07–$0.09 per problem**. Epoch AI's evaluation methodology limits each problem to 2M uncached tokens and 20M cached token reads.

---

## 4. Three-tier progressive compaction prevents context overflow

When conversation history grows beyond the context window, Claude Code employs an internally documented **three-tier escalating compaction pipeline**, each tier more aggressive and expensive than the last.

**Tier 1 — Microcompact (zero LLM cost).** This runs before every API call with negligible latency. It targets individual tool results — the highest-volume context consumers — clearing content from "compactable" tools while preserving the record that calls happened. A cached variant uses Anthropic's context editing API to delete tool results server-side without invalidating the prompt cache. When registered tools exceed a trigger threshold, the oldest results beyond a `keepRecent` count are queued for deletion.

**Tier 2 — Session memory compact (moderate cost).** Triggered automatically when context reaches approximately **95% capacity**. Clears older tool outputs first, then generates a structured summary preserving: the goal, active instructions, key discoveries, and accomplished tasks. This uses a lightweight LLM call.

**Tier 3 — Full compact (highest cost).** Spawns a separate LLM call that receives the entire message history and produces a comprehensive structured summary with seven mandatory sections: primary request and intent, key technical concepts, files and code sections, errors and fixes, current state and next steps, outstanding questions, and working hypotheses. This replaces the original messages entirely.

The OpenDev project (arXiv 2603.05344) implements a complementary **five-stage progressive model** that emphasizes delaying expensive LLM summarization: warning at 70% capacity, observation masking at 80%, fast pruning at 85%, aggressive masking at 90%, and full LLM compaction only at 99%. JetBrains research found that observation masking (hiding old tool outputs without LLM involvement) **matched LLM summarization in both cost savings and problem-solving ability** after tuning the masking window.

**Practical priority hierarchy for what to preserve:**

- **Always keep:** System prompt, CLAUDE.md, current task instructions, last 2–5 user turns
- **Summarize:** Older conversation history, completed subtask results, architectural decisions
- **Move to external memory:** Facts, findings, progress notes (CLAUDE.md, MEMORY.md files)
- **Drop first:** Old tool results (re-fetchable), thinking blocks, verbose command outputs

A notable alternative from Will Larson: messages exceeding 10K tokens become "virtual files" with only the first 1K tokens in context; the agent uses file tools to read more when needed. Community best practice suggests compacting at **60% capacity rather than 95%** to maintain higher quality context throughout the session.

---

## 5. Maximizing cache hit rates requires disciplined prompt engineering

The paper "Don't Break the Cache" (arXiv 2601.06007) evaluated 500+ agent sessions and found prompt caching reduces costs by **41–80%** with TTFT improvements of 13–31%. The key insight: **system-prompt-only caching provides the most consistent benefits**, while full-context caching can paradoxically increase latency because dynamic tool calls trigger cache writes for content that won't be reused.

The recommended **4-breakpoint strategy** places breakpoints at: (1) last tool definition, caching all tool schemas; (2) static system prompt, cached independently from tools; (3) RAG/context documents that update less frequently; (4) conversation history via automatic caching that advances the breakpoint forward each turn.

**Five cache-busting anti-patterns to avoid:**

- Dynamic timestamps in system prompts — move these to user messages or a dynamic system section after the cached prefix
- Non-deterministic tool ordering — sort tools alphabetically on every turn
- Changing `tool_choice` between turns — invalidates the entire cache
- Adding or removing images anywhere in the prompt — full invalidation
- Parallel first requests — race condition where none benefit from cache; use a "cache warming" call first

For cross-task cache sharing, design the system prompt to be **task-generic** and place task-specific instructions in user messages. This means all tasks sharing the same tool set and system prompt benefit from the same cached prefix. Use the 1-hour TTL for content shared across longer workflows, keeping in mind that longer-TTL entries must appear before shorter-TTL entries in the same request. Monitor the API response fields `cache_creation_input_tokens` (should be 0 after turn 1) and `cache_read_input_tokens` (should grow each turn). Target a **cache hit rate above 80%** after the first turn.

---

## 6. CLI subprocess spawning destroys caching benefits

This is one of the most consequential architectural decisions for cost. According to Claude Code team engineer Thariq Shihipar, **prompt caching is the architectural constraint around which Claude Code is designed** — they declare SEVs when cache hit rates drop. Native Claude Code sessions achieve **90–96% cache hit rates**.

However, when external tools shell out to Claude Code CLI with a fresh process per message (using flags like `--max-turns 1` and `-p`), caching **completely breaks**. Each process spawns a new session with fresh metadata and dynamic headers (`cc_version`, `cch` values) that differ between invocations. Since the prefix changes every time, `cache_read_input_tokens` and `cache_creation_input_tokens` are always zero. Cline's GitHub Discussion #9892 documents this problem in detail.

**The cost difference is stark.** A 100-turn Opus session with 90% cache hits costs ~$10–19 in input tokens. The same session with 0% cache hits (one-shot CLI subprocess) costs $50–100. That is a **5–10× cost penalty** for an architectural choice that appears functionally identical.

Two solutions exist: use `--resume <session_id>` with `-p` mode so subsequent calls resume the same session and maintain an identical prefix for cache hits, or keep a long-running CLI process alive and pipe messages incrementally. For maximum control and cost efficiency, **call the Anthropic API directly** with explicit `cache_control` breakpoints rather than going through the CLI. Direct API usage provides full control over cache breakpoint placement, deterministic prompt construction, and 90%+ hit rates.

---

## 7. Batch API stacks with caching for up to 95% input savings

Anthropic's Batch API provides a confirmed **50% discount on both input and output tokens**, processing requests asynchronously with most batches completing within 1 hour (maximum 24 hours). Any request valid for the Messages API — including tool use, extended thinking, and vision — can be batched.

The discounts stack multiplicatively. For Claude Sonnet 4.6: standard input costs $3/MTok; batch input costs $1.50/MTok; batch + cache read costs **$0.15/MTok** — a 95% reduction from standard pricing. This makes batch processing ideal for non-interactive agentic workloads.

**Strong use cases for batch in agentic coding** include code review passes across multiple files, test generation for a batch of functions, documentation generation, security audit scans, evaluation/benchmarking runs, and verification passes where results don't need to be immediate. The key constraint is the 24-hour processing window — each batch must complete within this window or requests expire.

**Practical limitations:** no streaming, results not guaranteed in submission order (use `custom_id` to match), 100,000 request or 256 MB size limit per batch, not eligible for Zero Data Retention, and processing may slow during high demand. For agentic workflows using batch, the 1-hour cache TTL is recommended over the 5-minute default, since batch processing timelines often exceed 5 minutes. Combine batch submissions by grouping requests that share the same prompt prefix to maximize cache reuse within the batch.

---

## 8. Multi-model routing saves 40–60% by matching task complexity to model tier

Claude Code already implements model routing through its subagent architecture. **Explore subagents run on Haiku by default** for read-only file discovery, codebase search, and pattern matching — handling roughly 34 million runs per week internally at Anthropic. Complex tasks inherit the parent model (Sonnet or Opus). The `opusplan` mode uses Opus for planning and Sonnet for execution, applying expensive reasoning only where it matters.

**Task routing decision framework:**

| Route to Haiku ($1/MTok in) | Route to Sonnet ($3/MTok in) | Route to Opus ($5/MTok in) |
|-----|------|------|
| File search and discovery | Standard code generation | Complex architecture design |
| Code classification | Bug fixes and features | Large codebase refactoring |
| Test result summarization | Code review | Security audits |
| Linting and formatting | Documentation | Multi-agent orchestration |
| Metadata extraction | Analysis and explanation | Novel algorithm design |

The open-source **RouteLLM** framework (LMSYS/UC Berkeley) achieves up to 85% cost reduction on benchmarks while maintaining 95% of frontier model performance. It routes between strong and weak models using trained classifiers (matrix factorization, BERT, causal LLM). **Cascade routing** (ETH Zurich, NeurIPS 2025) combines routing with cascading — try the cheap model first, escalate on low confidence — and outperforms either approach alone by up to 14%.

A practical **70/20/10 split** — routing 70% of requests to Haiku, 20% to Sonnet, 10% to Opus — cuts costs by roughly **60% compared to all-Sonnet**. The key insight from multiple sources: a well-prompted Sonnet consistently beats a lazily-prompted Opus. Invest in prompt engineering before upgrading model tiers. Note that **switching models mid-session invalidates the entire cache** since KV caches are model-specific, so commit to a model for each session or subagent.

---

## 9. Token auditing requires instrumentation at the API response level

Anthropic's API response includes four token fields that form the foundation of any cost attribution system: `input_tokens` (uncached), `cache_read_input_tokens` (cache hits), `cache_creation_input_tokens` (cache writes), and `output_tokens`. These should be captured on every API call and tagged with business dimensions: user, task, tool name, skill injection, session, and mission.

**No package called "costtrack" exists**, but several alternatives provide immediate value. **`toktrack`** (npm) is a Rust-based CLI dashboard tracking costs across Claude Code, Codex CLI, and Gemini CLI with daily/weekly/monthly views — install with `npx toktrack`. **`ai-cost-tracker`** provides per-user, per-feature attribution with SQLite storage. **`llm-cost`** handles token counting and cost estimation across providers. For Python, **`tokencost`** by AgentOps-AI covers 400+ models.

For production observability, **Helicone** offers 1-line proxy integration with built-in caching and 300+ model pricing. **Langfuse** provides open-source trace-level cost breakdowns with self-hosting. **LiteLLM** acts as a proxy with per-key/user/team cost tracking and budget enforcement. Anthropic's own **Usage & Cost Admin API** provides token consumption at 1-minute/1-hour/1-day granularity, filterable by API key, workspace, model, and context window size, plus USD cost breakdowns including web search and code execution costs.

**The metrics that matter most** for cost optimization are: cache hit rate (target >80%), cost per task completion (enables ROI analysis), tokens per tool call (identifies expensive tools), compaction frequency (indicates workflow efficiency), and the ratio of orientation tokens to problem-solving tokens (60–80% orientation suggests opportunity for better context injection). Track compaction calls separately — compaction itself has a cost that should be attributed to the task that triggered it.

---

## 10. Real-world costs: $6/day average, with massive variance

Anthropic reports the **average developer spends approximately $6/day** on Claude Code, with 90% of users staying below $12/day. But averages hide enormous variance. One well-documented heavy user (Kyle Redelinghuys) consumed roughly 10 billion tokens over 8 months, with API-equivalent costs of **$15,000+** versus ~$800 in Max subscription fees — a 93% savings from the subscription model. His busiest day involved 8,930 messages and 2,169 tool calls across 9 sessions.

**Cost scaling with usage intensity:**

- Light usage (1–2 sessions/day, <30 min): $2–5/day API, ~$50–100/month
- Moderate usage (3–5 hours/day): $6–12/day, ~$100–200/month on Sonnet
- Heavy usage (all day, complex projects): $20–50+/day, $400–2,000/month
- Power usage with Opus + Agent Teams: $2,000+/month on API

The token usage variance is surprisingly high. The ICLR 2026 study found **some runs use 10× more tokens than others for identical tasks**, with prediction of total consumption nearly impossible (Pearson's r < 0.15). Cost scaling with codebase size is driven primarily by orientation costs — a code knowledge graph tool (CartoGopher) demonstrated **40–55% token savings on real-world code changes** and 70–95% on comprehension questions by reducing file-reading overhead.

The price trajectory strongly favors patience and optimization. Opus pricing dropped from $15/$75 (Opus 4.1) to $5/$25 (Opus 4.5/4.6) — a **67% reduction** while capability improved. The combined optimization stack — prompt caching (41–80% savings) + model routing (40–60% savings) + batch processing (50% savings) + context compaction (preventing the 200K token price doubling) — makes it possible to run sophisticated agentic coding workflows at a fraction of naive API costs.

---

## Conclusion: the optimization stack compounds

The most important insight is that these optimizations are **multiplicative, not additive**. Prompt caching alone saves 41–80%. Adding intelligent model routing saves another 40–60% on top. Batch processing for non-interactive passes cuts remaining costs in half. Combined, a well-optimized system can achieve 95% cost reduction compared to naive API usage.

Three architectural decisions dominate the cost picture. First, never spawn one-shot CLI subprocesses — the 5–10× cost penalty from lost caching dwarfs all other inefficiencies. Second, invest in the prompt layering hierarchy (static tools → static system → dynamic system → history → current message) before anything else. Third, implement progressive compaction starting with zero-cost observation masking before resorting to expensive LLM summarization.

The field is moving toward a convergence point: Haiku-class models handle exploration and classification, Sonnet handles the bulk of coding, and Opus-class models are reserved for architectural reasoning and planning — all unified by aggressive prefix caching and intelligent context management. As model prices continue their steep decline and caching infrastructure matures, the marginal cost of agentic coding is dropping toward levels where token economics become a solved problem rather than a binding constraint.