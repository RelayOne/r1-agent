# Maximizing AI coding agent instruction following within token budgets

**Injecting fewer, sharper skills produces better results than loading everything.** A March 2026 study of 55,315 public skills found that compressing skill descriptions by 48% and bodies by 39% actually *improved* functional quality by 2.8% — a counterintuitive "less-is-more" effect driven by reduced attention dilution. Anthropic's own internal testing confirms this: loading all available tools drops Opus 4 accuracy to 49%, while dynamically selecting just 3–5 relevant tools per request lifts it to 74%. For a system selecting from 51 skills, the architecture that emerges from current research is clear: load only metadata at startup, inject full content for 2–3 top-ranked skills within a **3–5K token budget**, structure everything in XML within the system prompt, and cache aggressively. Every major coding agent — Claude Code, Cursor, Codex CLI, GitHub Copilot — has converged on this progressive disclosure pattern.

---

## Where to place skills: system prompt wins for persistence, user message wins for adherence

The placement question has a nuanced answer backed by Anthropic's own senior prompt engineer. Zack Witten stated at the AI Engineer 2024 Conference that **Claude follows instructions slightly better when placed in the user message** rather than the system prompt. His practice is to put only the role definition ("you are this") in the system prompt and move detailed instructions into the user turn. The exception is tool definitions, where system-prompt fine-tuning may provide a stronger signal.

This creates a tension for skill injection. System prompts persist across turns without re-sending, enable prompt caching (90% cost reduction), and provide stronger resistance to prompt injection overrides. User messages get higher instruction-following fidelity but must be re-sent each turn. The practical resolution most production systems adopt: place the stable skill block in the system prompt for caching and persistence, then **repeat the 2–3 most critical rules as a reminder at the end of the user message**, exploiting the recency effect. HumanLayer's analysis of Claude Code confirms this: "LLMs bias towards instructions on the peripheries of the prompt — at the very beginning (system message and CLAUDE.md) and at the very end (most recent user messages)."

**Assistant prefill** — pre-populating the start of Claude's response — was historically useful for forcing output formats (starting with `{` for JSON). Anthropic notes that Claude 4.x models have improved enough that "most use cases of prefill no longer require it," making this technique less relevant for skill injection.

For practical skill injection architecture, the evidence points to a layered approach: role and behavioral frameworks in the system prompt (cached), task-specific skill content in the system prompt's dynamic section, and critical constraint reminders appended to the final user message.

---

## The attention degradation problem is worse than most builders assume

Liu et al.'s landmark 2023 paper "Lost in the Middle" demonstrated a **U-shaped performance curve**: LLMs perform best when relevant information sits at the beginning or end of the input context, with **30%+ accuracy drops for information positioned in the middle**. GPT-3.5-Turbo with relevant information in the middle performed worse than its closed-book baseline. This finding held across decoder-only models even when explicitly designed for long contexts. The paper was published in *Transactions of the Association for Computational Linguistics* (Vol. 12, 2024) and has been confirmed and extended by multiple follow-up studies.

Chroma's "Context Rot" research (July 2025) tested **18 frontier LLMs** including GPT-4.1, Claude 4, Gemini 2.5, and Qwen3. The finding was stark: **every single model gets worse as input length increases** — not just near the context limit but at every increment. A model with a 1M-token window still degrades at 50K tokens. The degradation compounds through three mechanisms: lost-in-the-middle positional bias, quadratic attention dilution (100K tokens creates 10 billion pairwise relationships), and distractor interference from irrelevant content.

A particularly striking finding from arXiv:2510.05381 shows that **even with perfect retrieval — 100% exact-match token recitation — performance still degrades 13.9%–85%** as input length increases across math, QA, and code generation tasks. Context length alone hurts, independent of retrieval quality.

For skill injection specifically, HumanLayer found that frontier thinking LLMs can follow approximately **150–200 instructions with reasonable consistency**. Smaller models exhibit exponential decay in instruction-following as instruction count grows; larger frontier thinking models exhibit **linear decay**. The practical implication: every instruction you add has a cost, even on the best models. The LIFBench benchmark (ACL 2025) confirmed that instruction-following performance degrades significantly with both context length and task complexity, with a compounded negative interaction between the two.

**Mitigation strategies that work**, ranked by evidence strength:

- **Position critical instructions at the very start and very end of context.** Anthropic's own testing shows queries placed at the end improve response quality by up to 30%.
- **Use XML tags as structural markers.** Claude was specifically trained to recognize XML tags as a prompt organizing mechanism, and they create unambiguous boundaries that help the model parse long prompts.
- **Extract quotes into a scratchpad before answering.** Anthropic found this technique combined with few-shot examples reduced errors by 36% on long-context recall tasks.
- **Repeat the most critical rules.** Place them in the system prompt AND as a reminder at the end of the user message.
- **Simply shorten the context.** Limiting input tokens improves performance even when retrieval is already perfect — the simplest and most reliable mitigation.

---

## The 3–5K token sweet spot for skill injection has strong empirical backing

Trail of Bits' `claude-code-config` repository (3.3K stars) and skills library represent the most mature public implementation of a skill injection system for coding agents. Their explicit guidance: **"Keep the SKILL.md lean (under 2,000 words)"** — approximately 2,500–3,000 tokens — and move detailed content into `references/` files loaded on demand. Their philosophy encodes a critical distinction: skills should teach Claude *how to think* about a category of work, not provide step-by-step scripts. They describe skills as "conventions, checklists, and decision frameworks that shape how Claude approaches work."

The SkillReducer paper (arXiv 2603.29919, March 2026) provides the most rigorous empirical data. Analyzing 55,315 publicly available skills, the researchers found that **over 60% of skill body content is non-actionable** — preamble, verbose explanation, and redundant context that dilutes the model's attention without improving behavior. Their compression pipeline achieved 48% description compression and 39% body token reduction while improving functional quality by 2.8% (Cohen's d = 0.107). The effect scales with body length: official skills with longer bodies saw **+11.8 percentage points improvement** after compression versus +1.1pp for shorter community skills.

Multiple data points converge on the danger zone. Claude Code itself generates a warning when MCP tools exceed **25,000 tokens**. Anthropic's engineering blog states that "tool selection accuracy degrades significantly once you exceed 30–50 available tools." One practitioner documented 66,000+ tokens consumed before typing anything with 12 MCP servers — 41% of the 200K context window. After optimization down to one MCP server, consumption dropped to 5,700 tokens (2.8%). The Anthropic Tool Search feature, which loads only 3–5 tools per request, achieved a **46.9% reduction in total agent tokens** (51K to 8.5K) during actual use.

The convergent recommendation across all sources: **system prompt plus core skills should total 3–5K tokens**. Total overhead (tools + skills + system prompt) should stay under 10% of the context window — Claude Code's default threshold for triggering tool search deferral. Beyond 20K tokens of static injected context, expect measurable degradation in both instruction-following and task performance.

---

## Progressive disclosure is now the industry-standard loading pattern

Every major coding agent has independently converged on the same architecture for skill loading, confirming it as the de facto standard. The pattern operates across three to five tiers:

Claude Code implements a clean three-level system. **Level 1** loads only skill name and description from YAML frontmatter (~100 tokens per skill) at session startup — a library of 20 skills adds roughly 2,000 tokens, negligible in a 200K window. **Level 2** loads the full SKILL.md content (<5K tokens) only when a skill is invoked by the user or when the model matches the description to the current task. **Level 3** loads resources (scripts, templates, reference docs) only during execution, and only the *output* enters context — source code never does.

OpenAI's Codex CLI mirrors this almost exactly: metadata at startup, full SKILL.md on decision to use. GitHub Copilot describes the identical pattern: "You can install many skills without consuming context. Copilot loads only what is relevant for each task." Cursor takes a slightly different approach with glob-based auto-attachment (rules trigger automatically when matching file patterns are touched) but still separates rule definition from rule application.

For implementing this in a 51-skill system, the architecture should work as follows. At session start, inject a compact skill registry — all 51 names and one-line descriptions — consuming approximately **5,000 tokens total**. When the user's task or file context triggers a match, load the full skill content for the top 2–3 matches. Use frontmatter flags like `disable-model-invocation: true` for skills with side effects (deployments, destructive operations) and `user-invocable: false` for background knowledge skills the model should discover autonomously.

One team reported a **~15% miss rate** where a relevant skill should have been used but wasn't. The fix: write clearer, keyword-rich descriptions that serve as "routing hooks." Teams with 50+ skills saw a 23% drop in correct skill selection; grouping into a maximum of 20 skills per domain with a meta-skill router restored 88% accuracy. This suggests that for 51 skills, a two-level hierarchy — domains containing skills — may outperform a flat list.

---

## Compression works best when it targets non-actionable content

The most effective compression is not algorithmic token reduction but **semantic pruning**: identifying and removing the 60%+ of skill content that doesn't influence model behavior. The SkillReducer taxonomy classifies skill body content into actionable categories (rules, constraints, gotchas, decision criteria) and non-actionable categories (background explanation, motivation, verbose examples). Removing the non-actionable content is the highest-leverage compression technique.

For algorithmic compression, Microsoft Research's **LLMLingua** family represents the state of the art. LLMLingua achieves up to **20x compression with only a 1.5 point exact-match drop** on GSM8K, using a small language model (GPT-2-small or LLaMA-7B) to identify unimportant tokens. LongLLMLingua extends this to long-context scenarios with query-aware compression, achieving 21.4% performance improvement with 4x fewer tokens on NaturalQuestions. LLMLingua-2 reformulates compression as token classification, running **3–6x faster** than the original. The compressed prompts are unreadable to humans but GPT-4 can recover all key reasoning information from them.

Symbolic compression (MetaGlyph, 2025) achieves **62–81% token reduction** using metalanguage operators, but works reliably only on large models. Mid-sized open-source models (7B–12B) show near-zero operator fidelity, and constraint composition (applying multiple rules simultaneously) fails across all models tested.

**Deduplication across overlapping skills** is underexplored in the literature but critical in practice. When multiple skills share common rules (e.g., "always write tests," "use TypeScript strict mode"), the naive approach injects these rules repeatedly. The better architecture: extract shared rules into a base "conventions" block always loaded, then layer skill-specific gotchas on top. Relevance AI's production system handles this during high-threshold compaction (>50% window): it "reflects on all accumulated observations, removes repetition and redundancy, and further compresses them into a refined state."

The key insight from verbosity research: **LLMs follow compressed instructions effectively if compression preserves key semantic content and uses patterns familiar from training data.** Blind verbosity hurts (GPT-4 exhibits "verbosity compensation" 50.4% of the time, with a 27.6% performance gap between verbose and concise responses). Blind terseness also hurts. The sweet spot is dense, clear, well-structured instructions that remove redundancy without removing meaning.

---

## Prompt caching architecture for skill blocks

Anthropic's prompt caching system provides **90% cost reduction** on cached tokens and up to 85% latency reduction — critical economics for a skill injection system making many API calls with similar system prompts. The mechanism uses a `cache_control` field with either automatic placement (recommended for most cases) or explicit breakpoints for fine-grained control.

**Minimum token thresholds vary by model**: Claude Sonnet 4.5/Opus 4/Sonnet 4/Sonnet 3.7 require **1,024 tokens**, Claude Opus 4.5/4.6 require **4,096 tokens**, and Claude Haiku 3.5/3 require **2,048 tokens**. Prompts below these thresholds are processed normally without error — caching is silently skipped. This means a skill injection block must exceed the threshold to benefit from caching, making the 3–5K token sweet spot doubly important: it's large enough for cache eligibility on all models while small enough to avoid attention degradation.

The optimal structure for a cacheable skill block: bundle all static skill content into a **single system block** with one `cache_control` marker. Use XML tags to structure sections (`<skills>`, `<skill name="...">`, `<rules>`, `<examples>`). Place the breakpoint on the last static block — never on content containing timestamps, session IDs, or per-request variables, as any byte-level change invalidates the cache. The cache hierarchy processes in order: **tools → system → messages**, and changes at any level invalidate that level plus all subsequent levels.

For multi-turn conversations, automatic caching advances the breakpoint each turn. The system supports up to **4 explicit breakpoints** per request. A practical architecture: breakpoint 1 on tool definitions (rarely change), breakpoint 2 on system instructions plus skill blocks (change when skills are swapped), and automatic caching for the growing conversation. The TTL defaults to 5 minutes (refreshed on each hit) with a 1-hour option at 2x write cost. Cache writes cost 1.25x base input price for 5-minute TTL, meaning **you break even after just 2 requests** with a 100K-token system prompt.

One critical caveat: if the set of injected skills changes between turns (because the dynamic selection algorithm picks different skills), the cache for the entire system block is invalidated. This creates a tension between dynamic skill selection and cache efficiency. The resolution: partition skills into a **stable core** (always-loaded behavioral rules, cached) and a **dynamic layer** (task-specific skills, in a separate block that can change without invalidating the core cache).

---

## Selecting 3 skills from 10 matches requires behavioral-impact ranking

Trail of Bits' philosophy provides the clearest framework: **favor behavioral guidance over reference dumps**. Their skills "encode expertise rather than procedures" — they teach Claude how to think about a category of work, not what steps to follow. A skill describing "a senior auditor who's triaged hundreds of reentrancy bugs" shapes what the agent notices and prioritizes on every reasoning step. Raw reference documentation consumes tokens but only helps when the specific referenced fact is needed.

When budget allows only 3 of 10 matching skills, the ranking algorithm should score on multiple dimensions. **Specificity to the current task** ranks highest — a skill matching the exact file type or framework being edited outranks a general coding conventions skill. **Behavioral density** ranks second — skills with more actionable rules per token deliver more value. The SkillReducer finding that 60%+ of body content is non-actionable means scoring should weight the ratio of rules/constraints/gotchas to total content. **Uniqueness of guidance** ranks third — if two skills overlap significantly, pick the one covering more novel ground.

Production implementations use several matching approaches. Anthropic's built-in Tool Search uses **regex/BM25 matching** against names, descriptions, and parameter names — simple but fast. Community implementations achieve ~85% context reduction using **embedding similarity** with SentenceTransformer models. Cursor uses **glob-based matching** to auto-attach rules based on file paths being edited. The most sophisticated approach from recent research (arXiv 2506.20815) uses **two-stage hierarchical reasoning**: first classify the query into a skill domain, then rank within-domain skills by relevance.

For a 51-skill system, the recommended selection pipeline: maintain pre-computed embeddings of all skill descriptions, compute cosine similarity with the current task context at each turn, take the top 10 candidates, then apply a lightweight re-ranking based on (a) behavioral density score, (b) file-pattern match specificity, and (c) deduplication against already-loaded skills. Load full content for the top 3 and summaries for ranks 4–5 as fallback context.

---

## Skills are not portable across model families without adaptation

The PromptBridge paper (arXiv 2512.01420) provides the most direct evidence: transferring a GPT-4o-optimized prompt directly to o3 yields only **92.27% accuracy on HumanEval versus o3's achievable 98.37%** — a 6-point gap from prompt format alone. The PromptPort study found **cross-model portability gaps of 0.4–0.6 F1** across six model families on a 37,346-example benchmark, with smaller models experiencing severe "format collapse" where structured outputs degrade entirely.

Format preferences diverge meaningfully. **Claude was specifically trained to pay special attention to XML tags** — Anthropic's documentation is explicit about this, and XML is recommended across their prompt engineering guides, cookbooks, and partner documentation. **GPT models historically favored Markdown**, with a Daniel Voyce study showing up to 40% performance variation based on format choice (GPT-4 best with Markdown, GPT-3.5 best with JSON). OpenAI's newer reasoning models (o1, o3) now recommend "delimiters such as markdown, XML tags, and section headings," suggesting convergence toward XML compatibility. XML consumes approximately **15% more tokens** than equivalent Markdown, but accuracy gains typically outweigh the cost for complex structured prompts.

On the IFEval benchmark (instruction following), **Claude 3.7 Sonnet scores 0.932 versus GPT-4.5 at 0.882 and GPT-4.1 at 0.874** — Claude leads on raw instruction adherence. However, frontier models still fail 22–30% of verifiable instruction-following tasks, suggesting that skill adherence cannot be taken for granted regardless of model.

For a skill injection system targeting multiple models, the pragmatic approach: write skills in XML (the one format all major providers now encourage), but maintain model-specific formatting adapters for edge cases. Test each skill on every target model — expect degradation and budget time for model-specific tuning. The PromptBridge framework demonstrates that training-free cross-model prompt mapping can recover **27–39% of the portability gap**, suggesting that automatic adaptation layers are feasible.

---

## Measuring skill impact requires layered evaluation

The evaluation question has two distinct dimensions: does the model *follow* the skill's instructions (adherence), and does following them *improve outcomes* (impact)?

For **adherence measurement**, the IFEval framework provides a starting template: define verifiable constraints within each skill (e.g., "always include error handling," "never use `any` type in TypeScript") and check outputs programmatically. The "Instruction Gap" paper (arXiv 2601.03269) categorizes violations into content scope violations, format violations, and behavioral guideline violations — a useful taxonomy for classifying skill non-adherence. The Directive-Following Rate (DRFR) metric measures percentage of explicit directives followed, while the Meeseeks Score evaluates complex multi-step compliance.

For **impact measurement**, the gold standard is A/B testing against established benchmarks. Run identical tasks with and without the skill injected, measuring test pass rate, bug count, security vulnerability count, and code quality scores. **SWE-bench Verified** (500 real GitHub issues with unit test evaluation) is the strongest benchmark for real-world coding impact, though it primarily measures patch correctness rather than code quality. **EvoEval** is valuable for harder problems — all LLMs consistently perform 38% worse on evolved problems than original HumanEval, creating more headroom to detect skill impact.

Production evaluation infrastructure is mature. **Braintrust** offers visual A/B testing with automated quality scoring. **Langfuse** (open-source) supports prompt version labeling and per-version metric tracking. **Statsig** provides power analysis and guardrail metrics. The recommended methodology: establish baselines on a curated golden dataset of 50–100 representative tasks, run each task 3–5 times (accounting for LLM nondeterminism), measure both adherence metrics and outcome metrics, and compute statistical significance before shipping changes.

An important finding from the evaluation literature: **task capability and instruction adherence are distinct dimensions** (arXiv 2510.18892). A model may excel at a task while failing to respect constraints, or perfectly follow instructions while producing mediocre code. Skill evaluation must measure both.

---

## Dynamic adjustment during sessions closes the feedback loop

The most sophisticated production systems don't just select skills at session start — they continuously adjust context based on what the model is actually doing. Manus (Meta's AI agent) identified **KV-cache hit rate as "the single most important metric for a production-stage AI agent"** and designed their context management around it. Their key technique: constantly rewrite task objectives at the end of context to push the global plan into the recent attention span, directly combating lost-in-the-middle effects. They also keep failure traces in context rather than erasing them — the model needs evidence of past errors to avoid repeating them.

Relevance AI's production system implements a two-mechanism adaptive architecture. **Real-time tool output compaction** triggers when output exceeds 4,000 tokens — the agent chooses between compacting with explicit extraction instructions, keeping only a preview, or keeping the full output. This achieves **>80% reduction in tool output tokens**, turning previously failing workflows into completions. **Two-phase history compaction** uses dual thresholds: at 30% window utilization, raw history compacts into structured observations; at 50%, observations undergo reflection to remove redundancy. The layered abstraction — raw turns → observations → refined observations — preserves essential information while aggressively managing token budget.

Claude Code triggers auto-compaction at approximately **75% context utilization**, not the 95% many developers assume. This deliberate early compaction leaves ~25% of the window (50K tokens in a 200K window) for reasoning quality on subsequent turns. Practitioners report that stopping compaction earlier "actually extends productive session length" because each turn maintains higher reasoning quality. The newer context editing API (June 2025) supports selective clearing — old tool results are replaced with placeholder text chronologically, paired with a memory tool so Claude saves important information before it's cleared.

For a 51-skill system, dynamic adjustment should work across three timescales. **Per-turn**: re-score skill relevance based on files touched and errors encountered in the previous turn; swap skills if the task domain has shifted. **Per-phase**: as a multi-step task progresses from planning to implementation to testing, rotate skill emphasis accordingly. **Per-session**: track which skills the model actually references (mentioned in reasoning or applied in output) versus which sit unused, and shed unused skills after 3–5 turns of inactivity. Google's Agent Development Kit formalizes this with its artifact pattern: large data lives outside context as named references, loaded ephemerally on demand and offloaded after use.

---

## Conclusion

The research converges on a clear architecture for skill injection systems. The fundamental insight is that **context quality dominates context quantity** — every source from Anthropic's engineering team to Trail of Bits to academic researchers confirms that less, better-targeted context outperforms comprehensive dumps. The 3–5K token budget for active skills is not arbitrary; it sits at the intersection of cache eligibility thresholds, attention degradation curves, and empirical performance data showing compressed skills outperform verbose originals.

Three findings deserve particular emphasis. First, the SkillReducer result that **compression improves quality** upends the intuition that more detail always helps. Over 60% of typical skill content is non-actionable noise. Second, the Chroma Context Rot finding that **all 18 tested frontier models degrade at every context length increment** means there is no safe zone — every token matters, and the cost of injecting a marginal skill is never zero. Third, **skills are not portable across model families** without adaptation, and the 6-point HumanEval gap from prompt format alone means a multi-model skill system needs model-specific formatting layers.

The production-ready implementation pattern: maintain a cached core of behavioral rules (stable across turns, exploiting prompt caching for 90% cost reduction), dynamically select 2–3 task-specific skills via embedding similarity plus behavioral-density re-ranking, structure everything in XML with critical rules repeated at context boundaries, and continuously adjust the active skill set based on observed model behavior. This architecture balances instruction adherence, token efficiency, cache economics, and adaptability — the four axes that determine whether a skill injection system helps or hurts the agent it's meant to improve.