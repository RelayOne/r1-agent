# Measuring and improving AI agent skills: a practitioner's framework

**Most of your 51 skills are probably dead weight — and the ones that work may not work for the reasons you think.** ETH Zurich research found that developer-written context files improve AI agent task outcomes by only **4% on average**, while LLM-generated instructions actually *decrease* performance by 3%. Yet agents demonstrably *follow* injected instructions (using mentioned tools 1.6–2.5x more often), meaning the gap lies not in compliance but in whether following those instructions actually helps. The good news: a rigorous measurement infrastructure can separate signal from noise, and emerging tools make continuous skill improvement increasingly practical. Here's how to build that infrastructure across all ten dimensions.

---

## A/B testing skills requires matrix evaluation, not vibes

The single most important step is replacing subjective assessment with systematic comparison. **Promptfoo** (now part of OpenAI, 19.6K GitHub stars) provides the core workflow: define two prompt variants (with and without a skill), a test matrix of coding tasks, and automated assertions, then run every combination and compare. Its CI/CD GitHub Action can gate pull requests that modify skills, blocking merges when quality regresses.

The experimental design is straightforward. Build a golden dataset of **25–50 curated coding tasks** representing real usage, including known failure cases each skill should prevent. Run both the baseline (no skill) and treatment (with skill) against every task, generating 3–5 samples per combination to handle LLM non-determinism. Score outputs across four layers: **compilation success rate**, functional test pass rate (pass@k), static analysis findings (Semgrep/SonarQube alerts), and mutation testing scores on critical paths.

Statistical rigor matters because LLM outputs vary substantially — research found accuracy variations of up to **15% across identical runs**. Bootstrap resampling is the recommended method over classical tests, since LLM output distributions are non-normal and heteroskedastic. Compute confidence intervals from 10+ evaluation runs. Paired-difference analysis (measuring per-task deltas between control and treatment) accounts for task difficulty variation and increases statistical power.

Beyond promptfoo, **Braintrust** offers versioned experiments with per-case regression detection and an AutoEvals library for LLM-as-judge scoring. **LangSmith** provides both offline evaluation against curated datasets and online evaluation scoring production traffic in real-time. **DeepEval** (open-source, "Pytest for LLMs") supports unit-test-style assertions with built-in metrics for hallucination, relevancy, and faithfulness. Each tool fills a different niche: promptfoo for prompt comparison, Braintrust for regression monitoring, LangSmith for production observability, and DeepEval for developer-workflow integration.

A critical caveat from research: improvements are rarely monotonic. A study titled "When 'Better' Prompts Hurt" found that adding helpful-assistant rules *degraded* extraction accuracy by 10% while improving instruction-following by 13%. Every skill must be tested holistically — measuring what it breaks alongside what it fixes.

---

## Mutation testing is the objective umpire for skill adherence

Code coverage lies. A test suite with **85% coverage can have only a 57.3% mutation kill rate** — meaning 43% of injected bugs go undetected. When a skill says "always validate inputs," mutation testing answers whether that validation actually exists and is actually tested by systematically altering validation logic and checking whether tests catch the changes.

The workflow for skill validation is: instruct the agent to generate code with the skill active → run mutation testing targeting skill-relevant code paths → if mutations in validation logic survive, either the skill wasn't followed or tests don't cover it → feed surviving mutants back to the agent for iterative improvement. Practitioners at Test Double report getting Claude Code to iteratively improve mutation scores to **94.4%** by including Stryker Mutator commands directly in `CLAUDE.md` files and prompting the agent to run `npm run mutate` after implementation.

The tooling ecosystem is mature across languages: **PIT/pitest** for Java (the gold standard), **mutmut** for Python, **Stryker Mutator** for JavaScript/TypeScript, **cargo-mutants** for Rust, and **go-mutesting** (Avito fork) or the new **gomu** for Go. Go 1.26 is building mutation testing for assembly directly into `go test`. For industrial scale, Meta's **Automated Compliance Hardening (ACH)** tool uses LLMs to generate semantically relevant mutants rather than purely syntactic ones, addressing the unrealistic-mutant problem that plagues traditional tools.

Static analysis provides a complementary fast-feedback layer. Write custom **Semgrep** rules (YAML-based, scans in ~10 seconds) to enforce structural patterns like "every HTTP handler must call `validateInput()`." For deeper semantic analysis, **CodeQL** offers cross-file dataflow tracking with **88% accuracy and only 5% false positive rate**. The recommended pipeline runs Semgrep on every PR for fast pattern checks and mutation testing on critical paths before merge.

Recommended mutation score thresholds: **70% minimum for critical paths** (authentication, payment, data validation), 50% for standard features, 30% for experimental code. Any skill-relevant code path scoring below threshold indicates the skill isn't producing adequately tested code.

---

## Tracking which skills the model actually follows versus ignores

The "lost in the middle" problem is the foundational challenge. Research by Liu et al. (Stanford/UC Berkeley, TACL 2024) demonstrated that LLM performance follows a **U-shaped curve** — models attend most to instructions at the beginning and end of context, with significant degradation for instructions in the middle. This is architecturally hardwired and affects even explicitly long-context models. The practical implication: skills placed in the middle of a 51-skill system prompt may be systematically ignored regardless of their quality.

Measuring adherence requires multiple complementary approaches. **Programmatic verification** works for concrete constraints — IFEval's approach of testing verifiable instructions (word counts, keyword inclusion, format compliance) achieves reliable automated scoring. For semantic adherence, the **LLM-as-judge** pattern is now standard: Galileo's Instruction Adherence metric uses multiple GPT-4o evaluations per response, computing a 0–1 score from majority voting. The "coding extractor method" — where an LLM generates code to extract relevant response parts before scoring — increased accuracy from 78.7% to **98.4%**.

For practical detection of ignored skills, instrument your pipeline to log which skills are injected per request, then run post-hoc analysis. **Three detection methods** work well together: (1) pattern matching — check outputs for the absence of patterns skills mandate (e.g., if a skill requires error handling, grep for try/catch blocks); (2) embedding similarity — compute cosine similarity between skill text and output text, flagging skills with consistently low similarity; (3) self-citation — append "list which rules from the system prompt you applied" to the prompt, then compare claimed adherence against actual output analysis.

Observability platforms like **Datadog LLM Observability**, **Langfuse** (MIT-licensed, self-hostable), and **Helicone** provide the logging infrastructure. Datadog's Prompt Tracking feature lets you version prompts and correlate changes with output quality metrics. **Confident AI/DeepEval** offers 50+ research-backed metrics with production monitoring and drift detection, alerting via PagerDuty or Slack when skill adherence degrades.

The practical response to the positional bias problem: place highest-priority skills at the beginning and end of the system prompt, use hierarchical loading (only inject skills relevant to the current task), and keep total skill count manageable — the AdvancedIF benchmark shows even GPT-5 and Grok-4 achieve only **74–78% on complex multi-constraint instructions**.

---

## Detecting when skills contradict each other

The ConInstruct benchmark (arXiv:2511.14342) provides the most direct evidence on this problem. DeepSeek-R1 achieves **91.5% F1-score** on conflict detection, Claude-4.5-Sonnet reaches 87.3%, but open-source models under 7B parameters **underperform random guessing**. This means conflict detection is feasible with capable models but not with lightweight approaches.

For a 51-skill set, the practical approach is pairwise NLI screening. Run all O(n²) = 1,275 skill pairs through a Natural Language Inference model like `MoritzLaurer/DeBERTa-v3-base-mnli-fever-anli` (trained on 763K examples, available on HuggingFace, runs on CPU). This classifies each pair as entailment, contradiction, or neutral. Flag pairs with high contradiction scores for human review. For a more sophisticated pass, use an LLM-as-judge — Claude-4.5-Sonnet's 87.3% F1 makes it effective for semantic conflict detection that NLI models miss.

**Priority ordering is harder than it appears.** The "Instruction Hierarchy" paper from OpenAI proposed explicit system > user > third-party priority levels, achieving 63% improvement in hierarchy adherence. But the "Control Illusion" paper (arXiv:2502.15851) found this approach fundamentally unreliable: Priority Adherence Rate ranged from **14.4% (Qwen) to 47.5% (GPT-4o-mini)**. Societal hierarchy framings (authority, expertise, consensus) showed stronger influence than structural priority — suggesting that framing a skill as coming from a "senior security architect" may be more effective than marking it "priority: high."

The practical resolution: embed priority metadata in each skill, cluster skills by semantic similarity to surface within-cluster conflicts, and when conflicts are detected, either merge the conflicting skills into a single nuanced instruction or explicitly state the resolution logic ("When working with public APIs, prioritize input validation over code brevity").

---

## Gotchas must be measured with adversarial challenge sets

Testing gotcha effectiveness requires deliberately trying to trigger the failure the gotcha warns about. The **RuLES framework** ("Can LLMs Follow Simple Rules?") provides the gold standard: 14 scenarios with programmatic evaluation functions that determine whether the model broke specific rules. The finding that **all tested models, including GPT-4, are susceptible to rule violations** underscores the need for measurement.

Critical research findings shape how gotchas should be written. Positively framed rules ("always validate inputs before processing") achieve **higher adherence than negatively framed ones** ("never process inputs without validation"). RLHF training actively undermines constraint following — one study found that removing RLHF helpfulness signals improved constraint compliance from 0.06–0.26 to **0.96–1.00**. And constraint compliance is statistically orthogonal to output quality (r=0.193), meaning a model can follow your gotcha perfectly while producing poor code, or ignore it while producing excellent code.

The measurement pipeline for each gotcha: create **5–10 coding tasks** specifically designed to trigger the warned-about mistake. Run them without the gotcha (baseline failure rate), then with the gotcha (treatment failure rate). Use automated detection — compile checks, test execution, static analysis rules targeting the specific anti-pattern, and AST pattern matching. Track **Hard Constraint Satisfaction Rate** (binary: was the mistake avoided?) and **Session Stability Rate** (consecutive turns maintaining compliance, critical for multi-turn agents). When a gotcha doesn't reduce failure rate significantly, rewrite it — positively, specifically, and with concrete examples of the correct pattern.

---

## Skills decay silently as frameworks and APIs evolve

A skill referencing React class component patterns or Python 2 string formatting is actively harmful, but detecting staleness at scale requires automated tooling. **GitChameleon 2.0** tested LLMs on version-conditioned code generation across 328 Python problems and found even the best models achieve only **~51% success rate** — models consistently default to the API version they saw most during training, not the version specified.

Three tools provide the foundation for decay detection. **DocDrift** detects changed functions from git diffs, finds related documentation via semantic search, and uses AI to check whether docs still match code — directly applicable to checking whether skills reference functions that have changed. **Swimm** (Gartner Cool Vendor 2024) couples code elements with documentation and runs on every PR, classifying docs as up-to-date, out-of-sync, or outdated. **Ferndesk** proactively monitors support tickets and changelogs to identify content gaps, analyzing up to 5,000 tickets per month.

The practical deprecation workflow combines five signals into a staleness score per skill:

- **Time since last verification** (flag skills unreviewed in 90+ days)
- **API currency score** (parse skill text for library references, cross-reference against package registries for deprecation notices)
- **Version gap** (difference between skill's referenced version and latest stable version)
- **Error correlation rate** (rising error rates in outputs where the skill is active)
- **Embedding drift score** (cosine distance between skill embeddings and current documentation embeddings, using tools like DriftLens or Evidently AI)

When a skill trips multiple staleness signals, automatically create a review task with the specific drift evidence. For critical skills, use an LLM to compare the skill against current framework documentation and suggest updates.

---

## The community skills ecosystem is exploding but quality is abysmal

The numbers are staggering and the quality problem is severe. **skills.sh** (built by Vercel, functioning as "npm for AI agents") tracks **87,000+ skills** with top packages reaching 774.9K installs. **SkillsMP.com** aggregates skills from GitHub with categories spanning development, product management, and data analytics. The **awesome-agent-skills** GitHub repo has earned **2.8K stars** as a curated index. But **36% of skills in the wild have security flaws** according to skillsdirectory.com, and a Snyk audit found **1,467 of 3,984 scanned skills contained malicious payloads** — credential theft, backdoors, data exfiltration.

Quality signals vary dramatically by platform. skills.sh partners with **Socket.dev** for supply chain security scanning (98.7% recall, 96.7% F1 for malicious detection). **skillsdirectory.com** uses a letter-grading system scoring 0–100 across 50+ security rules and 10 threat categories. **Tessl** offers a CLI tool (`tessl skill review SKILL.md`) that checks line count, frontmatter validity, description voice, trigger hints, and uses LLM-as-judge for activation scoring. **Trail of Bits' skills-curated** repo requires human code review on every PR because "published skills have been found with backdoors and malicious hooks."

The open standard anchoring the ecosystem is **SKILL.md** (released by Anthropic December 2025, adopted by **26+ platforms** including Claude Code, Codex, Copilot, Cursor, and Gemini CLI). The specification includes an evaluation methodology: test cases with prompt/expected-output pairs, A/B comparison (with skill vs. without), and assertions graded by LLM or script. But SkillsBench research found that "everyone is writing skills, almost nobody is testing them, and most are AI-generated." The ecosystem's maturity mirrors early npm — massive growth, minimal quality gates, active supply chain attacks already occurring.

---

## Trail of Bits built the most sophisticated skill improvement loop

Trail of Bits' approach represents the current state of the art. They maintain **94 plugins, 201 skills, 84 specialized agents**, and 414+ reference files across their repositories. Their **skill-improver plugin** implements an iterative review-fix-review loop: invoke it on a skill, the skill-reviewer agent evaluates against quality standards, Claude applies fixes, the reviewer re-validates, and the loop continues until quality bar is met or **20 iterations** are exhausted (configurable via `--max-iterations`).

Their quality criteria go well beyond formatting. Skills must use **third-person voice** ("Analyzes X" not "I help with X"), include specific trigger conditions ("Use when auditing Solidity" not "Smart contract tool"), explain *why* not just *what* (including trade-offs and decision criteria), and stay under 2,000 words with detailed content in `references/` files. For security skills specifically, they require bundled analysis checklists, vulnerability patterns, example outputs, and decision logic.

The anti-hallucination rules are particularly notable: all claims must cite specific line numbers, all assumptions must be documented explicitly, all unknowns must be marked with "unclear; need to inspect X," and skills must meet minimum thresholds — **at least 3 invariants identified, 5 assumptions documented, 3 dependencies traced**. The instruction "never reshape evidence to fit assumptions; do not infer behavior from naming alone; cross-reference constantly" encodes hard-won audit experience.

The results validate the approach. AI-augmented auditors now find **200 bugs per week** on strong engagements (up from ~15), and **~20% of all bugs reported to clients** are initially discovered by AI. Their weekly `/insights` command analyzes recent sessions, identifies what's working and failing, and recommends adding rules, writing hooks to block recurring mistakes, or extracting workflows into new skills. Every engagement feeds the improvement cycle.

---

## Turning failures into skills automatically is the frontier

No fully productized "postmortem → skill" pipeline exists yet, but the components are converging from three directions. The **Reflexion framework** (NeurIPS 2023) demonstrated verbal reinforcement learning — agents generate linguistic self-critiques from failures and store them as future guidance, improving HumanEval pass rates by **11%** and AlfWorld task completion by 22%. **GEPA** (ICLR 2026 Oral, from UC Berkeley/Stanford/Databricks) extends this with Pareto-based reflective evolution, outperforming reinforcement learning by **10% average while using 35x fewer rollouts**, and is now integrated into DSPy and MLflow.

The practical architecture combines incident analysis with skill generation. Incident platforms like **Rootly** and **incident.io** already generate structured postmortems with automated timelines, root cause analysis, and action items. The missing link is converting those action items into agent instructions. LangSmith's **Insights Agent** demonstrates the pattern: cluster production traces by failure mode, identify common root causes, propose prompt changes, validate with offline evals, and deploy. When equipped with LangSmith Skills, Claude Code's performance jumped from **17% to 92%** on their evaluation set.

The OpenAI Self-Evolving Agents cookbook (November 2025) provides a concrete implementation pattern: a `VersionedPrompt` class tracks every instruction change with rollback capability, a metaprompt optimization agent rewrites system prompts based on grader results, and the loop continues until scores exceed a target threshold or maximum retries are exhausted. This creates a closed-loop system where every failure is an opportunity for instruction improvement.

For your 51 skills, the immediate implementation is: log every agent task outcome, tag which skills were active, cluster failures by root cause, and for each recurring failure pattern, draft a candidate gotcha or skill revision. Test the candidate against historical failures (does it catch known bugs?) and for regressions (does it create false positives?). Promote to production only after passing evaluation with a human review gate.

---

## Skills that work in one project may not transfer

The most sobering finding comes from ETH Zurich's evaluation of AGENTS.md files: context files only marginally improve performance (**+4% on average**), and the improvement doesn't scale with file quality or model capability. Agents reliably *change behavior* when instructed (using mentioned tools 1.6–2.5x more often), but changed behavior doesn't reliably improve outcomes.

This suggests a taxonomy of skill generalizability. **Universal skills** — security practices, error handling patterns, testing methodology — transfer well because they encode domain-invariant principles. **Project-specific skills** — framework patterns, architecture decisions, build tooling commands — transfer poorly and may actively harm when applied to projects with different conventions.

Modern tools address this with hierarchical scoping. Cursor's three-level system separates global IDE settings, project-level conventions (always active), and contextual rules that load based on file globs. GitHub Copilot's `.github/instructions/*.instructions.md` files use YAML frontmatter with `applyTo` patterns for file-type-specific activation. The **meta-repo pattern** (documented by Anyline) maintains a central conventions repository referenced by all project repos, preventing convention drift while allowing project-specific overrides.

The research paper "Codified Context" found that single-file manifests **don't scale beyond modest codebases** — a 1,000-line project quickly outgrows a single file. For the user's 51-skill set, this argues for aggressive decomposition: separate universal skills (security, testing, error handling — likely 10–15 of the 51) from project-specific ones, scope project-specific skills to relevant file patterns, and measure effectiveness per-project using the A/B testing pipeline described above. Track instruction-following rate (binary: did the agent apply the skill?) separately from outcome quality (did following the skill improve the code?) — the ETH research shows these metrics diverge substantially.

---

## Conclusion: building the improvement loop

The core insight across all ten dimensions is that **skill management is an engineering discipline, not a writing exercise**. The measurement stack you need: promptfoo or Braintrust for A/B testing, mutation testing tools for objective quality validation, Semgrep for structural adherence checking, an LLM-as-judge pipeline for semantic compliance scoring, and NLI models for conflict detection.

For your 51 skills specifically, start with triage. Run each skill through the A/B testing pipeline against a golden dataset of 25–50 tasks. Skills that don't produce statistically significant improvement (after bootstrap analysis with 5+ trials per task) are candidates for removal — reducing your set likely improves overall performance by reducing context length and avoiding the "lost in the middle" problem. Tag survivors with creation dates, referenced framework versions, and priority levels. Set up automated staleness detection cross-referencing skill content against package registry deprecation notices.

The continuous improvement loop then follows Trail of Bits' pattern: weekly analysis of agent session outcomes → identification of recurring failures → candidate skill generation or revision → evaluation against historical failures → human review gate → deployment with monitoring. GEPA's integration into DSPy and MLflow makes the prompt-optimization step increasingly automated. The goal is not 51 perfect skills — it's **the smallest set of highest-impact skills, continuously validated against real outcomes and automatically flagged when they decay**.