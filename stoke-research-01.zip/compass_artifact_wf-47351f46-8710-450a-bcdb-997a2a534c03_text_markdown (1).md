# Claude Code turn limits: what your QA audit system needs to know

**Claude Code's `--max-turns` and `--max-budget-usd` limits both cut the agent off abruptly between turns with no final summary opportunity and no `.result` field in the response.** This means your `qa-audit-loop.sh` system, as currently designed with 30 auditor turns and 50 fix turns, risks losing all findings unless you adopt a file-based output strategy. The agent never gets a "last chance" to produce output — the SDK returns an `error_max_turns` result with an `errors[]` array but **no `result` field**. Your system must be redesigned around incremental file writes, Stop hooks for completion validation, and session resumption as a fallback.

## The max-turns cutoff is abrupt and discards the result field

When Claude Code hits the `--max-turns` limit, the sequence is precise: (1) the agent completes the current turn's tool execution, (2) the turn counter increments, (3) the SDK checks `numTurns >= maxTurns`, and (4) if true, it emits a `ResultMessage` with `subtype: "error_max_turns"` and **terminates the loop immediately**. Claude is never given another API call to produce a final text response.

The TypeScript SDK defines a discriminated union type for `SDKResultMessage`. The `success` variant carries a `result: string` field containing the agent's final text output. All four error variants (`error_max_turns`, `error_max_budget_usd`, `error_during_execution`, `error_max_structured_output_retries`) carry an `errors: string[]` field instead — **the `result` field simply does not exist on these variants**. The official documentation states explicitly: "The `result` field (the final text output) is only present on the `success` variant, so always check the subtype before reading it."

Notably, `is_error` is `false` on `error_max_turns` — the SDK treats it as a stop condition, not a fatal error. The `session_id` is preserved, enabling resumption. A real-world example from GitHub issue #3286 shows the output structure:

```json
{
  "type": "result",
  "subtype": "error_max_turns",
  "is_error": false,
  "num_turns": 3,
  "total_cost_usd": 0.056918
}
```

The `--max-budget-usd` limit behaves identically — checked between turns, returns `error_max_budget_usd`, no `.result` field. **Both limits are enforced independently; whichever triggers first wins.** A critical limitation: there is a confirmed bug (GitHub issue #3286) where `--max-turns` is sometimes ignored when using `--resume`, so session continuation is not fully reliable.

## There is no warning mechanism, but Stop hooks offer a workaround

Claude Code provides **no built-in mechanism to warn the agent about approaching limits**. The model cannot detect how many turns remain — `--max-turns` is enforced externally by the SDK/CLI, not visible to the model's context. This contrasts with GitHub Copilot's coding agent, which warns its model as it approaches its 59-minute time limit.

The available hook events do not include an `on_turn_start` hook. The closest equivalents are `PreToolUse` (fires before each tool call) and `PostToolUse` (fires after each tool succeeds). However, the **Stop hook** is the most powerful tool for your use case — it fires when Claude tries to stop normally and can **block stopping** by returning exit code 2 or `{"decision": "block", "reason": "..."}`. This forces Claude to continue working if validation fails.

There is, however, **a critical gap**: Stop hooks only fire when Claude voluntarily finishes. They do **not** fire when `--max-turns` forcibly terminates the session. A confirmed bug (GitHub issue #58) notes that `PostToolUse` hooks are also skipped on the final turn when max-turns is hit. This means hooks cannot rescue you from a max-turns cutoff — they can only ensure that if Claude finishes early (within the turn budget), it has actually completed its work.

A community workaround exists: a shell-script-based turn tracker that counts unique message IDs in log files and injects warnings like "⚠️ Only N turns remain!" into the context. This requires coupling with `CLAUDE.md` instructions telling Claude to call the tracking script frequently. It's fragile but functional.

## Empirical turn data suggests your limits are reasonable but tight

No authoritative source from Anthropic provides task-specific turn recommendations. The following data is synthesized from benchmarks, official examples, and community reports:

**Code review and static analysis** tasks typically consume **3–15 tool-use turns**. The official GitHub Action defaults to 10 turns. Anthropic's own documentation examples use `maxTurns: 3` for quick reviews, `maxTurns: 10` for standard CI reviews, and `maxTurns: 50` for thorough security audits. Your auditor allocation of **30 turns is generous for review** — most reviews complete well within this, but complex multi-file security audits could approach it.

**Single-file bug fixes** typically require **12–30 turns**. Anthropic's SWE-bench analysis shows straightforward fixes completing in approximately 12 steps, while a community report using a 7-step bug fix protocol with 30 turns found Claude completing only ~50% of todos before stopping. SWE-agent recommends **50 turns as "cost-conservative"** for bug-fixing tasks on SWE-bench.

**Multi-file refactors** are the most variable, ranging from **30 to hundreds of turns**. Anthropic's own SWE-bench report notes that "many successful runs took hundreds of turns for the model to resolve, and >100k tokens." SWE-bench evaluations use limits of 100–250 steps. Your fix agent allocation of **50 turns is adequate for targeted fixes** but may be insufficient for complex multi-file refactors.

| Task type | Typical range | Your allocation | Assessment |
|---|---|---|---|
| Code review / audit | 3–15 turns | 30 (auditor) | Generous; safe margin |
| Single-file bug fix | 12–30 turns | 50 (fix agent) | Adequate for most cases |
| Multi-file refactor | 30–200+ turns | 50 (fix agent) | Tight for complex fixes |
| SWE-bench (hard, 1-4hr) | 50–150 turns | — | Far exceeds your limits |

## Default is unlimited; there's no magic "infinity" flag value

When `--max-turns` is not specified, the default is **no limit** — the loop runs until Claude finishes on its own. In the TypeScript SDK, this is `maxTurns?: number` (undefined = no limit). In Python, it's `max_turns: int | None = None`. **No documentation confirms that `--max-turns 0` or `--max-turns -1` means "no limit."** The correct way to run without a turn ceiling is simply to omit the flag.

You can absolutely use a shell `timeout` command as an external hard timeout without `--max-turns`:

```bash
timeout 600 claude -p "Fix the bug" --output-format json > result.json
```

However, `timeout` sends SIGTERM, which may not produce any partial output. For production, layer defenses: use `--max-turns` as the primary control, `--max-budget-usd` as a cost ceiling, and `timeout` as a catastrophic safety net.

The **GitHub Actions integration defaults to 10 turns**, distinct from the CLI/SDK default of unlimited. This is a common source of confusion.

## Recommended architecture for your QA audit system

Given the abrupt cutoff behavior and absent `.result` field, your `qa-audit-loop.sh` should be redesigned around three principles: **incremental file writes**, **Stop hook validation**, and **session resumption**.

**Principle 1: Never rely on stdout for results.** Since `error_max_turns` returns no `.result`, instruct agents via `--append-system-prompt` to write findings incrementally to a JSON file. Check for this file after the process exits, regardless of exit code:

```bash
claude -p "Perform QA audit" \
  --append-system-prompt "CRITICAL: Write all findings incrementally to qa-results.json. 
    After EVERY finding, update the file. Structure: {\"status\": \"in_progress\"|\"complete\", 
    \"findings\": [...]}. Begin by creating this file immediately." \
  --max-turns 30 --max-budget-usd 5.00 \
  --output-format json --dangerously-skip-permissions > /dev/null 2>&1

# Results are in the file, not stdout
if [ -f qa-results.json ]; then
  jq '.findings | length' qa-results.json
fi
```

**Principle 2: Use Stop hooks to enforce completeness within the turn budget.** Configure a Stop hook that validates the output file exists and contains valid, complete results. If validation fails, the hook blocks stopping and tells Claude to finish its work. This only helps when Claude tries to stop early — it cannot override a max-turns cutoff.

```json
{
  "hooks": {
    "Stop": [{"hooks": [{"type": "command", 
      "command": "python .claude/validate-output.py", "timeout": 60}]}]
  }
}
```

**Principle 3: Resume incomplete sessions.** When `error_max_turns` is returned, use the `session_id` to resume with a focused completion prompt:

```bash
session_id=$(jq -r '.session_id' claude-output.json)
claude -p "Finalize your findings and ensure qa-results.json is complete" \
  --resume "$session_id" --max-turns 10
```

Be aware of the known bug where `--max-turns` may be ignored on resume.

**Recommended turn and budget values for your system:**

- **Auditor agents (code review):** **30 turns** is appropriate. Most reviews complete in 5–15 turns; 30 provides a comfortable buffer for complex codebases. Set `--max-budget-usd 3.00` as a cost ceiling.
- **Fix agents (code modification):** **Increase to 75 turns** for safety. Single-file fixes typically need 12–30, but multi-file fixes with test validation can easily exceed 50. Set `--max-budget-usd 8.00`.
- **Budget:** Set `--max-budget-usd` generously (2–3x expected cost) rather than omitting it entirely. Omitting it risks runaway spending on pathological loops. The budget acts as a financial safety net, not a primary control.
- **Hard timeout:** Wrap both agent types in `timeout 900` (15 minutes) as a catastrophic safety net.

## Conclusion

The most important insight for your production system is that **Claude Code's turn limits are a blunt instrument** — they terminate with no final output opportunity and no partial result in the SDK response. The official recommendation is "setting a budget is a good default for production agents," but the documentation undersells the severity of the cutoff. Your system's reliability hinges entirely on the file-write-early pattern: instruct agents to persist results incrementally to disk, validate via Stop hooks when possible, and treat the max-turns limit as a last resort rather than a graceful boundary. The gap between Claude Code's current behavior and what production QA systems need — specifically, a "you have N turns left, wrap up now" warning injection — is a recognized limitation with no built-in solution. The community workaround of external turn tracking scripts coupled with `CLAUDE.md` instructions is the closest available approximation, but it adds fragility. For maximum robustness, combine generous turn limits (30 auditor / 75 fix), incremental file output, Stop hook validation, session resumption fallbacks, and external `timeout` safety nets in a defense-in-depth configuration.