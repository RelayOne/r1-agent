# Production data engineering patterns for multi-tenant SaaS analytics

**Building analytics infrastructure on a Kafka-backed, Go/TypeScript SaaS platform demands deliberate architectural choices across pipeline design, data quality, warehouse selection, privacy, and real-time processing.** This guide covers ten critical dimensions with concrete tool recommendations, decision frameworks, and code patterns calibrated for a growth-stage multi-tenant platform. The overarching architecture follows a pragmatic Kappa-style approach: Go and TypeScript services emit events into Kafka with schema validation via a Schema Registry, events flow through validation and enrichment stages, then fan out to a real-time serving layer (ClickHouse or Redis) and a batch analytics warehouse (Snowflake or BigQuery), with dbt or SQLMesh handling transformations and Dagster orchestrating the whole pipeline.

---

## 1. ETL/ELT pipeline patterns and when to use each

### Batch versus streaming versus micro-batch

The choice between processing modes hinges on three variables: **latency tolerance, cost budget, and operational complexity**. Batch processing (Spark, dbt scheduled runs) suits workloads where hours-old data is acceptable—historical analytics, ML training, financial reconciliation. Cost is lowest because compute can use spot instances and off-peak pricing. Streaming (Flink, Kafka Streams) targets sub-second decisions: fraud detection, live dashboards, real-time personalization. Always-on infrastructure makes this the most expensive option. Micro-batch (Spark Structured Streaming, dbt's new microbatch strategy) occupies the middle ground—seconds-to-minutes latency at moderate cost, ideal when SLAs require **under 5 minutes freshness** but full streaming complexity isn't justified.

For a Kafka-centric SaaS platform, the recommended starting architecture is a simplified Kappa approach: Kafka serves as the single event log, stream processing handles latency-critical paths, and Kafka Connect sinks feed the warehouse for historical analytics. This avoids maintaining dual business logic (the core Lambda architecture problem) while still supporting both real-time and batch consumption patterns.

### CDC with Debezium and Kafka Connect

Change Data Capture via Debezium reads database transaction logs (PostgreSQL WAL, MySQL binlog) rather than polling tables, producing structured change events with before/after states. Key production concerns:

- **Slot management**: Replication slots prevent WAL segment purging. Unmonitored slots cause disk exhaustion—set alarms on `TransactionLogsDiskUsage` and `OldestReplicationSlotLag` in RDS
- **Heartbeat configuration**: Set `heartbeat.interval.ms` to **60000ms or lower** for low-traffic databases. Without heartbeats, WAL files accumulate unbounded. Execute DML against a dedicated heartbeat table via `heartbeat.action.query` to advance LSN positions
- **Snapshot tuning**: Incremental snapshots use watermark-based deduplication between READ and streaming events. A Debezium blog (January 2025) documented **25% snapshot time reduction** (8 hours to 6) using `producer.override.batch.size: 1000000`, `linger.ms: 500`, and LZ4 compression
- **Schema Registry integration**: Use Avro or Protobuf converters with the Confluent Schema Registry. Pre-register schemas in production (`auto.register.schemas=false`)

Slack's CDC transition to Debezium + Kafka Connect reduced pipeline latency from **24 hours to under 10 minutes** and cut costs by millions annually.

### Transformation frameworks: dbt, SQLMesh, and Materialize

**dbt** (40K+ GitHub stars) offers the largest ecosystem, extensive hiring pool, and deep warehouse integrations. Incremental models process only new/changed rows. dbt Cloud's Fusion engine (Rust-based) delivers ~30× faster compilation. The weakness: Jinja templating treats SQL as strings, catching syntax errors only at runtime.

**SQLMesh** provides Terraform-like state management with a plan/apply workflow. Virtual environments create zero-cost dev environments using views pointing to hash-versioned physical tables. Databricks benchmarks show SQLMesh is **9× faster and 9× cheaper** than dbt Core, with rollbacks **136× faster**. Column-level lineage is built-in via SQLGlot SQL parsing. SQLMesh can read and execute existing dbt projects without modification.

**Materialize** delivers streaming SQL with **strict serializability**—the strongest consistency guarantee among streaming databases. It ingests from Kafka and PostgreSQL CDC, maintaining incrementally updated materialized views. Use Materialize when you need continuously updated query results over streaming data with true multi-way joins.

Use dbt for established teams needing ecosystem breadth. Evaluate SQLMesh for cost-sensitive deployments or Databricks/Snowflake environments. Use Materialize for real-time streaming SQL views where strict consistency matters.

### ELT versus ETL decision framework

Choose ELT (raw-first loading) when using modern cloud warehouses with elastic compute, when schemas evolve frequently, or when ad-hoc exploration matters. Choose ETL (pre-transformation) when you need to reduce data volume before loading, enforce PII masking before data enters the warehouse, or face storage-cost constraints. The recommended hybrid for multi-tenant SaaS: lightweight ETL in the stream (PII masking, schema validation, enrichment via Flink or Kafka Streams), then ELT in the warehouse (dbt/SQLMesh transformations).

### Idempotency and exactly-once semantics

Every pipeline stage must be safely re-runnable. Kafka's idempotent producer (`enable.idempotence=true`, default since Kafka 3.0) guarantees exactly-once per partition within a producer session. For cross-partition atomicity, use the transactional API with `transactional.id` and consumer `isolation.level=read_committed`. At the sink, use upsert patterns (`INSERT ... ON CONFLICT DO UPDATE` in PostgreSQL, `MERGE` in warehouses). For consumer-side deduplication, track processed message IDs in Redis with TTL-based expiry or use natural business keys as dedup identifiers.

---

## 2. Data quality enforcement across the pipeline

### Schema validation at ingestion

For Kafka topics on a Go/TypeScript platform, **Protobuf is the strongest choice**. It offers excellent code generation for both Go (`protoc-gen-go`) and TypeScript (`ts-proto` or `protobuf.js`), produces the smallest binary payloads, and provides robust schema evolution via field tags. Avro excels for data pipeline topics where schemas change frequently, thanks to its built-in schema resolution mechanism. JSON Schema should be reserved for system edges—REST APIs, audit logs, configuration events—where human readability matters.

The Confluent Schema Registry enforces compatibility at the broker level. Use **BACKWARD compatibility** (the default) for most topics—new schemas can read data from the last version, allowing consumers to rewind to the beginning of the topic. For Protobuf, use **BACKWARD_TRANSITIVE** since adding new message types isn't forward-compatible. Use `TopicNameStrategy` for subject naming (required by ksqlDB and Flink) with union/oneof types for bounded polymorphism within a topic.

Non-breaking changes include adding optional fields with defaults and widening types (int32→int64). Breaking changes include removing required fields, changing types incompatibly, and reusing Protobuf field tag numbers. Treat schemas like code: version, test, and validate before deploying.

### Data contract testing tools

| Scenario | Recommended tool |
|---|---|
| Already using dbt for transformations | dbt tests + dbt-expectations package |
| Python-heavy engineering team, CI/CD focus | Great Expectations |
| Quick pipeline-embedded SQL checks | Soda Core (SodaCL) |
| Enterprise-wide automated observability | Monte Carlo |

**dbt tests** provide the tightest integration with transformation workflows. Built-in generic tests (`unique`, `not_null`, `accepted_values`, `relationships`) live in `schema.yml`. The **dbt-expectations** package (maintained by Datadog) adds Great Expectations-style assertions including `expect_column_values_to_be_within_n_moving_stdevs` for anomaly detection without manual threshold tuning. Unit tests (dbt v1.8+) validate transformation logic with mock data.

**Soda Core** uses a YAML-based DSL (SodaCL) with 25+ built-in metrics. Its anomaly detection uses Prophet under the hood. **Great Expectations** offers the most expressive Python-native validation with automated profiling and auto-generated Data Docs. **Monte Carlo** provides ML-powered zero-configuration monitoring across five pillars: freshness, volume, schema, lineage, and quality.

### Freshness monitoring and anomaly detection

Track freshness via heartbeat records injected at known intervals, metadata table checks (`MAX(updated_at)` against SLA), Kafka consumer group lag monitoring, and dbt source freshness configurations with `warn_after` and `error_after` thresholds. Define SLA tiers per table based on business impact.

For anomaly detection, Z-score works for normally distributed metrics, IQR is robust to outliers, and Prophet handles seasonality in time-series data. Use relative thresholds (percentage change from baseline) rather than absolute values. Monitor record counts per ingestion window to detect silent data loss—the most dangerous failure mode.

---

## 3. Analytics event tracking architecture

### Event schema design with the envelope pattern

Wrap every event in a standard envelope that separates infrastructure concerns from business data. The envelope carries routing metadata; the payload carries domain content:

```json
{
  "event_id": "550e8400-e29b-41d4-a716-446655440000",
  "event_type": "feature.used",
  "timestamp": "2026-01-30T14:30:00.000Z",
  "source": "api-service",
  "schema_version": "1.2.0",
  "tenant_id": "org-xyz789",
  "correlation_id": "req-abc-123",
  "trace_id": "4f3ae9d1c044abcd",
  "payload": {
    "user_id": "usr-abc123",
    "feature_name": "dashboard_export",
    "duration_ms": 3400,
    "success": true
  }
}
```

In Protobuf, use `google.protobuf.Any` for the payload field and `google.protobuf.Timestamp` for event time. Semantic versioning in the envelope (`schema_version`) is the recommended approach: major for breaking changes, minor for backward-compatible additions, patch for documentation.

### Event naming conventions and taxonomy

The industry converges on the **object-action pattern** using past tense: `user.signed_up`, `feature.used`, `subscription.upgraded`. Use dot-separated snake_case for backend systems and consistent casing everywhere—Amplitude treats `Song Played` and `song played` as separate events. Build a hierarchical taxonomy organized by domain:

```
account.created / account.upgraded / account.churned
user.signed_up / user.invited / user.activated
feature.used / feature.limit_reached
billing.invoice_paid / billing.payment_failed
```

Event names should be **view-agnostic**—track location as a property, not in the event name. Maintain an event catalog (Segment's Tracking Plan pattern) that lists every event with its name, description, properties, and data types, validating live events against the spec.

### Event routing and late-arriving data

Route events through a three-stage pipeline: raw events → validated events (with DLQ for failures) → enriched events (user/org context, geo lookup). From the enriched topic, fan out to real-time consumers (Kafka Streams → Redis/dashboards), the warehouse (Kafka Connect sink), and product analytics platforms.

For late-arriving data, use **heuristic watermarks**: `watermark = max_observed_timestamp - configured_delay`. Configure allowed lateness windows on stream processors (e.g., Flink's `allowedLateness(Time.minutes(10))` with side output for late events). Kafka Streams uses grace periods—windows close when `watermark >= windowEnd + grace`. Events arriving after the grace period route to a batch reprocessing queue for correction.

Volume estimation for SaaS: **50–200 events per active user per day** for typical products, with server-side events running 5–20× client-side volume. At 10K DAU with 100 events/day, expect ~1M events/day (~12 events/second average, ~50 peak). Average event size is 500 bytes to 2KB in JSON, 200–500 bytes in Protobuf.

---

## 4. Choosing a data warehouse for growing SaaS analytics

### Architecture and performance characteristics

**ClickHouse** dominates single-table aggregation workloads, delivering **2–10× faster** performance than Snowflake on COUNT/SUM/GROUP BY over raw event data with vectorized SIMD execution. It supports 1,000+ concurrent queries per node and has the richest native Kafka integration (built-in Kafka table engine, ClickPipes managed ingestion, official Kafka Connect sink with exactly-once semantics).

**Snowflake** excels at complex multi-table joins and mixed workloads with its optimizer handling multi-table operations efficiently. Separated storage and compute enables independent scaling. Default concurrency is ~8 per warehouse, expandable via multi-cluster warehouses.

**BigQuery** offers true serverless operation with slot-based parallelism across thousands of nodes. Typical query latency is **1–2 seconds minimum**—excellent for ad-hoc batch analytics but unsuitable for sub-second serving. Native integration with Google's ML and BI ecosystem is unmatched.

**DuckDB** serves as the embedded analytics engine—"SQLite for analytics." It excels at window functions and single-user analytical queries on local data. Not designed for concurrent multi-user production serving but ideal for development, testing, and embedded per-tenant analytics under ~2TB.

### Cost comparison at different scales

| Scale | BigQuery (On-Demand) | Snowflake (Enterprise) | ClickHouse Cloud | DuckDB |
|---|---|---|---|---|
| **100 GB** | $50–200/mo | $400–800/mo | $50–200/mo | $0–50/mo |
| **1 TB** | $200–1,000/mo | $800–2,000/mo | $200–500/mo | $50–200/mo |
| **10 TB** | $1,000–5,000/mo | $2,000–8,000/mo | $500–2,500/mo | $200–800/mo |
| **100 TB** | $5,000–25,000/mo | $10,000–50,000/mo | $2,000–10,000/mo | Not practical |
| **1 PB** | $20,000–100,000/mo | $50,000–200,000/mo | $10,000–50,000/mo | Not practical |

BigQuery charges $5/TB scanned (on-demand) or ~$0.04–0.10/slot-hour (capacity). Snowflake credits cost $2–4 each, with warehouses consuming 1–128 credits/hour. ClickHouse Cloud scales to zero when idle (15-minute timeout) and delivers **~3–5× better cost-performance** than Snowflake for analytical workloads. Storage across all platforms is roughly $20–25/TB/month.

### Stage-appropriate warehouse selection

**Startup (0–1TB)**: Start with DuckDB for local analytics and ClickHouse Cloud Dev tier (~$50–200/month) for production event analytics. Avoid Snowflake/BigQuery—overkill and unpredictable costs.

**Growth (1–10TB)**: ClickHouse Cloud Scale tier for real-time event analytics and product analytics. Add BigQuery for ad-hoc analysis if on GCP. dbt for transformations across either platform.

**Scale (10TB+)**: Hybrid architecture—**ClickHouse for real-time serving** (sub-second latency, high concurrency, last 30–90 days of hot data) and **Snowflake or BigQuery for historical analytics** (complex joins, BI reporting, ML workloads, full dataset). This dual-engine pattern is explicitly recommended across the industry.

### Multi-tenancy patterns per warehouse

ClickHouse: shared tables with `tenant_id` in the primary key (`ORDER BY (tenant_id, timestamp)`) ensures co-located data for efficient filtering. Add row policies for RBAC.

Snowflake: Row Access Policies (Enterprise edition) apply row-level filtering based on session context. Secure views prevent exposure of underlying logic. Reader accounts enable external tenant data sharing.

BigQuery: Dataset-per-tenant is Google's recommended approach, scaling to thousands of tenants. Use Dataflow to dual-write to tenant-specific and internal tables. Row-level security and authorized views provide finer-grained control.

Across all warehouses, **partition by `tenant_id`** (or include it as a leading sort/cluster key) and enforce row-level security as a defense-in-depth layer beneath application-level filtering.

---

## 5. Pipeline observability and failure handling

### Orchestrator comparison

**Dagster** (recommended for new builds) uses an asset-centric model where pipelines are defined as versioned data assets, not tasks. Built-in observability includes metadata tracking, a lineage graph, an asset catalog, data quality checks, and Snowflake spend tracking. HIVED achieved **99.9% pipeline reliability** with zero data incidents over three years using Dagster. Its federated orchestration feature can observe and govern existing Airflow DAGs.

**Airflow 3.0** (April 2025) added DAG versioning, multi-language Task SDKs, and event-driven scheduling. With 30M+ monthly downloads across 80K+ organizations, it has the largest ecosystem. Best for teams with existing integrations and complex time-based scheduling.

**Prefect** offers the easiest setup with Python-native decorators, automatic retries with exponential backoff, and async support. Best for small-to-mid teams wanting quick setup and dynamic workflows.

### Data lineage from Kafka to warehouse

Implement end-to-end lineage using the **OpenLineage** spec (Linux Foundation Graduate project). The architecture: Debezium emits OpenLineage events natively (announced June 2025), Flink integrates via OpenLineage adapters, Kafka Connect uses the `OpenLineageLifecycleSmt` single message transform, and dbt/SQLMesh produce lineage graphs. All feed into **Marquez** as the lineage server for unified visualization. SQLMesh provides automatic column-level lineage via SQL parsing; dbt Cloud offers it as a premium feature.

### Failure handling patterns

Use **exponential backoff with jitter** for retries: `wait = random(0, base_delay × 2^attempt)`. Cap at 3–5 retries before routing to a dead letter queue. DLQs should include the original message plus error metadata (type, stack trace, timestamp, retry count). Separate DLQs by error type: serialization errors versus validation failures versus downstream service failures.

Implement **circuit breakers** on external dependencies: track consecutive failures, open the circuit after a threshold (e.g., 5 failures), allow a single test call after a cooldown period (e.g., 60 seconds), and re-open if the test fails. In Go, use custom implementations; in TypeScript, use libraries like `opossum`.

Monitor these critical metrics: pipeline execution duration (p50, p95, p99), success/failure rates per stage, data freshness, record counts (expected versus actual for silent data loss detection), Kafka consumer lag, DLQ message rates, and replication slot lag for CDC. Route critical SLA breaches to PagerDuty, warnings to Slack, informational to dashboards.

---

## 6. Privacy and compliance in analytics infrastructure

### Anonymization and differential privacy

Classical anonymization techniques provide layered protection. **K-anonymity** ensures each individual is indistinguishable from at least k-1 others on quasi-identifiers (age, zip, gender) via generalization and suppression. **L-diversity** requires at least l well-represented values for sensitive attributes within each equivalence class, addressing the homogeneity attack. **T-closeness** constrains the distribution of sensitive attributes to be within distance t of the overall distribution. These techniques are necessary but **not sufficient for GDPR anonymization alone**—they reduce re-identification risk without guaranteeing it.

Differential privacy adds formal mathematical guarantees. **Epsilon (ε)** controls the privacy budget: values of 0.1 provide strong privacy (more noise), 10 provides weak privacy. For practical implementation, **Tumult Analytics** (used by the US Census and IRS) prevents DP violations at the API level and scales to 100M+ rows. **DiffPrivLib** (IBM) has the simplest API but does not enforce correct sensitivity bounds. **BigQuery** offers native DP via `WITH DIFFERENTIAL_PRIVACY` clause on aggregate functions, powered by a partnership with Tumult Labs.

### PII detection and GDPR compliance

Scan for PII at ingestion time using stream processors before data lands in the warehouse. **Microsoft Presidio** (open-source) provides NER + regex + rule-based detection across 20+ languages, deployable as a microservice. **Google Cloud DLP API** offers 150+ built-in detectors with sub-100ms latency and native BigQuery integration. **AWS Macie** automatically discovers and classifies PII across S3 buckets.

For GDPR right to deletion in analytics warehouses, use a **pseudonymization architecture**: split PII into a lookup table linked by pseudonymous ID to analytical data. On deletion request, delete the lookup entry—analytical data becomes truly anonymous. For columnar storage (Parquet, ORC), individual row deletion is expensive. Delta Lake supports DELETE commands that create new file versions, cleaned up via VACUUM. In BigQuery, DML DELETE works but is costly at scale—partition by user or tenant for efficient deletion. Batch deletion requests monthly and maintain audit logs.

### Multi-tenant data isolation

Implement **row-level security** as defense-in-depth beneath application filtering:

```sql
ALTER TABLE analytics.events ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON analytics.events
  USING (tenant_id = current_setting('app.current_tenant')::UUID);
```

Set tenant context at the connection pool level, not in application queries. Create application database roles WITHOUT `BYPASSRLS` privilege. For cross-tenant platform analytics (internal only), use a separate service account with BYPASSRLS running on pre-aggregated anonymous data only.

Use a tiered isolation strategy: free tier gets shared schema with RLS, professional tier gets schema-per-tenant, enterprise tier gets database-per-tenant with dedicated compute.

---

## 7. Real-time analytics with approximate algorithms and stream processing

### Redis patterns for sub-millisecond analytics

Redis excels as the real-time analytics serving layer. **Atomic counters** (`INCR`/`INCRBY`) with time-bucketed keys and TTLs provide sliding window metrics. **Sorted sets** (`ZINCRBY`, `ZREVRANGE`) power leaderboards and top-K rankings. **HyperLogLog** uses a fixed **12KB** per counter with **0.81% standard error** for unique counts—track unique visitors, distinct events, or cardinality estimates at negligible memory cost. **Bitmaps** enable DAU tracking with `SETBIT`/`BITCOUNT` where each bit represents a user ID.

Pipeline batch all Redis commands using `r.pipeline()` to reduce network round-trips by 5–10×.

### Approximate algorithms decision matrix

| Algorithm | Problem | Error | Memory | Production use |
|---|---|---|---|---|
| HyperLogLog | Count distinct | ~0.81% | 12KB fixed | Unique visitors (Redis, ClickHouse `uniqHLL12`) |
| Count-Min Sketch | Frequency count | Configurable | Fixed (w×d counters) | Heavy hitters, Top-K (RedisBloom) |
| T-Digest | Percentiles | ~1% at extremes | ~64KB | P95/P99 latency (Elasticsearch, ClickHouse `quantileTDigest`) |
| Bloom Filter | Set membership | FP only | ~10 bits/element | Dedup pre-check, crawl tracking |

T-Digest is **especially accurate at extreme percentiles** (p95, p99) because error is proportional to q(1-q). It's the default algorithm for Elasticsearch's percentiles aggregation and available in ClickHouse as `quantileTDigest()`.

### Materialized views and stream processing

PostgreSQL materialized views refreshed via pg_cron (`REFRESH MATERIALIZED VIEW CONCURRENTLY`) suit hourly/daily dashboards. For true incremental maintenance, **pg_ivm** (PostgreSQL 17) eliminates full recomputation by updating views automatically via triggers—but it's unavailable on managed services (RDS, Cloud SQL). **TimescaleDB continuous aggregates** provide the most practical incremental solution for time-series workloads on managed PostgreSQL.

Kafka Streams and ksqlDB handle windowed aggregations directly on the stream. Tumbling windows provide fixed non-overlapping buckets, hopping windows give overlapping analysis, and session windows close after configurable inactivity gaps. State is backed by RocksDB with changelog topics for fault tolerance. ksqlDB materialized views support both pull queries (point-in-time lookup) and push queries (continuous updates).

**When to choose each tier**: real-time (sub-second) for user-facing features where latency is competitive advantage; near-real-time (1–15 minutes) for operational dashboards and internal alerting; batch (hourly/daily) for historical analytics, compliance reporting, and ML training where accuracy trumps freshness.

---

## 8. Feature stores for production ML on SaaS platforms

### Computation and serving architecture

Feature computation spans three tiers: **batch features** (daily/hourly via Spark or dbt, for stable signals like 30-day engagement scores), **streaming features** (from Kafka via Flink, for time-sensitive signals like recent error rates or session activity), and **on-demand features** (computed at request time, for context-dependent values like current cart contents). The offline store (Parquet on S3/GCS or warehouse tables) serves training data via point-in-time correct joins. The online store (Redis or DynamoDB) serves latest feature values with sub-millisecond latency for real-time inference.

### Platform comparison and recommendation

**Feast** (open-source, Linux Foundation) is the recommended starting point for a Kafka + Go/TypeScript stack. Its pluggable architecture supports Redis as online store, Parquet on S3/GCS as offline store, and KafkaSource for streaming features. Go services consume features via the HTTP or Java gRPC feature server (port 6566). TypeScript services use the REST endpoint. Multi-tenant isolation uses `tenant_id` as part of composite entity keys.

**Hopsworks** offers the best-in-class online store performance via RonDB (sub-millisecond latency, SIGMOD 2024 benchmarked) and native streaming support via Spark Streaming and Flink. **Tecton** (founded by Uber's Michelangelo creators) provides a fully managed platform with the new Rift compute engine (Arrow + DuckDB + Ray) that eliminates the Spark dependency for many workloads.

Build a custom feature store only if you have 5+ dedicated ML platform engineers, unique requirements, and willingness to invest 6–24 months—Airwallex spent 6 months on initial feature store and still lacked a UI or Python SDK.

### Point-in-time correctness prevents data leakage

Using feature values from the future in training data causes models to appear accurate in development but fail in production—affecting an estimated **~40% of production models**. Feature stores solve this with AS OF LEFT JOIN: for each training example at time T, join the most recent feature value where `feature_timestamp <= T`. Feast's `get_historical_features()` performs this automatically. Store three timestamps per feature record: event time (when it happened), entity timestamp (when the prediction occurred), and ingestion time (when data was written).

Monitor feature drift using Population Stability Index (PSI) or Kolmogorov-Smirnov tests. **Evidently AI** (open-source, 20M+ downloads) provides comprehensive drift detection dashboards. Alert only on high-importance features—statistical significance does not equal business significance.

---

## 9. Data modeling patterns for SaaS analytics

### Dimensional modeling remains the gold standard

The Kimball star schema—central fact tables connected to dimension tables via surrogate keys—provides the most reusable, query-friendly foundation for SaaS analytics. **Transaction fact tables** (one row per event) capture feature usage and user actions at the lowest grain. **Periodic snapshot facts** (one row per entity per period) track daily engagement metrics, monthly revenue, and subscription states. **Accumulating snapshot facts** (one row per lifecycle) model subscription journeys from trial through conversion to churn.

Conformed dimensions (dim_user, dim_feature, dim_date, dim_tenant) shared across fact tables create a single source of truth. Build a bus matrix mapping which dimensions apply to which business processes.

### Event-based models and the OBT approach

The **Activity Schema** (by Narrator) models all data as a single time-series table with a fixed 11-column structure: entity_id, activity, timestamp, revenue_impact, and five generic feature columns. Queries use temporal joins instead of foreign keys—excellent for behavioral and funnel analysis across the entire customer journey without complex dimensional modeling.

**One Big Table (OBT)** pre-joins all facts and dimensions into a single wide denormalized table. This eliminates joins at query time (critical for distributed systems) and simplifies BI tool queries. The recommended hybrid (Brooklyn Data approach): build the dimensional model as the Gold layer, then create OBT data marts on top for specific reporting use cases. OBTs inherit SCD properties from underlying dimensions.

### Slowly changing dimensions in practice

**SCD Type 2** (versioned rows with valid_from/valid_to dates) is the workhorse for analytics—tracking plan changes, address updates, and status transitions with full history. dbt snapshots implement this natively:

```yaml
snapshots:
  - name: customer_snapshot
    relation: source('app_db', 'customers')
    config:
      unique_key: customer_id
      strategy: timestamp
      updated_at: updated_at
```

dbt automatically adds `dbt_valid_from`, `dbt_valid_to`, and `dbt_updated_at` columns. Snapshot at the source (not final models) to capture everything for future use. Run snapshots between hourly and daily intervals.

Use **Type 1** (overwrite) only when history doesn't matter (fixing typos). Use **Type 6** (hybrid 1+2+3) when you need both a current-value shortcut and full versioned history—useful for BI tools that struggle with Type 2 temporal joins.

### Multi-tenant modeling essentials

Include `tenant_id` on every fact and dimension table as a first-class dimension. In ClickHouse, use `ORDER BY (tenant_id, event_timestamp, event_type)` with `PARTITION BY (tenant_id, toYYYYMM(event_timestamp))` and TTL for automatic expiration. For daily snapshots tracking subscription states at 1M subscriptions × 365 days, expect **365M rows/year**—columnar compression makes this manageable. Apply tiered retention: daily snapshots for 90 days, weekly for 1 year, monthly for 3+ years.

---

## 10. Engineering rules of thumb for data pipeline development

### Testing and CI/CD

Test at every layer: unit tests for transformation logic (dbt unit tests with mock data, standard Go/TypeScript test frameworks for producer/consumer logic), integration tests with test containers (Kafka, PostgreSQL), and data quality tests in production (dbt-expectations, Soda, Great Expectations).

For dbt CI, use **slim builds** with `state:modified+` selectors comparing current code against production's `manifest.json`. This builds only modified models and their downstream dependencies—often 2 out of 1,000 models. Persist `manifest.json` to S3/GCS after each production run. SQLMesh's virtual environments make CI nearly zero-cost—no warehouse rebuild required.

### Backfill strategies

Divide backfills into **time-partitioned chunks** (daily or hourly partitions) processed independently. This enables parallelism and failure isolation—a failed partition doesn't block others. SQLMesh handles this natively, batching backfills into manageable chunks. dbt requires `--full-refresh` or custom macros with date-range variables. For CDC, use Debezium incremental snapshots to re-snapshot specific table chunks without restarting from scratch.

Validate backfills by comparing row counts between source and destination per partition and running checksum validation on key columns.

### Cost optimization patterns

**Partition by date** on every time-series table—this is the single highest-impact cost optimization. BigQuery eliminates scanning irrelevant partitions entirely. Snowflake's automatic micro-partitioning skips **99.4% of data** across all customer workloads. Cluster by frequently filtered columns (tenant_id, service_name) within partitions.

Choose materialization strategies deliberately: views for lightweight, rarely-queried models; tables for heavily-queried or complex models; incremental for large, append-heavy tables; ephemeral for intermediate CTEs. Monitor warehouse compute usage with Dagster's built-in cost management suite (for Snowflake) or BigQuery's slot utilization metrics. Fix query design before scaling up warehouse size—right-size compute based on query complexity, not data volume.

---

## Conclusion

The core architectural decisions for a growth-stage multi-tenant SaaS analytics platform reduce to a handful of high-leverage choices. Use **Protobuf with Confluent Schema Registry** for event serialization from Go and TypeScript services into Kafka. Adopt a **hybrid warehouse strategy**—ClickHouse for real-time serving, Snowflake or BigQuery for historical analytics—as you grow past 10TB. Choose **Dagster** for orchestration and **dbt or SQLMesh** for transformations based on team maturity and cost sensitivity. Enforce **row-level security with tenant_id** as a first-class dimension everywhere, from Kafka topic design through warehouse table partitioning.

The most dangerous failure modes in production pipelines are silent: missing data that doesn't trigger alerts, cross-tenant data leakage from a missed WHERE clause, and training-serving skew from incorrect point-in-time joins. Every engineering pattern in this guide—idempotent pipelines, dead letter queues, schema validation at ingestion, RLS as defense-in-depth, feature store temporal joins—exists to make these silent failures loud. Build the alerting and quality infrastructure before you need it, because by the time you notice the problem, the damage is already in your dashboards and ML models.