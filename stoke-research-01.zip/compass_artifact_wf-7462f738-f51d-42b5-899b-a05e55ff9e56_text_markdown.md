# Self-configuring AI: ten design dimensions for an adaptive coding orchestrator

A coding orchestrator like Stoke can draw on a deep body of published research—from AutoML and reinforcement learning to Kubernetes control loops and recommendation systems—to continuously adapt its configuration as a codebase evolves. **The central insight across all ten dimensions is that orchestrator configuration is itself an optimization problem**, one that can be warm-started from prior projects, refined online through bandit algorithms, safeguarded by feature-flag experimentation infrastructure, and kept current through drift detection and self-healing loops. What follows is a detailed analysis of each dimension, with concrete systems, published references, and practical mappings to a Stoke-like orchestrator.

---

## 1. AutoML turns orchestrator configuration into a search problem

The foundational insight of AutoML is the **CASH problem** (Combined Algorithm Selection and Hyperparameter optimization), first formalized by Thornton et al. (2013) in Auto-WEKA: given a dataset, simultaneously select the best learning algorithm and its hyperparameters to minimize validation loss. This framing applies directly to a coding orchestrator, where the "dataset" is a codebase and the "pipeline" is the agent's full configuration stack.

Auto-sklearn (Feurer et al., NeurIPS 2015) operationalized this with two innovations that transfer cleanly. First, **meta-learning warm-starting**: the system computes 38 meta-features for a new dataset (skewness, dimensionality, class balance), finds the 25 most similar datasets from a library of 140, and seeds Bayesian optimization with their best configurations. This eliminates cold-start by leveraging what worked before on structurally similar problems. Second, **ensemble construction**: rather than committing to one pipeline, Auto-sklearn builds ensembles from all evaluated models using Caruana et al.'s (2004) ensemble selection with replacement, improving generalization substantially. Auto-sklearn 2.0 (Feurer et al., JMLR 2022) simplified this further with a **portfolio of 16 diverse configurations** selected via greedy submodular optimization over 421 datasets, eliminating meta-feature computation entirely.

The optimization backbone is Bayesian optimization via SMAC (Hutter et al., 2011), which uses random forest surrogates that natively handle the discrete, conditional, and hierarchical parameter spaces that characterize orchestrator configuration. BOHB (Falkner et al., ICML 2018) extends this with multi-fidelity evaluation—testing configurations cheaply first (few training epochs) before investing in expensive full evaluations—achieving strong anytime performance.

**Mapping to Stoke.** The orchestrator's hyperparameters form a hierarchical configuration space directly analogous to AutoML's:

| Orchestrator parameter | AutoML analog | Optimization approach |
|---|---|---|
| Model selection per task type | Algorithm selection in CASH | Portfolio of model assignments; bandit-based online selection |
| Verification depth (none → syntax → unit test → integration) | Budget allocation in multi-fidelity | BOHB-like: start cheap, escalate for uncertain outputs |
| Skill/tool routing | Feature preprocessing selection | Meta-learning from task-type features |
| Context window allocation | Data preprocessing hyperparameters | TPE over continuous parameter space |
| Decomposition granularity | Model complexity (tree depth) | Portfolio warm-started from similar past tasks |
| Retry strategies | Early stopping parameters | Bayesian optimization with racing |

**Codebase meta-features** (analogous to dataset meta-features) would include language, framework, lines of code, cyclomatic complexity, test coverage, dependency count, team size, and PR velocity. A practical bootstrap strategy: build a portfolio of 10–20 orchestrator configurations optimized across a benchmark of ~100 diverse coding tasks, then warm-start new projects from the nearest portfolio member. This mirrors Auto-sklearn 2.0's approach and avoids the complexity of per-project meta-feature extraction.

---

## 2. Adaptive difficulty calibrates the orchestrator to the task's demands

Three bodies of research converge on the principle that systems should match their effort to the difficulty of the problem at hand, adjusting dynamically based on observed performance.

**Computerized Adaptive Testing (CAT)** uses Item Response Theory (Lord, 1980) to select test questions that maximize information at the examinee's current ability level. Each item has parameters for difficulty and discrimination; the algorithm maintains a Bayesian estimate of ability (θ) and selects items at the boundary of what the examinee can handle. The GRE, GMAT, and NCLEX all use this approach. For Stoke, this suggests maintaining a **task difficulty catalog** parameterized like IRT items and tracking the agent's demonstrated ability per task category, then selecting configurations (model tier, decomposition depth, verification level) that match the current ability estimate.

**Dynamic Difficulty Adjustment** in games provides the most vivid implementation models. Left 4 Dead's AI Director (Booth, 2009, Valve) tracks a real-time "perceived stress" metric for each player and creates peaks and valleys of intensity. A critical design insight: **the Director adjusts pacing frequency, not difficulty amplitude**—it doesn't permanently downgrade challenge but modulates the rhythm of intensity. When stress is too high, it enters "Relax" mode and reduces threats; when too low, it spawns mobs. It also performs adaptive resource allocation, converting pain pills to medkits when team health is critical. Hunicke (2005) formalized the principle that adjustments must be **invisible** to preserve the user's experience.

**Curriculum learning** (Bengio et al., ICML 2009) showed that presenting training examples in order of increasing difficulty improves both convergence speed and final performance, acting as a continuation method that smooths the optimization landscape. Self-Paced Learning (Kumar et al., 2010) extended this by letting the model itself determine difficulty based on its current loss. Narvekar et al. (JMLR 2020) provided the definitive survey of curriculum learning for RL, identifying three key components: task generation, task sequencing, and knowledge transfer.

**Failure-adaptive strategies for Stoke.** When the agent keeps failing at a task type, the orchestrator should implement a graduated response: (1) escalate to a more capable model, (2) decompose the task into subtasks within the agent's demonstrated ability range, (3) add verification layers (test execution, type checking), (4) switch approach entirely (from generation to retrieval-augmented), and (5) log failure patterns to build task-specific few-shot examples from successful past solutions. The key implementation principle from Hunicke: these escalations should be **transparent to the developer**, happening automatically behind the scenes.

---

## 3. Bandit algorithms make model routing practical and cost-aware

Reinforcement learning—particularly multi-armed bandits and contextual bandits—provides the online adaptation layer for real-time orchestrator decisions. The core tradeoff is exploration (trying new configurations) versus exploitation (using the best-known one), and modern bandit algorithms handle this with strong theoretical and empirical properties.

**Thompson Sampling** maintains a Bayesian posterior over each arm's reward distribution, samples from each posterior, and selects the arm with the highest sample. It is proven asymptotically optimal (Chapelle & Li, 2011), handles delayed and batched feedback gracefully, and is the industry standard at companies like DoorDash and Netflix. **LinUCB** (Li et al., WWW 2010) extends bandits to incorporate context features, modeling expected reward as a linear function of context and maintaining confidence ellipsoids for exploration. It was originally developed for personalized news recommendation at Yahoo.

A wave of recent research applies these algorithms directly to **LLM routing**:

- **FrugalGPT** (Chen, Zaharia & Zou, 2023) implements an LLM cascade that queries models cheapest-first, using a DistilBERT-based scorer to determine when to stop. It matches GPT-4 quality with **98% cost reduction**.
- **RouteLLM** (Ong et al., 2024) trains router models using human preference data and data augmentation, reducing costs by **2× or more** without quality loss and demonstrating transfer to unseen model pairs.
- **ParetoBandit** (2025) introduces cost-aware contextual bandits with online primal-dual budget pacing and geometric forgetting for non-stationarity—the first LLM router to simultaneously enforce budgets and adapt to price/quality shifts.
- **Agent Lightning** (Microsoft Research, Luo et al., 2025) provides a framework for RL training of any AI agent with zero code modifications, using hierarchical credit assignment across multi-step trajectories.

**Mapping to Stoke.** Each orchestrator decision maps to a bandit problem: which model for code generation (K-armed contextual bandit, arms = models, context = task features), verification depth selection (contextual bandit with ordered arms), retry vs. escalate (2-armed bandit), and tool/skill selection (contextual bandit over available tools). The reward signal should be a composite: `reward = α × task_success + β × code_quality − γ × cost − δ × latency`, where task success uses verifiable signals from code execution (RLVR). Sample efficiency—critical since coding tasks are expensive—is addressed through warm-starting from offline logs, cheap proxy rewards (compilation, lint checks) as intermediate signals, and Thompson Sampling's robustness to delayed feedback.

---

## 4. Feature flags and chaos engineering create safe experimentation infrastructure

These two dimensions form a natural pair: feature flags provide the control plane for configuration experimentation, while chaos engineering provides the safety methodology.

**Feature flag platforms** have evolved from simple on/off toggles to sophisticated experimentation infrastructure. LaunchDarkly now offers dedicated **AI Model and AI Prompt flag types** (GA as of 2025) with JSON variations controlling model name, temperature, max_tokens, and system prompts, with targeting rules that deliver different configurations to different user segments. Statsig provides **Autotune** (multi-armed bandits) and **Autotune AI** (contextual bandits) for automated configuration optimization, plus Release Pipelines with webhook-triggered benchmark gates that block unsafe rollouts. Eppo, acquired by Datadog for ~$220M in 2025, provides warehouse-native experimentation; Perplexity uses Eppo to "test and orchestrate the matching of various AI models to use cases within their product and userbase."

Statistical methods in these platforms have matured significantly. **Sequential testing** allows peeking at results without inflating false-positive rates. **Bayesian A/B testing** provides continuous posterior updates and decisions based on "probability of being best." Multi-armed bandits dynamically shift traffic toward winning variants during experiments, minimizing exposure to inferior configurations. Configuration-as-code approaches (OpenFeature CRDs + ArgoCD GitOps) enable storing agent configurations in Git, managed via PRs with full audit trails.

**Shadow deployment** runs a challenger configuration alongside the champion, processing the same requests but never serving the challenger's output to users. This is the zero-risk validation technique described by JFrog ML and Wallaroo.AI. **Canary deployment** follows a phased progression: shadow → 1% canary → 20% → 50% → 100%, with metric gates at each stage. **Interleaving experiments** (Chapelle et al., 2012; Airbnb 2025) present merged results from two rankers and track which "team's" items users prefer, achieving a **50× speedup** over traditional A/B testing according to Airbnb's production results.

**Safe experimentation protocol for Stoke.** The recommended sequence: (1) offline evaluation against a benchmark suite (SWE-bench, HumanEval, internal corpus), (2) shadow deployment processing 100% of real tasks for 24–48 hours with output comparison, (3) automated benchmark gate (Statsig-style webhook validates before advancing), (4) canary at 1% serving real users with all metrics monitored, (5) gradual rollout 5% → 20% → 50% → 100% with gates, and (6) a kill switch for instant reversion if any guardrail metric degrades. Key metrics: task completion rate, code correctness (tests pass), first-pass success rate, latency, cost per task, and safety score. The cost of shadow execution (doubling compute) can be mitigated by sampling 10% of tasks or using cheaper evaluation models for the shadow comparison.

---

## 5. Implicit feedback reveals developer preferences without asking

Recommendation system research provides a mature framework for learning what developers actually want from the patterns of their behavior rather than explicit surveys or configuration.

The landmark paper by Hu, Koren & Volinsky (ICDM 2008) on **collaborative filtering for implicit feedback** introduced the key distinction between preference (binary: does the user want this?) and confidence (proportional to interaction frequency). Their Weighted Alternating Least Squares (WALS) algorithm scales linearly with data size and handles the fundamental asymmetry of implicit signals: observing an interaction suggests preference, but not observing one is ambiguous.

Recent research on AI coding assistants validates this framework. Mozannar, Bansal, Fourney & Horvitz (AAAI 2024) developed **CDHF** (Conditional Display from Human Feedback) for GitHub Copilot, training cascaded models on telemetry from 535 programmers to predict suggestion acceptance. By selectively hiding likely-to-be-rejected suggestions, they **increased acceptance rate by 7.2%**. Critically, they found that the programmer's latent cognitive state (implementing vs. debugging vs. thinking) significantly affects acceptance, and that **using acceptance as the sole reward signal can reduce quality**—the system learns to suggest only "safe" completions. Jiang et al. (2025) analyzed 66,329 industrial developer-AI interactions and found a strong momentum effect: past acceptance predicts future acceptance, achieving **0.973 accuracy** in acceptance prediction.

For Stoke, the implicit feedback signals available form a rich gradient of confidence levels. PR acceptance by a reviewer provides the highest-confidence positive signal. User edits to generated code reveal specific style preferences through edit distance analysis. Rejection and regeneration signals configuration mismatch. Time spent reviewing before acceptance indicates suggestion confidence. The **collaborative filtering approach** for multi-developer teams would build a developer × configuration matrix, use Hu et al.'s implicit feedback framework with confidence weights, and apply matrix factorization to discover latent factors like "prefers verbose vs. concise code" or "tolerates AI autonomy vs. wants verification." A two-tier system works well: quick bandit-level adjustments per task, with slower collaborative-filtering retraining periodically (nightly).

---

## 6. Drift detection and self-healing keep configuration current

These two dimensions form a natural pipeline: drift detection identifies when configuration has become stale, and self-healing reconciles it with reality.

**Configuration drift** in infrastructure tools follows a clear pattern: define baseline (desired state from IaC), observe current state, compute delta, classify severity, alert or remediate. Terraform uses a three-way comparison between `.tf` files, `terraform.tfstate`, and actual cloud resources. HCP Terraform supports periodic health assessments that automatically detect drift and alert via Slack. For a coding orchestrator, drift manifests as **divergence between the orchestrator's model of the codebase and the codebase's actual reality**—new frameworks added, architecture patterns shifted, team practices evolved.

**Change point detection algorithms** provide the mathematical foundation for detecting when something fundamental has changed. Bayesian Online Changepoint Detection (Adams & MacKay, 2007) computes the probability distribution of "run length" (time since last changepoint) using recursive message passing, working in real-time and handling uncertainty about whether a change has occurred. PELT (Killick et al., 2012) achieves optimal changepoint detection with **linear expected computational cost** through dynamic programming with pruning. **Concept drift** in ML (Lu et al., IEEE TKDE 2018) provides a comprehensive framework for detecting when the statistical properties of the target variable change, with types including sudden, gradual, incremental, and recurring drift.

For Stoke, monitoring signals should include structural indicators (new file patterns, dependency changes, config file additions), behavioral indicators (test failure rate trends, PR rejection rate changes), and external signals (linting rule changes, CI pipeline modifications). Applying BOCPD to time-series of PR acceptance rates can detect the exact moment when something shifted.

**Self-healing** draws directly from the Kubernetes reconciliation loop: observe → diff → act, continuously. The MAPE-K reference model (Kephart & Chess, 2003) formalizes this as Monitor → Analyze → Plan → Execute over shared Knowledge, defining four self-* properties: self-configuration, self-healing, self-optimization, and self-protection. The Rainbow framework (Garlan et al., CMU, 2004) separates generic adaptation infrastructure from system-specific knowledge, using probes, gauges, model managers, and an adaptation engine with the "Stitch" strategy language. Control theory adds PID-like principles: proportional response to current error (PR rejection rate jumps 20% → proportionally increase reconfiguration urgency), integral response to accumulated error (rejection rate slowly climbing for weeks → trigger thorough reconfiguration), and derivative response to rate of change (rejection rate accelerating → proactively begin reconfiguration).

**Recommended layered reconciliation for Stoke:**

- **Inner loop** (per-task, high frequency): quick checks—is the task result consistent with expectations? Bandit-level parameter adjustments.
- **Middle loop** (daily/weekly): structural drift detection—has the codebase fingerprint changed significantly? Update codebase meta-features and check for concept drift in task outcomes.
- **Outer loop** (on major events): full reconfiguration assessment—should the orchestrator's fundamental model be rebuilt? Requires human approval for high-impact changes.

Critical implementation considerations include **stability vs. responsiveness** (in control theory terms, the damping problem—implement a settling period after each configuration change), **confidence tiers** for autonomy (auto-apply small tweaks, suggest significant changes with rationale, require human approval for fundamental reconfiguration), and **multi-loop coordination** using patterns from decentralized MAPE-K research (Weyns et al., 2013).

---

## 7. Transfer learning bootstraps new projects from prior experience

If a team has configured Stoke for five repositories, the sixth should start with a strong baseline rather than from scratch. Meta-learning research provides the theoretical foundation, and cross-project transfer studies identify the pitfalls.

**MAML** (Finn et al., ICML 2017) learns parameter initializations that adapt to new tasks in just a few gradient steps through bi-level optimization. **Reptile** (Nichol et al., 2018) simplifies this dramatically—requiring only black-box optimizer access—by repeatedly sampling tasks, training for k steps, and moving the initialization toward the trained weights. Despite its simplicity, Reptile performs competitively with MAML on standard benchmarks, making it attractive for practical deployment.

The most directly applicable system is **Auto-sklearn's meta-learning**: datasets with similar meta-features perform similarly under the same configurations. Auto-sklearn 2.0's portfolio-based approach is even more practical—a fixed portfolio of 16 diverse configurations selected via greedy submodular optimization works robustly across datasets without computing meta-features at all. Cereda et al. (LCTES 2020) published a **collaborative filtering approach for compiler optimization**, directly applying matrix factorization to recommend optimization flag sequences based on program similarity—the exact analog of recommending orchestrator configurations based on repository similarity.

However, **transfer is not guaranteed**. Zimmermann et al. (ESEC/FSE 2009) found that **only 3.4%** of 622 cross-project pairs had adequate transfer power for defect prediction, establishing that naive transfer is dangerous without careful similarity matching. This finding is a crucial design constraint: Stoke must validate transfer quality and fall back to portfolio defaults when similarity is insufficient.

**Repository meta-features** for Stoke would include structural characteristics (language, framework, LOC, file count, module structure), process characteristics (team size, PR velocity, CI duration, test suite size), quality indicators (test coverage, lint error density, documentation coverage), and architectural patterns (microservices vs. monolith, API patterns, dependency topology). A practical approach: start with portfolio-based defaults for common project archetypes ("small-team React app," "enterprise Java monolith," "Python ML project"), then refine via collaborative filtering across the team's projects as data accumulates.

---

## 8. Prior art shows what works and what fails in self-configuring dev tools

Several production systems have attempted self-configuration for developer tools, and their successes and failures provide direct lessons for Stoke.

**Microsoft IntelliCode** is the most instructive case study. Version 1 (2019) offered Team Completions that trained custom models on a team's code, automatically shared via Azure DevOps CI. However, requiring explicit training setup created adoption friction. The deep learning upgrade (VS 2022+) replaced team-trained models with a neural encoder that **runs locally and adapts automatically** to any codebase without training, a major improvement. IntelliCode Suggestions used Programming-by-Examples (PROSE) to detect repetitive edit patterns and suggest applying them elsewhere. Key lesson: **automatic adaptation without setup steps drives adoption far more than explicit training workflows.**

**Google's Tricorder** (Sadowski et al., ICSE 2015) is the gold standard for feedback-driven tool tuning at scale. Its "NOT USEFUL" button enables continuous monitoring of false-positive rates per analyzer. Analyzers with high rejection rates enter probation and are either improved or disabled. The overall effective false-positive rate sits **just below 5%**—a critical threshold, as Google found tools are abandoned above this rate. A crucial finding: **project-level customization, not user-level customization**, produces better results. Per-user settings caused discrepancies and declining usage.

**Meta's Predictive Test Selection** (Machalica et al., ICSE-SEIP 2019) uses gradient-boosted decision trees to predict which tests will fail for a given code change, **reducing infrastructure cost by 2×** while guaranteeing >95% individual failure detection and >99.9% faulty change detection. Netflix uses the commercial implementation (Gradle Develocity), reporting **280,000+ developer hours saved per year**. Targeted Test Selection (2025) pushed this further: selecting only 15% of tests, reducing execution time by 5.6×, with models that remain valid for up to 6 months without retraining.

**Meta's Sapienz** (Mao, Harman & Jia, ISSTA 2016) uses multi-objective evolutionary algorithms for automated Android test generation that adapts as the GUI changes. In production since 2017, **75% of its reports result in developer fixes** and it achieved an **80% reduction in Android app crashes**. Its adaptive quality comes from continuously generating and discarding tests as the application evolves—"human tests can't do this, but an automated tester can keep throwing away tests that no longer run because the GUI's changed, and grow new ones" (Mark Harman).

**Cursor AI** represents the current state of codebase-adaptive AI coding, using semantic chunking, embeddings in Turbopuffer, and Merkle trees for efficient incremental indexing. It is retrieval-augmented rather than truly self-configuring—the AI doesn't change its behavior but grounds responses in project-specific context via RAG. Sourcegraph Cody takes a "search-first" approach, scanning the entire codebase before generating code and achieving **82% accuracy on a 200-file service vs. Copilot's 68%** in testing.

Notably, **no widely deployed linter currently uses ML** to learn team-specific style preferences automatically—Prettier, ESLint, and Black all enforce manually configured fixed rulesets. This represents an open opportunity.

---

## Conclusion: an integrated architecture for Stoke

The ten dimensions converge on a layered architecture with three speeds of adaptation.

The **fast layer** (per-task, milliseconds) uses contextual bandits for real-time decisions: model routing via Thompson Sampling or LinUCB, verification depth selection, tool routing, and FrugalGPT-style cascades for cost optimization. Reward signals come from verifiable code execution outcomes. This layer draws from Dimensions 1, 2, and 3.

The **medium layer** (daily/weekly) performs drift detection using BOCPD on metrics time-series, updates preference models via collaborative filtering on accumulated implicit feedback, and adjusts configuration through feature-flag-controlled canary rollouts with automated benchmark gates. This layer integrates Dimensions 4, 5, 6, and 7.

The **slow layer** (monthly or on major events) handles transfer learning to new projects via portfolio warm-starting and collaborative filtering across repositories, full reconfiguration through MAPE-K reconciliation loops, and Kubernetes-style operator patterns that encode domain knowledge about project archetypes. This layer draws from Dimensions 8, 9, and 10.

Five design principles emerge consistently across the research. First, **portfolio defaults beat complex meta-feature computation** (Auto-sklearn 2.0). Start with curated configurations for common project archetypes; refine later. Second, **false-positive rate is the single most critical metric for adoption** (Tricorder's <5% threshold). Precision beats recall. Third, **automatic adaptation without explicit setup drives adoption** (IntelliCode's evolution from team-trained to auto-adapting models). Fourth, **project-level configuration, not user-level** (Google's experience). And fifth, **verifiable reward signals** from code execution (tests pass, lint clean, type-safe) provide the objective feedback that makes online learning practical for coding tasks, avoiding the quality-degradation pitfall that Mozannar et al. identified when using acceptance as the sole reward signal.

The research base is substantial and mature. What has been missing is not the individual techniques but their integration into a coherent system that operates across all three time horizons simultaneously. Stoke's opportunity is precisely this synthesis.