# Rate limiting, abuse prevention, and DDoS mitigation for API platforms

**The most effective API protection stacks multiple defense layers — rate limiting at the edge, abuse scoring at the gateway, cost-based metering for expensive operations, and circuit breakers for downstream resilience.** No single algorithm or tool suffices. The token bucket algorithm (used by Stripe, AWS, and Go's standard library) has emerged as the default for general-purpose APIs because it permits controlled bursts while enforcing sustained throughput caps. Redis Lua scripts provide the atomicity required for distributed rate limiting, and the IETF's draft `RateLimit` header standard is finally converging toward adoption. Meanwhile, the rise of AI agent traffic — bursty, high-cost, and indistinguishable from DDoS — has forced a shift from request-count rate limiting to cost-based metering, with real-world incidents costing organizations six figures in hours.

---

## Four algorithms and when each one wins

Rate limiting algorithms differ on three axes: burst tolerance, memory usage, and boundary accuracy. Choosing the wrong algorithm can either block legitimate traffic or let abuse slip through.

**Token bucket** is the strongest general-purpose default. A bucket holds tokens that refill at a constant rate (e.g., 10/second) up to a maximum capacity. Each request consumes one token. When the bucket is empty, requests are rejected. The key advantage is **controlled burst handling** — a full bucket absorbs traffic spikes up to its capacity, then reverts to the refill rate. It requires only O(1) space per client (two fields: current tokens and last refill timestamp) and O(1) time per request. Stripe, AWS API Gateway, and Go's `golang.org/x/time/rate` all use this algorithm. The tradeoff is tuning two parameters (capacity and refill rate) instead of one, and floating-point refill math that must be computed atomically.

**Sliding window log** provides exact enforcement with zero boundary artifacts. It stores every request timestamp in a sorted set, prunes entries older than the window, and counts the rest. This precision makes it ideal for security-critical endpoints — payment APIs and authentication — where even one extra request matters. The cost is **O(n) memory per client** where n equals the rate limit, making it unsuitable for high-volume, high-cardinality scenarios. Redis sorted set operations (ZADD, ZREMRANGEBYSCORE, ZCARD) run in O(log n) time.

**Fixed window counter** is the simplest approach: divide time into fixed intervals, increment a counter per request, reject when the counter exceeds the limit. It uses a single Redis STRING key with INCR and EXPIRE, achieving O(1) everything. The critical flaw is the **boundary burst problem** — a client can make N requests at the end of one window and N more at the start of the next, effectively doubling throughput in a short span. This makes it acceptable for basic throttling but dangerous for security-critical limits.

**Leaky bucket** is the mathematical dual of token bucket. Where token bucket starts full and spends tokens (permitting bursts), leaky bucket starts empty and fills with requests (smoothing all bursts). In "policing" mode, it provides instant allow/deny decisions. In "shaping" mode, it queues requests and drains them at a fixed rate, guaranteeing perfectly smooth output. Shopify uses this algorithm — their REST API has a bucket of 40 requests that leaks at 2 requests/second. The leaky bucket is the right choice when downstream services cannot tolerate any traffic spikes.

**Sliding window counter** deserves mention as a hybrid approach. It maintains counters for the current and previous windows, then computes a weighted estimate: `previous_count × (1 - elapsed_fraction) + current_count`. This achieves near-exact accuracy with minimal memory (two STRING keys per client) and no boundary burst problem. The Redis.io tutorial recommends it as the best general-purpose algorithm.

| Algorithm | Redis type | Memory | Accuracy | Burst behavior | Best for |
|-----------|-----------|--------|----------|----------------|----------|
| Token bucket | HASH (2 fields) | O(1) | Exact | Controlled bursts | General-purpose APIs, bursty traffic |
| Sliding window log | SORTED SET | O(n) | Exact | No bursts | Payment/auth endpoints, auditing |
| Fixed window counter | STRING | O(1) | Approximate | 2× burst at boundaries | Simple throttling, internal services |
| Leaky bucket | HASH (1–2 fields) | O(1) | Exact | No bursts | Traffic shaping, downstream protection |
| Sliding window counter | STRING ×2 | O(1) | Near-exact | Smoothed | General-purpose with accuracy needs |

---

## Redis Lua scripts deliver atomic rate limiting

Rate limiting requires an atomic read-decide-write cycle: check the current count, decide whether to allow the request, and update state. Redis's MULTI/EXEC cannot express conditional logic (all commands are queued before execution), and WATCH/MULTI/EXEC causes frequent aborts under concurrent access. **Lua scripts via EVAL execute atomically on the Redis server** with full branching logic, no retry loops, and a single network round trip.

A concrete race condition illustrates the necessity. Without Lua, two pods concurrently executing INCR followed by EXPIRE can overwrite each other's TTL, breaking window boundaries. With Lua, the EXPIRE is set conditionally only when the counter equals 1 (first request in the window), preventing the race entirely.

**Token bucket Lua script** — the most commonly deployed pattern:

```lua
-- KEYS[1] = bucket key
-- ARGV[1] = capacity, ARGV[2] = refill_rate (tokens/sec), ARGV[3] = now, ARGV[4] = requested
local key = KEYS[1]
local capacity = tonumber(ARGV[1])
local refill_rate = tonumber(ARGV[2])
local now = tonumber(ARGV[3])
local requested = tonumber(ARGV[4])

local bucket = redis.call('HMGET', key, 'tokens', 'last_refill')
local tokens = tonumber(bucket[1])
local last_refill = tonumber(bucket[2])

if tokens == nil then
    tokens = capacity
    last_refill = now
end

local elapsed = now - last_refill
tokens = math.min(capacity, tokens + elapsed * refill_rate)

if tokens < requested then
    redis.call('HMSET', key, 'tokens', tokens, 'last_refill', now)
    redis.call('EXPIRE', key, math.ceil(capacity / refill_rate) + 1)
    return {0, math.floor(tokens * 100) / 100, math.ceil((requested - tokens) / refill_rate)}
end

tokens = tokens - requested
redis.call('HMSET', key, 'tokens', tokens, 'last_refill', now)
redis.call('EXPIRE', key, math.ceil(capacity / refill_rate) + 1)
return {1, math.floor(tokens * 100) / 100, 0}
```

The script stores two fields in a HASH (`tokens` and `last_refill`), calculates refill lazily based on elapsed time, and returns a tuple of `{allowed, remaining_tokens, wait_time}`. The EXPIRE ensures automatic cleanup of inactive clients.

**Sliding window log Lua script** — for security-critical endpoints:

```lua
local key = KEYS[1]
local limit = tonumber(ARGV[1])
local window = tonumber(ARGV[2])
local now = tonumber(ARGV[3])
local request_id = ARGV[4]

redis.call('ZREMRANGEBYSCORE', key, 0, now - window)
local current = redis.call('ZCARD', key)

if current >= limit then
    local oldest = redis.call('ZRANGE', key, 0, 0, 'WITHSCORES')
    local retry_after = window - (now - tonumber(oldest[2]))
    return {0, current, math.ceil(retry_after)}
end

redis.call('ZADD', key, now, request_id)
redis.call('EXPIRE', key, window + 1)
return {1, current + 1, 0}
```

**Sliding window counter Lua script** — the best balance of accuracy and efficiency, requiring Redis Cluster hash tags to ensure both keys land on the same slot:

```lua
-- KEYS[1] = {ratelimit:user123:swc}:5 (current window)
-- KEYS[2] = {ratelimit:user123:swc}:4 (previous window)
local prev_count = tonumber(redis.call('GET', KEYS[2]) or '0')
local curr_count = tonumber(redis.call('GET', KEYS[1]) or '0')
local estimate = prev_count * (1 - tonumber(ARGV[2])) + curr_count

if estimate >= tonumber(ARGV[1]) then
    return {0, math.ceil(estimate), -1}
end

curr_count = redis.call('INCR', KEYS[1])
if curr_count == 1 then
    redis.call('EXPIRE', KEYS[1], tonumber(ARGV[3]) * 2)
end
return {1, math.ceil(estimate + 1), -1}
```

The `{...}` hash tag syntax ensures both keys hash to the same Redis Cluster slot, avoiding CROSSSLOT errors.

---

## Designing rate limits per endpoint class

Not all endpoints deserve the same limits. A login endpoint that allows 1,000 requests per minute is an open invitation to credential stuffing; a read endpoint limited to 5 per minute kills developer experience.

**Authentication endpoints warrant the strictest limits — typically 5–10 requests per minute.** These are the primary target for brute-force attacks and credential stuffing. Best practice applies limits at multiple levels simultaneously: per-IP, per-targeted-account, and per-device fingerprint. WorkOS Radar uses progressive rate limiting on auth endpoints, where limits tighten as suspicious behavior accumulates, applied to device fingerprints rather than just IPs.

**Read endpoints can be generous — 1,000+ requests per minute** — because GET operations are typically cacheable, idempotent, and cheap. GitHub allows 5,000 authenticated REST requests per hour. Servers should support ETags and conditional requests (`If-None-Match`) so cache-hit responses don't consume rate limit quota. Some implementations exclude 304 Not Modified responses from counting entirely.

**Write endpoints sit at moderate limits — around 100 per minute.** POST, PUT, and DELETE operations modify server state, are harder to reverse, and often trigger expensive downstream processes. Stripe enforces 100 requests/second overall but adds a concurrent request limiter that returns HTTP 423 with `lock_timeout` for concurrent writes to the same object.

**Search endpoints need complexity weighting, not simple request counting.** A keyword search costs orders of magnitude less than a full-text search with aggregations, filters, and wildcard matching. The pattern is to assign point values to query parameters (basic filter: 2 points, aggregation: 5, wildcard: 10) and rate-limit based on total points consumed. Jira Cloud exemplifies this: each API call consumes points proportional to the work performed.

**Webhook delivery endpoints** require retry budgets with exponential backoff and jitter. The standard formula is `delay = base_delay × 2^attempt × random(0.5, 1.5)`, with a typical schedule starting at 5 seconds and capping at 1 hour. Stripe retries webhooks for up to 3 days in live mode. A circuit breaker pattern should disable endpoints after N consecutive failures, with events routed to a dead letter queue for manual replay.

**GraphQL endpoints present a unique challenge** because a single request can have wildly varying costs. GitHub's GraphQL API uses a point-based system: **5,000 points per hour** per authenticated user, with query cost calculated by multiplying connection sizes at each nesting level. A query requesting `repositories(first: 50) { pullRequests(first: 20) { comments(first: 10) } }` costs 50 × 20 × 10 = 10,000 nodes. Depth limiting (typically 5–10 levels), breadth limiting, and computed complexity scoring before execution form the standard defense stack. Shopify's GraphQL API assigns integer costs per field and refunds the difference between requested and actual costs after execution.

**Tiered rate limits** create natural upgrade paths. A common structure gives free users 100 requests/minute, basic 1,000, premium 10,000, and enterprise custom limits. Both per-user and per-organization limits should apply simultaneously — per-user prevents one developer from monopolizing org quota, while per-org ensures the organization stays within contracted capacity.

---

## Rate limit headers and the IETF standard

The traditional headers — `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset` — were never formally standardized, leading to painful inconsistencies. GitHub and Twitter use Unix epoch timestamps for `X-RateLimit-Reset`; others use seconds-until-reset or ISO 8601 dates. This forces custom parsing per provider.

The **IETF HTTPAPI Working Group** has been developing `draft-ietf-httpapi-ratelimit-headers`, with the latest version (draft-10+) published September 24, 2025. It defines two standardized header fields:

**`RateLimit-Policy`** advertises the server's quota policies and remains relatively stable across responses:
```http
RateLimit-Policy: "burst";q=100;w=60, "daily";q=1000;w=86400
```

Parameters include `q` (quota — required), `w` (window in seconds), `qu` (quota unit: `"requests"`, `"content-bytes"`, or `"concurrent-requests"`), and `pk` (partition key identifying which client group applies).

**`RateLimit`** communicates current remaining quota and may change on every response:
```http
RateLimit: "burst";r=57;t=43
```

Where `r` is remaining quota units and `t` is time in seconds until quota reset. Earlier drafts (01–07) used separate `RateLimit-Limit`, `RateLimit-Remaining`, and `RateLimit-Reset` headers; draft-08+ consolidated them into this combined format.

A critical design decision: **reset values use delay-seconds, not Unix timestamps**, maintaining compatibility with the `Retry-After` header defined in RFC 9110. The draft also defines three problem types: quota exceeded, temporary reduced capacity, and abnormal usage detected.

Jira Cloud is an early adopter, using beta headers matching the draft:
```http
Beta-RateLimit-Policy: "global-app-quota";q=65000;w=3600,"jira-burst-based";q=100;w=1
Beta-RateLimit: "global-app-quota";t=200,"jira-burst-based";r=90;t=1
```

For HTTP 429 response bodies, **RFC 9457 Problem Details** (`application/problem+json`) is the recommended format:
```json
{
  "type": "https://api.example.com/problems/rate-limited",
  "title": "Rate Limit Exceeded",
  "status": 429,
  "detail": "You have exceeded 100 requests per minute",
  "limit": 100,
  "remaining": 0,
  "resetAt": "2026-04-06T14:30:00Z"
}
```

The `Retry-After` header should always accompany 429 responses, using either delay-seconds (`Retry-After: 60`) or HTTP-date format. Per RFC 6585, 429 responses must not be stored by caches. Libraries like `express-rate-limit` (v8.3+) support `standardHeaders: 'draft-8'` for automatic IETF-compliant header generation.

---

## Client identification from user IDs to IPv6 prefixes

**Authenticated user ID is the most reliable identification method.** GitHub gives authenticated users 5,000 requests/hour versus 60 for unauthenticated. API keys associate requests with applications/developers rather than end users — Stripe differentiates between public keys (`pk_`) and secret keys (`sk_`) with different limits. The best practice is combining a global limit, a per-tenant limit, a per-user limit, and per-endpoint limits simultaneously.

IP addresses serve as fallback but carry significant limitations. Corporate NATs funnel thousands of users through a single IP, causing false positives. Attackers rotate through residential proxies, making per-IP limits easy to evade. Cloud hosting, VPNs, and mobile carriers create massive shared-IP pools that blur the line between legitimate and malicious traffic.

**IPv6 renders per-address rate limiting completely useless.** A single residential user receives at least a /64 prefix — **18.4 quintillion addresses** — more than the entire IPv4 address space. Tools like `freebind` exist explicitly for IPv6 rate-limit evasion. Residential ISPs commonly delegate /56 prefixes (256 /64 blocks), and businesses receive /48 (65,536 /64 blocks).

The minimum viable approach is rate-limiting by /64 prefix. Cloudflare blocks by "individual IPv4 address or IPv6 /64 IP range." The recommended approach tracks limits at /64, /56, and /48 simultaneously with progressively higher thresholds. Let's Encrypt limits account creations by /48. An nginx implementation extracts the /64 prefix:

```nginx
map $remote_addr $rate_key {
    "~^([0-9a-fA-F:]+:){4}" $1;  # First 4 groups = /64 prefix
    default $binary_remote_addr;   # IPv4: full address
}
limit_req_zone $rate_key zone=api:10m rate=60r/m;
```

For anonymous abuse detection, **TLS fingerprinting (JA3/JA4)** identifies clients across IP changes — Python's `requests` library has a completely different JA3 hash than Chrome. Cloudflare uses JA3 as a rate limiting key when no session cookie exists. WorkOS Radar applies progressive rate limits to device fingerprints rather than IPs. Emerging research on **Anonymous Rate-limited Credentials (ARC)** at the IETF would enable rate-limiting individual users without identifying them — critical for the AI agent era where traditional fingerprinting fails because agents share identical software/hardware signatures.

---

## Distributed rate limiting across service instances

The central challenge is consistency versus latency. Five architectural approaches have emerged, each with distinct tradeoffs.

**Centralized Redis** is the simplest mental model: all instances connect to a shared Redis, and every rate limit check involves a network round trip with atomic Lua script execution. Stripe uses this approach with Redis (ElastiCache on AWS). The tradeoff is **1–5ms latency per request** and Redis as a single point of failure. Stripe's practice is to fail open — if Redis is down, all requests are allowed through, with a "panic mode" switch to disable rate limiting entirely.

When a single Redis instance becomes a bottleneck, **Redis Cluster** provides horizontal scaling. Stripe migrated from a single hot instance to a 10-node cluster, with "negligible impact on performance" and dramatically reduced error rates. The key constraint is that all keys accessed by a Lua script must hash to the same slot — multi-key algorithms (like sliding window counter) require hash tags: `{ratelimit:user123:swc}:5` and `{ratelimit:user123:swc}:4` both hash on the `ratelimit:user123:swc` prefix. Passing keys with different hash tags causes CROSSSLOT errors.

**Local rate limiting with periodic sync** (LaunchDarkly's "Floodgate" pattern) eliminates network latency from the request path. Each server maintains local in-memory counters and makes rate limit decisions locally. Counters sync to Redis every 100ms–1s. This accepts eventual consistency — a limit of 1,000/min might briefly allow ~1,050 requests during sync gaps. This tradeoff is acceptable for high-throughput systems but not for security-critical limits like login attempts.

**Google's two-tier architecture** uses local quota servers for short-term limits (per-second, per-minute) and global quota servers for long-term limits (per-day, per-month). Local servers pre-fetch token batches from global servers, reducing cross-cell communication. Short-term limits operate almost entirely locally.

LaunchDarkly's **Poisson statistical rate limiter** requires zero coordination for fixed-shard systems. Given a global limit of 1,000 req/sec across 10 shards, traffic distributes approximately Poisson per shard. Computing the 95th percentile of the expected Poisson distribution yields 117 req/sec per shard — **95% confidence of not over-enforcing, no external storage, and zero failure modes**. The requirement is fixed shard counts and well-distributed authenticated traffic.

**Cell-based architectures** allocate proportional quotas per geographic region: a global 100 req/min across 3 regions gives each ~33 tokens, with periodic rebalancing based on actual traffic patterns. Cross-region communication failures trigger fallback to conservative local limits.

---

## Cost-based rate limiting protects expensive operations

Traditional request-count rate limiting fails catastrophically for AI and compute-heavy APIs. **A single AI agent request can cost 100× more than a typical human request**, yet simple rate limiters treat them identically. A documented $1.6M incident in early 2026 involved an AI agent hitting a timeout and retrying a $1.58 API call over 1,000 times across a weekend — the gateway approved every request because each was individually valid. A compromised Google Gemini API key generated **$82,314 in 48 hours**, a 457× spike from typical $180/month spending.

All major AI providers bill by tokens. Anthropic charges $15.00 per million input tokens for Claude Opus 4.5 and $0.25 for Haiku 4.5 — a 60× cost range across models. OpenAI measures rate limits across **five simultaneous dimensions**: RPM (requests/min), RPD (requests/day), TPM (tokens/min), TPD (tokens/day), and IPM (images/min). The lowest limit hit triggers throttling. Both providers use tiered systems where cumulative spending unlocks higher limits — OpenAI's tiers range from free (3 RPM) to Tier 5 ($1,000+ paid, up to $200,000/month usage).

The implementation pattern assigns different weights to different operations and budgets by cost, not count:

```typescript
// Cost-weighted rate limiting
app.get('/api/search', costBasedLimiter(1, 1000, 3600000), searchHandler);
app.post('/api/ai/inference', costBasedLimiter(100, 1000, 3600000), aiHandler);
app.post('/api/reports/generate', costBasedLimiter(50, 1000, 3600000), reportHandler);
app.get('/api/export', costBasedLimiter(200, 1000, 3600000), exportHandler);
```

Zuplo's approach reads actual token consumption from the LLM response and applies it retroactively to the rate limiter — this captures true cost rather than estimated cost. Cloudflare's enterprise Advanced Rate Limiting supports complexity-based limiting where the origin returns an HTTP header with a numeric cost score per request.

Per-tenant compute budgets enforce hard and soft caps. Soft caps trigger alerts but don't stop service. Hard caps suspend access until the next billing cycle or manual increase. Usage alerts fire at 75%, 90%, and 100% of budget consumption. Credit-based metering systems like Snowflake's "compute credits" and Vercel's "function invocations" abstract costs into platform-specific currencies with prepaid wallets, configurable burn rules, and expiry policies.

AI agents differ from human users in ways that demand specialized rate limiting: wildly variable request costs (50 vs. 10,000 tokens), bursty sequential call chains (10–20 tool lookups, RAG queries, and reasoning steps in rapid succession), and traffic patterns indistinguishable from DDoS. Best practice tags API keys with consumer type metadata and applies different policies per type.

---

## Graduated abuse response and scoring systems

Effective abuse prevention escalates through five levels: **monitoring → stricter rate limits → challenge-response → temporary block → permanent ban.** Each level increases friction for attackers while minimizing impact on legitimate users.

At the monitoring level, anomalous behavior triggers logging and baseline alerts with no user-facing impact. When thresholds are breached, dynamic rate limits impose tighter constraints — return 429 with Retry-After headers. For continued suspicious behavior, interactive challenges force attackers to invest in CAPTCHA-solving services ($2–5 per 1,000 solves). Cloudflare's "Managed Challenges" adaptively select the least intrusive challenge type. Temporary blocks use exponential backoff for repeat offenders (first: 15 minutes → second: 1 hour → third: 24 hours). Permanent bans require human review and a clear appeal mechanism separate from the blocked API.

**Abuse scoring systems** aggregate signals into a composite score. Input signals include request rate versus baseline, failed authentication ratio, sequential/enumeration access patterns, geographic anomalies (impossible travel), IP reputation (hosting provider, proxy, Tor exit node), TLS fingerprint matching known bot toolkits, and data volume extraction rates. A typical model maps scores 0–30 as clean, 31–50 as suspicious (stricter limits), 51–70 as likely abusive (require challenge), 71–90 as high risk (temporary block), and 91–100 as confirmed abuse (permanent block). Scores should decay over time — halving every 24 hours without new violations — to enable automatic de-escalation.

Cloudflare's bot management produces scores from 1 to 99 (lower means more likely bot). Scores below 30 commonly indicate automated traffic. Their separate WAF Attack Score (1–99, lower means more malicious) detects SQLi, XSS, and RCE. Enterprise customers create custom rules referencing `cf.bot_management.score` for layered enforcement.

---

## Layer 7 DDoS mitigation and WAF configuration

Application-layer DDoS attacks mimic legitimate traffic, making them harder to detect than volumetric network floods. HTTP floods send massive volumes of seemingly valid GET/POST requests. HTTP/2 Rapid Reset exploits stream multiplexing to send and cancel streams at massive scale. API-specific floods target computationally expensive endpoints like search, report generation, and AI inference. DDoS attacks grew from 274,000 in Q1 2023 to **512,000 in Q4 2024**, averaging ~$6,000/minute in damage.

A production Cloudflare WAF stack deploys rules in this order. First, Cloudflare Managed Ruleset provides auto-updating SQLi/XSS/RCE signatures. Second, WAF Attack Score rules block requests with `cf.waf.score le 20`. Third, Bot Management custom rules block definitely automated traffic: `(cf.bot_management.score lt 30 and not cf.bot_management.verified_bot)`. Fourth, Advanced Rate Limiting uses keys based on headers, session IDs, or JWT claims — not just IP. Fifth, OWASP Core Ruleset at paranoia level PL1 with score threshold 25+. Geo-blocking rules using `ip.geoip.country` filter traffic from high-risk regions.

AWS launched **AntiDDoS AMR** (Managed Rules) in June 2025 as a one-click WAF rule group. It profiles traffic within 15 minutes, detects and mitigates attacks within seconds using suspicion scoring, and does not charge for mitigated DDoS traffic. URI path exclusions accommodate API endpoints that don't support browser challenges.

The defense should layer edge and application protections. Edge filtering (CDN/WAF) absorbs volumetric attacks with sub-millisecond decisions before traffic reaches the origin. Application-level controls handle fine-grained business logic enforcement — per-user quotas, abuse scoring based on session state, and cost-based metering. Each layer adds detection surface.

---

## API abuse patterns demand specific defenses

**Credential stuffing** uses breached username/password pairs (billions available) with automated tools like OpenBullet and proxy rotation. Success rates hover around 0.1%, but at millions of attempts, the economics work. Modern variants spread attempts over weeks ("low-and-slow"), target mobile APIs that lack JS fingerprinting, and chain successful logins across multiple services. Defenses layer MFA (the single most effective control), breached password detection (Cloudflare WAF checks against known breach databases; HaveIBeenPwned's API enables k-anonymity lookups), rate-limiting by device/session/username (not just IP), and TLS fingerprinting to identify bot toolkits.

**Carding** tests stolen credit card numbers via payment APIs using small transactions ($0.01–$5.00). Detection signals include spikes in failed authorizations, many small-value transactions from the same device, BIN concentration (same first 6 digits appearing repeatedly), AVS mismatches, and direct checkout navigation without browsing. Stripe Radar provides ML-based fraud scoring with custom rules for velocity control. Defenses include velocity checks by BIN/IP/device/email, 3D Secure authentication, minimum transaction amounts, and per-session checkout attempt limits.

**Enumeration attacks** exploit differences in error messages or response timing to discover valid users, brute-force coupon codes, or iterate sequential resource IDs. A login endpoint returning "User not found" versus "Invalid password" leaks user existence. Bcrypt hashing on valid users takes ~200–400ms versus ~1–5ms for a database miss on invalid users, creating a timing oracle. Defenses: always return generic "Invalid credentials" messages, perform dummy bcrypt hashes when users don't exist to equalize timing, use UUIDs instead of sequential IDs, and rate-limit auth endpoints to 5 attempts per 15 minutes per IP.

**Webhook abuse** primarily manifests as SSRF — users provide URLs like `http://169.254.169.254/latest/meta-data/` that the webhook system fetches from internal infrastructure. Bypass techniques include DNS rebinding, URL schema abuse (`file://`, `gopher://`), and open redirects. Defenses: block private/loopback IPs after DNS resolution (not just at registration), require HTTPS, disable redirect following, route all webhook requests through an egress proxy (like Smokescreen) with network-level filtering, and run webhook workers on isolated infrastructure. **HMAC-SHA256 signature verification** on payloads is essential — research found 23 out of 31 open-source webhook implementations failed to verify signatures.

---

## Circuit breakers, rate limiting, and load shedding serve different purposes

These three resilience patterns protect against different failure modes and should be layered together, not used interchangeably.

**Rate limiting** controls request throughput per client — it answers "is this client sending too many requests?" Decision basis: request count or cost per client identity. Scope: per-client. Stripe implements two rate limiter types: request rate (N/second via token bucket) and concurrent request (max in-flight per user).

**Load shedding** protects the system from aggregate overload — it answers "is the system overwhelmed regardless of who's sending?" Decision basis: system-wide metrics (CPU utilization, in-flight request count, response latency velocity). Scope: system-wide. Stripe implements two load shedder types: fleet usage (reserves 20% capacity for critical APIs) and worker utilization (last line of defense, drops low-priority requests based on system state).

**Circuit breakers** prevent cascading failures in outbound calls — they answer "is this downstream dependency broken?" Decision basis: failure rate of outbound calls. Scope: per-dependency. The state machine transitions through closed (normal flow, monitoring failures), open (all calls immediately rejected/fallback returned), and half-open (limited test calls to probe recovery).

The **recommended layering from outside in**: rate limiting at the edge rejects excess client traffic, load shedding at the application layer protects against aggregate overload despite rate limits, and circuit breakers on outbound calls stop cascading failures to downstream services.

**Go implementation with gobreaker** (Sony):
```go
cb := gobreaker.NewCircuitBreaker[[]byte](gobreaker.Settings{
    Name:        "downstream-api",
    MaxRequests: 3,              // test calls in half-open
    Timeout:     30 * time.Second, // duration of open state
    ReadyToTrip: func(counts gobreaker.Counts) bool {
        return counts.Requests >= 3 &&
            float64(counts.TotalFailures)/float64(counts.Requests) >= 0.6
    },
})
body, err := cb.Execute(func() ([]byte, error) {
    resp, err := http.Get(url)
    // ...
})
```

**TypeScript implementation with opossum** (Red Hat):
```typescript
const breaker = new CircuitBreaker(callDownstream, {
    timeout: 3000,
    errorThresholdPercentage: 50,
    resetTimeout: 30000,
    volumeThreshold: 5,
});
breaker.fallback(() => ({ error: 'Service temporarily unavailable' }));
const result = await breaker.fire(requestData);
```

**Resilience4j** (Java) enables stacking all patterns via decorators — annotations `@Retry`, `@CircuitBreaker`, `@Bulkhead`, and `@RateLimiter` execute right-to-left, with Spring Boot YAML configuration for thresholds, window sizes, and timeout durations.

A production middleware chain combines all three in Go:

```go
// Layer 1: Rate limiting (outermost)
rl := NewRateLimitMiddleware(rate.Limit(10), 20)
// Layer 2: Load shedding (middle) 
ls := NewLoadShedder(maxInFlight: 500)
// Layer 3: Circuit breaker (innermost, protects downstream)
cb := NewCircuitBreakerMiddleware(settings)
// Chain: Rate Limit → Load Shed → Circuit Breaker → Handler
handler := rl.Middleware(ls.Middleware(cb.Middleware(mux)))
```

---

## How Stripe, GitHub, OpenAI, and Shopify implement rate limiting

**Stripe** uses the token bucket algorithm backed by Redis, with **100 requests/second per API key** as the default. Their architecture deploys four distinct limiters: a request rate limiter (token bucket, allows brief bursts for flash sales), a concurrent request limiter (prevents retry storms), a fleet usage load shedder (reserves 20% capacity for critical APIs), and a worker utilization load shedder (last resort). Rate limiters fail open — if Redis goes down, requests flow through. They migrated from a single Redis instance to a 10-node Redis Cluster for horizontal scalability.

**GitHub** separates primary and secondary rate limits. Primary: **5,000 requests/hour** for authenticated users (60 for unauthenticated), with the GraphQL API using a point-based system where query cost is computed by multiplying connection sizes at each nesting level. Secondary limits cap 100 concurrent requests, 900 points/minute for REST, and 90 seconds CPU time per 60 seconds real time. Conditional requests returning 304 don't count against primary limits.

**OpenAI** enforces five simultaneous dimensions (RPM, RPD, TPM, TPD, IPM) per organization and project. Their tier system auto-upgrades based on payment history — from free (3 RPM) through Tier 5 ($1,000+ paid, highest limits). Error messages specify exactly which limit was hit: `"Rate limit reached for gpt-4 in organization org-abc123 on requests per min. Limit: 3 / min."` Token counting uses input plus output tokens, calculated with the Tiktoken library.

**Shopify** uses leaky bucket for REST (40-request bucket, 2/second leak rate for standard; 400 and 20/second for Plus) and calculated query cost for GraphQL (50 points/second standard, 500 for Plus). Their GraphQL implementation is notable: it calculates requested cost before execution, runs the query, then refunds the difference between requested and actual cost. A debug header (`Shopify-GraphQL-Cost-Debug=1`) exposes the cost breakdown.

**Cloudflare** rate-limits its own API at 1,200 requests per 5 minutes per user and is an early adopter of IETF draft headers (`Ratelimit` and `Ratelimit-Policy`). Their rate limiting product for customers supports both request-based and complexity-based modes — the latter tracks cumulative cost scores from origin-provided headers, enabling true cost-based limiting at the edge. The Workers Rate Limiting API enforces limits per Cloudflare location with eventual consistency, adding no meaningful latency.

---

## Conclusion

The landscape of API protection has shifted fundamentally. Request-count rate limiting remains necessary but insufficient — the rise of AI agents, token-based billing, and compute-heavy operations demands cost-based metering as a first-class concern. The most effective architecture layers five defense surfaces: edge filtering (Cloudflare/AWS WAF for volumetric attacks), gateway rate limiting (token bucket via Redis Lua scripts for per-client enforcement), application-level abuse scoring (behavioral signals aggregated into composite scores with graduated escalation), cost-based budgets (per-tenant compute caps with hard and soft limits), and outbound circuit breakers (gobreaker/opossum protecting against cascading failures).

Three emerging trends will reshape this space. First, the IETF `RateLimit` header standard is converging, and adopting `RateLimit-Policy` and `RateLimit` headers now provides forward compatibility. Second, IPv6 has made per-IP rate limiting obsolete — /64 prefix grouping is the minimum, and multi-level tracking at /64, /56, and /48 simultaneously is recommended. Third, Anonymous Rate-limited Credentials (ARC) represent the most promising approach for rate-limiting AI agents that share identical fingerprints and rotate through IP ranges. The platforms that adapt fastest to cost-based, identity-aware, multi-dimensional rate limiting will be best positioned to serve both human developers and the coming wave of autonomous API consumers.