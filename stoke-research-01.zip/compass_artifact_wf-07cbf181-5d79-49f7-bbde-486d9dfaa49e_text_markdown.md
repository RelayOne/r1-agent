# The complete guide to modern API design across protocols

**Building APIs in 2026 means navigating a stack that spans REST, GraphQL, gRPC, MCP, and entirely new agent-to-agent protocols.** This guide synthesizes production-tested patterns, current specifications, and practical tradeoffs across all major API paradigms — from foundational HTTP semantics to the emerging agentic commerce layer. The landscape has shifted dramatically: Anthropic's MCP now sees **97 million monthly SDK downloads** across 10,000+ servers, Google's A2A protocol reached v1.0 production readiness under the Linux Foundation, and the x402 payment protocol has processed over 100 million payments since its May 2025 launch. What follows is a practitioner's reference covering every layer of this stack.

---

## 1. REST maturity rarely reaches Level 3, and that's mostly fine

The Richardson Maturity Model classifies REST APIs across four levels. **Level 0** ("Swamp of POX") uses a single URI and POST for everything — pure RPC tunneled over HTTP, exemplified by SOAP. **Level 1** introduces resource-based URIs (`/users`, `/orders`) but still overuses POST. **Level 2** adds correct HTTP verb semantics (GET for reads, POST for creation, PUT/PATCH for updates, DELETE for removal) along with proper status codes — this is where **the vast majority of production APIs operate**. Level 3 adds HATEOAS: hypermedia links in responses that let clients discover available actions dynamically.

The practical reality of HATEOAS adoption is telling. **PayPal** is the most prominent implementor, returning contextual links like `execute`, `refund`, and `self` in payment responses. Atlassian's Jira returns `_links` objects, and the Spring HATEOAS framework (HAL+JSON) sees use in enterprise Java shops. But the 2022 State of API Report confirms that over **80% of APIs use REST**, and nearly all stop at Level 2. The htmx project bluntly notes the industry has "broadly rejected HATEOAS in favor of simpler RPC-style APIs." The reasons are structural: clients rarely consume links dynamically (developers hardcode paths), no universally accepted JSON hypermedia format exists (HAL, JSON:API, Siren, Collection+JSON all compete), payload sizes balloon with embedded links, and OpenAPI/Swagger tooling doesn't natively support HATEOAS. The pragmatic middle ground is including `self` links and pagination URLs without full hypermedia semantics.

### Conditional requests and cache validation

Conditional requests are underused but powerful. **Strong ETags** (e.g., `"33a64df551425fcc55e4d42a148795d9f25f89d"`) guarantee byte-for-byte identical content. **Weak ETags** (prefixed `W/`, e.g., `W/"v25"`) indicate semantic equivalence — same meaning but potentially different bytes. The cache validation flow works as follows: the server sends a response with an `ETag` header; the client caches it; on re-request, the client sends `If-None-Match: "abc123"`; if the ETag matches, the server returns **304 Not Modified** with no body, saving bandwidth. For optimistic concurrency control, clients send `If-Match: "v1"` on updates — if another client modified the resource, the server returns **412 Precondition Failed**. Per RFC 9110, `If-Match` takes precedence over `If-Unmodified-Since`, and `If-None-Match` over `If-Modified-Since`. ETags generated from content hashes or database revision numbers are more reliable than `Last-Modified` timestamps, which suffer from 1-second granularity.

### Long-running operations across cloud providers

The **202 Accepted + polling** pattern is the universal standard. The server returns `HTTP 202` with a `Location` header pointing to a status resource and a `Retry-After` hint. Azure uses a custom `Operation-Location` header with auto-purging status monitors after 24 hours, applying this pattern to any operation where the 99th percentile response exceeds 1 second. Google Cloud returns Operation resources with a `done` boolean and recommends 10-second polling backoff. AWS diverges — asynchronous services return **200 OK** immediately with a job ID, using Step Functions for orchestration or DynamoDB for status polling. The practical recommendation is to **offer both polling and webhooks** since polling is simpler for browser clients while webhooks eliminate wasted requests.

For batch endpoints, three patterns dominate: **resource-specific bulk endpoints** (`POST /api/v2/tickets/create_many` à la Zendesk) are simplest; **Google's multipart/mixed batch** wraps complete HTTP requests as MIME parts, supporting heterogeneous operations but requiring complex parsing; and **JSON-based generic batch** endpoints wrap requests as JSON arrays with method, URL, and body fields. All providers agree that batched sub-requests count individually against rate limits.

---

## 2. GraphQL in production demands DataLoader, complexity limits, and a nullability strategy

### Solving N+1 with DataLoader

The N+1 problem is GraphQL's most common performance trap. When resolving a list of N items, each nested field resolver fires independently, producing 1 query for the list plus N queries for nested data. **DataLoader** solves this by collecting all `.load(key)` calls within a single tick of the event loop, dispatching them as one `batchLoadFn(keys)` call. The batch function must return values **in the same order as input keys** — this is the critical contract.

DataLoader instances **must be created per-request** to prevent data leakage between users with different permissions. Implementations exist across ecosystems: the canonical `graphql/dataloader` for Node.js, `strawberry.dataloader.DataLoader` for Python (async-native), `java-dataloader` for Java (which requires explicit `dispatch()` calls unlike Node.js's automatic event-loop integration), and `graph-gophers/dataloader` for Go. Facebook's original Haxl library in Haskell inspired the pattern.

### Query complexity scoring

GitHub's GraphQL API demonstrates the gold standard for rate limiting: a **points-based system** where users get 5,000 points per hour (10,000 for Enterprise Cloud). Points are calculated by summing the requests needed to fulfill each connection, dividing by 100, with a minimum cost of 1 point and a hard limit of **500,000 nodes per call**. The core complexity formula is `complexity = fieldCost × listArgument × childComplexity`. A query fetching 100 posts, each with 100 related posts, yields complexity of 10,000. Depth limiting (typically max 7–10 levels) catches cyclical queries, while field-level complexity scoring catches wide queries. Apollo Server plugins, `graphql-query-complexity`, and GraphQL Ruby's `max_complexity` setting all implement this pattern.

### Persisted queries eliminate arbitrary query injection

**Apollo Automatic Persisted Queries (APQ)** work through a hash negotiation: the client computes a SHA-256 hash of the query, sends only the hash, and if the server recognizes it, executes the cached query. On cache miss, the server returns `PersistedQueryNotFound`, and the client retries with both hash and full text. **Relay's persisted queries** differ fundamentally — they're compile-time, not runtime. The Relay compiler extracts all operations into a JSON map at build time, and the server only executes queries from this known set. This makes Relay's approach a true **operation safelist**, preventing arbitrary query injection entirely.

### Federation v2 brought explicit sharing and dropped the extend keyword

Apollo Federation v2 made several breaking changes from v1. The `extend type` syntax was eliminated — subgraphs define entities directly with `type Product @key(...)`. Fields resolved by multiple subgraphs now require an explicit **`@shareable`** directive (v1 handled this implicitly). New directives include `@override` for migrating field resolution between subgraphs, `@inaccessible` for hiding fields from the public API, and `@cost`/`@listSize` (v2.9) for demand control. Expedia's migration from schema stitching to Federation showed ~50% compute reduction and significantly lower gateway latency. **Apollo Router v1.60+ no longer supports Federation v1 supergraphs.**

### The null bubbling problem shapes schema design

GraphQL's **nullable-by-default** design exists for a critical reason: when a non-nullable field resolves to null, the null "bubbles up" to the nearest nullable parent, potentially nullifying entire response branches. If `Restaurant.location` is typed `Location!` but fails, the entire restaurant object is destroyed in the response — not just the location field. The Semantic Non-Null RFC (PR #1065 on graphql-spec) proposes a third type — semantically non-null fields that are null only on error, without triggering bubble propagation. Apollo Kotlin has experimental support. The practical rule: **start nullable, add non-null constraints as the schema matures**, especially for fields backed by external services.

---

## 3. gRPC operations hinge on keepalive, connection age, and deadline propagation

### Keepalive misconfiguration is the #1 gRPC operational issue

Client keepalive defaults to infinity (disabled), while servers default to 2 hours with an enforcement minimum of **5 minutes** between client pings. If a client pings more frequently than the server allows, the server sends GOAWAY with **ENHANCE_YOUR_CALM** — a notoriously confusing error. The coordination rule: deploy servers first with permissive settings, then clients with more aggressive pings.

Recommended keepalive values depend on environment. Behind AWS NLB (350-second idle timeout), set keepalive under 350 seconds. Azure TCP load balancers drop idle connections after **4 minutes** by default. GCP internal load balancers default to 600 seconds. A safe cross-environment default is **5 minutes for keepalive time** with a 20-second timeout, per practitioner guidance from Evan Jones.

### MaxConnectionAge solves the L4 load balancer problem

gRPC uses long-lived HTTP/2 connections, which means L4 load balancers pin all RPCs to the original backend — new server instances receive zero traffic. **MaxConnectionAge** forces periodic reconnection, triggering DNS re-resolution and allowing clients to discover new backends. A ±10% jitter is automatically applied. Production values vary: Jamf uses **30 seconds** (solved their Kubernetes scaling issues), Datadog uses **5 minutes** at scale, and the general recommendation behind L4 load balancers is 35% of the LB timeout to account for jitter.

### Deadlines must always be set and propagated

Deadlines are **absolute timestamps** transmitted as relative timeouts via the `grpc-timeout` header. When Service A sets a 5-second deadline and calls Service B after 0.5 seconds, B sees ~4.5 seconds remaining. No service ever operates with more time than the original caller intended. In Go, propagation is automatic via `context.Context`. In Java, it's automatic by default. In Python, use the `timeout` parameter and check `context.time_remaining()`. The best practice pattern reserves buffer time at each hop — for example, allocating 30% of remaining time for inventory check, 40% for payment, 30% for shipping. **Never use infinite deadlines** — they're gRPC's default and they're dangerous, holding resources indefinitely.

### Status codes most developers get wrong

The most common mistake is using `INTERNAL` for everything. **INVALID_ARGUMENT** means the request is bad regardless of system state; **FAILED_PRECONDITION** means valid input but wrong system state (retry won't help without fixing state). **ABORTED** means retry the whole transaction. **UNAVAILABLE** means retry with backoff. **PERMISSION_DENIED** means the identity is known but unauthorized; **UNAUTHENTICATED** means the identity is unknown. For richer errors, use `google.rpc.Status` with details like `BadRequest` (field-level validation errors), `RetryInfo` (when to retry), `QuotaFailure` (which quota was violated), and `ResourceInfo` (which resource was affected).

### Connect protocol is replacing gRPC-Web for browser clients

Browsers can't use native gRPC because JavaScript APIs don't expose HTTP/2 frame-level control or trailers — the issue isn't HTTP/2 support but API-level access to the primitives gRPC requires. gRPC-Web works through a proxy (typically Envoy) but lacks client-streaming and bidirectional streaming. The **Connect protocol** (connectrpc.com) by the Buf team is the modern alternative: it works over HTTP/1.1, HTTP/2, and HTTP/3 without trailers or a proxy, supports JSON and binary payloads, and is cURL-friendly. Connect servers natively support Connect, gRPC, and gRPC-Web simultaneously. The `connect-go` package is ~1 package versus grpc-go's ~130,000 lines.

---

## 4. MCP's spec has matured rapidly from stdio hack to enterprise protocol

### Specification status as of late 2025

The Model Context Protocol's latest version is **2025-11-25**, the one-year anniversary release. It runs on **JSON-RPC 2.0** with UTF-8 encoding over stateful connections, inspired by the Language Server Protocol. In December 2025, Anthropic donated MCP to the **Agentic AI Foundation** under the Linux Foundation, with OpenAI, AWS, Google, Microsoft, Cloudflare, and Bloomberg as members. The protocol has three server-side primitives — **Tools** (model-controlled functions), **Resources** (application-controlled read-only data), and **Prompts** (templated workflows) — plus client-side capabilities including Sampling (server-initiated LLM calls), Roots (filesystem boundaries), and Elicitation (user input requests).

The November 2025 release added **Tasks** for tracking work status, tool calling within sampling requests, server-side agent loops, parallel tool calls, and enterprise-managed authorization. Client registration evolved from Dynamic Client Registration to **Client ID Metadata Documents (CIMD)**, where clients provide a URL pointing to a self-describing JSON document.

### Transport selection: streamable HTTP replaced SSE

MCP defines two official transports. **stdio** communicates over standard in/out for local processes — the client launches the server as a subprocess with no authentication needed beyond OS-level permissions. **Streamable HTTP** (introduced March 2025) replaced the deprecated SSE transport as the standard for remote servers. It uses a **single HTTP endpoint** supporting both POST and GET, with optional SSE upgrade for streaming responses. The server may assign an `Mcp-Session-Id` header during initialization, and broken SSE connections can resume via `Last-Event-ID`. The old SSE transport required two separate endpoints and sticky sessions — Streamable HTTP eliminated both pain points.

### Tool schema design depends on description quality

Tool definitions use JSON Schema for input validation. Over **90% of MCP tools use snake_case** naming based on analysis of 100+ servers. The critical insight: the tool `description` field is sent directly to the LLM as part of its prompt context — it's the instruction manual for AI tool selection. Tool-level descriptions explain *what* and *when*; schema property descriptions guide *how*. Keep schemas as flat as possible since deeply nested structures increase token count and LLM errors. Tool execution errors use `isError: true` in results (for business logic failures), while protocol errors use standard JSON-RPC error codes.

### OAuth 2.1 with mandatory PKCE secures remote MCP

For HTTP transports, OAuth 2.1 with PKCE is the standard. The MCP server acts as an OAuth Resource Server; the client acts as an OAuth Client. The flow begins when the server returns HTTP 401 with a `WWW-Authenticate` header containing a `resource_metadata` URL. The client discovers the authorization server via RFC 9728 Protected Resource Metadata, performs the OAuth flow, and includes `Authorization: Bearer <token>` on subsequent requests. **Resource Indicators (RFC 8707) are mandatory** — the `resource` parameter prevents confused deputy attacks by binding tokens to specific MCP servers.

### Rate limiting is critical because LLMs call tools autonomously

A single agent in a retry loop can generate **1,000+ API calls per minute**. The token bucket algorithm (capacity for burst, refill rate for sustained load) is most common. Limit across multiple dimensions: per-client, per-tool (expensive operations get lower limits), and organization-level. Enterprise deployments increasingly use **MCP gateways** (MintMCP, Kong, Traefik Hub, Bifrost) that centralize rate limiting, authentication, and observability. AWS prescriptive guidance recommends implementing primary rate limiting at the MCP server level with backend services providing secondary protection.

---

## 5. A2A and x402 complete the agentic infrastructure stack

### Google's A2A reached v1.0 production readiness

The Agent-to-Agent protocol launched at Google Cloud Next in April 2025 and reached **v1.0 in early 2026** under Linux Foundation governance. Where MCP standardizes agent-to-tool communication (vertical), A2A standardizes agent-to-agent communication (horizontal). Agents are treated as **opaque autonomous peers** — they don't share internal state, plans, or tool implementations.

**Agent Cards** are JSON metadata documents published at `/.well-known/agent-card.json`, functioning as digital business cards describing identity, service endpoint, capabilities, skills, and authentication requirements. V1.0 added cryptographic signing via JWS for identity verification across organizational boundaries.

Tasks progress through defined states: `submitted` → `working` → `input-required` → `completed`/`failed`/`canceled`, with `auth-required` added in v1.0. Messages contain Parts (TextPart, FilePart, DataPart) and communication flows over JSON-RPC 2.0 with SSE streaming, push notifications via webhooks, or gRPC (added in v0.3). The protocol has **150+ supporting organizations** including Google, Salesforce, SAP, ServiceNow, Atlassian, Microsoft, and IBM (which merged its Agent Communication Protocol into A2A).

### x402 revives HTTP 402 for machine-to-machine payments

Created by Coinbase's developer platform team, x402 enables programmatic payments within HTTP interactions. The flow: a client requests a resource, the server returns **HTTP 402 Payment Required** with payment terms (price, accepted networks, recipient address), the client creates a signed payment payload, retries the request with a `PAYMENT-SIGNATURE` header, a **facilitator** verifies and settles the payment on-chain, and the server returns the resource.

V2 (December 2025) added multi-chain support via CAIP-2 identifiers, an extensions system, dynamic per-request payment routing, and unified fiat/crypto rails. **Stripe has native x402 support in preview** as of early 2026, letting merchants accept x402 payments through their existing Stripe dashboard. The **x402 Foundation** launched April 2, 2026, under the Linux Foundation with founding members including Coinbase, Stripe, Cloudflare, Google, Microsoft, AWS, Visa, Mastercard, and Shopify. Primary settlement uses **USDC on Base and Solana** (65% of volume) with sub-cent transaction costs. Daily volume as of early March 2026 was ~$28K across ~131K transactions — still early but growing.

These protocols form complementary layers: agents use **A2A** to discover and coordinate with each other, **MCP** to access tools and data, and **x402** to pay for services autonomously. Google's Agentic Payments Protocol (AP2) already integrates x402 as the default stablecoin settlement rail.

---

## 6. API versioning: Stripe's date-based approach remains the gold standard

**URL path versioning** (`/v1/`, `/v2/`) is the most popular strategy — used by Stripe, Twilio, Meta, Twitter — because versions are visible in URLs, easy to test, and simple to route at the infrastructure level. **Header versioning** (`Accept-Version` or custom headers) keeps URLs clean and is more RESTful, but versions become invisible in logs and harder to debug. **Content negotiation** (`Accept: application/vnd.github.v3+json`) is the most REST-purist approach — GitHub uses it — but requires deep understanding of media types and is difficult to test.

Stripe's implementation is the industry benchmark. Versions are date-based (e.g., `2024-12-18.acacia`) and the first API request pins an account to the current version. Engineers write code only for the latest version — a **response compatibility layer** transforms modern responses backward to match older client versions. Stripe has maintained backward compatibility with every API version since 2011. Since 2024, Stripe publishes **biannual named releases** (Acacia, Basil) with a 72-hour rollback window after upgrade.

For breaking change detection, **oasdiff** covers 300+ breaking change categories with CI/CD integration via GitHub Action. **Optic** offers "forwards-only governance" that won't retroactively lint existing endpoints. **Sunset headers** (RFC 8594) indicate when a URI will become unresponsive, while the newer **Deprecation header** (RFC 9745) signals deprecation timing. Zalando mandates both headers in their guidelines. The emerging best practice is to support the current plus previous version for **12-24 months**, with GitHub guaranteeing at least 24 months.

---

## 7. Webhook reliability requires HMAC verification, idempotent consumers, and exponential backoff

**At-least-once delivery** is the only achievable guarantee — exactly-once is mathematically impossible per the Two Generals Problem. The practical goal is exactly-once *processing* through idempotent consumers. Every major provider includes idempotency keys: Stripe's `event.id`, GitHub's `X-GitHub-Delivery` header, Shopify's `X-Shopify-Webhook-Id`.

Signature verification follows a consistent pattern across providers: the sender computes **HMAC-SHA256** over the payload using a shared secret, includes the signature in a header, and the receiver recomputes and compares. Stripe signs `{timestamp}.{raw_payload}` (the timestamp in the signature prevents replay attacks) and sends it as `Stripe-Signature: t=1614265330,v1=5257a869...`. GitHub uses `X-Hub-Signature-256: sha256=757107ea...`. Always verify against **raw request body bytes** (not parsed-then-reserialized JSON) and use constant-time comparison (`crypto.timingSafeEqual`) to prevent timing attacks.

Retry strategies follow exponential backoff: `wait = min(base_delay × 2^attempt + jitter, max_delay)`. Stripe retries over **3 days** (~7 attempts), Shopify makes **19 attempts over 48 hours**, and GitHub notably offers no automatic retries at all. After exhausting retries, events move to a **dead letter queue** — store the full payload, all delivery attempts, and failure categorization. Alert when failure rate exceeds 0.5%. The **Standard Webhooks** initiative (backed by Zapier, Twilio, ngrok, Supabase, Kong) standardizes three mandatory headers (`webhook-id`, `webhook-timestamp`, `webhook-signature`) and is adopted by OpenAI, Brex, and Clerk among others.

For tooling, **Svix** is the leading outbound webhook-as-a-service (used by OpenAI), **Hookdeck** handles reliable inbound webhook processing with 120+ pre-configured sources, and **ngrok** remains the standard for local development tunneling.

---

## 8. OpenAPI generation and SDK tooling have diverged by quality tier

### Code-first generation across languages

**FastAPI** delivers the most seamless code-first experience — complete OpenAPI 3.0 specs auto-generate from Python type hints and Pydantic models with zero annotations needed. **springdoc-openapi** (successor to springfox) scans Spring MVC controllers and JSR-303 validation annotations to produce OpenAPI 3.0+ specs. In Go, **swaggo/swag** uses comment annotations for Swagger 2.0, while **oapi-codegen** is preferred for spec-first development with OpenAPI 3.0/3.1. For TypeScript, **tsoa** generates both OpenAPI specs and Express routes from decorators, while NestJS's `@nestjs/swagger` provides similar capabilities.

### SDK generators: openapi-generator vs Speakeasy vs Stainless

**openapi-generator** (open source, 50+ languages) has the broadest support but generated code often requires manual refinement — enterprises estimate **3+ FTEs** of maintenance burden. **Speakeasy** (10 languages, free tier to $600/month) generates production-ready SDKs with runtime type safety (Zod for TypeScript, Pydantic for Python) and minimal dependencies — its TypeScript SDKs have exactly one dependency versus 25+ for competitors. **Stainless** generates the official SDKs for OpenAI, Anthropic, and Cloudflare, downloaded **130+ million times per week**, using a custom config layer atop OpenAPI that enables advanced customization at the cost of additional complexity. Both Speakeasy and Stainless now generate MCP servers and Terraform providers from OpenAPI specs.

### Contract testing catches integration breaks before deployment

**Pact** pioneered consumer-driven contract testing: consumers define expected interactions, generate "pact" files, and providers verify they can fulfill the contracts. The `can-i-deploy` tool gates deployments based on contract verification. **Schemathesis** takes a different approach — property-based API testing that auto-generates thousands of test cases including edge cases and boundary values from OpenAPI schemas. It typically surfaces **5-15 issues on first run** against production schemas. Zalando mandates Dredd for all APIs and Pact for core APIs.

---

## 9. Three style guides dominate, and linting makes them enforceable

**Google's API Design Guide** (organized as numbered AIPs) emphasizes resource-oriented design with standard methods (List, Get, Create, Update, Delete) and custom methods using `:action` suffixes. **Microsoft's REST API Guidelines** prefer PATCH over PUT (calling PUT "dangerous" for full replacement), use `api-version` query parameters, and follow Azure's `Operation-Location` pattern for long-running operations. **Zalando's guidelines** mandate snake_case properties (not camelCase), API-first development with peer review, RFC 7807 Problem Details for errors, and a dedicated `Money` type with decimal amounts.

**Spectral** by Stoplight is the most widely adopted API linter, supporting custom YAML rulesets with JSONPath targeting and built-in OpenAPI/AsyncAPI rules. It integrates via GitHub Action with branch protection. **Redocly CLI** offers configurable rules without code plus custom JavaScript plugins, with a unique "decorators" feature for modifying specs during publishing. Both tools can enforce any of the three major style guides.

The emerging **SKILL.md and AGENTS.md** ecosystem encodes API design rules for AI coding assistants. Every major tool now supports project-level instructions: Cursor uses `.cursor/rules/*.mdc`, Claude Code uses `CLAUDE.md`, GitHub Copilot uses `.github/instructions/*.instructions.md`, and OpenAI Codex uses `AGENTS.md` (emerging as the cross-tool standard). **Ruler** (open source) centralizes rules in `.ruler/skills/` and distributes them to 30+ AI agent formats simultaneously, enabling teams to encode API design standards (response formats, error handling, naming conventions) as living, version-controlled assets.

---

## Conclusion

The modern API stack has stratified into clear layers with distinct concerns. **REST at Richardson Level 2** remains the pragmatic baseline for most APIs, with conditional requests and long-running operation patterns handling the hard cases. **GraphQL** thrives in production when DataLoader eliminates N+1 queries, complexity scoring prevents abuse, and nullable-by-default prevents null bubbling disasters. **gRPC** demands operational attention to keepalive coordination, MaxConnectionAge for load balancer compatibility, and strict deadline propagation — with the Connect protocol emerging as the sensible browser-facing alternative.

The genuinely new developments are in the agentic layer. **MCP's Streamable HTTP transport** solved the scalability problems of the original SSE approach, and OAuth 2.1 with mandatory PKCE provides enterprise-grade security. **A2A** fills the gap MCP doesn't address — how autonomous agents discover and collaborate with each other as opaque peers. **x402** adds the payment primitive, enabling agents to pay for API access without human intervention. These three protocols form a complementary stack that's rapidly consolidating under Linux Foundation governance.

The meta-pattern across all these protocols is the same: **machine-readable specifications** (OpenAPI, GraphQL SDL, protobuf, JSON Schema) enable automated tooling — SDK generation, contract testing, linting, breaking change detection, and now AI coding assistant rules. Teams that invest in spec-first development, automated governance via Spectral or Redocly, and SDK generation via Speakeasy or Stainless compound their velocity with every API they ship.