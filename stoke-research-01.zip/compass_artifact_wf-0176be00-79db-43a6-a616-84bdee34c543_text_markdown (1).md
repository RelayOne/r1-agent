# Premium B2B SaaS design systems: a technical benchmark

**Eight products — Linear, Attio, Notion, Vercel, Stripe, Raycast, Arc Browser, and Liveblocks — define the current gold standard for B2B SaaS interface design.** The common thread is restraint: desaturated palettes, 13–14px body text, barely-visible shadows, and sub-200ms animations. These products achieve their premium feel not through bold visual flourishes but through obsessive consistency at the pixel level — algorithmic color generation, perceptually-uniform spacing, and custom typography tuned with bespoke letter-spacing. This report documents the exact design tokens, patterns, and implementation details for each product, then synthesizes the 10 concrete decisions that separate premium from generic SaaS UI, and closes with a production-ready Tailwind CSS + shadcn/ui configuration modeled on Linear.

---

## Product-by-product design system audit

### Linear

**Color palette.** Linear's brand colors are Mercury White `#F4F5F8` and Nordic Gray `#222326`. The signature accent is a **desaturated indigo `#5E6AD2`** — muted enough to recede in dense interfaces but distinct enough for CTAs. The entire theme system runs on **LCH color space** (not HSL), driven by just three inputs: base color, accent color, and a contrast slider (0–100). These three variables generate ~98 derived tokens for surfaces, borders, and text. Default dark background sits at **`#0F0F10` to `#1A1A1E`** (true dark, not gray-dark), with elevated surfaces stepping up to `#151516` → `#1E1E22`. Light mode uses `#FFFFFF` background with `#EDEEF3` elevated surfaces. Status colors follow the product's unique circular indicators: **orange-red for urgent**, orange for high priority, yellow for medium, blue for low. Completed states use a desaturated green (~`#4CB782`).

**Typography.** Primary font is **Inter** for body text and **Inter Display** for headings (introduced in the 2024 redesign). The font stack falls back through SF Pro Display → system-ui → Segoe UI. Body text in the application is **13px** (not 14 or 16), achieving the dense productivity feel. Overline labels run at **12px/semibold** with wide letter-spacing (`0.08em`). Button labels are **14px/semibold**. Marketing headings scale up to 62px/800 weight. Critically, Linear enables Inter's OpenType features: `font-feature-settings: "cv02", "cv03", "cv04", "cv11"` for tighter, more geometric glyph alternates.

**Spacing and layout.** An **8px grid** with 4px half-steps. No traditional column grid — instead a content-first modular layout. The 2024 redesign explicitly increased information density. Sidebar alignment is pixel-precise across labels, icons, and buttons both horizontally and vertically.

**Border radius.** Subtle and consistent: **6px** on buttons and inputs, **8px** on cards/panels, **8–12px** on modals, **50%** on avatars. Never pill-shaped, never sharp — the aesthetic is crisp, not bubbly.

**Shadows and elevation.** Minimal. Linear communicates elevation primarily through **surface color differentiation** using LCH-derived steps rather than box-shadows. Borders are semi-transparent white overlays in dark mode. When shadows appear (modals, command palette), they're subtle compound shadows: tight 1px shadow + larger diffused shadow at very low opacity.

**Dark mode.** True dark (`#0F0F10`–`#1A1A1E`), not pure black — has subtle color tinting. The 2024 redesign moved from the original "Magic Blue" tinted theme to a more neutral palette. Borders are generated algorithmically via opacity-based calculations. Surface layering progresses: background → foreground → panels → dialogs → tooltips, each a perceptually-uniform step lighter. Text was made **lighter in dark mode** and the overall contrast increased.

**Iconography.** Fully custom icon set — not Lucide, Phosphor, or Heroicons. Distinctive circular status indicators and multi-bar priority icons are signature elements. Estimated **1.5px stroke weight**, primarily **16px and 20px** sizes. Built on Radix Primitives for accessible interactions.

**Motion.** Linear deliberately moved away from heavy animations in its 2024 redesign. Transitions run at **100–200ms** with ease-out curves. The command palette (⌘K) uses a subtle scale + fade entrance. The architecture (offline-first with IndexedDB) minimizes loading states entirely — content appears near-instantly. The philosophy is speed-serving, not decorative.

---

### Vercel (Geist design system)

**Color palette.** Vercel's brand color is functionally **black `#000`** — the triangle logo is pure black on white, pure white on dark. The design system uses **10-step color scales** with P3 wide-gamut support. Background-1 (light): **`#FFFFFF`**; Background-2: **`#FAFAFA`**. Dark mode Background-1: **`#0A0A0A`**; Background-2: **`#111111`**. Primary text: `#000000` (light) / `#EDEDED` (dark). Secondary text: **`#666666`** (light) / **`#A1A1A1`** (dark). Semantic scales: Blue **`#0070F3`**, Red **`#E5484D`**, Amber **`#F5A623`**, Green **`#46A758`**, Teal `#12A594`, Purple `#8E4EC6`, Pink `#E93D82`. Each hue has a full 10-step scale (component backgrounds, hover states, active states, borders at various levels, high-contrast backgrounds, and text). CSS variables follow the pattern `--background-100`, `--blue-dark-100`, consumable via the `geist-colors` npm package.

**Typography.** **Geist Sans** — a custom variable font (weights 100–900) inspired by Swiss design, available under OFL. Monospace counterpart: **Geist Mono**. Display variant: **Geist Pixel** (bitmap-inspired). The type scale is extensive: headings from 14px to 72px, buttons at 12/14/16px, labels at 12–20px, and copy at 13–24px. The **most commonly used text style is Copy-14 (14px)**, with Copy-13 (13px) for secondary text in space-constrained views. Label styles have tighter line-heights than Copy styles (designed for single-line with icon pairing vs. multi-line text).

**Spacing.** 8px base grid with 4px subgrid. Common padding values: 8, 12, 16, 24, 32, 48px. The grid is described as "a huge part of the new Vercel aesthetic."

**Border radius.** Tight and minimal: **~6px** on buttons, **~8px** on cards/fieldsets, **~12px** on modals. Badges/pills are fully rounded. The design philosophy uses borders as "lines and dividers, not boxes" — directional borders (top, bottom, left) for emphasis.

**Shadows.** **Border-driven, not shadow-driven.** Primary elevation uses subtle 1px borders at `var(--gray-alpha-400)`. When shadows appear (rare), they're minimal: `0 1px 2px rgba(0,0,0,0.1)`. The system includes a Materials foundation for backdrop-filter/blur glassmorphism overlays.

**Dark mode.** First-class implementation via CSS custom properties with `data-theme="dark"`. Dark background is **`#0A0A0A`** — near-black but not pure black. Every color in every 10-step scale has explicit light and dark values.

**Iconography.** Custom **Geist icon set** — tailored for developer tools, SVG format, outlined/stroked style. Designed to pair with label-13 and label-14 text sizes.

**Motion.** Subtle and fast — spring animations with damped motion, standard CSS transitions at ~150–200ms ease. Custom "Loading Dots" and "Spinner" components. Button hover lift, tab slide indicators, toast entrance animations.

---

### Stripe Dashboard

**Color palette.** Primary brand color: **`#635BFF`** ("Blurple" — a warm indigo-purple). Deep navy `#0A2540` for dark marketing backgrounds. Dashboard surface: **`#F6F9FC`** page background, **`#FFFFFF`** card backgrounds. Text: **`#30313D`** primary, **`#727F96`** placeholder. Error: **`#DF1B41`**. Elements API primary: `#0570DE`. Stripe built a custom accessible color system using **CIELAB perceptual uniformity** — each color scale step predictably passes WCAG 2.0 contrast thresholds (4.5:1 small text, 3:1 large text).

**Typography.** **Söhne** (by Klim Type Foundry) — a variable font (`Söhne-var`) licensed ~2020, replacing Camphor. Monospace: Söhne Mono. Display: **Söhne Breit** (wide variant for marketing). Seven font files with 124 variations. Base size: **14px** with weight 500 (medium) as "normal." Marketing body is 18px/300 weight. Font tokens include `heading`, `subheading`, `body`, `bodyEmphasized`, `caption`, `captionEmphasized`.

**Spacing.** Base unit: **2px** (`spacingUnit`), with standard steps: 0, 2, 4, 8, 16, 24, 32, 48px. Layout uses a fractional grid system (halves, thirds, quarters, fifths) with stack-based composition (`stack: 'x' | 'y' | 'z'`).

**Border radius.** Elements default: **4px**. Marketing CTA buttons: **8px**. Mobile payment elements: 12px default. Cards: ~8px. Stripe is slightly tighter than peers.

**Shadows.** Stripe uses distinctive **compound layered shadows**: a tight 1px shadow paired with a larger diffused shadow for realistic depth. Tab shadow: `0px 1px 1px rgba(0,0,0,0.03), 0px 3px 6px rgba(18,42,66,0.02)`. Focus states use a **ring pattern** (`0 0 0 2px`) rather than glow. Invalid input: `0 1px 1px 0 rgba(0,0,0,0.07), 0 0 0 2px var(--colorDanger)`.

**Dark mode.** Dashboard has historically been light-only. The Elements API supports `stripe` (light), `night` (dark), and `flat` themes. Mobile has full light/dark support via separate `colorsLight` and `colorsDark` maps.

**Iconography.** Custom icon set with extensive payment-specific icons. Clean, outlined style consistent with the geometric Söhne typeface. Comprehensive icon color tokens: `iconColor`, `iconHoverColor`, `iconCardErrorColor`, `iconCheckmarkColor`, and more.

**Motion.** Marketing site is renowned for high-quality animations (animated gradients, code editors, globes). Dashboard transitions are smooth but restrained. Button hover shadows elevate, tabs have smooth selection transitions. Standard `transition: box-shadow 0.3s ease` for interactive elements.

---

### Notion

**Color palette.** Brand identity is essentially **black and white** with a selection accent of **`#2EAADC`** (teal-blue). Light mode background: **`#FFFFFF`**, secondary surface: **`#F7F6F3`** (warm off-white). Default text: **`#37352F`** (warm dark brown, not pure black). Dark mode background: **`#2F3437`** (warm dark gray, not true black). Notion's defining color feature is its **10-color semantic system** — Default, Gray, Brown, Orange, Yellow, Green, Blue, Purple, Pink, Red — each with separate hex values for text, background, and icon usage. For example, in light mode: Blue text `#487CA5`, Blue background `#E9F3F7`, Blue icon `#337EA9`. In dark mode these shift: Blue text `#447ACB`, Blue background `#1F282D`, Blue icon `#2E7CD1`. All backgrounds are notably **desaturated and pastel** in light mode, and deeply muted in dark mode.

**Typography.** **Inter** as default, with user-selectable alternatives: Georgia/Lyon-Text (serif) and iaWriter Mono (monospace). Body text is **16px** with 1.5 line-height (24px) — larger than most peers. H1: **30px/700**, H2: **24px/600**, H3: **20px/600**. Small text toggle reduces to ~14px. Letter-spacing is normal for body; headings use slightly tighter spacing.

**Spacing.** Content max-width: **720px**. Header height: 45px. Block indent: 27px. Page left padding: 96px. Block spacing is tight: 1px margin between adjacent blocks, 4px top/bottom on paragraphs. Base unit is 4px.

**Border radius.** Notably **minimal**: **3px** on buttons, inline code, select tags, callout blocks. 4–8px on modals/tooltips. Page covers are full-bleed (0px). Avatars are circular. Notion's design is intentionally flat — most elements use very small radii.

**Shadows.** Three-tier system for overlays only: border-like `rgba(15,15,15,0.05) 0px 0px 0px 1px`, medium `rgba(15,15,15,0.1) 0px 3px 6px`, deep `rgba(15,15,15,0.2) 0px 9px 24px`. Cards and database items have no shadow — rely on border/background differentiation. The philosophy is flat-first.

**Dark mode.** Warm dark gray `#2F3437` background (not true black). All 10 semantic colors shift — backgrounds become deeply muted (e.g., Blue bg from `#E9F3F7` → `#1F282D`), text colors become lighter and more vibrant. Surface layering uses slightly lighter grays for nested surfaces (`#454B4E` for highlights vs `#2F3437` base).

**Iconography.** Custom thin-stroke SVG icons (~1.5px stroke) at 14px inline, 18px toolbar, 24px page headers. Page icons are emoji-based. Icon colors follow the 10-color system with dedicated, more-saturated hex values.

**Motion.** Deliberately restrained. Opacity transitions at 20ms ease-in, expanding elements at 300ms ease-in. No spring animations or bouncy effects. Menu/dropdown appearance uses fade + slight scale at ~200ms. Priority is speed and content focus.

---

### Raycast

**Color palette.** Primary brand color: **`#FF6363`** (warm coral-red). The theme system uses a **12-slot token structure**: background primary/secondary, text primary/secondary/tertiary, plus 7 semantic colors (red, orange, yellow, green, blue, purple, magenta). The API exposes 9 named `Color.*` tokens that **automatically adapt** between light and dark with built-in contrast adjustment. Default dark backgrounds are deep charcoal (~`#1A1A2E`); light backgrounds are ~`#EFF1F5`. The website is predominantly dark-themed.

**Typography.** **Inter** — confirmed by Raycast's team: "Throughout the app, we use @rsms's Inter font with custom letter and line spacing. It was surprisingly challenging to support it in an all-native Swift application but we think it was worth the effort." Custom letter-spacing (tighter than Inter defaults) and custom line-height, both deliberately tuned. Search bar input: ~16–18px. List item titles: **~13–14px**. Subtitles/metadata: ~11–12px. Section headings: ~11px, often uppercase semibold.

**Spacing.** 8px base grid. List items: ~8–10px vertical, 12–16px horizontal padding. Icon-to-text gaps: 4px. Content padding: 16px. Section separations: 20–24px. Main window is ~750px wide with variable height.

**Border radius.** Main window: **12–16px** (generous macOS-native radius). Search bar: **8–10px**. List selection highlight: 6–8px. Buttons/tags: 4–6px. Extension icons use a rounded-rectangle mask (~22% corner radius). Supports `Image.Mask.Circle` and `Image.Mask.RoundedRectangle`.

**Shadows.** Relies on **macOS native vibrancy and translucency** (NSVisualEffectView) rather than CSS box-shadows. The floating panel casts a large system-level drop shadow. Action panel has subtle elevation separation. The approach is frosted-glass + system shadows, not hand-crafted box-shadow values.

**Dark mode.** True dark by default — deep charcoal/near-black backgrounds. Surface layering through slight luminance differences and vibrancy/translucency rather than heavy borders. All built-in icons ship with **separate light and dark SVG variants**. Custom themes (Pro feature) allow full 12-color palette customization.

**Iconography.** Custom proprietary set of **hundreds of icons** at **16px** base size. Clean geometric outlines with ~1.5px stroke weight. Many icons have both outline and filled variants. All are theme-aware with separate light/dark versions. Raycast provides a Figma Extension Icon Template for consistent extension icon creation.

**Motion.** Built entirely in **AppKit** (not SwiftUI or Electron) for 60fps performance. List items slide in/out with subtle ease transitions. Compact Mode expands smoothly from search-bar-only to full window. Action panel springs up from bottom. Navigation uses push/pop transitions. The team describes their priority: "render something as quickly as possible." Animations use custom cubic-bezier curves with slight spring overshoot.

---

### Attio

**Color palette.** Logo/wordmark: **`#1C1D1F`** (near-black). Primary accent is an indigo-blue range used for interactive elements and the signature "blinking blue cursor." Light mode: white backgrounds with `#F8F8F8`–`#F5F5F5` secondary surfaces. Dark mode: deep dark gray (not pure black). Subtle gradients are core to Attio's visual identity — gradient overlays on cards, backgrounds, and interactive elements. Status colors in pipeline views: green/active, red/lost, amber/pending, blue/in-progress.

**Typography.** **Inter/InterVariable** with stack: `Inter, -apple-system, BlinkMacSystemFont, sans-serif`. Marketing H1: ~48–64px/600–700. Body: ~15–16px/400. Product UI uses a tighter, more compact scale appropriate for data-dense CRM views. Formalized type system via SDK `<Typography />` component.

**Spacing.** Compact spacing (likely 4px or 8px base) given data-dense CRM context. SDK includes `<Section />`, `<Divider />`, `<DescriptionList />` for modular spacing. Marketing site uses generous whitespace (80–120px section padding).

**Border radius.** App icons: **30% corner radius** automatically applied based on icon size (1000px icon = 300px radius) with a **10% opacity inset outline**. Product UI: ~8–12px on cards/modals, ~4–6px on buttons/inputs.

**Shadows.** Described as "elegant cards with perfect shadows and timing." Notifications stack like macOS-style cards with layered shadows. Hover states reveal additional shadow/elevation for interactive feedback.

**Dark mode.** Full support via Account Settings → Appearance toggle. Icons designed to work on both light and dark backgrounds. Follows modern dark gray (not pure black) convention.

**Motion.** **Cubic-bezier curve animations** explicitly called out as "perfectly-smooth." Tactile hover states are a signature interaction pattern. Subtle gradients animate on interaction. Workflow canvas features animated data flow visualization with "satisfying arrow bends." Command+K launcher with smooth animation. Notification stacking with "perfect timing."

---

### Arc Browser

**Color palette.** Arc has no fixed brand palette — its core identity is **user-personalized color theming**. Each user selects their own gradient/color during onboarding. Arc injects CSS custom properties into every page: `--arc-palette-background`, `--arc-palette-foregroundPrimary`, `--arc-palette-foregroundSecondary`, `--arc-palette-hover`, `--arc-palette-focus`, plus gradient variables. Default text: **`#0C0D1D`** (deep navy). Marketing uses purple/gradient aesthetics.

**Typography.** **SF Pro / SF Pro Display** (Apple's system font) on macOS; **Segoe UI Variable** on Windows. Sidebar tab labels: ~13px regular. Section headers: ~11px semibold uppercase with tracking. Command bar: ~16–18px. This is a native-first typographic approach.

**Border radius.** Command bar: **8px** (confirmed from SwiftUI code). Tab items: 6–8px. Little Arc floating window: 12px. Browser window follows macOS system radius (~10px). Overall: soft, rounded, consistent with modern macOS language.

**Shadows.** Uses **macOS vibrancy and blur effects** extensively (NSVisualEffectView / `.ultraThinMaterial`) rather than traditional box-shadows. Elevation is communicated through **translucency, blur, and color** rather than drop shadows. The command bar popup has prominent frosted-glass elevation.

**Dark mode.** Adapts to macOS system appearance. The CSS custom properties automatically recalculate — `--arc-palette-background` shifts to very dark values, foreground shifts to light values. User's chosen theme gradient persists across both modes. A colored border around the viewport remains in both modes.

**Motion.** Arc's standout feature. **Spring-based physics animations** throughout via SwiftUI. The command bar has a signature "pop" animation with `scaleEffect` and `PhaseAnimator`. Tab switching: smooth crossfade. Sidebar show/hide: animated slide. Space switching: horizontal swipe with spring transition. Drag-and-drop: spring physics. Search bar has a multi-phase animation sequence (idle → validating → decrease → increase → finished) with shadow pop and scale transform. Built natively in Swift for 60fps.

---

### Liveblocks

**Color palette.** Design token system via CSS variables scoped to `.lb-root`: `--lb-accent` (configurable, default blue/indigo), `--lb-background` (e.g., `#EEEEEE`), `--lb-destructive` / `--lb-destructive-foreground` / `--lb-destructive-contrast` for error states. Example values: surface `#FFFFFF`, button background `#F8F8F8`, text `#181818`. Marketing site uses dark backgrounds with gradient accent highlights.

**Typography.** Inter for marketing/docs. Component text uses relative sizing via `--lb-spacing` (em-based). Demonstrated compact layout at `font-size: 14px`. Semibold for usernames, `text-sm` + `text-gray-500` for timestamps.

**Spacing.** Token-driven: `--lb-spacing` controls all component internal spacing (default ~1em). Thread gaps: 8px. Active thread offset: 12px. Tutorial patterns show 4px, 8px, 12px, 16px steps.

**Border radius.** Token-based via `--lb-radius` (can be set to 0 for sharp corners or any value). Toolbar: 8px. Buttons: 4px. Built on Radix Primitives for configurable radius.

**Shadows.** Dual-layer pattern: `0px 2px 4px rgba(0,0,0,0.1), 0px 0px 0px 1px rgba(0,0,0,0.05)` — soft spread shadow + hairline border shadow. AI Chat composer uses shadow by default (removable in compact layout).

**Dark mode.** Two approaches: system-based (`@media (prefers-color-scheme: dark)`) or attribute-based (`.dark` class / `data-theme="dark"` / `data-dark="true"`). Progressive: base styles first, dark mode layered on top. Separate CSS imports for each approach.

**Architecture.** Built on **Radix Primitives** (Dialog, Menu, Tooltip, ScrollArea) + Tailwind CSS + React + Next.js. Components are composable with `asChild` pattern. CSS variables scoped to `.lb-root` for shadow DOM support. Official Figma "Collaboration Kit" on Figma Community.

---

## 10 specific decisions that make these products feel premium

These are not abstract principles. They are concrete, pixel-level choices observable across the benchmark set.

**1. Body text is 13px, not 14 or 16px.** Linear, Vercel (Copy-13), and Raycast all use 13px for secondary or primary body text. This creates information density that signals "power tool" rather than "consumer app." Notion is the outlier at 16px, but it's a document editor — context matters. The 13px choice with Inter at `-webkit-font-smoothing: antialiased` produces a crisp, refined look that 14px cannot replicate.

**2. Shadows are barely visible — elevation is communicated through surface color difference.** Linear's shadows run at **3–8% opacity** (e.g., `rgba(0,0,0,0.04)` for cards). Vercel uses borders instead of shadows entirely. The observable pattern across the set: `0 1px 2px rgba(0,0,0,0.03)` for micro-elevation, `0 4px 12px rgba(0,0,0,0.06)` for dropdowns — compared to generic SaaS which commonly uses `0 4px 16px rgba(0,0,0,0.15)` or heavier. Cards at `#FFFFFF` on `#F8FAFA` backgrounds already feel elevated without any shadow.

**3. Status/semantic colors are desaturated compared to typical SaaS.** Linear's success green is `#4CB782` (muted sage, not `#22C55E` neon green). Vercel's red is `#E5484D` (warm, not screaming). Notion's semantic backgrounds are deeply pastel (`#E9F3F7` for blue, `#EEF3ED` for green). This desaturation prevents semantic colors from dominating the interface and maintains a calm, editorial tone. Standard SaaS uses Tailwind's default saturated palette; premium products uniformly pull saturation down **15–25%**.

**4. Border radius is 6px on buttons and inputs, not 8px or rounded-full.** Linear: 6px buttons. Vercel: ~6px buttons. Stripe: 4–8px. The premium SaaS consensus lands at **4–8px** — sharp enough to feel precise, round enough to feel modern. Generic SaaS defaults to `rounded-lg` (8px) or pill shapes (`rounded-full`), which reads as softer and less intentional. Notion goes even sharper at 3px. None of these products use pill-shaped buttons for primary actions.

**5. Dark mode backgrounds are `#0A0A0A` to `#111`, not `#1F2937` gray.** Linear: `#0F0F10`. Vercel: `#0A0A0A`. Raycast: deep charcoal ~`#1A1A2E`. These are **true dark** backgrounds with barely perceptible color tinting — warm or cool — but never the common `gray-800`/`gray-900` that Tailwind defaults suggest. The exception is Notion at `#2F3437` (soft dark), which suits its document-editor context. The true-dark approach increases contrast range and makes accent colors pop.

**6. Borders in dark mode use 10–15% white opacity, not gray hex values.** Linear generates borders via "opacities of black and white" — e.g., `rgba(255,255,255,0.08)` rather than `#2A2A2E`. This produces borders that adapt naturally to any surface color underneath. At `16%` lightness in the HSL space, these borders are nearly invisible but do their structural job. Generic SaaS hard-codes `border-gray-700` which looks heavy.

**7. Font weight distribution is Medium (500) for UI, not Bold (700).** Across the benchmark: Linear uses 500 for navigation, 600 for buttons/labels. Stripe's "normal" weight is explicitly 500 (Medium). Vercel uses Label styles with medium weight for UI elements, reserving bold for emphasis. The consistent pattern: **body at 400, UI elements at 500, emphasis at 600, headings at 600–700**. Generic SaaS overuses 700 (Bold), which creates visual noise.

**8. Letter-spacing is tightened on headings and widened on small caps/overlines.** Linear uses `-0.02em` to `-0.03em` on large display text and `0.08em` (wide tracking) on 12px overline labels. Vercel's heading classes include negative letter-spacing. This bidirectional letter-spacing — tight on large text, open on small text — is a hallmark of professional typesetting that generic SaaS almost never implements.

**9. Animations target 150–200ms with ease-out, never spring bounce.** Linear, Vercel, Stripe, and Notion all converge on **150–200ms ease-out** for standard UI transitions (dropdowns, tooltips, hover states). Not the 300ms that CSS defaults suggest. Not spring physics (except Arc and Raycast, which are native macOS apps where spring physics are platform-native). The translate distance is minimal: **4px**, not 8 or 16. Scale transitions use `0.97` → `1.0`, barely perceptible. This creates the "instant but smooth" feel.

**10. The accent color is a single desaturated indigo/blue used sparingly.** Linear: `#5E6AD2` (desaturated indigo). Vercel: `#0070F3` (restrained blue). Stripe: `#635BFF` (muted purple). The interface is **95% monochrome** with this single accent appearing only on primary CTAs, active states, and focus rings. Generic SaaS sprays color across navigation highlights, badges, dividers, and section headers. Premium products achieve visual calm by restricting chromatic color to moments that demand attention.

---

## Reproducing Linear's quality: complete Tailwind + shadcn/ui configuration

### globals.css — shadcn/ui CSS variables

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    /* ─── Light Mode (Linear Light) ─── */
    --background: 240 5% 97.6%;        /* #F8F8FA */
    --foreground: 240 6% 10%;          /* #18181B */

    --card: 0 0% 100%;                 /* #FFFFFF */
    --card-foreground: 240 6% 10%;     /* #18181B */

    --popover: 0 0% 100%;             /* #FFFFFF */
    --popover-foreground: 240 6% 10%; /* #18181B */

    --primary: 234 58% 60%;           /* #5E6AD2 — Linear's signature indigo */
    --primary-foreground: 0 0% 100%;  /* #FFFFFF */

    --secondary: 240 4% 93%;          /* #EDEDF0 */
    --secondary-foreground: 240 6% 25%; /* #3C3C43 */

    --muted: 240 4% 93%;              /* #EDEDF0 */
    --muted-foreground: 240 4% 46%;   /* #6E6E76 */

    --accent: 240 4% 93%;             /* #EDEDF0 */
    --accent-foreground: 240 6% 10%;  /* #18181B */

    --destructive: 0 72% 51%;         /* #DC2626 */
    --destructive-foreground: 0 0% 100%;

    --border: 240 6% 90%;             /* #E4E4E8 */
    --input: 240 6% 90%;              /* #E4E4E8 */
    --ring: 234 58% 60%;              /* matches primary */

    --radius: 0.375rem;               /* 6px */

    /* ─── Sidebar ─── */
    --sidebar: 240 5% 95.5%;          /* #F2F2F5 */
    --sidebar-foreground: 240 6% 10%;
    --sidebar-primary: 234 58% 60%;
    --sidebar-primary-foreground: 0 0% 100%;
    --sidebar-accent: 240 4% 90%;
    --sidebar-accent-foreground: 240 6% 10%;
    --sidebar-border: 240 6% 90%;
    --sidebar-ring: 234 58% 60%;

    --chart-1: 234 58% 60%;
    --chart-2: 173 58% 39%;
    --chart-3: 43 96% 56%;
    --chart-4: 0 72% 51%;
    --chart-5: 280 60% 55%;
  }

  .dark {
    /* ─── Dark Mode (Linear's default/primary) ─── */
    --background: 240 6% 7%;           /* #101012 */
    --foreground: 240 5% 92%;          /* #EAEAED */

    --card: 240 5% 10%;               /* #191A1E */
    --card-foreground: 240 5% 92%;    /* #EAEAED */

    --popover: 240 5% 12%;            /* #1E1E22 */
    --popover-foreground: 240 5% 92%;

    --primary: 234 58% 65%;           /* #6B75DB */
    --primary-foreground: 0 0% 100%;

    --secondary: 240 4% 15%;          /* #252528 */
    --secondary-foreground: 240 5% 80%;

    --muted: 240 4% 15%;              /* #252528 */
    --muted-foreground: 240 4% 53%;   /* #838389 */

    --accent: 240 4% 17%;             /* #2A2A2E */
    --accent-foreground: 240 5% 92%;

    --destructive: 0 62% 55%;         /* #D44747 */
    --destructive-foreground: 0 0% 100%;

    --border: 240 4% 16%;             /* #272729 */
    --input: 240 4% 18%;              /* #2C2C30 */
    --ring: 234 58% 65%;

    --sidebar: 240 6% 6%;             /* #0E0E10 */
    --sidebar-foreground: 240 5% 85%;
    --sidebar-primary: 234 58% 65%;
    --sidebar-primary-foreground: 0 0% 100%;
    --sidebar-accent: 240 4% 13%;
    --sidebar-accent-foreground: 240 5% 92%;
    --sidebar-border: 240 4% 14%;
    --sidebar-ring: 234 58% 65%;

    --chart-1: 234 58% 65%;
    --chart-2: 173 58% 50%;
    --chart-3: 43 96% 60%;
    --chart-4: 0 62% 55%;
    --chart-5: 280 60% 65%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
    font-feature-settings: "cv02", "cv03", "cv04", "cv11";
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }
}
```

### tailwind.config.ts

```ts
import type { Config } from "tailwindcss";
import tailwindAnimate from "tailwindcss-animate";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    fontFamily: {
      sans: [
        "Inter",
        "ui-sans-serif",
        "-apple-system",
        "BlinkMacSystemFont",
        '"Segoe UI"',
        "Roboto",
        '"Helvetica Neue"',
        "Arial",
        "sans-serif",
      ],
      display: [
        '"Inter Display"',
        "Inter",
        "ui-sans-serif",
        "-apple-system",
        "sans-serif",
      ],
      mono: [
        '"JetBrains Mono"',
        '"SF Mono"',
        '"Fira Code"',
        "ui-monospace",
        "SFMono-Regular",
        "monospace",
      ],
    },

    /* Tight type scale centered on 13px body */
    fontSize: {
      "2xs":  ["0.625rem",  { lineHeight: "0.875rem" }],   // 10px
      xs:     ["0.6875rem", { lineHeight: "1rem" }],        // 11px
      sm:     ["0.75rem",   { lineHeight: "1rem" }],        // 12px
      base:   ["0.8125rem", { lineHeight: "1.25rem" }],     // 13px
      md:     ["0.875rem",  { lineHeight: "1.25rem" }],     // 14px
      lg:     ["1rem",      { lineHeight: "1.5rem" }],      // 16px
      xl:     ["1.125rem",  { lineHeight: "1.625rem" }],    // 18px
      "2xl":  ["1.25rem",   { lineHeight: "1.75rem" }],     // 20px
      "3xl":  ["1.5rem",    { lineHeight: "2rem",
               letterSpacing: "-0.01em" }],                  // 24px
      "4xl":  ["1.875rem",  { lineHeight: "2.25rem",
               letterSpacing: "-0.02em" }],                  // 30px
      "5xl":  ["2.25rem",   { lineHeight: "2.5rem",
               letterSpacing: "-0.02em" }],                  // 36px
      "6xl":  ["3rem",      { lineHeight: "3.25rem",
               letterSpacing: "-0.025em" }],                 // 48px
      "7xl":  ["3.75rem",   { lineHeight: "4rem",
               letterSpacing: "-0.03em" }],                  // 60px
    },

    extend: {
      colors: {
        border:      "hsl(var(--border))",
        input:       "hsl(var(--input))",
        ring:        "hsl(var(--ring))",
        background:  "hsl(var(--background))",
        foreground:  "hsl(var(--foreground))",
        primary:     {
          DEFAULT:    "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary:   {
          DEFAULT:    "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT:    "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted:       {
          DEFAULT:    "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent:      {
          DEFAULT:    "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover:     {
          DEFAULT:    "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card:        {
          DEFAULT:    "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        sidebar:     {
          DEFAULT:           "hsl(var(--sidebar))",
          foreground:        "hsl(var(--sidebar-foreground))",
          primary:           "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent:            "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border:            "hsl(var(--sidebar-border))",
          ring:              "hsl(var(--sidebar-ring))",
        },
        chart: {
          "1": "hsl(var(--chart-1))",
          "2": "hsl(var(--chart-2))",
          "3": "hsl(var(--chart-3))",
          "4": "hsl(var(--chart-4))",
          "5": "hsl(var(--chart-5))",
        },
        /* Linear-specific semantic tokens */
        linear: {
          accent:       "#5E6AD2",
          "accent-hover": "#4850B8",
          success:      "#4CB782",
          warning:      "#F2C94C",
          error:        "#D44747",
          info:         "#4DA8DA",
        },
      },

      borderRadius: {
        lg:   "var(--radius)",              // 6px
        md:   "calc(var(--radius) - 2px)",  // 4px
        sm:   "calc(var(--radius) - 4px)",  // 2px
        xs:   "1px",
        full: "9999px",
      },

      spacing: {
        "4.5":  "18px",
        "5.5":  "22px",
        "13":   "52px",
        "15":   "60px",
        "18":   "72px",
        sidebar:       "240px",
        "sidebar-sm":  "200px",
        "content-max": "720px",
      },

      boxShadow: {
        "linear-xs":    "0 1px 2px 0 rgba(0,0,0,0.03)",
        "linear-sm":    "0 1px 3px 0 rgba(0,0,0,0.04), " +
                        "0 1px 2px -1px rgba(0,0,0,0.03)",
        "linear-md":    "0 4px 12px 0 rgba(0,0,0,0.06), " +
                        "0 1px 4px 0 rgba(0,0,0,0.04)",
        "linear-lg":    "0 8px 30px 0 rgba(0,0,0,0.08), " +
                        "0 2px 8px 0 rgba(0,0,0,0.04)",
        "linear-xl":    "0 16px 60px 0 rgba(0,0,0,0.12), " +
                        "0 4px 16px 0 rgba(0,0,0,0.06)",
        "linear-inset": "inset 0 1px 2px 0 rgba(0,0,0,0.04)",
        "linear-dark-sm": "0 1px 3px 0 rgba(0,0,0,0.2), " +
                          "0 1px 2px -1px rgba(0,0,0,0.15)",
        "linear-dark-md": "0 4px 12px 0 rgba(0,0,0,0.3), " +
                          "0 1px 4px 0 rgba(0,0,0,0.2)",
        "linear-dark-lg": "0 8px 30px 0 rgba(0,0,0,0.4), " +
                          "0 2px 8px 0 rgba(0,0,0,0.25)",
      },

      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to:   { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to:   { height: "0" },
        },
        "fade-in": {
          from: { opacity: "0" },
          to:   { opacity: "1" },
        },
        "fade-out": {
          from: { opacity: "1" },
          to:   { opacity: "0" },
        },
        "scale-in": {
          from: { opacity: "0", transform: "scale(0.97)" },
          to:   { opacity: "1", transform: "scale(1)" },
        },
        "scale-out": {
          from: { opacity: "1", transform: "scale(1)" },
          to:   { opacity: "0", transform: "scale(0.97)" },
        },
        "slide-down": {
          from: { opacity: "0", transform: "translateY(-4px)" },
          to:   { opacity: "1", transform: "translateY(0)" },
        },
        "slide-up": {
          from: { opacity: "0", transform: "translateY(4px)" },
          to:   { opacity: "1", transform: "translateY(0)" },
        },
        "slide-in-from-left": {
          from: { transform: "translateX(-100%)" },
          to:   { transform: "translateX(0)" },
        },
        "slide-in-from-right": {
          from: { transform: "translateX(100%)" },
          to:   { transform: "translateX(0)" },
        },
        spinner: {
          to: { transform: "rotate(360deg)" },
        },
        "pulse-subtle": {
          "0%, 100%": { opacity: "1" },
          "50%":      { opacity: "0.6" },
        },
        "toast-in": {
          from: { opacity: "0", transform: "translateY(8px) scale(0.98)" },
          to:   { opacity: "1", transform: "translateY(0) scale(1)" },
        },
        "toast-out": {
          from: { opacity: "1", transform: "translateY(0) scale(1)" },
          to:   { opacity: "0", transform: "translateY(-4px) scale(0.98)" },
        },
      },

      animation: {
        "accordion-down":      "accordion-down 200ms ease-out",
        "accordion-up":        "accordion-up 200ms ease-out",
        "fade-in":             "fade-in 150ms ease-out",
        "fade-out":            "fade-out 100ms ease-in",
        "scale-in":            "scale-in 200ms ease-out",
        "scale-out":           "scale-out 150ms ease-in",
        "slide-down":          "slide-down 200ms ease-out",
        "slide-up":            "slide-up 200ms ease-out",
        "slide-in-from-left":  "slide-in-from-left 250ms ease-out",
        "slide-in-from-right": "slide-in-from-right 250ms ease-out",
        spinner:               "spinner 600ms linear infinite",
        "pulse-subtle":        "pulse-subtle 2s ease-in-out infinite",
        "toast-in":            "toast-in 200ms ease-out",
        "toast-out":           "toast-out 150ms ease-in forwards",
      },

      transitionDuration: {
        fast:   "100ms",
        normal: "200ms",
        slow:   "300ms",
      },
      transitionTimingFunction: {
        "linear-ease":   "cubic-bezier(0.25, 0.1, 0.25, 1)",
        "linear-spring": "cubic-bezier(0.175, 0.885, 0.32, 1.1)",
      },

      letterSpacing: {
        overline: "0.08em",
      },
      opacity: {
        "2.5": "0.025",
        "3.5": "0.035",
        "7.5": "0.075",
        "15":  "0.15",
        "35":  "0.35",
        "85":  "0.85",
      },
    },
  },
  plugins: [tailwindAnimate],
};

export default config;
```

### Implementation notes for Linear-quality execution

Beyond the config, four implementation details are critical. First, **enable Inter's stylistic alternates** via `font-feature-settings: "cv02", "cv03", "cv04", "cv11"` on `body` — these swap the default `a`, `g`, `l`, and `ß` glyphs for tighter, more geometric variants that Linear uses. Second, always apply **`-webkit-font-smoothing: antialiased`** — without this, Inter renders with subpixel hinting that looks heavier and less refined on macOS. Third, use the `font-display` stack for headings: `Inter Display` at 600–700 weight with negative letter-spacing (`-0.02em` at 24px+), dropping to regular Inter at 500 for UI labels. Fourth, the sidebar should be **slightly darker** than the main background in dark mode (not lighter) — `#0E0E10` sidebar on `#101012` background — which is the opposite of what many implementations do.

For shadcn/ui component overrides, the key adjustment is replacing the default `rounded-md` with `rounded-lg` (which maps to the custom 6px `--radius`), ensuring all dropdowns and popovers use `shadow-linear-md` instead of the default shadow, and setting the base font size to `text-base` (13px in this config). Focus rings should use `ring-2 ring-primary/50` rather than the default broader ring. Buttons should use `font-medium` (500 weight) rather than `font-semibold` for a lighter touch, except for primary CTAs which use `font-semibold` (600).

## Conclusion

The premium SaaS aesthetic is not about adding visual richness — it is about systematic restraint. These eight products converge on a narrow band of choices: 13–14px body text in Inter or a comparable geometric sans-serif, true-dark backgrounds below `#111`, desaturated semantic colors, compound shadows at 3–8% opacity, and animations completing in under 200ms. The most transferable insight is that **premium interfaces are 95% monochrome** with a single desaturated accent color. Linear's design system architecture — generating ~98 tokens from just 3 inputs using perceptually-uniform LCH color space — represents the current technical frontier. The Tailwind configuration above captures the output tokens of this approach, giving you a production-ready starting point that matches the quality bar these products have set.