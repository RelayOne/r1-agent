# Database migration safety, schema evolution, and polyglot persistence

**Safely evolving schemas across PostgreSQL, MongoDB, Redis, and Kafka without downtime requires mastering expand-and-contract patterns, lock-aware DDL, schema compatibility modes, and cross-store consistency guarantees.** This report provides battle-tested patterns, specific commands, and tool recommendations for every layer of a polyglot stack. The techniques draw from production practices at Stripe, GitHub, Uber, and Netflix, covering PostgreSQL 14–17, MongoDB 6.x–7.x, Kafka 3.x, and Confluent Schema Registry 7.x.

---

## 1. Zero-downtime PostgreSQL migrations demand lock awareness

The expand-and-contract pattern is the foundational approach: add new schema elements alongside existing ones, migrate data, update application code, then remove old elements. Every step must be backward-compatible so both old and new application versions function simultaneously. Stripe's migration of hundreds of millions of Subscription objects followed this four-phase model — dual-write, shadow-read with GitHub's Scientist library, switch primary, then remove old paths — with each changeset kept to a few hundred lines.

### ACCESS EXCLUSIVE lock reference for PostgreSQL 14–17

The critical insight for zero-downtime DDL is that **ACCESS EXCLUSIVE locks block all concurrent reads and writes**, and worse, queued ACCESS EXCLUSIVE requests block all subsequent operations behind them — even simple SELECTs. Always set `lock_timeout` before DDL:

```sql
SET lock_timeout = '5s';
ALTER TABLE users ADD COLUMN phone TEXT;
```

Here is the complete lock behavior matrix for modern PostgreSQL:

| Operation | Lock Level | Duration | Rewrites Table? |
|---|---|---|---|
| ADD COLUMN (no default) | ACCESS EXCLUSIVE | Instant | No |
| ADD COLUMN (constant default, e.g. `0`, `'active'`) | ACCESS EXCLUSIVE | Instant | No (PG 11+) |
| ADD COLUMN (volatile default: `now()`, `gen_random_uuid()`) | ACCESS EXCLUSIVE | Full rewrite | **Yes** |
| DROP COLUMN | ACCESS EXCLUSIVE | Instant | No |
| ALTER COLUMN TYPE (general) | ACCESS EXCLUSIVE | Full rewrite | **Yes** |
| ALTER COLUMN TYPE (widen varchar or → TEXT) | ACCESS EXCLUSIVE | Instant | No |
| SET NOT NULL (no CHECK exists) | ACCESS EXCLUSIVE | Full table scan | No |
| SET NOT NULL (valid CHECK exists, PG 12+) | ACCESS EXCLUSIVE | **Instant** | No |
| ADD CHECK ... NOT VALID | ACCESS EXCLUSIVE | Instant | No |
| VALIDATE CONSTRAINT | SHARE UPDATE EXCLUSIVE | Full scan | No |
| ADD FK ... NOT VALID | SHARE ROW EXCLUSIVE | Instant | No |
| DETACH PARTITION CONCURRENTLY (PG 14+) | SHARE UPDATE EXCLUSIVE | Two-phase | No |

The **PG 12+ SET NOT NULL optimization** is the most impactful pattern for safely adding NOT NULL constraints:

```sql
-- Step 1: Add CHECK constraint without validation (instant, ACCESS EXCLUSIVE briefly)
ALTER TABLE users ADD CONSTRAINT chk_email_nn CHECK (email IS NOT NULL) NOT VALID;

-- Step 2: Validate (SHARE UPDATE EXCLUSIVE — does NOT block writes)
ALTER TABLE users VALIDATE CONSTRAINT chk_email_nn;

-- Step 3: SET NOT NULL is now instant (skips scan due to valid CHECK)
ALTER TABLE users ALTER COLUMN email SET NOT NULL;

-- Step 4: Clean up
ALTER TABLE users DROP CONSTRAINT chk_email_nn;
```

For unique constraints, build the index first, then attach it:

```sql
CREATE UNIQUE INDEX CONCURRENTLY idx_users_email ON users(email);
ALTER TABLE users ADD CONSTRAINT uniq_email UNIQUE USING INDEX idx_users_email;
```

### Online schema change tools

**pg_repack** creates a shadow table, copies data with a trigger-based change log, then swaps atomically with a brief ACCESS EXCLUSIVE lock. It requires a PRIMARY KEY and approximately 2× free disk space. Key commands:

```bash
pg_repack -j 4 --table my_table your_database  # Parallel index rebuilds
pg_repack --wait-timeout=30 --no-kill-backend --table my_table your_database
```

**pgroll by Xata** takes a different approach: it creates versioned virtual schemas via views. Each schema "version" is a set of views pointing to the correct columns. Dual-writes between old and new columns are handled by triggers. Rollback is instant — just cancel the migration. Migrations are defined in JSON:

```json
{
  "name": "02_set_not_null",
  "operations": [{
    "alter_column": {
      "table": "customers", "column": "review",
      "nullable": false,
      "up": "CASE WHEN review IS NULL THEN 'No review' ELSE review END",
      "down": "review"
    }
  }]
}
```

```bash
pgroll start migration.json    # Expand phase — both versions coexist
pgroll complete                 # Contract phase — remove old version
pgroll rollback                 # Instant rollback at any point
```

### CREATE INDEX CONCURRENTLY pitfalls

`CREATE INDEX CONCURRENTLY` acquires only SHARE UPDATE EXCLUSIVE (allows reads and writes) but has critical failure modes. If it fails mid-build, the index remains **INVALID** in the catalog — invisible to the planner but still consuming write overhead on every INSERT/UPDATE/DELETE. Always check for invalid indexes:

```sql
SELECT indexname FROM pg_indexes i
JOIN pg_class c ON c.relname = i.indexname
JOIN pg_index idx ON idx.indexrelid = c.oid
WHERE NOT idx.indisvalid;
```

**Never rely on `IF NOT EXISTS`** — it silently succeeds even with an invalid index present. Always drop invalid indexes explicitly before retrying. Monitor progress with `pg_stat_progress_create_index` (PG 12+).

### Migration testing with production-scale data

**Neon database branching** creates instant copy-on-write branches regardless of database size (~1 second). Each branch gets its own connection string for isolated testing:

```yaml
# GitHub Actions integration
- uses: neondatabase/create-branch-action@v5
  with:
    project_id: ${{ secrets.NEON_PROJECT_ID }}
    branch_name: pr-${{ github.event.number }}
- name: Run migrations on branch
  run: npx drizzle-kit migrate
  env:
    DATABASE_URL: ${{ steps.create-branch.outputs.db_url }}
```

---

## 2. PostgreSQL operational knowledge every migration depends on

### pg_stat_statements for identifying migration impact

Enable in `postgresql.conf` with `shared_preload_libraries = 'pg_stat_statements'` (requires restart), then `CREATE EXTENSION pg_stat_statements`. The most impactful query for migration planning identifies the heaviest queries by total time:

```sql
SELECT round(total_exec_time::numeric, 2) AS total_ms, calls,
  round(mean_exec_time::numeric, 2) AS mean_ms,
  round((100 * total_exec_time / sum(total_exec_time) OVER ())::numeric, 2) AS pct,
  substring(query, 1, 100) AS query
FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 10;
```

### VACUUM, autovacuum, and transaction ID wraparound

PostgreSQL's MVCC means dead tuples accumulate from every UPDATE and DELETE. Autovacuum triggers when `dead tuples > threshold + scale_factor × reltuples`. The default **20% scale factor** means a 10-million-row table must accumulate 2 million dead tuples before vacuuming. For high-write tables, override per-table:

```sql
ALTER TABLE hot_table SET (
  autovacuum_vacuum_scale_factor = 0.02,    -- 2% instead of 20%
  autovacuum_vacuum_cost_delay = 0          -- No throttling
);
```

**Transaction ID wraparound** is PostgreSQL's most dangerous operational risk. With 32-bit XIDs, if old tuples aren't frozen, PostgreSQL eventually **halts all writes** to prevent data corruption. Monitor with:

```sql
SELECT datname, age(datfrozenxid) AS xid_age,
  round(100.0 * age(datfrozenxid) / 2147483647, 2) AS pct_to_wraparound
FROM pg_database ORDER BY age(datfrozenxid) DESC;
```

### Long-running transactions poison VACUUM

VACUUM can only remove dead tuples invisible to all active transactions. The **xmin horizon** — the oldest active snapshot — determines the cleanup boundary. Four things hold it back: long-running transactions, abandoned replication slots, standby transactions with `hot_standby_feedback`, and orphaned prepared transactions. A comprehensive monitoring query must check all four:

```sql
SELECT pid, state, now() - xact_start AS duration, left(query, 80) AS query
FROM pg_stat_activity WHERE state = 'idle in transaction'
ORDER BY xact_start ASC;
```

Set `idle_in_transaction_session_timeout = '5min'` to auto-terminate idle sessions. **PostgreSQL 17 added `transaction_timeout`** as a hard cap on total transaction duration.

### Bloat detection and remediation

Use `pgstattuple` for accurate measurement (`SELECT * FROM pgstattuple('my_table')`) or `pgstattuple_approx` for a faster estimate. For index bloat, `SELECT * FROM pgstatindex('my_index')` reveals `avg_leaf_density` and fragmentation. **REINDEX CONCURRENTLY** (PG 12+) rebuilds indexes without blocking reads or writes — use it when bloat exceeds 20%.

### Partition pruning verification

Confirm pruning works with `EXPLAIN (COSTS OFF)` — pruned partitions simply won't appear in the plan. Common mistakes that **prevent pruning**: applying functions to partition keys (`WHERE to_char(logdate, 'YYYY-MM-DD') = '...'`), data type mismatches, and prepared statements switching to generic plans after 5 executions. PG 16+ adds `last_seq_scan` timestamps to `pg_stat_user_tables` for identifying problematic sequential scans.

---

## 3. MongoDB schema evolution with version-aware documents

### Schema versioning pattern

The MongoDB-recommended approach adds a `schemaVersion` field to every document. Application code dispatches to version-specific handlers:

```python
SCHEMA_HANDLERS = {
    1: lambda doc: {"name": doc["name"], "work": doc.get("work")},
    2: lambda doc: {"name": doc["name"],
         "work": next((c["work"] for c in doc.get("contact_method", []) if "work" in c), None)}
}

def read_contact(collection, contact_id):
    doc = collection.find_one({"_id": contact_id})
    version = doc.get("schema_version", 1)
    return SCHEMA_HANDLERS[version](doc)
```

The **polymorphic pattern** stores documents with different shapes in the same collection, distinguished by a discriminator field. Mongoose supports this natively via `discriminatorKey`. Partial indexes per type keep queries efficient:

```javascript
db.notifications.createIndex({ recipientEmail: 1 },
  { partialFilterExpression: { type: "email" } });
```

### Lazy vs. batch migration tradeoffs

**Lazy migration** transforms documents on read and optionally writes back the new format. It requires no downtime and amortizes cost over traffic, but cold data never migrates and every read path must handle multiple versions. **Batch migration** using `bulkWrite` with `ordered: false` and cursor-based pagination achieves a clean uniform state but generates heavy oplog traffic. For sharded clusters, always route through **mongos**, use `{ ordered: false }` for throughput, and consider disabling the balancer during intensive migrations with `sh.stopBalancer()`.

### Schema validation evolution

MongoDB's JSON Schema validation supports gradual enforcement. Start with `validationLevel: "moderate"` and `validationAction: "warn"` to grandfather existing non-compliant documents, then progressively tighten to `"strict"` + `"error"` after cleanup. Multi-version validation uses `oneOf`:

```javascript
db.runCommand({
  collMod: "contacts",
  validator: { $jsonSchema: { bsonType: "object", oneOf: [
    { required: ["name"], properties: { schemaVersion: { enum: [1] } } },
    { required: ["name", "schemaVersion", "contact_method"],
      properties: { schemaVersion: { enum: [2] } } }
  ]}}
});
```

**MongoDB 6.0** added `changeStreamPreAndPostImages` for tracking before/after states during migration. **MongoDB 7.0** added `dryRun: true` for `collMod` unique index conversion and compound wildcard indexes.

---

## 4. Kafka Schema Registry compatibility modes decoded

### Avro vs. Protobuf evolution rules

**Avro** identifies fields by name and requires explicit default values for new fields in backward-compatible changes. Type promotions follow `int → long → float → double` and `string ↔ bytes`. Adding enum symbols is backward-compatible; removing them is forward-compatible.

**Protobuf** identifies fields by number — **never change field numbers**. Adding fields is always safe (both directions). Removing fields is safe if the number is reserved. Field renaming is safe since names aren't on the wire. The recommended compatibility mode for Protobuf is **BACKWARD_TRANSITIVE**.

| Feature | Avro | Protobuf |
|---|---|---|
| Field identification | By name | By number |
| Add field | Needs default for backward compat | Always safe |
| Remove field | Safe if has default (FORWARD) | Safe; reserve the number |
| Rename field | Via aliases only | Safe (names not on wire) |
| Type promotion | int→long→float→double | Limited same-wire-type only |

### Six compatibility modes explained

**BACKWARD** (default): New schema reads old data. Consumers upgrade first. Adding fields with defaults and removing fields are allowed. **FORWARD**: Old schema reads new data. Producers upgrade first. **FULL**: Both directions — only add/remove fields with defaults. Each has a **TRANSITIVE** variant checking against all historical versions, not just the latest. `FULL_TRANSITIVE` is the most restrictive mode, suitable for safety-critical systems.

The deployment order rule is critical: **BACKWARD = upgrade consumers first; FORWARD = upgrade producers first; FULL = any order**.

### Subject naming and tooling

Confluent Schema Registry 7.x supports three naming strategies: `TopicNameStrategy` (default, `<topic>-value`), `RecordNameStrategy` (fully-qualified record name, for multiple schemas per topic), and `TopicRecordNameStrategy` (hybrid). Test compatibility before registering:

```bash
curl -X POST -H "Content-Type: application/vnd.schemaregistry.v1+json" \
  --data '{"schema": "{...}"}' \
  http://localhost:8081/compatibility/subjects/{subject}/versions/latest?verbose=true
```

**Apicurio Registry** (Red Hat, open-source) supports additional formats including OpenAPI, AsyncAPI, and GraphQL, with a Confluent-compatible API endpoint at `/apis/ccompat/v7/`. **Karapace** (Aiven, Apache 2.0) is a true drop-in replacement that can use the same `_schemas` topic and Confluent serdes unchanged.

### Dead letter queues for schema failures

Kafka Connect sink connectors support DLQ natively with `errors.tolerance: "all"` and `errors.deadletterqueue.topic.name`. **Always enable** `errors.deadletterqueue.context.headers.enable: true` — without error context headers, debugging is impossible. For Kafka Streams, implement a custom `DeserializationExceptionHandler` that routes failed records to a DLQ topic with error metadata. Confluent Enterprise offers broker-side Schema ID Validation that rejects invalid messages before they reach consumers.

---

## 5. Cross-service schema coordination without downtime

### The ordering problem and its solution

When Service A adds a field that Service B must start sending, the expand-contract pattern resolves the sequencing: deploy the migration first (new field nullable with default), then deploy Service B to start populating the field, then deploy Service A to consume it, then finally make the field required.

**Consumer-driven contract testing with Pact** prevents breaking changes: consumers define expected interactions, generate contract files shared via a Pact Broker, and providers verify against these contracts. The `can-i-deploy` CLI tool gates deployments on contract verification status. Only tested interactions are enforced — unused provider behavior can change freely.

The **tolerant reader pattern** (Postel's Law) instructs consumers to ignore unexpected fields and use defaults for missing ones. In Jackson: `@JsonIgnoreProperties(ignoreUnknown = true)`. In Protobuf this is built-in — unknown fields are preserved during deserialization.

### Feature flags for migration rollout

LaunchDarkly provides purpose-built **migration flags** with six stages: `off → dualwrite → shadow → live → rampdown → complete`. Each stage controls which system is read from and written to, with percentage-based rollout. Their own MongoDB-to-DynamoDB migration used four independent flags controlling read/write to each store, enabling gradual customer-by-customer cutover with instant rollback.

---

## 6. Migration rollback requires data-level thinking

### Why data rollback is harder than schema rollback

Rolling back application code is a container swap. Rolling back data is fundamentally different — restoring a backup loses all subsequent writes, referential integrity constraints may conflict, and the longer since migration, the more new data depends on the new schema. The primary strategies are: **keeping old columns during the transition period** (never drop immediately), **storing rollback metadata** in temporal/audit tables, and **rolling forward** with a new corrective migration rather than rolling backward.

### Shadow migration and dual-write verification

Stripe's shadow migration pattern writes to both old and new stores simultaneously, then uses GitHub's **Scientist** library to compare results from both read paths. Production traffic is served from the trusted (old) path while the new path is validated in the background. Only after verified consistency does the read path switch. This approach requires that every phase is independently reversible.

### Blue-green database deployments

AWS RDS provides native blue-green deployments using PostgreSQL logical replication. Green mirrors Blue's topology; switchover takes ~1 minute. Key constraints: **every table must have a primary key** for logical replication, DDL is not replicated (apply manually to both), and sequences are not replicated until switchover. Monitor `TransactionLogsGeneration` to ensure WAL doesn't accumulate excessively.

### Point-in-time recovery limitations

PostgreSQL PITR via WAL replay restores the **entire cluster** — not individual tables. It requires an unbroken WAL chain from the base backup and makes the database unavailable during recovery. Use PITR for catastrophic events (accidental DROP TABLE); use application-level rollback for targeted fixes. MongoDB's oplog-based PITR has similar constraints — oplog gaps from topology changes invalidate recovery windows.

---

## 7. Backfilling billions of rows without locking production

### Cursor-based pagination over OFFSET

OFFSET-based pagination degrades catastrophically at scale (from ~1.5s to 15s+ per batch as offset grows). **Keyset/cursor pagination** maintains constant performance:

```sql
UPDATE users SET display_name = first_name || ' ' || last_name
FROM (SELECT id FROM users WHERE id > $last_processed_id
      AND display_name IS NULL ORDER BY id LIMIT 1000) AS batch
WHERE users.id = batch.id RETURNING users.id;
```

Each batch runs as a separate transaction, releasing locks immediately. Use `pg_sleep(0.1)` between batches and advisory locks to prevent concurrent backfills:

```sql
SELECT pg_try_advisory_lock(hashtext('backfill_users_display_name'));
```

### Progress tracking and resumability

A checkpoint table tracks the last processed ID, total processed count, and status. All backfill operations must be **idempotent** — safe to re-run on the same rows. DoorDash achieved ~10,000 rows/sec but throttled to keep replica lag under 20ms. OpenAI accepted backfills taking over a week to complete safely.

### Dual-write with triggers during transition

PostgreSQL triggers synchronize old and new columns automatically:

```sql
CREATE OR REPLACE FUNCTION sync_status_columns() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status_new IS DISTINCT FROM OLD.status_new THEN NEW.status_old := NEW.status_new; END IF;
  IF NEW.status_old IS DISTINCT FROM OLD.status_old THEN NEW.status_new := NEW.status_old; END IF;
  RETURN NEW;
END; $$ LANGUAGE plpgsql;
```

---

## 8. Polyglot consistency across Postgres, Redis, and Kafka

### The consistency gap every polyglot system faces

At T0 a user writes to Postgres. At T1 the Redis cache still holds the old value. At T2 the Kafka event hasn't propagated. At T3 downstream consumers haven't processed the event. The window T0–T3 is where different stores return different answers.

### Cache-aside with TTL is the 95% solution

**Cache-aside** (application manages cache, invalidate on write) is the dominant pattern. The critical ordering rule: **always commit to the database first, then invalidate the cache** (delete, don't update). Reversing this allows stale data to be cached indefinitely. For the race condition where a read between commit and invalidation repopulates stale data, Facebook's lease-token approach (from their Memcache paper) provides the fix.

```python
async def update_user(user_id, data):
    await db.execute("UPDATE users SET name=$2 WHERE id=$1", user_id, data['name'])
    await redis.delete(f"user:{user_id}")  # Invalidate, don't set
```

### The outbox pattern eliminates dual-write failures

Writing to Postgres and publishing to Kafka in the same code path is a dual-write — if Kafka fails after DB commit, the event is lost. The **transactional outbox** writes the event to an outbox table within the same database transaction. A separate relay process (polling-based or CDC-based) publishes from the outbox to Kafka:

```sql
CREATE TABLE outbox (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sequence_id BIGSERIAL NOT NULL,
    event_type TEXT NOT NULL, topic TEXT NOT NULL,
    payload JSONB NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW(),
    published_at TIMESTAMPTZ
);
```

### Debezium CDC as the gold standard relay

Debezium reads PostgreSQL's WAL via logical decoding (`pgoutput` plugin), converting every committed change into a Kafka event in commit order. Configure PostgreSQL with `wal_level = logical` and create a dedicated publication. The Debezium outbox `EventRouter` transform routes events from the outbox table directly to their target Kafka topics. CDC advantages over polling: **near-zero latency, zero database load** (reads WAL, not the table), and preserved commit ordering.

### Read-your-own-writes across stores

Combine multiple strategies: write to cache immediately after DB commit for the writing user's session, use consistency tokens (version numbers returned on write, required on read), and fall back to reading from the primary when the replica hasn't caught up. MongoDB natively supports causal consistency sessions with `readConcern: "majority"` and `writeConcern: "majority"`.

---

## 9. Connection pooling determines your migration ceiling

### PgBouncer transaction mode — what breaks and what doesn't

PgBouncer in `transaction` mode assigns backend connections per-transaction, enabling thousands of clients on a handful of server connections. But session-scoped features break entirely:

- **SET/RESET**: Lost between transactions. Use `SET LOCAL` within transactions instead
- **Prepared statements**: Broken pre-1.21. **PgBouncer 1.21+** added protocol-level prepared statement support — set `max_prepared_statements = 100`. Only works with protocol-level `PQprepare`, not SQL-level `PREPARE`
- **Advisory locks**: Session-scoped `pg_advisory_lock` breaks. Use `pg_advisory_xact_lock()` instead
- **LISTEN/NOTIFY**: Use a separate dedicated connection in session mode
- **Temp tables**: Use `ON COMMIT DROP` temp tables only

### The connection pool sizing formula

The PostgreSQL-origin formula, popularized by HikariCP: **`connections = (core_count × 2) + effective_spindle_count`**. For a 4-core server with SSD: `(4 × 2) + 1 = 9 connections`. Oracle demonstrated a **50× latency improvement** by reducing pool size. Beyond ~50 connections, throughput actually *decreases* due to context switching, lock contention, and cache pollution.

### PgCat and Odyssey as modern alternatives

**PgCat** (Rust, multi-threaded) adds read replica load balancing, automatic failover, sharding, and Prometheus metrics. Instacart runs it in production serving hundreds of thousands of queries/second. Benchmarks show PgCat reaching **59K TPS** vs PgBouncer's 44K at high connection counts, where PgBouncer's single thread saturates.

**Odyssey** (C, Yandex) uses a coroutine engine with configurable worker threads. It handles **1M+ requests/second** at Yandex and critically provides automatic cancel + ROLLBACK on client disconnect — preventing connection pool poisoning that PgBouncer allows. Odyssey excels under heavy TLS loads where PgBouncer's single thread bottlenecks.

### MongoDB connection pooling

The default `maxPoolSize` changed from **5** (driver v3.x) to **100** (v4.x) — a significant change. Each `MongoClient` creates a separate pool per server in the topology plus 2 monitoring connections. A 3-member replica set with 4 app servers at default settings generates **1,224 total connections**. The `maxConnecting: 2` default rate-limits connection storms during failover.

---

## 10. Migration safety tools that catch dangerous DDL before production

### Linters that prevent outages

**Squawk** (Rust, 30+ rules) statically analyzes PostgreSQL migration SQL for lock-acquiring operations, missing `CONCURRENTLY`, `NOT VALID` omissions, and unsafe type changes. GitHub Actions integration:

```yaml
- uses: sbdchd/squawk-action@v2
  with:
    pattern: "migrations/*.sql"
```

**strong_migrations** (Rails) intercepts ActiveRecord migrations at runtime, blocking dangerous operations with suggested safe alternatives. It detects non-concurrent index creation, column removal without `safety_assured`, and adding NOT NULL without defaults.

**django-pg-zero-downtime-migrations** transparently rewrites Django's migration SQL — always using `CREATE INDEX CONCURRENTLY`, splitting NOT NULL additions into multi-step operations, and adding constraints with `NOT VALID`.

### Schema management platforms

**Atlas** (Ariga) supports both declarative (Terraform-like desired-state) and versioned migration workflows. Its **50+ safety analyzers** detect destructive changes, lock-acquiring operations, and backward-incompatible modifications. The `--dev-url "docker://postgres/16/dev"` flag spins up ephemeral databases for diffing.

**Flyway** provides version-based SQL migrations with checksum validation. Undo migrations require the paid Teams edition; the community edition supports rolling forward only. **Liquibase** offers four changelog formats (XML, YAML, SQL, JSON) with built-in auto-rollback for many change types and a precondition system for conditional execution.

**Bytebase** is a full database DevOps platform with **200+ SQL review rules**, approval workflows, GitOps integration, and 1-click rollback via pre-execution snapshots. It covers PostgreSQL, MySQL, MongoDB, Redis, and ClickHouse.

### CI pipeline integration pattern

The recommended CI pipeline combines multiple tools: Squawk for SQL linting, Atlas for migration analysis, and a dry-run against an ephemeral database:

```yaml
name: Migration Safety
on: pull_request
jobs:
  lint:
    runs-on: ubuntu-latest
    services:
      postgres: { image: "postgres:16", env: { POSTGRES_PASSWORD: test }, ports: ["5432:5432"] }
    steps:
      - uses: actions/checkout@v4
      - uses: sbdchd/squawk-action@v2
        with: { pattern: "migrations/*.sql" }
      - uses: ariga/atlas-action/migrate/lint@v1
        with:
          dir: 'file://migrations'
          dev-url: 'postgres://postgres:test@localhost:5432/postgres?sslmode=disable'
```

---

## Conclusion

The core principle unifying all ten areas is **incremental, reversible change**. PostgreSQL migrations succeed when every ALTER TABLE is lock-aware and every step supports rollback — the PG 12+ CHECK-then-SET-NOT-NULL pattern and pgroll's virtual schemas both embody this. MongoDB's schemaless nature shifts the burden to application code via versioned handlers, with `moderate` validation as the bridge. Kafka's compatibility modes enforce evolution rules at registration time, but the choice between BACKWARD and FULL_TRANSITIVE has real deployment-order consequences that teams often discover too late.

The most underappreciated risk is **polyglot consistency**. The outbox pattern with Debezium CDC — not naive dual-writes — is the only reliable path from Postgres commits to Kafka events. Cache-aside with delete-on-write (never set-on-write) eliminates the most common Redis staleness pattern. Read-your-own-writes across stores requires session-aware routing and consistency tokens, not just lower TTLs.

For connection management, the formula `(cores × 2) + spindles` consistently outperforms "more connections = more throughput" intuition. PgBouncer 1.21+ finally resolved the prepared statement limitation that forced many teams into session mode. PgCat and Odyssey offer compelling alternatives when load balancing, automatic failover, or TLS scalability matter.

Finally, migration safety tools have matured enough that **no migration should reach production without automated linting**. Squawk catches unsafe PostgreSQL DDL, strong_migrations intercepts Rails operations, and Atlas provides language-agnostic analysis with 50+ safety rules. The CI pipeline that combines linting, dry-runs against ephemeral databases, and PR-level review comments represents the current state of the art for migration safety.