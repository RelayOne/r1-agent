# Production logging infrastructure: a complete guide for Go and TypeScript at scale

**At significant scale, logging costs can consume 10–25% of your infrastructure budget — sometimes exceeding compute itself.** The difference between a well-architected logging pipeline and a naive one is tens of thousands of dollars monthly and the difference between debugging an outage in minutes versus hours. This guide covers every dimension of production logging for Go and TypeScript services: from choosing the right aggregation platform and structuring log lines, to sampling, PII protection, volume management, alerting, retention, correlation, and application-level idioms — all with 2025–2026 pricing, tooling, and code examples.

---

## 1. Aggregation platforms differ by 20x in cost at scale

The choice of log aggregation platform is the single highest-leverage decision in your logging infrastructure. At **100 GB/day**, monthly costs range from **~$250 to ~$5,400** depending on your choice. The gap widens dramatically at higher volumes.

### Cost comparison at three ingestion tiers

| Platform | 100 GB/day | 1 TB/day | 10 TB/day | Architecture |
|----------|-----------|---------|----------|--------------|
| **Elastic Cloud Serverless** | ~$250/mo | ~$2,500/mo | ~$25,000/mo | Inverted index |
| **Axiom** | ~$500–750/mo | ~$5,000–6,750/mo | ~$45,000–67,500/mo | Columnar (cloud-native) |
| **Grafana Cloud Loki** | ~$1,500/mo | ~$15,000/mo | ~$150,000/mo (negotiable) | Index-free (labels only) |
| **AWS CloudWatch Logs** | ~$1,560/mo | ~$15,600/mo | ~$156,000/mo | Proprietary |
| **Datadog Logs** (all indexed) | ~$5,400/mo | ~$54,000/mo | ~$540,000/mo | Proprietary inverted index |
| **Datadog** (20% indexed + Flex) | ~$1,300/mo | ~$13,000/mo | ~$130,000/mo | Mixed |

These estimates include ingestion, 30-day retention, and moderate query volume. Datadog's sticker price is $0.10/GB ingestion but standard indexing adds $1.70/million events (15-day retention), making the effective cost $1.00–$2.50/GB. CloudWatch charges $0.50/GB ingestion plus $0.03/GB/month storage and $0.005/GB scanned for Logs Insights queries. Grafana Cloud Loki charges ~$0.50/GB ingested with 30-day retention included.

### Architecture drives query performance tradeoffs

**Loki (index-free)** stores compressed log chunks in object storage (S3/GCS) and indexes only labels — not log content. This makes it extremely cheap to store but means full-text search requires brute-force scanning across chunks. Label-based filtering is fast because labels are indexed. Loki excels when you query by known labels (service, namespace, level) and filter with `|=` or `| json` pipes. It struggles with unstructured grep across millions of lines.

**Elasticsearch/OpenSearch (inverted index)** indexes every token in every field. Full-text search is fast because it reads from the index, not raw data. The tradeoff is storage overhead — the index can be **1.5–2× raw data size**. Hot/warm/cold/frozen tiers via Index Lifecycle Management (ILM) help manage costs. Query performance degrades on frozen-tier data.

**Axiom (columnar)** uses a cloud-native columnar format with **~95% compression** (20× reduction). Queries execute on serverless compute (AWS Lambda), scaling to zero when idle. Virtual fields can be created at query time without re-indexing. This architecture offers excellent cost efficiency for long-term retention and ad-hoc analytics.

### Self-hosted versus SaaS

Self-hosting Loki or OpenSearch eliminates per-GB licensing but introduces significant operational overhead. A self-hosted Loki cluster handling 1 TB/day requires infrastructure costing **$3,000–$8,000/month** plus **1–2 SRE headcount** (~$300K+/year each). Total cost: $28,000–$60,000/month — mostly labor. Self-hosting becomes economically justified above roughly **5 TB/day** or when data sovereignty requirements exist. Below that threshold, managed services like Grafana Cloud or Elastic Cloud Serverless offer better cost-to-value ratios.

**Recommendation:** For most teams, **Grafana Cloud Loki** (good price, strong ecosystem, Grafana integration) or **Elastic Cloud Serverless** (cheapest, best full-text search) are the best starting points. Supplement with the dual-shipping pattern described in Section 6 to keep costs manageable. Avoid Datadog Logs as your primary log store unless you're already deeply invested in their ecosystem and can negotiate aggressively on volume pricing.

---

## 2. Every log line should tell a complete story

A structured JSON log line is the atomic unit of your observability system. Every log entry should contain enough context to be independently useful without requiring a second query.

### The canonical log line

```json
{
  "timestamp": "2025-04-06T10:30:15.123456Z",
  "level": "ERROR",
  "message": "payment processing failed",
  "service": "payment-service",
  "version": "2.4.1",
  "environment": "production",
  "trace_id": "5b8efff798038103d269b633813fc60c",
  "span_id": "eee19b7ec3c1b174",
  "request_id": "req-f878fb79-84a0",
  "caller": "handlers/payment.go:142",
  "error": {
    "type": "StripeTimeoutError",
    "message": "connection timed out after 30s",
    "stack_trace": "..."
  }
}
```

These fields align with the **OpenTelemetry Log Data Model** (stable as of OTel Spec 1.55.0). The OTel LogRecord defines `Timestamp`, `SeverityText`, `SeverityNumber` (1–24, where ERROR=17–20), `Body`, `TraceId`, `SpanId`, `Resource` (service.name, service.version, deployment.environment), and `Attributes` for arbitrary key-value pairs. The critical design principle: **OTel does not replace your logging library**. Use slog/zap/pino for log emission and connect them to OTel via log bridges.

### Go library recommendations (2025)

| Library | Best for | Allocations | OTel support |
|---------|----------|-------------|--------------|
| **`log/slog`** (stdlib) | New projects, minimal deps | ~40 B/op | Official bridge (`otelslog`) |
| **`uber-go/zap`** | High-perf + customization | ~168 B/op, 3 allocs | Official bridge (`otelzap`) |
| **`rs/zerolog`** | Maximum throughput | ~40 B/op, ~0 allocs | Community bridges |

For new Go projects, **slog is the recommended default**. It ships in the standard library (Go 1.21+), has official OTel support, and the `Handler` interface allows plugging in zap or zerolog as backends. For performance-critical hot paths, zerolog remains the fastest option.

```go
// slog: production-ready JSON logging with trace context
logger := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{
    AddSource: true,
    Level:     programLevel, // *slog.LevelVar for dynamic control
}))
logger.InfoContext(ctx, "request processed",
    slog.String("method", "POST"),
    slog.Int("status", 200),
    slog.Duration("duration", 150*time.Millisecond),
)
```

For TypeScript, **pino is the clear winner** — 5–10× faster than winston, JSON-first, with built-in child loggers and redaction. Winston remains useful only for legacy codebases needing complex multi-transport routing.

```typescript
const logger = pino({
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  timestamp: pino.stdTimeFunctions.isoTime,
  base: { service: 'auth-service', version: '1.2.3', environment: process.env.NODE_ENV },
});
// Child logger inherits all base fields + adds request scope
const reqLogger = logger.child({ request_id: 'req-abc123', trace_id: traceId });
```

### Automatic context enrichment without boilerplate

The goal is that every log line automatically includes service metadata and trace context without developers specifying it each time. In **Go**, wrap `slog.Handler` to inject `trace_id`, `span_id`, and `request_id` from `context.Context`:

```go
func (h *contextHandler) Handle(ctx context.Context, r slog.Record) error {
    if sc := trace.SpanContextFromContext(ctx); sc.IsValid() {
        r.AddAttrs(
            slog.String("trace_id", sc.TraceID().String()),
            slog.String("span_id", sc.SpanID().String()),
        )
    }
    if reqID, ok := ctx.Value(requestIDKey).(string); ok {
        r.AddAttrs(slog.String("request_id", reqID))
    }
    return h.inner.Handle(ctx, r)
}
```

In **TypeScript**, use `AsyncLocalStorage` with pino's `mixin` function — this automatically injects request-scoped context into every log line without parameter drilling:

```typescript
const als = new AsyncLocalStorage<{ requestId: string; traceId?: string }>();
const logger = pino({
  mixin() {
    const ctx = als.getStore();
    return ctx ? { request_id: ctx.requestId, trace_id: ctx.traceId } : {};
  },
});
// Express middleware: wrap each request in AsyncLocalStorage
app.use((req, res, next) => {
  als.run({ requestId: req.headers['x-request-id'] || uuidv4() }, () => next());
});
```

---

## 3. Log levels are operational contracts, not decoration

Treat log levels as SLA commitments. **ERROR means "wake someone up."** WARN means "investigate next business day." INFO means "audit trail for post-hoc debugging." DEBUG means "never on in production unless explicitly enabled per-request."

The most common mistake is over-logging at ERROR level. A retry that succeeds is a WARN, not an ERROR. A user entering an invalid password is INFO (business event), not ERROR. A downstream service returning a 4xx is WARN (their problem, but worth noting). Reserve ERROR strictly for conditions where something is broken and needs immediate human attention.

### Enforce discipline through tooling

**Go: `sloglint`** (via golangci-lint) enforces consistent slog usage — requiring `snake_case` keys, forbidding bare `slog.Info()` global calls (inject loggers instead), requiring context-aware methods (`InfoContext`), and mandating string-literal messages:

```yaml
# .golangci.yml
linters-settings:
  sloglint:
    attr-only: true        # Enforce slog.String(), slog.Int() attributes
    no-global: "all"       # Forbid slog.Info() — inject loggers
    context-only: "scope"  # Require InfoContext() when context available
    static-msg: true       # Messages must be string literals
    key-naming-case: "snake"
```

**TypeScript: ESLint `no-console`** blocks direct console usage, forcing all logging through your structured logger:

```javascript
// eslint.config.js
{ rules: { "no-console": "error" } }
```

### Dynamic log level control without restart

This is essential for production debugging. All three Go libraries support it:

**zap's `AtomicLevel`** is the gold standard — it natively implements `http.Handler`, giving you a GET/PUT HTTP endpoint for free:

```go
atom := zap.NewAtomicLevelAt(zap.InfoLevel)
mux.Handle("/log/level", atom)
// curl -X PUT -d '{"level":"debug"}' localhost:8080/log/level
```

**slog's `LevelVar`** provides atomic, concurrent-safe level changes:

```go
var programLevel = new(slog.LevelVar) // defaults to INFO
h := slog.NewJSONHandler(os.Stderr, &slog.HandlerOptions{Level: programLevel})
programLevel.Set(slog.LevelDebug) // atomic, immediate effect
```

**pino** (TypeScript) supports runtime level changes with a simple assignment: `logger.level = 'debug'`. For per-request overrides, create child loggers in `AsyncLocalStorage` with the level set based on an `X-Debug-Level` header — enabling you to debug a single user's requests in production without affecting other traffic.

---

## 4. Sampling keeps costs sane without sacrificing debuggability

At high throughput, logging every successful request is wasteful. A service handling **10,000 req/s** generating 1 KB per log produces **864 GB/day** — that's $432/day on Grafana Cloud Loki, or $13,000/month. Sampling at 10% cuts this to $1,300/month while retaining statistical significance for dashboards and enough data for debugging.

### What to never sample

- **Errors and warnings** — every error matters; you cannot debug from a sampled subset
- **Security events** — authentication failures, permission denials, suspicious activity
- **Business-critical events** — payments, order completions, user signups
- **Deployment/lifecycle events** — startup, shutdown, configuration changes

### What to sample aggressively

- **Health check logs** (`/health`, `/ready`) — extremely high volume, near-zero signal. Drop 100% or sample at 1%
- **Successful request logs** on high-QPS endpoints — sample at 1–10%
- **Debug-level logs** if temporarily enabled — sample at 1%
- **Cache hit/miss logs** — high volume, better captured as metrics

### Head-based versus tail-based sampling

**Head-based sampling** decides at log emission time using rate limits or probability. It's simple and low-overhead but may drop interesting events. **Tail-based sampling** buffers logs until the request completes, then decides based on outcome (error? slow?). It keeps all logs from interesting traces but requires buffering infrastructure (OTel Collector's `tail_sampling` processor).

**Recommendation:** Use head-based sampling in the application for volume control, and tail-based sampling in the telemetry pipeline for intelligent trace-level decisions. If a trace is sampled in, keep all its logs; if sampled out, drop them all to maintain coherence.

### Go: zap's built-in SamplingConfig

```go
cfg.Sampling = &zap.SamplingConfig{
    Initial:    100,  // Log first 100 per second with same level+message
    Thereafter: 10,   // Then every 10th
}
```

For smarter sampling that never drops errors, wrap two cores — an unsampled `WarnLevel+` core and a sampled `DebugLevel+` core:

```go
unsampledCore := zapcore.NewCore(encoder, writer, zap.WarnLevel)
sampledCore := zapcore.NewSamplerWithOptions(
    zapcore.NewCore(encoder, writer, zap.DebugLevel),
    time.Second, 10, 5,  // first 10, then every 5th per second
)
logger := zap.New(&NeverSampleErrorsCore{sampled: sampledCore, unsampled: unsampledCore})
```

### TypeScript: custom pino sampling

Pino lacks built-in sampling but supports hooks for custom logic:

```typescript
const logger = pino({
  hooks: {
    logMethod(inputArgs, method, level) {
      if (level >= 50) return method.apply(this, inputArgs); // Never sample errors
      const msg = typeof inputArgs[inputArgs.length - 1] === 'string' ? inputArgs[inputArgs.length - 1] : '';
      if (sampler.shouldLog(`${level}:${msg}`)) return method.apply(this, inputArgs);
    },
  },
});
```

For health checks, pino-http's `autoLogging.ignore` drops them entirely:

```typescript
pinoHttp({ autoLogging: { ignore: (req) => req.url === '/health' } });
```

---

## 5. PII in logs is a ticking compliance bomb

A single unmasked credit card number in your logs violates PCI-DSS. An email address in a log shipped to a third-party SaaS vendor is a GDPR data transfer. **IP addresses are personal data under GDPR** (Breyer v. Germany, CJEU). The safest approach: **mask at the source, not in storage**.

### Detection patterns for common PII

| Data type | Detection approach |
|-----------|-------------------|
| Email | `\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b` |
| Credit card | `\b(?:\d[ -]*?){13,16}\b` (with Luhn validation) |
| JWT | `\beyJ[A-Za-z0-9-_]+\.eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_.+/]*\b` |
| AWS key | `(?:AKIA\|ABIA\|ACCA\|ASIA)[0-9A-Z]{16}` |
| SSN | `\b\d{3}-\d{2}-\d{4}\b` |

### GDPR right-to-erasure and logs

Logs are append-only, compressed, and distributed across systems — making deletion nearly impossible. The UK ICO accepts that backup data can remain if put "beyond use" (guaranteed not used for any purpose, deleted when overwritten on schedule). A regulator recommended a **€160,674 fine** for failure to demonstrate effective deletion from backups. The best practice is prevention: never log PII, or pseudonymize it at the source so erasure requests don't need to touch log stores.

### Go: cockroachdb/redact

CockroachDB's `redact` library (Apache-2.0, production-proven) uses safe/unsafe markers:

```go
redactable := redact.Sprintf("user email: %s", userEmail)
logger.Info(redactable.Redact()) // "user email: ‹×›"
```

### TypeScript: pino's built-in redact

Pino's `redact` option (powered by `fast-redact`) supports path-based redaction with ~2% overhead:

```typescript
const logger = pino({
  redact: {
    paths: ['password', 'user.email', 'headers.authorization', 'payment.card.number'],
    censor: '[REDACTED]',
  },
});
```

For content-based detection (scanning log message bodies for PII patterns), use `@agiledigital/pino-redact-pii` which wraps regex-based detection into pino formatters. For secret scanning in log streams, **TruffleHog** classifies 800+ secret types with live credential verification (actually confirming if leaked secrets are still active). It can scan syslogs directly with `trufflehog syslog`.

---

## 6. Pipeline filtering is the highest-ROI cost optimization

**Combined pipeline filtering typically reduces log volume by 50–80%.** At 1 TB/day on Grafana Cloud Loki ($15,000/month), a 60% reduction saves $9,000/month — $108,000/year. The tools to do this are Vector, Fluent Bit, Grafana Alloy, and the OpenTelemetry Collector.

### The dual-shipping architecture

The most cost-effective pattern sends **all logs** (after PII redaction) to cheap object storage (S3 at $0.023/GB/month) and **filtered, sampled logs** to your analytics platform. Query S3 with Athena when you need the full dataset.

```
App → Collector (Vector/OTel) → PII Redaction
                                     ↓
                    ┌────────────────┴────────────────┐
                    │                                  │
             S3 Archive                         Loki/Datadog
             ALL logs, gzipped                  Filtered + sampled
             ~$0.02/GB/mo                       ~$0.50-$1.70/GB/mo
             Query via Athena                   Interactive queries
```

### Pipeline processor comparison

**Vector** (Rust, by Datadog) is the most capable — its VRL (Vector Remap Language) supports filtering, field dropping, sampling, redaction, and routing in a single pipeline. Performance is ~10× faster than Logstash. **Fluent Bit** (C) has the smallest memory footprint (~450 bytes) and is ideal for sidecar/DaemonSet deployments. **Grafana Alloy** integrates tightly with the Grafana ecosystem. **OTel Collector** is the standards-based choice with growing processor support.

### Vector configuration: drop, sample, redact, dual-ship

```yaml
transforms:
  filter_health_checks:
    type: filter
    inputs: ["parse"]
    condition: |
      !includes(to_string(.message) ?? "", "/health") &&
      .kubernetes.container_name != "istio-proxy"

  sample_debug:
    type: sample
    inputs: ["filter_health_checks"]
    rate: 10                          # Keep 10% of debug logs
    condition: '.level == "debug"'

  drop_fields:
    type: remap
    inputs: ["sample_debug"]
    source: |
      del(.kubernetes.pod_id)
      del(.kubernetes.docker_id)
      del(.request_body)
      del(.response_body)

sinks:
  loki:
    inputs: ["drop_fields"]           # Filtered stream
    type: loki
    endpoint: "http://loki:3100"
  s3_archive:
    inputs: ["redact_pii"]            # Full stream (before volume filtering)
    type: aws_s3
    bucket: "log-archive"
    compression: gzip
```

### Typical savings by optimization

| Optimization | Volume reduction |
|-------------|-----------------|
| Drop health check logs | 15–30% |
| Drop/sample debug logs | 20–40% |
| Drop verbose Kubernetes metadata | 10–30% |
| Deduplication of repeated errors | 5–15% |
| **Combined pipeline** | **50–80%** |

Real-world examples confirm these numbers. Organizations report observability spending at **10–25% of infrastructure budget**; OpenAI reportedly spends $170M/year on Datadog. After pipeline optimization, one SaaS company reduced log ingestion by 45%, metric cardinality by 60%, and trace storage by 70%.

---

## 7. Log-based alerting converts noise into signal

The best alerts are derived from log patterns, not raw log volume. Each platform offers different mechanisms for turning logs into actionable alerts.

### LogQL metric queries (Loki)

Loki's LogQL supports Prometheus-style metric queries that power alerting rules:

```yaml
groups:
  - name: production_alerts
    rules:
      - alert: HighErrorRate
        expr: |
          ( sum(rate({namespace="production"} |= "error" [5m]))
          / sum(rate({namespace="production"} [5m])) ) > 0.05
        for: 5m
        labels: { severity: critical }
        annotations:
          runbook_url: "https://runbooks.example.com/high-error-rate"

      - alert: ServiceNotLogging
        expr: absent_over_time({app="payment-service"}[10m])
        for: 5m
        labels: { severity: critical }
```

Key LogQL functions: `rate()` for logs-per-second, `count_over_time()` for totals, `absent_over_time()` to detect services that stopped logging (potential crash), and `quantile_over_time()` for percentile extraction from numeric log fields.

### Datadog log-based metrics and CloudWatch metric filters

Datadog generates custom metrics from log patterns: define a search query, choose count or distribution aggregation, group by tags. The resulting metric is stored for **15 months** and monitored with standard Datadog monitors. Billing is as custom metrics — avoid grouping by high-cardinality attributes.

CloudWatch metric filters use pattern syntax (`{ $.level = "ERROR" }`) to emit CloudWatch metrics from log groups, which then power CloudWatch Alarms. Limitations: no regex support (use Logs Insights for that), max event size 256 KB.

### Reducing alert fatigue

- **Use `for` clauses**: Require 5 minutes of sustained breach before alerting, preventing single-spike false positives
- **Prefer rate over count**: "Error rate >5% for 5 minutes" is more meaningful than "10 errors occurred"
- **Severity-based routing**: Critical → PagerDuty page; Warning → Slack channel; Info → dashboard only
- **Inhibition rules**: Suppress symptom alerts when the root cause alert is already firing (e.g., suppress `ServiceHighLatency` when `DatabaseDown` is active)
- **Every alert must link to a runbook** describing what it means, likely causes, and remediation steps

### Anomaly detection

**Datadog Watchdog** automatically detects new log text patterns and volume anomalies without configuration. **Elastic ML** creates anomaly scores (0–100) by analyzing log rate distributions across partitions. For a lighter-weight approach, track rolling mean and standard deviation of error counts and alert when the current value exceeds mean + N×σ.

---

## 8. Retention strategy balances compliance with cost

### Compliance-driven minimums

| Framework | Required retention | Key detail |
|-----------|-------------------|------------|
| **SOC 2 Type II** | ~12 months | Industry standard for demonstrating control effectiveness |
| **PCI-DSS 4.0** | 12 months (3 months hot) | Requirement 10.5.1: 3 months immediately accessible for analysis |
| **HIPAA** | **6 years** | Audit logs tracking ePHI access (45 CFR 164.316(b)(2)(i)) |
| **SOX** | 7 years | Financial audit records |
| **GDPR** | No fixed period | Data minimization: retain only as long as necessary |

### Tiered retention per environment

| Environment | Hot retention | Archive | Rationale |
|-------------|-------------|---------|-----------|
| Production | 30 days (90 for critical services) | 1–6 years per compliance | Active debugging + audit |
| Staging | 7 days | None | Short-lived debugging |
| Development | 1–3 days | None | Minimal value after use |

### Cold storage is essentially free

Archive storage pricing makes long-term compliance retention trivial:

| Tier | $/TB/month |
|------|-----------|
| S3 Standard | $23.55 |
| S3 Glacier Instant Retrieval | $4.10 |
| S3 Glacier Flexible Retrieval | $3.69 |
| **S3 Glacier Deep Archive** | **$1.01** |
| **GCS Archive** | **$2.56** |

For HIPAA compliance at 1 TB/day (assuming 5× compression in archives), 6 years of accumulated compressed data (~14.4 TB) costs only **~$14/month** on S3 Glacier Deep Archive. Even at 10 TB/day, archive storage runs ~$142/month. The expensive part is never the archive — it's the hot tier.

### Platform lifecycle policies

**Elasticsearch ILM** automates rollover → warm (HDD) → cold (searchable snapshots) → frozen (S3, search on demand) → delete. **Loki** supports per-stream retention via `retention_stream` selectors — payment-service logs can retain 90 days while dev namespace logs retain 24 hours. **Datadog** archives to S3/GCS (included with $0.10/GB ingestion) and rehydrates on demand at $0.10/GB scanned. **CloudWatch** sets retention per log group (1 day to 10 years) and exports to S3 via subscription filters for archival.

---

## 9. Distributed correlation assembles the full request picture

When a single user request flows through 5+ microservices, you need a correlation mechanism that ties all logs together. The **W3C Trace Context** standard provides this through the `traceparent` header.

### The traceparent header

```
traceparent: 00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01
             ^^  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  ^^^^^^^^^^^^^^^^  ^^
          version    trace-id (32 hex, 128-bit)     span-id (16 hex)  flags
```

OpenTelemetry uses W3C Trace Context as its default propagation format. The `tracestate` companion header carries vendor-specific data. **OTel Baggage** propagates arbitrary key-value context (tenant_id, feature flags) across service boundaries via HTTP headers — but unlike span attributes, baggage is not stored by backends; it's purely a runtime propagation mechanism.

### Propagation across transport protocols

Context propagates through **HTTP headers** (`traceparent`, `tracestate`, `baggage`, `X-Request-ID`), **gRPC metadata** (same headers via HTTP/2), and **Kafka message headers** (injected at producer, extracted at consumer). OTel SDKs handle injection/extraction automatically via interceptors and middleware.

### Go: context.Context is the backbone

```go
// Setup global propagator
otel.SetTextMapPropagator(propagation.NewCompositeTextMapPropagator(
    propagation.TraceContext{}, propagation.Baggage{},
))

// Middleware extracts trace context from incoming headers
func traceMiddleware(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        ctx := otel.GetTextMapPropagator().Extract(r.Context(), propagation.HeaderCarrier(r.Header))
        ctx, span := otel.Tracer("my-service").Start(ctx, r.URL.Path)
        defer span.End()
        next.ServeHTTP(w, r.WithContext(ctx))
    })
}
```

Critical rule: **always pass `ctx` explicitly to goroutines**. Using `context.Background()` in a goroutine breaks trace continuity.

### TypeScript: AsyncLocalStorage propagates without parameter drilling

```typescript
import { AsyncLocalStorage } from 'node:async_hooks';
const als = new AsyncLocalStorage<Map<string, string>>();

app.use((req, res, next) => {
  const store = new Map<string, string>();
  store.set('requestId', req.headers['x-request-id'] || uuidv4());
  const span = trace.getActiveSpan();
  if (span) {
    store.set('traceId', span.spanContext().traceId);
    store.set('spanId', span.spanContext().spanId);
  }
  als.run(store, () => next());
});
```

AsyncLocalStorage propagates across all async operations (Promises, setTimeout) without explicit context passing. Node.js 24+ uses `AsyncContextFrame` by default for improved performance.

### Cross-service log queries by trace_id

- **Loki**: `{namespace="production"} | json | trace_id = "5b8efff..."` — configure derived fields to auto-link to Tempo/Jaeger
- **Elasticsearch**: `trace_id: "5b8efff..."` in KQL, sorted by `@timestamp asc`
- **Datadog**: `@trace_id:5b8efff...` — Datadog auto-injects `dd.trace_id` when `DD_LOGS_INJECTION=true`

---

## 10. Application-level patterns that prevent production pain

### Never log in hot loops

Logging inside a tight loop can cause **33–66× slowdowns** due to I/O, serialization, lock contention, and buffer flushing. Instead, aggregate counters and log a summary:

```go
// BAD: logging in loop
for _, item := range items {
    slog.Info("processed item", "id", item.ID) // DON'T
}

// GOOD: log summary after loop
var processed, failed int
for _, item := range items {
    if err := processItem(item); err != nil { failed++; continue }
    processed++
}
slog.Info("batch complete", "total", len(items), "processed", processed, "failed", failed)
```

### Log at boundaries, not everywhere

Log at **request start/end** (method, path, status, duration), **external call start/end** (URL, status, duration), and **operation start/end** (job type, items processed). This gives you timing data and a clear trace of what happened without interior noise.

### Structured error logging requires more than error.message

A bare error message lacks stack trace, error classification, and surrounding context. Include `error.type` (class name), `error.stack`, `error.code` (application-specific), the `operation` being attempted, and relevant IDs:

```go
slog.Error("operation failed",
    "error", err.Error(),
    "error_type", fmt.Sprintf("%T", err),
    slog.Group("context", "user_id", userID, "operation", "createOrder"),
)
```

### Request/response logging safety

**Safe to log**: Content-Type, Accept, User-Agent, X-Request-ID. **Never log**: Authorization, Cookie, Set-Cookie, X-API-Key. Log request/response bodies only for small payloads (<1 KB) during error conditions — never for file uploads, large responses, or anything containing PII.

### Platform log entry size limits

| Platform | Max log entry | Action on exceed |
|----------|--------------|-----------------|
| Grafana Loki | **256 KB** (configurable) | Reject or truncate (`max_line_size_truncate: true`) |
| CloudWatch | **256 KB** | Silently dropped |
| Datadog | **1 MB** | Truncated |
| Elasticsearch | Configurable (~100 KB recommended) | Performance degradation |

Target **1–10 KB** per log entry. Stack traces can push to 10–50 KB — truncate at ~10 KB or offload to a dedicated error tracking service.

### Avoid computing disabled log arguments

In Go, function arguments are evaluated before the function call. `slog.Debug("msg", "key", expensiveFunc())` calls `expensiveFunc()` even if debug is disabled. The only way to avoid this is an explicit check:

```go
if slog.Default().Enabled(ctx, slog.LevelDebug) {
    slog.Debug("details", "data", computeExpensiveString())
}
// zap equivalent:
if ce := logger.Check(zap.DebugLevel, "details"); ce != nil {
    ce.Write(zap.String("data", computeExpensiveString()))
}
```

In pino (TypeScript), `logger.debug()` returns immediately without serializing the object argument when debug is disabled — but `computeExpensive()` is still called (JS evaluates args). Use `logger.isLevelEnabled('debug')` to guard expensive computations.

For maximum slog performance, use `LogAttrs` which avoids the allocation from `any` interface boxing:

```go
slog.LogAttrs(ctx, slog.LevelInfo, "request processed",
    slog.String("method", r.Method),
    slog.Int("status", statusCode),
    slog.Duration("duration", elapsed),
)
```

---

## Conclusion: the cost-effective logging stack for 2025

The optimal logging infrastructure for Go and TypeScript services at scale combines several key decisions. **Choose Grafana Loki or Elastic Cloud Serverless** as your primary log store — they offer the best price-to-capability ratio. **Use the dual-shipping pattern**: all logs to S3 (after PII redaction), filtered logs to your analytics platform. **Deploy Vector or Fluent Bit** as your pipeline processor to drop health checks, sample verbose logs, strip unnecessary fields, and redact PII before ingestion — this alone saves 50–80% on log costs.

Standardize on **slog** (Go) and **pino** (TypeScript) with automatic context enrichment via `context.Context` and `AsyncLocalStorage`. Enforce structured logging discipline through `sloglint` and ESLint rules. Wire up dynamic log level control from day one — zap's `AtomicLevel` or slog's `LevelVar` in Go, `logger.level` assignment in pino. Implement per-request debug level overrides to diagnose production issues without redeployment.

Never sample errors. Sample everything else aggressively. Mask PII at the source, not in storage. Set tiered retention (30 days hot, years in Glacier at ~$1/TB/month). Derive alerting metrics from LogQL or platform-native metric queries, and ensure every alert links to a runbook. The most important operational insight: **your logging costs should not exceed 5% of your compute costs**. If they do, your pipeline is missing filters.