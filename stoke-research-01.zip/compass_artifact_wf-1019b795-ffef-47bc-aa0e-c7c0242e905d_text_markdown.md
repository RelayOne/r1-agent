# Production patterns for real-time systems at scale

**A Go WebSocket server on Linux can sustain 50K–100K connections with standard goroutine-per-connection patterns, or 1M+ connections using epoll-based approaches like gobwas/ws — but connection count is just the beginning.** Building production real-time features demands answers to authentication, presence, ordering guarantees, mobile lifecycle, collaboration conflict resolution, and operational testing. This guide covers all ten domains with concrete numbers drawn from Discord, Slack, Figma, and Cloudflare's own architecture, optimized for a Cloudflare Durable Objects + Go WebSocket stack.

---

## 1. WebSocket scaling: from 10K to 3 million connections

### Memory and connection budgets

Every WebSocket connection in Go's standard goroutine model consumes **~20–50 KB**: two goroutine stacks (2–8 KB each), 4 KB read buffer, 4 KB write buffer, net/http hijack buffers (8 KB), plus TCP kernel buffers (4–16 KB). At 10K connections with gorilla/websocket, benchmarks show **~267 MB RSS** and ~313% CPU with 1 KB messages at 10 msg/s. The nhooyr.io/websocket library uses ~373 MB under the same load due to context.Context overhead. The gobwas/ws epoll approach drops this to **~91 MB** for the same 10K connections.

Mail.Ru's Sergey Kamardin demonstrated **3 million concurrent WebSocket connections** on a single Go server using gobwas/ws with a custom epoll poller and goroutine pool of just 128 workers. The technique eliminates per-connection goroutines entirely: connections register with epoll, buffers are allocated from `sync.Pool` only when data arrives, and a fixed-size goroutine pool processes readable connections. This reduced memory from a theoretical **~72 GB** (naive approach at 3M connections) to **~2–4 GB** — a 97% reduction. For most production systems, target **50K–100K connections per server** with standard gorilla/websocket on 16 GB RAM, or **500K–1M+** with the epoll-based approach.

### Linux tuning essentials

The default per-process file descriptor limit of **1,024** is comically low for a WebSocket server. Production configuration requires:

```bash
# /etc/security/limits.conf
*    soft    nofile    1000000
*    hard    nofile    1000000

# /etc/sysctl.conf
fs.file-max = 12000500
net.ipv4.ip_local_port_range = 1024 65535
net.core.somaxconn = 65535
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_rmem = 1024 4096 16384    # Reduce per-socket buffers
net.ipv4.tcp_wmem = 1024 4096 16384
net.ipv4.tcp_keepalive_time = 60
net.core.netdev_max_backlog = 5000
```

Reducing TCP buffer sizes to 1–4 KB per socket saves gigabytes at scale — most WebSocket messages are small. For systemd services, set `LimitNOFILE=1000000` in the unit file since `ulimit -n` changes are session-only.

### Load balancing and connection draining

NGINX requires explicit WebSocket support: set `proxy_http_version 1.1`, add `Upgrade` and `Connection` headers, and critically set `proxy_read_timeout 86400s` (the default 60 seconds kills idle connections). HAProxy needs `timeout tunnel 24h` for the same reason. Slack migrated millions of concurrent WebSocket connections from HAProxy to **Envoy** for its dynamic cluster configuration, hot restart without dropping connections, and zone-aware routing.

For sticky sessions, **IP hash is unreliable** — corporate NATs route thousands of users through one IP. Cookie-based or session-ID-based stickiness is preferred. Consistent hashing (`hash-type consistent` in HAProxy) ensures adding a server redistributes only 1/N connections instead of all of them.

Connection draining in Go requires manual tracking because `http.Server.Shutdown()` does not track hijacked connections. The pattern: maintain a `sync.Map` of active connections, send `CloseGoingAway` (code 1001) on SIGTERM, wait up to 30 seconds for drain, then force-close remaining connections. In Kubernetes, add a `preStop` hook with 5–10s sleep to let the load balancer deregister the pod before draining begins.

---

## 2. WebSocket lifecycle: auth, heartbeats, and reconnection

### Authentication during the handshake

The browser WebSocket API does not allow setting custom HTTP headers, forcing three creative patterns:

**Query parameter token** (`wss://host/ws?token=jwt`) is simplest and rejects before upgrade with a proper HTTP 401, but tokens leak into server logs, proxy logs, browser history, and Referer headers. Mitigate with short-lived single-use tokens (valid 30 seconds, generated via REST endpoint).

**First-message authentication** (send `{"type":"auth","token":"jwt"}` after connection opens) keeps tokens out of URLs entirely but establishes the connection before auth — vulnerable to DoS from unauthenticated connections. Enforce a **10-second auth timeout** and per-IP connection limits.

**Sec-WebSocket-Protocol header** (pass the token as a subprotocol string) keeps the token in headers and rejects before upgrade. The server must echo back one of the requested protocols or Chrome rejects the connection. Kubernetes and Jupyter use this approach in production.

### Heartbeat tuning

The optimal ping interval is **25–30 seconds** with a **10-second pong timeout**. These numbers derive from infrastructure defaults: AWS ALB idle timeout is 60s, nginx `proxy_read_timeout` is 60s, cellular NAT gateways close at 30–120s. Pinging at 25s ensures activity within every 60-second window. In Go with gorilla/websocket, set a `PongHandler` that extends the read deadline on each pong, and use a ticker in the write goroutine to send protocol-level pings. Zombie connections — where TCP dies silently without FIN/RST, common on mobile network switches — are detected by the missing pong triggering the read deadline.

### Reconnection with state reconciliation

Every message should carry a monotonically increasing sequence number or event ID per channel. On reconnect, the client sends its `lastEventId` in the query parameter or first message. The server maintains a bounded event buffer (last 1,000 events per channel in Redis with TTL), replays missed events, then resumes normal delivery. If the gap exceeds the buffer, send a full state snapshot instead of replaying.

Exponential backoff with jitter is non-negotiable: start at 500ms, double each attempt, cap at 30 seconds, add 20–50% random jitter to each delay, and stop after 10–15 attempts (~2 minutes). Without jitter, a server restart creates synchronized retry waves from thousands of clients that can DDoS the recovering server.

For **mid-connection token expiration**, the server sends `{"type":"token_expiring","expires_in":60}` before the token expires. The client obtains a fresh token via REST API and sends `{"type":"token_refresh","new_token":"xxx"}`. If no refresh arrives by expiry, close with a custom code (4001). Set token TTL longer than the maximum reconnection window.

---

## 3. When SSE beats WebSocket — and when it doesn't

**Default to SSE when data flows server-to-client only.** SSE provides automatic browser reconnection, built-in message replay via `Last-Event-ID`, and works through any HTTP infrastructure without special configuration. This covers live feeds, stock tickers, AI token streaming, dashboards, and notification systems. The practical heuristic widely cited in the industry: "Default to SSE, upgrade to WebSocket only when you need frequent client-to-server real-time communication."

The critical SSE limitation under HTTP/1.1 is the **6-connection-per-domain limit** (per browser, across all tabs). Since SSE responses never complete, 6 SSE connections block all other HTTP requests to that domain — images, API calls, everything queues. **HTTP/2 solves this entirely**: SSE streams become logical streams multiplexed over a single TCP connection, with a default limit of **100 concurrent streams**. This makes the connection limit practically irrelevant.

SSE's biggest production pitfall is **silent proxy buffering**. Corporate proxies, firewalls, and some CDNs buffer SSE streams, causing events to arrive in batches instead of real-time. The fix is setting `X-Accel-Buffering: no` for nginx and sending keepalive comments (`: heartbeat\n\n`) every 15–30 seconds, but you cannot fix intermediaries you don't control. WebSocket avoids this because proxies either pass WebSocket through or block it entirely — no silent buffering.

In Go, SSE implementation requires the `http.Flusher` interface. Call `Flush()` after writing each event to push data immediately. Set `Content-Type: text/event-stream`, `Cache-Control: no-cache`, and disable timeouts for the SSE handler.

Choose **WebSocket over SSE** when: bidirectional real-time communication is needed (chat, collaborative editing), the client sends data frequently, sub-100ms latency matters, or binary data must be transmitted efficiently (SSE is text-only; base64 adds 33% overhead).

---

## 4. Presence at scale: how Discord and Slack solved "who's online"

### Heartbeat-driven presence

Production presence systems use a hybrid of persistent WebSocket connections and periodic heartbeats. The connection provides instant detection for clean disconnects; heartbeats detect silent failures (NAT drops, network partitions). The standard pattern uses **Redis sorted sets** with timestamps: `ZADD user_heartbeats <timestamp> <user_id>` on each heartbeat. A periodic sweep via `ZRANGEBYSCORE` finds users whose last heartbeat exceeds the timeout threshold. For 1 million users, basic presence data in Redis consumes **~100–200 MB** (100–200 bytes per user for ID, status, and timestamps).

### Discord's Manifold architecture

Discord scaled to **5M+ concurrent users** on Elixir/BEAM. Each guild (server) is a single GenServer process. When a guild like r/Overwatch reached 30,000 concurrent users, publishing a single message required 30K `send/2` calls at 30–70μs each — taking **900ms–2.1s wall clock time**. Their solution, the **Manifold library**, groups subscriber PIDs by remote Erlang node and sends one message per node to a `Manifold.Partitioner`, which consistently hashes PIDs across CPU cores for local delivery. This reduced per-node fan-out to O(1) network messages.

### Slack's selective subscription model

Slack runs dedicated in-memory **Presence Servers** (Java), with users hashed to individual PS instances. The critical optimization: clients receive presence updates **only for users visible on their screen**, not all workspace members. This selective subscription model replaced an earlier broadcast-all approach that couldn't scale. At peak, Slack handles **5M+ simultaneous WebSocket sessions** with messages delivered globally in 500ms.

### Phoenix Presence and CRDTs

Phoenix's approach is notable for having **no single point of failure and no external dependencies**. It uses an Observed-Remove Set (ORSet) CRDT variant. Each node maintains local presence state; delta broadcasts propagate changes every **1.5 seconds** (configurable `broadcast_period`). Nodes merge received deltas using CRDT semantics. After 10 missed heartbeats (15 seconds), a node is suspected down; after 20 minutes (`permdown_period`), its state is discarded. This self-heals from network partitions without Redis.

### Optimizing presence fan-out

- **Selective subscription** (Slack): only push updates for users visible on screen
- **Manifold pattern** (Discord): group by node, send one message per node
- **Jittered heartbeat refresh**: randomize refresh timing between 75–100% of TTL to prevent synchronized heartbeat storms
- **Delta compression**: send only joins/leaves, not full presence lists
- **Batching**: collect presence changes over a short window, send as a single batch

---

## 5. Collaborative editing: CRDTs won, but the details matter

### Yjs dominates the CRDT landscape

**Yjs processes 260K keystrokes in ~56ms** versus Automerge 2.0's ~600ms and the original Automerge's ~5 minutes. Diamond Types (by Joseph Gentle, creator of ShareDB) achieves ~11ms in Rust but only supports plain text. Yjs uses the YATA algorithm with lamport timestamps, state vectors for sync, and struct merging to minimize metadata. Its JavaScript bundle is ~70 KB versus Automerge's ~120 KB (WASM). At **900K+ weekly npm downloads**, Yjs is used by Proton Docs, Evernote, ClickUp, and Shopify.

The stored document overhead for CRDTs is **1.5–3x raw content size** for Yjs due to tombstones (deleted characters retain ordering metadata). Automerge retains full history for version-control-like reconstruction, adding more overhead but enabling time-travel debugging.

### How Figma, Linear, and Notion actually work

**Figma** uses CRDT-inspired but centralized conflict resolution. Each document is a tree of objects with properties. Same property on the same object uses **last-write-wins** (the last value to reach the server wins). Different properties never conflict. A dedicated Rust "multiplayer" process per document handles all connected clients over WebSocket. State is held in memory, checkpointed every 30–60 seconds, with a DynamoDB write-ahead journal for durability. Updates flow at **33ms intervals** (30 FPS). For code layers, Figma adopted the **Eg-walker** algorithm — a hybrid that builds a temporary internal CRDT during conflict resolution then discards it, achieving CRDT merge quality with OT-like memory efficiency.

**Linear** is local-first: all data lives in browser IndexedDB, pushed via WebSocket. LWW handles most fields (status, assignee, labels). CRDTs are used **only for issue descriptions** (rich text editing). As co-founder Tuomas Artman noted: "conflicts are actually not that common in Linear."

**Notion** uses LWW with server authority. Engineer Jake Lazaroff confirmed: "We don't use a CRDT for text, it's all last-write-wins decided by the server." LWW texts are individually small — one block/paragraph — and block-level operations (add, move, remove) are intention-preserving.

### Awareness protocol and cursor broadcasting

Yjs's awareness protocol is separate from the document CRDT and ephemeral — not persisted. Each client sets local state (cursor position using `Y.RelativePosition`, selection, username, color), and remote states are stored in a `Map<clientID, state>`. **Throttle cursor updates to 50–100ms** intervals for responsive feel without excessive bandwidth. Yjs uses relative positions that remain valid as the document changes, referencing a specific struct ID + offset rather than an absolute index.

### Undo in collaborative contexts

Yjs's `UndoManager` implements **local undo** — each user undoes only their own changes via `trackedOrigins`. Edits within 500ms (`captureTimeout`) merge into a single undo step. Meta-information on stack items allows saving/restoring cursor positions on undo/redo. Global undo (all users share one stack) is almost never desirable in collaborative editors.

---

## 6. Room architecture and fan-out to 10K+ subscribers

### Two-tier fan-out is the industry standard

Slack's architecture exemplifies the pattern: the client sends a message to a Gateway Server via WebSocket, which routes to the appropriate **Channel Server** via consistent hash ring. The Channel Server broadcasts to all Gateway Servers subscribed to that channel. Each Gateway Server fans out to its locally connected clients. This means a single message to 10K subscribers crosses the network only once per server, not once per subscriber. Slack runs **~16 million channels per Channel Server host** at peak.

Discord's Manifold pattern applies the same principle: group subscribers by node, send one message per node, then distribute locally across CPU cores. Socket.IO's Redis Adapter follows an identical model — local fan-out + Redis Pub/Sub for cross-server broadcast. The **Sharded Adapter** (Redis 7.0+) distributes pub/sub traffic across Redis cluster nodes instead of funneling through a single node.

### Room membership and lifecycle

Socket.IO tracks membership with two maps: `sids: Map<SocketId, Set<Room>>` and `rooms: Map<Room, Set<SocketId>>`. Rooms are ephemeral by default — created when the first socket joins, destroyed when the last leaves. For persistent rooms (Slack-style), channel history is held in memory backed by database persistence.

Ably imposes concrete limits: **200 messages/second recommended maximum per channel** and a max message payload of 64 KB (2 MB hard limit). Channel creation is rate-limited to hundreds per second. Their consistent hashing uses **progressive hashing** — new servers gradually acquire load rather than triggering instant redistribution, preventing thundering herd during scaling events.

For large rooms exceeding 10K subscribers, partition by subscriber into sub-channels (`room:123:shard-0`, `room:123:shard-1`) with the publisher sending to all shards. Alternatively, use Twitter's fan-out-on-read model: small rooms push immediately, celebrity/massive rooms have subscribers pull on demand.

---

## 7. Message ordering: sequence numbers, deduplication, and exactly-once delivery

### In-order delivery per channel

Assign each message a **strictly monotonically increasing sequence number** per channel. The client tracks `lastReceivedSeq` and implements a reordering buffer: if `msg.seq == lastReceivedSeq + 1`, process normally; if greater, buffer the message and start a **500ms gap timer**; if less or equal, discard as duplicate. When the gap timer fires, request retransmission of missing sequence numbers from the server's bounded message buffer. If the buffer doesn't contain the messages (TTL expired), trigger a full state sync.

### Delivery semantics in practice

**WebSocket provides no built-in delivery guarantees** — it's at-most-once by default. Building exactly-once over WebSocket requires: session tracking, sequence numbering, a server-side message buffer for replay, ACK/dedup logic, and idempotency keys for client→server messages. Most production systems settle for **at-least-once delivery with client-side deduplication** because true exactly-once is impossible in the general distributed case (Two Generals Problem).

**Kafka** guarantees strict ordering within a single partition via sequential offsets. Idempotent producers (default since Kafka 3.0) track `(ProducerID, sequence)` pairs per partition for dedup. Transactions enable atomic consume-process-produce cycles within a single cluster. **NATS JetStream** achieves effectively-once via message deduplication on publish (`Nats-Msg-Id` header) and double-ack on consume (`AckSync`). **Redis Streams** provides at-least-once with consumer groups + XACK, using the Pending Entries List (PEL) to track unacknowledged messages and `XCLAIM` for dead consumer recovery.

### Vector clocks and causal ordering

Vector clocks provide **causal ordering** (detect "happened-before" relationships) at O(N) space per message where N is the number of processes. For real-time systems with many clients, this doesn't scale. Alternatives include **Hybrid Logical Clocks** (combine physical timestamps with logical counters, constant size) and **Bloom Clocks** (probabilistic, fixed space). In practice, most real-time chat/collaboration systems use server-assigned sequence numbers rather than vector clocks, since the server is already a coordination point.

---

## 8. Cloudflare Durable Objects: the hibernatable WebSocket API explained

### How hibernation works

The hibernatable WebSocket API (`ctx.acceptWebSocket()`) tells the Cloudflare runtime that a DO can be **evicted from memory** while its WebSocket connections remain open on the Cloudflare network. When a message arrives for a hibernated DO, the runtime re-creates the DO by calling its constructor, then delivers the message to `webSocketMessage(ws, message)`. In-memory state is completely wiped during hibernation — only SQLite storage and `serializeAttachment` values (max 2,048 bytes per connection) persist.

The billing impact is dramatic. For **100 DOs with 50–100 WebSocket connections each** sending 1 message/minute for 8 hours/day: without hibernation costs **$138.65/month** (DOs pinned to memory the entire time); with hibernation costs **$10.00/month** (duration billed only when JavaScript executes). Protocol-level ping/pong and configured auto-responses (`ctx.setWebSocketAutoResponse`) are handled by the runtime **without waking the DO** — zero duration charges for keepalive.

### Single-point-of-coordination and SQLite

Each DO has a globally unique ID with **exactly one instance active worldwide at any time**. This eliminates distributed consensus for per-entity operations. SQLite runs in the **same thread** as DO compute — zero network hops, effectively zero-latency reads. Writes are synchronous from the application's perspective, with output gates ensuring no external party sees confirmation until writes are persisted to 3 of 5 follower machines. Storage limits are **10 GB per DO** (paid plan) with 2 MB max row size. Write coalescing automatically batches multiple writes without intervening `await` into a single atomic transaction.

### Connection limits and tradeoffs versus Go servers

DOs support a maximum of **32,768 WebSocket connections per instance** (hard limit). The 128 MB memory allocation per DO constrains working set size. Cold starts add **tens to hundreds of milliseconds** depending on constructor complexity. WebSocket messages are billed at a **20:1 ratio** (100 WebSocket messages = 5 billed requests) at $0.15 per million requests.

Choose DOs when rooms/entities are naturally isolated, traffic is bursty (hibernation saves money during inactivity), and you want zero-ops global distribution with built-in persistence. Choose a dedicated Go server when you need sub-millisecond guaranteed latency, sustained throughput exceeding 1,000 messages/second per room, fine-grained backpressure control, or working memory beyond 128 MB. The two architectures compose well: use DOs for room coordination and state persistence, with Go servers for high-throughput fan-out.

### Alarm API for periodic tasks

Each DO supports **one alarm at a time** via `ctx.storage.setAlarm(scheduledTime)`, with at-least-once execution guaranteed. On failure, retries use exponential backoff starting at 2 seconds, up to 6 retries. Alarms typically fire within milliseconds of the scheduled time but can delay up to a minute during maintenance. The room-cleanup pattern: set an alarm on the last activity, check `ctx.getWebSockets().length` when it fires, delete all storage if empty, or reschedule if connections remain. **Do not call `setAlarm` in the constructor** — this perpetually extends TTLs since the constructor runs on every hibernation wake-up.

---

## 9. Real-time on mobile: iOS kills your WebSocket in 5 seconds

### iOS and Android background behavior

When an iOS app moves to background, it gets approximately **5–10 seconds** of execution before suspension (extendable to ~30 seconds with `UIApplication.beginBackgroundTask`). WebSocket connections are killed upon suspension — no FIN, no RST, no error. The connection simply goes dormant. React Native confirmed: apps with open WebSocket connections get terminated (not just suspended) shortly after backgrounding.

Android's Doze mode (6.0+) suspends network access entirely. Even foreground services are affected — WebSocket connections in foreground services get `SocketTimeoutException` after 10–15 minutes with screen off. Only **high-priority FCM data messages** bypass Doze mode reliably.

### The hybrid push architecture

The production pattern is clear: **WebSocket for foreground real-time, push notifications for background delivery**. On iOS, use `content-available: 1` silent pushes (priority 5) to trigger reconnection or deliver payloads. On Android, use FCM data-only messages with `priority: "high"`. Tag each message type: ephemeral (typing indicators — don't buffer), bufferable (chat messages — replay on reconnect), persistent (security alerts — push + store permanently).

The wake-and-reconnect flow: server detects WebSocket disconnect, buffers messages, sends silent push with reconnection hint, app receives push in background, initiates WebSocket reconnection, sends last received sequence number, server replays missed messages.

### Mobile reconnection essentials

Use React Native's `@react-native-community/netinfo` to detect WiFi↔cellular transitions, complete network loss, and restoration. On network change or app foreground, trigger reconnection with exponential backoff (500ms base, 2x multiplier, 30s cap, 30% jitter). The **25-second heartbeat interval** balances battery life against the 30-second cellular NAT timeout — the shortest common infrastructure timeout. At this interval, heartbeat overhead is ~2.4 KB/min per connection.

For offline operation, queue outbound messages locally and replay on reconnect. Socket.IO's event queue pattern (buffer events when disconnected, flush on reconnection) handles this transparently.

---

## 10. Testing real-time systems: from unit tests to chaos

### Load testing WebSocket connections

**k6** provides a stable `k6/ws` module where each virtual user runs an async event loop. Configure ramp-up stages (e.g., 60 VUs over 1 minute, then 600 VUs sustained for 10 minutes), set thresholds on `http_req_duration` and `http_req_failed`, and verify the handshake returns status 101. For 100K+ connections, deploy k6 across multiple machines — each load generator handles ~40K–60K connections limited by the ephemeral port range. The Phoenix framework team achieved 2 million WebSocket connections using Tsung distributed across 8+ client machines, each generating 40K–60K connections.

**Artillery** supports WebSocket via the `ws` engine with YAML scenario definitions. Five action types (connect, send, think, loop, function) compose realistic user flows. Use `ensure.maxErrorRate` to fail CI pipelines on error thresholds.

Before any load test, tune the load generator: `ulimit -n 65535`, expand `ip_local_port_range`, and increase `somaxconn`. Ramp connections gradually (50 connections/second) — spawning all at once overwhelms the handshake path.

### Chaos testing and network simulation

**Toxiproxy** (Shopify) is the standard tool for integration/CI environments. It provides TCP-level toxics: latency injection, bandwidth limiting, connection reset simulation (`reset_peer`), data slicing, and complete proxy disable. In Go tests, create a proxy, add a 500ms latency toxic, dial through the proxy, and verify the application handles degraded conditions correctly.

For network partition simulation, use `tc netem`:

```bash
# Add 200ms latency with jitter
sudo tc qdisc add dev eth0 root netem delay 200ms 50ms
# 10% packet loss
sudo tc qdisc add dev eth0 root netem loss 10%
# 25% packet reordering
sudo tc qdisc add dev eth0 root netem reorder 25% 50%
```

Test connection draining by sending SIGTERM during active connections: verify the server sends CloseGoingAway (1001), clients receive the close frame, reconnect to healthy instances, and no messages are lost during the drain window.

### Integration testing Go WebSocket handlers

Use `httptest.NewServer` with gorilla/websocket's `DefaultDialer.Dial` to test handlers without external dependencies. For tests that shouldn't listen on a port, `posener/wstest` provides a dialer that runs the handler in a goroutine over a fake `net.Conn`. Test the full lifecycle: connect, authenticate (with both valid and invalid tokens), subscribe to a channel, send a message, verify broadcast to other connected test clients, disconnect, and verify cleanup. Set write and read deadlines in tests to prevent hanging CI jobs.

---

## Conclusion: architectural decision matrix for your stack

The Durable Objects + Go WebSocket hybrid architecture maps naturally to production real-time systems. **Use DOs as the coordination layer** — one DO per room/document provides globally unique single-threaded execution with built-in SQLite persistence and WebSocket hibernation that reduces costs by 90%+ during idle periods. Use Go WebSocket servers for workloads that need sub-millisecond latency, sustained high throughput (>1,000 msg/s per entity), or working memory beyond 128 MB.

Three patterns emerged consistently across Discord, Slack, Figma, and Ably's architectures: **two-tier fan-out** (cross-server pub/sub + local delivery) for room messaging, **selective subscription** for presence (only push updates for visible users), and **sequence-number-based reconciliation** for reconnection (replay from last-seen ID, fall back to full snapshot if gap exceeds buffer). Yjs CRDTs with the awareness protocol handle collaborative editing, while LWW registers suffice for most structured data — Linear and Notion both chose this simpler path. On mobile, the split is clean: WebSocket when foregrounded, silent push notifications for background delivery, exponential backoff with jitter for reconnection. Test with k6 for load, Toxiproxy for chaos, and `httptest` for integration — and always test connection draining before your first production deploy.