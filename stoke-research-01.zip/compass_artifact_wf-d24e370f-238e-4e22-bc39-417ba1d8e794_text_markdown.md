# Production patterns for usage-based SaaS billing with Stripe

**Building a metering-to-invoice pipeline that doesn't lose revenue, overcharge customers, or break under international tax complexity requires getting dozens of interlocking systems right.** This guide covers the complete architecture for a TypeScript/Node.js stack on GCP, integrated with Stripe Billing, serving Canadian, US, and EU customers. Every pattern here addresses a real production failure mode — from floating-point arithmetic destroying invoice accuracy to idempotency gaps causing double-billing. The 10 sections below form a complete reference for shipping a billing system that handles usage metering, subscription management, tax compliance, dunning, multi-currency, and revenue recognition.

---

## 1. The metering pipeline: from raw events to Stripe invoices

The fundamental architecture separates raw events from billing metrics. Every billable action (API call, compute second, token consumed) flows through a four-stage pipeline: **collection → aggregation → rating → invoicing**. This separation lets you change pricing logic retroactively without modifying how applications emit events.

**The reference pipeline on GCP:**

```
App Services → Cloud Pub/Sub (ingestion buffer)
  → Cloud Dataflow / Apache Beam (dedup, windowed aggregation)
    → BigQuery (audit trail, analytics)
    → Cloud Run / Functions (rating engine)
      → Stripe Billing Meter API (invoicing)
```

**Event emission at the application layer** is the first critical integration point. Every service that performs billable work emits a structured event with an idempotency key, customer identifier, event-time timestamp, and usage properties:

```typescript
interface MeteringEvent {
  eventName: string;
  idempotencyKey: string;
  timestamp: string; // ISO 8601, event time — not processing time
  customerId: string;
  properties: Record<string, string | number>;
}
```

**Durability is non-negotiable** because losing events means losing revenue. The write-ahead log (WAL) pattern provides the guarantee: persist every event to a durable store (Firestore, Cloud SQL) *before* publishing to Pub/Sub. If the publish fails, a recovery process replays pending WAL entries. GCP Pub/Sub provides at-least-once delivery with 31-day retention across zones, but it does not provide exactly-once semantics — your Dataflow pipeline must deduplicate downstream.

**How leading billing platforms architect their pipelines** reveals a spectrum of trade-offs. Stripe's Billing Meter API processes events asynchronously with **24-hour uniqueness enforcement** on the `identifier` field and accepts timestamps up to 35 calendar days in the past. Stripe acquired Metronome for ~$1B in January 2026, signaling that its native metering needed the streaming-first architecture Metronome had built. Orb stores all raw events (not pre-aggregated), enabling backfills and retroactive pricing changes. Amberflo uses asynchronous SDKs with automatic batching and recommends "squashing" high-volume events at the source. OpenMeter (now part of Kong) uses CloudEvents + Kafka + ksqlDB for deduplication within a 32-day window.

**Pre-aggregation is essential at scale.** WarpStream's two-tiered pattern is the gold standard: per-connection counters flush every 10 seconds into per-tenant aggregators, which flush to the billing system every 60 seconds. This reduces event volume from O(events) to O(tenants × nodes). The trade-off is clear: in-memory aggregation is not durable. If a node crashes, the unflushed window is lost. WarpStream explicitly accepts this because worst-case is under-billing, which is preferable to over-billing.

**Exactly-once semantics** require coordination at every pipeline stage. The practical approach used by most production systems is at-least-once delivery everywhere combined with idempotent consumers at every stage. For the Dataflow-to-BigQuery leg, use the BigQuery Storage Write API with stream offsets for exactly-once guarantees. For the Dataflow-to-Stripe leg, use the `identifier` field on every meter event to achieve deduplication.

---

## 2. Idempotency, deduplication, and windowing prevent billing errors

**Double-counting destroys customer trust faster than any other billing failure.** Every metering platform — Stripe, Amberflo, OpenMeter, Orb — names idempotent ingestion as the #1 design principle.

**Idempotency key patterns** vary by context. For request-scoped events, use `req_${requestId}_${customerId}`. For natural business keys, use `${orderId}_${lineItemId}`. For time-bucketed aggregations (WarpStream's pattern), use `${customerId}::${metricName}::${truncatedTimestamp}`. For Stripe specifically, always set the `identifier` field on meter events — without it, Stripe auto-generates one, meaning a network timeout plus retry creates two separate billable events.

**Deduplication strategies** form a hierarchy of cost and precision:

- **Redis SET NX** with TTL provides exact deduplication with sub-millisecond checks. Set `dedup:${key}` with `EX 86400 NX` — returns `OK` only if the key didn't exist. Simple, fast, and recommended for most SaaS metering workloads.
- **Bloom filters** provide memory-efficient probabilistic deduplication. A Bloom filter never produces false negatives — if it says "new," the event is definitely new. For billing, false positives (occasionally dropping a legitimate event) are strictly preferable to false negatives (double-counting). Use a tiered approach: Bloom filter for the fast path, Redis exact check for the slow path when the Bloom filter reports "maybe duplicate."
- **Database unique constraints** via `INSERT ... ON CONFLICT DO NOTHING` on the idempotency key provide ACID-guaranteed deduplication but don't scale for very high throughput.
- **Kafka stream processing** (OpenMeter's approach) counts occurrences by idempotency key within a configurable window using ksqlDB, forwarding only the first occurrence.

**Deduplication windows must exceed your maximum replay window.** If you might replay events from 7 days ago during incident recovery, your dedup window must be at least 7 days. Stripe enforces 24-hour uniqueness; events older than 35 days are rejected entirely.

**Aggregation windows** for billing are typically tumbling (fixed, non-overlapping) — hourly or daily. Apache Beam on Dataflow provides the windowing primitives: `FixedWindows` for tumbling, `Sessions` for activity-based grouping, and configurable allowed lateness for late-arriving events. Set allowed lateness to at least 6 hours for metering pipelines. Use `ACCUMULATING` mode so each late pane includes the correct total for the window, and use the window's idempotency key when reporting to Stripe so updated totals overwrite previous reports.

**Clock accuracy matters.** GCP VMs synchronize via Google's NTP servers using `chrony`. Stripe accepts events up to 5 minutes in the future (accommodating minor drift) and rejects events older than 35 calendar days. Always use event time — when the action happened — not processing time. Alert if clock drift exceeds 100ms.

---

## 3. Deterministic billing and safe money arithmetic

**The same inputs must produce the same invoice, every time.** Billing calculation determinism requires immutable price snapshots, consistent rounding, defined computation order, and safe arithmetic.

**Never use JavaScript's `Number` type for money.** IEEE 754 double-precision floats cannot precisely represent many decimal fractions: `0.1 + 0.2` produces `0.30000000000000004`. Accumulated across thousands of line items, these errors produce incorrect invoices.

**Integer cents** is the recommended pattern for most SaaS billing, and it's what Stripe uses internally — all API amounts are in the smallest currency unit. Store monetary values as integers (cents), perform additions and subtractions directly, and use a library for multiplication and division:

```typescript
import Decimal from 'decimal.js';
Decimal.set({ rounding: Decimal.ROUND_HALF_EVEN });

const amount = new Decimal('19.99');
const taxRate = new Decimal('0.13'); // 13% Ontario HST
const taxCents = amount.times(taxRate).times(100).round().toNumber(); // 260
```

**dinero.js v2** is the best TypeScript library for a multi-currency SaaS. It provides immutable money objects with currency awareness, safe allocation that handles the extra-cent problem (e.g., $999.99 split 50/50 → $500.00 and $499.99), and ISO 4217 currency support. For intermediate calculations requiring arbitrary precision, use `decimal.js`.

**Banker's rounding (round half to even)** is recommended for billing. When a value falls exactly on a halfway point (e.g., 2.5), it rounds to the nearest even number. This prevents systematic bias over large datasets. Document your rounding strategy and apply it identically across all calculations.

**Decimal precision requirements:** maintain at least 6-8 decimal places during intermediate calculations, round only at final output. Store final amounts as integer cents or `NUMERIC(19,4)` in PostgreSQL. **Never use PostgreSQL's `MONEY` type** (locale-dependent) or `FLOAT`/`DOUBLE PRECISION`.

**Credit application order** follows a defined sequence: calculate line item subtotals → apply discounts/coupons (reducing taxable amount) → calculate tax on discounted subtotal → sum to total → apply credit balance against final total. This matches Stripe's behavior and is correct for US, Canadian, and EU tax compliance.

**Proration on plan changes** in Stripe works as: credit for unused time on old plan + debit for remaining time on new plan. Control via `proration_behavior`: `create_prorations` (default, collected at next cycle), `always_invoice` (charge immediately), or `none`. Usage-based billing components are not subject to proration — you charge only for actual consumption.

---

## 4. Stripe Billing integration: meters, invoices, and webhooks

**The legacy Usage Records API was removed in API version 2025-03-31.basil.** All new implementations should use the **Billing Meter API**, which decouples usage reporting from subscription structure. You need only a `stripe_customer_id`, not a `subscription_item_id`. Meters support `sum`, `count`, and `last` aggregation formulas, and values must be **whole number strings** — no decimals. For fractional units (e.g., $0.005/request), multiply by 1000 and adjust the price accordingly.

**Meter configuration and event reporting:**

```typescript
// Create a billing meter
const meter = await stripe.billing.meters.create({
  display_name: 'API Requests',
  event_name: 'api_request',
  default_aggregation: { formula: 'sum' },
  customer_mapping: {
    event_payload_key: 'stripe_customer_id',
    type: 'by_id',
  },
});

// Report usage with idempotency
await stripe.billing.meterEvents.create({
  event_name: 'api_request',
  payload: {
    stripe_customer_id: 'cus_xxx',
    value: '150', // whole number string
  },
  identifier: 'evt_unique_key_123', // CRITICAL for deduplication
  timestamp: Math.floor(Date.now() / 1000),
});
```

Rate limits are **1,000 events/sec** on the standard API. For higher throughput, the v2 Meter Event Streams API supports **10,000 events/sec** using 15-minute session tokens. Contact Stripe sales for up to 200,000/sec.

**The invoice lifecycle** flows from `draft` → `open` → `paid` (or `void`/`uncollectible`). Stripe delays finalization approximately 1 hour after a successful `invoice.created` webhook response, giving you time to add line items or modify the draft. If no webhook endpoint responds within 72 hours, Stripe proceeds anyway. Listen for `invoice.finalization_failed` — this fires when tax validation fails or the customer's location is invalid for automatic tax calculation.

**Webhook handling requires five practices without exception:**

1. **Signature verification** using `stripe.webhooks.constructEvent()` with the raw request body (`express.raw()`), never parsed JSON.
2. **Immediate 2xx response** before any business logic. Process asynchronously via a queue (Cloud Tasks, Pub/Sub, or BullMQ).
3. **Idempotency checking** via `event.id` stored in a database with `ON CONFLICT DO NOTHING`.
4. **No ordering assumptions.** Stripe does not guarantee event order. `subscription.updated` may arrive before `subscription.created`. Fetch current state from the Stripe API when needed.
5. **Monitor delivery.** Stripe retries up to 35 times over 72 hours. Poll `stripe.events.list({ delivery_success: false })` as a safety net.

**Meter event corrections** are possible via Meter Event Adjustments, but only within 24 hours. After that window, if the event appears on a finalized invoice, no automatic correction occurs. Billing meters are immutable after creation — get the configuration right before production.

**API version pinning** is critical. Pin explicitly in your Stripe client initialization and test new versions against a staging environment before upgrading. Key recent changes: **2025-03-31.basil** removed legacy usage records; **2025-06-30.basil** introduced flexible billing mode with improved prorations.

---

## 5. Pricing models from flat-rate to hybrid usage tiers

Stripe's billing architecture centers on **Products** (what you sell) and **Prices** (how much and how often). The `billing_scheme` field (`per_unit` or `tiered`) and `usage_type` (`licensed` or `metered`) control pricing behavior.

**The critical distinction between graduated and volume tiered pricing** trips up many implementations. With **graduated** pricing, each tier is billed independently: first 1,000 units at $0.10, next 9,000 at $0.05, remainder at $0.02. With **volume** pricing, the *entire* quantity falls into one tier based on total usage — which can create counter-intuitive price drops at tier boundaries. Choose graduated for most SaaS usage billing.

**Hybrid models** combining a flat subscription base with metered overage are the most common SaaS pattern. Stripe handles this naturally with multi-item subscriptions:

```typescript
const subscription = await stripe.subscriptions.create({
  customer: customerId,
  items: [
    { price: 'price_base_monthly' },    // $99/mo flat fee
    { price: 'price_usage_overage' },    // Graduated: first 10K free, then $0.01/call
  ],
});
```

**Entitlement checking** should be cached, not real-time. Stripe's Entitlements API maps Features → Products → Customer access, but checking Stripe on every API request adds unacceptable latency. Instead, sync entitlements to Redis (Cloud Memorystore) via webhooks on `entitlements.active_entitlement_summary.updated`, and check the cache at your API gateway middleware. Use a 5-minute TTL with webhook-driven invalidation.

**Plan changes** should use `always_invoice` for upgrades (charge the proration difference immediately) and **subscription schedules** for downgrades at period end. Preview proration amounts before confirming via `stripe.invoices.createPreview()`. Subscription schedules support up to 10 phases, enabling introductory pricing, scheduled migrations, and future start dates.

**Price versioning and grandfathering** leverage Stripe's immutable Price objects. Create a new Price on the same Product, use `transfer_lookup_key: true` to atomically reassign the lookup key, and set `active: false` on the old Price. Existing subscriptions continue on the old Price indefinitely. For time-limited grandfathering, use subscription schedules to auto-migrate customers:

```typescript
const newPrice = await stripe.prices.create({
  product: 'prod_ProPlan',
  unit_amount: 12900,
  currency: 'usd',
  recurring: { interval: 'month' },
  lookup_key: 'pro_monthly',
  transfer_lookup_key: true, // Atomic reassignment
});
await stripe.prices.update('price_old', { active: false });
```

Version your plans in metadata (`metadata: { version: '2' }`) and make entitlement checks version-aware.

---

## 6. Revenue recognition data engineering for ASC 606 and IFRS 15

**Revenue recognition differs fundamentally from billing.** A customer billed at month-end for usage has revenue recognized daily as consumption occurs. An annual subscriber paying $1,200 upfront generates $100/month in recognized revenue and $1,100 in deferred revenue at day one.

**The ASC 606 five-step model** maps directly to billing data structures: identify the contract (order form + ToS acceptance), identify performance obligations (SaaS access, onboarding, usage), determine transaction price (stated price minus discounts and variable consideration), allocate price to obligations (based on relative standalone selling prices), and recognize revenue as each obligation is satisfied. IFRS 15 follows the same model with minor differences — notably, the collectibility threshold is "more likely than not" (>50%) versus ASC 606's "probable" (~75-80%).

**Usage-based revenue is generally recognized at point of consumption** — each API call, each GB stored, each compute second triggers recognition. Billing in arrears is a commercial artifact; revenue follows the performance obligation. Minimum commitments create a hybrid: the minimum is recognized ratably over the contract term, and overage is recognized as consumed.

**Stripe Revenue Recognition** automates this via a double-entry accounting ledger. It handles subscription amortization, prorations, refunds, disputes, and multi-currency with FX tracking. Revenue Contracts allow modeling enterprise B2B arrangements with custom performance obligations. Key limitations: **72-hour data delay** in reports, no native SSP allocation engine for multi-element arrangements, non-Stripe data requires CSV import, and complex usage patterns (estimates, true-ups, variable consideration constraints) may need supplemental logic.

**Engineering data requirements** are extensive. Every invoice line item needs a service period (start and end dates) — without it, Stripe recognizes revenue immediately. Your data model needs tables for `contracts`, `performance_obligations` (with fulfillment type: over-time or point-in-time), `revenue_schedules` (period-by-period recognition amounts), and `journal_entries` (double-entry audit trail). The reconciliation equation must always balance: **total billed = recognized revenue + deferred revenue + contra revenue**.

For a Canadian company reporting under both IFRS and US GAAP contexts, Stripe Revenue Recognition supports both standards. Build jurisdiction-aware rules that account for the differences in collectibility thresholds and renewal treatment.

---

## 7. Dunning that prevents involuntary churn without destroying trust

**Smart Retries** use an ML model trained on 500+ attributes across Stripe's entire network — customer geography, payment behavior, issuer patterns, time-of-day seasonality, and dynamic signals. Stripe reports businesses recover an average of **57% of failed recurring payments**. Configure retries in the Dashboard under Billing → Revenue Recovery: **8 retries within 2 weeks** is the recommended default.

Card network rules constrain retries: Mastercard allows 35 attempts, Visa allows 15 within a rolling 30-day period. Exceeding limits triggers fines up to $15,000. Smart Retries avoids hard declines (lost_card, stolen_card) and only executes retries after detecting favorable conditions.

**The email dunning sequence** should escalate progressively:

- **Day 1**: Gentle notification with Customer Portal link for self-service payment update
- **Day 3-4**: Follow-up emphasizing what they'll lose, with a value reminder
- **Day 7**: Urgent notice via email + SMS + persistent in-app banner
- **Day 10**: Service degradation begins (read-only mode)
- **Day 14**: Final warning — "your subscription will be canceled tomorrow"

**Service degradation patterns** matter enormously for B2B SaaS. Hard cutoff destroys trust and causes data loss anxiety. The recommended pattern is **progressive degradation**: full access during days 1-7 with a persistent banner, read-only mode during days 8-14 (can view and export data but not create/edit), and hard cutoff after day 14 with a data export window. Implement via subscription status mapping — `past_due` = grace period with full or restricted access, `unpaid` = read-only for data export, `canceled` = full revocation.

**Stripe's Automatic Card Updater** works with Visa, Mastercard, AmEx, and Discover to silently update saved card details when cards are replaced. This handles ~70% of expired cards before they cause payment failures. At **$0.25 per update**, it's highly cost-effective for churn prevention. Some experts recommend *disabling* pre-dunning "card expiring" emails when Card Updater is active, since these can trigger unnecessary customer anxiety.

The **Customer Portal** provides self-service payment method updates, plan switching, cancellation with reason collection, invoice history, and tax ID management. Create sessions programmatically with `stripe.billingPortal.sessions.create()` and optionally deep-link to specific flows like `flow_data: { type: 'payment_method_update' }`. Key limitation: the portal cannot handle subscriptions with multiple products or usage-based billing modifications.

---

## 8. Multi-currency billing for CAD, USD, and EUR

**For a Canadian company billing in three currencies, the optimal strategy is manual currency prices with multi-currency settlement.** Create Price objects with curated, psychologically-rounded amounts per currency using `currency_options`:

```typescript
const price = await stripe.prices.create({
  currency: 'cad',
  unit_amount: 4900, // $49 CAD
  recurring: { interval: 'month' },
  product: 'prod_pro',
  currency_options: {
    usd: { unit_amount: 3900 }, // $39 USD — not exact conversion
    eur: { unit_amount: 3500 }, // €35 EUR — rounded for market
  },
});
```

**Presentment currency** is what the customer sees and pays. **Settlement currency** is what lands in your bank account. If they differ, Stripe converts using mid-market rate plus ~1% conversion fee. **Eliminate this fee entirely** by setting up multi-currency settlement: maintain separate bank accounts for CAD, USD, and EUR in your Stripe Dashboard under Payout Settings. USD charges accrue in your USD balance and pay out to your USD account with zero FX conversion.

**Exchange rate timing** varies by context. Standard charges use the mid-market rate at payment time. Stripe's Adaptive Pricing (available for Checkout) locks the rate from session start through settlement, absorbing FX risk for the merchant. For `send_invoice` collection, the rate is estimated at finalization but the actual rate at payment time may differ, creating FX gain/loss.

**Use round-number prices, not exact conversions.** $49 CAD converted to USD at current rates produces awkward amounts like $36.27. Instead, set $39 USD — it feels intentional, looks professional, and lets you optimize per-market pricing. Review and adjust quarterly based on FX movements.

**Refund handling** differs by payment type. With Adaptive Pricing, refunds use the same exchange rate as the original transaction — the customer gets back exactly what they paid. With standard multi-currency charges, the refund rate may differ from the original, creating FX gain or loss on your books.

**Currency display** should use `Intl.NumberFormat` with locale awareness: `formatCurrency(4900, 'cad', 'en-CA')` produces "CA$49.00" while `formatCurrency(4900, 'cad', 'fr-CA')` produces "49,00 $ CA".

---

## 9. Tax compliance across Canada, the US, and the EU

**Start with Stripe Tax** (`automatic_tax: { enabled: true }`) as your primary engine. It covers GST/HST, US state sales tax, and EU VAT natively with rooftop-level accuracy, automatic threshold monitoring, and tax ID validation. If you outgrow it (complex exemption certificates, multi-channel sales, ERP integration), consider Avalara. TaxJar, while Stripe-owned, is US-only and its development has largely stalled.

### Canadian tax is the most complex provincial landscape

GST/HST rates vary by province: **5% GST** in Alberta, **13% HST** in Ontario, **15% HST** in Atlantic provinces (Nova Scotia dropped to 14% in April 2025), and **separate GST + PST/QST** in BC (5% + 7%), Saskatchewan (5% + 6%), Manitoba (5% + 8%), and Quebec (5% + 9.975%). All of these apply to SaaS.

**Saskatchewan has no registration threshold** — one sale triggers a PST obligation. Quebec's QST threshold is C$30K. BC PST applies to SaaS with no B2B exemption. For GST/HST, the C$30K threshold applies to B2C sales over 12 months. PST has no B2B exemption for software in Saskatchewan, BC, or Manitoba — you must collect even from business purchasers.

### US SaaS tax depends on the state

**25 US states tax SaaS** as of 2025. Key taxable states include New York, Texas, Pennsylvania, Washington, Connecticut, and Ohio. Key non-taxable states include **California** (SaaS is a nontaxable service), Virginia, and Colorado. The five NOMAD states (Delaware, Montana, Alaska, New Hampshire, Oregon) have no general sales tax.

**Economic nexus** post-Wayfair typically triggers at **$100,000 in sales or 200 transactions** per state, though the trend is toward eliminating the transaction threshold. Notable exceptions: California, Texas, and New York use a $500,000 threshold. A Canadian company creates nexus purely through sales volume — no physical presence required.

### EU VAT requires OSS registration

SaaS is classified as an "electronically supplied service" subject to VAT in all EU member states. **B2C sales** require charging VAT at the customer's country rate (ranging from **17% in Luxembourg to 27% in Hungary**). Register for the **Non-Union OSS** (One-Stop Shop) scheme in one EU member state to file a single quarterly return covering all EU B2C sales. There is **no minimum threshold** for non-EU companies.

**B2B reverse charge** applies when the customer provides a valid EU VAT ID. Invoice without VAT, include the notation "Reverse charge," and exclude these sales from OSS reporting. Stripe validates VAT numbers against VIES asynchronously and fires `customer.tax_id.updated` when validation completes.

**Implementation pattern for tax-aware subscriptions:**

```typescript
const subscription = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: price.id }],
  automatic_tax: { enabled: true },
});
```

Use `tax_behavior: 'exclusive'` for CAD and USD prices (standard in North America) and `tax_behavior: 'inclusive'` for EUR prices (standard EU consumer expectation). Collect tax IDs via `stripe.customers.createTaxId()` with types `ca_gst_hst`, `eu_vat`, or `us_ein`. Enable `tax_id_collection: { enabled: true }` on Checkout Sessions.

**Registration priority for a Canadian SaaS company:** (1) Canada GST/HST with CRA, (2) Quebec QST if selling to QC consumers, (3) BC PST, Saskatchewan PST, Manitoba RST as you sell to those provinces, (4) US states as you exceed $100K per state, (5) EU Non-Union OSS in one member state.

---

## 10. Observability: knowing if your billing system is correct

**MRR calculation from Stripe data has a critical pitfall**: the API returns only the most recent subscription state, not historical changes. For accurate historical MRR, **use invoice line items** (each has a `period` object with start/end dates) rather than subscription objects. Normalize non-monthly intervals: a $1,200/year plan contributes $100 MRR. Stripe excludes metered/usage-based products from MRR by default.

Track the full MRR waterfall: **new MRR + expansion MRR + reactivation MRR - contraction MRR - churned MRR ± FX adjustment = net new MRR**. The SaaS Quick Ratio (new + expansion) ÷ (churn + contraction) should exceed 4.0 for healthy growth.

**Churn decomposition** separates voluntary (customer cancels, ~78% of churned revenue) from involuntary (payment failure, ~22%). Track both logo churn (customer count) and revenue churn (MRR lost) — losing many small customers inflates logo churn without proportional revenue impact, while losing one enterprise account barely affects logo churn but devastates revenue. Industry benchmarks: SaaS averages 39% annual churn total; best practice targets <5% annual voluntary churn, <1% involuntary.

**Metering accuracy verification** requires dual-write reconciliation. Instrument your application to write every billable event to both your internal audit log and the Stripe Meter API, plus maintain a shadow counter in Redis. Run daily reconciliation comparing all three sources:

```typescript
async function reconcileUsage(customerId: string, period: DateRange) {
  const internalTotal = await db.usageLog.aggregate({ /* ... */ });
  const meterSummary = await stripe.billing.meters.listEventSummaries(meterId, {
    customer: customerId,
    start_time: period.start, end_time: period.end,
  });
  const stripeTotal = meterSummary.data.reduce((s, e) => s + e.aggregated_value, 0);
  const drift = Math.abs(internalTotal - stripeTotal) / internalTotal;
  if (drift > 0.01) await alerting.send({ severity: 'warning', /* ... */ });
}
```

**Alert thresholds for billing system health:**

| Metric | Warning | Critical |
|--------|---------|----------|
| Payment failure rate | >5% | >10% |
| MRR day-over-day drop | >3% | >10% |
| Webhook delivery failures | >1% | >5% |
| Metering drift | >1% | >5% |
| API error rate | >0.5% | >2% |

**GCP-specific monitoring** uses Cloud Monitoring custom metrics for real-time alerting and BigQuery for batch analytics. Use Stripe Data Pipeline to sync billing data to BigQuery for complex MRR calculations, cohort analysis, and multi-currency normalization. Build Looker Studio dashboards on BigQuery datasets. For Stripe-native analytics, Sigma provides SQL access to live billing data with prebuilt SaaS templates.

**Daily reconciliation** between internal records and Stripe should cover invoice amounts (match by `stripe_invoice_id`, compare `amount_due`, `amount_paid`, line items), payment amounts (match charges/payment intents, track refunds and disputes), and usage totals (application logs vs meter summaries vs invoice line items). Common discrepancy causes include late-arriving events, failed webhooks, timezone misalignment, and floating-point rounding. Automate the reconciliation as a Cloud Function on a daily schedule, flag mismatches, auto-create tickets for anything exceeding thresholds, and document resolutions in an audit trail.

---

## Conclusion: the billing system is a distributed financial ledger

Three architectural principles emerge across all 10 areas. First, **idempotency is the universal safety mechanism** — from meter event deduplication to webhook processing to invoice generation, every component must handle retries gracefully using deterministic keys. Second, **separation of concerns** between metering (what happened), rating (what it costs), billing (what the customer owes), and revenue recognition (when revenue is earned) enables each layer to evolve independently while maintaining end-to-end correctness. Third, **observability is not optional** — without reconciliation between your metering system, Stripe's records, and your financial ledger, drift accumulates silently until it surfaces as customer disputes or audit findings.

The most dangerous pattern in billing engineering is premature abstraction. Start with Stripe's native capabilities — Billing Meters, automatic tax, Smart Retries, Revenue Recognition — and add custom infrastructure only when you hit measured limitations. Every additional layer between your application and Stripe is a layer that can lose events, double-count usage, or drift out of sync. Build the minimum viable metering pipeline first, verify it with dual-write reconciliation, and expand from there.