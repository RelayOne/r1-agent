# Production patterns for background job processing and async workflows

**The right job infrastructure depends on your workflow complexity, not your throughput.** PostgreSQL-backed queues like Graphile Worker handle the vast majority of background job needs with transactional safety and zero additional infrastructure. Kafka excels at cross-service fan-out and event streaming. Temporal becomes essential when workflows span days, require compensation logic, or involve complex multi-step orchestration with durable state. The most effective production architectures layer all three: Graphile Worker for within-service jobs (same-transaction guarantees), Kafka for cross-service events, and Temporal for complex orchestration — each solving a distinct class of problem.

This report covers the full landscape of production job processing patterns: framework selection, idempotency, failure handling, scheduling, long-running work, fairness, saga orchestration, event-driven design, and observability.

---

## Seven frameworks, three fundamental architectures

Background job frameworks fall into three architectural camps: **deterministic replay** (Temporal), **event-driven step memoization** (Inngest, Trigger.dev), and **queue-based workers** (BullMQ, Graphile Worker, River, Faktory). The architecture you choose determines your guarantees, operational complexity, and ceiling for workflow sophistication.

**Temporal** uses deterministic replay as its core mechanism. Workflows are written as ordinary code but must be deterministic — no random numbers, no direct I/O, no time calls. The Temporal Service records every decision, timer, and activity invocation as an immutable Event History. When a worker crashes, another replays this history to reconstruct state exactly. Side effects execute as Activities, whose results are persisted and never re-executed on replay. This model enables workflows that run for months or years, surviving any infrastructure failure. The tradeoff is operational complexity: self-hosting requires four services plus a database cluster, though Temporal Cloud eliminates this burden at **$200/month** for the Growth tier.

**Inngest and Trigger.dev** take a lighter approach. Inngest invokes your functions via HTTPS when triggering events arrive — your code doesn't poll a queue. Each `step.run()` call creates a retriable checkpoint whose output is memoized. On failure, execution resumes from the last successful step. Trigger.dev v3 deploys tasks to its own elastic runtime with a checkpoint-resume system that pauses, saves state, and resumes without consuming resources during waits. Both offer managed hosting with free tiers and open-source self-hosting.

**BullMQ, Graphile Worker, River, and Faktory** follow the traditional queue-worker model. BullMQ uses Redis data structures with Lua scripts for atomic operations, delivering sub-millisecond latency and thousands of jobs per second. Graphile Worker and River use PostgreSQL's `SKIP LOCKED` and `LISTEN/NOTIFY` for job claiming and real-time pickup, achieving **~2ms latency** from insert to execution start. Faktory takes a "smart server" approach with an embedded RocksDB store and a polyglot TCP protocol supporting workers in any language.

| Feature | Temporal | Inngest | Trigger.dev | BullMQ | Graphile Worker | River (Go) | Faktory |
|---|---|---|---|---|---|---|---|
| **Architecture** | Deterministic replay | Event-driven HTTP | Checkpoint-resume | Redis queues | PG SKIP LOCKED | PG + goroutines | Smart server + RocksDB |
| **Hosted option** | Cloud + self-host | Cloud + self-host | Cloud + self-host | Self-host only | Self-host only | Self-host only | Self-host only |
| **Languages** | Go, Java, TS, Python, .NET | TS, Go, Python | TypeScript only | Node.js primary | Node.js | Go | Any (polyglot) |
| **Tx enqueue** | No | No | No | No | **Yes (same PG tx)** | **Yes (same PG tx)** | No |
| **Workflow support** | Native (core feature) | Steps + fan-out | Task chaining | Parent-child | No | Pro (fan-out/in) | Batches (Enterprise) |
| **Throughput** | 300k+ actions/sec (Cloud) | Managed scaling | Elastic | Thousands/sec | ~700 jobs/sec/node | ~10k jobs/sec | ~5k jobs/sec |

All frameworks provide **at-least-once** delivery. None provides true exactly-once execution of activities or tasks — this is a fundamental distributed systems constraint. Temporal comes closest: workflow logic executes effectively once through deterministic replay, but individual activities may retry and must be designed as idempotent.

---

## PostgreSQL as a job queue works better than you think

The `FOR UPDATE SKIP LOCKED` clause, introduced in PostgreSQL 9.5, is what makes PostgreSQL viable as a job queue. When a transaction tries to lock a row already locked by another transaction, it skips that row and moves to the next available one. Workers never block each other, and the convoy effect that plagued earlier approaches disappears entirely.

```sql
WITH next_job AS (
  SELECT id FROM jobs
  WHERE status = 'pending' AND scheduled_at <= now()
  ORDER BY priority ASC, created_at ASC
  LIMIT 1
  FOR UPDATE SKIP LOCKED
)
UPDATE jobs SET status = 'processing', started_at = now()
FROM next_job WHERE jobs.id = next_job.id
RETURNING jobs.*;
```

Graphile Worker layers `LISTEN/NOTIFY` on top of this. When a job is inserted via `graphile_worker.add_job()`, a `NOTIFY` fires on a known channel, waking workers within milliseconds. Combined with `SKIP LOCKED` for claiming, this achieves **sub-3ms latency** from job insert to execution start — comparable to Redis-based queues for most workloads.

The killer feature of PostgreSQL-backed queues is **transactional job enqueue**. You can insert business data and enqueue a job in the same database transaction. If the transaction rolls back, the job vanishes too. This eliminates the dual-write problem that plagues every Redis or Kafka-based queue and removes the need for a separate outbox pattern within a single service.

```sql
BEGIN;
  UPDATE orders SET status = 'confirmed' WHERE id = $1;
  SELECT graphile_worker.add_job(
    'send_order_confirmation',
    json_build_object('order_id', $1),
    job_key := 'confirm_order_' || $1
  );
COMMIT;
```

**Throughput benchmarks** tell a clear story. PostgreSQL handles **2,885 msg/sec on a 4-vCPU node** and **20,144 msg/sec on a 96-vCPU node** for queue workloads. River achieves ~10,000 trivial jobs/sec on a commodity laptop. These numbers cover the vast majority of applications. You need Redis when sub-millisecond dispatch latency matters or throughput exceeds ~20k jobs/sec. You need Kafka when throughput requirements hit 100k+ messages/sec, you need pub/sub fan-out to multiple independent consumer groups, or you need message replay capability.

One critical caveat: advisory locks do not work reliably with PgBouncer in `pool_mode=transaction` because connections swap between clients. Use `pool_mode=session` for connections that hold advisory locks, or maintain a separate direct connection pool for coordination.

---

## Every job must be safely re-runnable

Idempotency is not optional in distributed job processing. Every framework delivers at-least-once, meaning every job handler must produce the same outcome whether it runs once or five times. Three patterns dominate production systems.

**"Check before work"** is the most common pattern. Before performing any mutation, verify the current state. If the work is already done, return successfully without side effects. This requires entities to have explicit terminal states — `pending`, `processing`, `completed`, `failed` — so a job finding a record in a terminal state can exit safely.

```typescript
async function processPayment(payload: { orderId: string }) {
  const order = await db.query('SELECT status FROM orders WHERE id = $1', [payload.orderId]);
  if (order.status === 'paid') return; // Already processed
  
  const charge = await stripe.charges.create({
    amount: order.amount,
    idempotency_key: `charge_order_${payload.orderId}` // External API idempotency
  });
  
  await db.query(
    'UPDATE orders SET status = $1, charge_id = $2 WHERE id = $3 AND status = $4',
    ['paid', charge.id, payload.orderId, 'pending'] // Optimistic lock via WHERE status = 'pending'
  );
}
```

**Database-level deduplication** uses unique constraints and upserts. `INSERT ... ON CONFLICT DO NOTHING` naturally deduplicates — if the insert succeeds, the work was new; if it conflicts, it was a duplicate. Stripe stores idempotency keys in a dedicated table with the request parameters and cached response, auto-expiring after **24 hours** (API v1) or **30 days** (API v2).

**Framework-specific deduplication** varies significantly. Graphile Worker's `job_key` is the primary mechanism, with three modes: `replace` (overwrites unlocked jobs — good for debouncing), `preserve_run_at` (overwrites but keeps the original schedule — good for throttling), and `unsafe_dedupe` (silently drops duplicates even if the existing job is locked or failed). BullMQ offers simple deduplication (until job completion), throttle mode (TTL-based), and debounce mode (delay + TTL + replace). Temporal uses Workflow IDs as natural idempotency keys — starting a workflow with an ID that's already running returns `WorkflowAlreadyStartedError`.

For Kafka-to-database pipelines, Kafka's built-in exactly-once only covers Kafka-to-Kafka flows. The **Idempotent Consumer Pattern** is essential: include a unique event ID in each message, check a `processed_events` table before processing, and mark as processed within the same database transaction as the business logic.

---

## Retry strategies that actually work in production

The canonical approach is **exponential backoff with full jitter**, as documented in the AWS Architecture Blog. The formula `delay = random_between(0, min(cap, base * 2^attempt))` spreads retries across the backoff window, preventing thundering herd problems that un-jittered backoff creates when many jobs fail simultaneously.

Graphile Worker's default backoff formula `exp(least(10, attempt))` produces a natural escalation: **~3 seconds** at attempt 1, **~2.5 minutes** at attempt 5, **~2 hours** at attempt 9, and a ceiling of **~6 hours** per attempt thereafter. With the default 25 max attempts, a job exhausts retries over roughly 4 days — enough to survive extended outages.

The most impactful production pattern is **error classification**. Transient errors (network timeouts, 429s, 502s, 503s) warrant retries. Permanent errors (400s, 401s, 404s, validation failures) should fail immediately. Every framework provides a mechanism: Temporal's `non_retryable_error_types` in RetryPolicy, BullMQ's `UnrecoverableError`, Inngest's `NonRetriableError`, or manual `permanently_fail_jobs()` in Graphile Worker. Classifying errors at the point of failure prevents wasting retry budget on jobs that will never succeed.

**Dead letter queues** catch jobs that exhaust all retries. In Graphile Worker, permanently failed jobs remain queryable via SQL — `SELECT * FROM graphile_worker._private_jobs WHERE attempts >= max_attempts`. For Kafka, implement retry topics with escalating delays (`retry-1min`, `retry-10min`) feeding into a dead letter topic after exhaustion. Monitor DLQ depth as a critical production metric — any growth indicates a systemic issue requiring investigation.

**Poison job detection** prevents a single bad job from crashing workers repeatedly. Track jobs that fail immediately (sub-second execution) across multiple attempts. Implement a circuit breaker per task type: after N consecutive failures within a time window, pause processing for that task type and alert. Graphile Worker's exponential backoff provides natural protection — a poison job doesn't immediately return to the queue — but proactive detection is still essential.

---

## Distributed cron requires more than a cron expression

Running a scheduled job exactly once across multiple server instances is deceptively difficult. The core challenge is leader election — ensuring only one instance fires the job while surviving instance failures.

**PostgreSQL advisory locks** are the most reliable approach for PostgreSQL-centric stacks. `pg_try_advisory_lock(hashtext('daily-report'))` returns `true` for exactly one session; all others get `false`. If the leader crashes, PostgreSQL detects the closed connection and releases the lock automatically. River uses this pattern for all its maintenance tasks.

Graphile Worker's built-in crontab uses SQL transactions and a `known_crontabs` lock table. The first worker to insert the cron job for a given timestamp wins; others take no action. This provides exactly-once scheduling, though execution still follows at-least-once semantics if the job fails and retries. The crontab supports a `?fill=2d` option to backfill missed executions during downtime, and each job receives `_cron.ts` (scheduled timestamp) in its payload.

Temporal Schedules are the most feature-rich option: calendar-based or interval-based expressions with **six overlap policies** (Skip, BufferOne, BufferAll, CancelOther, TerminateOther, AllowAll), a configurable catchup window for missed executions, auto-pause on failure, built-in jitter for load spreading, and IANA timezone support.

**Overlap prevention** is often overlooked. When a cron job takes longer than its interval, frameworks diverge. Kubernetes CronJobs offer `concurrencyPolicy: Forbid` (skip new runs) or `Replace` (terminate and restart). Temporal provides the overlap policies listed above. Graphile Worker has no built-in overlap prevention — a new cron job is created each interval regardless. The workaround is combining `job_key` with the cron task to prevent duplicate executions.

**DST handling** catches teams by surprise. Jobs scheduled between 2:00–2:59 AM during spring-forward simply don't fire because that hour doesn't exist. During fall-back, jobs between 1:00–1:59 AM may fire twice. The safest approach: **store and evaluate all schedules in UTC**. If user-facing schedules must use local time, store the cron expression alongside the user's IANA timezone and recompute the next UTC execution time after each run. Avoid scheduling anything in the 1:00–3:00 AM local time window.

---

## Long-running jobs need heartbeats, checkpoints, and cancellation

Jobs that run for minutes or hours require fundamentally different patterns than sub-second tasks. Three mechanisms are essential: heartbeats for liveness detection, checkpoints for resumability, and explicit cancellation support.

**Temporal's heartbeat model** is the gold standard. Activities call `activity.RecordHeartbeat(ctx, progressData)` at regular intervals. If the heartbeat timeout expires without a heartbeat, Temporal reschedules the activity to another worker. Critically, heartbeat details serve as checkpoints — on retry, the new activity execution accesses the last heartbeat detail and resumes from that point rather than restarting. The SDK throttles heartbeats at 80% of the heartbeat timeout to reduce server load, but this means cancellation delivery can be delayed by up to the throttle interval.

**BullMQ** detects stalled jobs through lock renewal. Workers automatically renew their lock on active jobs via the Node.js event loop. If the event loop blocks (CPU-intensive work), lock renewal fails and the job is marked stalled. The `lockDuration` setting (default 30 seconds) must be increased for long-running jobs. Running job logic in sandboxed processors (separate processes) prevents event loop blocking from triggering false stall detection.

**Graphile Worker** takes a simpler approach: jobs locked for more than 4 hours are considered crashed and released for retry. Worker Pro improves this with configurable heartbeat-based crash detection. For long-running jobs on open-source Graphile Worker, the 4-hour ceiling is a real constraint.

**Checkpointing** patterns vary by framework. In BullMQ, use `job.updateData()` to persist intermediate state every N items processed. In Graphile Worker, store checkpoint data in a separate table keyed by job ID. On retry, the task reads the checkpoint and resumes. Temporal's durable execution model handles this automatically for workflow-level logic — state is persisted at every await point — but activities still need explicit heartbeat-based checkpointing.

**Cancellation** requires active cooperation from the job. Temporal delivers cancellation through heartbeats — activities that don't heartbeat cannot receive cancellation. Graphile Worker (v0.16+) provides an `AbortSignal` during graceful shutdown with a configurable timeout. In all cases, wrap cleanup logic in a non-cancellable scope to ensure resources like files, API sessions, and locks are released even during cancellation.

For Temporal workflows that would exceed the **50,000-event or 50MB** Event History limit, the **Continue-As-New** pattern atomically completes the current execution and starts a new one with the same Workflow ID but fresh history. This is essential for entity workflows, subscription processors, or any workflow that loops indefinitely.

---

## Fair scheduling prevents noisy tenants from starving the queue

In multi-tenant systems, a single tenant enqueuing 100,000 jobs can starve every other tenant in a FIFO queue. Standard queues — BullMQ, Graphile Worker, SQS — are not inherently multi-tenant-fair.

**Per-tenant sharded queues with round-robin** is the simplest effective pattern. Maintain logical sub-queues per tenant. When a worker dequeues, it round-robins across tenant shards instead of pulling from a single FIFO. Even if one tenant has 100x the jobs, each tenant gets equal scheduling attention.

**Weighted fair queuing (WFQ)** extends this with proportional allocation. Deficit Round-Robin allocates tokens to each active tenant proportional to their weight, processes requests consuming tokens, and cycles through tenants. Inngest's production implementation uses a "global pointer" queue that workers scan for available work, then shuffle jobs into a weighted random order considering latency, capacity, and tier — minimizing contention while guaranteeing fairness across billions of function runs.

**Temporal's fairness system** (public preview) provides native support via fairness keys. Assigning a key like `tenant_id` to workflows creates virtual queues with round-robin dispatch. Each key can have a weight between 0.001 and 1000, and per-key rate limits control individual tenant throughput. The system is probabilistic and best-effort — accuracy degrades as the number of unique keys increases.

**Rate limiting per job type** prevents any single job type from monopolizing workers. BullMQ offers a global rate limiter (`limiter: { max: 100, duration: 1000 }`) shared across all workers via a Redis counter. Temporal provides per-worker limits (`maxWorkerActivitiesPerSecond`) and global task queue limits (`maxTaskQueueActivitiesPerSecond`). Graphile Worker lacks native rate limiting but supports a **forbidden flags** pattern: assign flags to jobs, dynamically compute which flags are "forbidden" based on current rate, and workers skip flagged jobs.

**Starvation prevention** requires breaking strict priority ordering. Strict priority (all priority-1 jobs before any priority-2) guarantees starvation under sustained load. Priority bands group priorities into tiers (urgent, normal, batch) with proportional allocation across bands. In BullMQ, create separate queues per band with proportional rate limits — high (50%), normal (35%), low (15%). In Graphile Worker, run dedicated worker instances per priority tier. Priority aging — periodically boosting the priority of long-waiting jobs — is not natively supported in any major framework but can be implemented with a scheduled `UPDATE` in PostgreSQL-based systems.

---

## Saga orchestration makes complex workflows survivable

The saga pattern replaces distributed transactions with a sequence of local transactions, each paired with a compensating action. If step N fails, compensations for steps N-1 through 1 execute in reverse. Compensations are not rollbacks — they create new transactions that semantically undo prior effects. A refund is a new credit transaction, not a database rollback.

**Temporal provides the most mature saga implementation.** The Saga utility tracks compensations as forward steps complete, then executes them in reverse on failure:

```typescript
const saga = new Saga();
try {
  const reservationId = await reserveInventory(orderId);
  saga.addCompensation(releaseInventory, reservationId);
  
  const paymentId = await chargePayment(orderId, amount);
  saga.addCompensation(refundPayment, paymentId);
  
  await shipOrder(orderId);
} catch (err) {
  await saga.compensate(); // Runs compensations in reverse order
  throw err;
}
```

Each forward step must capture enough context for its compensation (reservation IDs, transaction IDs). Compensations themselves must be idempotent — they may retry. Configuration options include `parallelCompensation` for independent compensations and `continueWithError` if a compensation itself fails.

**Workflow versioning** is a real production concern. Changing workflow code while in-flight executions exist can cause non-determinism errors during replay. Temporal offers two solutions. **Patching** acts like a feature flag: `patched('my-change-id')` inserts a marker in the Event History, and during replay the system branches based on whether the marker exists. **Worker Versioning** (recommended for production) pins workflows to the Worker deployment version where they started. Multiple worker versions coexist in "rainbow deployments," with old versions draining while new versions handle new workflows.

**For Graphile Worker**, implement sagas with a `saga_executions` table tracking `current_step`, `step_data` (JSONB), and a `compensations` array. Each step is a separate Graphile Worker task that executes the forward action, records the compensation, and enqueues the next step — all in the same PostgreSQL transaction. The `graphile-saga` community library provides typed step definitions with automatic compensation queueing.

The choice between **orchestration** (central coordinator) and **choreography** (event-driven, each service reacts) depends on workflow complexity. Orchestration provides clear visibility, centralized error handling, and explicit compensation logic — ideal for complex, multi-step, conditional workflows. Choreography offers loose coupling and no coordinator SPOF, but Martin Fowler warns: "It's very easy to make nicely decoupled systems with event notification, without realizing that you're losing sight of that larger-scale flow." The practical hybrid: choreography between bounded contexts (via Kafka events), orchestration within them (via Temporal or Graphile Worker sagas).

---

## Events for fan-out, commands for direct work

**Direct job enqueue** (GraphQL mutation → `add_job()` in the same PostgreSQL transaction) is the right choice when the consumer is known, the trigger is synchronous, and you're within a single service. The transactional guarantee — business data and job creation atomically committed or rolled back — eliminates an entire class of consistency bugs.

**Kafka events** are the right choice when multiple independent consumers need the same event, you need cross-service communication, replay capability matters, or you need an audit trail. A single `order-created` event on Kafka can independently trigger payment processing, inventory reservation, analytics recording, and notification sending — each consumer group maintaining its own offset.

**The transactional outbox pattern** bridges these two worlds. Write the event to an `outbox` table in the same database transaction as the business data change. A separate relay process (or Kafka Connect with CDC) publishes to Kafka. With Graphile Worker, the outbox pattern is elegantly simplified: the job itself acts as the relay. INSERT business data + `add_job('publish_to_kafka', ...)` in the same transaction. When the job executes, it publishes to Kafka. If publishing fails, the job retries with Graphile Worker's built-in exponential backoff.

For the recommended architecture: within a service, enqueue jobs via Graphile Worker in the same PostgreSQL transaction. For cross-service communication, publish events to Kafka. For complex multi-service orchestration, use Temporal workflows calling Activities that interact with individual services. This three-layer approach matches each tool to its strength.

---

## Observability starts with queue latency, not queue depth

The most important metric for background job health is **queue latency** — the time from enqueue to start of processing — not queue depth. A thousand items on a queue might be processed instantly with sufficient workers, while five items could be significantly delayed by a saturated pool. Alert on latency exceeding your SLO, not on absolute queue size.

- **Queue latency**: Time from `run_at` to actual processing start. Alert when P95 exceeds your target (e.g., 30 seconds)
- **Processing time**: Duration per job type. Track P50/P95/P99 histograms. Alert when P95 exceeds 2x historical baseline
- **Failure rate**: Failed jobs divided by total, segmented by job type. Alert above 5% over a 5-minute window
- **DLQ depth**: Any growth in permanently failed jobs warrants immediate investigation
- **Worker utilization**: Active jobs divided by capacity. Scale up when sustained above 80%

**Tracing across async boundaries** requires explicit context propagation. The universal pattern: at enqueue time, serialize the W3C TraceContext into the job payload; at dequeue time, extract it and create a consumer span linked to the producer span. BullMQ offers first-party OpenTelemetry support via the `bullmq-otel` package. Temporal provides native tracing interceptors in every SDK that automatically propagate spans through client → Workflow → Activity → Child Workflow, even across different workers and time boundaries. Graphile Worker requires manual instrumentation via its events system — listen to `job:start`, `job:success`, and `job:error` events and create spans accordingly.

For structured logging, inject `trace_id`, `job_id`, `tenant_id`, and `attempt_number` into every log line. Graphile Worker's `helpers.logger` is scoped per-job. BullMQ's worker events include `job.id`, `job.name`, and `job.attemptsMade`. Temporal's SDK loggers are automatically scoped to the workflow/activity context.

Define SLOs for background job processing the same way you would for API endpoints. A practical SLI: "fraction of jobs completed within target latency." A practical SLO: **99.9% of jobs complete within 2 seconds** of their scheduled time over a 28-day window. Alert on error budget burn rate rather than instantaneous thresholds — a fast burn (14.4x rate over 1 hour) warrants paging, while a slow burn (6x over 6 hours) warrants a ticket.

---

## Practical architecture for your stack

Given your current use of PostgreSQL with Graphile Worker, Kafka for events, and evaluation of Temporal, the highest-leverage architecture layers all three with clear boundaries.

**Graphile Worker** remains your workhorse for straightforward background jobs. Its transactional enqueue (same PostgreSQL transaction as business data) is a superpower that no Redis or Kafka-based system can match. Use `job_key` with `preserve_run_at` mode for throttling, `replace` mode for debouncing, and content-based keys for deduplication. For rate limiting, the forbidden flags pattern or the community `graphile-worker-rate-limiter` package fills the gap. The ~700 jobs/sec/node throughput ceiling is rarely a practical constraint.

**Kafka** handles cross-service event distribution and fan-out. Implement idempotent consumers with a `processed_events` table in PostgreSQL — Kafka's exactly-once semantics don't extend to external databases. Use the Graphile Worker job-as-outbox pattern to bridge: enqueue a publishing job in the same transaction as your business write, and the job publishes to Kafka when it executes.

**Temporal** is the right choice for workflows that span multiple services, require compensation logic, run for extended periods, or involve complex conditional branching. Start with Temporal Cloud to avoid the operational burden of self-hosting four services plus a database cluster. Use Worker Versioning from the beginning to enable safe deployments. Design activities to be idempotent using composite idempotency keys from `workflow_run_id + activity_id`. Reserve Temporal for genuinely complex orchestration — simple fire-and-forget jobs don't warrant the additional infrastructure.

The key insight across all of these patterns is that **at-least-once delivery is the universal reality**. No framework provides true exactly-once execution of side effects. The entire reliability model — idempotency keys, check-before-work, terminal states, deduplication tables — exists to make at-least-once behave like exactly-once at the application level. Build this into every job handler from day one, and the choice of framework becomes a question of operational preference rather than correctness guarantees.