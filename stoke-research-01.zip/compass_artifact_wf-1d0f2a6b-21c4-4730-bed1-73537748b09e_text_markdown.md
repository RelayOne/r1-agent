# Production networking across Cloudflare, GCP, Fly.io, and Firecracker

**Every production outage you'll remember starts with a networking failure you didn't plan for.** This guide covers the 10 critical domains of operational networking knowledge — TLS lifecycle, mTLS, DNS, HTTP/2-3, connection management, load balancing, security, IPv6, proxy detection, and debugging — with specific configurations and pitfalls for services deployed across Cloudflare's edge, GCP Cloud Run, Fly.io, and self-hosted Firecracker VMs communicating over gRPC and REST. All recommendations reflect the state of the art as of 2025–2026, including the CA/Browser Forum's vote to reduce maximum certificate lifetimes to 47 days, HTTP/3 reaching >95% browser support, and the shift toward zero-trust architectures as the default posture.

---

## 1. TLS certificate lifecycle automation

### ACME protocol and Let's Encrypt in 2025–2026

The ACME protocol (RFC 8555) automates certificate issuance through a challenge-response flow: create account → create order → prove domain control → finalize → download certificate. **Let's Encrypt announced a roadmap to shorten lifetimes**: opt-in 45-day certificates in May 2026, mandatory 64-day by February 2027, and 45-day by February 2028. The CA/Browser Forum voted for 47-day maximums industry-wide. Certbot 4.1.0 (June 2025) added ACME Renewal Information (ARI) support, where the CA tells the client the optimal renewal window.

**DNS-01 vs HTTP-01 challenges** dictate your automation strategy. HTTP-01 places a token at `http://<domain>/.well-known/acme-challenge/<token>`, requires port 80, and cannot issue wildcards. DNS-01 creates a `_acme-challenge.<domain>` TXT record, supports wildcards, and works for internal services unreachable from the internet. Use DNS-01 with Cloudflare's API for wildcard certificates:

```bash
# /etc/letsencrypt/cloudflare.ini (chmod 600)
dns_cloudflare_api_token = YOUR_SCOPED_API_TOKEN

certbot certonly --dns-cloudflare \
  --dns-cloudflare-credentials /etc/letsencrypt/cloudflare.ini \
  -d "*.example.com" -d example.com
```

Automate renewal via systemd timers (preferred over cron for jitter support):

```ini
# /etc/systemd/system/certbot-renewal.timer
[Timer]
OnCalendar=*-*-* 00,12:00:00
RandomizedDelaySec=3600
Persistent=true
```

**Platform-specific behavior varies dramatically.** Cloudflare manages Universal SSL at the edge automatically — no certbot needed. GCP Cloud Run provisions and rotates certificates for custom domains via Google-managed TLS. Fly.io auto-provisions Let's Encrypt certificates. Only self-hosted Firecracker VMs require full certbot automation with deploy hooks (`--deploy-hook "systemctl reload nginx"`).

### Internal CA: Vault PKI and step-ca

For service-to-service encryption, run your own CA. HashiCorp Vault's PKI secrets engine is the production standard:

```bash
vault secrets enable -path=pki_int pki
vault write pki_int/roles/my-service \
  allowed_domains="service.internal" \
  allow_subdomains=true max_ttl=72h key_type=ec key_bits=256

# Issue a 24-hour certificate
vault write pki_int/issue/my-service \
  common_name="api.service.internal" ttl=24h
```

Vault Agent auto-renews certificates via templates, triggering service reloads when certs change. **Vault 1.14+ supports ACME natively**, acting as an internal ACME server that existing tooling (certbot, Caddy) can use.

Smallstep's step-ca is a lighter alternative with full ACME support, OIDC integration, and SSH certificates. Configure short-lived defaults (`defaultTLSCertDuration: 24h`) to eliminate the need for CRL/OCSP — certificates simply expire before compromise becomes relevant.

### Certificate rotation without downtime

The key to zero-downtime rotation is **per-handshake certificate resolution**. In Go, use the `GetCertificate` callback on `tls.Config`:

```go
type CertReloader struct {
    mu   sync.RWMutex
    cert *tls.Certificate
}

func (cr *CertReloader) GetCertificate(*tls.ClientHelloInfo) (*tls.Certificate, error) {
    cr.mu.RLock()
    defer cr.mu.RUnlock()
    return cr.cert, nil
}
// Watch filesystem with fsnotify, reload atomically via RWMutex
```

In Node.js, call `server.setSecureContext(newOpts)` — existing connections continue on old certs, new handshakes use the new certificate. In Rust, rustls uses `Arc<ServerConfig>` — build a new config and atomically swap the Arc. The `ResolvesServerCert` trait provides dynamic per-handshake resolution. Nginx handles this via `nginx -s reload`, which spawns new workers with new certs while old workers drain connections gracefully.

### Monitoring and alerting

Monitor certificate expiration with Prometheus blackbox_exporter's `probe_ssl_earliest_cert_expiry` metric. Set three-tier alerts:

```yaml
- alert: SSLCertExpiring30Days
  expr: probe_ssl_earliest_cert_expiry - time() < 86400 * 30
  labels: { severity: warning }
- alert: SSLCertExpiring7Days
  expr: probe_ssl_earliest_cert_expiry - time() < 86400 * 7
  labels: { severity: page }
```

**Common pitfall:** Certificate monitoring only checks the leaf certificate. Intermediate CA expiration (which happens less often but causes equally catastrophic outages) requires separate monitoring with `openssl verify -CAfile`.

---

## 2. mTLS between services

### Implementation patterns across languages

**Go** provides the most explicit mTLS API. Set `ClientAuth: tls.RequireAndVerifyClientCert` on the server and load client certificates into the transport on the client. The critical detail is `ClientCAs` (server verifies client) vs `RootCAs` (client verifies server) — confusing these is the #1 mTLS misconfiguration in Go:

```go
// Server: verify client certificates
tlsConfig := &tls.Config{
    ClientAuth:   tls.RequireAndVerifyClientCert,
    ClientCAs:    caCertPool,  // CA that signed client certs
    Certificates: []tls.Certificate{serverCert},
    MinVersion:   tls.VersionTLS12,
}

// Client: present certificate, verify server
transport := &http.Transport{
    TLSClientConfig: &tls.Config{
        Certificates: []tls.Certificate{clientCert},
        RootCAs:      caCertPool,  // CA that signed server cert
    },
}
```

**Rust (rustls + tokio-rustls)** enforces safety by design — certificate verification cannot be disabled in the main API. Use `WebPkiClientVerifier::builder()` for server-side client verification. Note that rustls requires Rust 1.83+ and uses aws-lc-rs for cryptography by default.

**Node.js** mTLS uses `requestCert: true` and `rejectUnauthorized: true` in the HTTPS server options. **Never set `rejectUnauthorized: false` in production** — this disables all certificate validation and is the most common Node.js TLS vulnerability.

### Service mesh vs application-level mTLS

**Istio** provides automatic mTLS with zero application changes. Migrate safely: set mesh-wide `PeerAuthentication` to `PERMISSIVE` (accepts both plaintext and mTLS), then switch per-namespace to `STRICT`, then mesh-wide `STRICT`. Resource overhead is **~100m CPU and 128Mi RAM per Envoy sidecar**.

**Linkerd** enables mTLS by default with zero configuration. Its Rust-based proxies use **~10MB memory per proxy** (vs Envoy's ~40-50MB) and show **163ms faster p99 latency** at 2000 RPS compared to Istio.

For **non-Kubernetes platforms** (Firecracker VMs, bare metal), application-level mTLS or SPIFFE/SPIRE is the path. SPIFFE assigns workload identities as URIs (`spiffe://trust-domain/workload-path`), and SPIRE agents on each node automatically issue and rotate short-lived X.509 SVIDs (typically 1-hour lifetime) via a Unix socket API. Never write SVID keys to disk — use in-memory delivery via Envoy SDS.

### Platform-specific mTLS approaches

**Cloudflare Authenticated Origin Pulls** provide mTLS from edge to origin — Cloudflare presents a client certificate when connecting to your backend. Use custom certificates (not the shared Cloudflare cert) for stronger authentication that proves the request came from *your* Cloudflare zone specifically.

**GCP Cloud Run** primarily uses IAM + identity tokens for service-to-service auth, not mTLS. Cloud Run doesn't natively terminate inbound mTLS.

**Fly.io** encrypts internal traffic via WireGuard automatically. Services communicate over `.internal` DNS with network-level encryption. For defense-in-depth, add application-level mTLS on top.

**Firecracker VMs** require full application-level mTLS implementation. Use Vault PKI or step-ca as the internal CA, deploy SPIRE agents on each VM, and consider WireGuard as an additional network-level encryption layer.

---

## 3. DNS operational patterns

### TTL selection strategy

TTL governs the tradeoff between failover speed and DNS query volume. **Low TTLs (30–60s)** enable fast failover but increase query volume by 60–80% compared to high TTLs. **High TTLs (3600s)** reduce load but make failover slow. Recommended values by record type:

- **A/AAAA (stable production):** 3600–86400s
- **A/AAAA (health-checked failover):** 30–300s
- **NS records:** 86400–172800s
- **SOA MINIMUM (negative cache):** 60–300s — set this low to prevent NXDOMAIN from being cached during deployments

**The migration TTL pattern** is non-negotiable: lower TTL to 60–300s at least 48 hours before any DNS change, wait for the old TTL to expire fully, make the change, verify, then raise TTL back. Cloudflare proxied records have a fixed 300s TTL that you cannot change — use Cloudflare Load Balancing for proxy-layer failover that bypasses DNS TTL entirely.

### DNS failover and health-checked DNS

Cloudflare Load Balancing probes from 200+ data centers with configurable intervals, thresholds, and expected response codes. For Pro+ plans, when the primary origin fails during TCP/TLS connection, Cloudflare **automatically retries alternate origins without any DNS change** — failover happens at the proxy layer in milliseconds rather than minutes.

Route 53 health-checked failover requires TTL ≤ 60s on failover records. Typical failover time: 1–3 minutes (health check interval × failure threshold + TTL propagation). Use calculated health checks to combine multiple probes with AND/OR logic.

### Critical DNS pitfalls

**Negative caching** is the silent killer during deployments. If a DNS query for a not-yet-created record returns NXDOMAIN, that response gets cached for the SOA MINIMUM TTL. Create DNS records *before* deploying services, never after. Set SOA MINIMUM to 60–300s for dynamic zones.

**The Kubernetes `ndots:5` problem** causes every external hostname with fewer than 5 dots to trigger search path expansion — `google.com` generates 5+ queries before the actual resolution. Fix with trailing dots (`google.com.`) or set `ndots: 1` for pods making primarily external calls.

**musl vs glibc DNS** differences break Alpine containers silently. musl sends queries to all nameservers in parallel (first response wins), didn't support DNS over TCP until version 1.2.4 (Alpine 3.20+), and behaves differently with search domains. For DNS-heavy workloads, use Debian-slim or Alpine 3.20+, or run dnsmasq as a local caching resolver.

**Nginx caches DNS forever at startup** by default. Use the `resolver` directive with an explicit TTL. The JVM similarly caches DNS indefinitely — set `networkaddress.cache.ttl=30`.

### Split-horizon DNS and service discovery

GCP Cloud DNS private zones return different answers based on whether the query originates from an authorized VPC. Fly.io provides `.internal` DNS where `<appname>.internal` resolves to AAAA records of all running machines, `<region>.<appname>.internal` targets specific regions, and `<machine_id>.vm.<appname>.internal` addresses individual machines. For self-hosted Firecracker, run CoreDNS with the `file` plugin for internal zones and `forward` to public resolvers for everything else.

---

## 4. HTTP/2 and HTTP/3 in production

### HTTP/2 configuration changes in 2025

**Nginx 1.25.1 deprecated the `listen ... http2` parameter.** The new syntax uses `http2 on;` as a separate directive. This is a breaking change when managing mixed-version fleets — Ubuntu 24.04 LTS ships nginx 1.24 (old syntax), while newer versions require the new form:

```nginx
# nginx 1.25.1+ (new, correct)
server {
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;
}
```

Nginx also **removed HTTP/2 server push entirely** in 1.25.1 (Chrome dropped support in 2022). Use `103 Early Hints` instead. Caddy enables HTTP/2 automatically with zero configuration — it handles ALPN negotiation, TLS, and protocol selection transparently.

### gRPC requires HTTP/2 — and this creates load balancing problems

gRPC mandates HTTP/2. Use **h2c** (cleartext HTTP/2) for internal services behind a TLS-terminating proxy, and **h2** (HTTP/2 over TLS) for external endpoints. The critical nginx pitfall: `grpc_pass` and `proxy_pass` are different directives — you cannot use `proxy_pass` for gRPC traffic.

```nginx
# Nginx gRPC proxy: TLS terminated, h2c to backend
location /grpc/ {
    grpc_pass grpc://grpc_backend;  # NOT proxy_pass
}
```

Caddy simplifies this with `reverse_proxy h2c://localhost:50051`. GCP Cloud Run supports all gRPC RPC types (unary, streaming, bidirectional) when you enable HTTP/2 end-to-end via `gcloud run services update SERVICE --use-http2` — the container must serve h2c. Cloudflare proxies gRPC using an internal gRPC-Web conversion; **Cloudflare Workers cannot natively call gRPC services** due to lacking HTTP/2 streaming support.

### HTTP/3 (QUIC) has reached production readiness

Browser support exceeds **95%** (Chrome since 2020, Firefox since 2021, Safari since 16.4). Cloudflare reports ~30% of HTTP requests use HTTP/3. Server support varies: Caddy has HTTP/3 enabled by default since v2.6.0 (best out-of-box experience). Nginx supports HTTP/3 since 1.25.0 but requires a special build with BoringSSL or QuicTLS — **standard OpenSSL cannot be used** due to an API incompatibility that persists even in OpenSSL 3.5. This is a significant operational consideration for self-hosted Firecracker deployments.

```nginx
# nginx HTTP/3 (requires BoringSSL build)
listen 443 quic reuseport;
http3 on;
quic_retry on;          # Address validation
add_header Alt-Svc 'h3=":443"; ma=86400' always;
```

**0-RTT (Zero Round-Trip Time)** enables instant connection resumption but is vulnerable to replay attacks. Only allow idempotent/safe requests in 0-RTT data and return `425 Too Early` for state-changing operations.

### HTTP/2 rapid reset attack mitigations

CVE-2023-44487 (CVSS 7.5) exploited stream creation/cancellation at minimal client cost but significant server cost. Google mitigated **398 million requests per second**. Keep nginx's `http2_max_concurrent_streams` at the default 128, don't inflate `keepalive_requests` beyond necessity, and ensure all HTTP/2 implementations are patched (Go 1.21.3+, updated Envoy, etc.).

---

## 5. Connection management

### The Go connection pooling trap

Go's `http.DefaultTransport` sets **`MaxIdleConnsPerHost = 2`** — this is the #1 HTTP performance bug in Go applications. With the default, 98 out of 100 connections are closed and left in TIME_WAIT. Production configuration must increase this:

```go
t := http.DefaultTransport.(*http.Transport).Clone()
t.MaxIdleConns = 100
t.MaxIdleConnsPerHost = 100  // CRITICAL: increase from default 2
t.MaxConnsPerHost = 100
t.IdleConnTimeout = 90 * time.Second
```

The second universal pitfall: **creating a new `http.Client` per request** destroys connection reuse entirely. Always reuse clients. The same applies to Rust's `reqwest::Client` and Node.js undici `Agent` — construct once, reuse globally.

For **Node.js**, undici (powering native `fetch` since Node 18) replaces the legacy `http.Agent`. Configure with `new Agent({ connections: 128, keepAliveTimeout: 4000 })` and set as global dispatcher. Undici supports HTTP pipelining (`pipelining: 2`) for 134% speedup over non-pipelined HTTP/1.1.

### gRPC channel management for load balancing

gRPC's persistent HTTP/2 connections create a critical load balancing problem: **new pods after scale-out never receive traffic** because existing channels maintain connections to old pods. The solution is `MaxConnectionAge` on the server, which forces periodic reconnection:

```go
kasp := keepalive.ServerParameters{
    MaxConnectionAge:      5 * time.Minute,  // Force reconnection for LB
    MaxConnectionAgeGrace: 5 * time.Second,  // Grace for in-flight RPCs
}
```

Datadog runs this in production at scale. The server sends GOAWAY, the client reconnects, re-resolves DNS, and discovers new pods. A ±10% jitter is automatically added to prevent connection storms.

Client-side keepalive pings detect dead connections through proxies with idle timeouts. Set `Time: 30s` (must be ≥ server's `MinTime`), `Timeout: 10s`, and ensure the load balancer's idle timeout exceeds the keepalive interval.

### WebSocket and TCP keepalive

WebSocket ping/pong frames (RFC 6455) must be sent every **20–30 seconds** to stay under proxy idle timeouts (typically 60s). Browsers cannot send pings — implement server-initiated pings with `isAlive` tracking. Reconnection should use exponential backoff starting at 500ms, doubling to a 30s cap, with ±30% random jitter to prevent thundering herd.

**TCP_NODELAY should be enabled for virtually all distributed systems.** Nagle's algorithm buffers small packets until ACK received, adding up to 200ms latency that interacts badly with Delayed ACK (another 200ms). Modern HTTP libraries enable it by default, but verify. Reduce `tcp_keepalive_time` from the Linux default of 7200s to **600s** for cloud environments where NAT gateways have idle timeouts of 5–10 minutes.

---

## 6. Load balancing patterns

### L7 is mandatory for gRPC

HTTP/2 multiplexing means an L4 load balancer sends **all streams to one backend** — defeating the purpose of load balancing entirely. Solutions ranked by preference:

1. **L7 proxy (Envoy):** Routes each RPC independently. Gold standard. Configure with `lb_policy: ROUND_ROBIN` and gRPC health checking.
2. **L4 LB + MaxConnectionAge:** Simpler. Server forces reconnection every 5 minutes → client re-resolves DNS → discovers new backends.
3. **Client-side load balancing:** Best latency (no proxy hop). Use `round_robin` policy with Kubernetes headless services that expose individual pod IPs. Standard ClusterIP returns a single IP and breaks `round_robin`.
4. **xDS/look-aside LB:** Full Envoy xDS protocol support in gRPC clients. Most complex to operate.

### Connection draining done right

The correct SIGTERM handling sequence in Go:

```go
ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGTERM)
defer stop()
<-ctx.Done()
shutdownCtx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
server.Shutdown(shutdownCtx) // Stops accepting, waits for in-flight
```

In Kubernetes, the sequence matters: pod marked terminating → removed from endpoints → **preStop hook (sleep 5s to let LB deregister)** → SIGTERM → drain → SIGKILL after `terminationGracePeriodSeconds`. The `sleep 5` in preStop is essential because endpoint removal is asynchronous.

**GCP Cloud Run** sends SIGTERM with a default 10s grace period (configurable to 60 minutes). **Fly.io** sends SIGINT by default (not SIGTERM) — set `kill_signal = "SIGTERM"` in `fly.toml` and `kill_timeout` up to 24 hours.

### Algorithms: when to use each

**Round robin** for stateless APIs with homogeneous backends. **Least connections** for variable request durations and WebSockets. **Power of two choices (P2C)** for high-scale distributed load balancers with no global coordination — Envoy selects 2 random hosts and picks the one with fewer active requests. **Consistent hashing** (Ketama or Maglev) for cache layers where key affinity matters. **Bounded-load consistent hashing** (balance factor c=1.25) gives the best of both: cache locality with no server exceeding 125% of average load.

---

## 7. Network security

### Firewall rules as code

For Firecracker VMs, manage nftables via Ansible. Use the `inet` family for unified IPv4/IPv6 rules:

```nft
table inet firewall {
  chain input {
    type filter hook input priority 0; policy drop;
    ct state {established,related} accept
    tcp dport 443 accept
    tcp dport 22 ip saddr 203.0.113.0/24 accept
  }
  chain output {
    type filter hook output priority 0; policy drop;
    ct state {established,related} accept
    tcp dport {80,443} accept
    udp dport 53 accept
  }
}
```

GCP VPC firewall rules in Terraform should use **service accounts** (not network tags) for production targeting, use hierarchical firewall policies at org/folder level for critical rules, and enable firewall logging on sensitive rules. Start Cloudflare's OWASP WAF ruleset in **log mode for weeks** before switching to block — false positives in production are worse than the threats you're blocking.

### Egress filtering prevents supply chain attacks

Without egress controls, compromised workloads establish C2 connections and exfiltrate data freely. Deploy Squid proxy with domain allowlisting, Cloudflare Gateway for DNS/HTTP/network-layer filtering, or Cilium's FQDN-based egress policies in Kubernetes. **Always allow DNS (port 53) in egress rules** scoped to your DNS resolver — blocking DNS breaks everything silently.

### Cloudflare Tunnel eliminates exposed ports

`cloudflared` creates **4 outbound-only connections** to different Cloudflare servers across at least 2 data centers (built-in HA). Your origin needs zero inbound ports open. Combine with Cloudflare Access for identity-verified requests — the tunnel validates JWT tokens before proxying to origin. Deploy multiple `cloudflared` replicas for production redundancy.

### Private networking across platforms

**Fly.io 6PN** provides automatic private IPv6 networking for all apps in an organization using `fdaa::/16` with BPF-enforced isolation — zero configuration required. **Tailscale** overlays WireGuard mesh networking with MagicDNS and version-controlled ACL policies. For GCP, **Private Service Connect** enables private access to services across VPC boundaries without peering, and setting Cloud Run ingress to "internal" rejects internet traffic entirely.

---

## 8. IPv6 readiness

### Rate limiting must use prefix-based bucketing

A single residential user gets a /64 (**2⁶⁴ addresses**). Per-IP rate limiting is completely ineffective — attackers rotate through their allocation trivially. **Rate limit by /64 prefix** (analogous to a single IPv4 address), with optional secondary limits at /56 and /48:

```nginx
map $remote_addr $rate_limit_key {
    "~^(?P<prefix>[0-9a-fA-F]+:[0-9a-fA-F]+:[0-9a-fA-F]+:[0-9a-fA-F]+):" $prefix;
    default $binary_remote_addr;
}
limit_req_zone $rate_limit_key zone=api:20m rate=60r/m;
```

Cloudflare rate limits per /64 prefix. Let's Encrypt limits account creation per /48. Google Cloud Armor IPv6 rules use subnet masks no larger than /64.

### Dual-stack configuration and Apple's IPv6 mandate

Apple requires all App Store apps to work on IPv6-only networks via NAT64/DNS64 — rejection during review is common when apps use hardcoded IPv4 literals or IPv4-specific socket APIs. Go's `net.Listen("tcp", ":8080")` creates a dual-stack socket on Linux, but on OpenBSD it does NOT accept IPv4. For nginx, use explicit dual-stack with `ipv6only=on`:

```nginx
listen 443 ssl;
listen [::]:443 ssl ipv6only=on;
```

Cloudflare enables IPv6 by default on all domains, acting as an IPv6 gateway that accepts IPv6 from clients and connects to IPv4-only origins. Fly.io provides a **free dedicated Anycast IPv6 address** per app. GCP Cloud Run supports dual-stack subnets in custom-mode VPCs with Premium Tier networking.

### IPv6 firewall rules must mirror IPv4

The most common IPv6 security vulnerability is securing IPv4 while leaving IPv6 wide open. **Never block ICMPv6 types 133–136** (NDP) on host firewalls — IPv6 will stop working entirely. Always allow `packet-too-big` (type 2) for Path MTU Discovery. Use nftables `inet` family for unified rules that apply to both address families.

---

## 9. Proxy and corporate firewall detection

### Corporate MITM proxies break certificate validation

Enterprise proxies (Zscaler, Palo Alto, Fortigate) intercept HTTPS by replacing server certificates with ones signed by a corporate CA. Applications that don't trust this CA fail with certificate errors. Solutions per language:

- **Node.js:** `NODE_EXTRA_CA_CERTS=/path/to/corporate-ca.pem` (must be set before Node starts)
- **Go:** `x509.SystemCertPool()` automatically includes system-installed CAs
- **Rust/OpenSSL:** `SSL_CERT_FILE=/path/to/ca-bundle.pem`

**Certificate pinning directly conflicts with MITM inspection.** Chrome and browsers skip pin validation for private trust anchors by design. For applications, use conditional pinning (only enforce when not behind a corporate proxy, detected by checking the issuer) or replace pinning with Certificate Transparency monitoring.

### Electron proxy detection

Electron's `session.resolveProxy(url)` returns PAC-style strings (`"PROXY proxy:8080"` or `"DIRECT"`). **Key pitfall:** `resolveProxy()` does NOT return credentials from OS proxy settings (Electron issue #20215). For Node.js HTTP requests from the main process, use `electron-proxy-agent` to bridge Electron's proxy detection to Node's HTTP stack.

### WPAD is a security risk

WPAD (Web Proxy Auto-Discovery) is enabled by default on Windows. Devices broadcast for PAC files on any network, enabling **name collision attacks** (SentinelOne documented active exploitation for years), URL leakage (FindProxyForURL receives full URLs including tokens), and even RCE via the Windows JScript engine (Google Project Zero). **Disable WPAD on all systems not explicitly requiring it.** PAC file execution via `pac-proxy-agent` had a critical sandbox escape vulnerability (CVE-2021-23406) fixed in v5+.

### Mobile apps behind corporate proxies

iOS `NSURLSession` respects system proxy settings automatically. Android apps targeting API 24+ only trust system CAs by default (not user-installed). For corporate environments, add the corporate CA to Android's Network Security Config. **Google now recommends against certificate pinning** for most Android apps due to brittleness (usage dropped to ~0.9%) — always include backup pins and expiration dates if pinning is used.

---

## 10. Network debugging tools and patterns

### curl timing breakdown isolates the bottleneck

The single most useful debugging command for production networking:

```bash
curl -o /dev/null -s -w "\n\
  DNS:       %{time_namelookup}s\n\
  TCP:       %{time_connect}s\n\
  TLS:       %{time_appconnect}s\n\
  TTFB:      %{time_starttransfer}s\n\
  Total:     %{time_total}s\n" https://example.com
```

**Interpret the diffs:** `time_connect - time_namelookup` = TCP RTT. `time_appconnect - time_connect` = TLS handshake time. `time_starttransfer - time_appconnect` = server processing time. Use `--resolve example.com:443:10.0.0.1` to test a specific backend without DNS, and `--cert`/`--key` for mTLS testing.

### TLS debugging with SSLKEYLOGFILE

Set `SSLKEYLOGFILE` to export TLS session keys for Wireshark decryption — this works with all TLS versions including 1.3:

```go
// Go
tlsConfig := &tls.Config{KeyLogWriter: keyLogFile}
```

```bash
# Node.js (v20+)
node --tls-keylog=/tmp/tls-keys.log app.js
```

Rustls supports `SSLKEYLOGFILE` natively via environment variable. Configure Wireshark at Preferences → Protocols → TLS → Pre-Master-Secret log filename.

### tcpdump recipes for production

```bash
# TLS Client Hello only
tcpdump -n 'tcp port 443 and (tcp[((tcp[12] & 0xf0) >> 2)] = 0x16) \
  and (tcp[((tcp[12] & 0xf0) >> 2)+5] = 0x01)'

# DNS queries
tcpdump -i eth0 -n 'udp port 53 or tcp port 53'

# RST packets (connection failures)
tcpdump -i eth0 'tcp[tcpflags] & (tcp-rst) != 0'
```

For containers without tcpdump: use `kubectl debug -it <pod> --image=nicolaka/netshoot --target=<container>` or `nsenter -t $(docker inspect -f '{{.State.Pid}}' my-app) -n tcpdump`. The netshoot image includes tcpdump, curl, dig, mtr, and other essential tools.

### Application-level HTTP tracing

**Go's `net/http/httptrace`** provides per-request hooks for DNS resolution, TCP connection, TLS handshake, and first byte timing — integrate with OpenTelemetry via `otelhttptrace.NewClientTrace(ctx)`. **Node.js native fetch** (undici-based) does NOT work with `NODE_DEBUG=http` — use `diagnostics_channel` subscriptions on `undici:request:create`, `undici:request:headers`, and `undici:request:error` channels. **Rust** uses `RUST_LOG=reqwest=debug,hyper=debug` with the tracing crate and tower-http's `TraceLayer` for server-side request tracing.

### DNS debugging essentials

```bash
dig +trace example.com        # Full resolution path
dig @8.8.8.8 example.com A    # Query specific resolver
dig +short example.com AAAA   # Quick IPv6 check
```

For certificate chain verification: `openssl s_client -connect host:443 -servername hostname -showcerts` reveals the full chain, and `step certificate inspect https://example.com` from Smallstep provides human-readable output. Use `mtr --tcp -P 443 example.com` for TCP-mode traceroute that bypasses ICMP-blocking firewalls, and `ss -ti` for socket statistics including per-connection RTT.

---

## Conclusion

The operational landscape for production networking in 2025–2026 is defined by three converging trends. **Certificate lifetimes are collapsing** — from 90 days to 47 days and eventually shorter — making automated lifecycle management non-optional and short-lived certificates (24-hour via Vault PKI or step-ca) the strategic bet. **HTTP/3 has crossed the production threshold** with >95% browser support and mature server implementations in Caddy and Cloudflare, though nginx's dependency on BoringSSL for QUIC remains a friction point for self-hosted deployments. **Zero-trust networking has moved from philosophy to implementation**, with Cloudflare Tunnel, Tailscale ACLs, and Fly.io 6PN providing practical zero-inbound-port architectures across all four deployment targets.

The most impactful operational changes to make immediately: increase Go's `MaxIdleConnsPerHost` from the disastrous default of 2, set gRPC `MaxConnectionAge` to 5 minutes for proper load distribution, rate limit IPv6 by /64 prefix rather than individual addresses, use `ndots: 1` in Kubernetes pods making external DNS queries, and pre-lower DNS TTLs 48 hours before any migration. These five changes alone prevent the majority of production networking incidents.