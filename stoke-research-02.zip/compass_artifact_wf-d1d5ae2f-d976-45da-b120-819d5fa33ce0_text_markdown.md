# Production-grade IaC across GCP, Cloudflare, Fly.io, and DigitalOcean

Terraform remains the dominant IaC tool for multi-cloud deployments, but its ecosystem has evolved dramatically through 2025–2026. **GCS backends now lock state automatically without extra configuration**, Terraform 1.5+ import blocks have replaced imperative imports, the Cloudflare provider v5 is stabilizing after a rocky launch, and **the Fly.io Terraform provider has been archived** — making flyctl the only supported path. Meanwhile, HashiCorp has shipped both an MCP server and Agent Skills for Claude Code, and Pulumi's Automation API offers capabilities Terraform fundamentally cannot match. This report covers all ten requested areas with production-grade depth.

---

## 1. Terraform advanced patterns for module composition, state, and refactoring

### Module composition favors flat trees over deep nesting

HashiCorp recommends keeping module trees flat — one level of child modules composed in the root module via **dependency inversion**. Modules receive dependencies as inputs rather than creating them internally. This pattern decouples modules and enables flexible composition:

```hcl
module "network" {
  source         = "./modules/networking"
  base_cidr_block = "10.0.0.0/8"
}

module "database" {
  source     = "./modules/cloud-sql"
  vpc_id     = module.network.vpc_id
  subnet_ids = module.network.private_subnet_ids
}
```

Nesting is appropriate only when a sub-module is an encapsulated implementation detail owned by its parent. For multi-cloud abstraction, create **separate cloud-specific modules with a common variable interface** — same variable names and output contracts, but no unified facade. The "wrapper module" pattern that switches providers based on a `cloud` variable creates opaque configurations and debugging nightmares (the "Wrapper Tax" anti-pattern recognized across the community since 2024).

For versioned modules, use **semantic versioning** with pessimistic constraints in staging (`version = "~> 5.5.0"` allows patches only) and exact pins in production (`version = "5.5.1"`). The `version` argument only works with registry sources; for Git, pin with `?ref=v1.2.0`. Private registries (HCP Terraform, Scalr, GitLab, Artifactory) auto-discover SemVer tags matching `^v?[0-9]+\.[0-9]+\.[0-9]+$`.

### Workspaces are not for environment separation

**Strong community consensus: use separate directories, not workspaces, for dev/staging/prod.** HashiCorp's own docs state workspaces "are not appropriate for system decomposition or deployments requiring separate credentials and access controls." The dangers are real — an engineer thinking they're in `dev` who runs `terraform destroy` while actually in `prod` finds no structural safeguard. All environments share the same `.tf` files, making production-only resources (monitoring, WAF) require scattered conditionals. Same credentials, hidden state context, and difficult code review compound the risk.

Workspaces are appropriate for **same configuration, different instances** — regional deployments of identical infrastructure, ephemeral feature-branch environments, or CI test environments.

### GCS backend provides built-in locking; S3 now has native locking too

**GCS backend configuration is the simplest production backend** — state locking is automatic with no additional resources:

```hcl
terraform {
  backend "gcs" {
    bucket             = "mycompany-terraform-state"
    prefix             = "terraform/prod"
    kms_encryption_key = "projects/myproject/locations/us/keyRings/ring/cryptoKeys/key"
  }
}
```

For S3, **Terraform 1.10+ supports native S3 locking** via `use_lockfile = true`, eliminating the DynamoDB table requirement (deprecated in 1.11). The new mechanism uses S3 conditional writes to create a `.tflock` file alongside the state. Always enable bucket versioning for recovery.

**State file security is non-negotiable.** Terraform stores all resource attributes in plaintext in state — database passwords, API keys, TLS certificates. The `sensitive = true` marker only hides values from CLI output. Mitigations: restrict state bucket access via IAM (only CI/CD service accounts), never commit state to version control, enable encryption at rest (GCS encrypts by default; S3 needs `encrypt = true`), and use external secret managers for dynamic secrets rather than storing them in Terraform-managed resources.

### Import blocks and moved blocks have transformed refactoring

**Terraform 1.5+ import blocks** replace the imperative `terraform import` command with declarative, version-controlled imports:

```hcl
import {
  to = google_sql_database_instance.production
  id = "projects/myproject/instances/postgres-prod"
}
```

Pair with `terraform plan -generate-config-out=generated.tf` to auto-generate HCL from existing resources — always review and clean up the output. Import blocks support `for_each` for bulk operations and are one-time: remove them after successful apply.

**Moved blocks** (Terraform 1.1+) handle refactoring without destroy/recreate. Renaming resources, moving into modules, converting `count` to `for_each`, and chaining multi-version refactors all work declaratively. HashiCorp recommends retaining moved blocks indefinitely in shared modules. For cross-state moves (splitting monoliths), use the remove-and-import pattern: declare `removed { lifecycle { destroy = false } }` in the old config and `import {}` in the new one. **Terraform 1.7+ added the `removed` block** as a declarative alternative to `terraform state rm`.

---

## 2. Terraform for GCP: Cloud Run, Cloud SQL, VPC, IAM, and beyond

### Cloud Run v2 with secrets, VPC connectors, and traffic splitting

Use `google_cloud_run_v2_service` for all new deployments. Key production patterns include Gen2 execution environment for better performance, `cpu_idle = true` for request-driven cost savings, and secrets integration via both environment variables and volume mounts:

```hcl
resource "google_cloud_run_v2_service" "app" {
  name     = "my-app"
  location = "us-central1"
  ingress  = "INGRESS_TRAFFIC_INTERNAL_AND_CLOUD_LOAD_BALANCING"

  template {
    service_account           = google_service_account.app.email
    execution_environment     = "EXECUTION_ENVIRONMENT_GEN2"
    max_instance_request_concurrency = 80

    scaling {
      min_instance_count = 1
      max_instance_count = 10
    }

    containers {
      image = "us-central1-docker.pkg.dev/project/repo/app:latest"
      resources {
        limits   = { cpu = "2", memory = "1Gi" }
        cpu_idle = true
      }
      env {
        name = "DATABASE_PASSWORD"
        value_source {
          secret_key_ref {
            secret  = google_secret_manager_secret.db_password.id
            version = "latest"
          }
        }
      }
    }

    vpc_access {
      connector = google_vpc_access_connector.connector.id
      egress    = "PRIVATE_RANGES_ONLY"
    }
  }
}
```

A critical subtlety: environment variables referencing `latest` secret version are **not updated when a new version is added** — the revision must be redeployed. Volume mounts using `latest` do auto-update. For traffic splitting, define multiple `traffic` blocks targeting specific revision names with percentages.

### Cloud SQL PostgreSQL with private networking and production tuning

Production Cloud SQL requires **private service access** (VPC peering), HA with `availability_type = "REGIONAL"`, automated backups with PITR, and carefully tuned database flags. The `google_service_networking_connection` resource establishes the VPC peering required for private IP:

```hcl
resource "google_sql_database_instance" "postgres" {
  name                = "postgres-production"
  database_version    = "POSTGRES_16"
  deletion_protection = true

  settings {
    tier              = "db-custom-4-16384"
    availability_type = "REGIONAL"
    disk_type         = "PD_SSD"
    disk_autoresize   = true

    ip_configuration {
      ipv4_enabled    = false
      private_network = google_compute_network.main.id
    }

    backup_configuration {
      enabled                        = true
      point_in_time_recovery_enabled = true
      retained_backups               = 30
    }

    database_flags { name = "shared_buffers";    value = "4096000" }
    database_flags { name = "max_connections";   value = "200" }
    database_flags { name = "random_page_cost";  value = "1.1" }
    database_flags { name = "idle_in_transaction_session_timeout"; value = "300000" }
    database_flags { name = "cloudsql.enable_pg_stat_statements";  value = "on" }

    insights_config { query_insights_enabled = true }
  }
}
```

Set `shared_buffers` to 25% of RAM, `effective_cache_size` to 75%, and `random_page_cost = 1.1` for SSD. The `idle_in_transaction_session_timeout` prevents lock-holding and MVCC bloat.

### IAM: always use `google_project_iam_member` and Workload Identity Federation

**The critical IAM distinction:** `google_project_iam_member` is additive (safe alongside manual bindings), `google_project_iam_binding` is authoritative per-role (overwrites all members for that role), and `google_project_iam_policy` is authoritative for the entire project (can lock you out). **Default to `google_project_iam_member`** unless Terraform is the sole source of truth.

For CI/CD, **Workload Identity Federation with GitHub Actions OIDC** eliminates long-lived service account keys. Always include `attribute_condition` to restrict which repositories can impersonate the service account — without it, any GitHub repository could authenticate.

### terraform-google-modules and provider strategy

Google's Cloud Foundation Toolkit maintains **60+ official modules** at `terraform-google-modules`. The most valuable are `terraform-google-network` (VPC/subnets), `terraform-google-sql-db` (Cloud SQL with HA), `terraform-google-project-factory` (project provisioning), and `terraform-google-github-actions-runners` (includes WIF submodule). Use official modules when they cover >80% of your requirements; write your own when the module over-abstracts or uses older API versions.

Keep `hashicorp/google` and `hashicorp/google-beta` at the same version. Use `google-beta` only for features not yet GA. The Google provider releases minor versions weekly — pin with `~> 5.0` and use `.terraform.lock.hcl` for reproducibility.

---

## 3. Cloudflare Terraform provider: powerful but turbulent

### The v5 provider is stabilizing — production teams should proceed with caution

The Cloudflare Terraform provider **v5 launched January 2025**, auto-generated from Cloudflare's OpenAPI schemas. At launch, roughly **15% of resources had issues**. A resource-by-resource stabilization effort has brought the provider to **v5.17.0** (February 2026), but Cloudflare officially recommends holding off on v4→v5 migration until their planned March 2026 migration tool ships. The Grit migration scripts don't support Terraform modules — module users need manual migration.

### Workers, KV, D1, and R2 in Terraform

Worker deployment in v5 uses `cloudflare_workers_script` with `content_file` + `content_sha256` (added in v5.7.0) to avoid bloating state with large script bodies. **Terraform does not bundle Workers** — you must pre-build with Wrangler or esbuild before `terraform apply`. KV namespaces and bindings are Terraform-managed, but individual KV entries should be managed by application code (eventual consistency and state bloat make Terraform impractical for data entries).

D1 databases can be created via `cloudflare_d1_database`, but **when a D1 database is replaced, all data is lost** — ensure backups before any operation triggering replacement. No SQL migration support exists in Terraform; use `wrangler d1 execute` for schema management. R2 buckets support CORS, custom domains, lifecycle rules, event notifications, and object locks via dedicated v5 resources.

### WAF migration and modern rulesets

**Legacy WAF was fully deprecated June 15, 2025.** All WAF, rate limiting, URL rewrites, header modifications, and redirects now use `cloudflare_ruleset` with appropriate phases: `http_request_firewall_managed` for managed WAF, `http_request_firewall_custom` for custom rules, `http_ratelimit` for rate limiting, `http_request_transform` for URL rewrites, and `http_request_dynamic_redirect` for redirects. Always use the `ref` field on rules for stable IDs — without it, Terraform recreates rules on every change.

### Known gotchas that will bite you

The **API rate limit of 1,200 requests per 5 minutes** is the biggest operational concern. The v5 provider does not implement built-in rate limiting, so large configurations (11,000+ resources) trigger 429 errors during refresh. Workaround: split configurations into smaller root modules and use `-parallelism=5`. Additional gotchas include Terraform assuming complete control over rulesets (import existing dashboard rules with `cf-terraforming` first), WAF exception ordering dependencies, Durable Object bindings requiring a two-step apply, and `secret_text` bindings getting replaced on every deploy in some v5 versions.

---

## 4. Fly.io's Terraform provider is dead — flyctl is the only path

**The Fly.io Terraform provider (`fly-apps/terraform-provider-fly`) was archived on March 1, 2024** and is read-only. The last release was v0.0.23 (June 2023). It was always a community-contributed beta project, never officially maintained by Fly.io's core team. The `fly_machine` resource was beta, volumes were reported broken, and it never supported Postgres, Redis, secrets, autoscaling, health checks, deploy strategies, or internal networking.

Fly.io's official position: "We don't have a Terraform provider anymore, and that's intentional. It's not a great fit for how our platform works." Their Machines API's imperative lifecycle (create → start → stop → destroy) maps poorly to Terraform's declarative model.

**The recommended alternatives are `flyctl` + GitHub Actions** for most users, or the **Machines REST API** for custom orchestration. For teams needing cross-provider IaC that includes Fly.io, the pragmatic approach is managing Fly.io via shell provisioners, `local-exec` in Terraform calling flyctl, or a separate CI/CD pipeline. Fly.io's private networking (`.internal` DNS, Flycast load balancing, WireGuard 6PN) is configured exclusively through flyctl.

---

## 5. HashiCorp's MCP server and Agent Skills bring AI into Terraform workflows

### terraform-mcp-server exposes the full Terraform ecosystem to AI assistants

The **official HashiCorp MCP server** (v0.5.x, ~1,200 GitHub stars) provides three toolsets: `registry` for public provider/module/policy search, `registry-private` for organizational registries, and `terraform` for full HCP Terraform/Enterprise workspace management. Key tools include `search_providers` and `get_provider_details` for real-time documentation lookup, `create_workspace` and `create_run` for workspace operations, and `list_variable_sets`/`create_variable_in_variable_set` for variable management. Static resources expose the official Terraform style guide and module development guide.

Destructive operations are disabled by default (require `ENABLE_TF_OPERATIONS=true`). Setup is straightforward: `claude mcp add --transport http terraform http://localhost:8080/mcp` for HTTP mode, or Docker stdin for stdio mode.

### Agent Skills are the "textbooks" complementing the MCP "pipe"

**Announced February 2, 2026**, the `hashicorp/agent-skills` repository provides curated domain knowledge as Agent Skills (an open standard by Anthropic). Three Terraform plugin bundles are available:

**terraform-code-generation** includes `terraform-style-guide` (enforces HashiCorp formatting/naming conventions), `terraform-test` (native `.tftest.hcl` testing framework guidance including mock providers since Terraform 1.7), and `terraform-search-import` (discovering existing resources for brownfield adoption). **terraform-module-generation** includes `refactor-module` (transforms monolithic configs into reusable modules with success criteria checklists) and `terraform-stacks` (HCP Terraform Stacks for multi-region/multi-environment deployments). **terraform-provider-development** covers scaffolding new providers and running acceptance tests.

Install via Claude Code: `claude plugin install terraform-code-generation@hashicorp`. Skills activate automatically when working with Terraform files. HashiCorp partnered with Tessl to evaluate skills using both "review evals" and "task evals" running agents through real tasks.

Notable community alternatives include **antonbabenko/terraform-skill** (~4,400 tokens, comprehensive best practices from the creator of widely-used Terraform AWS modules) and **terrashark** (~600 tokens, 7-step diagnostic workflow).

---

## 6. Drift detection requires scheduled plans and a tiered remediation strategy

### `terraform plan` catches drift but misses unmanaged resources

Running `terraform plan -detailed-exitcode` in CI/CD on a schedule (every 4–6 hours) is the baseline drift detection mechanism. Exit code 2 means drift detected. The critical limitation: **plan only detects drift on resources in state** — it cannot find resources created outside Terraform via the console or CLI.

### The tool landscape has shifted significantly

**driftctl (Snyk) is effectively dead** — last release December 2023, in maintenance mode since June 2023. Do not adopt for new projects. **HCP Terraform Standard** includes built-in health assessments running refresh-only plans every ~24 hours at **$0.00014/resource/hour** beyond 500 free resources. **Spacelift** offers configurable drift detection with automatic reconciliation runs. **env0** provides AI-powered analysis (Cloud Compass) that assesses drift likelihood and identifies who made changes, plus smart auto-remediation that can auto-deploy code changes or auto-create PRs.

### The recommended tiered remediation approach

**Critical resources** (security groups, IAM, encryption): alert + page on-call, always require human review. **Standard resources** (compute, storage): alert + create ticket, review within SLA. **Low-risk resources** (tags, descriptions): auto-remediate with approval policies. To prevent drift, enforce CI/CD-only apply workflows, grant engineers read-only console access, tag all Terraform-managed resources (`ManagedBy=Terraform`), and use IAM deny policies that restrict modifications to resources unless the caller is the Terraform CI/CD role.

---

## 7. Security scanning: Checkov or Trivy, plus policy-as-code

### tfsec is dead — use Trivy or Checkov

**tfsec was merged into Aqua Security's Trivy** and is no longer actively developed. For new projects, use `trivy config ./terraform-directory` which provides the same checks plus container image, Kubernetes, and Dockerfile scanning in one tool. For maximum accuracy, scan both HCL files and `terraform plan` JSON output.

**Checkov** (Bridgecrew/Palo Alto) offers the broadest IaC coverage with **750+ built-in checks** and graph-based scanning that understands cross-resource relationships (e.g., "Is this instance in a public subnet exposed via a permissive security group?"). Custom policies can be written in Python, YAML, or Rego. **Terrascan** (Tenable) is built natively on OPA/Rego — ideal if your organization already uses OPA for Kubernetes admission control.

All three detect the same categories: hardcoded secrets, overly permissive IAM (`roles/owner`, `Action: *`), unencrypted storage, public-facing resources, missing logging, and insecure network configurations.

### Sensitive variables and the state file problem

`sensitive = true` only prevents CLI display — **values remain plaintext in state**. Terraform 1.10+ introduced `ephemeral = true` which omits values from state and plan files entirely. For secrets, combine environment variables (`TF_VAR_`) with CI/CD secret stores, or use HashiCorp Vault for dynamic short-lived credentials. Never commit `.tfvars` containing secrets.

### OPA for open-source policy enforcement, Sentinel for HCP Terraform

**OPA with Conftest** is the free, portable approach: `conftest test tfplan.json` evaluates Rego policies against plan output. **Sentinel** is HashiCorp-proprietary (HCP Terraform/Enterprise only) with native access to plan data and cost estimates. The recommended enterprise pattern: use OPA in CI for shift-left developer feedback, then Sentinel in HCP Terraform as the final enforcement gate before apply.

---

## 8. When Pulumi beats Terraform — and when it doesn't

### Complex logic, real testing, and the Automation API are Pulumi's winning scenarios

Pulumi treats infrastructure as software rather than configuration. TypeScript/Go provide real functions, classes, type safety, full IDE support, and native package ecosystems. Where Terraform requires fighting `for_each`, `dynamic` blocks, and `locals` for complex logic, Pulumi uses standard language constructs:

```typescript
const buckets = ["logs", "data", "backups"].map(name => {
  return new gcp.storage.Bucket(`${name}-bucket`, {
    name: `my-app-${name}-${environment}`,
    versioning: { enabled: name === "backups" },
  });
});
```

**Testing is Pulumi's strongest differentiator.** Unit tests run in milliseconds using mocks with Jest, `go test`, or pytest. Integration tests use the Automation API to provision real infrastructure. Terraform's `terraform test` (since 1.6) and Terratest are viable but cannot match Pulumi's mock-based unit testing speed or language-native test framework integration.

**The Automation API is Pulumi's unique capability with no Terraform equivalent.** It exposes the full Pulumi engine as an SDK, enabling programmatic infrastructure provisioning inside applications — self-service developer portals, per-customer SaaS provisioning, dynamic PR preview environments. CockroachDB, Snowflake, and Lemonade use it in production.

### When to stay with Terraform

Terraform's **4,800+ providers** dwarf Pulumi's ~1,500 (though Pulumi can bridge any Terraform provider). The community is significantly larger — more Stack Overflow answers, tutorials, and better GenAI code generation quality due to larger training data. HCL's intentional limitations are features for infrastructure-focused teams: no side effects, pure declaration, easier audit/compliance review. If HCL is "clumsy but not blocking," Terragrunt is a simpler answer than a full Pulumi migration.

### Multi-cloud provider coverage for your stack

GCP, Cloudflare, and DigitalOcean all have **official first-party Pulumi providers** with full resource coverage. Fly.io has only a community provider (`@ediri/pulumi-fly`) and is notably weaker — reflecting Fly.io's general resistance to declarative IaC tools.

Pulumi Cloud can now serve as a **Terraform state backend**, storing Terraform state alongside Pulumi stacks with encryption, locking, and RBAC. The `pulumi convert --from terraform` tool achieves ~90–95% automated conversion. Pulumi also supports executing Terraform modules directly within Pulumi programs via `pulumi package add terraform-module`, enabling incremental migration.

---

## 9. GitOps with Atlantis, cost estimation, and plan approval workflows

### Atlantis remains the gold standard for self-hosted Terraform GitOps

Atlantis embeds plan/apply into PR workflows: webhook triggers automatic `terraform plan`, output appears as a PR comment, and `atlantis apply` executes after approval. Its **locking mechanism prevents concurrent modifications** — if a PR is open against a directory, other PRs targeting the same directory are blocked until the lock releases.

Custom workflows enable pre-plan hooks (tflint, checkov, conftest) and post-plan hooks (Infracost, Slack notifications). Security requires webhook secret validation, GitHub App integration over PATs, cloud credentials in secret managers, and `apply_requirements: [approved, mergeable]` for mandatory review.

**HCP Terraform pricing deserves scrutiny.** Every managed resource counts individually — security group rules, IAM policies, S3 lifecycle configs. Teams frequently discover **30–50% more resources than expected**. The per-resource pricing model (~$0.47/resource/month on Standard) makes costs unpredictable. **Spacelift uses concurrency-based pricing** which is more predictable, supports Terraform + OpenTofu + Terragrunt + Pulumi + Ansible natively, and includes unlimited OPA policies in all tiers.

### Infracost makes infrastructure spending a deliberate decision

Infracost parses plan output, maps resources to cloud pricing APIs, and posts cost diffs as PR comments. It supports **1,100+ Terraform resources** across AWS, Azure, and GCP. The VS Code extension shows cost estimates inline as you write Terraform. Combine with Sentinel/OPA for automatic budget guardrails — block PRs exceeding thresholds.

### Plan approval workflows should enforce CODEOWNERS and policy gates

Use GitHub CODEOWNERS to require platform team review for all `.tf` files and additional security team review for production directories. Layer OPA/Conftest policy checks in CI (require encryption, restrict instance types, enforce tagging) and GitHub environment protection rules with required reviewers for production applies. The result: `terraform plan` → security scan → cost check → CODEOWNERS review → manual approval → `terraform apply`.

---

## 10. Multi-environment management: directories beat workspaces, Terragrunt beats both at scale

### The community strongly favors directory-based separation on a single branch

The recommended structure uses shared modules called from environment-specific root modules:

```
infrastructure/
├── modules/
│   ├── networking/
│   ├── cloud-run/
│   └── cloud-sql/
└── environments/
    ├── dev/
    │   ├── main.tf
    │   ├── terraform.tfvars
    │   └── backend.tf
    ├── staging/
    └── prod/
```

Each environment has its own state file, backend configuration, and variable values. Structural parity comes from shared modules; scale differences come from variables (`instance_type = "t3.small"` in dev vs `"t3.large"` in prod). This approach provides explicit visibility, separate blast radius, independent credentials, and clean code review.

### Terragrunt eliminates boilerplate at the cost of complexity

Terragrunt's `generate` blocks auto-create `backend.tf` and `provider.tf`, `dependency` blocks wire cross-module outputs, and `include` blocks inherit configuration hierarchically. `terragrunt run-all apply` resolves dependency order automatically. The tradeoff is an additional abstraction layer and a DSL to learn.

**Use Terragrunt when** managing 3+ environments with cross-module dependencies, multi-account or multi-region deployments, or teams of 5+ engineers. **Skip Terragrunt when** using Terraform Cloud or Spacelift (which solve the same problems natively), managing single environments, or when the team is still learning Terraform basics.

### Promoting changes through environments

The standard pipeline is dev → staging → prod with automated testing between stages. In the directory approach: modify `environments/dev/`, open PR, plan, review, apply. If successful, modify `environments/staging/` and repeat. For production, add manual approval gates via GitHub environment protection rules. Automated promotion (the Gruntwork Patcher pattern) creates PRs updating module versions sequentially through environments, with auto-apply in lower environments and mandatory human approval for production.

**Ephemeral feature-branch environments** work well with Terraform workspaces or dynamically keyed state. Create on PR open, destroy on PR close, tag with TTLs for safety, and use minimal infrastructure to control costs. This is one of the few scenarios where workspaces are appropriate — the infrastructure is truly identical across instances and transient by design.

---

## Conclusion

The production IaC landscape for multi-cloud deployments across GCP, Cloudflare, Fly.io, and DigitalOcean demands pragmatic tool choices rather than dogmatic allegiance. **GCP is best served by directory-based Terraform with the `hashicorp/google` provider**, shared modules, and GCS backends — the ecosystem is mature and well-documented. **Cloudflare requires pinning the provider carefully** (stay on v4 until the March 2026 migration tool ships, or audit v5 compatibility per-resource) and understanding that all WAF, rate limiting, and redirect rules now flow through `cloudflare_ruleset`. **Fly.io is a Terraform dead-end** — accept flyctl-based workflows or the Machines API and manage it separately from your Terraform stack. **DigitalOcean's Terraform provider is stable** and works well for both Terraform and Pulumi.

Three strategic choices have outsized impact on long-term maintainability. First, adopt **import blocks and moved blocks** aggressively — they make Terraform refactoring safe and reviewable, replacing the dangerous imperative `state mv` workflow. Second, implement **Infracost + OPA/Conftest + CODEOWNERS** in CI/CD — this combination catches security issues, cost surprises, and review gaps before they reach production. Third, evaluate **Pulumi's Automation API** honestly — if you're building self-service infrastructure platforms or per-tenant SaaS provisioning, Terraform fundamentally cannot do what the Automation API provides, and no amount of HCL will change that. For everything else, Terraform's ecosystem depth and hiring pool remain compelling advantages.