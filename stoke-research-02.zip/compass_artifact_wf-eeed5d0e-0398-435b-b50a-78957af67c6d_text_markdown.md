# The deep Kubernetes operations guide for teams that ship

Kubernetes delivers genuine value when your team reaches **10+ engineers with 2+ dedicated platform staff** managing **15+ services** that need fine-grained control over networking, scheduling, or compliance—but it will cost you $560K+ per year in staffing alone and 6+ months of ramp-up. For a team currently on Cloud Run and Fly.io, that threshold matters. This guide covers every operational domain you need to master before and after making the switch, distilled from production-tested patterns across GKE, EKS, and AKS.

The core tension is real: **70% of Kubernetes users cite operational complexity as their top pain point**, and average cluster CPU utilization sits at just 10%. But 93% of organizations use or evaluate K8s because nothing else gives you declarative GitOps, service mesh networking, namespace-level multitenancy, and a composable platform ecosystem in a single system. The decision isn't binary—it's about knowing exactly when the trade-off tips in Kubernetes's favor.

---

## 1. When Kubernetes actually earns its complexity

The strongest version of the "you probably don't need Kubernetes" argument comes from real numbers. A 6-person startup with 12,000 DAU ran 3 EKS clusters with 12 m5.xlarge workers and spent **$38,400/month**—absurdly overbuilt. Meanwhile, a $5M ARR SaaS business ships daily on six DigitalOcean droplets with no containers at all. One startup lost six months of feature development to a K8s migration while competitors shipped weekly on Heroku.

The counterpoints are equally concrete. Kubernetes replaces 8–10 standalone tools: load balancing, service discovery, DNS, config management, secrets, rolling updates, health checks, and autoscaling—all integrated. GitOps with ArgoCD or Flux means any developer can check current config files and be confident about the current state, replacing tribal knowledge with pull requests. And hiring becomes easier when you run the **de facto industry standard** with 93% adoption.

**A practical decision framework for your situation:**

| Signal | Stay on Cloud Run / Fly.io | Move to Kubernetes |
|--------|---------------------------|-------------------|
| Services | Fewer than 15 | 15+, strong case at 50+ |
| Team size | Fewer than 10 engineers | 10+ with ≥2 dedicated platform engineers |
| Workload type | Stateless HTTP, event-driven | Stateful, GPU, complex networking, custom scheduling |
| Multi-cloud | Not required | Genuinely needed |
| Compliance | Standard | SOC2/HIPAA/PCI with custom network/audit controls |
| GitOps need | Nice-to-have | Critical for operational confidence |

If you do move, **GKE Autopilot is the easiest managed Kubernetes to operate**. Google manages nodes, scaling, and patching. Pod-based billing eliminates node management entirely. Provisioning takes 3–5 minutes versus 2–4 hours for EKS, which requires manual node group, IAM, and networking configuration. AKS offers a free control plane and sits in the middle for operational burden. The migration path from Cloud Run to GKE is particularly smooth—Cloud Run's Admin API v1 was designed for maximum portability with K8s YAML conventions, and a global Application Load Balancer can split traffic incrementally between Cloud Run and GKE during migration.

---

## 2. Resource management determines whether your cluster runs or burns money

The single most important resource management rule: **set memory limits equal to requests, and consider omitting CPU limits entirely**. This pattern—endorsed by Tim Hockin (Google/K8s maintainer) and broadly adopted since 2024—reflects a fundamental asymmetry. CPU is compressible: exceeding a limit causes CFS quota throttling, which silently degrades latency without any error. Memory is non-compressible: exceeding a limit triggers an instant OOM kill (exit code 137) with no warning.

```yaml
resources:
  requests:
    cpu: "200m"
    memory: "384Mi"
  limits:
    memory: "384Mi"   # equals request → Guaranteed-like for memory
    # No CPU limit — avoids unnecessary throttling
```

CPU throttling is the silent performance killer. Detect it with `rate(container_cpu_cfs_throttled_periods_total[5m]) / rate(container_cpu_cfs_periods_total[5m])`—anything above **25% throttling** is concerning. Without CPU limits, containers burst to use idle CPU, and the kernel's CFS scheduler shares fairly based on request weights.

Kubernetes assigns QoS classes automatically: **Guaranteed** (requests = limits, evicted last), **Burstable** (requests < limits, most common), and **BestEffort** (no specs, evicted first—never use in production). During node memory pressure, the kubelet sets `oom_score_adj` per QoS: BestEffort at 1000 (most likely killed), Burstable at 2–999, and Guaranteed at -997.

**Right-sizing from actual data** is where money is saved. Approximately **70% of requested CPU/memory is never utilized** across the industry, consistent for three years per CAST AI benchmarks. Deploy Goldilocks (by Fairwinds) to auto-create VPA objects in recommendation mode across labeled namespaces, then review its dashboard showing target requests for both Guaranteed and Burstable QoS. For manual analysis, profile with `quantile_over_time(0.95, rate(container_cpu_usage_seconds_total[5m])[24h:])` for CPU P95 and `quantile_over_time(0.99, container_memory_working_set_bytes[24h:])` for memory P99. Teams typically achieve **30–50% cost reduction** from right-sizing alone.

The Vertical Pod Autoscaler runs in four modes: **Off** (recommendations only—start here), **Initial** (sets resources only at pod creation), **Recreate** (evicts pods when recommendations diverge), and the new **InPlaceOrRecreate** (K8s 1.35+, resizes without eviction when possible). A critical gotcha: never use VPA and HPA on the same CPU/memory metrics simultaneously, as this creates a resource thrashing feedback loop. Instead, run VPA in Off mode for recommendations and HPA on custom metrics like requests per second.

For OOM debugging by language: Java requires `-XX:MaxRAMPercentage=75.0` to leave room for off-heap memory (metaspace, thread stacks, NIO buffers). Go goroutine leaks accumulate in maps and slices that the GC can't reclaim. Node.js defaults to a ~1.7GB V8 heap limit—set `--max-old-space-size` explicitly.

---

## 3. Deployment strategies that prevent 3 AM incidents

The zero-downtime rolling update configuration for critical production APIs uses `maxSurge: 1, maxUnavailable: 0, minReadySeconds: 10-30`. This never reduces available capacity—new pods must be ready before old pods terminate. For large deployments with 15+ replicas, increase to `maxSurge: 3` for faster rollouts while maintaining capacity. Dev and staging environments can tolerate `maxSurge: 50%, maxUnavailable: 50%` for speed.

A **critical race condition** exists in Kubernetes pod termination: endpoint removal propagates asynchronously, meaning pods may still receive traffic after receiving SIGTERM. The fix is a preStop hook with a sleep:

```yaml
spec:
  terminationGracePeriodSeconds: 60
  containers:
  - lifecycle:
      preStop:
        exec:
          command: ["/bin/sh", "-c", "sleep 20"]
```

The 20-second sleep gives load balancers, ingress controllers, and kube-proxy time to update routing. The `terminationGracePeriodSeconds` must exceed preStop time plus application shutdown time.

For canary and progressive delivery, **Argo Rollouts and Flagger** represent two philosophies. Argo Rollouts replaces the Deployment with a custom Rollout CRD, providing explicit step-by-step control (`setWeight → pause → analysis → setWeight`) with a dedicated UI and tight ArgoCD integration. Flagger works with standard Deployments unchanged—zero manifest migration required—and provides declarative, automatic canary analysis with configurable step progression. Both support Prometheus-based analysis with automatic rollback when error rates or latency exceed thresholds.

Choose Flagger for automatic, metric-driven canary with minimal migration effort. Choose Argo Rollouts when you need explicit manual approval gates and visual step control. Both support traffic shifting (10% → 25% → 50% → 100%), header-based routing for targeted testing, and traffic mirroring for shadow analysis.

**Startup probes** are essential for slow-starting applications (JVM, data-loading services). Set `failureThreshold × periodSeconds` to the maximum acceptable startup time. Once the startup probe succeeds, it never runs again and liveness/readiness probes take over.

---

## 4. Pod disruption budgets are the safety net you always need

PDBs protect pods during voluntary disruptions—node drains, cluster autoscaler scale-down, and managed node group upgrades. They do not protect against hardware failure, kernel panics, or `kubectl delete pod` (which bypasses the eviction API).

Prefer **`maxUnavailable`** over `minAvailable` for most workloads because it adapts automatically to replica count changes from HPA scaling. For a stateless frontend: `maxUnavailable: 1`. For a 3-replica database needing quorum: `maxUnavailable: 1`. For background workers: `maxUnavailable: 25%`.

The most dangerous PDB anti-pattern is setting `minAvailable` equal to replica count (or `maxUnavailable: 0`). This **blocks all voluntary disruptions indefinitely**—node drains hang, cluster autoscaler cannot scale down, and managed node group upgrades stall. Kyverno has a built-in policy to detect and prevent this. A closely related trap: PDB with `minAvailable: 1` on a single-replica deployment has the same blocking effect.

Since Kubernetes 1.31, set **`unhealthyPodEvictionPolicy: AlwaysAllow`** on all PDBs. By default, unhealthy pods count against the disruption budget even though they're already broken. `AlwaysAllow` permits eviction of misbehaving pods during drains even when the budget is tight.

PDBs interact directly with the cluster autoscaler. A node is only "unneeded" if all its important pods can move elsewhere without violating PDBs. Restrictive PDBs prevent node scale-down entirely, wasting money. Always ensure `minAvailable < replicas` or `maxUnavailable >= 1` so the autoscaler can proceed. For stateful workloads like Kafka or ZooKeeper, combine PDBs with ordered StatefulSet pod management for sequential, safe updates.

---

## 5. Network policies start with default deny or they're useless

The foundational pattern is a **zero-trust default-deny** policy applied to every namespace. Without it, all pods can talk to everything—network policies are additive, and pods not selected by any policy follow default allow-all behavior.

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: production
spec:
  podSelector: {}
  policyTypes: [Ingress, Egress]
```

**Immediately after deploying egress deny, pods lose DNS resolution.** This is the second most common mistake (after the first, below). Always pair egress deny with an explicit DNS allow rule for UDP/TCP port 53 to kube-system/kube-dns.

The **number one network policy mistake** is creating policies when your CNI doesn't enforce them. Kubernetes silently accepts NetworkPolicy YAML even if enforcement never happens. Flannel has zero NetworkPolicy support. Verify your CNI: `kubectl get pods -n kube-system | grep -E "calico|cilium"`. If you only see Flannel, your policies are decorative.

For CNI selection in 2025–2026: **Cilium** (eBPF-based) is technically superior for greenfield deployments, providing L3/L4/L7 policy enforcement, FQDN-based egress policies, transparent WireGuard encryption, and Hubble observability—all without sidecar proxies. GKE Dataplane V2 is Cilium under the hood (default for Autopilot). AKS offers Azure CNI Powered by Cilium. Calico remains the right choice for Windows workloads, BGP integration, or brownfield environments with existing iptables tooling.

Cilium's FQDN-based policies solve a real operational pain point: controlling egress to cloud services with dynamic IPs. Standard NetworkPolicy only supports static CIDR blocks, but services like S3 use thousands of IPs. Cilium intercepts DNS responses via a transparent proxy, dynamically populates eBPF maps with resolved IPs, and auto-expires entries based on DNS TTL.

NetworkPolicy (L3/L4) and service mesh authorization (L7) complement each other. Use NetworkPolicy for basic segmentation and namespace isolation. Layer Istio or Linkerd AuthorizationPolicies on top for HTTP method/path-level controls and mTLS with cryptographic identity. Apply both as defense in depth—NetworkPolicies protect unmeshed workloads and non-TCP traffic that meshes can't handle.

---

## 6. RBAC failures are silent until they're catastrophic

Start with two principles: **namespace-scoped Roles by default** (limits blast radius), and **one ServiceAccount per workload** with `automountServiceAccountToken: false` everywhere. The default ServiceAccount in every namespace is a shared identity—any permissions granted to it apply to all pods that don't specify a custom SA, and a compromised container can use the auto-mounted token for API access.

For CI/CD, never grant cluster-admin. ArgoCD needs cluster-wide read (`get`, `list`, `watch`) for its application controller cache, but write permissions should be scoped per namespace via RoleBindings. Flux uses service account impersonation: each Kustomization specifies a `serviceAccountName`, and the controller impersonates that SA—limiting reconciliation to that SA's RBAC scope. GitHub Actions deployers get namespace-scoped Roles granting only `create`, `update`, `patch` on Deployments, Services, and ConfigMaps.

**Wildcard verbs (`*`) are the most dangerous RBAC mistake** because they implicitly grant `escalate`, `bind`, and `impersonate`—the three verbs that enable privilege escalation. Similarly, wildcard resources apply to all current and future resource types including CRDs. Always enumerate specific verbs and resources. Granting `create` on Pods or Deployments in a namespace implicitly grants access to every Secret and ConfigMap mountable in that namespace.

Enable audit logging on every cluster. GKE has it enabled by default via Cloud Audit Logs. EKS requires explicit enablement (disabled by default). AKS needs Diagnostic Settings configuration. Monitor these events: ClusterRoleBinding creation/modification, Secret access, pod exec/attach/port-forward, and anonymous API requests. Tools like Falco provide runtime threat detection using audit logs.

Use `kubectl auth can-i --as=system:serviceaccount:production:myapp create deployments -n production` to test permissions before granting. The rbac-lookup, who-can, and rakkess kubectl plugins provide reverse-lookup capabilities: who has access to what, and what can a given identity do.

---

## 7. Secrets management needs three layers, not one

Kubernetes Secrets are base64-encoded, not encrypted—`echo <value> | base64 -d` decodes them instantly. Even with etcd encryption at rest (enabled by default on managed K8s), secrets remain readable via the API to any principal with RBAC `get` access. Native secrets provide no audit trail, no central rotation, no versioning, and no cross-cluster sharing.

The **recommended production stack** uses three layers: an external secrets store (Vault, AWS Secrets Manager, GCP Secret Manager), External Secrets Operator for sync, and Stakater Reloader for pod restarts on changes. ESO defines `ExternalSecret` CRDs that reference external secrets—Git stores only references, never values. ESO polls the external provider at configurable intervals (5 minutes for high-security, 1 hour for API keys) and creates standard K8s Secrets that pods consume normally.

For GitOps workflows requiring encrypted secrets in Git, **SOPS with age or cloud KMS** is superior to Sealed Secrets. SOPS encrypts only YAML values (leaving keys as plaintext for diff-ability), supports multiple encryption backends (age, AWS KMS, GCP KMS, Azure Key Vault), and enables local decryption for development. Flux has native SOPS support—just add `decryption.provider: sops` to a Kustomization spec. Sealed Secrets by contrast uses cluster-specific RSA keys (complicating multi-cluster), cannot integrate with cloud KMS, and encrypts the entire data blob (destroying diff readability).

**Workload Identity eliminates static credentials entirely.** GKE Workload Identity Federation maps Kubernetes ServiceAccounts to Google Cloud IAM principals—enabled by default on Autopilot. EKS Pod Identity (newer, simpler than IRSA) associates IAM roles with ServiceAccounts via a DaemonSet agent, no OIDC provider configuration needed. AKS Workload Identity uses Azure AD federated identity credentials. All three provide automatic credential rotation and cloud-native audit logging, solving the "secret zero" problem where ESO itself needs credentials to access the secret store.

---

## 8. Your observability stack will become your most expensive workload

The LGTM stack (Loki, Grafana, Tempo, Mimir) has converged as the open-source standard. Prometheus scrapes metrics, Loki aggregates logs with label-based indexing, Tempo stores distributed traces, and Grafana provides unified dashboards with cross-signal correlation. OpenTelemetry Collector or Grafana Alloy serves as the telemetry collection agent.

For long-term metric storage, **Grafana Mimir is the recommended choice** for new deployments. It handles **1 billion active series** in a single tenant, delivers 7-day query latency of 80–100ms (versus 2,000–4,000ms for Thanos), and uses 66% less storage. Cortex is effectively in maintenance mode—most maintainers moved to Mimir. Thanos remains excellent for teams already using it successfully or preferring decentralized sidecar architectures. VictoriaMetrics deserves consideration for operational simplicity (single binary) and best-in-class compression.

Resource sizing matters because **observability can consume 20–40% of total cluster resources**. Loki ingesters need **16GiB memory each** in production. Prometheus needs ~1–2GB RAM per million active time series. Per Grafana Labs guidelines, plan a 1:4 ratio of CPU to memory (every CPU core → 4GB RAM) for Mimir/Tempo infrastructure, with fast NVMe storage for ingesters.

Deploy OpenTelemetry Collectors in a **two-tier architecture**: DaemonSet agents on each node (collecting node metrics, container logs, receiving OTLP from apps) feeding into a Deployment gateway (2+ replicas for batching, filtering, sampling, and routing to backends). This architecture lets you export to multiple backends simultaneously—Prometheus and Datadog, or Loki and Elasticsearch—without changing application instrumentation.

Loki vs Elasticsearch is a settled question for most Kubernetes teams. Loki uses **~10x less storage** because it indexes only labels/metadata, not full log content. It stores compressed chunks in cheap object storage. Elasticsearch indexes every log line with an inverted index, creating 3–5x the raw data size. Choose Elasticsearch only when you need deep full-text analytics or SIEM capabilities.

Cost control requires active management. Tune scrape intervals by criticality: critical control-plane metrics at 15s, application metrics at 30s, infrastructure at 60s. Drop high-cardinality labels via relabeling before ingestion. Implement tiered retention: 30 days detailed, 90 days downsampled to 5m, 1 year at 1h. Use USE method (Utilization, Saturation, Errors) for infrastructure monitoring and RED method (Rate, Errors, Duration) for service monitoring.

---

## 9. GitOps with ArgoCD or Flux makes Kubernetes actually manageable

ArgoCD holds **~60% of the GitOps market** with a full-featured web UI, visual resource trees, one-click rollback, and centralized multi-cluster management. Flux holds ~30%, offering a lighter footprint (200–400MB vs 500MB–1GB), native SOPS integration, built-in image automation, and a decentralized model where each cluster runs independently—ideal for edge and air-gapped environments.

Choose ArgoCD when your team includes developers, SREs, and managers who need a visual dashboard, or when managing multiple clusters from a single pane of glass. Choose Flux when you're a platform engineering team that prefers CLI-first workflows, need native SOPS for regulated industries, or run resource-constrained edge environments.

**Use directories, not branches, for environments.** Branch-per-environment is the #1 GitOps anti-pattern—branches diverge, cherry-picks get missed, and configs drift silently. Structure your repo with Kustomize overlays:

```
config-repo/
  base/          # Common config
  overlays/
    dev/         # Auto-sync enabled
    staging/     # Auto-sync with PR approval gate
    production/  # Manual sync or strict PR review
```

ArgoCD's drift detection runs a continuous reconciliation loop (default 3 minutes), performing semantic diffs that normalize both desired and actual state. With `selfHeal: true`, manual kubectl changes revert to Git-defined state within ~5 seconds. Configure `ignoreDifferences` for fields managed by other controllers—HPA replicas, cert-manager CA bundles, auto-assigned ClusterIPs—to prevent ArgoCD from fighting with other operators.

For secret handling in GitOps, the maturity progression is: Sealed Secrets (simplest, no external dependencies) → SOPS with cloud KMS (diff-friendly, multi-cloud) → External Secrets Operator (automated rotation, centralized management). One production team reported switching from Sealed Secrets to ESO reduced secret rotation time from **47 minutes to 90 seconds**.

The critical CI/CD principle: **CI never needs cluster credentials.** CI handles build, test, scan, and image push. The GitOps controller inside the cluster pulls from Git. This eliminates the security risk of CI pipelines having cluster write access.

---

## 10. Cost optimization recovers the 70% of resources you're wasting

Average Kubernetes clusters waste **70% of requested CPU/memory**—consistent across all three major clouds for three years. Systematic optimization typically delivers **30–50% cost reduction** without sacrificing reliability.

**Spot/preemptible nodes** save 60–90% off on-demand pricing. Run a dual node pool: on-demand for critical services (databases, control plane), spot for stateless web services and batch jobs. Every deployment on spot needs a PDB, and applications must handle SIGTERM gracefully. Recommended split: 70–80% spot for non-critical workloads, 20–30% on-demand for critical services, enforced via taints and tolerations.

**Karpenter has replaced Cluster Autoscaler as the best choice for AWS.** It provisions nodes in 45–60 seconds (versus 3–4 minutes for CA), dynamically selects the cheapest instance type matching pod requirements, and proactively consolidates underutilized nodes. Teams report **20–40% savings from bin-packing alone**, doubled with spot instances. Karpenter now runs in preview on AKS as well. Use Cluster Autoscaler for multi-cloud, on-prem, or dedicated GPU node groups where explicit reservation matters.

For cluster autoscaler tuning, reduce `scale-down-unneeded-time` to 5 minutes for cost-focused environments (default 10 minutes leaves idle nodes burning money). Set `scale-down-utilization-threshold` to 0.5. Use the **least-waste expander** for cost optimization—it selects the node group leaving the fewest unused resources. The priority expander enables sophisticated strategies like preferring spot with on-demand fallback.

**ARM64 nodes deliver 20–40% better price-performance** for compatible workloads. Netflix migrated 70% of encoding to Graviton3, achieving 30% compute cost reduction and **$15M+ annual savings**. Migration approach: multi-arch CI builds with `docker buildx`, deploy 10–20% on ARM, monitor P99 and SLOs, then promote to 60–80%.

Namespace ResourceQuotas and LimitRanges enforce cost boundaries per team. Start with showback (teams see their costs via OpenCost) and graduate to chargeback. Only **14% of organizations run active chargeback programs** despite 49% seeing costs jump post-K8s adoption. Label every resource with `app.kubernetes.io/owner` and `cost-center` for allocation. OpenCost is free and provides per-workload visibility; Kubecost adds multi-cluster unified views, RI/Spot reconciliation, and predictive forecasting for enterprise needs.

The FinOps maturity path: Month 1, install OpenCost and right-size obvious over-provisioned workloads. Month 2, introduce spot node pools and ResourceQuotas. Month 3, roll out HPA on bursty services and VPA recommendations on stable ones. Month 4+, tune autoscaler delays, add policy enforcement via Kyverno. Quarterly: run the descheduler, audit orphaned PVCs and unattached load balancers, review reserved instance commitments.

---

## Conclusion: the operational knowledge that separates success from regret

The decision to adopt Kubernetes is not about technology—it's about whether your organization can sustain the operational investment. If you're on Cloud Run and Fly.io today and they work, the burden of proof lies with Kubernetes to justify its complexity. That justification comes when you need namespace-level isolation for compliance, custom scheduling for stateful or GPU workloads, or GitOps-driven multi-service deployment across teams.

Three insights cut across all ten domains. First, **defaults are dangerous**: default ServiceAccounts leak API access, default allow-all networking policies leave clusters wide open, default resource configurations waste 70% of compute, and default CPU limits silently throttle performance. Every production cluster needs explicit configuration for resources, RBAC, network policies, and PDBs. Second, **the tooling ecosystem has matured dramatically**: Karpenter for autoscaling, Cilium for networking, ESO for secrets, Mimir for metrics, and ArgoCD/Flux for GitOps are no longer experimental—they're production-proven at scale. Third, **cost optimization is not optional**: start measuring on day one with OpenCost, right-size from actual usage data, use spot instances with PDBs, and treat observability infrastructure as a first-class cost center before it consumes 40% of your cluster.

The teams that succeed with Kubernetes are not the ones with the most YAML. They're the ones that treat every operational decision—from QoS classes to scrape intervals to PDB thresholds—as a deliberate, data-informed choice.