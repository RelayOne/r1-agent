# High-performance IPC in Go for event bus systems

**For a hook/event bus like Stoke operating at 100–1,000 events/sec, transport and serialization overhead together consume less than 20% of a single CPU core — making developer experience, correctness, and debuggability far more important than raw throughput.** gRPC over Unix domain sockets provides the best balance of structured contracts, streaming, and performance for this architecture. Raw Unix sockets with JSON framing remain ideal for IDE integration where zero-dependency connectivity matters. The sections below provide complete implementation details, benchmarks, and code for every layer of the transport stack.

---

## 1. gRPC server setup with reflection, health checks, and interceptors

A well-structured protobuf definition forms the contract for the entire hook system. The service below defines the three core operations: fire-and-forget publish, streaming subscriptions, and synchronous gate-hook dispatch.

```protobuf
syntax = "proto3";
package eventbus.v1;
option go_package = "github.com/yourorg/stoke/gen/eventbus/v1;eventbusv1";

import "google/protobuf/timestamp.proto";

service EventService {
  rpc Publish(PublishRequest) returns (PublishResponse);
  rpc Subscribe(SubscribeRequest) returns (stream Event);
  rpc DispatchHook(DispatchHookRequest) returns (DispatchHookResponse);
}

message Event {
  string id = 1;
  string topic = 2;
  bytes payload = 3;
  google.protobuf.Timestamp occurred_at = 4;
  map<string, string> metadata = 5;
}

message PublishRequest {
  string topic = 1;
  bytes payload = 2;
  map<string, string> metadata = 3;
}

message PublishResponse { string event_id = 1; }

message SubscribeRequest { string topic_filter = 1; }

message DispatchHookRequest {
  string hook_name = 1;
  bytes payload = 2;
  map<string, string> metadata = 3;
}

message HookResult {
  string handler_id = 1;
  bool ok = 2;
  string error = 3;
  bytes response = 4;
}

message DispatchHookResponse { repeated HookResult results = 1; }
```

The server wires together keepalive enforcement, chained interceptors, health checking, and reflection in a single `grpc.NewServer` call. **Interceptors chain left-to-right** since gRPC-Go v1.28+ — the older `go-grpc-middleware` chain helper is no longer needed.

```go
package main

import (
    "context"
    "fmt"
    "log"
    "net"
    "os"
    "os/signal"
    "syscall"
    "time"

    "google.golang.org/grpc"
    "google.golang.org/grpc/codes"
    "google.golang.org/grpc/health"
    healthgrpc "google.golang.org/grpc/health/grpc_health_v1"
    "google.golang.org/grpc/keepalive"
    "google.golang.org/grpc/metadata"
    "google.golang.org/grpc/reflection"
    "google.golang.org/grpc/status"

    eventbusv1 "github.com/yourorg/stoke/gen/eventbus/v1"
)

func main() {
    grpcServer := grpc.NewServer(
        grpc.KeepaliveEnforcementPolicy(keepalive.EnforcementPolicy{
            MinTime:             5 * time.Second,
            PermitWithoutStream: true,
        }),
        grpc.KeepaliveParams(keepalive.ServerParameters{
            MaxConnectionIdle:     15 * time.Minute,
            MaxConnectionAge:      30 * time.Minute,
            MaxConnectionAgeGrace: 5 * time.Second,
            Time:                  1 * time.Minute,
            Timeout:               20 * time.Second,
        }),
        grpc.MaxConcurrentStreams(250),
        grpc.MaxRecvMsgSize(4<<20),
        grpc.ChainUnaryInterceptor(loggingUnary, authUnary),
        grpc.ChainStreamInterceptor(loggingStream, authStream),
    )

    eventbusv1.RegisterEventServiceServer(grpcServer, NewEventServiceServer())

    healthSrv := health.NewServer()
    healthgrpc.RegisterHealthServer(grpcServer, healthSrv)
    healthSrv.SetServingStatus("eventbus.v1.EventService",
        healthgrpc.HealthCheckResponse_SERVING)
    healthSrv.SetServingStatus("", healthgrpc.HealthCheckResponse_SERVING)

    reflection.Register(grpcServer)

    lis, err := net.Listen("tcp", ":50051")
    if err != nil { log.Fatal(err) }

    go func() { log.Fatal(grpcServer.Serve(lis)) }()
    gracefulShutdown(grpcServer, healthSrv)
}
```

The logging interceptor captures method name, status code, and duration. The auth interceptor skips health and reflection endpoints, then extracts tokens from gRPC metadata:

```go
func loggingUnary(ctx context.Context, req any, info *grpc.UnaryServerInfo,
    handler grpc.UnaryHandler) (any, error) {
    start := time.Now()
    resp, err := handler(ctx, req)
    st, _ := status.FromError(err)
    log.Printf("unary %s | %s | %v", info.FullMethod, st.Code(), time.Since(start))
    return resp, err
}

func authUnary(ctx context.Context, req any, info *grpc.UnaryServerInfo,
    handler grpc.UnaryHandler) (any, error) {
    if isPublicMethod(info.FullMethod) { return handler(ctx, req) }
    md, ok := metadata.FromIncomingContext(ctx)
    if !ok { return nil, status.Error(codes.Unauthenticated, "missing metadata") }
    vals := md.Get("authorization")
    if len(vals) == 0 { return nil, status.Error(codes.Unauthenticated, "no token") }
    userID, err := validateToken(vals[0])
    if err != nil { return nil, status.Errorf(codes.Unauthenticated, "bad token: %v", err) }
    return handler(context.WithValue(ctx, ctxKeyUserID{}, userID), req)
}
```

Graceful shutdown sets health to `NOT_SERVING` first (so load balancers drain traffic), then calls `GracefulStop()` with a hard timeout fallback:

```go
func gracefulShutdown(srv *grpc.Server, hs *health.Server) {
    quit := make(chan os.Signal, 1)
    signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
    <-quit

    hs.SetServingStatus("", healthgrpc.HealthCheckResponse_NOT_SERVING)
    hs.Shutdown()

    stopped := make(chan struct{})
    go func() { srv.GracefulStop(); close(stopped) }()

    select {
    case <-stopped:
        log.Println("graceful shutdown complete")
    case <-time.After(15 * time.Second):
        log.Println("forcing shutdown")
        srv.Stop()
    }
}
```

---

## 2. Unix domain socket servers require careful lifecycle management

Unix domain sockets provide **~1.6x lower latency** than TCP loopback for small messages and avoid the kernel's TCP stack entirely. The core pattern in Go is straightforward, but production use demands attention to stale file cleanup, permissions, and path selection.

```go
const SockAddr = "/tmp/stoke.sock"

func main() {
    // Remove stale socket from previous crash
    os.RemoveAll(SockAddr)

    listener, err := net.Listen("unix", SockAddr)
    if err != nil { log.Fatal(err) }
    defer listener.Close()

    // Set permissions for multi-user access
    os.Chmod(SockAddr, 0770)

    sigCh := make(chan os.Signal, 1)
    signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
    go func() {
        <-sigCh
        listener.Close() // Go automatically removes socket file on Close
        os.Exit(0)
    }()

    for {
        conn, err := listener.Accept()
        if err != nil { log.Printf("accept: %v", err); continue }
        go handleConnection(conn)
    }
}
```

**Path selection matters for IDE integration.** The `XDG_RUNTIME_DIR` is the correct location for per-user runtime sockets — it's mode 0700, cleaned on logout, and always available in VS Code's user session (typically `/run/user/<UID>`). Fall back to `/tmp` with a UID suffix:

```go
func socketPath() string {
    if dir := os.Getenv("XDG_RUNTIME_DIR"); dir != "" {
        subdir := filepath.Join(dir, "stoke")
        os.MkdirAll(subdir, 0700)
        return filepath.Join(subdir, "stoke.sock")
    }
    return fmt.Sprintf("/tmp/stoke-%d.sock", os.Getuid())
}
```

**Abstract sockets** (Linux only) use the `@` prefix and live in the kernel namespace rather than the filesystem. They require no cleanup and no file permissions, but they offer weaker security and aren't portable to macOS:

```go
listener, _ := net.Listen("unix", "@/stoke/events") // No file created, auto-cleaned
```

For security beyond file permissions, **SO_PEERCRED** lets the server verify the connecting process's UID, GID, and PID:

```go
func getPeerCreds(conn net.Conn) (*unix.Ucred, error) {
    uc := conn.(*net.UnixConn)
    raw, _ := uc.SyscallConn()
    var cred *unix.Ucred
    var credErr error
    raw.Control(func(fd uintptr) {
        cred, credErr = unix.GetsockoptUcred(int(fd), unix.SOL_SOCKET, unix.SO_PEERCRED)
    })
    return cred, credErr
}
```

Note that `syscall.Umask` is process-wide and not goroutine-safe — set it only immediately before `net.Listen`, then restore it. The default file descriptor soft limit of 1024 can become a bottleneck with many connected IDE instances; increase via `/etc/security/limits.conf` or `ulimit -n 65536`.

---

## 3. JSON-over-socket protocol: NDJSON vs length-prefixed framing

Two framing approaches dominate custom socket protocols. **Newline-delimited JSON (NDJSON)** is simpler and debuggable with standard tools; **length-prefixed framing** provides better performance and explicit message boundaries.

### NDJSON framing

Go's `json.Encoder` appends `\n` automatically, and `json.Decoder` reads one value at a time, making NDJSON nearly free to implement:

```go
// Writer
encoder := json.NewEncoder(conn)
encoder.Encode(&request) // writes JSON + \n

// Reader
decoder := json.NewDecoder(conn)
for decoder.More() {
    var msg Message
    decoder.Decode(&msg)
    process(msg)
}
```

Embedded newlines aren't an issue because `json.Marshal` escapes them as `\n` within strings.

### Length-prefixed framing

This approach sends a 4-byte big-endian length header before each JSON payload. The critical detail: **always use `io.ReadFull()`** instead of `conn.Read()`, because Unix sockets are stream-oriented and a single read may return partial data.

```go
func WriteMessage(conn net.Conn, v any) error {
    data, _ := json.Marshal(v)
    header := make([]byte, 4)
    binary.BigEndian.PutUint32(header, uint32(len(data)))
    conn.Write(header)
    _, err := conn.Write(data)
    return err
}

func ReadMessage(conn net.Conn, v any) error {
    header := make([]byte, 4)
    io.ReadFull(conn, header)
    msgLen := binary.BigEndian.Uint32(header)
    if msgLen > 16<<20 { return fmt.Errorf("message too large") } // 16MB DoS cap
    payload := make([]byte, msgLen)
    io.ReadFull(conn, payload)
    return json.Unmarshal(payload, v)
}
```

| Feature | NDJSON | Length-prefixed |
|---|---|---|
| Debugging | `nc`, `socat`, `jq` | Hex viewer needed |
| Go stdlib support | `json.Decoder` native | Manual with `encoding/binary` |
| Pre-allocate buffer | No | Yes (size known upfront) |
| Recovery from corruption | Skip to next `\n` | Connection likely unrecoverable |
| Performance | Slightly slower (scan) | Slightly faster (exact reads) |

**For IDE integration, start with NDJSON** — it's trivially debuggable and universally supported. The Language Server Protocol, Docker, and many VS Code extensions use NDJSON-style framing successfully.

### Request-reply correlation over a single connection

Multiplexing multiple concurrent requests requires a message ID matching scheme. Each request carries a unique ID; the server echoes it in the response:

```go
type Request struct {
    ID     string          `json:"id"`
    Method string          `json:"method"`
    Params json.RawMessage `json:"params,omitempty"`
}

type Response struct {
    ID     string          `json:"id"`
    Result json.RawMessage `json:"result,omitempty"`
    Error  *RPCError       `json:"error,omitempty"`
}

type Multiplexer struct {
    conn    net.Conn
    mu      sync.Mutex
    pending map[string]chan *Response
    encoder *json.Encoder
}

func (m *Multiplexer) Call(ctx context.Context, method string, params any) (*Response, error) {
    id := uuid.New().String()
    ch := make(chan *Response, 1)

    m.mu.Lock()
    m.pending[id] = ch
    m.encoder.Encode(&Request{ID: id, Method: method})
    m.mu.Unlock()

    select {
    case resp := <-ch: return resp, nil
    case <-ctx.Done():
        m.mu.Lock()
        delete(m.pending, id)
        m.mu.Unlock()
        return nil, ctx.Err()
    }
}
```

A background `readLoop` goroutine decodes responses and dispatches them to the appropriate channel. This is exactly how Go's own `net/rpc/jsonrpc` works internally.

---

## 4. Transport overhead is negligible below 5,000 events/sec

Benchmark data from multiple sources shows consistent patterns. **Raw Unix sockets are ~3x faster than TCP and ~30–50x faster than gRPC** for simple round-trip latency, but this gap matters far less than it appears at typical hook system throughputs.

| Transport | p50 latency | p99 latency | Max msgs/sec |
|---|---|---|---|
| Raw Unix socket | **2–5 µs** | 6–15 µs | 200K–500K |
| Raw TCP loopback | 4–15 µs | 15–30 µs | 70K–200K |
| HTTP/1.1 JSON | ~49 µs | 100–200 µs | ~20K |
| gRPC over Unix socket | 100–170 µs | 140–200 µs | 10K–20K |
| gRPC over TCP | 120–190 µs | 170–250 µs | 8K–16K |

gRPC-over-Unix-socket benchmarks from the Ja7ad/grpc-unix-socket Go repo show **102 µs/op** vs **127 µs/op** for TCP — roughly a **20% latency reduction** with identical memory allocation. The MPI Heidelberg study (C++, EPYC 7402P) measured gRPC at **167 µs p50** vs raw UDS at **4 µs p50** — a 40x gap that's entirely in the HTTP/2 framing and protobuf serialization.

At **1,000 events/sec**, the CPU cost breakdown tells the real story:

- Raw UDS: 1,000 × 5µs = **0.5% of one core**
- gRPC over UDS: 1,000 × 150µs = **15% of one core**
- HTTP/JSON: 1,000 × 50µs = **5% of one core**

**The practical bottleneck for a hook system at this scale is always handler logic, database calls, or network I/O — never transport.** Transport choice should be driven by developer experience, debugging needs, and feature requirements (streaming, type safety, middleware). gRPC's ~150µs overhead becomes relevant only above ~5,000 calls/sec on a single core.

One surprising finding: benchmarks from the `duh-rpc` project show **HTTP/1.1 outperforming gRPC for simple unary calls** on localhost (49µs vs 57µs). This is because HTTP/1.1's simpler framing avoids HTTP/2 overhead when multiplexing isn't needed.

---

## 5. When gRPC is overkill and when JSON sockets suffice

### net/rpc: frozen, not deprecated

Go's `net/rpc` is **frozen** per Rob Pike's 2016 decision (issue #16844) — it receives no new features, bug fixes, or security patches. It works over any `net.Conn` (including Unix sockets) with zero code generation, but lacks context support, TLS, streaming, and interceptors. The community fork `keegancsmith/rpc` adds `context.Context` while maintaining wire compatibility. **Avoid net/rpc for new projects.**

### Decision framework

| Criterion | Custom JSON/socket | gRPC | ConnectRPC |
|---|---|---|---|
| Code generation | None | Required | Required |
| Streaming | Manual | Built-in | Built-in |
| Cross-language IDE plugins | Easy (just JSON) | 10+ languages | Multiple + curl |
| Middleware/interceptors | Manual | Built-in chain | Built-in |
| Debugging | curl/netcat | grpcurl | curl (native HTTP) |
| Setup complexity | Low | High | Medium |

**ConnectRPC** (by the Buf team) deserves special attention. It generates idiomatic Go code using `net/http` (not gRPC's custom HTTP/2 stack), supports three wire protocols simultaneously (Connect, gRPC, gRPC-Web), and makes unary RPCs curl-able with plain HTTP POST + JSON. It's wire-compatible with gRPC servers. For a new Go project that wants gRPC ecosystem compatibility with simpler code, **ConnectRPC is the strongest choice**.

The tipping point from custom JSON to gRPC/ConnectRPC typically occurs when you need more than 2–3 message types, want streaming subscriptions, start building your own framing/reconnection/error codes, or require cross-team contract enforcement. For Stoke's IDE integration specifically, a JSON-over-Unix-socket protocol keeps the barrier to entry lowest — any language can connect with just a JSON library and socket — while gRPC or ConnectRPC handles the structured external service layer.

---

## 6. Bidirectional streaming for subscribe-and-receive patterns

gRPC's bidirectional streams map naturally to event subscription: the client sends subscription filters (and acknowledgments), while the server pushes matching events. The server manages a **per-subscriber buffered channel** to decouple publish rate from per-client consumption rate:

```go
type subscriber struct {
    id     string
    topics map[string]bool
    ch     chan *pb.Event  // buffered channel as per-client queue
    done   chan struct{}
}

func (s *EventServer) Subscribe(stream pb.EventService_SubscribeServer) error {
    firstMsg, _ := stream.Recv()
    sub := &subscriber{
        id:     firstMsg.ClientId,
        topics: topicSet(firstMsg.Topics),
        ch:     make(chan *pb.Event, 256),
    }
    s.register(sub)
    defer s.unregister(sub)

    // Read client messages (acks, subscription updates) in background
    recvErr := make(chan error, 1)
    go func() {
        for {
            msg, err := stream.Recv()
            if err != nil { recvErr <- err; return }
            // Handle subscription updates or acks
        }
    }()

    // Push events to client
    for {
        select {
        case evt := <-sub.ch:
            if err := stream.Send(evt); err != nil { return err }
        case err := <-recvErr:
            return err
        case <-stream.Context().Done():
            return status.Error(codes.Canceled, stream.Context().Err().Error())
        }
    }
}
```

**Backpressure is critical.** `stream.Send()` blocks when the HTTP/2 flow control window is full. Without the buffered channel, one slow client blocks the entire publish path. The publish method uses a non-blocking send to implement drop-newest policy:

```go
func (s *EventServer) Publish(topic string, payload []byte) {
    evt := &pb.Event{Topic: topic, Payload: payload, Id: time.Now().UnixNano()}
    s.mu.RLock()
    defer s.mu.RUnlock()
    for id, sub := range s.subscribers {
        if !sub.topics[topic] { continue }
        select {
        case sub.ch <- evt: // delivered
        default:
            log.Printf("dropping event for slow client %s", id)
        }
    }
}
```

### Client reconnection with exponential backoff

Streams are **not** automatically reconnected by gRPC-Go — only the underlying connection is. Stream reconnection must be manual:

```go
func subscribeWithReconnect(client pb.EventServiceClient) {
    attempt := 0
    for {
        err := runSubscription(client) // blocks until stream breaks
        if err == nil { return }

        st, _ := status.FromError(err)
        if st.Code() == codes.Unauthenticated { log.Fatal("non-retryable") }

        wait := min(time.Second*time.Duration(math.Pow(2, float64(attempt))), 60*time.Second)
        jitter := time.Duration(rand.Float64() * 0.4 * float64(wait))
        log.Printf("reconnecting in %v (attempt %d)", wait+jitter, attempt)
        time.Sleep(wait + jitter)
        attempt = min(attempt+1, 20)
    }
}
```

---

## 7. Keepalive and dead connection detection

gRPC uses **HTTP/2 PING frames** for connection liveness probing. The client sends a PING after `Time` seconds of inactivity; if no ACK arrives within `Timeout` seconds, the connection is declared dead. For long-lived subscription streams, configure both sides consistently:

**Server parameters** control connection lifecycle bounds. `MaxConnectionAge` with its automatic ±10% jitter forces periodic reconnection, enabling load rebalancing. `MaxConnectionIdle` reclaims resources from abandoned connections. The `EnforcementPolicy.MinTime` must be ≤ the client's `Time` parameter, or the server sends GOAWAY with `ENHANCE_YOUR_CALM`:

```go
// Server
keepalive.ServerParameters{
    MaxConnectionIdle:     5 * time.Minute,
    MaxConnectionAge:      30 * time.Minute,
    MaxConnectionAgeGrace: 10 * time.Second,
    Time:                  1 * time.Minute,  // server PING interval
    Timeout:               20 * time.Second, // PING ACK timeout
}
keepalive.EnforcementPolicy{
    MinTime:             10 * time.Second, // client must not ping faster
    PermitWithoutStream: true,             // allow idle-connection pings
}

// Client
keepalive.ClientParameters{
    Time:                10 * time.Second, // ≥ server MinTime
    Timeout:             5 * time.Second,
    PermitWithoutStream: true,
}
```

**`grpc.NewClient` replaced `grpc.Dial`** in gRPC-Go v1.63. The new API performs no I/O on creation (starts in IDLE state), uses `dns` as the default resolver, and ignores `WithBlock`/`WithTimeout`. Connection happens lazily on first RPC or explicitly via `conn.Connect()`. Monitor state transitions with `conn.GetState()` and `conn.WaitForStateChange()`:

```go
conn, _ := grpc.NewClient("localhost:50051",
    grpc.WithTransportCredentials(insecure.NewCredentials()),
    grpc.WithConnectParams(grpc.ConnectParams{
        Backoff: backoff.Config{
            BaseDelay: 1*time.Second, Multiplier: 1.6,
            Jitter: 0.2, MaxDelay: 120*time.Second,
        },
    }),
)
// Transport-level reconnection is automatic.
// Stream-level reconnection is NOT — implement manually.
```

The five connectivity states are: **Idle** → **Connecting** → **Ready** (healthy) or **TransientFailure** (retrying with backoff) → **Shutdown** (terminal). RPCs on a `TransientFailure` connection fail fast unless `grpc.WaitForReady(true)` is used.

---

## 8. Concurrent fan-out with bounded goroutines and timeouts

The dispatcher must handle two distinct semantics: **gate hooks** (synchronous, all-must-respond, can veto) and **observe hooks** (fire-and-forget, non-blocking). Both need goroutine limits to prevent leak-driven OOM under load.

### Gate hooks with errgroup and semaphore

`errgroup.WithContext` provides fail-fast semantics — the first error cancels the derived context, which propagates to all other goroutines (if they check `ctx.Done()`). For wait-for-all semantics, collect errors via a channel instead:

```go
func (d *Dispatcher) dispatchGate(ctx context.Context, event Event,
    subs []Subscriber) error {
    ctx, cancel := context.WithTimeout(ctx, d.totalTimeout)
    defer cancel()

    g, ctx := errgroup.WithContext(ctx)
    g.SetLimit(d.maxWorkers) // bounded concurrency

    for _, sub := range subs {
        g.Go(func() error {
            subCtx, cancel := context.WithTimeout(ctx, d.perSubTimeout)
            defer cancel()
            return sub.Handle(subCtx, event)
        })
    }
    return g.Wait()
}
```

### Observe hooks: fire-and-forget with timeout safety

```go
func (d *Dispatcher) dispatchObserve(event Event, subs []Subscriber) {
    for _, sub := range subs {
        go func(s Subscriber) {
            ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
            defer cancel()
            if err := s.Handle(ctx, event); err != nil {
                log.Printf("observe subscriber %s failed: %v", s.ID, err)
            }
        }(sub)
    }
}
```

### Why unbounded goroutines are dangerous

Benchmark data shows the difference starkly. With 50K+ concurrent tasks, **unbounded goroutine creation consumes 2.1 GB and causes 2.1ms GC pauses** with degraded throughput. A worker pool of 16 goroutines uses **0.13 MB with 0.3ms GC pauses** and maintains stable performance. Always bound concurrency with `errgroup.SetLimit(n)` or a `semaphore.Weighted`.

### Circuit breaker for chronically slow subscribers

After N consecutive timeouts, stop dispatching to a subscriber temporarily using `sony/gobreaker`:

```go
settings := gobreaker.Settings{
    Name: subscriberID,
    ReadyToTrip: func(counts gobreaker.Counts) bool {
        return counts.ConsecutiveFailures > 5
    },
    Timeout: 10 * time.Second, // time in open state before half-open retry
}
cb := gobreaker.NewCircuitBreaker[any](settings)
```

Detect goroutine leaks in tests with `uber-go/goleak`:

```go
func TestMain(m *testing.M) { goleak.VerifyTestMain(m) }
```

---

## 9. Serialization cost is dominated by encoding/json's allocations

Benchmark data from `alecthomas/go_serialization_benchmarks` and production measurements reveals a clear performance hierarchy. **Protobuf marshaling is 3–6x faster than `encoding/json`** and produces payloads 50–70% smaller. Code-generated serializers (gogo/protobuf, tinylib/msgp) achieve another 3–5x speedup over reflection-based alternatives.

| Serializer | Marshal (ns/op) | Unmarshal (ns/op) | Output size | Allocs (marshal) |
|---|---|---|---|---|
| **gogo/protobuf** (codegen) | 152–267 | 234–1,268 | ~70 bytes | 1 |
| **tinylib/msgp** (codegen) | 171–183 | 297–326 | 106 bytes | 1 |
| **google/protobuf** | 500–990 | 645–1,902 | ~70 bytes | 4–6 |
| **easyjson** (codegen) | ~1,000 | ~700–900 | ~150 bytes | 1–2 |
| **json-iterator/go** | ~1,300 | ~1,479 | 139 bytes | 3 |
| **vmihailenco/msgpack** | 1,706 | 1,863 | 93 bytes | 6 |
| **encoding/json** | 2,006–2,165 | 4,115–6,077 | 150 bytes | 4–5 |

For a production-scale event payload (~500 bytes JSON, ~190 bytes protobuf), the DevFlex benchmarks on a Ryzen 7950X show: **Protobuf encode at 6.5µs, MessagePack at 12µs, JSON at 42µs**. At 1,000 events/sec, this translates to 6.5ms vs 42ms of CPU per second — a **35ms difference** that's meaningful but not a bottleneck.

**Practical recommendations for Stoke:**

- **gRPC path**: Protobuf is the natural choice — it's already required for service definitions, adds zero additional dependencies, and provides the best performance.
- **Unix socket / IDE path**: Start with `encoding/json` for debuggability. If profiling shows serialization >20% of CPU, drop in `json-iterator/go` as a zero-change-needed 2–3x speedup (`import jsoniter "github.com/json-iterator/go"; var json = jsoniter.ConfigCompatibleWithStandardLibrary`).
- **High-throughput path**: `tinylib/msgp` with code generation achieves **150ns/op with zero allocations** — but requires a `go:generate` step and isn't human-readable.

The serialization format matters most when payloads are large (>10KB) or throughput exceeds 5,000 events/sec. Below that threshold, optimize for developer experience and debuggability.

---

## 10. Testing IPC with bufconn, temporary sockets, and race detection

### gRPC testing with bufconn

`google.golang.org/grpc/test/bufconn` provides an in-memory `net.Listener` that exercises the full gRPC stack — protobuf serialization, HTTP/2 framing, interceptor chains, metadata propagation — without touching the network. This is the standard approach for unit-testing gRPC services:

```go
func startTestServer(t *testing.T, opts ...grpc.ServerOption) eventbusv1.EventServiceClient {
    t.Helper()
    lis := bufconn.Listen(1 << 20) // 1MB buffer
    srv := grpc.NewServer(opts...)
    eventbusv1.RegisterEventServiceServer(srv, NewEventServiceServer())
    go srv.Serve(lis)
    t.Cleanup(srv.GracefulStop)

    conn, err := grpc.NewClient("passthrough:///bufconn",
        grpc.WithContextDialer(func(ctx context.Context, _ string) (net.Conn, error) {
            return lis.DialContext(ctx)
        }),
        grpc.WithTransportCredentials(insecure.NewCredentials()),
    )
    require.NoError(t, err)
    t.Cleanup(func() { conn.Close() })
    return eventbusv1.NewEventServiceClient(conn)
}
```

The `"passthrough:///bufconn"` target skips DNS resolution. The custom dialer ignores the address and connects through bufconn's in-memory pipe. Variadic `opts` lets tests inject interceptors for testing middleware independently:

```go
func TestAuthInterceptor(t *testing.T) {
    client := startTestServer(t, grpc.UnaryInterceptor(authUnary))
    _, err := client.Publish(context.Background(), &eventbusv1.PublishRequest{})
    s, _ := status.FromError(err)
    assert.Equal(t, codes.Unauthenticated, s.Code())
}
```

Test gRPC error details with `status.FromError` for code checking and `s.Details()` for rich error metadata. Test deadlines by injecting a `slowStore` that respects `ctx.Done()` via `select`.

### Unix socket test paths: beware the 104-byte limit

Unix socket paths are limited to **104 bytes on macOS** and 108 on Linux. `t.TempDir()` includes the test name and frequently exceeds this — the Go standard library itself switched away from `t.TempDir()` for socket tests (issue #62614). Use `os.MkdirTemp` with short names:

```go
func testSocketPath(t *testing.T) string {
    t.Helper()
    dir, _ := os.MkdirTemp("", "")
    t.Cleanup(func() { os.RemoveAll(dir) })
    path := filepath.Join(dir, "s.sock")
    if len(path) >= 104 { t.Fatalf("socket path too long: %d", len(path)) }
    return path
}
```

### Mock subscribers for dispatch testing

Build a set of mock subscribers with controllable behavior — immediate, slow, erroring, and hanging — using channels for synchronization:

```go
type MockSubscriber struct {
    mu       sync.Mutex
    received []Event
    delay    time.Duration
    err      error
    called   chan struct{}
}

func (m *MockSubscriber) Handle(ctx context.Context, evt Event) error {
    if m.delay > 0 {
        select {
        case <-time.After(m.delay): // simulate slow processing
        case <-ctx.Done(): return ctx.Err()
        }
    }
    m.mu.Lock()
    m.received = append(m.received, evt)
    m.mu.Unlock()
    m.called <- struct{}{}
    return m.err
}

func (m *MockSubscriber) WaitForN(t *testing.T, n int, timeout time.Duration) {
    timer := time.NewTimer(timeout)
    defer timer.Stop()
    for i := 0; i < n; i++ {
        select {
        case <-m.called:
        case <-timer.C: t.Fatalf("timeout waiting for event %d/%d", i+1, n)
        }
    }
}
```

Table-driven tests cover the dispatch matrix efficiently:

```go
func TestDispatchScenarios(t *testing.T) {
    tests := []struct {
        name     string
        numSubs  int
        delay    time.Duration
        timeout  time.Duration
        wantErr  bool
    }{
        {"single_fast", 1, 0, time.Second, false},
        {"10_parallel", 10, 0, time.Second, false},
        {"slow_timeout", 1, 5*time.Second, 100*time.Millisecond, true},
    }
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            bus := NewEventBus(WithTimeout(tt.timeout))
            subs := make([]*MockSubscriber, tt.numSubs)
            for i := range subs {
                subs[i] = &MockSubscriber{delay: tt.delay, called: make(chan struct{}, 10)}
                bus.Subscribe("test", subs[i])
            }
            err := bus.Publish(Event{Type: "test", Data: "x"})
            if tt.wantErr { assert.Error(t, err) } else { assert.NoError(t, err) }
        })
    }
}
```

**Always run with `-race`** — Go's race detector (powered by ThreadSanitizer) has zero false positives and catches data races in concurrent dispatch. It adds 2–20x slowdown and 5–10x memory, which is fine for CI. Note the ~8,192 goroutine limit under `-race`.

Go 1.24 introduced **`testing/synctest`** (experimental, `GOEXPERIMENT=synctest`) for deterministic concurrent testing. `synctest.Run` creates an isolated "bubble" where `synctest.Wait()` blocks until all goroutines are durably blocked, and fake time advances automatically — eliminating flaky time-based assertions.

```go
func TestTimeout(t *testing.T) {
    synctest.Run(func() {
        ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
        defer cancel()
        go func() { <-ctx.Done() }()
        synctest.Wait() // deterministically waits for all goroutines
    })
}
```

---

## Conclusion

The architecture for Stoke's transport layer should use **three tiers matched to each integration point's needs**. For IDE integration via VS Code extensions, a JSON-over-Unix-socket protocol with NDJSON framing provides zero-dependency connectivity in any language, trivial debugging with standard tools, and latency well under 10µs. For structured external services, gRPC (or ConnectRPC for simpler code) over Unix sockets delivers type-safe contracts, bidirectional streaming for subscriptions, and built-in interceptors for auth and observability — with only ~100–150µs per call. For in-process Go hooks, direct function dispatch with `errgroup.SetLimit` and per-subscriber timeouts avoids all serialization and transport overhead entirely.

The most impactful architectural decisions aren't about transport speed. They're about **bounded concurrency** (never unbounded goroutines for subscriber dispatch), **circuit breaking** for slow subscribers, and **clear separation between gate and observe hook semantics**. A gate hook fan-out with `errgroup.WithContext` provides fail-fast cancellation; an observe hook uses fire-and-forget goroutines with per-call `context.WithTimeout`. Both patterns must cap goroutine count via semaphore or `SetLimit` to survive slow consumers. At the throughputs typical for developer tooling (hundreds to low thousands of events/sec), the combined transport and serialization overhead is under 20ms per second — invest engineering effort in correctness, testing with `bufconn` and `-race`, and graceful shutdown handling instead of micro-optimizing the wire format.