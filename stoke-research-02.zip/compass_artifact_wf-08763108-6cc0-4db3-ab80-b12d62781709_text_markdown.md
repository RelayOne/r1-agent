# The Kubernetes operations field guide for platform engineers

**Kubernetes justifies its complexity at roughly 20+ microservices, 20+ engineers, and 2+ dedicated platform staff — below these thresholds, Cloud Run and Fly.io remain better choices.** For a VP Eng currently on those platforms evaluating K8s for workloads needing more control, the right move is a hybrid: keep stateless services on Cloud Run/Fly.io, graduate only the workloads that need StatefulSets, network policies, GPU scheduling, or multi-cloud portability. This report distills practitioner-level operational knowledge across all 10 critical domains with specific configurations, anti-patterns, and decision frameworks current through early 2026.

---

## 1. When Kubernetes earns its complexity budget

The strongest version of the "you probably don't need Kubernetes" argument comes from practitioners who ran K8s for years and migrated away. Ben Houston moved Clara.io's 3D rendering platform entirely to Cloud Run in 2024, finding it "difficult to provision, expensive to maintain, and time-consuming to manage." The Spectro Cloud 2025 State of Production Kubernetes Report found **88% of organizations reported rising TCO**, with 42% naming cost as their top pain point.

The practitioner heuristics are remarkably consistent across sources. Teams below **5-10 engineers with no dedicated infra staff** will lose productivity to K8s overhead. A reliable production K8s environment typically requires **~4 DevOps/Platform engineers at ~$141K average compensation — over $500K/year** before infrastructure spend. Below $3-5K/month in infrastructure, PaaS alternatives are more cost-effective. The service count threshold sits around **20+ microservices** with complex inter-service dependencies; at 3-5 services, Docker Compose or Cloud Run handles everything.

The counterpoints are equally strong. K8s is the de facto industry standard with 1,200+ job postings in Q1 2025 versus 176 for Docker Swarm. Once mastered, it provides a consistent deployment model across all environments. For stateful workloads, GPU scheduling, service mesh, network policies, and compliance-driven namespace isolation, no simpler platform provides viable alternatives. Managed K8s has gotten significantly easier — as one HN practitioner put it, "it just chugs along, self-healing, with essentially zero maintenance."

**What you specifically lose moving from Cloud Run + Fly.io to K8s:** scale-to-zero without complex KEDA setup, pay-per-request pricing, sub-second deployment updates, zero-ops simplicity, and Fly.io's native global edge distribution. **What you gain:** StatefulSets, service mesh, network policies, CRDs and operators, namespace-based multi-tenancy with RBAC, pod disruption budgets, GPU device plugins, sophisticated autoscaling (HPA, VPA, Karpenter), and multi-cloud portability.

Google's own documentation now explicitly recommends the hybrid approach: run stateless microservices on Cloud Run for cost efficiency, deploy complex stateful applications requiring deep customization on GKE. This is likely the right architecture for a multi-product platform — Cloud Run for the long tail of HTTP services, GKE for the workloads that genuinely need scheduling control.

---

## 2. Resource management: the no-CPU-limits consensus and right-sizing reality

The 2025 consensus has coalesced around a position that would have been controversial three years ago: **set CPU requests but do NOT set CPU limits** for most production workloads. CPU is compressible — when a container exceeds its request, the kernel proportionally assigns CPU time via CFS rather than killing the process. CPU limits cause CFS throttling: a multi-threaded app using 4 cores with a 0.5 vCPU limit consumes its quota in 12.5ms and is throttled for the remaining 87.5ms of the 100ms CFS period. This throttling affects all threads, including those processing liveness probes, which can cascade into probe failures and container restarts.

Memory limits, conversely, should **almost always be set**. Memory is incompressible — exceeding a limit triggers an OOM kill, but without a limit, a memory leak can consume all node memory, affecting every pod on the node.

The recommended baseline for most workloads is Burstable QoS:

```yaml
containers:
- name: api
  resources:
    requests:
      cpu: "250m"       # Based on P95 observed usage
      memory: "512Mi"
    limits:
      # cpu: intentionally omitted — burstable
      memory: "1Gi"     # ~2x request for headroom
```

Reserve Guaranteed QoS (requests equal limits for both CPU and memory) for payment processing, databases, and latency-critical APIs where predictable performance outweighs burst capacity. Never deploy BestEffort pods (no resource spec) in production — they are evicted first under any node pressure.

**Vertical Pod Autoscaler reached a milestone with Kubernetes 1.35 (December 2025):** in-place pod vertical scaling graduated to GA. VPA 1.2+ introduced the `InPlaceOrRecreate` update mode, eliminating the biggest adoption barrier — forced pod restarts for resource changes. Start VPA in `Off` mode (recommendations only) and use **Goldilocks** to visualize recommendations across entire namespaces. The 2025 Kubernetes Benchmark Report shows average CPU utilization at just **10%** and memory at **23%** — organizations typically achieve **30-50% cost reduction** from right-sizing alone.

**Critical VPA + HPA pitfall:** never let VPA and HPA scale on the same metric. VPA lowers per-pod requests based on lower usage; HPA's percentage thresholds shift underneath, creating a death spiral of smaller pods and more replicas. Use HPA on custom metrics (requests per second, queue depth) and VPA on CPU/memory.

For OOM debugging, the detection chain is: `kubectl describe pod` → look for `Reason: OOMKilled, Exit Code: 137` → check node `dmesg | grep -i oom` → inspect cgroup v2 memory events at `/sys/fs/cgroup/<pod-path>/memory.events`. In cgroup v2 (default since K8s 1.25), OOM kills terminate the entire cgroup, not individual processes. Watch for "invisible" OOM kills in cgroup v1 environments where a child process dies but PID 1 survives, leaving the container running in a broken state.

Set **LimitRange** defaults per namespace so pods without explicit resource specs get sane values. Gotcha: LimitRange does not validate consistency of its own defaults — if `default` (limit) is less than `defaultRequest`, pods become unschedulable with a confusing error.

---

## 3. Deployment strategies tuned for zero-downtime rollouts

The default rolling update parameters (`maxSurge: 25%`, `maxUnavailable: 25%`) are reasonable for balanced workloads but wrong for zero-downtime critical APIs. For those, set **`maxSurge: 1, maxUnavailable: 0`** — this ensures capacity never drops below current levels, replacing one pod at a time. For resource-constrained clusters where you cannot afford surge capacity, invert: `maxSurge: 0, maxUnavailable: 1`. Always pair rolling updates with `minReadySeconds: 30` (wait 30 seconds after ready before proceeding) and `progressDeadlineSeconds: 600` (fail the deployment if no progress in 10 minutes).

**Argo Rollouts is the de facto standard for progressive delivery in 2025.** It replaces the native Deployment with a Rollout CRD that supports canary analysis with metric-based promotion:

```yaml
strategy:
  canary:
    steps:
    - setWeight: 10
    - pause: { duration: 5m }
    - analysis:
        templates:
        - templateName: success-rate   # Prometheus query: success rate ≥ 99%
    - setWeight: 25
    - pause: { duration: 10m }
    - setWeight: 50
    - pause: { duration: 10m }
    - setWeight: 100
```

The AnalysisTemplate queries Prometheus to verify the canary's success rate stays above 99% before advancing. On failure, Argo Rollouts automatically rolls back. Use `dynamicStableScale: true` to reduce the stable ReplicaSet as canary weight increases, saving resources during high-replica rollouts.

**Probes are the critical deployment safety net**, and misconfigured probes cause more production incidents than bad code. The correct pattern uses three separate probes: a **startup probe** with generous timeout (up to 5 minutes for JVM apps), a **liveness probe** checking only the container's own health (never dependencies), and a **readiness probe** on a separate endpoint that checks dependencies. The most dangerous anti-pattern is a liveness probe that checks database connectivity — when the database goes down, every pod restarts simultaneously, turning a partial outage into a complete cascading failure.

---

## 4. Pod disruption budgets: the single-replica trap and unhealthy eviction

PDBs protect against voluntary disruptions (node drains, autoscaler scale-down, eviction API calls) but not involuntary ones (node crashes, OOM kills, `kubectl delete pod`). **Prefer `maxUnavailable` over `minAvailable`** — it automatically adapts when replica count changes via HPA, while `minAvailable` requires manual updates whenever you rescale.

The most common and dangerous PDB misconfiguration is `minAvailable: 1` on a **single-replica deployment**. This means zero voluntary evictions are ever allowed — `kubectl drain` hangs indefinitely, the cluster autoscaler cannot scale down the node, and automated reboot tools cannot function. This was a real bug in JupyterHub's Helm chart. Use `maxUnavailable: 1` instead, which always permits one pod to be disrupted.

Since Kubernetes 1.31, the `unhealthyPodEvictionPolicy` field graduated to GA. **Set `AlwaysAllow` on every PDB.** The default `IfHealthyBudget` creates a deadlock where pods in CrashLoopBackOff cannot be evicted because they count as unhealthy for PDB purposes, blocking node drains indefinitely. This is the number one cause of stuck node drains in production:

```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: api-pdb
spec:
  maxUnavailable: 1
  selector:
    matchLabels:
      app: api-server
  unhealthyPodEvictionPolicy: AlwaysAllow
```

For maintenance windows, drain nodes sequentially with `kubectl drain node-X --timeout=300s --ignore-daemonsets`. Monitor PDB status — if `ALLOWED DISRUPTIONS = 0`, identify which PDB is blocking. For critical workloads that must not be disrupted without explicit coordination, set `maxUnavailable: 0` temporarily, then delete the PDB when ready for maintenance and recreate afterward.

---

## 5. Network policies: default deny first, then allow specifically

Kubernetes operates a flat network by default — **every pod can communicate with every other pod across all namespaces**. This is the most dangerous default in Kubernetes networking. The single most important network policy is default-deny applied to every namespace:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: production
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
```

**The number one gotcha after applying default-deny egress: DNS breaks.** Every pod needs access to CoreDNS in kube-system. Always pair default-deny with a DNS allow policy targeting `k8s-app: kube-dns` in the `kube-system` namespace on UDP/TCP port 53.

A subtle but critical YAML mistake involves AND versus OR logic. A single `from` entry with both `namespaceSelector` and `podSelector` creates an AND condition (must match both). Separate array entries create OR (either matches). Incorrect indentation silently changes policy semantics.

**Cilium vs Calico in 2025:** performance is nearly identical in eBPF mode (P50 latency ~0.15ms vs ~0.16ms). Choose Cilium for greenfield deployments needing L7 policies (HTTP method/path filtering), DNS-aware egress (`toFQDNs`), or sidecar-free service mesh. Choose Calico for brownfield environments with BGP peering, mixed Linux/Windows, or teams familiar with traditional networking. Major cloud providers are converging on Cilium — GKE Dataplane V2 and AKS Azure CNI both use it. Critically, **Flannel does not support NetworkPolicy at all** — policies are silently ignored with no error, no enforcement.

Standard NetworkPolicies operate at L3/L4 only. Cilium's CiliumNetworkPolicy CRD extends to L7, allowing rules like "allow only GET requests to `/api/v1/*` from the frontend service." For teams running Istio, AuthorizationPolicy provides similar L7 control via sidecar proxies. Cilium collapses these layers — its eBPF dataplane provides L7 enforcement without sidecars, potentially eliminating the need for a separate service mesh.

---

## 6. RBAC designed for multi-team clusters at scale

Use `Role` + `RoleBinding` (namespace-scoped) for 95% of cases. `ClusterRole` + `ClusterRoleBinding` is only for cluster-scoped resources like nodes, persistent volumes, and namespaces. The most important RBAC hardening step: **set `automountServiceAccountToken: false`** on every ServiceAccount and pod that doesn't explicitly need API access. The default service account is auto-assigned to all pods — if any pod is compromised, the attacker inherits whatever permissions are bound to `default`.

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: my-app-sa
automountServiceAccountToken: false
```

Since Kubernetes 1.24, **long-lived service account token Secrets are no longer auto-created**. The kubelet uses projected volume tokens that are time-limited (default 1 hour, auto-rotated), audience-bound, and object-bound. CI/CD pipelines should use `kubectl create token cicd-deployer --duration=60m` for time-bounded tokens, not static credentials.

For multi-team clusters, give each team a namespace with a "namespace admin" Role bound to an IdP group (via OIDC with Dex or Keycloak), not individual users. CI/CD service accounts should receive the minimum permissions needed — typically `get/list/create/update/patch` on Deployments, Services, and ConfigMaps, with **no delete permission and no secrets access**. Common anti-patterns to avoid: granting `cluster-admin` to CI/CD, using wildcards in verbs/resources (silently grants access to future resource types), adding users to `system:masters` (bypasses all RBAC permanently), and granting `list` or `watch` on secrets (effectively allows reading all secret contents).

Test RBAC before applying with impersonation: `kubectl auth can-i create deployments --as=system:serviceaccount:production:cicd-deployer -n production`.

---

## 7. Secrets management: base64 is not encryption

**Base64 is encoding, not encryption.** `echo 'TXlQYXNzd29yZDEyMw==' | base64 -d` outputs plaintext instantly. Kubernetes Secrets are stored in etcd as base64-encoded plaintext by default. The mandatory minimum baseline is enabling encryption at rest via `EncryptionConfiguration` with `aescbc` (or preferably the `kms` v2 provider to keep encryption keys outside the cluster via AWS KMS, GCP Cloud KMS, or Azure Key Vault).

For GitOps-driven secrets, the decision framework maps to team maturity:

- **Sealed Secrets** (~$200/month): Asymmetric encryption via `kubeseal` CLI. SealedSecret CRDs are safe to commit to Git. Best for single-cluster, small teams. Limitation: cluster-specific encryption, no automatic rotation.
- **SOPS + age/KMS** (free): Encrypts YAML values in-place. Integrates natively with Flux. No external infrastructure required. Best for smaller teams wanting GitOps-native secrets without a secrets manager.
- **External Secrets Operator** (~$530/month): Git contains only `ExternalSecret` references, not values. ESO fetches from AWS Secrets Manager, GCP Secret Manager, or Vault at runtime. Best for cloud-native, multi-cluster environments. Run ESO with **2+ replicas** — single-replica ESO stops syncing during pod restarts.
- **HashiCorp Vault** (~$2,400/month): Full dynamic secret generation, automatic rotation, comprehensive audit logging. Best for enterprise compliance.

**Always mount secrets as files, never environment variables.** Environment variables are set at pod creation and never updated — they require pod restarts for rotation. Volume-mounted secrets are automatically updated by kubelet when the underlying Secret changes (default ~1 minute sync). Applications should watch the file or reload periodically.

---

## 8. Observability sizing: 8KB per active series and the cardinality trap

The Grafana LGTM stack (Loki + Grafana + Tempo + Mimir) is the dominant open-source observability framework, with Grafana Labs recognized as a Gartner Leader in 2025. The **kube-prometheus-stack** Helm chart remains the standard entry point, bundling Prometheus, Grafana, Alertmanager, kube-state-metrics, and node-exporter with pre-configured dashboards.

**The fundamental Prometheus sizing formula: `needed_RAM ≈ active_series × ~8KB`.** Real-world data confirms this — 1.1M active series requires ~9-10 GB RAM. But cardinality is the silent killer. Coveo found Prometheus consuming **30 GB before OOMKill** on 5.5M active series. After dropping high-cardinality labels (particularly the `id` label from kubelet/cAdvisor metrics), sample rate dropped 75% and memory halved to 8 GB. The most common cardinality offenders are `container_*` metrics with `id` labels, ingress controller metrics with `path`/`host` labels, and histogram metrics with dynamic labels.

Practical sizing for the full monitoring stack on a **200-pod cluster with ~500K active series**: Prometheus 8-16 GB RAM; Grafana 512 MB-1 GB; Loki 2-4 GB; Alertmanager 256-512 MB; kube-state-metrics 256-512 MB; node-exporter 64 MB × N nodes; OTel Collector DaemonSet 256 MB × N nodes. **Total: ~15-25 GB on a cluster with 100-200 GB capacity — roughly 10-15%.** Aggressive cardinality optimization reduces this by 40-50%.

**For long-term storage in 2025-2026, Grafana Mimir is recommended for new deployments.** Cortex is effectively dead (most maintainers moved to Mimir). Thanos remains viable for teams already invested in its edge-style architecture (per-cluster Prometheus with sidecar). **VictoriaMetrics** is the dark horse — used by Adidas, Grammarly, Wix, and OpenAI, offering **10x compression** versus Prometheus, single-binary deployment, and dramatically simpler operations. A common hybrid pattern: "Prometheus scrapes, VictoriaMetrics stores."

For collection, deploy **OpenTelemetry Collector as a DaemonSet for log collection** (reads `/var/log/pods`), a **Deployment for metrics scraping** (avoids metric duplication), and optionally sidecars for per-pod trace collection. Always configure the `memory_limiter` processor (`limit_percentage: 80`) to prevent OOM. Grafana Alloy (the successor to Grafana Agent) wraps OTel Collector components with Grafana-specific integrations but uses a non-standard config language.

---

## 9. GitOps: ArgoCD wins on adoption, folder-per-environment is mandatory

**ArgoCD is 2-3x more popular than Flux** by every measure — GitHub stars (17.8K vs 6.5K), job postings, and enterprise adoption. Weaveworks, Flux's primary corporate sponsor, shut down in February 2024. While Flux continues as a CNCF project, ArgoCD's backing by Intuit and the Akuity/Codefresh ecosystem gives it stronger forward momentum. Practitioner consensus: "ArgoCD is for humans, Flux is for robots."

**Branch-per-environment is an anti-pattern.** Branches are designed for temporary divergence; environments are permanently different. Merging staging→prod drags along staging-specific configs, and configuration drift becomes invisible across branches. The recommended pattern uses **folder-per-environment on a single branch** with Kustomize overlays:

```
gitops-repo/
├── base/                    # Common manifests
├── envs/
│   ├── dev/kustomization.yaml
│   ├── staging/kustomization.yaml
│   └── prod/kustomization.yaml
```

Promotion is a PR that copies changes from `envs/dev/` to `envs/staging/` to `envs/prod/`. Akuity's **Kargo** is an emerging tool that automates this promotion flow with policy-driven gates.

**App-of-Apps vs ApplicationSet:** use App-of-Apps when you need **sync waves** (dependency ordering — CRDs before controllers before applications). ApplicationSets do not support sync waves between generated apps. Use ApplicationSets when you need to dynamically generate apps across clusters/environments from templates. The recommended structure is exactly 3 levels: K8s manifests → ApplicationSets → optional root App-of-Apps for bootstrapping. More levels create cognitive overload.

Critical anti-patterns: manual `kubectl apply` alongside GitOps (creates drift that the reconciler overwrites — use Kyverno to block manual changes in production), disabling auto-sync and self-heal (defeats GitOps purpose), using `latest` image tags (impossible to know what's deployed), and CIOps masquerading as GitOps (CI pipeline running `kubectl apply` is push-based, not pull-based).

Enable **`selfHeal: true`** in ArgoCD production applications. Without it, manual kubectl changes persist as silent drift. The rule is absolute: if it's not in Git, it doesn't exist.

---

## 10. Cost optimization: 59% savings from spot, 30-50% from right-sizing

The Cast AI 2025 Kubernetes Cost Benchmark Report quantifies real-world savings: **mixed on-demand + spot clusters average 59% savings; all-spot clusters average 77%**. AWS Spot offers 70-90% discounts, GCP Spot 60-91%. Delivery Hero runs 90% of EKS workloads on spot.

**Karpenter has displaced Cluster Autoscaler for AWS deployments.** Scale-up latency dropped from 3-4 minutes (ASG-based) to **~55 seconds** (pod-aware provisioning). Karpenter's consolidation engine proactively evicts pods to optimize bin-packing, delivering **20-40% additional savings** beyond spot discounts. Use Karpenter on AWS (now also Azure preview); stick with Cluster Autoscaler for multi-cloud or strict change management environments. Key Cluster Autoscaler parameters to tune: `scale-down-unneeded-time` (5m for aggressive, 30m for conservative), `scale-down-utilization-threshold` (0.5 for cost-focused, 0.3 for stability), and `scale-down-delay-after-add` (prevents rapid cycling).

For node selection, **fewer larger nodes are more efficient** — each node carries fixed overhead from kubelet, OS, and DaemonSets. One 4-vCPU/32GB node has ~2.9 GB reserved overhead versus seven 1-vCPU/4GB nodes consuming ~7.7 GB. ARM instances (Graviton on AWS, Ampere on GCP) are **20-40% cheaper** than x86 equivalents; most stateless workloads work out of the box with multi-arch container builds.

**GKE Autopilot vs Standard:** Autopilot is per-resource pricing, roughly **191% more expensive** on a direct price comparison, but cheaper for small/variable workloads with low utilization because you don't pay for idle node capacity. Standard wins at scale with expert tuning. Start with Autopilot for simplicity, graduate to Standard when cost optimization becomes a priority.

Deploy **OpenCost** (CNCF, free) or **Kubecost** (OpenCost + optimization recommendations) from day one. Enforce labeling standards (`team`, `cost-center`, `environment`, `project`) on every workload for chargeback. Set namespace ResourceQuotas to prevent teams from over-provisioning, paired with LimitRange defaults for sane per-pod baselines. The realistic total from a disciplined optimization program: **30-50% cost reduction** from right-sizing, spot instances, and eliminating abandoned resources — not the 80% vendors claim, but substantial.

---

## Conclusion: the hybrid architecture and graduation criteria

The path from Cloud Run + Fly.io to Kubernetes is not a binary switch — it's a selective graduation. Keep the long tail of stateless HTTP services on Cloud Run where scale-to-zero and pay-per-request pricing deliver superior economics. Move to managed GKE or EKS only the workloads that genuinely require StatefulSets, network policy isolation, GPU scheduling, service mesh traffic management, or multi-cloud portability.

When you do move, the operational foundation is non-negotiable: default-deny network policies with DNS allow, RBAC with `automountServiceAccountToken: false`, encryption at rest for secrets with External Secrets Operator, PDBs with `unhealthyPodEvictionPolicy: AlwaysAllow` on every workload, VPA in recommendation mode for right-sizing, and ArgoCD with folder-per-environment GitOps. Start Karpenter and spot instances from day one — the 59% average savings fund the platform team that makes everything else work.

The two insights most likely to save you from production incidents: never use a liveness probe that checks dependencies (it turns partial outages into cascading failures), and never set `minAvailable` equal to your replica count on a PDB (it blocks all node drains forever). These two misconfigurations cause more Kubernetes production incidents than any other operational mistakes.