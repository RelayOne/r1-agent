# Observability SKILL.md: The Complete Agent Ruleset for Production-Grade Instrumentation

**Every service must ship with observability built in from day one.** This SKILL.md encodes the complete set of patterns — from OpenTelemetry instrumentation to SLO-based alerting to cost control — that AI coding agents should enforce when generating, modifying, or reviewing production services. The document synthesizes current best practices from Google SRE, OpenTelemetry (v1.40.0 semantic conventions, stable spec 1.55.0), Prometheus, Grafana Labs, and Honeycomb's observability-driven development philosophy as of 2025–2026.

---

## SKILL.md frontmatter and activation rules

```yaml
---
name: observability-enforcer
description: >
  Ensures all new services, endpoints, middleware, and infrastructure code include
  proper observability instrumentation following OpenTelemetry, Prometheus, and
  Google SRE best practices. Activates when creating new services, HTTP/gRPC handlers,
  middleware, Kubernetes manifests, CI/CD pipelines, or when asked to add monitoring,
  alerting, dashboards, logging, tracing, or health checks.
metadata:
  author: "Platform Engineering"
  version: "2.0.0"
  tags: [observability, monitoring, alerting, sre, opentelemetry]
---
```

The SKILL.md format (published by Anthropic at agentskills.io, December 2025) is now supported by **27+ AI coding agents** including Claude Code, Cursor, OpenAI Codex, Gemini CLI, VS Code Copilot, Amp, Roo Code, and Windsurf. Skills live in `~/.claude/skills/` (personal) or `.claude/skills/` (project-level) and use three-level progressive disclosure: metadata (~100 tokens loaded at startup), instructions (loaded on trigger), and references (loaded on demand). The frontmatter `description` field must explain both *what* the skill does and *when* it activates. Keep instruction bodies under **5,000 tokens** and offload templates to `references/` directories.

Related formats serve complementary roles. **AGENTS.md** provides always-on project context loaded every prompt. **CLAUDE.md** holds Claude-specific project rules loaded at conversation start. Cursor now uses `.cursor/rules/*.mdc` files with glob patterns for file-type-specific rules. The enforcement pattern is layered: AGENTS.md declares standards, SKILL.md provides on-demand implementation templates, and hooks (PreToolUse/PostToolUse) validate generated code against requirements.

---

## 1. OpenTelemetry implementation patterns

OpenTelemetry is the single instrumentation standard every service must adopt. The **hybrid approach** — auto-instrumentation for infrastructure telemetry plus manual instrumentation for critical business paths — is the consensus best practice across Grafana Labs, Google, and the OTel community.

### Auto-instrumentation versus manual instrumentation

Auto-instrumentation covers the "edges" of an application (HTTP requests, database queries, external API calls) with zero code changes. **Java** is the most mature, using `-javaagent` injection. **Python** wraps applications with `opentelemetry-instrument`. **Node.js** uses the `@opentelemetry/auto-instrumentations-node` package. **Go** reached beta in 2025 via eBPF. **.NET** uses the CLR profiler. In Kubernetes, the **OpenTelemetry Operator** injects instrumentation via a single annotation (`instrumentation.opentelemetry.io/inject-python: "true"`), eliminating per-service configuration.

Manual instrumentation is required for business-specific spans — "Loan Approval," "Fund Transfer," "Checkout Validation" — that auto-instrumentation cannot detect. The rule is: **auto-instrument everything, then add manual spans for the operations that matter to your business**.

```javascript
// Node.js: SDK initialization with selective auto-instrumentation
const sdk = new NodeSDK({
  resource: new Resource({
    [SemanticResourceAttributes.SERVICE_NAME]: 'payment-service',
    [SemanticResourceAttributes.SERVICE_VERSION]: '1.2.0',
    'deployment.environment': 'production'
  }),
  traceExporter: new OTLPTraceExporter(),
  instrumentations: [getNodeAutoInstrumentations({
    '@opentelemetry/instrumentation-fs': { enabled: false },
    '@opentelemetry/instrumentation-http': {
      ignoreIncomingRequestHook: (req) => req.url === '/healthz',
    }
  })]
});
sdk.start();
```

### Trace context propagation across protocols

All services must use **W3C TraceContext** as the default propagator. The `traceparent` header (`00-{traceId}-{spanId}-{flags}`) propagates automatically across HTTP via auto-instrumentation and across gRPC via metadata interceptors. Kafka requires explicit header injection: call `inject(headers)` on the producer side and `extract(carrier)` on the consumer side to maintain trace continuity across async boundaries. Set propagators via `OTEL_PROPAGATORS="tracecontext,baggage"`. Add `b3` only for Zipkin/Istio compatibility.

### Sampling strategies

**Head-based sampling** decides at trace creation. Use `parentbased_traceidratio` as the default sampler (set via `OTEL_TRACES_SAMPLER`). A **10% sample rate** is a reasonable production starting point for high-traffic services. **Tail-based sampling** decides after all spans arrive, enabling policies like "keep 100% of errors, 100% of slow requests >2s, and 5% of everything else." Configure tail sampling in the **OTel Collector** using the `tail_sampling` processor — this requires routing all spans from a trace to the same Collector instance. In 2025, OTel published a consistent probability sampling milestone using `tracestate` encoding, solving long-standing issues with `TraceIdRatioBased` behavior.

### OTel Collector deployment

**Always deploy an OTel Collector** between applications and backends. Use the **agent+gateway pattern**: DaemonSet agents on each node handle local collection and enrichment, gateway Deployments handle centralized processing (tail sampling, routing). The critical pipeline ordering rule is: **`memory_limiter` first → `resourcedetection` → `transform/filter` → `batch` last**. Build custom Collector distributions using `ocb` (OpenTelemetry Collector Builder) to include only needed components, reducing attack surface and resource usage.

```yaml
# OTel Collector pipeline — production configuration
processors:
  memory_limiter:                    # ALWAYS first
    limit_mib: 4000
    spike_limit_mib: 800
  resourcedetection:
    detectors: [env, system, k8s_node]
  batch:                             # ALWAYS last
    send_batch_size: 1024
    timeout: 5s

service:
  pipelines:
    traces:
      receivers: [otlp]
      processors: [memory_limiter, resourcedetection, batch]
      exporters: [otlp/tempo]
    metrics:
      receivers: [otlp]
      processors: [memory_limiter, resourcedetection, batch]
      exporters: [prometheus]
    logs:
      receivers: [otlp]
      processors: [memory_limiter, resourcedetection, batch]
      exporters: [otlphttp/loki]
```

### SDK configuration essentials

Every service must set `OTEL_SERVICE_NAME` explicitly — never deploy with `unknown_service`. Required resource attributes: `service.name`, `service.version`, `deployment.environment`, `service.namespace`, `service.instance.id`. **Always register shutdown hooks** to flush pending telemetry; without them, the final batch of spans is lost on process exit. Use `OTEL_SDK_DISABLED=true` as an emergency kill switch. Follow stable semantic conventions (HTTP attributes renamed: `http.method` → `http.request.method`, `http.status_code` → `http.response.status_code`) and opt in via `OTEL_SEMCONV_STABILITY_OPT_IN=http`.

---

## 2. Structured logging standards every service must follow

### JSON log format specification

Every log entry must be a machine-parseable JSON object. The required fields are: **`timestamp`** (ISO 8601 UTC), **`level`**, **`message`**, **`service`**, **`trace_id`**, and **`span_id`**. Use snake_case consistently. Keep structure flat at the top level with nested objects for domain groups (`error.type`, `http.method`). Never nest deeper than three levels.

```json
{
  "timestamp": "2025-01-15T10:23:45.123Z",
  "level": "error",
  "message": "Payment processing failed",
  "service": "payment-service",
  "version": "2.1.0",
  "environment": "production",
  "trace_id": "5b8efff798038103d269b633813fc60c",
  "span_id": "eee19b7ec3c1b174",
  "error": {
    "type": "PaymentGatewayTimeout",
    "message": "Gateway responded in 30.2s",
    "code": "GATEWAY_TIMEOUT"
  }
}
```

### Correlation ID propagation

Use **W3C Trace Context** as the primary correlation mechanism. The OpenTelemetry Log Bridge API automatically injects active `TraceId` and `SpanId` into every log record, enabling one-click jumps from a log line to the exact trace and distributed timeline. For Java, use MDC (Mapped Diagnostic Context) with Micrometer's context-propagation library to bridge across async/reactive flows — **always clear MDC in `finally` blocks** to prevent context leakage between requests in thread pools. For Node.js, use `AsyncLocalStorage`. For Python, use `contextvars`.

### Log level discipline

| Level | Use when | Alert? |
|-------|----------|--------|
| **FATAL** | Unrecoverable failure; process must terminate | Immediate page |
| **ERROR** | Operation failed, user's request cannot complete | High-priority alert |
| **WARN** | Recoverable issue or degraded condition (retry succeeded, approaching threshold) | Slack/ticket |
| **INFO** | Significant business events (user created, order placed, deployment completed) | No |
| **DEBUG** | Implementation details for troubleshooting — **OFF in production by default** | No |

The most common mistake is **logging expected validation errors as ERROR**. Invalid user input is DEBUG or INFO. A successful retry after a timeout is WARN, not ERROR. Production log level must be INFO; enable DEBUG only temporarily during incidents via runtime configuration (Spring Boot Actuator `/actuator/loggers`, ConfigMap-based hot reload, or feature flags).

### Sensitive data masking

Mask PII **at the source** before serialization — never rely solely on downstream processors. Maintain a sensitive field names list (`password`, `token`, `api_key`, `email`, `ssn`, `credit_card`, `authorization`) and apply regex pattern matching for common PII formats (emails, SSNs, credit card numbers, JWTs). Use a **whitelist of safe fields** rather than trying to blacklist sensitive ones. AWS CloudWatch supports managed data protection policies with automated PII detection.

### Log volume budgeting

A single service at 10K req/s generating 500 bytes/log produces **~430 GB/day**. Target **1–3 log lines per normal request** in production (entry + exit + any warnings). Set per-service daily quotas with alerts at 80%. Always include a `sample_rate` field in sampled logs so analysis can compensate for dropped data. Filter health check logs at the Collector level — this alone eliminates **20–40% of log volume**.

### Aligning with ECS and OTel log data model

The Elastic Common Schema (ECS, v9.3) is converging with OpenTelemetry Semantic Conventions to create a single open schema. Key mappings: `log.level` (ECS) ↔ `SeverityText` (OTel), `trace.id` (ECS) ↔ `TraceId` (OTel). The OTel Log Data Model (stable as of spec 1.55.0) uses the **Log Bridge API** — it does not replace existing logging libraries but intercepts log records from SLF4J, Python stdlib logging, or .NET ILogger, converts them to OTel `LogRecord` format, and automatically attaches active trace context.

---

## 3. Metrics design using RED, USE, and Prometheus conventions

### RED method for every request-driven service

Created by Tom Wilkie, RED measures **Rate** (requests/second), **Errors** (failed requests/second), and **Duration** (latency distribution). RED is a proxy for customer happiness — high error rate means page load errors for users; high duration means slow pages. Every HTTP, gRPC, and message-consuming service must expose RED metrics.

```promql
# Rate: requests per second
rate(http_requests_total[5m])

# Error rate: percentage of 5xx responses
sum(rate(http_requests_total{code=~"5.."}[5m])) / sum(rate(http_requests_total[5m]))

# Duration: p50, p95, p99 latency
histogram_quantile(0.99, sum(rate(http_request_duration_seconds_bucket[5m])) by (le))
```

### USE method for every resource

Created by Brendan Gregg, USE measures **Utilization** (time resource was busy), **Saturation** (queued work), and **Errors** for every resource: CPU, memory, disk, network, database connection pools, thread pools, file descriptors. Key insight: **low average utilization does not mean no saturation** — bursts of 100% utilization cause latency spikes even when 5-minute averages look healthy.

```promql
# CPU Utilization
1 - avg(rate(node_cpu_seconds_total{mode="idle"}[5m])) by (instance)

# DB Connection Pool Utilization
hikaricp_connections_active / hikaricp_connections_max

# Thread Pool Saturation
executor_queued_task_count
```

### Histogram bucket selection

Prometheus default buckets (`[0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10]`) cover typical web services. For custom buckets, use **10–15 exponentially-spaced buckets** and always include boundaries around SLO thresholds. **Prometheus Native Histograms** (stable as of Prometheus v3.8, announced at PromCon EU 2025, GA in Grafana Cloud) eliminate manual bucket configuration entirely — they use sparse exponential buckets, produce a single time series instead of N+2, and are compatible with OpenTelemetry exponential histograms. Enable via `NativeHistogramBucketFactor: 1.1` (~10% bucket width).

### Cardinality explosion prevention

Every unique combination of metric name + label values = one time series. A metric with `method` (5) × `handler` (10) × `status_code` (50) = **2,500 series**. **Never use** user IDs, request IDs, trace IDs, email addresses, or URL paths with dynamic segments as labels. Use exemplars for debugging data (trace IDs attached to metrics without creating new series). Set `sample_limit: 5000` per scrape target. Monitor cardinality with `topk(10, count by (__name__) ({__name__=~".+"}))`. For debugging data that needs metric-like access, use exemplars or recording rules for pre-aggregation.

### Prometheus naming conventions

Metric names must use **snake_case** with a namespace prefix, base unit suffix in plural (`_seconds`, `_bytes`, `_total` for counters), and no colons in directly instrumented metrics (reserved for recording rules). Never put label values in metric names: use `http_requests_total{method="GET"}`, not `http_get_requests_total`. Choose metric types deliberately: counters for things that only increase (use `rate()`), gauges for values that go up and down, histograms for distributions needing percentiles.

---

## 4. SLO-based alerting that prevents alert fatigue

### Multi-window multi-burn-rate alerting

This is the **gold standard** from Google SRE Workbook Chapter 5. Burn rate measures how fast a service consumes its error budget relative to the SLO. A burn rate of 1 exhausts the budget exactly at the end of the window; 14.4 exhausts **2% in 1 hour**. The multi-window approach combines a long window (ensuring statistical significance) with a short window (ensuring the problem is still active) using AND logic.

| Severity | Long Window | Short Window | Burn Rate | Budget Consumed |
|----------|-------------|--------------|-----------|-----------------|
| **Page** | 1 hour | 5 minutes | 14.4 | 2% |
| **Page** | 6 hours | 30 minutes | 6 | 5% |
| **Ticket** | 24 hours | 2 hours | 3 | 10% |
| **Ticket** | 3 days | 6 hours | 1 | 10% |

```yaml
# Page-level: Fast burn (14.4x, 2% budget in 1 hour)
- alert: ErrorBudgetFastBurn
  expr: |
    (
      job:slo_errors_per_request:ratio_rate1h{job="myjob"} > (14.4 * 0.001)
    and
      job:slo_errors_per_request:ratio_rate5m{job="myjob"} > (14.4 * 0.001)
    )
  labels:
    severity: page
  annotations:
    summary: "High error budget burn rate (14.4x)"
    runbook_url: "https://wiki.example.com/runbooks/error-budget-burn"
```

Use tools like **Sloth** (sloth.dev) to auto-generate these rules from simple SLO specifications. Pre-compute SLIs as recording rules at 1–5 minute intervals for efficient burn rate calculation.

### Error budget policies

When error budget is exhausted: **freeze non-critical deployments**. Google's policy halts all changes except P0 issues or security fixes until the service is back within SLO. A tiered approach works well: >50% budget remaining = ship normally; 20–50% = reduce deployment frequency; 1–20% = freeze non-critical features; 0% = complete feature freeze, all hands on reliability.

### Rob Ewaschuk's alerting philosophy

Every alert must be **urgent, important, actionable, and real**. Alert on **symptoms, not causes** — "the website error rate went up" catches far more issues than "one MySQL replica is down" (which may have zero user impact). The further up the serving stack you alert from, the more problems a single rule catches. If you can ever ignore an alert knowing it's benign, that alert should be removed.

### Alert routing and suppression

Route by severity in Alertmanager: critical → PagerDuty immediately, warning → Slack, info → email. Use **inhibition rules** to automatically suppress cascading alerts (NodeDown suppresses all pod alerts on that node). Automate silence creation in deployment pipelines via the Alertmanager API. Use `mute_time_intervals` for recurring maintenance windows (business hours vs. after hours routing). Every alert must link to a runbook via the `runbook_url` annotation.

---

## 5. Dashboard as code with Grafana

### Grafana JSON provisioning

Store dashboards as JSON in Git and provision via YAML providers that scan a directory on startup. Set `allowUiUpdates: false` to enforce GitOps — all changes must flow through version control. Use `foldersFromFilesStructure: true` to automatically create Grafana folders matching the filesystem hierarchy. **Grafana 12** (2025) introduced Git Sync for direct GitHub two-way synchronization with PR-based review workflows.

### Terraform-managed dashboards

The `grafana/grafana` Terraform provider (v3.0+) manages `grafana_dashboard` and `grafana_folder` resources. Use `for_each` with `fileset()` for bulk deployment. Set `overwrite = true` to prevent state conflicts. Deploy via GitHub Actions triggered on pushes to `dashboards/**` paths. Grafana 12 introduces new Kubernetes-style API resources for dashboards.

### The four golden signals dashboard template

Every service dashboard must have **Row 1** showing all four golden signals at a glance using Stat panels with traffic-light backgrounds (green = healthy, yellow = noteworthy, red = SLO violation):

- **Latency**: `histogram_quantile(0.99, sum(rate(http_request_duration_seconds_bucket{service="$service"}[5m])) by (le))` — show p50, p95, p99
- **Traffic**: `sum(rate(http_requests_total{service="$service"}[5m]))` — requests/sec
- **Errors**: `sum(rate(http_requests_total{service="$service",status=~"5.."}[5m])) / sum(rate(http_requests_total{service="$service"}[5m]))` — error percentage
- **Saturation**: Container CPU/memory vs. limits — `container_memory_working_set_bytes / container_spec_memory_limit_bytes`

Use cascading template variables: datasource → cluster → namespace → service → instance. Add deployment annotations. Link from overview → service detail → debug dashboards.

### Grafonnet and Foundation SDK

**Grafonnet** (auto-generated Jsonnet library at `github.com/grafana/grafonnet`) is the current code-based dashboard approach for Jsonnet workflows. **Grafana Foundation SDK** (Go, TypeScript, Python, Java, PHP) is the recommended path forward for Grafana 12+ — it provides strongly-typed builder libraries with schema validation. Use `grafanactl` CLI to push SDK-generated dashboards to instances. The old `grafonnet-lib` is deprecated.

---

## 6. Incident response automation patterns

### Severity classification (SEV1–SEV4)

| Level | Definition | Response Time | Communication |
|-------|-----------|---------------|---------------|
| **SEV-1** | Complete outage or data breach impacting many customers. SLA broken. | Acknowledge <5 min, update <15 min | Public notification, executive liaison, war room |
| **SEV-2** | Major functionality degraded, significant user impact | Acknowledge <15 min, update <30 min | Dedicated Slack channel, stakeholder notification |
| **SEV-3** | Partial loss of functionality, potential to become SEV-2 | Business hours priority | Team Slack channel, monitor for escalation |
| **SEV-4** | Minor issues not affecting user ability to use the product | Ticket created, first priority above normal | JIRA ticket, monitor |

**Always assume the worst** — if unsure between SEV-2 and SEV-1, treat as SEV-1. Litigate severity in the postmortem, not during the incident. Make definitions metric-driven: "SEV1 means >5% error rate on checkout" rather than "checkout feels broken."

### PagerDuty/OpsGenie integration

Alertmanager natively supports PagerDuty (Events API v2 via `routing_key`) and OpsGenie. Map alert severity to PagerDuty priority using label-based templating. Enable `send_resolved: true` for automatic incident resolution. Be aware of OpsGenie's deduplication via `alias` field — add unique cluster/team labels to `group_by` to prevent cross-team deduplication in multi-cluster setups.

### Blameless postmortems

Follow Google's SRE postmortem template: Summary, Impact (quantified), Root Causes, Trigger, Resolution, Detection, Action Items (with type/owner/status), Lessons Learned (including **"where we got lucky"** — a distinctive Google practice revealing hidden risks), and Timeline. Conduct the review **24–72 hours** after resolution. Focus on systems and processes, never individuals. Reframe blame: "What about our process made it easy to miss that check?" instead of "Person X should have checked."

### Modern incident management platforms

**incident.io** and **Rootly** lead the Slack-native incident management space, both offering AI-powered timelines, automated channel creation, status page updates, and postmortem generation. Both support native Alertmanager integration. **Atlassian has announced OpsGenie shutdown by April 5, 2027**, driving migration to these modern platforms. The key differentiator from PagerDuty is chat-native operation — incidents live entirely in Slack rather than a separate web UI.

---

## 7. Health check patterns for Kubernetes

### Three probes, three purposes

**Startup probes** run first and only during initialization. They protect slow-starting containers (JVM warmup, large model loading) from premature liveness kills. **Liveness probes** detect deadlocks and unrecoverable states — failure triggers a container restart. **Readiness probes** control traffic routing — failure removes the pod from Service endpoints without restarting it.

The most critical rule: **never check downstream dependencies in liveness probes**. The Kubernetes documentation and Spring Boot documentation both explicitly warn against this. When a downstream service fails, liveness probes that check it trigger mass restarts, creating cascading failures that turn a single dependency outage into a complete platform outage.

```yaml
# Production-recommended probe configuration
startupProbe:
  httpGet:
    path: /readyz
    port: 8080
  periodSeconds: 5
  failureThreshold: 12      # Up to 60 seconds to start

livenessProbe:
  httpGet:
    path: /livez
    port: 8080
  periodSeconds: 10          # Not too aggressive
  timeoutSeconds: 2          # Generous to avoid false positives
  failureThreshold: 3        # 30 seconds before restart

readinessProbe:
  httpGet:
    path: /readyz
    port: 8080
  periodSeconds: 5           # More frequent than liveness
  timeoutSeconds: 1
  failureThreshold: 2        # 10 seconds to remove from LB
  successThreshold: 2        # Require 2 successes to re-add
```

### Endpoint design

Expose three endpoints: `/livez` (static 200 or lightweight local check — is the process alive?), `/readyz` (checks owned dependencies like the service's own database — can it serve traffic?), and a separate deep health endpoint for monitoring only (checks all dependencies, not tied to probes). Use the **background health check pattern**: run dependency checks in a background goroutine every 10 seconds, cache the result, and have the probe endpoint return the cached status instantly. This ensures probes respond in under 1ms and dependency load is predictable.

---

## 8. The cost of observability and how to control it

### Pricing reality check

Observability costs frequently exceed compute costs. **Datadog** charges $15–$23/host/month for infrastructure plus $31/host for APM, with custom metrics at $5 per 100 metrics/month — a 1,000-server deployment with full-stack monitoring can reach **$50,000–$120,000+/month**. Custom metrics can constitute up to **52% of total Datadog invoices**. A single metric with 10 endpoints × 3 status codes × 1,000 customer IDs = 90,000 custom metrics = ~$4,500/month from one metric name. All OpenTelemetry metrics are billed as custom metrics, bypassing native integration allowances.

**CloudWatch** charges $0.50/GB for log ingestion (first 10 TB), and its biggest trap is custom metrics: each unique combination of dimensions is billed separately. 100,000 users as a dimension = **$30,000/month** at the first tier. **Grafana Cloud** uses 95th-percentile billing (more forgiving than Datadog) at ~$8/1,000 active series and ~$0.50/GB for logs.

Industry data shows **over 50% of observability spend goes to logs alone**, with **96% of organizations actively taking steps to control costs**. Self-hosting the LGTM stack (Loki, Grafana, Tempo, Mimir) can reduce vendor bills by 70–90%, but requires 0.5–2 FTE SREs ($150K–$600K+/year). Self-hosting becomes cost-effective at roughly 500+ hosts or when observability spend exceeds $10K–15K/month.

### Five strategies that cut costs without losing signal

**Filter at the edge.** Use the OTel Collector to drop health check logs, debug-level logs, and successful fast request traces before they reach your vendor. This alone reduces volume by **40–70%**. Drop `/healthz`, `/metrics`, and `/readyz` logs — they often constitute 30–50% of total volume.

**Implement tail-based sampling.** Keep 100% of error traces and slow requests (>1s), sample 5–10% of everything else. This reduces trace volume by **60–90%** while preserving all actionable data. Configure via the OTel Collector's `tail_sampling` processor with policies for error status, latency threshold, and probabilistic fallback.

**Control cardinality ruthlessly.** Never use unbounded values as metric labels. Fix the top 5 highest-cardinality metrics first (find them with `topk(10, count by (__name__) ({__name__=~".+"}))`). Use recording rules for pre-aggregation. Change scrape intervals from 15s to 60s for non-critical metrics — a **75% cost reduction** on those series.

**Tier your storage.** Hot (7 days, SSD) → Warm (30 days, compressed) → Cold (365 days, S3 at $0.023/GB). Never use default "Never Expire" retention. Use Thanos, Mimir, or VictoriaMetrics for long-term metric storage with automatic downsampling. Route compliance/archival logs directly to S3 instead of expensive ingestion pipelines.

**Evaluate open-source alternatives.** For teams spending $10K+/month, the LGTM stack or ClickHouse-based platforms (SigNoz, OpenObserve) deliver comparable functionality at a fraction of the cost. An OpenTelemetry Demo benchmark showed Datadog at $174/day versus OpenObserve at $3/day for the same 16-microservice workload — a **58x cost difference**.

---

## 9. Mandatory observability checklist for every new service

This is the core enforcement section. AI coding agents must ensure every new service, endpoint, or middleware includes these elements before considering the implementation complete.

### Every new service must include

```markdown
## Health Endpoints
- GET /livez — returns 200 if process is alive (no dependency checks)
- GET /readyz — returns 200 when ready to serve (checks owned DB/cache)
- GET /metrics — Prometheus-format metrics endpoint

## OpenTelemetry Initialization
- Tracer provider initialized in main() with service.name, service.version,
  deployment.environment resource attributes
- W3C TraceContext propagation configured
- Auto-instrumentation enabled for HTTP/gRPC/DB clients
- Shutdown hook registered for telemetry flushing
- OTEL_SDK_DISABLED support as emergency kill switch

## RED Metrics (minimum)
- http_request_duration_seconds (histogram: method, path, status_code)
- http_requests_total (counter: method, path, status_code)

## Structured JSON Logging
- All logs output as JSON with: timestamp, level, message, service,
  trace_id, span_id
- PII masking applied at the source for known sensitive fields
- Production log level set to INFO

## Kubernetes Manifests
- Startup, liveness, and readiness probes configured
- Resource requests and limits set
- PodMonitor or ServiceMonitor for Prometheus scraping
```

### Every new HTTP handler must include

```go
func observabilityMiddleware(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        ctx, span := tracer.Start(r.Context(), r.URL.Path)
        defer span.End()
        start := time.Now()
        wrapped := &responseWriter{ResponseWriter: w, statusCode: 200}
        next.ServeHTTP(wrapped, r.WithContext(ctx))
        duration := time.Since(start)
        requestDuration.WithLabelValues(r.Method, r.URL.Path,
            strconv.Itoa(wrapped.statusCode)).Observe(duration.Seconds())
        logger.Info("request completed",
            "traceId", span.SpanContext().TraceID().String(),
            "method", r.Method, "path", r.URL.Path,
            "status", wrapped.statusCode, "duration_ms", duration.Milliseconds())
    })
}
```

### Every new SLO must include

Alerting rules following multi-window multi-burn-rate pattern (14.4x/1h for page, 6x/6h for page, 1x/3d for ticket), a Grafana dashboard with golden signals in Row 1, a runbook linked via `runbook_url` annotation, and error budget policy thresholds.

### Enforcement via hooks and CI

Use Cursor's glob-pattern rules (`.cursor/rules/observability.mdc` targeting `**/handlers/**/*.go`, `**/routes/**/*.ts`) to trigger observability checks on handler code. Use PostToolUse hooks to validate generated code includes required imports (OTel SDK, structured logger). Run custom linting in CI that verifies `/healthz` and `/readyz` endpoints exist, structured logging is configured, and OTel initialization is present.

---

## 10. Debugging in production without SSH access

### Structured logs and distributed tracing as the primary debugging tools

Production debugging starts with querying structured logs by `trace_id` to reconstruct the complete request flow across all services. OpenTelemetry automatically correlates logs with traces — click a log line to jump to the exact trace and span, then use the waterfall view to identify slow spans, error attribution, and cross-service latency. Always include domain-specific identifiers (`orderId`, `userId`, `tenantId`) as log context fields for business-level debugging.

### Dynamic log level changes without restarts

Use Spring Boot Actuator's `/actuator/loggers` endpoint (POST to change levels at runtime), ConfigMap-based hot reload with Log4j2's `monitorInterval`, or **feature flags for targeted debugging**. LaunchDarkly multivariate flags enable verbose logging for specific users, specific services, or a percentage of traffic — all without restarts and with real-time propagation. This is "debug logging with an audience."

### Continuous profiling with Grafana Pyroscope

Deploy Pyroscope for always-on, low-overhead profiling (**~2–5% overhead**). Go services expose pprof endpoints on a separate internal-only port behind auth middleware. Pyroscope supports push mode (Go/Java/Python SDKs) and pull mode (scraping pprof endpoints). Secure production pprof endpoints with token-based auth, rate limiting, and network-level restrictions — never expose to public traffic.

### Ephemeral debug containers for when logs and traces aren't enough

Kubernetes ephemeral containers (stable since v1.25) inject debugging tools into running pods without modifying production images. Use `kubectl debug -it my-pod --image=nicolaka/netshoot --target=app` for network debugging, or `kubectl debug node/mynode -it --image=busybox` with `chroot /host` for node-level access — the complete replacement for SSH. For **CrashLoopBackOff** pods, copy the pod with a different command: `kubectl debug myapp -it --copy-to=myapp-debug --container=myapp -- sh`. The `--profile sysadmin` flag grants elevated privileges for accessing the target container's filesystem via `/proc/1/root`.

---

## Conclusion: the observability-driven development mindset

The patterns in this document encode a specific philosophy, articulated most clearly by Charity Majors and the Honeycomb team: **define instrumentation before writing code**, just as TDD defines tests before code. Never accept a pull request without answering "how will I know when this isn't working?" SLOs should be the entry point to understanding system health, not dashboards.

The most impactful shift is moving from infrastructure-focused monitoring (CPU at 95%!) to user-focused observability (are we consuming our error budget faster than planned?). Rob Ewaschuk's principle — alert on symptoms from the user's perspective, not infrastructure causes — eliminates the majority of alert fatigue. Multi-window multi-burn-rate alerting, built on well-defined SLIs, replaces hundreds of threshold-based rules with a handful of alerts that fire only when user experience is genuinely at risk.

For AI coding agents, the enforcement model is layered: AGENTS.md declares the standards (always loaded), SKILL.md provides implementation templates (loaded on demand when generating services/handlers), and CI hooks validate compliance. The goal is not just observability after the fact, but **observability as a first-class design requirement** — every service ships instrumented, every endpoint ships with tracing, every SLO ships with burn-rate alerts and a runbook.