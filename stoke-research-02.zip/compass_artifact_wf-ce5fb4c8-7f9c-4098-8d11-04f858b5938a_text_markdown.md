# Building the central nervous system for AI coding agents

An AI coding tool like Stoke, built around an internal event bus, can integrate with virtually every piece of the developer toolchain by adopting battle-tested protocols and patterns already proven in IDEs, observability systems, and distributed architectures. The key insight across all ten integration areas is that **existing developer infrastructure protocols — LSP, DAP, Prometheus exposition, OpenTelemetry, GitHub Checks — were designed for exactly the kind of structured, streaming, bidirectional event communication that AI agent orchestration demands**. Rather than inventing new protocols, Stoke can adapt these proven models, mapping agent concepts (gate hooks, cost thresholds, approval workflows) onto protocol primitives (stopped events, progress notifications, check run conclusions) that tooling already understands.

This report covers concrete technical patterns, protocol specifications, code examples, and architectural recommendations across all ten integration surfaces, with specific attention to how each pattern applies to AI coding agent tooling.

---

## 1. LSP gives you a proven bidirectional IDE channel

The Language Server Protocol communicates over **JSON-RPC 2.0** with three message types: Requests (carrying an `id` requiring a response), Responses (matching a request `id`), and Notifications (fire-and-forget, no `id`). Messages are framed with `Content-Length` headers over stdin/stdout, TCP, or pipes. This architecture — a single multiplexed bidirectional channel between editor and subprocess — is the foundation for AI agent IDE integration.

**The notification pattern is directly applicable to agent events.** The `textDocument/didChange` notification flows client→server on every keystroke; `textDocument/publishDiagnostics` pushes analysis results server→client asynchronously. For Stoke, custom notifications like `stoke/hookTriggered`, `stoke/costUpdate`, and `stoke/status` follow the identical pattern — the agent pushes structured JSON events to the IDE without expecting a response.

LSP's `$/progress` mechanism provides a complete streaming lifecycle with `begin`, `report`, and `end` phases, plus `partialResultToken` for streaming incremental results within a single request. An agent task maps naturally: `begin` when the task starts, `report` with percentage and message updates as work progresses, `end` when complete. Progress tokens support cancellation, letting users abort agent operations mid-flight.

**Approval workflows map to server→client requests.** LSP already supports this pattern — `window/showMessageRequest` sends a request from server to client that blocks until the user responds. Stoke can define `stoke/requestApproval` as a custom request where the agent asks the IDE to present an approve/deny dialog, and the IDE responds with the user's decision:

```json
{
  "jsonrpc": "2.0",
  "id": 15,
  "method": "stoke/requestApproval",
  "params": {
    "taskId": "task-abc-123",
    "approvalType": "fileEdit",
    "description": "Modify src/auth/middleware.ts",
    "diff": "--- a/src/auth/middleware.ts\n+++ b/src/auth/middleware.ts\n...",
    "timeout": 30000
  }
}
```

Custom method extensions use namespace prefixes — rust-analyzer defines `rust-analyzer/syntaxTree`, clangd uses `textDocument/clangd.fileStatus`, and GitHub Copilot implements `textDocument/inlineCompletion`. Stoke should use the `stoke/` prefix for its custom methods and advertise capabilities through the `experimental` field during initialization.

**The Agent Client Protocol (ACP)**, launched by Zed Industries in August 2025 and co-developed with JetBrains, is directly modeled on LSP for AI agent communication. It uses JSON-RPC 2.0 over stdin/stdout with session management, streaming responses via notifications, and MCP tool integration. Compatible agents include Google Gemini CLI, Kiro, and Codex; supported editors include Zed, JetBrains, and Neovim. Implementing ACP compatibility would give Stoke plug-and-play access to this growing ecosystem.

---

## 2. DAP's stopped/continued cycle maps perfectly to gate hooks

The Debug Adapter Protocol uses a **hybrid push/pull model** that is remarkably well-suited to AI agent activity streaming. The adapter pushes lightweight event notifications (`stopped`, `continued`, `output`, `progress`), and the client lazily requests detailed state on demand. This is the exact pattern an AI agent needs: push high-level status changes, let the UI drill into details only when the developer wants them.

The central DAP interaction loop — **stopped → inspect → continued** — maps directly to Stoke's gate hook workflow. When an agent hits a configured boundary (cost threshold, permission check, dangerous operation), it emits a `stopped` event with a custom reason:

```json
{
  "seq": 100,
  "type": "event",
  "event": "stopped",
  "body": {
    "reason": "cost_threshold",
    "description": "Agent paused: estimated cost exceeds $0.50 budget",
    "threadId": 1,
    "text": "Current spend: $0.48, Projected: $0.72",
    "allThreadsStopped": true
  }
}
```

The `reason` field accepts custom strings (the spec uses `| string` union types), enabling reasons like `cost_threshold`, `permission_boundary`, `human_review`, and `tool_confirmation`. After the user inspects agent state and approves, the client sends a `continue` request and the agent resumes.

**DAP's lazy-loading waterfall is ideal for agent state inspection.** Just as a debugger lazily loads threads → stack frames → scopes → variables, an "AI Debug Adapter" would expose agent threads (parallel work streams) → reasoning trace (decision chain) → scopes (loaded files, conversation context, tool state, token budget) → individual variables. The UI only fetches what the developer expands — no need to transfer all loaded file contents if they only care about token usage.

The `output` event's `category` field cleanly separates output streams: `stdout` for generated code, `console` for chain-of-thought reasoning, `stderr` for errors, `telemetry` for token usage and cost metrics, and `important` for critical alerts. Progress events (`progressStart`/`progressUpdate`/`progressEnd`) with cancellation support map directly to multi-step agent tasks.

DAP stepping commands translate naturally: `next` executes the next agent action without drilling into sub-calls, `stepIn` enters a tool call's execution, `stepOut` completes the current tool call, `continue` runs freely until the next gate hook, and `pause` immediately suspends the agent. The **go-dap** library from Google provides a Go codec that supports registering custom events and requests.

---

## 3. SSE wins for dashboards, with RAF batching for performance

For streaming agent activity to a web dashboard, **Server-Sent Events (SSE) should be the primary transport**. SSE provides one-way server→client streaming over standard HTTP with automatic browser reconnection, no WebSocket infrastructure complexity, and excellent proxy compatibility. The wire format is simple (`event: type\ndata: json\nid: cursor\n\n`), and HTTP/2 multiplexing eliminates the 6-connection-per-domain limit of HTTP/1.1. Use standard REST endpoints for user actions like approve/deny — reserve WebSocket only if true bidirectional features like interactive terminal sessions are needed. Use gRPC streaming for internal service-to-service communication, never for browser-facing APIs (it requires a grpc-web proxy).

**TanStack Query integrates elegantly with push-based updates** through two complementary strategies. For entity-level changes (agent state, session details), SSE messages trigger `queryClient.invalidateQueries()` — queries refetch only if actively observed by a mounted component, preventing wasted bandwidth. For high-frequency metrics (cost accumulation, latency), use `queryClient.setQueryData()` to update the cache directly without a round-trip. The experimental `streamedQuery` API supports `AsyncIterable` data sources, reporting **3x faster perceived performance** for AI response streaming.

The critical performance pattern for real-time dashboards is **requestAnimationFrame (RAF) batching**. High-frequency events (potentially hundreds per second) must be buffered in a ref and flushed at most once per animation frame:

```tsx
const bufferRef = useRef([]);
const rafRef = useRef(null);

const onMessage = (event) => {
  bufferRef.current.push(JSON.parse(event.data));
  if (!rafRef.current) {
    rafRef.current = requestAnimationFrame(() => {
      const batch = bufferRef.current;
      bufferRef.current = [];
      rafRef.current = null;
      setData(prev => [...prev.slice(-(MAX_POINTS - batch.length)), ...batch]);
    });
  }
};
```

This reduces renders from hundreds per second to **12–16 per second**, matching the display refresh rate. For the event log, TanStack Virtual provides virtualized scrolling at 60fps with only ~15KB overhead, rendering only visible rows. Always cap data arrays with a sliding window (`data.slice(-MAX_POINTS)`) to prevent memory leaks.

For charting, **Recharts** (SVG-based, React-native) works well for cost graphs with fewer than 200 data points when animation is disabled (`isAnimationActive={false}`). For higher-density visualizations, Chart.js (Canvas-based) handles 10,000+ points efficiently. Tremor provides pre-built dashboard components (KPI cards, area charts, bar lists) on top of Recharts with Tailwind CSS styling, making it the fastest path to a polished Stoke dashboard.

---

## 4. Bubble Tea's Elm architecture handles streaming events naturally

Bubble Tea implements the Elm Architecture (Model/Update/View) where **`Update()` is never called concurrently** — one message at a time, no locks needed. The framework runs a single-threaded event loop: receive message → call Update → queue returned commands → render View. Commands execute in separate goroutines, but results flow back through the serial message channel. The renderer batches at **60 FPS by default** (configurable via `tea.WithFPS()`), inherently preventing flickering on high-frequency updates.

The canonical pattern for consuming Stoke's event bus uses a Go channel bridge:

```go
func waitForEvent(eventCh chan EventMsg) tea.Cmd {
    return func() tea.Msg {
        return <-eventCh  // blocks until event received
    }
}

func (m model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
    switch msg := msg.(type) {
    case EventMsg:
        m.events = append(m.events, msg)
        m.viewport.SetContent(m.renderEventLog())
        m.viewport.GotoBottom()
        return m, waitForEvent(m.eventCh) // re-subscribe for next event
    }
    return m, nil
}
```

After receiving each channel message, the handler **must return a new `waitForEvent` command** to continue listening — this creates a continuous subscription loop without goroutine leaks.

Multi-panel layouts use **lipgloss's `JoinHorizontal` and `JoinVertical`** composition: events log on the left (viewport with auto-scroll), metrics panel on the right (cost display, test summary, hook status), header and footer spanning full width. The viewport component from Bubbles provides keyboard/mouse scrolling for the event log. Terminal resizing triggers `tea.WindowSizeMsg`, which recalculates panel dimensions.

For gate hook approval workflows, the **Huh library** provides `huh.NewConfirm()` that integrates as a `tea.Model` component, offering polished approve/deny prompts. For periodic metric refreshes (elapsed time, running cost), use `tea.Tick(time.Second, ...)` — remembering that ticks are one-shot and must be re-issued from Update to create repeated timers. High-frequency updates can be debounced by tracking a `pendingUpdate` and flushing on a tick interval.

---

## 5. Thread-per-session keeps chat channels clean

For Slack integration, the **Web API combined with Socket Mode (development) or HTTP Events API (production)** provides the right foundation. Incoming Webhooks are too limited — they can't handle button interactions. The Web API's `chat.postMessage` and `chat.update` are essential for Stoke's core workflow: post an initial session message, thread all events under it via `thread_ts`, and update messages in-place as hook status changes.

**Block Kit's actions block with styled buttons** creates the approval workflow:

```json
{
  "type": "actions",
  "elements": [
    {
      "type": "button",
      "text": {"type": "plain_text", "text": "✅ Approve"},
      "style": "primary",
      "action_id": "approve_hook",
      "value": "{\"session\":\"ses_abc123\",\"hook\":\"deploy-production\"}"
    },
    {
      "type": "button",
      "text": {"type": "plain_text", "text": "❌ Deny"},
      "style": "danger",
      "action_id": "deny_hook",
      "value": "{\"session\":\"ses_abc123\",\"hook\":\"deploy-production\"}"
    }
  ]
}
```

When a user clicks a button, the interaction payload arrives via Socket Mode or the Request URL. The handler must `ack()` within **3 seconds**, then use `chat.update` to replace the buttons with a static "✅ Approved by @user" context block — this prevents double-clicks and provides a clear audit trail. For critical approval requests, set `reply_broadcast: true` to surface the message in the main channel.

**Rate limiting requires batching.** Slack enforces roughly 1 message per second per channel. A busy AI agent generates far more events. The solution is an `EventBatcher` that buffers low-priority events and flushes every 2–3 seconds, while sending approval requests immediately. Use `chat.update` on a single "live status" message rather than posting new messages for each hook completion.

For Discord, use the **Bot API with gateway** for interactive features (buttons require application-owned bots). Discord embeds support rich formatting with fields, color coding, timestamps, and footers. Action rows hold up to 5 buttons each. Thread creation via `message.startThread()` parallels Slack's thread model. Discord's webhook rate limit is **30 requests per minute** per URL; the bot global limit is 50 requests per second.

---

## 6. GitHub Checks API makes hook results first-class PR citizens

The GitHub Checks API enables Stoke to report hook gate results directly on pull requests with **rich Markdown output, file-level annotations, and interactive action buttons**. Creating check runs requires a GitHub App with `checks:write` permission — OAuth tokens and PATs cannot create checks.

The pattern is one check run per hook type (`Stoke: Cost Gate`, `Stoke: Permission Check`, `Stoke: Test Validation`), each independently visible in the PR Checks tab and configurable as a required status check for branch protection. The lifecycle maps cleanly:

- Hook triggered → `POST /check-runs` with `status: "queued"`
- Hook executing → `PATCH` to `status: "in_progress"` with initial summary
- Results streaming → `PATCH` with annotations (up to **50 per request**, appended not replaced)
- Hook approved → `PATCH` with `conclusion: "success"`
- Hook denied → `PATCH` with `conclusion: "failure"`
- Awaiting human approval → `conclusion: "action_required"` with action buttons

Annotations appear inline in the PR Files tab, pointing to specific lines the AI agent modified:

```json
{
  "path": "infrastructure/main.tf",
  "start_line": 42,
  "end_line": 55,
  "annotation_level": "failure",
  "message": "This resource block adds $120/month in compute costs",
  "title": "High-cost resource detected"
}
```

Action buttons (max 3, label ≤20 chars) trigger a `check_run.requested_action` webhook when clicked, enabling approve/deny workflows directly from the PR. The `action_required` conclusion adds a prominent "Resolve" link.

For GitLab, the **Commit Status API** (`POST /projects/:id/statuses/:sha`) provides basic status reporting (pending/running/success/failed/canceled) on the free tier. GitLab External Status Checks (Ultimate tier) add MR-level integration but have a **2-minute pending timeout** that's problematic for human approval gates — use the Commit Status API instead for broader compatibility.

Subscribe to `check_suite.requested` webhooks to automatically create check runs on new pushes. Store `{sha, hook_type} → check_run_id` mappings for idempotent updates on retries. GitHub retains check data for **400 days**.

---

## 7. RED and USE methods guide event bus instrumentation

Prometheus metrics for Stoke's event bus follow the **RED method** (Rate, Errors, Duration) for request-driven signals and the **USE method** (Utilization, Saturation, Errors) for infrastructure monitoring. The Go client library `prometheus/client_golang` provides Counters, Histograms, and Gauges — always prefer Histograms over Summaries for latency because they're aggregatable across instances.

The core metric set for Stoke:

```go
// Counters (monotonically increasing)
stoke_hook_invocations_total{hook_type, hook_name, result}  // result: approved|denied|error
stoke_hook_denials_total{hook_type, reason}
stoke_agent_cost_dollars_total{agent_id, model}
stoke_events_total{event_type, source}

// Histograms (distributions)
stoke_hook_duration_seconds{hook_type, hook_name}
stoke_event_bus_processing_seconds{event_type}

// Gauges (current values)
stoke_active_agents
stoke_event_bus_queue_depth
```

**Label cardinality must be bounded.** Each label should have fewer than 100 possible values; total cardinality per metric should stay under 10,000 time series. Never use unbounded values like `session_id` or `trace_id` as metric labels. The estimated cardinality for Stoke's hook invocations counter is ~5 hook_types × ~20 hook_names × 3 results = **300 series**, well within safe limits.

The middleware wrapper pattern instruments every event handler:

```go
func (m *StokeMetrics) InstrumentedHandler(hookType, hookName string, 
    handler func(Event) (Result, error)) func(Event) (Result, error) {
    return func(event Event) (Result, error) {
        timer := prometheus.NewTimer(m.HookDurationSeconds.WithLabelValues(hookType, hookName))
        defer timer.ObserveDuration()
        result, err := handler(event)
        resultLabel := "approved"
        if err != nil { resultLabel = "error" } 
        else if result.Denied { resultLabel = "denied" }
        m.HookInvocationsTotal.WithLabelValues(hookType, hookName, resultLabel).Inc()
        return result, err
    }
}
```

Use `promauto.With(reg)` for a custom registry (better testability than the global default), and `promhttp.HandlerFor(reg, promhttp.HandlerOpts{EnableOpenMetrics: true})` to expose `/metrics` with exemplar support. Recording rules pre-compute expensive queries like `histogram_quantile(0.95, ...)` and hook denial ratios for dashboard performance.

Grafana dashboards use dashboard variables (`$hook_type`, `$agent_id`) for interactive filtering. Key PromQL queries: `rate(stoke_hook_invocations_total[5m])` for throughput, `histogram_quantile(0.95, sum by (le)(rate(stoke_hook_duration_seconds_bucket[5m])))` for p95 latency, and `sum(increase(stoke_agent_cost_dollars_total[24h]))` for daily cost. Alert rules trigger on cost rate exceeding $10/hour, denial rates above 50%, or queue depth exceeding 1000.

---

## 8. OpenTelemetry unifies logs, traces, and metrics through a single pipeline

Structured logging with **slog** (Go 1.21+ standard library) provides native context support (`InfoContext(ctx, ...)`), a composable Handler interface, and zero external dependencies. Create per-session loggers with pre-populated fields using `slog.With()`:

```go
logger := base.With(
    slog.String("agent_id", agentID),
    slog.String("session_id", sessionID),
    slog.String("hook_name", hookName),
)
```

For trace correlation, a custom slog Handler injects `trace_id` and `span_id` from OpenTelemetry context into every log record:

```go
func (h *OtelHandler) Handle(ctx context.Context, r slog.Record) error {
    spanCtx := trace.SpanContextFromContext(ctx)
    if spanCtx.IsValid() {
        r.AddAttrs(
            slog.String("trace_id", spanCtx.TraceID().String()),
            slog.String("span_id", spanCtx.SpanID().String()),
        )
    }
    return h.inner.Handle(ctx, r)
}
```

Alternatively, the official **otelslog bridge** (`go.opentelemetry.io/contrib/bridges/otelslog`) handles this automatically. Every event bus event should carry `context.Context` containing the active span, so logs from hook execution share the same trace as the parent agent task.

OpenTelemetry spans for hook execution capture structured attributes (`hook.name`, `hook.type`, `agent.id`), record errors with `span.RecordError()`, and add events for key decisions. The OTel Collector receives all telemetry via OTLP (gRPC on port 4317, HTTP on 4318) and routes it to the appropriate backends:

- **Traces → Tempo**: Full request tracing with hook execution waterfall
- **Logs → Loki**: Label-indexed log storage via Loki's native OTLP endpoint (`/otlp`)
- **Metrics → Prometheus**: Time-series via remote write

**Loki's design principle — index labels, not content** — means keeping index labels low-cardinality (`service_name`, `level`, `hook_type`) while putting `agent_id`, `session_id`, and `trace_id` in structured metadata (queryable without indexing). LogQL queries like `{service_name="stoke"} | json | hook_result="denied"` parse JSON at query time. Grafana connects the three signals: Loki derived fields link `trace_id` to Tempo traces, Tempo links back to Loki logs, and Prometheus exemplars on histograms link metric spikes to specific traces.

For teams using Elasticsearch, the OTel Collector's elasticsearch exporter with ECS mapping mode provides full-text search across hook events. For Datadog, the DDOT Collector (Datadog's OTel Collector distribution) is now the recommended ingestion path.

---

## 9. Work partitioning beats file locking for multi-agent coordination

When multiple AI agents work on the same codebase, coordination through an event bus requires careful pattern selection. Real-world evidence from **Cursor's experiment** (hundreds of concurrent agents building a browser from scratch) found that **file-level locking failed catastrophically** — agents held locks too long, forgot to release them, and "didn't understand the significance of holding a lock," reducing twenty agents to the throughput of two or three.

The recommended hybrid strategy for Stoke:

**Primary: Work partitioning.** A planner agent decomposes tasks and assigns non-overlapping zones (directories, packages, file sets) to worker agents. Publish `WorkZoneAssigned{AgentID, Paths[]}` events. Agents reject tasks outside their zone. This reduces conflicts by 80%+ in production reports.

**Secondary: Event-driven intentions.** Before editing shared files, agents publish `IntendToEdit{AgentID, FilePath, Reason}`. Other agents see the intention and can yield, wait, or negotiate. Follow with `EditInProgress`, `EditCompleted`, and `ConflictDetected` events as the edit lifecycle progresses.

**Fallback: Optimistic concurrency via Git.** Each agent works on an isolated branch. Accept occasional merge conflicts. A separate reconciliation agent periodically produces a clean "green" branch. Cursor's final production solution explicitly traded commit correctness for throughput using this approach.

**NATS JetStream via Watermill** provides the event backbone. Subject-based routing with hierarchical topics (`stoke.agent.{id}.{type}`, `stoke.file.{path}`) enables precise subscriptions. Queue groups ensure each task is claimed by exactly one worker. JetStream adds persistence with configurable retention, replay policies, and deduplication via `Nats-Msg-Id` headers. Watermill's abstraction allows starting with Go channels for testing and swapping to NATS for production without code changes.

Distributed systems patterns apply directly: **Saga pattern** for multi-step agent operations (analyze → modify → test → commit) with compensating transactions on failure. Dead letter queues for events that fail processing after retries. Idempotent handlers checked via event ID deduplication. Back-pressure through NATS's `MaxAckPending` and buffered Go channels. Per-agent or per-file subject partitioning maintains ordering guarantees where they matter.

---

## 10. Record LLM responses as events for deterministic replay

Event replay is the debugging superpower for AI agents, but it faces a fundamental challenge: **LLMs are inherently non-deterministic**. Six sources of non-determinism affect replay — LLM sampling, tool/API state changes, system clock, data drift, concurrency ordering, and prompt drift. The solution is recording every non-deterministic interaction as an event, then substituting recorded responses verbatim during replay.

The recording format should be **JSONL** (JSON Lines) — human-readable, appendable, grep-friendly, and compressible to 15% with zstd:

```jsonl
{"id":"evt-002","seq":2,"ts":"...","type":"llm.request","agent_id":"agent-1","session_id":"sess-abc","payload":{"model":"claude-3.5-sonnet","prompt":"Analyze this error...","temperature":0.0}}
{"id":"evt-003","seq":3,"ts":"...","type":"llm.response","agent_id":"agent-1","session_id":"sess-abc","payload":{"text":"The error is caused by...","tokens_used":1523}}
```

The **decorator/middleware pattern** adds recording to the existing event bus with minimal overhead:

```go
func (r *RecordingEventBus) Publish(ctx context.Context, event Event) error {
    event.Sequence = atomic.AddInt64(&r.seqNum, 1)
    select {
    case r.eventCh <- event: // async buffered write (1024 capacity)
    default: // backpressure handling
    }
    return r.inner.Publish(ctx, event) // pass through to real bus
}
```

A background goroutine flushes the buffer every 100ms via `bufio.Writer`, keeping recording overhead negligible. Storage tiers progress from SQLite (local development), to PostgreSQL with JSONB and global sequence numbers (production, handling **10K events/sec**), to S3 with compression (archival).

The **snapshot + replay pattern** avoids replaying entire histories. Take snapshots every 100 events; loading state means deserializing the latest snapshot and replaying only subsequent events. The replay controller supports multiple modes: original timing (visual replay), fast-forward (state reconstruction), step-through (debugging), and filtered replay (only events from agent X, or only file modifications).

Multiple tools validate this approach in production. **Temporal.io** (used by OpenAI Codex and Replit Agent) separates deterministic orchestration from non-deterministic activities, replaying workflow logic without re-executing LLM calls. **Docker Cagent** uses a proxy-and-cassette model, recording LLM request/response pairs in YAML and replaying them in isolation. **Litmus** provides zero-code-change recording for Python agents by monkey-patching the HTTP transport layer. For terminal recording, **asciinema** produces lightweight `.cast` files in JSONL format, and Charm's **VHS** creates declarative `.tape` files for reproducible terminal recordings.

Recorded event streams serve double duty as **regression test fixtures**. Load a JSONL recording, replay it through the agent with modified hook logic, and assert on outcomes — testing real agent behavior without making LLM API calls.

---

## Conclusion

The ten integration surfaces covered here share a common architectural theme: **events as the universal interface**. LSP and DAP prove that JSON-based event protocols over stdin/stdout can support rich bidirectional communication with capability negotiation. The `stopped`/`continued` cycle from DAP and the notification/request pattern from LSP translate directly to gate hook approval workflows. SSE with RAF batching and TanStack Query provides the web dashboard layer. Bubble Tea's Elm architecture handles terminal streaming with zero concurrency complexity. Slack and Discord thread-per-session with batched updates keeps team communication manageable. GitHub Checks makes hook results first-class CI citizens with inline annotations. Prometheus with RED/USE methods and Grafana dashboards provide operational visibility. OpenTelemetry unifies logs, traces, and metrics through a single collector pipeline. NATS JetStream with work partitioning enables multi-agent coordination. And JSONL event recording with snapshot/replay provides time-travel debugging.

The most consequential architectural decision for Stoke is **making the event bus the single source of truth** — every hook invocation, every LLM call, every agent decision flows through it as a structured event. Recording middleware captures the stream for replay. Prometheus middleware extracts metrics. LSP/DAP adapters translate events to IDE protocol messages. Chat and CI/CD integrations subscribe to relevant topics. This fan-out from a central event bus transforms Stoke from a coding tool into the central nervous system the developer ecosystem needs.