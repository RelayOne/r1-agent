# Building reproducible, isolated benchmark execution at scale

**Running 9,000 AI coding benchmarks (12 harnesses × 750 tasks) with strong reproducibility requires layered Docker isolation, per-task resource and cost caps, and careful orchestration to prevent cross-run contamination.** The core architecture combines container-per-task execution with layered images for fast startup, proxy-based LLM cost enforcement, and either Kubernetes Jobs or AWS Batch for parallel scheduling. SWE-bench's three-tier Docker hierarchy provides a proven reference implementation, while Firecracker microVMs offer stronger isolation at the cost of operational complexity. This report covers every layer of the isolation stack — from filesystem snapshots to statistical reproducibility verification — with concrete implementation patterns for each.

---

## 1. Docker-based isolation: container-per-task is the only safe model

The fundamental design choice is **container-per-task** versus container-per-harness. Container-per-harness (one long-running container executing all 750 tasks sequentially) breaks reproducibility because state accumulated from one task — installed packages, temp files, modified configs, polluted caches — leaks into subsequent tasks. Container-per-task spawns a fresh container for every execution, guaranteeing each task starts from an identical, pristine state. Docker's OverlayFS copy-on-write makes container creation near-instantaneous when images are cached locally, so the overhead is negligible.

The image hierarchy should maximize layer sharing across your 9,000 runs:

```
Base Image (ubuntu:22.04, pinned by digest)
  └── Harness Base (git, build-essential, language runtimes)
       └── Harness-Specific (12 images, one per harness with its dependencies)
            └── Task Data (injected via read-only bind mount, NOT baked into image)
```

Pre-build all 12 harness images and inject per-task data via volume mounts rather than building 9,000 separate images. A comprehensive launch command captures the key isolation flags:

```bash
docker run \
  --rm \                              # Destroy writable layer on exit
  --read-only \                       # Immutable root filesystem
  --tmpfs /tmp:size=256m,mode=1777 \  # Ephemeral scratch space
  --tmpfs /workspace:size=2g \        # Working directory in RAM
  -v "/data/tasks/${TASK_ID}:/task:ro" \     # Read-only task input
  -v "/data/results/${HARNESS}/${TASK_ID}:/output" \  # Persistent results
  --network=none \                    # Complete network isolation
  --cpus=2.0 --memory=8g --memory-swap=8g \  # Hard resource limits
  --pids-limit=512 \                  # Fork bomb protection
  --init \                            # tini for signal forwarding
  --security-opt=no-new-privileges \  # Prevent privilege escalation
  --cap-drop=ALL \                    # Drop all Linux capabilities
  "benchmark/${HARNESS}:v1@sha256:..." \
  /harness/run.sh /task /output
```

**Pin images by content digest** (`image@sha256:...`), never by mutable tags like `:latest`. The `--read-only` flag combined with `--tmpfs` mounts ensures the image layers are never modified — all writes go to ephemeral RAM-backed filesystems that vanish on container removal.

---

## 2. SWE-bench's three-tier Docker architecture and its lessons

SWE-bench's evaluation harness is the most mature reference implementation for containerized AI coding benchmarks. It uses a **three-tier Docker image hierarchy** that balances build time against cache efficiency.

**Tier 1 — Base image** builds from `ubuntu:22.04` with system packages and Miniconda. A single base image is shared by all 2,294 evaluation instances. **Tier 2 — Environment image** installs a conda virtual environment with repository-specific dependencies. Roughly 60 environment images cover all repo/version combinations, each shared by multiple instances. **Tier 3 — Instance image** clones the target repository at the specific commit, installs it in editable mode, and prepares the test environment. Each task instance gets a unique image.

The evaluation pipeline executes in a clear sequence: `make_test_spec()` generates scripts from versioning specs → `build_container()` creates the instance container → `copy_to_container()` injects the model's patch → `exec_run_with_timeout()` applies the patch and runs tests → `get_eval_report()` parses results → `cleanup_container()` removes the container. Patches are applied via a fallback chain (`git apply` → `git apply --reject` → `patch -p1`) to handle edge cases.

Grading uses two test categories: **FAIL_TO_PASS** tests (must pass after the patch) and **PASS_TO_PASS** tests (must remain passing). Full resolution requires all tests in both categories to pass.

**Key limitations worth learning from:**

- **Unpinned dependencies** mean images built at different times may differ. Epoch AI addressed this by publishing pre-built images to `ghcr.io`, reducing total image size from **684 GiB to 67 GiB** through optimizations like moving `git clone` to the environment layer and disabling pip cache.
- **Data leakage risk**: instance images contain full git history including future commits. A sophisticated model could access future commits via `git fsck --lost-found` or checkout tags. For your harness, strip git history with `git clone --depth 1` or remove `.git` after checkout.
- **Worker scaling limits**: SWE-bench recommends `max_workers < min(0.75 × cpu_count, 24)` because more workers cause resource contention that slows evaluation.
- **Build fragility over time**: old Python versions and deprecated packages make dependency resolution increasingly unreliable. Pre-built image registries solve this.

For your system, adopt the layered image pattern but improve on SWE-bench by pinning all dependencies by exact version, stripping git history, and using content-addressable image digests.

---

## 3. Firecracker microVMs provide hardware-enforced isolation

Firecracker is a lightweight Virtual Machine Monitor written in Rust that uses Linux KVM for hardware virtualization. It powers AWS Lambda and Fargate, handling trillions of function executions monthly. Each Firecracker process manages exactly one microVM with a minimalist device model — only 5 emulated devices (virtio-net, virtio-block, virtio-vsock, serial console, keyboard controller).

**Performance specifications** are enforced in CI: boot time **≤125ms**, memory overhead **≤5 MiB per VM**, CPU performance **>95% of bare metal**, and creation rate up to **150 microVMs/second per host**. Firecracker has been proven to run 4,000+ microVMs on a single host.

The critical advantage over Docker for benchmark isolation is the **isolation boundary**. Docker containers share the host kernel via namespaces and cgroups — a container escape exploit compromises the host. Firecracker runs each VM with a **separate guest kernel**, enforced by hardware virtualization (Intel VT-x / AMD-V). Cross-benchmark kernel state pollution — page caches, scheduler state, network stacks — is eliminated because each benchmark gets its own kernel.

| Property | Docker | Firecracker |
|---|---|---|
| Isolation boundary | Namespaces + cgroups (shared kernel) | KVM hypervisor (hardware-enforced) |
| Boot/start time | ~50ms | ~125ms cold, **4–28ms snapshot restore** |
| Memory overhead | Near zero | ≤5 MiB per VM |
| CPU overhead | Near zero | <5% |
| Density | ~2,000 per host | ~1,778 per host |
| Tooling maturity | Extensive (Docker, K8s) | Requires custom orchestration |

**Snapshot/restore** is Firecracker's killer feature for benchmarks. You boot a microVM, install your benchmark environment, take a snapshot (serializing full RAM + CPU state + device state), then restore from that snapshot for each benchmark run in **4–28ms**. Clean pages are shared across clones via `MAP_PRIVATE` mmap. The workflow: boot once → snapshot → restore per task → execute → destroy. Each restore starts from a bit-identical state.

**ForgeVM**, an open-source project, achieves ~28ms snapshot restore for AI agent code sandboxing using this pattern. It communicates via vsock (virtio socket) rather than networking, eliminating the network stack entirely.

**Regarding "Stoke/Ember/Flare"**: no publicly documented projects with these names were found in the context of Firecracker. These are likely internal project names. If your organization's Stoke platform already integrates Firecracker via Ember/Flare, it may already provide the snapshot/restore workflow described above.

**Practical recommendation**: start with Docker (lower operational complexity) and use Firecracker if you need stronger isolation against untrusted harness code or need deterministic kernel-level reproducibility. Integration paths include **Kata Containers** (OCI-compliant, works with existing Docker/K8s tooling) or **firecracker-containerd** (AWS's official bridge).

---

## 4. Network isolation prevents data leakage and result contamination

Network isolation serves two purposes: preventing harnesses from accessing test answers online (data leakage) and ensuring network-dependent behavior doesn't introduce non-determinism.

**Complete isolation** with `--network=none` removes all network interfaces except loopback. The container cannot resolve DNS, make outbound connections, or receive inbound traffic. Data exchange happens exclusively via volume mounts. This is the strongest option and should be the default unless harnesses require API access.

**Selective filtering** is needed when harnesses must call LLM APIs (OpenAI, Anthropic) while being blocked from all other internet access. Three patterns work:

**iptables in the DOCKER-USER chain** — Docker's NAT rules process before filter rules, so you must use the `DOCKER-USER` chain for container traffic filtering:

```bash
iptables -I DOCKER-USER -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -I DOCKER-USER -d <LLM_API_IP>/32 -p tcp --dport 443 -j ACCEPT
iptables -A DOCKER-USER -i br-<network_id> -j DROP
```

**Sidecar proxy pattern** — run a proxy container (envoy, nginx, mitmproxy) on both the internal and external networks. Benchmark containers connect only to the internal network and route all traffic through the proxy, which whitelists specific domains. This also enables API call monitoring and cost tracking.

**Docker internal networks** — `docker network create --internal benchmark-net` creates a network with no external connectivity. Combine with a gateway container that selectively forwards allowed traffic.

For the strongest guarantees, use `--network=none` for harnesses that don't need API access, and the sidecar proxy pattern for those that do. The proxy doubles as your cost enforcement layer (see section 8).

---

## 5. Filesystem isolation through OverlayFS and snapshot strategies

Docker's OverlayFS storage driver provides the foundation for filesystem isolation. It stacks read-only image layers (lowerdir) beneath a per-container writable layer (upperdir), presenting a unified view (merged). **Copy-on-write** means reading touches image layers directly, while writes copy files to the upper layer first. When the container is removed (`--rm`), the upper layer is destroyed — all changes vanish.

For benchmark runs, the recommended filesystem layout:

- **Root filesystem**: read-only (`--read-only`) — image layers are immutable
- **Scratch space**: tmpfs-backed (`--tmpfs /tmp:size=256m`) — in-memory, auto-cleaned
- **Working directory**: tmpfs-backed (`--tmpfs /workspace:size=2g`) — ephemeral work area
- **Task input**: bind-mounted read-only (`-v /host/tasks/${TASK_ID}:/task:ro`)
- **Results output**: bind-mounted writable (`-v /host/results/${ID}:/output`)

This ensures every task starts from identical filesystem state. The results bind mount persists output even if the container is killed.

**For faster resets**, consider **ZFS or BTRFS** as Docker's storage driver. Both provide instant copy-on-write snapshots at the block level. ZFS additionally offers data checksumming (detecting silent corruption) and per-dataset storage quotas via `--storage-opt size=10G`. BTRFS offers similar snapshot capabilities with native subvolume cloning.

**CRIU checkpoint/restore** (experimental in Docker) can snapshot a running container's full process state — useful for harnesses with expensive initialization (loading models, building indexes). Create a checkpoint after initialization, then restore for each task. However, CRIU requires `--security-opt seccomp:unconfined` and has limitations with network connections.

For Firecracker-based setups, snapshot/restore provides the cleanest filesystem isolation: the entire VM state (including filesystem caches, kernel buffers, and process memory) is restored from a known-good snapshot in 4–28ms.

---

## 6. Resource quotas prevent runaway harnesses from blocking the pipeline

Without resource limits, a single runaway harness can consume all CPU, memory, or disk on the host, blocking all other benchmark runs. Docker provides fine-grained controls via cgroups:

**CPU**: `--cpus=2.0` sets a hard limit of 2 CPU cores. `--cpuset-cpus="0,1"` pins the container to specific cores, eliminating cross-socket NUMA traffic and noisy-neighbor effects from CPU cache contention. For 12 parallel harnesses on a 48-core machine, assign each harness a dedicated 4-core set.

**Memory**: `--memory=8g --memory-swap=8g` sets a hard 8 GB limit with swap disabled (setting swap equal to memory). Exceeding the limit triggers the OOM killer (exit code 137). Disabling swap is critical for benchmarks — swap introduces massive, unpredictable latency that distorts timing measurements.

**Processes**: `--pids-limit=512` prevents fork bombs. AI coding harnesses that execute arbitrary generated code are especially vulnerable to this.

**Disk**: `--storage-opt size=10G` limits container filesystem size (requires overlay2 on XFS with `pquota`, or BTRFS/ZFS). Alternatively, use tmpfs with size limits for all writable paths.

**I/O bandwidth**: `--device-read-bps=/dev/sda:100mb --device-write-bps=/dev/sda:50mb` caps throughput. `--blkio-weight=300` sets relative I/O priority between containers.

**In Kubernetes**, set `requests == limits` for both CPU and memory to get **Guaranteed QoS class**. This prevents resource contention entirely — the scheduler won't overcommit, and the CPU Manager's static policy enables exclusive core allocation. Use `topologySpreadConstraints` to distribute pods evenly across nodes.

Firecracker provides hardware-enforced resource isolation — each microVM gets a fixed vCPU count and memory allocation that cannot be exceeded, plus built-in per-VM network and storage rate limiters configurable via its REST API.

---

## 7. Timeout handling: SIGTERM first, capture results, then SIGKILL

Docker's `docker stop` sends **SIGTERM** to PID 1, waits a grace period (default 10 seconds), then sends **SIGKILL**. The critical subtlety: if PID 1 is a shell script, the shell receives SIGTERM but **does not forward it** to child processes. Use Docker's `--init` flag (which injects `tini` as PID 1) or the exec form in Dockerfiles (`CMD ["python", "benchmark.py"]`, not `CMD python benchmark.py`).

A robust timeout pattern uses three layers:

```python
# Orchestrator-side timeout
container = client.containers.run(image, detach=True, init=True, ...)
try:
    result = container.wait(timeout=600)  # 10-minute hard timeout
except:
    container.stop(timeout=30)            # 30s grace for partial result saving
    exit_code = -1
logs = container.logs()                   # Works even on killed containers
container.remove()
```

Inside the container, the harness process should catch SIGTERM and save partial results:

```python
def handle_sigterm(signum, frame):
    with open('/output/partial.json', 'w') as f:
        json.dump({'status': 'timeout', 'steps': completed_steps}, f)
    sys.exit(143)  # 128 + 15 (SIGTERM)
signal.signal(signal.SIGTERM, handle_sigterm)
```

**Always set `PYTHONUNBUFFERED=1`** in benchmark containers. Python buffers stdout by default, so logs from killed containers may be empty without this. Use **atomic file writes** (write to temp file, then `os.rename`) for checkpoint files to prevent corruption on SIGKILL.

Distinguish failure modes by exit code: **137** = SIGKILL (likely OOM or timeout after grace period), **143** = SIGTERM (graceful timeout). Check `container.attrs['State']['OOMKilled']` to distinguish OOM kills from timeouts.

---

## 8. Cost cap enforcement through proxy-based API metering

AI coding harnesses calling LLM APIs can burn through budgets rapidly — research shows **"agents succeed fast but fail slowly,"** with most cost consumed by failing tasks that keep iterating. The standard per-task budget in SWE-bench evaluations is **$3 with a 250-step limit**.

**LiteLLM Proxy** is the most mature open-source solution for cost enforcement. It acts as a unified gateway supporting 100+ LLM providers with built-in per-key spend tracking and budget limits. The workflow:

1. Before each task, generate a budget-limited API key via LiteLLM's `/key/generate` endpoint with `max_budget` set to your per-task limit
2. Inject this key and LiteLLM's URL as `OPENAI_BASE_URL` / `ANTHROPIC_BASE_URL` into the container's environment
3. LiteLLM tracks token usage and cost in real-time, returning `x-litellm-response-cost` headers
4. When the budget is exhausted, LiteLLM returns HTTP 429, causing the harness to fail gracefully

```python
# Generate per-task key with $3 budget
task_key = requests.post("http://litellm:4000/key/generate",
    headers={"Authorization": "Bearer sk-master"},
    json={"max_budget": 3.0, "budget_duration": "1h",
          "metadata": {"task_id": task_id, "harness": harness}}
).json()["key"]

# Inject into container
container = client.containers.run(image, environment={
    "OPENAI_API_KEY": task_key,
    "OPENAI_BASE_URL": "http://litellm:4000",
    "TASK_BUDGET": "3.0",
}, ...)
```

The LiteLLM proxy also serves as the network gateway — benchmark containers connect only to the proxy (via the sidecar pattern from section 4), which handles both cost enforcement and network isolation in one layer. **Proxide** is another purpose-built alternative that returns HTTP 402 when per-client budgets are exceeded and includes agent loop detection.

For defense in depth, enforce budgets at three layers: **per-request** (token limits in API calls), **per-task** (cumulative cost via proxy), and **global** (organization-level spending caps via API provider dashboards).

---

## 9. Reproducibility requires controlling every source of non-determinism

Non-determinism in containerized benchmarks comes from multiple layers. **Hardware/OS level**: CPU scheduling introduces ~2% variation in system call sequences even for identical programs. ASLR randomizes memory layouts affecting cache behavior. Directory iteration order varies across filesystems. **Container level**: unpinned packages, Docker layer timestamps, and build cache inconsistencies. **Application level**: unseeded RNGs, network timing, and fundamentally, LLM inference non-determinism — studies show **up to 72% accuracy difference** across identical runs even with temperature=0.

**Minimize non-determinism through:**

- Pin base images by digest: `FROM python:3.12-slim@sha256:abc123...`
- Pin all packages with lockfiles and hashes (`pip-compile --generate-hashes`)
- Disable ASLR inside containers: `--security-opt seccomp=...` or `setarch $(uname -m) -R`
- Use `SOURCE_DATE_EPOCH=0` for reproducible build timestamps
- Set explicit random seeds in test frameworks
- Fix filesystem ordering by sorting directory listings explicitly

**Measure reproducibility statistically.** Run a validation subset (5–10% of tasks, run 5 times each) before the full benchmark. Key metrics:

- **Coefficient of Variation (CV)**: σ/μ × 100%. CV ≥ 15% indicates unacceptable repeatability
- **Intraclass Correlation Coefficient (ICC)**: values >0.90 indicate excellent reproducibility, <0.50 is poor
- **TARr@N (Total Agreement Rate)**: specifically designed for LLM benchmark instability, measuring exact agreement across N runs

**DetTrace** (from U Penn) is a purpose-built tool that forces reproducible execution by intercepting non-deterministic syscalls (time, sleep, random) via ptrace. It wraps container execution to eliminate OS-level non-determinism. For LLM-based benchmarks, however, API-level non-determinism (model inference randomness) will always dominate — plan for it by running multiple trials and reporting statistical aggregates rather than single-run numbers.

---

## 10. Parallel execution: scheduling 9,000 runs without resource contention

Managing 9,000 runs efficiently requires a job scheduler that handles parallelism, retry logic, resource allocation, and result aggregation. Three tiers of solutions exist, ordered by scale and complexity:

**Kubernetes with Indexed Jobs** is the recommended approach for production. Create 12 Jobs (one per harness), each with `completions: 750` and `parallelism: 50-100`. Each pod receives a `JOB_COMPLETION_INDEX` for task assignment. Set `requests == limits` for Guaranteed QoS, use CPU Manager's static policy for core pinning, and `topologySpreadConstraints` to distribute pods across nodes. For complex workflows, **Argo Workflows** adds DAG-based orchestration with fan-out/fan-in, artifact passing, and built-in retry logic.

**AWS Batch** offers the simplest managed solution. Array Jobs support up to 10,000 tasks — ideal for 750 per harness. Batch handles provisioning, scaling, and teardown automatically. Use Spot instances for up to 90% cost savings with retry logic for interruptions. Adobe uses this pattern for tens of thousands of concurrent inference jobs.

**GNU Parallel** works for single-node or small-cluster prototyping:

```bash
parallel --jobs 50 --joblog benchmark.log --resume-failed \
  --results results/{1}/{2}/ \
  ./run_benchmark.sh {1} {2} \
  ::: $(seq 1 12) ::: $(seq 1 750)
```

**Sizing estimates**: if each benchmark needs 2 CPUs + 4 GB RAM on 32-core/128 GB nodes, you get 16 concurrent runs per node. Running 100 concurrently requires ~7 nodes. At 10 minutes average per task with 100-way parallelism, the full 9,000 runs complete in **~15 hours wall-clock time**. With Spot instances on AWS, estimated compute cost is **$50–200**.

**Result aggregation** should use PostgreSQL for structured metadata (run status, exit codes, timing, costs), object storage (S3/GCS) for raw logs and artifacts, and Grafana + Prometheus for real-time monitoring dashboards. Track every run by `(harness_id, task_id, attempt_number)` with the container image digest, worker node, and timestamps for full traceability. Implement idempotent tasks with dead-letter queues for failures that exceed max retries.

For queue-based architectures, **Temporal** provides the strongest workflow guarantees — durable execution that survives crashes, built-in retry policies, and deterministic workflow replay for debugging. It handles the fan-out/fan-in pattern naturally: launch 750 child workflows per harness, aggregate results, and the full workflow state is persisted and queryable.

---

## Conclusion

The architecture for 9,000 reproducible benchmark runs rests on a few non-negotiable foundations: **container-per-task execution** (never reuse containers across tasks), **image pinning by digest** (never use mutable tags), **layered resource enforcement** (CPU pinning + memory caps + PID limits + cost proxy), and **statistical validation** of reproducibility before trusting single-run results.

SWE-bench's three-tier image hierarchy is the right model to follow but should be improved by pinning all dependencies, stripping git history, and using pre-built image registries. Firecracker's snapshot/restore (4–28ms restore to a bit-identical VM state) offers the theoretically cleanest isolation — separate kernels, hardware-enforced boundaries, zero kernel state leakage — but Docker with proper flags provides sufficient isolation for most benchmark scenarios with far lower operational overhead.

The highest-leverage decisions are: use LiteLLM as a cost-enforcement proxy (solving both network isolation and budget control in one layer), set `requests == limits` in Kubernetes for Guaranteed QoS (eliminating resource contention), and run a 5% validation subset with 5 repetitions to measure ICC and CV before committing to the full 9,000-run campaign. The most underappreciated risk is LLM inference non-determinism — even with temperature=0, expect meaningful variance, and design your analysis pipeline to report statistical aggregates rather than single-point results.