# Production file handling in Go: R2, GCS, and Cloudflare CDN

**R2's zero egress fees, combined with Go's memory-safe standard library and a defense-in-depth upload pipeline, form the foundation of a modern file handling architecture that can save over $50,000/year at scale compared to S3 or GCS alone.** This report covers every layer of production file handling — from magic-byte validation and virus scanning through image/video processing pipelines, storage cost optimization, compliance, and content moderation — with concrete Go code patterns, library recommendations, and architectural decisions grounded in 2025–2026 best practices. The architecture assumes Go services writing to Cloudflare R2 and GCS, served through Cloudflare CDN, with async processing for media and documents.

---

## 1. File upload security requires defense in depth

No single validation layer is sufficient. Production upload handlers must combine magic-byte detection, size enforcement, virus scanning, filename sanitization, and vulnerability-aware image handling.

### Magic-byte validation over file extensions

Never trust file extensions or `Content-Type` headers. The recommended library is **`gabriel-vasile/mimetype`** (v1.4.8) — pure Go, no CGO, detects **200+ formats** using hierarchical magic-byte matching with ~97% accuracy versus Linux `file --mime`:

```go
import "github.com/gabriel-vasile/mimetype"

func validateFileType(r io.Reader, allowed []string) error {
    mtype, err := mimetype.DetectReader(r) // reads first 3072 bytes
    if err != nil {
        return fmt.Errorf("detection failed: %w", err)
    }
    for _, a := range allowed {
        if mtype.Is(a) {
            return nil
        }
    }
    return fmt.Errorf("disallowed file type: %s", mtype.String())
}
```

The alternative `h2non/filetype` (v1.1.3) is simpler but has documented non-deterministic detection for some inputs. Go's stdlib `net/http.DetectContentType` only covers ~20 types and should be reserved for basic checks. For streaming validation without buffering the entire file, wrap an `io.Reader` that inspects the first 512 bytes as they flow through — this integrates cleanly with S3/R2 upload managers so that invalid files fail the upload stream immediately.

### Size limits at every layer

Enforce size at three layers: **Cloudflare** (100 MB on Free, configurable on Enterprise), **reverse proxy** (`client_max_body_size` in nginx), and **application** via `http.MaxBytesReader`:

```go
r.Body = http.MaxBytesReader(w, r.Body, 10<<20) // 10 MB
if r.ContentLength > maxSize {
    http.Error(w, "Content Too Large", http.StatusRequestEntityTooLarge)
    return
}
```

Check `Content-Length` early for fast rejection but never trust it alone — attackers can spoof it.

### Virus scanning with ClamAV

Use **`dutchcoders/go-clamd`** to communicate with the `clamd` daemon over Unix socket. The production pattern is **async quarantine**: upload to a quarantine prefix, enqueue a scan job, and move to verified storage only after ClamAV returns clean. ClamAV requires **3–4 GB RAM** minimum; use `freshclam` for automatic signature updates. For stream scanning without touching disk: `c.ScanStream(reader, abort)`.

### Image processing vulnerabilities

**ImageTragick (CVE-2016-3714)** exploits ImageMagick's delegate system to execute shell commands via crafted SVG/MVG files. The strongest mitigation: **don't use ImageMagick for untrusted input**. Go's stdlib `image/png`, `image/jpeg`, and `image/gif` decoders are memory-safe and don't shell out. Re-encoding uploaded images through Go's native decoders strips embedded payloads and validates structure:

```go
img, _, err := image.Decode(uploadedFile)
if err != nil { return fmt.Errorf("invalid image: %w", err) }
var buf bytes.Buffer
png.Encode(&buf, img) // clean, re-encoded output
```

**SVG XXE attacks** exploit XML entity resolution. Mitigate by parsing with `encoding/xml` (which disables external entities by default), stripping `<script>` tags and event handlers, converting to raster before serving, or serving from a sandboxed domain with strict CSP headers.

### Filename sanitization and path traversal

**Never use user-provided filenames for storage paths.** Generate server-side keys using random bytes or UUIDs, storing the original filename as metadata only:

```go
func GenerateObjectKey(ext string) string {
    b := make([]byte, 16)
    crypto_rand.Read(b)
    return hex.EncodeToString(b) + ext
}
```

Go 1.20+ provides `filepath.IsLocal()` to reject traversal attempts, and **Go 1.24's `os.Root`** is the gold standard for traversal-resistant local filesystem operations — all operations on a root directory are sandboxed so `..` and symlinks cannot escape.

### Zip bomb detection

Check **compression ratio** (flag >100:1), enforce maximum decompressed size with `io.LimitReader`, limit archive nesting depth to 2–3, cap file count, and use `filepath.IsLocal()` on every zip entry name.

---

## 2. Large file uploads should bypass the application server

For files over a few megabytes, presigned URLs let clients upload directly to R2 or GCS, eliminating application server bandwidth costs and enabling parallel chunked uploads.

### Presigned URLs for direct upload

**R2** (S3-compatible via `aws-sdk-go-v2`):

```go
func newR2Client(accountID, accessKeyID, secretKey string) *s3.Client {
    cfg, _ := config.LoadDefaultConfig(context.TODO(),
        config.WithCredentialsProvider(
            credentials.NewStaticCredentialsProvider(accessKeyID, secretKey, "")),
        config.WithRegion("auto"),
    )
    return s3.NewFromConfig(cfg, func(o *s3.Options) {
        o.BaseEndpoint = aws.String(
            fmt.Sprintf("https://%s.r2.cloudflarestorage.com", accountID))
    })
}

presignClient := s3.NewPresignClient(r2Client)
result, _ := presignClient.PresignPutObject(ctx, &s3.PutObjectInput{
    Bucket:      aws.String(bucket),
    Key:         aws.String(key),
    ContentType: aws.String("image/jpeg"), // enforced at signature level
}, s3.WithPresignExpires(15*time.Minute))
```

**GCS** uses V4 signed URLs with a 7-day maximum expiry. Include `Content-Type` in the signature to restrict uploads. Both providers require **CORS configuration** — set `allowed_origins` to your domain, allow PUT/GET methods, and expose the `ETag` response header.

Security best practices: **15 minutes for uploads**, 1 hour for downloads. Use IAM user credentials (not STS/role creds) if longer expiry is needed. Implement client-side retry with URL regeneration on 403 errors.

### Multipart and resumable uploads

The **S3 Upload Manager** in `aws-sdk-go-v2` handles multipart automatically for R2:

```go
uploader := manager.NewUploader(r2Client, func(u *manager.Uploader) {
    u.PartSize = 10 * 1024 * 1024 // 10 MB parts
    u.Concurrency = 5
})
```

GCS's Go client uses **resumable uploads by default** — the `Writer` with `ChunkSize > 0` enables automatic retry. Set `Writer.ProgressFunc` for upload tracking.

For user-facing resumable uploads, **tusd** (v2.8.0, the tus protocol reference implementation in Go) supports S3/R2 and GCS backends, provides completion hooks, and is production-proven at Vimeo and Cloudflare.

**Important R2 compatibility note**: `aws-sdk-go-v2` client v1.73.0+ changed default checksum behavior that's incompatible with R2. Pin to v1.72.x or set `RequestChecksumCalculation: aws.RequestChecksumCalculationWhenRequired`.

---

## 3. Image pipelines: eager for critical sizes, lazy for everything else

The hybrid approach generates only essential variants on upload (thumbnail, blurhash) and delegates all other transformations to an on-demand proxy cached at the CDN edge.

### Library selection for Go

| Criteria | `disintegration/imaging` | `h2non/bimg` | `davidbyttow/govips` |
|---|---|---|---|
| CGO required | No | Yes (libvips) | Yes (libvips) |
| WebP/AVIF output | No | Yes | Yes |
| Performance vs baseline | 1× | ~5× faster | ~5× faster |
| Best for | Prototypes, low volume | High-throughput, simple API | Advanced pipelines, fine control |

**`govips` v2** (actively maintained, auto-generated bindings for 193+ libvips operations) is the recommended choice for production image processing. It provides explicit AVIF export tuning, `AutoRotate()` for EXIF orientation, and `StripMetadata: true` for privacy:

```go
import "github.com/davidbyttow/govips/v2/vips"

img, _ := vips.NewImageFromBuffer(input)
img.AutoRotate()
img.Thumbnail(800, 600, vips.InterestingCentre)
webpBuf, _, _ := img.ExportWebp(&vips.WebpExportParams{Quality: 80, StripMetadata: true})
avifBuf, _, _ := img.ExportAvif(&vips.AvifExportParams{Quality: 50, Effort: 4})
```

For simple thumbnailing in low-volume services, `disintegration/imaging` (v1.6.2, pure Go, zero CGO) is trivial to deploy but lacks WebP/AVIF output.

**Production tip**: Set `MALLOC_ARENA_MAX=2` in libvips containers to prevent GLib memory fragmentation under heavy multi-threaded load.

### On-demand transformation

**Cloudflare Image Resizing** (Pro+ plans) transforms at the edge with `format=auto` inspecting the browser `Accept` header to serve AVIF > WebP > JPEG. **Imgproxy** (self-hosted, written in Go, uses libvips internally) offers URL-based transformation with HMAC signing. Both support automatic format negotiation — set `Vary: Accept` on CDN responses to cache per-format.

### EXIF stripping and blurhash

Strip EXIF metadata through your image processing library (`StripMetadata: true` in govips/bimg) rather than a separate library. Read GPS coordinates first if needed for geotagging via `rwcarlsen/goexif`. Generate blurhash from a **32×32 downscaled** image (same visual result, 100× faster) using `bbrks/go-blurhash`, storing the ~28-byte hash string alongside image metadata.

---

## 4. Video processing demands async worker queues

FFmpeg is the core of any video pipeline. The recommended Go integration is **`exec.Command`** — no abstraction leakage, matches FFmpeg docs directly, and supports any feature without waiting for library updates.

### HLS adaptive bitrate generation

```go
renditions := []struct{ Name string; Width int; Bitrate string }{
    {"360p", 640, "800k"}, {"720p", 1280, "2800k"}, {"1080p", 1920, "5000k"},
}
// Run renditions in parallel, each producing segment files + playlist
// Generate master.m3u8 linking all rendition playlists
```

For metadata extraction, **`vansante/go-ffprobe`** provides typed Go structs for duration, resolution, and codec info. For pure-Go MP4 parsing without FFmpeg, `abema/go-mp4` handles box-level operations.

### Queue management with Asynq

**`hibiken/asynq`** (Redis-backed) is the recommended task queue for Go video pipelines — it supports per-queue priorities, max retry, timeouts, and worker concurrency limits:

```go
srv := asynq.NewServer(asynq.RedisClientOpt{Addr: "redis:6379"}, asynq.Config{
    Concurrency: 4, // match CPU cores for FFmpeg
    Queues: map[string]int{"video": 6, "thumbnails": 3, "default": 1},
})
```

Limit concurrent FFmpeg processes to ~CPU core count (it's CPU-bound). For PostgreSQL-native transactional queues, **`riverqueue/river`** uses `FOR UPDATE SKIP LOCKED` and integrates with existing Postgres transactions.

### Managed services versus self-hosted

**Cloudflare Stream** ($5/1K min stored + $1/1K min delivered) is simplest for startups under 1,000 videos. **AWS MediaConvert** suits complex AWS workflows with DRM. Self-hosted FFmpeg workers win on cost at high volume — unlimited customization, compute cost only.

---

## 5. R2 saves 96% on egress versus S3 and GCS

The decisive factor in storage provider selection for CDN-served content is egress cost. At **10 TB storage + 50 TB egress/month**:

| Component | S3 Standard | R2 Standard | GCS Standard |
|---|---|---|---|
| Storage | $235.52 | **$153.60** | $204.80 |
| Egress | $4,403.20 | **$0.00** | $4,413.44 |
| **Monthly total** | **$4,643** | **$158** | **$4,623** |

R2 saves **~$4,485/month ($53,820/year)** at this scale. Even S3→CloudFront (free S3 egress but CloudFront distribution costs) totals ~$4,592/month.

### Content-addressable storage eliminates cache invalidation

Store files keyed by their SHA-256 hash: `objects/{hash[:2]}/{hash}`. Set `Cache-Control: public, max-age=31536000, immutable`. New content gets a new URL, so **cache purging is never needed**. Combined with reference counting in PostgreSQL, this also deduplicates storage — identical files uploaded by different users share one blob.

```go
h := sha256.New()
io.Copy(h, content)
hash := hex.EncodeToString(h.Sum(nil))
key := fmt.Sprintf("objects/%s/%s", hash[:2], hash)
// Check DB for existing blob → increment ref_count or upload new
```

### Lifecycle and tiering

R2 supports lifecycle rules for Standard → Infrequent Access ($0.01/GB, 30-day minimum) transitions and auto-expiration. GCS offers **Autoclass** — automatic tiering through Standard → Nearline → Coldline → Archive with no retrieval fees and no early deletion penalties. For long-term archival, **GCS Archive at $0.0012/GB is 12.5× cheaper than R2 IA**.

**Recommended architecture**: R2 as the primary CDN-serving layer (zero egress), GCS for compliance/versioning/archival (richer feature set, deeper tiers). Enable Smart Tiered Cache on the Cloudflare zone for optimal origin shielding.

---

## 6. Document processing chains conversion, OCR, and moderation

### PDF and office document handling

**`pdfcpu/pdfcpu`** (Apache 2.0, pure Go) is the most versatile PDF library — extraction, watermarking, merging, form handling, all PDF versions through 2.0. For simple text extraction, `ledongthuc/pdf` is lighter. **`unidoc/unipdf`** (commercial license) covers enterprise needs like table extraction and PDF creation.

For OCR, **`otiai10/gosseract/v2`** wraps Tesseract with a clean Go API. Google Cloud Vision's `AsyncBatchAnnotateFiles` handles PDF OCR at scale, processing directly from GCS. Office conversions use **LibreOffice headless** in containers — critical caveat: LibreOffice is single-threaded per user profile, so production deployments need one container per concurrent conversion or isolated `HOME` directories.

```go
exec.CommandContext(ctx, "libreoffice", "--headless", "--convert-to", "pdf",
    "--outdir", outputDir, inputPath)
```

For document previews, **MuPDF** (`mutool draw`) produces higher quality PDF thumbnails than ImageMagick with less attack surface.

### Content moderation pipeline

CSAM detection **must be first** in any moderation pipeline — US law (**18 USC §2258A**) mandates reporting to NCMEC's CyberTipline with fines up to $300K per violation. Microsoft's **PhotoDNA** (free for qualified organizations) creates perceptual hashes that survive resize/crop/recompression.

For NSFW detection, **AWS Rekognition** `DetectModerationLabels` and **Google Cloud Vision SafeSearch** both provide confidence-scored labels. PII detection uses **Google Cloud DLP** with 120+ built-in detectors (SSN, credit cards, emails, phone numbers) and inline de-identification via masking:

```go
resp, _ := dlpClient.InspectContent(ctx, &dlppb.InspectContentRequest{
    InspectConfig: &dlppb.InspectConfig{
        InfoTypes: []*dlppb.InfoType{
            {Name: "US_SOCIAL_SECURITY_NUMBER"}, {Name: "CREDIT_CARD_NUMBER"},
        },
    },
    Item: &dlppb.ContentItem{DataItem: &dlppb.ContentItem_Value{Value: text}},
})
```

The moderation pipeline flows: **Upload → Quarantine → CSAM check → NSFW check → PII scan → Decision (approved/quarantined/blocked) → Human review queue for borderline cases → Appeal process**.

---

## 7. Backup, compliance, and the right to erasure

**GCS provides native object versioning and soft delete** (7–90 day configurable retention, GA since 2024). R2 does not support versioning as of April 2026 — implement application-level versioning with version-suffixed keys if needed. For regulatory compliance, **GCS Bucket Lock** provides irreversible retention that meets FINRA, SEC, and HIPAA requirements.

GDPR Article 17 (right to erasure) requires multi-layer purge: delete from R2 and all GCS versions, purge Cloudflare CDN cache (use Cache-Tag purging for instant global invalidation), delete database records and search index entries, and audit-log the deletion itself. Use `errgroup` for parallel deletion across providers.

---

## 8. Go architecture patterns tie everything together

### Storage abstraction interface

Abstract R2 and GCS behind a common `FileStore` interface for testability and provider flexibility:

```go
type FileStore interface {
    Upload(ctx context.Context, key string, r io.Reader, meta ObjectMeta) error
    Download(ctx context.Context, key string) (io.ReadCloser, *ObjectMeta, error)
    Delete(ctx context.Context, key string) error
    SignURL(ctx context.Context, key string, opts SignedURLOptions) (string, error)
}
```

Implement `R2Store` (via `aws-sdk-go-v2`), `GCSStore` (via `cloud.google.com/go/storage`), and `MultiStore` that tees writes to both for redundancy. The multi-cloud abstraction `gocloud.dev/blob` works with both R2 (`s3blob`) and GCS (`gcsblob`) via URL openers if you prefer a ready-made solution.

### Resilience patterns

Wrap storage calls in **`sony/gobreaker` v2** (generics-enabled circuit breaker) with **`cenkalti/backoff/v4`** for exponential retry inside the breaker. Exclude 4xx client errors from failure counts. Pattern: breaker open → fail fast without retrying; breaker closed → retry with backoff on 5xx/network errors.

### Middleware chain

```go
router.Use(Tracing, RateLimit(100, 200), MaxBodySize(50<<20), AuthMiddleware)
```

Use `http.MaxBytesReader` for size, `golang.org/x/time/rate` for rate limiting, and OpenTelemetry for distributed tracing across upload → process → store → serve.

### Testing without cloud dependencies

**MinIO** via `testcontainers-go/modules/minio` provides an S3-compatible local container that works identically to R2. **`fsouza/fake-gcs-server`** embeds directly in Go tests with `fakestorage.NewServer()`, returning a real `*storage.Client`. Strategy: unit tests use interface mocks (no containers), integration tests spin up MinIO + fake-GCS, contract tests verify both implementations satisfy the interface identically.

### Production monitoring essentials

Track upload duration, file size distribution, processing latency, storage error rates, circuit breaker state, and queue depth with Prometheus histograms and counters. Use **`log/slog`** (Go 1.21+ stdlib) for structured JSON logging with file_id, storage provider, content_type, and trace_id in every log entry. Critical alerts: upload error rate > 1%, circuit breaker open, GDPR deletion failures, and CDN purge failures.

---

## Conclusion

The architecture that emerges from these patterns is **R2 as the primary serving store** (zero egress, Cloudflare CDN native integration), **GCS as the compliance and archival store** (versioning, bucket lock, deep archive at $0.0012/GB), with content-addressable storage eliminating both deduplication overhead and cache invalidation complexity. Go's memory-safe image decoders provide a meaningful security advantage over ImageMagick-based pipelines — re-encoding through `image.Decode` neutralizes entire classes of image exploits. The `govips` library bridges the performance gap when WebP/AVIF output is needed.

For uploads, presigned URLs should be the default for anything over a few megabytes, with tusd handling resumable uploads for large files. Processing happens asynchronously through Asynq/Redis worker queues, with CSAM scanning as the mandatory first stage of any content moderation pipeline. The `FileStore` interface abstraction, combined with MinIO and fake-gcs-server for testing, keeps the entire system provider-agnostic and fully testable without cloud dependencies. Every storage operation should be wrapped in circuit breakers and exponential backoff — cloud storage APIs are reliable but not infallible, and graceful degradation is what separates production systems from prototypes.