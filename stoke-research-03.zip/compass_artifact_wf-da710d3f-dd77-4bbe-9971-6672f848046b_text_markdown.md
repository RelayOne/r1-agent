# Mapping agent confidence to action policy: a research foundation for Stoke

**No production AI coding tool publishes formal confidence thresholds — and the ones LLMs self-report are dangerously miscalibrated.** This is the central tension Stoke must resolve. Across Cursor, Claude Code, Copilot, Devin, and Aider, autonomy gating relies on coarse permission modes (manual/auto/YOLO) rather than continuous confidence scores. Meanwhile, calibration research shows LLMs expressing 90%+ confidence still produce **20–30% error rates**. The path forward combines post-hoc calibration of model confidence, risk-tiered action policies drawn from decades of automation research, and a per-logical-action checkpoint architecture — not per tool call, not per task. What follows synthesizes peer-reviewed research, documented product behavior, and engineering practice across all ten topics.

---

## 1. Production tools gate on permission modes, not confidence scores

Despite extensive investigation, **no production AI coding tool exposes a numeric confidence threshold** that determines when to auto-apply versus present a diff. This is a confirmed gap — Cursor's community forums contain multiple feature requests for configurable confidence levels, all unresolved. Instead, the industry has converged on tiered permission modes.

**Claude Code** offers the most documented model: five modes ranging from Default (permission required for every file edit, shell command, and network request) to Bypass (`--dangerously-skip-permissions`). The March 2026 Auto Mode represents the state of the art — a separate **Sonnet 4.6 classifier** evaluates each action through a two-stage filter (fast yes/no, then chain-of-thought reasoning if flagged). Published metrics on real traffic (n=10,000): **0.4% false positive rate** (benign actions blocked) and **17% false negative rate** on overeager actions (n=52). Anthropic's own data shows **93% of permission prompts are accepted** by users — evidence of pervasive approval fatigue that motivates the move toward classifier-based gating. The system categorizes threats into four types: overeager behavior, honest mistakes, prompt injection, and misaligned models.

**Cursor** uses a plan-mode/implementation-mode split rather than confidence scoring. In Plan Mode, the system prompt explicitly instructs: "If any of the user instructions are ambiguous, you MUST ask the user to clarify" — limited to 1–2 questions at a time, ≤200 characters each, lettered multiple choice. In Implementation Mode, the prompt says "you should almost never ask the user whether to proceed; instead proactively attempt the plan." Cursor claims clarifying questions reduce implementation errors by **34%** and iterations by **42%**, though these figures appear in marketing materials without published methodology.

**GitHub Copilot's** ~**27–30% suggestion acceptance rate** is itself a confidence signal — 70% of suggestions fail to match user intent and are silently rejected. A Communications of the ACM study narrowed this to **21–24%**. Less experienced developers accept at **31.9%** versus **26.2%** for experienced developers, suggesting that expertise correlates with stricter filtering. Of accepted suggestions, **88%** are retained in the final code.

**Devin** added self-assessed confidence evaluation in later versions, asking for clarification "when it is not confident enough." Its PR merge rate improved from **34% to 67%** over 2025, meaning roughly one-third of autonomous work still needs significant rework. **Aider's** `--yes-always` flag is all-or-nothing with no granular control — users have requested per-category flags (`--yes-output`, `--yes-file`) but these don't exist. **Sourcegraph Batch Changes** sidesteps the problem entirely with a preview-before-apply model.

The convergence across tools is notable: Claude Code, Devin, and OpenAI Codex CLI all implement nearly identical five-tier permission hierarchies (manual → accept edits → plan → auto → bypass). This is an emerging de facto standard for Stoke to build on rather than reinvent.

---

## 2. Humans take stated confidence at face value — and ~70% is the danger zone

The trust-in-automation literature, anchored by **Lee & See's 2004 framework** (~5,000 citations), defines trust calibration as the correspondence between a person's trust and the automation's actual capability. Three failure modes matter for Stoke: **misuse** (over-reliance when trust exceeds capability), **disuse** (under-reliance when trust falls below capability), and the insidious **automation bias** documented by Parasuraman & Manzey (2010) — the tendency to accept incorrect automated recommendations, which cannot be overcome through training or instructions alone.

A 2026 CHI study (N=126) delivered the most actionable finding: **most participants could not recognize AI miscalibration**. When collaborating with overconfident AI, participants over-relied on it. When collaborating with underconfident AI, they under-relied. Communicating calibration levels helped users detect miscalibration but decreased trust in all AI, leading to increased under-reliance without improving overall decision efficacy. The implication is stark: displaying raw confidence scores may not help and could hurt.

**No single peer-reviewed study identifies a universal confidence threshold where humans become complacent.** However, converging evidence from Spain (2009), industry implementations (Microsoft, Zendesk), and analogical trust-tuning research points to **~70%+ stated confidence** as the practical inflection point where human verification drops significantly. High-stakes domains (healthcare, finance) use **90%+** thresholds; low-stakes use **60–70%**.

Anthropic's February 2026 analysis of millions of Claude Code interactions provides the best available production data on trust dynamics. New users employ full auto-approve in ~**20%** of sessions; experienced users (~750 sessions) increase to **>40%**. Crucially, experienced users **interrupt more often** (5% → 9% of turns), not less — they shift from per-action approval to intervention-based monitoring. The 99.9th percentile autonomous turn duration nearly doubled from ~25 to ~45 minutes over three months. Trust accumulates gradually, and effective oversight doesn't require approving every action.

For Stoke's design, Dzindolet et al. (2003) found that providing an **explanation for why an agent might err** maintained trust even after observed failures — and Lee & Moray (1992) showed that trust is essentially a tradeoff between self-confidence and trust in the system. When trust exceeds self-confidence, users rely on the agent. This suggests Stoke should communicate not just confidence but *reasoning about uncertainty sources*.

---

## 3. The 37% rule and Thompson Sampling provide theoretical grounding for explore-exploit

The optimal stopping literature offers a direct framework for Stoke's "execute now versus research more" decision. The **secretary problem's 37% rule** states: observe the first ~37% of options without committing, then select the next option exceeding all previously observed. Applied to an AI coding agent, this translates to spending roughly **37% of effort budget on exploration** (reading files, searching code, checking docs) before committing to implementation.

The **Gittins index** provides the provably optimal policy for discounted multi-armed bandits: at each decision point, select the arm with the highest index (a scalar encoding the value of continued investigation). For a coding agent, each potential information source (file, function, API endpoint, documentation page) has a Gittins index. When the index of continued exploration drops below the index of acting (writing code), the agent should switch. Dhankhar, Mishra & Bodas (2024) proposed QGI and DGN algorithms for learning Gittins indices when transition probabilities are unknown — directly applicable to an agent that doesn't know which files will be informative.

**Thompson Sampling** has emerged as the preferred bandit algorithm for LLM agent systems. Sun et al. (2025) combined classical MAB algorithms with LLM-based reward prediction using Thompson Sampling with decaying temperature for exploration-to-exploitation transition, consistently outperforming direct LLM arm selection. TensorZero implements Thompson Sampling in a production LLM gateway for adaptive A/B testing of configurations.

Among agent frameworks, **LATS (Language Agent Tree Search)** comes closest to formalizing explore-exploit: it uses Monte Carlo Tree Search to systematically balance exploration with exploitation at each reasoning step. **ReAct's** Thought → Action → Observation loop is an implicit explore-exploit mechanism but can get stuck in loops. **Reflexion** adds meta-level exploration across trials by learning from failed trajectories.

Simon's **satisficing** framework (Nobel Prize, 1978) may be the most practically relevant: agents should search sequentially until an option meeting an aspiration threshold is found, rather than optimizing over all alternatives. The aspiration adaptation model — set threshold, search, adjust threshold downward if nothing found after time β — maps directly to Stoke's context-gathering behavior.

---

## 4. Context has sharply diminishing returns after ~32K tokens

Anthropic's 2025 guidance on context engineering states explicitly: **"Context must be treated as a finite resource with diminishing marginal returns."** The attention mechanism creates n² pairwise relationships for n tokens — at 100K tokens, that's 10 billion relationships competing for attention weight.

The strongest empirical evidence comes from **Liu et al. (2024, TACL)**: performance follows a **U-shaped curve** across input positions. In multi-document QA with 20 documents, accuracy dropped **>30%** when relevant information was placed in positions 5–15 versus position 1 or 20. This "lost in the middle" effect holds even for models designed for long contexts. For a coding agent reading 8 files, relevant code in file #4 sits in the model's blind spot.

Chroma's 2025 evaluation of **18 frontier models** (including GPT-4.1, Claude Opus 4, Gemini 2.5) confirmed universal degradation with input length, identifying three compounding mechanisms: lost-in-the-middle, attention dilution, and distractor interference. Counter-intuitively, models performed better on randomly shuffled documents than logically structured ones. Together AI's fine-tuning research pinpointed **~32K tokens** as the threshold after which diminishing returns become sharp for Llama 3.1 405B.

The information foraging literature provides the theoretical framework. Pirolli & Card's (1999) **Marginal Value Theorem** predicts that a forager should leave an information "patch" when the rate of return drops below the average return across all patches. SEER demonstrated the practical power of quality over quantity: **9.25× reduction in context length** yielded **13.5% F1 improvement**. Joren et al. (2025, ICLR, Google Research) introduced "sufficient context" for RAG systems, showing that hallucinations often result from insufficient rather than excessive context — but that a sufficiency check before generation can identify when enough is enough.

For Stoke, the practical framework is:

- **Files 1–5 of relevant context**: High marginal return per file
- **Files 6–10**: Moderate, position-dependent (middle files get 30%+ less attention)
- **Beyond ~32K tokens**: Diminishing sharply
- **Beyond 100K tokens**: Actively harmful due to context rot

The design implication is to use sub-agent architectures where search happens in isolated context windows, and only condensed, high-signal results enter the generation context.

---

## 5. Implementation uncertainty triggers research; intent uncertainty triggers confirmation

No production tool explicitly uses formal epistemic/aleatoric uncertainty frameworks, but every tool handles the distinction through UX design patterns. This is a critical gap Stoke can address more formally.

**Implementation uncertainty** ("I don't know HOW") consistently triggers autonomous context gathering. Claude Code reads files using Tier 1 safe-tool allowlist operations that require no permission. Cursor's agent mode uses grep and semantic search automatically. Devin spins up a browser, terminal, and editor to research by browsing docs and running commands. This research behavior is universally auto-approved because it's low-risk and high-value.

**Intent uncertainty** ("I don't know WHETHER this is what the user wants") triggers fundamentally different responses. Cursor's Plan Mode is the most explicit mechanism — the system prompt mandates asking clarifying questions when ambiguity is detected. Claude Code's auto-mode classifier checks whether "the action is something the user authorized, not just an action related to the user's goal" — a formal distinction between authorization and relevance. Copilot's ~30% acceptance rate **is itself an intent filter** — the tool generates the most likely completion and lets human filtering handle intent mismatches.

Research from ICLR 2025 notes that "the concepts of aleatoric and epistemic uncertainty become even more blurred when we go towards agents that interact with the real world," since agents can ask follow-up questions that change the underlying distribution. An arXiv paper (2502.11620) on iterative prompting measures mutual information between successive responses to distinguish epistemic from aleatoric uncertainty — high dependency between responses indicates elevated epistemic uncertainty that additional context could resolve.

For Stoke, the practical mapping is:

- **High implementation uncertainty, low intent uncertainty** → auto-trigger research actions (file reads, searches, doc lookups) without user interruption
- **Low implementation uncertainty, high intent uncertainty** → ask a focused clarifying question at a natural breakpoint
- **Both high** → research first to reduce implementation uncertainty, then ask about remaining intent ambiguity with more informed questions
- **Both low** → execute autonomously

---

## 6. Interruptions cost programmers 10–23 minutes — ask only when error cost exceeds this

The interruption cost literature establishes hard numbers. Parnin & Rugaber (2011) analyzed **10,000 programming sessions** from 86 programmers: after interruption, programmers take **10–15 minutes** to start editing code. When interrupted during a method edit, only **10%** resumed work in less than one minute. Gloria Mark's research program established the widely cited figure of **23 minutes 15 seconds** to fully refocus. A programmer typically gets just **one uninterrupted 2-hour session** per day.

Horvitz's (1999) **mixed-initiative principles** provide the decision-theoretic framework. The system should use Bayesian inference about user goals and choose among three options: do nothing, engage in dialog, or provide service. The expected value calculation: **E[acting] = P(correct) × V(correct) − P(wrong) × C(wrong) − C(interruption)**. Act autonomously when positive. Principle 8 is especially relevant: "scope precision of service to match uncertainty — a preference for 'doing less' but doing it correctly."

A 2025 study on mixed-initiative AI found the **"Goldilocks Time Window"** for intervention — assistance triggered by user-defined periods of inactivity (e.g., 10 seconds of no activity) was effective, but finding the optimal moment remains a key challenge. Delegating timing judgment to users (letting them set inactivity thresholds) works well.

The practical framework for Stoke:

- **Ask when**: stakes are high AND errors are hard to reverse AND confidence is below threshold AND the user is at a natural breakpoint between subtasks
- **Act when**: errors are easily reversible (undo/git) OR interruption cost (~15 min) exceeds expected error cost OR the user is in flow state
- **Batch questions**: collect multiple uncertainties and ask at a single natural breakpoint rather than interrupting for each
- **Make defaults visible but non-blocking**: show what the agent assumed, allow easy correction without requiring upfront approval

---

## 7. Read README → entry points → types → tests → task-focused code, then edit

Program comprehension research provides a well-validated sequence. **Pennington (1987)** found that when code is completely unfamiliar, the first mental representation built is a **bottom-up program model** (control-flow abstraction). **Von Mayrhauser & Vans' (1995) integrated model** — the most comprehensive framework, drawing on six prior models — shows that understanding is "built at all levels of abstraction simultaneously" with frequent switches between code, design, and domain knowledge. Koenemann & Robertson (1991) found that in larger programs, comprehension is mostly top-down with bottom-up only for failed hypotheses.

**Letovsky's (1986) model** describes the expert programmer's inquiry cycle: question → conjecture → search for confirmation. Programmers generate three types of conjectures — Why (purpose), How (method), and What (classification) — with varying degrees of certainty. This maps directly to an agent's hypothesis-driven exploration.

Synthesizing across research and production implementations (Claude Code's documented exploration pattern, OpenAI Codex's sub-agent architecture), the optimal sequence for an AI agent entering a fresh codebase is:

1. **Orientation** (top-down): README, package manifests, directory structure → form primary hypothesis about system purpose and architecture
2. **Architecture discovery** (top-down): Configuration files, entry points, dependency graph → map subsystems
3. **Domain model construction**: Type definitions, interfaces, data models, database schema → understand the domain vocabulary
4. **Test exploration** (bottom-up validation): Test files → understand expected behaviors, business rules, and edge cases
5. **Task-focused drilling** (opportunistic): Navigate to the specific area relevant to the task, trace call chains, read local code
6. **Hypothesis testing**: Form hypotheses about required changes, verify by cross-referencing code paths
7. **First edit**: Only after sufficient mental model construction

Steinmacher et al.'s (2015) systematic review of newcomer barriers in open source identified "finding a way to start" as the most common barrier. Git history of most-frequently-changed files reveals the "meat" of the application — a signal Stoke can use for prioritization.

---

## 8. Sheridan-Verplank's 10 levels and the Agentic Trust Framework provide the blueprint

The **Sheridan & Verplank (1978) 10-level taxonomy** remains foundational. Levels 1–4 keep humans in the decision loop (computer offers alternatives or suggests one). Level 5 is the critical transition: computer executes if human approves. Levels 6–10 progressively remove human involvement — from a veto window (Level 6) to full autonomy (Level 10). **Parasuraman, Sheridan & Wickens (2000)** (~11,000 citations) extended this across four functional types — information acquisition, information analysis, decision selection, and action implementation — each independently automatable at different levels. This creates a multi-dimensional automation space rather than a single linear scale.

The **Agentic Trust Framework (ATF)** from the Cloud Security Alliance (February 2026) provides the most actionable modern implementation with four levels and explicit promotion gates:

- **Intern**: Observe, report, recommend — human approves all actions
- **Junior**: Execute within guardrails, notify humans in real-time
- **Senior**: Execute autonomously within defined guardrails, post-hoc notification
- **Principal**: Operate autonomously, escalate only edge cases

Promotion criteria require all five conditions: demonstrated accuracy over evaluation period, security audit, measurable positive impact, clean operational history, and explicit stakeholder approval. Specific thresholds: Intern → Junior requires **4 weeks with >95% recommendation acceptance rate**; Junior → Senior requires **8 weeks with zero critical incidents**. The framework treats autonomy as "something that must be earned through demonstrated trustworthiness."

The **sliding autonomy** literature from robotics (Dias et al., 2008, CMU) provides the dynamic adjustment mechanism: when an agent encounters unexpected situations, it can request help from the human operator, effectively sliding to lower autonomy. Conlon et al.'s **event-triggered self-assessment** — where a robot's Model Quality Assessment monitors alignment between its model and reality — is the closest direct parallel to confidence-gated autonomy.

Endsley & Kaber (1999) documented the **out-of-the-loop performance problem**: operators of highly automated systems become handicapped in their ability to take over during automation failure. This means Stoke must maintain enough human engagement that escalation is productive — if the human has been entirely hands-off, asking them to intervene will produce poor decisions.

For Stoke's mapping, combining Sheridan-Verplank with Parasuraman's four function types yields:

| Confidence | Action Policy | Sheridan-Verplank Level |
|---|---|---|
| >95% | Execute autonomously, log | Levels 7–8 |
| 80–95% | Execute, notify human in real-time | Level 7 |
| 60–80% | Propose action, execute on approval | Level 5 |
| 40–60% | Present alternatives, human decides | Levels 3–4 |
| <40% | Present analysis only, human acts | Level 2 |

Critically, these thresholds should be **function-specific**: information acquisition (reading code) can be highly automated at all confidence levels, while action implementation (making edits) should be strictly confidence-gated.

---

## 9. LLM confidence is severely miscalibrated — isotonic regression and verbalized confidence help

The metrics landscape for confidence calibration centers on three measures: **Expected Calibration Error (ECE)**, which measures alignment between predicted confidence and actual accuracy; **Brier Score**, which captures both discrimination and calibration; and **AUROC/AUPRC** for discrimination quality. A comprehensive benchmarking study using prediction markets (KalshiBench) found Claude Opus 4.5 achieved a Brier score of **0.227**, approaching but not matching human superforecasters (**0.15–0.20**). The study's blunt conclusion: **"Don't trust high-confidence predictions. When models express 90%+ confidence, expect 20–30% error rates."**

Tian et al. (EMNLP 2023) found that **verbalized confidence outperforms token-level probabilities** for RLHF models — GPT-4's verbalized probabilities are "substantially better-calibrated than the model probabilities themselves, even after temperature scaling." Self-reported confidence achieves the lowest ECE across datasets (**0.142** for large models), outperforming self-consistency (0.221) and token probability (0.242). However, confidence histograms are top-skewed with most mass above 0.8, meaning thresholds must be calibrated to observed distributions rather than a fixed midpoint.

For post-processing calibration, a TU Wien thesis found that **isotonic regression consistently outperforms both Platt Scaling and Beta Calibration**. Amazon Science's "Calibrated Reflection" (ACL 2025) achieves lower ECE without fine-tuning by generating initial confidence, reflecting on reasoning, updating scores, and applying distance-aware calibration.

The major labs' approaches to threshold tuning remain opaque. **Anthropic** embeds calibration in its Responsible Scaling Policy through capability evaluations but has not published a dedicated confidence calibration methodology. **OpenAI** documents automated feedback loops in their Cookbook: run evals → analyze precision/recall gaps → adjust thresholds → re-validate → save tuned config, with oscillation prevention. Their Reinforcement Fine-Tuning uses floating-point grader scores (0.0–1.0) as reward signals. **Google DeepMind's** Frontier Safety Framework defines Critical Capability Levels triggering escalating mitigations, and their scalable oversight research uses confidence-based "hybridization" — slicing evaluation data into AI-decided and human-decided sets based on AI rater confidence.

**No major AI lab has published formal A/B testing results specifically for agent autonomy levels.** The closest approximation is Anthropic's observational data on Claude Code usage patterns and OpenAI's self-evolving agents cookbook. SWE-bench Verified (500 human-validated tasks) is the standard coding agent benchmark, with current SOTA at ~**76% pass@1**. SWE-bench Pro shows much harder tasks: ≤23.3% on public sets.

For Stoke, the practical calibration pipeline should be: extract verbalized confidence → apply isotonic regression on held-out data → validate against downstream task success → use dynamic thresholds (aggressive during low-stakes, conservative during high-stakes operations). LlamaIndex's guidance captures the tradeoff honestly: "you can't optimize for everything at once — choose between automation rates, error minimization, and manageable review queues."

---

## 10. Per-logical-action is the right checkpoint granularity for a hub event bus

A 2026 systematic review in MDPI Entropy proposes a unified three-dimensional taxonomy for human-in-the-loop systems: loop placement (where in the pipeline), interaction granularity (how fine-grained), and temporal characteristics (synchronous versus asynchronous). The key finding: "Systems that prioritize throughput may select coarser interaction and episodic review, then add targeted synchronous checkpoints for edge cases."

The **action chunking** literature from robotics provides the strongest theoretical grounding. Zhao et al.'s Action Chunking with Transformers (ACT) predicts chunks of **k future actions** (typically 4–30 steps) rather than single actions per timestep, reducing the effective task horizon k-fold and achieving **80–90% success rates** with minimal demonstration data. The explicit tradeoff: "If the optimal policy would switch strategies mid-chunk, we're out of luck." This maps precisely to the AI agent checkpoint decision — grouping tool calls into semantic units reduces overhead but sacrifices the ability to intervene mid-unit.

The checkpoint granularity spectrum for Stoke's event bus:

| Granularity | Use Case | Risk |
|---|---|---|
| Per tool call | Destructive operations (data deletion, production deployment) | Approval fatigue if applied broadly |
| **Per logical action** | Default for most operations — groups of related tool calls forming a semantic unit | Best balance for most systems |
| Per task | Low-risk workflows with established patterns | Less control over individual steps |
| Per turn | Monitoring-only oversight, post-hoc review | Cascading errors from early mistakes |

**LangGraph's** implementation validates per-logical-action as the practical sweet spot: `interrupt_before` and `interrupt_after` pause execution at any node in a computation graph, where nodes map to logical actions. A deep research agent example from Towards Data Science demonstrates just two strategic checkpoints — after query generation and during iterative search — to "effectively transform a fully autonomous agentic workflow into an LLM-human collaborative one."

The cost tradeoff is real in both directions. Too-frequent checkpoints cause approval fatigue (Claude Code's 93% acceptance rate is evidence of this pathology), add latency, and can multiply LLM costs **3–5×**. Too-infrequent checkpoints allow cascading errors — a flawed early assumption propagates through later steps, and by the time the human sees the result, significant rework is needed.

For Stoke's hub event bus architecture, the research supports **risk-tiered checkpoint routing**:

- **Auto-approve** (no checkpoint): Read-only operations, context gathering, search queries
- **Async notify** (log + notify, no block): Low-risk file edits within project scope, test execution
- **Confidence-gated** (block if below threshold): File modifications outside immediate task scope, shell commands, network requests
- **Always block** (require explicit approval): Destructive operations, operations affecting protected paths, operations outside the project sandbox

The granularity question resolves to: gate at the **logical action** level by default, drop to **per-tool-call** gating when the logical action is flagged as high-risk or when the agent's calibrated confidence falls below the threshold for that risk tier. This maps to Parasuraman et al.'s insight that automation levels "do not need to be fixed at the system design stage" but should "vary depending on production demands during operational use."

---

## Conclusion: what Stoke should build

The research converges on several non-obvious design principles. First, **confidence scores must be calibrated before they're useful** — raw LLM confidence is misleadingly high, and isotonic regression on held-out task outcomes is the minimum viable calibration step. Second, the most effective trust pattern is not displaying confidence numbers to users but rather **expressing uncertainty through behavioral signals** — asking clarifying questions, showing diffs, offering alternatives — that maintain appropriate human vigilance without triggering the documented failure mode where users take stated confidence at face value. Third, the explore-exploit boundary follows a satisficing model: set an aspiration threshold for context sufficiency (informed by the 37% rule and information foraging theory), gather context until the threshold is met or diminishing returns are detected (~32K tokens, ~5–7 relevant files), then act. Fourth, Stoke's event bus should implement the ATF pattern of **earned autonomy** — agents start as "interns" with per-action approval, graduating to higher autonomy tiers based on empirically measured success rates, not self-reported confidence. The specific promotion gates (>95% acceptance over 4 weeks for first promotion, zero critical incidents over 8 weeks for second) provide concrete starting points.

The biggest gap in the literature is the absence of published A/B testing for autonomy thresholds from any major lab. Stoke has an opportunity to be the first system to publish empirical data on how confidence-to-policy mappings affect downstream task success rates — data the entire field needs.