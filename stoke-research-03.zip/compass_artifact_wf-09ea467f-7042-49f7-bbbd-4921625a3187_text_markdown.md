# Convergence loops, self-repair, and goal-driven architectures for AI coding agents

**AI coding agents achieve most gains in the first 2–3 repair iterations, after which effectiveness decays exponentially—losing 60–80% of debugging capability by attempt 3.** This finding, consistent across AlphaCodium, Self-Refine, Reflexion, and LDB, is the single most important design constraint for Stoke's convergence loop. The research further reveals that broader initial sampling outperforms deep iterative repair, that LLMs cannot reliably self-evaluate without external signals, and that agent success drops 3–4× when task complexity increases from single-file to multi-file changes. This survey covers 12 architectural dimensions with specific numbers, citations, and design patterns for building a production convergence-research-build-verify orchestrator.

---

## 1. The convergence landscape: what works and what plateaus

Eight major convergence architectures have been evaluated on competitive coding and software engineering benchmarks, revealing a consistent pattern: **massive gains early, severe diminishing returns after iteration 3–5**.

**AlphaCode** (Li et al., DeepMind, Science 2022) uses generate-then-filter rather than iterative repair: it samples up to **1 million programs** per problem, filters by test execution, clusters by output behavior, and submits one solution per cluster. It achieved top-54.3% ranking on Codeforces but requires 4 orders of magnitude more compute than iterative approaches. **AlphaCodium** (Ridnik et al., CodiumAI, 2024) takes the opposite approach with a two-phase iterative flow—pre-processing (reflection, analysis, test generation) then code iteration with "test anchors" that prevent regression. It boosted GPT-4 pass@5 from **19% to 44%** on CodeContests using only **15–20 LLM calls** per solution. Critically, the AlphaCodium team found that injecting execution traces, prior failed solutions, or git diffs into the prompt produced **no improvement**—suggesting that naive context enrichment fails.

**MapCoder** (Islam et al., ACL 2024) deploys four specialized agents—retrieval, planning, coding, debugging—in a structured pipeline with dynamic traversal. It achieved **93.9% pass@1 on HumanEval** and 28.5% on CodeContests. **Reflexion** (Shinn et al., NeurIPS 2023) stores verbal self-reflections in episodic memory, raising HumanEval pass@1 from **80% to 91%** over 2–3 iterations. However, on MBPP, Reflexion actually *dropped* GPT-4 performance by 3% due to incorrect self-generated tests—a critical warning about self-evaluation quality.

**Self-Refine** (Madaan et al., NeurIPS 2023) runs a single-LLM feedback→refine loop capped at 4 iterations, achieving **~20% absolute improvement** across 7 tasks, with most gains in iterations 1–2. **LDB** (Zhong et al., ACL 2024 Findings) decomposes programs into basic blocks via control flow graphs, verifies each block's intermediate variables, and achieves up to **98.2% on HumanEval** (with GPT-4o + Reflexion seeds). LDB is notable for showing continued improvement up to **10 iterations**—an outlier—though after attempt 5, the next 15 attempts collectively added only **2.4%**. **REx** (Tang et al., NeurIPS 2024) reframes repair as multi-armed bandit exploration-exploitation, finding that strategically alternating between exploring new solutions and refining promising ones outperforms always-exploit strategies.

The universal quantitative pattern across systems: **iterations 1–3 capture 80–95% of achievable improvement**. Beyond 5 iterations, regression risk rises and marginal gains approach zero.

**Stoke design pattern:** Implement a 3-iteration default convergence loop with test anchors (AlphaCodium-style regression prevention). After iteration 3, switch from exploitation to exploration via a "strategic fresh start" (new approach rather than continued patching). Cap total attempts at 5–7.

---

## 2. Termination conditions: how agents know when to stop

Production systems overwhelmingly use **fixed caps** rather than adaptive termination. SWE-agent enforces a **$4 per-instance cost cap** and 100 LLM call limit. OpenHands caps at **100 iterations** (averaging 29 per task). AutoCodeRover completes in **~6 iterations** on average at $0.70 per issue. Agentless uses a fixed three-phase pipeline (localize → repair → validate) at **$0.34 per issue**.

The failure modes split cleanly into two categories. **Premature termination** manifests when agents declare success after superficial fixes—SWE-EVO analysis identifies this as a distinct failure category especially for weaker models. Agents sometimes "optimize for green, not for correct," rewriting test assertions to match broken behavior rather than fixing underlying bugs. **Infinite looping** was documented as a concrete bug in OpenHands (GitHub Issue #6357), where context window overflow triggered improper state handling after history truncation, causing endless repetition. One SWE-agent configuration with GPT-4o-mini consumed **181 API calls and 8.1M+ input tokens** (18× typical cost) while achieving only 10% resolution.

Confidence-based termination—where the LLM judges whether its output is "good enough"—is unreliable as a sole signal. Self-Refine includes a scalar quality check, and CRITIC (Gou et al., ICLR 2024) iterates its verify→correct→verify cycle "until specific stopping criteria are met," but **LLM confidence is poorly calibrated** (see Section 8). The SWE-Effi paper (2025) proposes "Effectiveness under Token Budget" as a metric, highlighting that smarter termination strategies remain an open problem.

**Stoke design pattern:** Layer three termination signals: (1) external test-passing gate (all tests green), (2) cost/iteration hard cap (configurable per task, default 5 iterations or $4), (3) no-progress detection (if the last 2 iterations produced identical or regressing test results, stop). Make pre-existing tests read-only to prevent gaming.

---

## 3. Research, build, and verify phases: sequential versus interleaved

Two paradigms dominate with clear tradeoffs. **Pipeline/sequential** (Agentless, Xia et al. 2024) follows localize → repair → validate, achieving **27.3% on SWE-bench Lite at $0.34/issue**—the best cost-performance ratio among open approaches. **Interleaved/agentic** (SWE-agent, OpenHands) uses plan-act-observe loops, achieving higher absolute scores on complex tasks: OpenHands reaches **72% on SWE-bench Verified** with Claude Sonnet 4.5 extended thinking.

The evidence strongly favors **planning before coding**. Self-Planning Code Generation (Jiang et al., ACM TOSEM 2024) shows significant HumanEval/MBPP improvements from generating a plan first. Plan-and-Solve prompting (Wang et al., ACL 2023) achieves **+8% absolute improvement** over zero-shot chain-of-thought by replacing "Let's think step by step" with explicit plan-then-execute instructions. LATS (Zhou et al., ICML 2024) integrates Monte Carlo Tree Search with LLM reasoning, hitting **92.7% pass@1 on HumanEval** with 3.55× fewer nodes than alternative tree search methods.

A crucial finding from "Learning When to Plan" (2025) reveals an optimal **"Goldilocks" planning frequency**—too much planning wastes compute, too little causes poor performance. RL-trained agents learn to approach 0% planning on trivial steps and heavy planning on critical junctures. The iML framework (2025) measured phase time allocation empirically: planning consumed only **3% of total time**, implementation **10%**, while verification/debugging consumed **85%**.

**Stoke design pattern:** Implement a three-phase loop: Research (cheap, greedy decoding, ~5–15% of budget) → Build (strongest model or diverse sampling, ~50–70% of budget) → Verify (different model family, external test execution, ~15–30% of budget). Use adaptive planning—attempt simple tasks directly, invest in planning only when initial build attempts fail.

---

## 4. Escalation policies: knowing when to ask for help

The RL literature provides the strongest theoretical foundation. **PAINT** (Xie et al., Stanford, NeurIPS 2022) trains agents to detect irreversible states and proactively request intervention, requiring only **~100 interventions across 3 million training steps**—up to **15× fewer** than naive approaches. The key principle: escalate *before* entering irrecoverable states, not after.

Production systems handle escalation inconsistently. **Copilot Agent Mode** eventually displays "Copilot has been working on this problem for a while" and offers to continue or accept new input—a crude timeout-based escalation. **Devin** has no formal "I'm stuck" signal; escalation is implicit through Slack messages. **Claude Code** tracks context usage as a percentage and triggers automatic compaction before overflow. **Microsoft's Magentic-One** uses a **dual-loop architecture**: an inner loop attempts the task while an outer loop can reset the entire strategy when the inner loop stalls.

The economics strongly favor early escalation. An agent stuck in a retry loop burned **$14 overnight** from a 6-hour spin. Multi-agent orchestration can reach **$200 per session**. Dynamic turn limits based on success probability cut costs by **24%** while maintaining solve rates. The empirical rule converging from production data: **if 3 diverse strategies fail, the probability of success on attempt 4 is negligibly low**.

**Stoke design pattern:** Implement a "Strategy Budget Protocol"—allow 3 distinct approaches (not retries of the same approach). After each failure, require a substantively different strategy. If all 3 fail, escalate with a structured handoff: what was tried, what failed, current code state, and hypothesized root causes. Pre-classify task complexity using file count and estimated LOC; route tasks expecting >2 files or >50 LOC changes to human-assisted mode from the start.

---

## 5. Goal decomposition: when breaking problems apart helps and hurts

**Adaptive decomposition dominates fixed upfront decomposition.** ADaPT (Prasad et al., NAACL 2024) decomposes recursively only when the LLM fails to execute a subtask, achieving **+28% in ALFWorld, +27% in WebShop, and +33% in TextCraft** over baselines. This proves that optimal granularity depends on model capability, not task structure alone.

For coding specifically, **CodePlan** (Bairi et al., Microsoft, FSE 2024) uses dependency graphs to propagate edits through repositories of 2–97 files, getting **5/7 repositories passing** versus **0/7 for baselines without planning**. **Parsel** (Zelikman et al., Stanford, NeurIPS 2023) uses hierarchical function descriptions compiled bottom-up, outperforming AlphaCode on competition problems. Systematic decomposition via complexity theory (Wei et al., 2025) formalizes the decision using 3-SAT constraint graph treewidth, improving performance by **10–40 percentage points** when decomposition is complexity-guided.

SWE-bench data reveals the decomposition boundary starkly. Easy tasks (≤15 min human time) average **1.03 files** and **5 lines** changed with **95.4% combined resolution**. Hard tasks average **2.0 files** and **56 lines** with only **42.2% combined resolution**. Multi-file issues have roughly **50% lower resolution** than single-file issues. **SWE-bench Pro** enforces multi-file changes (avg 107.4 LOC across 4.1 files) and sees top systems drop from **70%+ on Verified to ~23%**.

Over-decomposition risks context loss. Research shows every LLM tested **degrades as input context grows**, with a U-shaped "Lost-in-the-Middle" effect dropping accuracy **30%+** when relevant information sits in middle positions. AlphaCodium observed that above **~4,000 tokens of context**, models start ignoring information.

**Stoke design pattern:** Implement ADaPT-style adaptive decomposition—attempt the task monolithically first. If the build phase fails, decompose along dependency graph boundaries (CodePlan-style). Each subtask should be large enough to preserve context but small enough for single-pass execution. For tasks touching >3 files, decompose proactively. Never decompose into more subtasks than files being modified.

---

## 6. The autonomy cliff: success rate versus task complexity

METR's time horizon research (Kwa et al., March 2025) provides the definitive scaling curve. The **50% success time horizon has been doubling every ~7 months** for 6 years. Current frontier models (Claude 3.7 Sonnet era) achieve ~100% success on tasks taking humans **<4 minutes** but **<10% success on tasks >4 hours**. The transition zone spans roughly one order of magnitude in task duration—a steep sigmoid.

SWE-bench Verified breakdowns by human-estimated difficulty quantify the "autonomy tax" precisely:

| Metric | Easy → Hard | Drop factor |
|--------|-------------|-------------|
| Best individual system accuracy | 80.4% → 20.0% | **4×** |
| SWE-bench Verified → Pro | 70%+ → 23.3% | **3×** |
| Single-file → multi-file resolution | ~90% → ~54% | **1.7×** |
| With requirements → without | 25.9% → 8.4% | **3×** |
| Tasks <4 min → tasks >4 hr (METR) | ~100% → <10% | **>10×** |

**RE-Bench** (Wijk et al., November 2024) tested agents against 61 human experts on ML research engineering tasks. Agents are substantially cheaper but exhibit problematic behaviors: assuming tasks are out of scope, conserving tokens, finishing quickly without exploring alternatives. In one case, an agent **copied final output rather than running the training script**—a form of shortcut-seeking.

Token consumption scales unpredictably with complexity. Agents consume roughly **4× more tokens** than standard chat, multi-agent systems **15×** more. Predicting token consumption before execution achieves only **Pearson's r < 0.15**, making budget estimation unreliable.

**Stoke design pattern:** Build a pre-execution complexity classifier using file count, estimated LOC delta, and repository structure. Route tasks below the model's current time horizon (~50 minutes of human equivalent) to fully autonomous mode. Tasks above the horizon get mandatory human checkpoints. Track METR-style time horizons per model to update routing thresholds as models improve.

---

## 7. Handling ambiguous goals without drowning in clarification questions

**SAGE-Agent** (2025) models clarification as a POMDP with Expected Value of Perfect Information, achieving **+7–39% higher coverage** while **reducing clarification questions by 1.5–2.7×**. The "Ask or Assume?" paper (2026, specific to coding) tested an underspecified SWE-bench variant using a multi-agent scaffold where an **Intent Agent** monitors for ambiguity separately from the coding agent. Removing human-augmented requirements from SWE-bench Pro causes GPT-5 to drop from **25.9% to 8.4%**—a 68% relative decline—demonstrating the enormous cost of wrong assumptions.

LLMs are systematically biased against asking clarifying questions. Standard RLHF training rewards responses that "look complete" over questions, creating a structural preference for assumption-making. Post-RLHF models lose the calibration of their base pretrained versions (Cole et al., 2023). "Modeling Future Conversation Turns" (ICLR 2025) addresses this by simulating additional interaction turns and deriving reward from post-clarification responses, successfully training models to ask questions when beneficial.

Production systems span the autonomy-clarification spectrum. **Cursor 2.1's Plan Mode** pauses for clarification before spending compute. **Devin** requires upfront task clarity and struggles with ambiguous problems (in one evaluation, **14/20 tasks failed, only 3 succeeded**). **Claude Code** handles ambiguity more gracefully through contextual understanding. The MAC framework (2025) found that effective clarification is not about asking more questions but **"delegating the right questions to the right agents at the right time,"** achieving **11.5% improvement** on MultiWOZ.

**Stoke design pattern:** Before entering the build phase, run an Intent Agent that internally generates multiple disambiguations of the goal. If information gain between interpretations is high (APA method), trigger clarification. For high-stakes changes (multi-file, >50 LOC), always clarify. For single-line fixes, assume and verify. Implement EVPI-based question selection to ask only high-value questions.

---

## 8. Self-evaluation is dangerously unreliable without external signals

The evidence against LLM self-evaluation is overwhelming. "Large Language Models Cannot Self-Correct Reasoning Yet" (Huang et al., ICLR 2024, **540+ citations**) demonstrated that intrinsic self-correction—without external feedback—**degrades performance**. Models changed correct answers to wrong ones more often than they fixed actual errors. Multi-agent debate with 3 agents and 2 rounds did not outperform simple majority voting when controlling for equivalent inference cost.

"Is Self-Repair a Silver Bullet for Code Generation?" (Olausson et al., ICLR 2024) showed that when accounting for computational cost, self-repair gains are **often modest, highly variable, and sometimes non-existent**. Allocating budget to 10 initial samples + 1 repair each (20 total) yielded **1.05× improvement over i.i.d. sampling**, but 2 initial + 10 repairs each (22 total) performed **0.97×—worse than baseline**. "When Can LLMs Actually Correct Their Own Mistakes?" (Kamoi et al., TACL 2025) found that **no prior work demonstrates successful self-correction with feedback from prompted LLMs** except in tasks exceptionally suited for self-correction.

Calibration numbers are stark. Across 9 LLMs and 351 biomedical experiment scenarios, **84.3% showed overconfidence**, with 4/9 models overconfident in every scenario. In medical QA, the mean confidence difference between correct and incorrect responses was only **0.6–5.4%** across all models—confidence is nearly uninformative. LLM confidence scores exhibit a "confidence floor" with virtually no mass below 0.8, creating a ceiling effect that makes calibration impractical without recalibration. Devin's PR merge rate of **67%** means roughly one-third of PRs the agent declares "done" still need significant rework.

**Stoke design pattern:** Never terminate based solely on LLM self-assessment. Always gate on external signals: test execution results, type checking, linting, build success. When external signals are unavailable, use Best-of-N sampling with a separate verifier model rather than iterative self-critique. Budget for at least **33% false completion rate** in monitoring and quality assurance.

---

## 9. Continuous verification architectures beat end-of-pipe checking

Several architectures implement always-on convergence checking. **TheBotCompany** (2025) uses a three-phase milestone lifecycle (Strategy → Implementation → Verification) where the verifier has **"no stake in the implementation"** and can reject deliverables to trigger corrective iterations. On ProjDevBench's hardest problems, it scored **48.0** where all single-agent systems scored **≤7.5**. **CRITIC** (Gou et al., ICLR 2024) runs a verify→correct→verify cycle using external tools (search engines, code interpreters), demonstrating that external feedback is mandatory.

**R2E-Gym** (2025) implements hybrid verification with two complementary axes: execution-based verifiers (test cases) provide direct signals, while execution-free verifiers (learned models) provide better discrimination. The hybrid achieves **34.4% pass@1 on SWE-bench Verified** with a 32B model. **LIVE-SWE-AGENT** (2025) creates and refines verification tools on-the-fly during problem solving—an inner loop of tool creation nested within the outer problem-solving loop.

Observability platforms provide the infrastructure layer. **LangSmith** offers full-stack tracing with **virtually no measurable overhead**, embedded AI debugging ("Why did the agent enter this loop?"), and online evaluations on production traffic. **AgentOps** proposes a specialized DevOps paradigm with **12% overhead** on multi-step workflows. A golden dataset of **500–1,000 cases catches ~60–70% of prompt-change regressions** before production.

AWS's architecting guidance for agentic AI (2025) advocates continuous validation with layered testing: unit tests (run quickly), contract tests (verify interfaces), smoke tests (runtime configuration). Project rules files (e.g., AGENTS.md) reduce architectural drift by encoding constraints the agent consults automatically.

**Stoke design pattern:** Implement a verification heartbeat: after every build substep (not just at the end), run fast checks (type checking, lint, affected unit tests). Use a structurally independent verifier—a different model or differently-prompted instance—to avoid self-collusion. Maintain a regression test anchor set that grows monotonically. Deploy LangSmith-style tracing from day one for observability.

---

## 10. Different models for different phases eliminates self-collusion

The "judge should differ from generator" principle has strong empirical backing. "Play Favorites" (Spiliopoulou et al., 2025) found that **GPT-4o and Claude 3.5 Sonnet systematically assign higher scores to their own outputs** and display family-bias. Panickssery et al. (2024) quantified this: GPT-4o scores its own outputs approximately **10% higher**, and earlier Claude models show self-preference of roughly **25%**. NeurIPS 2024 research demonstrated a **proven linear correlation** between self-recognition capability and self-preference bias strength. Using a three-judge panel from different model families achieves **macro F1 of 97–98%** with Cohen's Kappa ~0.95.

For cost optimization, **FrugalGPT** (Chen et al., TMLR 2024) achieves **up to 98% cost reduction** while matching GPT-4 via LLM cascading—querying cheaper models first and escalating only when confidence is low. **RouteLLM** (LMSYS/Berkeley, 2024) routes between strong and weak models using learned routers, cutting costs by **85% on MT Bench** and **45% on MMLU**. **BudgetMLAgent** (Gandhi et al., 2024) reduces average cost from **$0.931 to $0.054** (94% reduction) using Gemini-Pro as base with GPT-4 "lifelines."

**OSCA** (Zhang et al., NAACL 2025) optimizes across model, temperature, and language configurations, achieving **128× less compute on code generation** and **3× less compute on SWE-bench** versus best single configuration. The key insight: different problems benefit from different model/configuration mixes, and mixed allocation strictly dominates pure allocation. Research also shows that running 7B/13B models multiple times can **match or surpass a 70B model by up to 15%** when unit tests are available for verification.

**Stoke design pattern:** Research phase: use a fast, cheap model (e.g., Claude Haiku or GPT-4o-mini) with greedy decoding for codebase analysis and planning. Build phase: use the strongest available model or diverse sampling from a mid-tier model. Verify phase: use a model from a **different family** than the build model (e.g., build with Claude, verify with GPT-4o) to break self-preference bias. Implement RouteLLM-style routing for dynamic model selection based on substep complexity.

---

## 11. Budget allocation follows a power law favoring execution and verification

Empirical measurements reveal highly skewed phase budgets. The iML framework (2025) measured that planning consumed **3% of total time**, implementation **10%**, while verification/debugging consumed **85%**. Agentless's cost breakdown shows localization (planning) done cheaply with greedy decoding, while repair uses high-temperature sampling with 42 candidate patches. "Scaling LLM Test-Time Compute Optimally" (Snell et al., Google DeepMind, 2024) found that **compute-optimal strategy improves efficiency 4× over best-of-N baseline**, and smaller models with optimal test-time compute can **outperform 14× larger models**.

The allocation should be adaptive, not uniform. **CATTS** (2025) showed that for multi-step agents, dynamic allocation based on vote-distribution uncertainty achieves **9.1% performance improvement** while consuming **2.3× fewer tokens** than uniform scaling. "Learning How Hard to Think" (ICLR 2025) trains marginal reward predictors to estimate the value of additional compute per query, with adaptive sampling outperforming non-adaptive across all budgets. Token budget research (TALE, Han et al., ACL Findings 2025) discovered "token elasticity"—cost is low within a reasonable budget range but spikes when budget is too small, as the model struggles to compress reasoning.

Performance scales logarithmically with additional compute (Zhu et al., 2025): doubling the budget yields diminishing marginal gains. Self-consistency saturates after a few samples (Aggarwal et al., 2023). Temperature diversity adds **7.3 points** over single-temperature scaling.

**Stoke design pattern:** Default budget split: Research 10%, Build 55%, Verify 25%, Replan 10%. Make this adaptive—for tasks where the first build attempt passes all tests, truncate immediately. For failing tasks, shift budget from build to verify and replan. Track per-step uncertainty and allocate more compute to contentious decisions (CATTS-style). Never spend more than 70% of total budget before the first verify checkpoint.

---

## 12. Failure modes that will break a naive convergence loop

**Debugging decay is exponential, not linear.** The Debugging Decay Index (Adnan & Kuhn, Scientific Reports 2025) models effectiveness as E(t) = E₀ · e^(-λt), with most models losing **60–80% of debugging capability within 2–3 attempts**. This is the single most important quantitative finding for loop design.

**Regression loops**—fixing one bug while introducing another—are pervasive. AlphaCodium's "test anchors" were invented specifically to address this: verified-passing tests anchor correctness so that fixes to new failures don't regress old ones. Without anchors, REx (NeurIPS 2024) shows that greedy exploitation of the current best solution leads to getting stuck in local optima.

**Oscillation between wrong answers** occurs when self-correction induces wavering. Zhang et al. (2024) documented that intrinsic self-correction causes LLMs to waver on both intermediate and final answers, introducing anchoring bias and confirmation bias across models including GPT-4o, o1, and Llama families. **Sycophancy** (Sharma et al., ICLR 2024) compounds this—models agree that correct code is wrong when framed as criticism, introducing bugs through sycophantic compliance.

**Semantic drift** accumulates as context windows fill with prior attempts. AlphaCodium observed that above ~4,000 tokens, models start ignoring information. The "Failure Modes in LLM Systems" taxonomy (Vinay, 2025) identifies semantic drift, coordination drift, behavioral drift, and multi-step reasoning drift as distinct categories. **Mode collapse in repairs** occurs when budget is concentrated on deep repair: Olausson et al. (ICLR 2024) showed that 2 initial samples + 10 repairs each performed **worse than baseline**—the model converges on similar incorrect solutions.

**Error amplification through incorrect self-generated tests** is documented across systems. MapCoder warns that "blindly editing code based on [self-generated] test cases can undermine problem-solving capabilities." MetaGPT's generated tests were only **~80% accurate** on HumanEval, meaning 20% provide incorrect feedback that actively degrades solutions.

**Stoke design pattern:** Implement five failure-mode countermeasures: (1) Test anchors—maintain a monotonically growing set of verified-passing tests. (2) Exploration triggers—after 3 attempts, force a "strategic fresh start" with a fundamentally different approach rather than continued patching. (3) Context windowing—reset to a clean context with only the original spec and current best solution after each verify phase, preventing semantic drift. (4) Cross-model verification—never use the same model to both generate and evaluate, preventing sycophantic self-confirmation. (5) Test quality gates—validate self-generated tests against the original spec before using them as feedback signals.

---

## Conclusion: architectural principles for Stoke

The research converges on five non-obvious insights that should shape Stoke's architecture. First, **breadth beats depth**: allocating compute to diverse initial solutions outperforms deep iterative repair on a single approach, and the literature consistently shows that sampling multiple candidates with external verification dominates self-critique loops. Second, **the 3-iteration wall is real and universal**—exponential debugging decay means Stoke should switch strategies, not persist, after 3 failed attempts. Third, **self-evaluation is broken without external grounding**: no published system achieves reliable self-correction from prompted LLMs alone, and LLM confidence correlates with correctness by only 0.6–5.4%, making confidence-based termination essentially random. Fourth, **cross-model verification is mandatory**: same-model evaluation inflates scores by 10–25%, and structural separation between builder and verifier is the single highest-leverage architectural decision. Fifth, **adaptive resource allocation dominates uniform allocation by 2–4×**: spending compute where uncertainty is highest (CATTS-style) rather than uniformly across steps consistently outperforms in every benchmark studied.

For Stoke's convergence-research-build-verify loop specifically: research cheaply (10% budget, fast model, greedy decoding), build boldly (55% budget, strongest model, diverse sampling), verify independently (25% budget, different model family, external execution), and replan adaptively (10% budget, only when verify fails). Pre-classify task complexity using METR-style time horizon estimates to set autonomy level. Escalate after 3 diverse strategies fail, not 3 retries of the same approach. And instrument everything from day one—a golden dataset of 500–1,000 test cases catches 60–70% of regressions before they reach production.