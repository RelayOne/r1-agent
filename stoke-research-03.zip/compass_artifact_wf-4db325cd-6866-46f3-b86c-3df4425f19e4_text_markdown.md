# Frontier AI models for autonomous coding: a multi-model orchestration guide for Stoke

**Claude Opus 4.6 and GPT-5.4 lead coding benchmarks at 79–81% on SWE-bench Verified, but the agent scaffold matters more than model choice** — the same model swings 22+ points depending on orchestration quality. This finding is the most consequential for Stoke's architecture. The frontier has converged: six models now cluster within 2 percentage points on the hardest benchmarks. Cost efficiency varies **100×** between models at similar performance levels, making intelligent routing and cascading the primary levers for competitive advantage. The optimal architecture is not "pick the best model" but rather a tiered multi-model system that routes tasks by complexity, uses cross-model review for quality assurance, and reserves premium models for the 10–20% of tasks that truly need them.

---

## 1. Benchmark scores have converged at the frontier

SWE-bench Verified remains the most-cited coding benchmark, though OpenAI's audit confirmed **training data contamination across all frontier models**, prompting the community to shift toward SWE-bench Pro and SWE-rebench for cleaner signals. HumanEval is saturated (all frontier models score 90%+) and no longer differentiates.

**SWE-bench Verified (March 2026, 500 real GitHub issues):**

| Model | Self-reported | Standardized (mini-SWE-agent) | Gap |
|-------|-------------|-------------------------------|-----|
| Claude Opus 4.5 | 80.9% | 76.8% | 4.1pp |
| Claude Opus 4.6 | 80.8% | 75.6% | 5.2pp |
| Gemini 3.1 Pro | 80.6% | 69.6% | 11.0pp |
| GPT-5.2 | 80.0% | 72.8% | 7.2pp |
| Claude Sonnet 4.6 | 79.6% | — | — |
| Gemini 3 Flash | — | 75.8% | — |
| DeepSeek V3.2 | 73.0% | 70.0% | 3.0pp |
| Grok 4 | 73.5% | 58.6% | 14.9pp |

The self-reported vs. standardized gap ranges from **3 to 15 points**. Gemini 3.1 Pro and Grok 4 show the largest discrepancies, suggesting their official numbers depend heavily on optimized scaffolding. For Stoke's planning, the standardized numbers are more predictive of what you'll see with your own agent harness.

**SWE-bench Pro (1,865 multi-language tasks, less contaminated)** tells a different story. With custom agent scaffolding, GPT-5.4 leads at **57.7%**, followed by GPT-5.3-Codex at **56.8%** and Claude Code (Opus 4.5) at **55.4%**. Under the standardized SEAL scaffold, Claude Opus 4.5 leads at **45.9%** while GPT-5 scores **41.8%**. This divergence confirms that **agent engineering is the primary multiplier at the frontier**.

**Aider Polyglot (225 exercises across 6 languages, October 2025):** GPT-5 (high reasoning) leads at **88.0%** ($29.08/run), followed by o3-pro at **84.9%** ($146.32/run), Gemini 2.5 Pro at **83.1%** ($49.88/run), and Grok 4 at **79.6%** ($59.62/run). DeepSeek V3.2 scores **74.2%** at just **$1.30/run** — the best cost-efficiency by a wide margin.

**METR Time Horizons** measure how long a task (in human-equivalent time) an AI agent can reliably complete. Claude Opus 4.6 achieves a **50% success time horizon of 14 hours 30 minutes** — meaning it succeeds half the time on tasks that take a human expert 14.5 hours. This metric has been **doubling every ~7 months** since 2019, accelerating to every ~4 months in 2024–2025. At this rate, week-long autonomous tasks become feasible within 2–4 years.

**LiveCodeBench (competitive programming, contamination-free):** Gemini 3 Pro Preview leads at **91.7%**, followed by Gemini 3 Flash at **90.8%** and DeepSeek V3.2 at **83.3–89.6%**. Gemini's dominance here reflects strong algorithmic reasoning, though this measures competitive programming rather than real-world software engineering.

---

## 2. Each model has distinct strengths that inform routing decisions

The models are not interchangeable. Their profiles differ substantially on coding subtasks, and these differences should drive Stoke's task routing logic.

**Claude Opus 4.6** excels at **architectural reasoning, multi-file comprehension, and sustained agentic work**. Developer surveys show ~70% preference for Claude on coding tasks. A Google principal engineer reported Claude "replicated a year of architectural work in one hour." Claude's edit consistency on SWE-rebench is unmatched: **34 of 40 tasks solved 5/5 attempts**. Claude also demonstrates the best calibration behavior — Sonnet 3.7 with thinking showed only **0.04% unfaithful reasoning rate**, and Claude 4.1 Opus achieved **0% hallucination on AA-Omni** by refusing uncertain queries rather than guessing. Weakness: performance degradation after ~147K–152K tokens in context, documented "lazy completion" patterns (inserting `// Rest of the code remains the same`), and a recent regression in March 2026 where stop-hook violations rose from zero to 10/day.

**GPT-5/5.4** leads on **targeted code editing** (88% on Aider Polyglot) and **token efficiency** (fewest tokens per problem on SWE-rebench). GPT-5.4 achieves **75% on OSWorld** (surpassing human baseline of 72.4%). OpenAI's Codex scaffold with 1M context window is optimized for long-running coding tasks. Weakness: verbosity — OpenAI introduced a `text.verbosity` parameter specifically to combat this. GPT-5.4 also "makes assumptions silently" rather than asking clarifying questions, and the Codex variant can be "too terse when planning is needed."

**Gemini 3.1 Pro** leads on **Terminal-Bench 2.0** at **78.4%** (CLI/DevOps tasks) and has the strongest reasoning scores (GPQA Diamond: 94.3%, ARC-AGI-2: 77.1%). Cost-effective at $2/$12 per million tokens. Weakness: **severe context window degradation** — after approximately 20% of context is used (~200K tokens), the model begins confusing past information with current state. Multiple P0 GitHub issues document instruction-following failures in long sessions, infinite loops, and "going rogue."

**DeepSeek V3.2/V4** offers **extreme cost efficiency** at $0.28/$0.42 per million tokens — roughly **60× cheaper** than Claude Opus 4.6 for output. DeepSeek V3.2 scores 73% on SWE-bench Verified and achieves 70.2% on SWE-bench Multilingual (vs. GPT-5's 55.3%). Weakness: poor instruction-following documented by 16x Eval — "repeatedly outputs entire files when asked for targeted changes." DeepSeek R1 has an **83% hallucination rate on AA-Omni** (almost always guesses wrong rather than refusing). CrowdStrike found R1 produces code with **50% more security vulnerabilities** when prompts contain certain sensitive topics.

**Grok 4** shows strong self-reported numbers but the largest gap between self-reported and independent scores (**14.9 points** on SWE-bench). No official system card published. Limited ecosystem and documentation for agent building. The **58.6% independent SWE-bench score** suggests caution in relying on it for production coding agents.

**Mistral Large 3** has limited benchmark presence on major coding leaderboards. Devstral 2 (Mistral's coding model) scores **53.8% on SWE-bench Verified** — significantly below frontier. Best use case is output-heavy tasks where Mistral's competitive output pricing ($6/M) matters, and for EU data sovereignty requirements.

**Qwen 3 Coder** achieves **70.6% on SWE-bench Verified** with only **3B active parameters** — extraordinarily parameter-efficient. However, it averages **8.12M tokens per problem** (~154 turns), making it token-hungry despite being compute-light. Independent testing shows significant discrepancies from claimed benchmarks (73.7% claimed on Aider vs. 16.4% independently).

---

## 3. The architect/editor split works, but review beats planning

Aider's architect mode achieved **85% pass rate** (often misquoted as "85% improvement") using o1-preview as architect and o1-mini or DeepSeek as editor. The actual improvement from splitting is more modest: self-pairing (e.g., Sonnet as both architect and editor) adds **3–5 percentage points** over solo performance, while weak models like o1-mini improve by **~17% relative** when paired with a strong editor.

**Optimal documented pairings from Aider:**

| Architect | Editor | Score | Cost |
|-----------|--------|-------|------|
| o1-preview | o1-mini (whole) | 85.0% | High |
| o1-preview | Claude 3.5 Sonnet (diff) | 82.7% | Moderate |
| DeepSeek R1 | Claude 3.5 Sonnet | 64.0%* | 14× cheaper than o1 |
| Claude 3.5 Sonnet | Claude 3.5 Sonnet | 80.5% | Moderate |

*Different benchmark version (polyglot).

**The key insight is architectural, not about specific pairings:** strong reasoning models (o1, R1, QwQ) excel as architects because they handle the planning phase well but struggle with structured code editing output. Fast instruction-following models (Sonnet, DeepSeek, GPT-4o) excel as editors because they reliably format code changes. For Stoke with current models, the recommended pairings would be **Claude Opus 4.6 as architect with Claude Sonnet 4.6 or GPT-5.4 as editor**.

However, a March 2026 paper — "Review Beats Planning: Dual-Model Interaction Patterns for Code Synthesis" — found that **the review-then-fix pattern outperforms plan-then-code**. Plan-then-code actually *decreased* performance by 2.4 percentage points on HumanEval+ due to "guidance contamination" (the planner's abstract guidance introduced errors in 15 of 164 problems). Review-then-fix achieved **90.2% on HumanEval+** with retry, exceeding both GPT-4o (87.2%) and O1 Preview (89.0%). This suggests Stoke should prioritize the **generate → review → fix** loop over the architect → editor pipeline, or ideally combine both approaches.

**Cross-model review catches 3–5× more bugs than single-pass review.** Practitioner data from Zylos (February 2026) across production PRs shows iterative multi-model review finding **21 bugs** where single-pass would have found ~5, with only 3 false positives across 24+ review rounds. The cost is **$1–5 per review cycle** for ~2,000-line PRs. The Multi-LLMSecCodeEval study (March 2026) found cross-model verification improved vulnerability detection by **14.9%** over single-model approaches. Different model architectures have largely **uncorrelated blind spots** — one model catches timing-unsafe cryptographic comparisons, another flags architectural problems, a third spots naming inconsistencies. For Stoke, this means routing code through at least two different model families for review before merging.

---

## 4. Cost efficiency varies 100× and cascading can save 75–90%

**Current API pricing (April 2026, per million tokens, input/output):**

| Model | Input | Output | SWE-bench % | Value ratio* |
|-------|-------|--------|-------------|-------------|
| DeepSeek V3.2 | $0.28 | $0.42 | 73% | **173.8** |
| DeepSeek V4 | $0.30 | $0.50 | ~81%† | **162.0** |
| MiniMax M2.5 | $0.30 | $1.20 | 80.2% | **66.8** |
| Grok 4.1 | $0.20 | $0.50 | ~59%‡ | 118.0 |
| Gemini 3.1 Pro | $2.00 | $12.00 | 80.6% | **6.7** |
| GPT-5.4 | $2.50 | $15.00 | ~80% | **5.3** |
| Claude Sonnet 4.6 | $3.00 | $15.00 | 79.6% | **5.3** |
| Claude Opus 4.6 | $5.00 | $25.00 | 80.8% | **3.2** |

*Value ratio = SWE-bench % ÷ output cost per M tokens. †Unverified internal claim. ‡Independent standardized score.

**Best model per dollar by task type:**

- **Bug fixes:** Gemini 3.1 Pro ($2/$12) delivers 80.6% SWE-bench at 52% less than Opus output cost. For complex multi-file bugs, Claude Opus 4.6 remains the premium choice.
- **Feature implementation:** MiniMax M2.5 ($0.30/$1.20) achieves 80.2% SWE-bench at 95% less than Opus — the best value for standard feature work.
- **Refactoring:** DeepSeek V4 ($0.30/$0.50) with 1M context and claimed 81% SWE-bench. Refactoring is primarily structural and doesn't need frontier reasoning.
- **Test writing:** DeepSeek V3.2 ($0.28/$0.42) — test writing is more formulaic; 73% SWE-bench is sufficient. **96% cheaper** than Claude.
- **Code review:** Mistral Large 3 ($2/$6 output) has the cheapest output in its tier, and review is output-heavy. Use Claude Opus 4.6 for architectural-level review.
- **Documentation:** DeepSeek V3.2 — lowest-stakes coding task where any capable model suffices.

**No published paper applies FrugalGPT-style cascading specifically to coding benchmarks**, but the principle is being deployed in production. Claude Code itself uses ~30% Haiku calls for auxiliary tasks, reserving Opus for core reasoning — implicit cascading. OpenDev (arxiv 2603.05344) uses a four-level hierarchy with "workload-specialized model routing" across execution, thinking, and compaction workflows.

The converging evidence suggests a three-tier cascade for Stoke:

- **Tier 1 (Budget, $0.28–$0.50/M output):** DeepSeek V3.2/V4, Gemini Flash — handles ~40–50% of coding work (boilerplate, tests, documentation, simple fixes)
- **Tier 2 (Mid, $1.20–$6.00/M output):** MiniMax M2.5, Mistral Large 3, Gemini 3.1 Pro — handles ~30–40% (feature implementation, code review, medium refactoring)
- **Tier 3 (Premium, $15–$25/M output):** Claude Opus 4.6, GPT-5.4 — needed for ~10–20% (complex multi-file reasoning, architectural decisions, ambiguous requirements)

**Estimated blended cost: $1–3/M** vs. $15–$25/M for all-Opus, representing a **75–90% reduction**. The cascade trigger for coding is uniquely reliable because compilation success, test pass rates, and linting provide **automatic quality verification** — if the cheap model's code compiles and passes tests, no escalation is needed.

---

## 5. Long-horizon performance is the key differentiator for agents

For autonomous coding agents like Stoke, sustained multi-step performance matters more than single-shot benchmarks. METR's time horizon data provides the cleanest signal here.

**Claude Opus 4.6** holds the documented lead with a **14.5-hour 50% time horizon** — it succeeds half the time on tasks that take a human expert nearly 15 hours. Its 1M token context window (beta), adaptive thinking, and context compaction features are designed specifically for long-running agentic work. Anthropic describes it as designed to "plan more carefully, sustain agentic tasks for longer, and operate more reliably in larger codebases."

**GPT-5.4** achieves **75% on OSWorld** (surpassing human baseline) and shows strong multi-step performance, though it hasn't been formally measured by METR yet. The Codex scaffold is optimized for sustained coding with 1M context.

**Context management is the practical bottleneck.** Claude Code's best practices acknowledge that "Claude's context window fills up fast, and performance degrades as it fills." Output quality drops noticeably at ~147K–152K tokens. Solutions include context compaction (auto-summarizing older conversation parts), subagent delegation, and fresh context for review passes. Gemini's context issues are worse: reliable performance degrades after ~200K tokens despite a 1M capacity, with multiple P0 bugs for instruction-following failures.

The METR trend shows **exponential improvement with no plateau in sight** — R² = 0.83 correlation between task length and agent success rate across 7 years of data. However, performance drops substantially on "messier," less-structured tasks, and holistic scoring reduces measured performance versus algorithmic scoring. For Stoke, this means **well-specified, test-driven tasks** will see the best autonomous completion rates, while ambiguous requirements should trigger human escalation.

---

## 6. Calibration and hallucination create hidden risks for autonomous agents

The most dangerous failure mode for an autonomous coding agent isn't generating wrong code — it's generating wrong code *confidently*. MIT research found that models use **34% more confident language when hallucinating** than when stating facts.

**Calibration rankings** (expected calibration error, lower is better): Claude Haiku 4.5 (ECE = 0.122, best), GPT-4o/5.x (well-calibrated at high confidence), Gemini 2.5 Pro (0.14% unfaithful reasoning rate), DeepSeek R1 (0.37% unfaithful), GPT-4o-mini (13% unfaithful — dramatically worse). Kimi K2 showed the worst calibration (ECE = 0.726) with only 23.3% accuracy — a 72+ percentage point miscalibration gap mirroring the Dunning-Kruger effect.

**Code-specific hallucination data is alarming.** A USENIX Security 2025 study across 576,000 code samples found a **19.6% average package hallucination rate** — models inventing nonexistent packages. Commercial models averaged ~5.2% vs. ~21% for open-source models. GPT-4 Turbo had the lowest package hallucination rate. Critically, **43% of hallucinated packages repeated across queries**, making them exploitable through "slopsquatting" attacks. For code review tasks specifically, hallucination rates reached **42.8–47.0%** across all models.

**Veracode's 2025 report** testing 100+ LLMs found **45% of AI-generated code** introduced OWASP Top 10 vulnerabilities. Java had a 72% security failure rate. Cross-site scripting failed in 86% of relevant samples. Security performance remained flat regardless of model size. **No model demonstrated reliably secure code generation** — this means Stoke must include security scanning as a hard gate, not rely on any model's security awareness.

For Stoke's design, the implication is clear: **never trust a single model's output for autonomous execution**. Multi-model verification reduces hallucinations up to 96%. Web search access reduces hallucinations 73–86%. Test execution is the most reliable cascade trigger.

---

## 7. Model gotchas that will break autonomous agents

Each model has documented behavioral quirks that will cause failures in autonomous pipelines if unmitigated.

**Claude:** The "lazy completion" pattern is the most critical — Claude inserts `// Rest of the code remains the same` when editing long files, making the output unusable. An AMD AI Director's April 2026 analysis of **6,852 Claude Code sessions** found stop-hook violations (premature cessation, permission-seeking) went from zero before March 8 to 10/day. Code reads before making changes dropped from 6.6 average to just 2. Claude also truncates long responses with `[Content continues following the same pattern...]` approximately 90% of the time for 1,400+ word outputs. Context window auto-compaction can cause infinite loops where Claude reads the same files repeatedly.

**GPT-5/5.4:** Verbosity is the primary issue — GPT "confuses itself" as repeated summaries fill the context window. OpenAI's own prompting guide explicitly warns about this and introduced a `text.verbosity` parameter. GPT also makes silent assumptions about environment (e.g., assuming Redis is available without checking) and doesn't offer alternatives unprompted. Set `max_completion_tokens` to prevent runaway billing.

**Gemini:** Context window degradation is severe — after ~200K tokens, the model confuses past with current state, takes actions based on outdated information, and enters infinite loops. This is documented across multiple P0 GitHub issues. Bug re-introduction is also common: Gemini fixes a bug, then makes the exact same mistake in the next generation. **Gemini should not be used for long-running autonomous sessions without aggressive context management.**

**DeepSeek:** Poor instruction-following — outputs entire files when asked for targeted changes. R1 has an 83% hallucination rate on uncertain queries (guesses rather than refusing). Reliability is also an infrastructure concern: 84+ outages tracked since January 2025 with no published post-mortems.

**Universal pattern (KAMI Benchmark):** Four recurring failure modes affect all models — premature action without grounding (acting before verifying state), over-helpfulness (substituting missing entities rather than returning errors), vulnerability to distractor context, and fragile execution under heavy tool-call load. The MAST study found **41–86.7% of multi-agent LLM systems fail in production**, with 79% of failures from specification and coordination issues.

---

## 8. API reliability demands multi-provider fallback

AI APIs are the **least reliable category** of developer APIs. Traditional SaaS sees 0–1 incidents per month; AI providers see 10–15+.

| Provider | 90-day API uptime | Incidents/month | SLA |
|----------|------------------|-----------------|-----|
| Anthropic | **98.98%** | 10–15+ | Enterprise only |
| OpenAI | **99.5%** (2025 avg) | 10–15+ | Azure: 99.9% |
| Google (Vertex) | **~99.9%** | Low (GA models) | 99.9% with credits |
| DeepSeek | **99.52%** (web) | 5–10+ | None |
| xAI | ~99% (est.) | 4+/month | Dedicated capacity |

**Anthropic's uptime has degraded in Q1 2026** from ~99.5% to ~98.8–99.0%, driven by massive user growth after users migrated from ChatGPT in March 2026. The longest recent incident (Opus 4.5 errors, January 2026) took ~30 hours to resolve. For Stoke, this means expecting **~7–9 hours of Claude downtime per month**.

The mitigation is straightforward: **two providers at 99.3% each yield 99.995% effective uptime** when combined with automatic failover. Google's Vertex AI offers the only firm 99.9% SLA with financial credits. For a production agent, the recommended stack is Anthropic as primary with Google Vertex as the reliability backstop and OpenAI as the capability backstop.

---

## 9. Routing strategy for 7 Claude Max plus 1 ChatGPT Pro

With this subscription setup ($900–$1,600/month depending on Max tier), the optimal routing strategy maximizes throughput while maintaining quality and resilience.

**Claude Max subscriptions** provide ~225 messages per 5-hour rolling window (Max 5×) or ~900 messages (Max 20×). Claude Code and web chat share the same usage bucket. Weekly limits exist for both all-model and Sonnet-specific usage. These are subscription-based (not API), accessed through Claude Code's OAuth flow.

**Allocate 4 accounts to active Claude Code workstreams** (one per project or developer), **2 accounts to interactive analysis and review** (claude.ai/desktop), and **1 account as reserve/overflow** for peak demand. Stagger heavy usage across accounts so weekly limits don't all reset simultaneously. Use Sonnet 4.6 as default (separate weekly limit, more efficient) and reserve Opus 4.6 for complex architectural decisions.

**Route to ChatGPT Pro when:** all Claude accounts are rate-limited, Anthropic is experiencing an outage (~7–9 hours/month expected), tasks need deep research synthesis (ChatGPT Pro's research mode excels here), image/video generation is needed, or for cross-model verification of critical Claude outputs. ChatGPT Pro's "unlimited" access provides burst capacity, though subject to fair-use guardrails.

**Multi-account infrastructure:** Use the `CLAUDE_CONFIG_DIR` environment variable with separate config directories per account. Tools like Maestro (docs.runmaestro.ai) and CCS (Claude Code Switch) enable parallel orchestration across subscriptions with session resume.

---

## 10. Vendor architecture recommendations converge on key patterns

All three major vendors — Anthropic, OpenAI, and Google — have published comprehensive agent-building guides, and their recommendations converge on several principles.

**Start simple, add complexity only when demonstrated.** Anthropic's "Building Effective Agents" guide recommends beginning with augmented LLMs (single model + tools), then advancing through prompt chaining → routing → parallelization → orchestrator-workers → evaluator-optimizer → full agents. OpenAI similarly recommends starting single-agent and evolving to multi-agent only when needed. This is directly relevant to Stoke: begin with a single Claude Code-style loop, then add specialization.

**The writer/reviewer pattern is universally recommended.** Anthropic specifically advocates one agent writing code in full context, then a fresh-context agent reviewing (avoiding anchoring bias). OpenAI's Agents SDK supports evaluator-optimizer loops. Google's ADK includes LoopAgent with reviewer feedback patterns. For Stoke, implement generate → test → review → fix as the core loop.

**Context management is the critical engineering challenge.** All vendors offer compaction APIs (server-side context summarization). Anthropic recommends "just-in-time" context — maintaining lightweight identifiers (file paths, queries) and dynamically loading data at runtime using tools. OpenAI recommends `previous_response_id` chaining for conversation state. Google emphasizes progressive disclosure through their Skills system. For Stoke, use CLAUDE.md/AGENTS.md for persistent project context, compaction for long sessions, and subagent delegation for context isolation.

**Key API features for Stoke to leverage:**
- **Anthropic:** Extended thinking with adaptive depth, effort parameter (4 levels), tool use (bash, text editor, web search), Agent SDK with pre-built tools, compaction API, prompt caching (up to 90% savings)
- **OpenAI:** Responses API (flagship agent API), Agents SDK with handoffs/guardrails/tracing, structured outputs, Codex for cloud sandboxed coding, AGENTS.md for project guidance
- **Google:** Agent Development Kit (ADK) with LLM agents + workflow agents (sequential/parallel/loop), MCP support, A2A protocol for inter-agent communication, built-in evaluation framework

**AGENTS.md has become a cross-industry standard** adopted by Codex, Jules, Cursor, Aider, GitHub Copilot, Windsurf, Gemini CLI, and others. Stoke should support this format for project-level agent configuration.

---

## Conclusion: architectural recommendations for Stoke

Five insights should drive Stoke's multi-model architecture:

1. **Scaffold over model.** The 22+ point performance swing from agent engineering dwarfs the 1–2 point differences between frontier models. Invest more engineering effort in context management, tool orchestration, and error recovery than in model selection.

2. **Three-tier cascade with test-gated escalation.** Route ~40–50% of tasks to DeepSeek/Flash tier ($0.28–$0.50/M), ~30–40% to MiniMax/Gemini mid-tier ($1.20–$12/M), and ~10–20% to Claude Opus/GPT-5.4 ($15–$25/M). Use compilation + test passing as the cascade trigger — uniquely reliable for code versus natural language. Expected blended cost: **$1–3/M** vs. $15–$25/M for all-premium.

3. **Review-then-fix over plan-then-code.** Academic evidence shows the review pattern outperforms the planning pattern by **12+ percentage points** on HumanEval+. Use a cheap model to generate, a different model family to review, then the generator to fix. Cross-model review catches **3–5× more bugs** than single-pass for roughly $1–5 per cycle.

4. **Never trust a single model's security or correctness.** With 19.6% package hallucination rates, 45% of generated code containing security vulnerabilities, and 42–48% hallucination rates on code review tasks, autonomous execution requires hard gates: static analysis, test suites, and multi-model consensus before any code is merged.

5. **Design for degradation.** With AI API reliability at 98.8–99.5%, build multi-provider fallback into the core architecture. Claude as primary, Google Vertex as reliability backstop (only provider with 99.9% SLA), OpenAI as capability backup. This yields **~99.99% effective uptime** and provides the cross-model diversity that improves both quality and resilience.