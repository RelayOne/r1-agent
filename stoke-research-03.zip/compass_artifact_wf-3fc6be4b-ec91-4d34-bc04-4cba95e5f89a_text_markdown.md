# Compliance-grade audit infrastructure for LLM agent systems

**LLM-driven agents cannot be made fully deterministic, but they can be made fully auditable.** The core architectural insight for Stoke is that deterministic gates, cryptographic hash chains, and record-replay infrastructure compensate for the irreducible non-determinism in model inference. This report synthesizes findings from peer-reviewed papers, IETF standards, compliance frameworks, and emerging agent-security research across all ten questions to provide a technical foundation for building compliance-grade audit infrastructure.

---

## 1. Temperature=0 does not mean deterministic — and the reasons are deeper than sampling

The widespread assumption that setting `temperature=0` eliminates LLM output variance is empirically false. Atil et al. (2024, arXiv:2408.04667) tested five LLMs on MMLU and BBH benchmarks at temperature=0 across 10 runs each and found **accuracy variations of up to 15%**, with a gap between best and worst possible performance reaching **70%** on some tasks. Ouyang et al. (2025, ACM TOSEM, arXiv:2308.02828) found that even at temperature=0, **16–44% of code generation tasks** produced no identical outputs across five runs.

The root cause is not sampling randomness. A critical September 2025 blog post from Thinking Machines Lab (Horace He, "Defeating Nondeterminism in LLM Inference") reframes the field: **the forward pass of a standard LLM involves no atomic-add operations and is actually run-to-run deterministic given identical inputs.** The true culprit is **batch invariance failure** — when the same computation runs with different batch sizes (as happens in production inference servers with dynamic batching), each element receives numerically different results due to floating-point non-associativity. Their experiments showed that `torch.mm(a[:1], b)` versus `torch.mm(a, b)[:1]` can differ by up to **1,669.25** on CUDA.

For Mixture-of-Experts models like GPT-4, a second mechanism compounds this. Sherman Chann (2023, "Non-determinism in GPT-4 is caused by Sparse MoE") demonstrated that batched inference causes tokens from different sequences to compete for expert buffer slots, making outputs dependent on co-processed requests. Puigcerver et al. ("From Sparse to Soft Mixtures of Experts") confirmed: **the model is deterministic at the batch level but not the sequence level.**

Quantization does not solve the problem. Ingonyama's empirical testing of quantized LLaMA models across NVIDIA RTX 3090, RTX 4080, and L4 GPUs found **0% reproducibility across architectures** because LayerNorm and dequantization still rely on floating-point operations, and different GPU architectures generate different PTX instructions for matrix multiply kernels. Cross-architecture matching between A100 and H100 also yields **0% match rates** (EigenAI, 2025).

All three major providers issue explicit disclaimers. OpenAI states outputs are "non-deterministic by default" and the `seed` parameter provides only "mostly deterministic" results (with `system_fingerprint` changes occurring "a few times a year"). The seed parameter is being deprecated in the newer Response API. Anthropic states "even with a temperature of 0.0, the results will not be fully deterministic." Google notes "a small amount of variation is still possible." Yuan et al. (arXiv:2506.09501), selected for oral presentation at NeurIPS 2025, proposed LayerCast to achieve FP32-level determinism with BF16 memory efficiency, and Zhang et al. (arXiv:2511.17826, NeurIPS 2025) introduced Tree-Based Invariant Kernels enabling deterministic inference across tensor parallel sizes — but both remain research-stage solutions.

**Practical implication for Stoke:** Response caching (hashing prompt + parameters as cache key) is the most reliable production approach to determinism. For self-hosted models, batch-invariant inference kernels (vLLM support, EigenAI's custom GEMM) can achieve bitwise reproducibility on a single GPU architecture, but with **~7x performance penalty** in prompt processing.

---

## 2. The determinism spectrum defines what contracts Stoke can enforce

Gates in an agent orchestration system fall along a clear determinism spectrum, and the appropriate SLA differs fundamentally at each level.

**Fully deterministic gates (100% SLA, hard pass/fail)** include schema validation (JSON Schema, Pydantic), regex matching, hash comparison, and formal verification (Lean 4 theorem proving). These execute specification-based algorithms with no probabilistic components. Guardrails AI uses Pydantic models as deterministic output validators; if validation fails, the corrective re-ask step is non-deterministic, but the gate itself is perfectly repeatable. The Lean-Agent Protocol (Rashie & Rashi, arXiv:2604.01483, 2026) demonstrates the frontier: agent actions permitted "if and only if the Lean 4 kernel proves that the action satisfies pre-compiled regulatory axioms."

**Conditionally deterministic gates (threshold-based SLA)** include embedding similarity comparisons and local ML classifiers. Cosine similarity computation is deterministic given fixed vectors, but embedding generation introduces variance through floating-point non-associativity and precision format effects. ReproRAG (arXiv:2509.18869) found FP32 embeddings achieve perfect run-to-run reproducibility while BF16 introduces drift. OpenAI community reports show consecutive embedding API calls yielding cosine similarity of only ~0.968 rather than 1.0. The appropriate SLA is threshold-based: "similarity > 0.85 = match."

**Non-deterministic gates (statistical SLA only)** include LLM-as-judge evaluation, LLM classification, and NeMo Guardrails' canonical form generation. Khatchadourian et al. ("Replayable Financial Agents," arXiv:2601.15322, 2025) found across 4,700+ agentic runs that **decision determinism and task accuracy are uncorrelated (r = -0.11, p = 0.63)**. Swept AI argues bluntly that "stacking homogeneous probabilistic checks simply increases the number of points that can fail in the same way." SLAs should be statistical (e.g., "85%+ factuality score across 3 evaluations") with threshold-based regression gates requiring baseline calibration data.

**Best practice across sources:** Layer deterministic checks first (sub-millisecond, free), then ML classifiers (~50ms), then LLM-as-judge only for qualitative dimensions code cannot measure (~1-30s, $1-3 per evaluation suite). The "Blueprint First, Model Second" framework (arXiv:2508.02721, 2025) formalizes this: a deterministic engine executes a code-defined blueprint, invoking LLMs only at specific nodes for bounded sub-tasks.

---

## 3. Deterministic replay requires recording, not re-executing

Agent runs **cannot be reproduced by re-execution** due to the non-determinism documented above. However, they **can be faithfully replayed** using record-replay techniques that capture and substitute all non-deterministic inputs during playback — a pattern borrowed from decades of distributed systems research.

Docker's Cagent runtime (April 2026) implements a **proxy-and-cassette model**: recording mode captures full LLM request/response pairs as YAML cassettes; replay mode blocks all external calls and matches requests against recorded responses. If execution diverges, the run fails deterministically. This directly parallels `vcr.py` in integration testing. The Sakura Sky primitives series (Andrew Stevens, November 2025) defines the required architecture: append-only JSONL event logs capturing LLM calls, tool calls, decisions, model parameters, and timestamps, with event-type-specific cursors and exhaustion detection during replay.

AgentRR (Feng et al., arXiv:2505.17716, May 2025) introduces a three-phase Record → Summarize → Replay framework with multi-level abstraction (low-level action sequences, mid-level procedural knowledge, high-level strategies) and "check functions" as trust anchors. LangGraph's Time Travel feature provides checkpoint-based state persistence enabling inspection of intermediate states and forking from any checkpoint. Temporal.io's durable workflow orchestration (used by OpenAI's Codex web agent and Replit's Agent 3) naturally provides replay via event sourcing — workflows are "deterministic in execution" even though "not predetermined."

The conceptual mapping from classical record-replay literature is exact. Liblog (Geels et al., USENIX '06) and Friday (Geels et al., NSDI 2007) logged non-deterministic system calls for distributed application replay. DCR: Datacenter Replay (Altekar & Stoica, UC Berkeley) recorded only control-plane I/O for low-overhead replay. The rr debugger provides practical user-space record-replay. In all cases: **system calls → LLM API calls; thread scheduling → agent task ordering; I/O → tool responses.** The agent replay problem is a solved architectural pattern; what's new is applying it to LLM inference outputs.

**Implication for Stoke:** Every non-deterministic boundary (LLM responses, tool outputs, timestamps, random seeds) must be captured at record time. Replay substitutes these captured values rather than re-invoking the LLM. The orchestration logic between these boundaries should be kept deterministic.

---

## 4. Compliance frameworks demand per-tool-call logging with workflow correlation

The **EU AI Act Article 12** requires high-risk AI systems to "technically allow for the automatic recording of events (logs) over the lifetime of the system," with sufficient detail for "full reconstructability of algorithmic decisions." Article 19 mandates minimum **6-month retention** of automatically generated logs; Article 18 requires **10 years** for technical documentation. Draft harmonized standards EN 18229-1 and ISO/IEC DIS 24970:2025 are developing specific guidance for implementing these provisions.

**NIST SP 800-53 Rev 5** defines 16 controls in the Audit and Accountability (AU) family. AU-3 requires recording event type, timestamp, location, source, outcome, and identity. AU-9 mandates protection from unauthorized modification or deletion. AU-10 (high baseline only) requires non-repudiation with "irrefutable evidence of actions." The CSA's NIST AI RMF Agentic Profile (March 2026 draft) identifies four structural gaps in AI RMF 1.0 for agents: no autonomy tier concepts, no tool-use risk model, **insufficient runtime monitoring** (MEASURE was designed for periodic review, not continuous telemetry), and no delegation/oversight boundary framework.

**ISO/IEC 42001:2023** (the first international AI management system standard) control A.6.2.8 requires "tamper-evident, lifecycle-mapped, fully auditable event trails across every stage of AI system lifecycle." SOC 2 Type II audits increasingly require AI-specific audit trails demonstrating explainability for automated decisions, with typical **12-month** log retention.

Multiple industry sources converge on a clear hierarchy of logging insufficiency:

- **Per-API-call logging** (infrastructure level): Captures HTTP status codes but not what data was accessed or why. Insufficient.
- **Per-model-invocation logging** (inference level): Captures prompts and outputs but not tool interactions, policy evaluations, or data lineage. Insufficient.
- **Per-tool-call logging** (recommended minimum): Captures tool name, inputs/outputs, orchestration steps, routing decisions, errors/retries.
- **Per-workflow/task logging** (recommended ideal): Links all actions to a single originating task via correlation ID, including authorization events, credential scopes, and all subsequent actions.

A critical gap identified by Waxell AI: "Most logging implementations capture inputs and outputs at the API call level. They don't capture the full context window — the accumulated history, the system prompt, the tool results that formed the decision context." Each model invocation is stateless; a single agent task can span 5–15 discrete API calls across different services. Without a workflow-scoped correlation ID, these appear as unrelated events.

---

## 5. Tool calling reproducibility is unmeasured but almost certainly poor

There is a **notable absence of published studies specifically measuring run-to-run reproducibility of LLM tool calls** — whether the same prompt with the same tools produces the same function name and arguments at temperature=0. The Berkeley Function-Calling Leaderboard (Patil et al., ICML 2025) evaluates accuracy across 2,000+ test pairs but does not measure variance across repeated identical requests. This is a significant gap in the literature.

The closest quantitative evidence comes from Johnson et al. (arXiv:2510.14453, October 2025), who evaluated 10 models across **6,400 trials** and found structured JSON tool calling has a mean accuracy of 69.1% with **variance of 0.0411 (SD = 20.28 percentage points)** — substantial variability. Their proposed Natural Language Tools approach reduced variance by 70% but still showed measurable inconsistency. Per-model data shows even GPT-5's structured tool calling has variance of 0.0020, and DeepSeek V3 shows variance of 0.023.

Since tool calls are generated via the same token-by-token process as regular text, **all sources of non-determinism from Question 1 apply equally**: batch invariance failure, MoE routing interference, floating-point non-associativity, and infrastructure-level changes. The KDD 2025 survey on LLM agent evaluation (arXiv:2507.21504) notes explicitly: "LLM agents are inherently stochastic; measuring consistency requires executing the same task multiple times." The τ-benchmark uses a **pass^k metric** specifically to capture this variance.

Tool calling introduces additional failure modes beyond text generation: parameter mis-filling, format errors, contextual failures (documented in HiTEC, arXiv:2506.00042), and the compound effect of multi-step tool chains where variance accumulates. ToolPRM (arXiv:2510.14703) proposes fine-grained beam search with process reward models for function calling, implicitly acknowledging single-pass unreliability.

**Implication for Stoke:** Tool call outputs should be treated as non-deterministic and logged with full input/output capture. For critical operations, consider multi-sample consensus (invoke the tool call N times and verify agreement) or constrained decoding that restricts the output space to valid function signatures.

---

## 6. Merkle tree logs are the gold standard, and agent-specific implementations are emerging rapidly

The foundational pattern is **RFC 6962 Certificate Transparency** (Laurie, Langley, Kasper; Google, 2013; superseded by RFC 9162). CT defines append-only Merkle trees with Signed Certificate Timestamps (promises of inclusion), Signed Tree Heads (commitments to tree state), Merkle Audit Proofs (O(log n) inclusion verification), and Consistency Proofs (append-only extension verification). This model powers the entire modern verifiable-log ecosystem.

**Trillian** (Google, open source) generalizes CT into a reusable verifiable data store with Log mode (append-only Merkle tree) and Map mode (sparse Merkle tree). Its "personality layer" allows domain-specific admission criteria — directly extensible to agent action validation. **SCITT** (IETF draft-ietf-scitt-architecture-22, October 2025) provides the supply chain integrity architecture using COSE-signed statements with Merkle tree inclusion receipts, explicitly designed for extensibility beyond supply chains. The community is already exploring SCITT for AI governance (UN AI for Good Summit, July 2024).

Crosby & Wallach (USENIX Security 2009, "Efficient Data Structures for Tamper-Evident Logging") improved on linear hash chains with **history trees** providing O(log n) proofs in an untrusted-logger model. Buldas et al. (2014, ePrint 2014/552) contributed record-level keyless signatures enabling individual record verification without exposing other records.

Agent-specific implementations are proliferating in 2025–2026:

- **Agent Receipts** (MCP integration): Ed25519-signed, content-hashed, chain-linked action proofs with 14 verification tools
- **Sigil Notary**: Python library with hash-chain accountability layer; each agent gets an Ed25519 key pair
- **ArkForge Trust Layer**: Certifying proxy pattern — Agent → Verification Proxy → API, producing cryptographic receipts for transparency logs
- **Eliza TEE Log Plugin**: TEE-secured logging for autonomous agents with Intel SGX/TDX remote attestation
- **EQTY Lab Verifiable Compute**: End-to-end framework using Intel TDX and NVIDIA H100 confidential computing producing persistent "AI Certificates"
- **VeritasChain Protocol v1.1**: Applies RFC 6962 principles to AI trading logs with three-layer integrity (per-event hashing, Merkle batch commitment, external Bitcoin anchoring) and **completeness guarantees** detecting event omission

Amazon QLDB demonstrated market demand for centralized verifiable ledgers but was **discontinued July 2025**, underscoring the importance of building on open standards rather than proprietary services.

---

## 7. Agent identity requires a composite fingerprint, not a single identifier

No single attribute suffices for agent identity. The emerging consensus is a **composite identity** combining persistent identifiers, cryptographic credentials, model metadata, and configuration state.

**OpenID Foundation's "Identity Management for Agentic AI" whitepaper** (Dean H. Saxe et al., October 2025) provides the most authoritative framework, covering agent protocols (MCP), dynamic client registration, delegated authorization, transitive trust, and scalable human governance. **Microsoft Entra Agent ID** treats agent identities as first-class constructs with Zero Trust Conditional Access, lifecycle management, and access reviews — "all authentication and actions performed by agents are logged in Microsoft Entra ID." SailPoint's Agent Identity Security aggregates AI agents across cloud platforms with unique identifiers tied to ownership data.

The **Dock.io framework** identifies three core elements: (1) a unique persistent identifier (DID), (2) cryptographic proof of legitimacy (credentials not tampered with), and (3) explicitly delegated authority scope. The **Know Your Agent (KYA)** pattern assigns every agent a unique ID tied to a human owner with lifecycle tracking.

For model-level identity, provider approaches differ. OpenAI returns a `system_fingerprint` representing backend configuration, but community reports show fingerprints change unpredictably and return `None` for older models. Anthropic provides **stable snapshot identifiers** (e.g., `claude-sonnet-4-5-20250929`) that "will never change once released" alongside rolling aliases — explicitly designed for audit trails. The recommended audit identity record should include:

- **Persistent agent ID** (DID or UUID, registered in organizational identity system)
- **Model snapshot version** (e.g., `claude-sonnet-4-5-20250929`, not a rolling alias)
- **System prompt hash** (SHA-256 of the full system prompt)
- **Tool configuration hash** (tools enabled, versions, parameters)
- **Infrastructure fingerprint** (GPU type, driver version, inference framework version)
- **Owner/principal attribution** (traceable to a human accountable party)

The **EU AI Act Article 49** requires providers to register high-risk AI systems with "any additional unambiguous reference allowing the identification and traceability of the AI system." **AI Bills of Materials (AIBOM)** extend SBOMs to AI: SPDX 3.0 introduced formal AI/Dataset profiles, CycloneDX v1.6 includes ML-BOM capabilities, and OWASP launched a dedicated AIBOM project with 10 strategic workstreams. IBM's Granite 4.0 pioneered machine-readable JSON metadata for model cards, enabling programmatic identity comparison.

---

## 8. Decision attribution requires structural separation at the architecture level, not post-hoc analysis

Distinguishing "model decided X" from "user instructed X" is an open problem in both philosophy and engineering. Zeiser (2024, Science and Engineering Ethics, 30(4):27) formalizes the **"attributability gap"**: AI decision-support tools make it difficult to identify the moral agent behind value-judgments, creating a distinction between accountability (who is blamed) and attributability (whose values the decision reflects). The risk of "rubber-stamping" — where human oversight becomes ceremonial — is well-documented (Wagner, 2019).

Qi et al. (arXiv:2411.03275, 2024) present a causal framework using **Structural Causal Models** to attribute responsibility in human-AI systems, employing counterfactual reasoning to measure blameworthiness while accounting for epistemic levels. Their key finding: human-in-the-loop approaches improve efficiency but introduce risks when AI is overconfident. A 2025 study in Nature Scientific Reports (588 participants) found responsibility attribution is **dynamic**: prior knowledge of the AI agent shifts responsibility toward the agent and its developer, and perceived importance of the decision further increases developer accountability.

The **EU AI Act Article 14** mandates that human overseers of high-risk AI systems must be enabled to "correctly interpret outputs" and "decide, in any particular situation, not to use the high-risk AI system or to otherwise disregard, override or reverse" its output. Fink (2025, SSRN:5147196) warns this requirement provides little detail on actual implementation, risking reduction to box-ticking.

For practical implementation, ElixirData's **Decision Traces** concept distinguishes between event logs (which capture system events but not reasoning) and Decision Traces (which record full provenance). The recommended audit record structure should include an explicit **operator field** distinguishing "human-in-the-loop" from "autonomous," an **approval status** (APPROVED_HUMAN, APPROVED_AUTO, PENDING_REVIEW), and a complete **instruction chain** tracing system prompts → user messages → model reasoning → tool calls → human overrides. Each decision record should capture: who made the decision (system ID, model version, operator classification), what was decided (action, inputs, outputs, confidence), why (evidence chain with policy references), and cryptographic proof (timestamp, content hash, chain hash).

An MDPI 2025 paper on blockchain-based AI decision provenance demonstrates logging every AI inference to a permissioned ledger with model ID, inputs, outputs, and cryptographic signatures — aligned with both EU AI Act and GDPR transparency requirements. The key architectural principle: **decision attribution must be built into the execution path, not reconstructed from logs after the fact.** If the system cannot distinguish instruction-following from autonomous decision-making at execution time, no amount of post-hoc analysis will reliably recover this distinction.

---

## 9. Design for the longest applicable retention period and tier aggressively

Compliance retention requirements vary dramatically across frameworks:

| Framework | Retention period | Storage requirements |
|-----------|-----------------|---------------------|
| **SOX** | 5–7 years | WORM storage, tamper-proof, executive certification |
| **HIPAA** | 6 years | ePHI access logs, from creation or last effective date |
| **SEC Rule 17a-4** | 3–6 years | WORM format, secondary location copy, prompt electronic access |
| **EU AI Act** | 6 months (logs) / 10 years (technical documentation) | Automatic recording, accessible to authorities |
| **SOC 2** | ~12 months | Security event logs with documented retention policies |
| **GDPR** | No fixed period | Storage limitation principle — keep only as long as necessary |
| **PCI DSS 4.0** | 12 months | 3 months immediately available for analysis |

When multiple frameworks apply, **use the longest required period**. A healthcare organization processing payments needs 6 years minimum (HIPAA). Financial services firms need 7 years (SOX). The EU AI Act's 10-year technical documentation requirement applies to system architecture and model documentation, not individual inference logs.

The **Write-Ahead Log (WAL) pattern** maps naturally to agent audit: every agent state change is logged before execution, enabling full state reconstruction on crash. This is the standard in databases (PostgreSQL WAL, MongoDB oplog) and message systems (Kafka's log-is-the-system architecture). For agent systems, each tool call or decision is a "transaction" that must be committed to the audit log before proceeding.

**Log-Structured Merge Trees** provide the write-throughput characteristics needed for high-volume agent logging. Writes buffer in an in-memory memtable, flush to immutable Sorted String Tables, and compact via background merges. For compliance, compaction must preserve all entries (reorganize for query efficiency, never delete), distinguishing this from operational log compaction.

**Tiered storage** is essential for cost management. The recommended pattern: hot storage (0–3 months, full-text search, ~$25/GB/year), warm storage (3–12 months, compressed, reduced query frequency), cold/archive (1–7+ years, ~90% cheaper, acceptable retrieval latency). AWS CloudTrail Lake offers 1-year ($0.75/GB) and 7-year (tiered from $2.50/GB) retention options. S3 lifecycle policies automate transitions to Glacier and Deep Archive. GDPR tension with immutable logs is resolved through **crypto-shredding** — encrypt personal fields with keys that can be destroyed, preserving audit structure while satisfying erasure rights — or irreversible anonymization after operational need expires. The CSA Agentic Profile explicitly requires preserving complete audit log history through agent decommissioning.

---

## 10. Forward integrity is necessary but not sufficient — agent-specific threats require layered defense

The foundational defense is **forward integrity**, defined by Bellare & Yee (1997, UC San Diego): if a machine is compromised at time Tc, all log entries committed before Tc cannot be modified without detection. The mechanism uses evolving MACs where each key Ki is derived from Ki-1 via a one-way function, with old keys deleted after evolution. Schneier & Kelsey (USENIX Security 1998, ACM TISSEC 1999) extended this with linear hash chains linking the entire audit log: Cn = H(Cn-1 || Xn).

However, Ma & Tsudik (IEEE S&P 2007) identified **two fundamental attacks** against these schemes: the **delayed detection attack** (a semi-trusted verifier is tricked into accepting a modified log) and the **truncation attack** (deleting entries from the tail, undetectable by linear chain verification). LogCrypt (Holt, 2006) extended to public-key verification but remained vulnerable to truncation. Crosby & Wallach's history trees (USENIX Security 2009) address this with O(log n) Merkle proofs in an untrusted-logger model. Critically, a 2024 security analysis of systemd's journald log sealing (KIT Bibliothek) discovered that its forward integrity implementation was **completely broken** — allowing forging of arbitrary past entries — demonstrating the gap between cryptographic theory and actual deployment.

**Forward-secure sequential aggregate signatures** (FssAgg) represent the state of the art: Ma & Tsudik's scheme aggregates signatures across time intervals into constant-size signatures while providing forward security, stream security, and integrity against insertion/modification/deletion. Hartung et al. (ProvSec 2017) added fault tolerance — tolerating bounded manipulated entries while maintaining truncation security with provable guarantees.

**TEE-based logging** provides hardware-rooted trust. Sinha et al. (Trust 2014) used TPM 2.0 monotonic counters for tamper-proof logging that works across system restarts with formal verification. The Eliza TEE Log Plugin uses Intel SGX/TDX with remote attestation. EQTY Lab's Verifiable Compute framework combines Intel TDX with NVIDIA H100 confidential computing for near-zero performance overhead. Chun et al.'s **Attested Append-Only Memory (A2M)** (ACM SIGOPS 2007) and Levin et al.'s **TrInc** (NSDI 2009) use minimal trusted hardware to prevent equivocation — showing different log views to different parties.

Agent-specific threats are documented in CSA's **MAESTRO framework** (February 2025), which identifies memory poisoning via log file tampering as a confirmed practical attack causing measurable performance degradation. The ATFAA/SHIELD framework (arXiv:2504.19956, April 2025) maps 9 threats including goal/objective manipulation, agent memory corruption, and **oversight saturation attacks** that overwhelm monitoring systems. Paccagnella et al. (ACM CCS 2020) demonstrated race condition attacks that subvert audit frameworks even with cryptographic protections by exploiting timing vulnerabilities in the logging pipeline itself.

The recommended defense hierarchy for Stoke, in increasing strength: (1) hash chains for basic tamper evidence, (2) Merkle trees for efficient third-party verification, (3) forward-secure aggregate signatures for space-efficient forward integrity, (4) TEE-based logging for hardware trust root, (5) external timestamping/anchoring for independent verification, and (6) BFT log replication for multi-party resilience against compromised nodes.

---

## Conclusion

Building Stoke as compliance-grade audit infrastructure requires accepting a fundamental asymmetry: **LLM inference is irreducibly non-deterministic, but the audit layer wrapping it can be fully deterministic and cryptographically verifiable.** The research converges on several non-obvious insights that should shape architecture decisions.

First, the primary source of LLM non-determinism is not sampling but batch invariance failure and MoE routing — meaning even self-hosted models at temperature=0 with fixed seeds will produce different outputs depending on server load. Response caching, not parameter tuning, is the correct engineering response.

Second, the replay problem is solved: record all non-deterministic outputs (LLM responses, tool results, timestamps) and substitute them during replay, following 20 years of distributed systems research. Docker Cagent and the Sakura Sky primitives show this works in practice today.

Third, compliance frameworks are converging toward demanding **per-tool-call logging with workflow correlation** — the EU AI Act's "full reconstructability" requirement, NIST 800-53's AU-3 content requirements, and ISO 42001's tamper-evident lifecycle trails all point to this granularity. The CSA's Agentic NIST AI RMF Profile explicitly identifies continuous runtime telemetry as a gap in current standards.

Fourth, the most dangerous threat is not external attackers but **agents manipulating their own logs** — memory poisoning is confirmed as a practical attack in the MAESTRO framework. This mandates that the logging layer must be architecturally separated from the agent's execution environment, with TEE-backed write paths and external anchoring providing the strongest guarantees.

Finally, agent identity is not a solved problem but composite identities (persistent ID + model snapshot + system prompt hash + tool config hash + owner attribution) combined with AIBOM standards provide a practical path forward that satisfies both EU AI Act registration requirements and forensic needs.