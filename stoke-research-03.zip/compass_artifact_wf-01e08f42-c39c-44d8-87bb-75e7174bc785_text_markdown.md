# Replanning in AI coding agents: what the research actually shows

**The most important finding across dozens of papers is counterintuitive: iterative self-repair is usually less effective than generating diverse initial attempts.** The landmark ICLR 2024 paper by Olausson et al. demonstrated that spending compute on many independent code samples with one repair pass each outperforms deep iterative debugging of a single solution — sometimes by significant margins. A Nature-published study (Adnan & Kuhn, 2025) quantified the mechanism: LLM debugging effectiveness decays exponentially, with **60–80% of capability lost within 2–3 attempts**. This means the "replan" question is less about *how* to retry and more about *when to stop*. The evidence converges on a practical ceiling of 2–3 repair iterations before a fresh start or human escalation becomes the rational choice.

This report synthesizes peer-reviewed research, vendor documentation, and practitioner observations across 10 dimensions of replanning in AI coding agents. Every claim is tagged with its provenance — peer-reviewed paper, preprint, vendor claim, or community observation — so readers can calibrate their confidence accordingly.

---

## 1. The research landscape on replanning mechanisms

Seven major systems define the published landscape, each with a fundamentally different approach to what happens after failure.

**ReAct** (Yao et al., "ReAct: Synergizing Reasoning and Acting in Language Models," ICLR 2023, peer-reviewed) interleaves reasoning traces and actions in a Thought → Action → Observation loop. Replanning is *implicit* — when observations surprise the agent, the next Thought can reformulate the plan. There is no separate replanning module. ReAct was not evaluated on coding tasks directly, but its pattern underlies most production coding agents. On ALFWorld, ReAct outperformed RL methods trained on 10³–10⁵ instances by **34% absolute**.

**Reflexion** (Shinn et al., "Reflexion: Language Agents with Verbal Reinforcement Learning," NeurIPS 2023, peer-reviewed) is the only system with a truly *explicit* replanning mechanism for coding. It uses three models — an Actor, an Evaluator, and a Self-Reflection model — where failure triggers verbal analysis stored in an episodic memory buffer that conditions subsequent attempts. On HumanEval Python, Reflexion achieved **91% pass@1** versus GPT-4's 80% baseline, meaning **55% of previously-failing tasks were solved** through self-reflection. The critical caveat: Reflexion's effectiveness is bounded by self-generated test quality, with a **16.3% false-positive rate on MBPP** that actually degraded performance below baseline.

**Tree of Thoughts** (Yao et al., "Tree of Thoughts: Deliberate Problem Solving with Large Language Models," NeurIPS 2023, peer-reviewed) enables *structural replanning* through tree search with backtracking. Rather than reacting to failure, ToT proactively explores multiple reasoning paths, evaluates them, and abandons unpromising branches. On Game of 24, this achieved **74% success versus 4% for chain-of-thought** — an 18.5× improvement. Not evaluated on coding, but the backtracking principle is architecturally relevant.

**AlphaCode** (Li et al., "Competition-Level Code Generation with AlphaCode," *Science* 378:1092–1097, 2022, peer-reviewed) does not replan at all. It generates up to **one million code samples**, filters by test execution (~95% eliminated), clusters by behavioral similarity, and submits representatives from the top 10 clusters. This is parallel exploration with post-hoc selection — brute-force rather than reflection. AlphaCode 2 (DeepMind technical report, December 2023) achieved **85th percentile** on Codeforces with ~10,000× better sample efficiency using a Gemini-based scoring model.

**SWE-agent** (Yang et al., "SWE-agent: Agent-Computer Interfaces Enable Automated Software Engineering," NeurIPS 2024, peer-reviewed) introduced the Agent-Computer Interface (ACI) concept. Its replanning is implicit: when edits fail, informative error messages from the ACI allow the LLM to adjust. The paper's key insight is that **interface design matters more than explicit replanning architecture** — good error messages enable natural recovery. Achieved **12.5% on SWE-bench** at submission; later versions with Claude 3.7 reached state-of-the-art.

**OpenHands/OpenDevin** (Wang et al., "OpenHands: An Open Platform for AI Software Developers as Generalist Agents," arXiv 2407.16741, 2024, preprint) is a platform, not a single agent. Its CodeActAgent operates through an event stream architecture where execution feedback drives implicit replanning. Multi-agent delegation provides a form of plan decomposition. Achieved **26% on SWE-bench Lite** with Claude 3.5 Sonnet.

**mini-SWE-agent** (Princeton/Stanford team, open-source, 2025) is deliberately minimal — approximately **100 lines of Python** with no explicit replanning, no tools, and no verification scaffolds. All error recovery is delegated entirely to the LLM's own reasoning. Despite this minimalism, it achieved **>74% on SWE-bench Verified** with Claude Sonnet 4, matching far more complex systems. This result suggests a trend: as base models improve, explicit replanning scaffolding becomes less necessary.

Two comprehensive surveys synthesize this landscape: Wang et al.'s "A Survey on Large Language Model based Autonomous Agents" (*Frontiers of Computer Science*, 2024, peer-reviewed) and Huang et al.'s "Understanding the Planning of LLM Agents: A Survey" (arXiv 2402.02716, preprint), which provides a taxonomy covering task decomposition, plan selection, reflection, and memory.

---

## 2. Empirical success rates follow exponential decay

The probability of successful repair after failure is measurable, and the data tells a consistent story: **early retries help substantially, but returns diminish fast**.

The most rigorous per-attempt data comes from several peer-reviewed sources. The Reflexion paper (NeurIPS 2023) showed GPT-4 improving from 80% to 91% on HumanEval through iterative self-reflection — meaning roughly **55% of initial failures were eventually resolved**. On AlfWorld, success climbed from 75% to 97% across 12 trials, with the largest jump between trials 1 and 2. On HotPotQA, most gains arrived in the first 3–4 trials before plateauing.

The **pass@k** metric from the Codex paper (Chen et al., "Evaluating Large Language Models Trained on Code," 2021) provides the clearest data on independent sampling. Codex-12B achieved pass@1 = 28.8%, pass@10 = 46.8%, and pass@100 = 72.3% on HumanEval. Converting to conditional probabilities: **P(solve in 10 attempts | failed at 1) ≈ 25.3%**, and P(solve in 100 | failed at 10) ≈ 47.9%. Critically, pass@100 was only 72.3% — far below the ~99.99% that independent 28.8% trials would predict — revealing a hard capability ceiling per problem.

The self-repair literature adds crucial nuance. Olausson et al. ("Is Self-Repair a Silver Bullet for Code Generation?," ICLR 2024, peer-reviewed) found that for GPT-4 on APPS, the optimal configuration was **10 initial samples with 1 repair each** (1.05× improvement over baseline), while **2 initial samples with 10 repairs each actually performed worse** (0.97×) than pure sampling. The repair success rate was **33.3% with self-generated feedback** and **52.6% with human feedback**. Their conclusion: "The diversity of base samples generated up-front [is more important] rather than the diversity of the repairs."

Chen et al. ("Teaching Large Language Models to Self-Debug," ICLR 2024, peer-reviewed) found that **successful debugging almost always concludes within 3 turns** despite allowing up to 10. On MBPP, self-debugging improved the baseline by up to 12%. Jiang et al. (Amazon, 2024) showed that untrained models plateau quickly: "After three rounds, the prompting approach fails to match pass@k achieved by SFT after just the first round."

The **Debugging Decay Index** paper (Adnan & Kuhn, "Measuring and Mitigating Debugging Effectiveness Decay," *Nature Scientific Reports*, 2025, peer-reviewed) formalized this decay as E(t) = E₀ × e^(−λt), finding that models with rapid decay (λ > 1.0) exhaust their debugging capacity within **1–2 iterations**. The paper proposes strategic fresh starts at calculated intervention points.

Vendor data from Verdent AI (blog post, November 2025, not independently verified) showed SWE-bench Verified improving from pass@1 = 76.1% to pass@3 = 81.2% — meaning only **~21% of first-attempt failures were resolved** in two additional attempts. Warp Terminal (blog post, 2025) found that same-model retries "often produced repeat failures" and switched to model fallback chains instead.

The overall picture: **P(success | previous failure) is typically 15–35% per attempt** for feedback-based repair, decaying with each subsequent try. The optimal strategy is wide-then-shallow: many diverse initial attempts with at most one repair pass each.

---

## 3. A taxonomy of recoverable versus unrecoverable failures

Published failure analyses reveal three distinct categories with different replanning potential, based primarily on the SWE-agent failure analysis (NeurIPS 2024) of 248 unresolved trajectories on SWE-bench Lite.

**Recoverable via replanning** (~40–50% of failures) includes cascading edit failures (23.4% of SWE-agent failures), where a single bad edit compounds into subsequent errors — recovery probability drops from 90.5% to 57.2% after one failed edit, but lint-based guardrails substantially help. Overly specific implementations, wrong fault localization (Agentless shows file-level hit rates of 68–85%), syntax and formatting errors (especially common in smaller models), and tool-use errors all fall here. The SWE-PRM taxonomy (Gandhi et al., CMU/IBM, NeurIPS 2025 submission) specifically identifies action looping, redundant exploration, and failure to terminate as correctable inefficiencies, achieving **+10.6 percentage points** on SWE-bench Verified through corrective feedback.

**Requirements misunderstanding** (~15–25% of failures) includes instruction-following failures — the dominant failure mode for *strong* models on harder benchmarks like SWE-EVO, where the agent misinterprets nuanced task specifications. The Agentless team (UIUC) found that **9.3% of SWE-bench Lite issues lack sufficient information** (fundamentally unsolvable) and 4.3% have misleading instructions incompatible with the gold patch. These failures are unrecoverable without external clarification.

**Beyond model capability** (~25–35% of failures) includes semantic and algorithmic correctness failures on complex multi-file edits (the primary failure mode for frontier models like Opus 4 on SWE-Bench Pro), problems requiring deep cross-codebase understanding, and enterprise-scale complexity. SWE-Bench Pro (Scale AI, 2025) shows performance below 45% even for the best models, with resolution rates dropping to **<25% on the hardest tasks**. OpenAI's audit found that **59.4% of "hard" SWE-bench problems had flawed test cases** rejecting correct solutions — meaning some failures reflect benchmark artifacts, not model limitations.

The MAST taxonomy (Cemri et al., UC Berkeley, 2025, under review) provides a complementary framework for multi-agent systems: system design issues account for 41.8% of failures, inter-agent misalignment for 36.9%, and task verification failures for 21.3%. The AgentErrorTaxonomy (Zhu et al., UIUC, 2025) found that error propagation is the central bottleneck — **most failures cluster in mid-trajectory steps (6–15)** where early missteps cascade.

---

## 4. How production coding agents actually handle replanning

Every major production coding agent uses fundamentally the same pattern — **a tool-use loop where failure outputs feed back to the LLM** — but they diverge in sophistication around context management, safety rails, and escalation.

**Cognition's Devin** operates as a compound AI system with a cloud-based "Brain" and sandboxed "Devbox." Its plan-edit-test loop iterates autonomously until tests pass. Key differentiators include fork-and-rollback capabilities (branching from any session state), a knowledge management system that codifies feedback into reusable Playbooks, and dynamic replanning without human intervention. Third-party sources (unconfirmed by Cognition) describe a multi-model architecture: Planner, Coder, Critic, and Browser models. PR merge rate reportedly improved from **34% to 67%** over 2025 (vendor claim). No documented max retry count — the system iterates until success or user intervention.

**Cursor's Agent Mode** follows an Analyze → Search → Plan → Execute → Verify → Auto-fix loop. When linter or compile errors appear after edits, it enters an automatic fix loop. Plan Mode (Shift+Tab) creates explicit, editable Markdown plans before execution. Version 2.0 introduced **up to 8 parallel agents** using Git worktree isolation — each in a separate worktree with independent undo. Git checkpoints before every change enable rollback. No documented max retry limit.

**Claude Code** (Anthropic) uses a deliberately simple single-threaded master loop: `while(tool_call) → execute tool → feed results → repeat`. Failure becomes just another observation. Context compression triggers automatically at ~92% window usage. A subagent system allows lightweight parallel research, while a "Teams" feature provides true parallelism via tmux panes. The SDK exposes `maxTurns` and cost limits for programmatic control. Community reverse-engineering identified circuit breakers preventing infinite retry loops. (Sources: official Anthropic documentation and community analysis of open-source Rust rewrite.)

**Replit Agent** evolved from a simple ReAct loop to a multi-agent architecture with a Manager, Editor agents, and a Verifier agent. The Verifier's distinctive behavior: rather than always pushing for autonomous resolution, it **frequently falls back to talking to the user** — a deliberate design choice prioritizing engagement over full autonomy. Replit generates Python DSL code for tool invocations (~90% success rate for valid calls, vendor claim), found more reliable than standard function-calling APIs.

**GitHub Copilot** spans three systems: Workspace (sunset May 2025) offered spec-driven replanning with editable specifications and plans; Agent Mode operates in VS Code with self-healing capabilities for compile/lint/runtime errors; Cloud Agent works autonomously in GitHub Actions with hook-based validation. Community reverse-engineering of copilot-cli reveals four modes: Default, Autonomous, Plan, and Fleet (parallel subagents).

**Amazon Q Developer** uses five specialized agents (/dev, /doc, /test, /review, /transform) with a "textcode" framework — a text-based IDE optimized for LLM token efficiency. It has **built-in logic to prevent unproductive loops** (vendor-confirmed), though details are undisclosed. Vendor claims highest SWE-bench scores (verified via public leaderboard submissions).

**Aider** (open-source) provides the most transparent architecture: auto-lint via tree-sitter AST parsing after every edit, optional auto-test loops, and an Architect mode using a stronger model for planning with a faster model for execution. A documented bug (GitHub issue #1090) reveals that **Aider can loop infinitely on unfixable lint errors** — no built-in max retry limit exists. This illustrates that even well-regarded tools have loop vulnerability.

---

## 5. Fresh starts outperform context accumulation more often than expected

The distinction between "replan" (discard context, start fresh) and "retry with context" (append failure information and continue) has significant empirical backing — and the data often favors fresh starts.

**Context contamination is real and measurable.** Chroma Research (2025, industry study) tested 18 frontier models and found that **every model's performance degrades as input context grows**, even well below maximum window size. The "lost in the middle" phenomenon (Liu et al., Stanford, 2023) shows **30%+ lower accuracy for information positioned in the middle of context**. Even a single distractor document reduces performance. Google DeepMind's Gemini 2.5 technical report identified "context poisoning" as a critical failure mode: hallucinations that enter context are "repeatedly referenced" and "take a very long time to undo."

**Self-bias amplifies through iteration.** Xu et al. ("Pride and Prejudice: LLM Amplifies Self-Bias in Self-Refinement," ACL 2024, peer-reviewed) tested 6 LLMs and found that self-refinement improves surface metrics like fluency but **amplifies self-bias** — the model optimizes for its own preferences rather than correctness. After 10 iterations, actual performance measured by BLEURT/human evaluation did *not* improve even as the LLM's self-estimated quality increased. External feedback from a separate evaluation model significantly reduced this bias.

Huang et al. ("Large Language Models Cannot Self-Correct Reasoning Yet," ICLR 2024, peer-reviewed) confirmed that **intrinsic self-correction without external signals sometimes degrades performance**. A complementary ACL Findings 2024 paper showed that LLMs are poor at *locating* their own errors but can correct them when oracle error locations are provided — implying that self-repair without external error signals is fundamentally limited.

Liang et al. (ACL 2024, peer-reviewed) formalized the **"Degeneration-of-Thought" (DoT)** problem: once an LLM has established confidence in a solution, it cannot generate novel thoughts through self-reflection even if the initial stance is incorrect. This means retry-with-context can actively lock the model into wrong reasoning paths.

The **Debugging Decay Index** paper (Nature, 2025) provides the most actionable guidance: after 2–3 failed repair attempts, a "strategic fresh start" at the DDI-calculated threshold rescues effectiveness without additional computational cost. Tang ("Code Repair with LLMs gives an Exploration-Exploitation Tradeoff," NeurIPS 2024, peer-reviewed) framed this as an explore-exploit tradeoff and found that **gains from refinement are marginal compared to repeatedly sampling i.i.d. programs**.

The practical synthesis: retry with external feedback (compiler errors, test results) for 1–3 attempts, then switch to a fresh start using *summarized lessons* (not full failed context) to guide the new attempt. Wholesale context accumulation is counterproductive.

---

## 6. Recovery strategy mappings exist but remain fragmented

No single comprehensive "failure → recovery" library exists, but several published systems come close.

**SWE-PRM** (Gandhi et al., CMU/IBM, "When Agents go Astray: Course-Correcting SWE Agents with PRMs," NeurIPS 2025 submission) is the closest published work to a systematic failure-recovery mapping. It pairs observed trajectory inefficiencies with corrective natural language feedback delivered in real-time. The taxonomy covers action looping, redundant exploration, drifting toward irrelevant subgoals, and failure to terminate. Applied to SWE-bench Verified, it boosted resolution from 40.0% to **50.6% (+10.6 percentage points)** at ~$0.20 additional cost per instance.

**ChatRepair** (Xia & Zhang, UIUC, ISSTA 2024, peer-reviewed) implements conversational repair by interleaving patch generation with test failure feedback. It correctly fixed **162 of 337 bugs (48.1%)** on Defects4J at $0.42 per bug. **RepairAgent** (Bouzenia et al., ICSE 2025, peer-reviewed) adds autonomous tool selection and explicit backtracking operations, achieving **164 correct fixes** on Defects4J. **Agentless** (Xia et al., UIUC, 2024) uses hierarchical localization → repair → validation, reaching 27.3–32.0% on SWE-bench Lite at $0.34–$0.70 per issue.

Domain-specific systems show dramatically higher recovery rates. **GradleFixer** (2025, preprint) achieves **81.4% pass@1** on Android build errors using domain-specific tools. An industrial CI study (2025, preprint) using CodeLlama resolved **63% of previously unrepairable C/C++ compilation errors**, with 83% of fixes deemed reasonable by developers. **RustAssistant** (Microsoft Research, 2023) achieved **73.6% fix rate** for Rust compilation errors with GPT-4.

The APR survey by Yang et al. (arXiv, June 2025) covers 62–63 LLM-based repair systems and identifies four paradigms — fine-tuning, prompting, procedural pipelines, and agentic frameworks — with cross-cutting augmentations from retrieval (RAG) and analysis (static/dynamic). The community-driven FAILURE.md open specification provides a structured protocol mapping four failure modes (graceful degradation, partial failure, cascading failure, silent failure) to specific response procedures including escalation rules.

---

## 7. What the major AI companies actually recommend

Anthropic, OpenAI, Google, and Meta take markedly different approaches to documenting agentic replanning — and **none provides specific numerical retry guidance in their model cards**.

**Anthropic's** system cards for Claude Opus 4, Sonnet 4, and others focus on safety evaluations in agentic contexts rather than developer guidance. The company's most actionable document is "Building Effective Agents" (research blog post), which recommends simplicity, transparency in planning steps, and an **evaluator-optimizer pattern** (generate draft → review against criteria → refine). It notes "stopping conditions (like maximum iterations) help maintain task control" but specifies no numbers. Claude 4 prompting documentation recommends "adaptive thinking" for agentic behavior and describes the self-correction chaining pattern as the "most common." Claude Code best practices suggest engineers "review the 80% complete solution before taking over for final refinements" — an implicit escalation heuristic.

**OpenAI** provides the most concrete technical implementation through the Agents SDK. The JavaScript SDK defaults to **20 steps** via `stepCountIs(20)`. The Python SDK exposes `max_turns` with a `MaxTurnsExceeded` exception. Built-in retry policies include exponential backoff with configurable `initial_delay`, `multiplier`, `max_delay`, and `jitter`. The GPT-4o system card notably acknowledges that the model **"often failed to pivot to a different strategy if its initial strategy was unsuccessful"** — a candid admission of replanning limitations. The OpenAI Model Spec (December 2025) establishes principles of caution and reversibility: "minimize and disclose irreversible actions, prefer reversible approaches."

**Google DeepMind** provides the most explicit recovery architecture discussion. The Gemini Deep Research documentation states: "A single failure doesn't mean having to restart the task from the beginning. We developed a **novel asynchronous task manager that maintains a shared state** between the planner and task models, allowing for graceful error recovery." Gemini 3 introduces "Thought Signatures" — encrypted representations of internal reasoning passed back through conversation history to prevent context loss during multi-step execution. Google also describes adjustable `thinking_level` parameters for calibrating reasoning depth per step.

**Meta** provides no meaningful guidance on agentic replanning. Llama model cards focus on safety (Llama Guard, Prompt Guard, Code Shield, LlamaFirewall) and note that models should be "deployed as part of an overall AI system with additional guardrails," leaving all recovery implementation to developers.

---

## 8. Degenerate loops are a fundamental unsolved problem

Agents getting stuck in loops — repeating the same wrong approach — is documented across research and practice as a critical failure mode without a fully satisfactory solution.

Three loop patterns emerge from the literature. **Same-action retry loops** are the simplest: the agent performs an identical action, gets the identical failure, and repeats. **Oscillation loops** involve alternating between two actions where each locally appears correct but no global progress occurs. **Replanning loops** are the most expensive: the agent generates entirely new plans that fail similarly, consuming context rapidly.

Dong et al. ("Rethinking Repetition Problems of LLMs in Code Generation," ACL 2025, peer-reviewed) conducted the first systematic study across **19 LLMs**, identifying **20 distinct repetition patterns**. Code repetition is **significantly more severe** than general text (rep-2 values: 9.1 for code vs. 3.92 for human text) because code's inherently repetitive nature (loops, API calls, variable reuse) exacerbates the problem. A production-focused study (arXiv 2512.04419, 2024) showed repetition can increase processing time by **43% to 471%**, with Markov analysis revealing that "once the model enters a repetitive state, the expected escape time is infinite" under greedy decoding.

At the agent reasoning level, the Degeneration-of-Thought problem (Liang et al., ACL 2024) shows that LLMs cannot generate novel approaches once committed to a direction. Multi-Agent Reflexion (Delarue et al., 2024, preprint) replicated this on HumanEval: "Self-reflections tend to repeat earlier misconceptions and do not introduce new reasoning paths on difficult examples."

Sinha et al. ("The Illusion of Diminishing Returns," arXiv 2509.09677, 2025) quantified the self-conditioning effect: models become more error-prone when context contains their own prior errors, and even the best model tested (Qwen3-32B) falls **below 50% accuracy within 15 turns**. Thinking/reasoning models mitigate self-conditioning and enable longer task execution.

**Detection heuristics** used in practice include step count limits, action signature matching (comparing new actions against prior ones), semantic similarity detection via lightweight embeddings, result similarity tracking, and progress metric monitoring. Major frameworks handle this differently: LangChain/LangGraph uses `max_iterations`; AutoGen has `max_consecutive_auto_reply`; CrewAI combines `max_iterations` per task with `max_execution_time` limits. However, **none ship with loop detection enabled by default** — developers must explicitly configure limits.

Breaking strategies include temperature manipulation (raising temperature when loops are detected to increase cognitive diversity), Strategy-Guided Exploration (sampling strategy tokens at higher temperature than action tokens; arXiv 2603.02045, 2025), multi-agent debate (forcing consideration of alternatives), loop-breaking prompt injection, and beam search for escaping token-level repetition. No single approach is definitively superior.

---

## 9. Per-failure recovery rates vary by an order of magnitude

Recovery effectiveness ranges from near-deterministic for some failure types to essentially zero for others. Published data exists for most categories, though coverage is uneven.

**Test failures** are the most studied category. Self-debugging achieves roughly **60% correct fix accuracy within 3 iterations** (Chen et al., ICLR 2024). The DDI paper (Nature, 2025) shows exponential decay thereafter. Strategy: retry with test error output for up to 3 attempts, then fresh-start regeneration.

**Build and compilation errors** have the strongest published recovery rates. Industrial CI studies show **63% pass rate** for CodeLlama on C/C++ build errors (2025, preprint), with 83% of fixes judged reasonable by developers. RustAssistant achieves **73.6%** for Rust compilation errors (Microsoft Research, 2023). GradleFixer reaches **81.4%** for Android-specific build failures (2025, preprint). An ETH Zurich PLDI paper found that **94% of LLM compilation errors are type-related**, not purely syntactic.

**Type errors** benefit from type-constrained decoding: the ETH PLDI 2025 paper (peer-reviewed) showed that constraining generation improved compilation error repair from ~30% to **56–58%** on HumanEval/MBPP — a **~54% relative improvement**. AgenticTyper (2025, preprint) resolved all 633 initial type errors in two proprietary repos (81K LOC) in 20 minutes.

**Dependency conflicts** have the weakest published recovery data. PhantomRun (2025, preprint) found only **31–38% pass rates** for dependency-related errors. No rigorous peer-reviewed study provides clear recovery rates. Industry data (Sonatype) suggests "AI is confident only 4% of the time when selecting safe, high-quality components." Strategy: escalate early to specialized tooling rather than LLM-based retry.

**Hallucinated imports** affect **19.7% of generated code samples** across 16 LLMs (Lasso et al., 2024, multi-university study of 576,000 samples). GPT-series models show 5.2% hallucination rates versus 21.7% for open-source models. No published recovery rate exists because the correct strategy is **detection and regeneration**, not iterative repair — hallucinated APIs are systematic, not stochastic errors. Registry/index verification provides near-deterministic detection.

**Scope creep/task drift** has been characterized (Brand et al., 2025, preprint: agents exhibit predictable quality degradation over conversation length, manifesting at 12+ turns) but **no published recovery rate exists**. The recommended approach is replan from the original specification, not retry — reset to original intent and re-derive remaining work.

**Secret/credential leaks** in AI-generated code occur at roughly **3.2% of AI-assisted commits** versus 1.5% baseline (GitGuardian, 2026, vendor report). Claude Code-assisted commits peaked at 31 leaked secrets per 1,000 commits before declining. The only correct strategy is **immediate halt, credential rotation, and regeneration with environment variable patterns**. Pre-commit scanning detection exceeds 95% for known patterns.

---

## 10. The optimal stopping point is around 3 attempts

The "time to give up" question has converging answers from multiple independent research threads, though no single definitive paper exists.

The **strongest empirical guidance** comes from the DDI framework (Adnan & Kuhn, Nature Scientific Reports, 2025): the exponential decay model E(t) = E₀ × e^(−λt) produces a per-model strategic stopping threshold tθ. For most models, **60–80% of debugging capability is lost within 2–3 attempts**. The Self-Debugging paper (ICLR 2024) independently found that success "mostly ends within 3 turns" out of 10 allowed. MapCoder (2024) limited to 5 attempts per plan out of 25 total.

The **Reset-and-Discard (ReD)** framework (Meir et al., arXiv 2601.21522, 2025) applies stochastic resetting theory from physics to LLM code generation. Key finding: pass@k follows a power-law with sublinear growth, meaning each additional attempt on the same problem buys less. ReD recommends the **optimal reset interval τ = 1** — abandon after every failed attempt and reallocate compute to a different problem or fresh approach. This converts sublinear coverage growth into linear growth, substantially reducing required attempts, tokens, and cost.

Sinha et al. (arXiv, 2025) showed that even frontier models fall below 50% accuracy within 15 turns due to self-conditioning, and that **marginal gains in single-step accuracy compound exponentially** for multi-step tasks: a 95% → 97% improvement in per-step accuracy can be the difference between completing 5 versus 30 steps.

Cost-benefit data remains sparse in peer-reviewed literature. Olausson et al.'s pass@t metric (ICLR 2024) accounts for token cost, showing self-repair roughly matches i.i.d. sampling for GPT-4 but is **actively worse for GPT-3.5** when costs are included. Practitioner guidance converges on hard limits: **max 3 retries per agent per workflow** (multiple independent sources), **max 25 total steps** per task, and explicit USD/token budgets. No peer-reviewed paper directly applies optimal stopping theory (secretary problem formalism) to LLM coding agents, though the ReD paper is the closest analog.

The practical escalation heuristic emerging from this evidence: **attempt repair 2–3 times with external feedback, then fresh-start once with summarized lessons, then escalate to human review**. For simple errors (syntax, type, build), allow up to 4 repair attempts. For semantic/logic errors, the ceiling is 2–3. For systematic errors (hallucinated APIs, dependency conflicts), escalate after 0–1 attempts.

---

## Conclusion: what this research means for building coding agents

The research reveals several findings that challenge common assumptions. First, **explicit replanning scaffolding is becoming less necessary** as base models improve — mini-SWE-agent's >74% SWE-bench performance with ~100 lines of code demonstrates this convincingly. Second, **the optimal retry strategy is wide-then-shallow** (many diverse initial attempts with at most one repair pass), not deep iterative debugging of a single solution. Third, **context accumulation often hurts more than it helps** — context contamination, self-bias amplification, and Degeneration-of-Thought are documented, peer-reviewed phenomena. Fourth, **no major AI company provides specific numerical guidance** on retry counts in their model cards; the most actionable implementation comes from OpenAI's Agents SDK (default 20 steps) and practitioner convergence around 3 retries per subtask.

The critical gap in the literature is the absence of a unified, empirically validated decision framework mapping failure type → recovery strategy → expected success probability → optimal stopping threshold. SWE-PRM, ChatRepair, and the DDI framework each address pieces of this puzzle, but no published work assembles the complete picture. For practitioners building coding agents today, the evidence supports a tiered approach: syntax and build errors warrant 2–4 automated retries; logic and test failures justify 2–3 attempts before fresh regeneration; and systematic failures like hallucinated APIs or dependency conflicts should trigger immediate strategy changes rather than repeated attempts.