# AI agent memory systems for coding orchestrators

**Accumulated memory measurably improves AI agent performance — Voyager achieved 15.3x faster task completion, Reflexion gained +14% accuracy, and Mem0 showed 26% higher scores — but only when noise is actively managed.** Without governance, memory quality can degrade by 85% over time. The architectural consensus across MemGPT, Zep, Mem0, Claude Code, ChatGPT, and Devin is converging on hybrid systems combining structured rules, vector search, and temporal metadata, though the optimal design depends heavily on the access patterns of coding-specific recall. This report synthesizes findings from 40+ papers, production systems, and practitioner reports to provide a practical architecture guide for Stoke.

---

## The seven published memory architectures follow three philosophical camps

Production AI agent memory systems cluster into three design philosophies: **active self-editing** (the agent manages its own memory via tool calls), **passive extraction** (a background system extracts memories automatically), and **brute-force context stuffing** (everything goes into every prompt).

**MemGPT/Letta** pioneered the OS-inspired approach where the LLM acts as its own memory manager. It maintains two tiers: in-context "core memory" (small editable text blocks always visible to the model) and out-of-context storage split between "recall" (searchable conversation history) and "archival" (vector-database-backed long-term storage via pgvector or Chroma). The agent autonomously decides when to read, write, and search via function calls like `archival_memory_insert` and `conversation_search`. When context fills, older messages are recursively summarized. This gives maximum flexibility but makes memory quality entirely dependent on model judgment — the Letta team acknowledges that "recursive summarization is inherently lossy and eventually leads to large holes."

**Zep** takes the opposite approach with a temporal knowledge graph built on Neo4j via its open-source Graphiti engine. Every fact is stored as a graph edge with bitemporal metadata — `valid_from`, `valid_to`, and `invalid_at` timestamps tracking both when events occurred and when they were ingested. Retrieval combines semantic search, BM25, graph traversal, and multiple rerankers (reciprocal rank fusion, maximal marginal relevance, node distance) with **no LLM calls during retrieval**, achieving P95 latency of ~300ms. On the DMR benchmark, Zep scored **94.8%** versus MemGPT's 93.4%.

**Mem0** occupies the middle ground with a two-phase pipeline: an extraction phase where an LLM distills atomic facts from conversations, followed by an update phase that compares each new fact against existing memories and decides to ADD, UPDATE, DELETE, or NOOP. It supports both vector stores (Qdrant, Pinecone, FAISS) and an optional knowledge graph layer. On the LOCOMO benchmark, Mem0 delivers **26% higher accuracy** than OpenAI's memory and **91% lower latency** than full-context approaches.

**ChatGPT's memory** is perhaps the most surprising architecture. Reverse-engineering by Shlok Khemani revealed that OpenAI uses **no vector databases, no RAG, no knowledge graphs** — it stuffs four data buckets (interaction metadata, ~40 recent conversations, user-saved memories, and AI-generated biographical summaries) into every prompt. This "bitter lesson" bet assumes models will get smart enough to ignore irrelevant context while context windows keep growing and costs fall. The hidden "User Knowledge Memories" layer — dense AI-generated summaries not visible or editable by users — creates accountability concerns.

**Claude Code** chose radical simplicity: plain Markdown files (`CLAUDE.md`) at global, project, and directory levels, loaded into context at session start. No vector search, no RAG. Its "Auto Dream" consolidation runs between sessions in four phases — orient, gather, merge, finalize — resolving contradictions, converting relative dates to absolute, and pruning stale entries. The file-based approach means memories are version-controllable alongside code.

**Devin** maintains the richest memory taxonomy for coding: a persistent Knowledge system (tips, conventions, organizational context recalled automatically), Playbooks (reusable task templates with context-procedure-specification structure), Machine Snapshots (saved environment states), and DeepWiki (auto-generated codebase documentation). The Nubank case study showed **4x performance improvement** after investing in detailed playbooks.

**LangChain** provides modular primitives (buffer, window, summary, entity, vector-store memories) that developers compose. Its newer **LangMem** library for LangGraph supports background memory management with automatic extraction and consolidation. The LangChain team found in building their Agent Builder that "the hardest part is prompting" — they dedicated one full-time person to memory prompt engineering.

| System | Paradigm | Retrieval | Conflict resolution | Transparency |
|--------|----------|-----------|-------------------|-------------|
| MemGPT/Letta | Active self-editing | Self-directed vector search | Agent must manually update | Full (open source) |
| Zep/Graphiti | Temporal knowledge graph | Semantic + BM25 + graph + rerankers | Automatic edge invalidation | Graphiti open source |
| Mem0 | Passive extraction | Vector + optional graph | LLM-powered ADD/UPDATE/DELETE | Open source core |
| ChatGPT | Brute-force context stuffing | None (all-in-context) | Model Set Context overrides | Low (hidden layers) |
| Claude Code | File-based Markdown | File reading + grep | Auto Dream consolidation | High (editable files) |
| Devin | Knowledge base + Playbooks | RAG-like + relevance recall | Manual via Knowledge edits | Low (proprietary) |

---

## Memory improves performance but noise grows faster without governance

The empirical evidence for memory's value is strong but comes with a critical caveat. **Voyager's** skill library (a form of procedural memory) produced **3.3x more unique items** and **15.3x faster milestone completion** than baselines, while also enabling zero-shot transfer to new environments. **Reflexion** (Shinn et al., NeurIPS 2023) showed that verbal self-reflection stored as episodic memory yields **+14% accuracy** over chain-of-thought approaches and achieved 91% pass@1 on HumanEval. The GoodAI LTM Benchmark found that memory-augmented agents with 8K context achieved **13% better performance** than GPT-4-turbo with 128K context at less than 16% of the cost.

However, **unmanaged memory degrades catastrophically**. On the LOCCO dataset, Openchat-3.5 memory scores declined from 0.455 to 0.05 — an **85% reduction** over six evaluation periods. ChatGLM3-6B retained only 48% of memory quality after the same interval. The Atlas paper (2025) states the core tension directly: "Capacity is not the same as utility. An agent with access to more context does not automatically know which patterns are trustworthy enough to act on. More available context can become more noise."

A March 2026 diagnostic paper provides the strongest quantitative finding for practitioners: **retrieval method is the dominant factor in memory system performance** — accuracy spans 20 points across retrieval methods but only 3–8 points across write strategies. This means investing in retrieval quality yields far more return than investing in how memories are written. The "Anatomy of Agentic Memory" survey (2025) corroborates this, noting that "current agentic memory systems often fall short of their theoretical promise" due to benchmark saturation, metric misalignment, and system-level costs rarely measured in papers.

For Stoke specifically, the **SkillsBench** finding is essential: curated skills raise agent pass rates by **16.2 percentage points** on average, while self-generated skills degrade performance by 1.3 points. This means automatic skill promotion without quality gates actively hurts performance — a direct warning against naive "save everything the agent learns" approaches.

---

## The right schema is a three-layer hybrid with structured rules at the core

Production systems have converged on a pattern that combines the reliability of structured rules with the flexibility of searchable archives. The optimal schema for coding agent lessons learned is neither purely structured nor purely semantic — it is a **tiered hybrid** where each layer serves a different access pattern.

**Layer 1: Always-in-context structured rules (20–30 items).** These are imperative one-liners loaded into every session's system prompt, following the CLAUDE.md/AGENTS.md pattern. Examples: "Schema changes: push to BOTH dev and prod databases" or "Webhook returns 404 status but body contains valid data — don't check response.ok." This layer is the highest-leverage and simplest. GitHub Copilot extends this by storing memories **with citations to specific code locations** and verifying citations against the current branch in real-time before applying them. The verification step prevents stale rules from affecting current work.

**Layer 2: Searchable archive with full-text search.** A SQLite + FTS5 store for detailed lessons, conversation history, and contextual notes retrieved on demand. The claude-memory plugin author found this sufficient for most coding agent recall: "When the consumer is an LLM that can reason about language, construct targeted queries, and iterate on failed searches, much of [vector/graph] infrastructure becomes unnecessary overhead." Letta's benchmarking confirmed it — a **plain filesystem approach scored 74% on LoCoMo**, competitive with dedicated embedding pipelines.

**Layer 3: Procedural skill library (verified, composable, transferable).** Following Voyager's pattern, verified executable procedures indexed by natural-language description embeddings. Skills must pass a verification gate before promotion — the SkillsBench finding that unverified self-generated skills degrade performance makes this gate critical. The **cass-memory** system demonstrates this in practice for coding agents: it extracts lessons from cross-agent session histories and stores them in a three-layer architecture (episodic sessions → semantic rules → procedural playbook).

Each lesson should carry structured metadata: `created_at`, `source_hash` (for staleness detection), `scope` (project-specific vs. general), `validation_count` (how many times it was confirmed useful), and `lifecycle_state` (hypothesis → active → validated → deprecated). The `agentmem` governance system implements this lifecycle, preventing one-off fixes from becoming permanent rules.

---

## Hybrid retrieval with BM25 + reranking outperforms any single method by 15–30%

For code-specific memory recall, the empirical consensus is clear: **no single retrieval method suffices**. BM25 catches exact identifiers, function names, and error messages that embeddings miss. Embeddings capture semantic similarity across vocabulary gaps that BM25 cannot bridge. Graph traversal enables multi-hop reasoning ("what functions are affected if this API changes?"). The combination consistently outperforms any individual method.

**BM25/FTS5** is the most underrated method for coding agents. Code is dense with exact identifiers where precise matching matters — a query for `NullPointerException in UserService.java` needs exact matching, not semantic approximation. GitHub chose BM25 over vector search for their 100B+ document search infrastructure. For agent memory specifically, the key insight is that **when an LLM constructs the search queries**, BM25's vocabulary-gap weakness largely disappears because the model can reformulate queries and iterate on failed searches.

**Vector embeddings** for code require specialized models. General-purpose embeddings (OpenAI `text-embedding-3-large`) are "mediocre" for code. **UniXcoder** (Microsoft) achieves the highest MRR on code search benchmarks (45.91% on CAT vs. GraphCodeBERT at 8.10%). LoRA fine-tuning on task-specific data improved UniXcoder MRR by an additional **14.8%**. However, embedding a long document as a single vector "averages out the signal and destroys retrieval specificity" — chunking strategy matters enormously.

**Graph traversal** excels at temporal reasoning and relationship tracking. Zep achieved **18.5% improvement** over full-context baselines on LongMemEval while using less than 2% of baseline tokens. For coding agents, graphs can track entity relationships (function A calls function B, module X depends on module Y) that flat memory stores cannot represent.

**LLM-based retrieval** (MemGPT pattern) adds $0.001–0.01+ per operation and 200ms–2s latency but provides the highest-quality relevance judgments. The practical middle ground is **two-stage retrieve-then-rerank**: initial retrieval via BM25+vector optimizes for recall (top-20 candidates), then a cross-encoder or LLM reranks for precision. Zep's multi-strategy pipeline achieves 75–80% on LoCoMo versus Mem0's vector-only approach at 49–66%.

For Stoke, the recommended retrieval architecture is: always-loaded core rules (no retrieval needed) + FTS5 keyword search as primary retrieval for the searchable archive + code-specific embeddings (UniXcoder or fine-tuned variant) as secondary channel + LLM-based reranking for high-stakes decisions.

---

## Five failure modes threaten memory systems, with poisoning being the most dangerous

**Stale entries** are the most common failure mode. A practitioner documented a production build failure when their agent had "always apply loudnorm to voice audio" in memory alongside a newer rule saying "never do that — it lifts the noise floor." Both were active, ranked equally, and the agent grabbed the wrong one. Defenses include Zep's bitemporal metadata (marking facts as `invalid_at` rather than deleting), source hash tracking (flagging memories as stale when their source file changes), TTL-based expiration (Mem0, Google Vertex AI), and Claude Code's Auto Dream consolidation cycle.

**Overfitting to past failures** occurs when agents apply past fixes too broadly. Memory compression amplifies this: "When you compress diverse examples into compact vectors, underrepresented perspectives get marginalized and biased patterns dominate retrieval." The defense is memory lifecycle states (hypothesis → active → validated → deprecated) with explicit promotion criteria, plus importance decay that naturally down-weights old failure-specific memories.

**Memory poisoning attacks** are the most actively researched threat. **MINJA** (2025) achieves >95% injection rate and >70% attack success through query-only interaction — no elevated privileges needed. **AgentPoison** (NeurIPS 2024) poisons RAG knowledge bases with ≥80% attack success rate using <0.1% poison rate. Palo Alto's Unit 42 demonstrated a concrete attack on Amazon Bedrock where embedded prompt injection payloads in webpages manipulated session summarization to plant persistent malicious instructions. Analysis of 918 Claude Code sessions found **138 manipulation attempts**. No single defense suffices; the field recommends layered defenses: trust boundaries between memory scopes, composite trust scoring, memory contracts defining what an agent is permitted to believe, and regular memory audits.

**Retrieval misses** are caused by embedding gaps, wrong query formulation, and silent truncation. Claude Code has a hard **200-line index cap and 25KB limit** — beyond this, memories silently fall off with no notification. The March 2026 diagnostic paper found that hybrid reranking (pooling from both cosine and BM25, then LLM-based reranking) achieved 77.2% versus 57.1% for cosine-only, making retrieval method the single largest lever.

**Contradictory memories** accumulate as stores grow. Production resolution strategies include Mem0's LLM-based comparison during writes, Zep's temporal invalidation (old facts marked invalid when superseded), and explicit precedence rules (latest user input → session overrides → global defaults).

---

## Memory update policies should follow a lifecycle with temporal metadata and conflict resolution

The most robust update policy implements a structured lifecycle rather than simple append-only storage. Based on production systems, each memory entry should move through defined states:

**When to add:** Triggers include explicit user instruction ("remember this"), automatic extraction by an LLM detecting salient facts during conversation (ChatGPT, Mem0, Zep), agent self-reflection via tool calls (MemGPT/Letta), error detection and corrective feedback (LangMem), and session summarization at session end (Amazon Bedrock, ChatGPT). The most reliable trigger is explicit user instruction; automatic extraction trades reliability for coverage.

**When to modify:** Mem0's approach is most mature — each new fact is compared against top-K similar existing memories, and an LLM decides ADD/UPDATE/DELETE/NOOP. Letta's agent uses `core_memory_replace(name, old_content, new_content)` for in-place edits. Google Vertex AI automatically creates memory revisions, allowing inspection of how memories transform. The key principle: **preserve the original memory ID** for downstream traceability.

**When to deprecate:** Zep's temporal invalidation is the gold standard — old facts are marked `invalid_at` without deletion, preserving historical context for temporal reasoning. The `agentmem` governance system implements lifecycle states where deprecated memories are retained but de-prioritized in retrieval. Amazon Bedrock marks superseded memories as "inactive" rather than removing them.

**When to delete:** Permanent removal should occur for user-requested deletion, direct contradiction with verified newer information, TTL expiration, detected memory poisoning, and consolidation of redundant entries. Claude Code's Auto Dream removes debugging notes about deleted files, workarounds for fixed bugs, and duplicate entries. ChatGPT states deleted memories stop being referenced within "a few days" and data is purged within 30 days.

The OpenAI Agents SDK cookbook recommends the most practical consolidation pattern: structured state management with clear precedence (latest user input → session overrides → global defaults), asynchronous consolidation at session end with deduplication, conflict resolution, and non-invention checks.

---

## Memory and skills need an explicit promotion boundary with verification gates

The CoALA framework provides the foundational taxonomy: **episodic memory** (records of past events), **semantic memory** (factual knowledge), and **procedural memory** (knowledge of how to perform tasks). The critical insight is that consolidation pathways exist between these types — episodic patterns can be distilled into semantic knowledge, which can be further abstracted into procedural skills.

Voyager provides the strongest evidence for automatic skill promotion. Its pattern — attempt a task, verify success with a critic model, store only verified programs as reusable skills indexed by embedding — **alleviated catastrophic forgetting** and transferred to new Minecraft worlds where baselines failed. However, the SkillsBench finding adds an essential caveat: curated skills raise pass rates by **16.2 percentage points**, while **self-generated skills degrade performance by 1.3 points**. The SWE-Skills-Bench (2026) further warns that "skill design should favor abstract guidance patterns over concrete, opinionated templates" because specific templates risk anchoring agents on non-transferable details.

For Stoke, the boundary between memory and skill should be:

- **Memory** (project-scoped, may be stale): "This API returns dates as ISO strings, not Unix timestamps." "The CI pipeline requires Node 18, not 20." "The auth module uses a custom JWT implementation, not a library."
- **Skill** (general, verified, transferable): "Always validate API response schemas before parsing." "When migration fails, check for pending migrations first, then verify database connectivity." "For React components with complex state, prefer useReducer over multiple useState calls."

The promotion pathway should require: (1) the pattern has been observed in **multiple distinct contexts**, (2) it was **verified as helpful** (not just recorded), and (3) it is **abstracted to remove project-specific details**. GitHub Copilot's approach of auto-expiring memories after **28 days** provides a natural forcing function — only patterns that are re-discovered and re-verified survive.

---

## Multi-tenant memory requires namespace isolation with defense-in-depth

When one Stoke installation serves multiple codebases, memory must be treated as a **first-class tenant boundary** with the same rigor as data isolation. Three patterns exist:

**Fully isolated** (separate stores per tenant) offers zero cross-contamination risk but high cost. **Fully shared** (logical isolation via `tenant_id` filtering) is cheapest but risky — semantic search is approximate and **may return matches from wrong tenants** without strict filtering. **Namespace isolation** (shared infrastructure with per-tenant namespaces and mandatory metadata filtering) provides the recommended balance.

SolidNumber's production CRM (515 tables, hundreds of businesses) demonstrates the defense-in-depth approach: every table has `company_id`, 298 tables use PostgreSQL **Row Level Security (RLS)**, and application-layer filtering serves as the primary mechanism with RLS as backup. AWS Prescriptive Guidance (2026) recommends MCP-based tenant isolation where MCP servers use tenant context to acquire tenant-scoped IAM credentials.

For vector databases specifically: stamp every vector with `tenant_id`, require the filter on every query, and use separate indexes for highest-security tenants. The unique AI risk is that semantic search's approximate nature can leak cross-tenant matches without strict filtering — a failure mode traditional databases don't have.

---

## Warm starting works for abstract patterns but fails for specific details

Voyager provides the strongest evidence: skills learned in one Minecraft world **transferred to a completely new world** for zero-shot task completion, while baselines (ReAct, Reflexion, AutoGPT) could not generalize. The critical variable was **abstraction level** — executable procedures with natural-language descriptions transferred; world-specific memories did not.

The SWE-Skills-Bench finding reinforces this: concrete templates with hard-coded parameter values cause **context interference** where the agent anchors on non-transferable specifics. Abstract guidance patterns transfer reliably. Google's internal code migration system demonstrates this at scale — Gemini models fine-tuned on general migration patterns achieved **80% AI-authored code modifications** and 50% reduction in total migration time.

For Stoke, the practical warm-starting approach is: maintain a **shared skill library** of verified abstract patterns that any project can access (Layer 3 of the schema), while keeping project-specific memories (Layers 1–2) strictly isolated. Transfer should be opt-in, with auto-expiration (28-day TTL) to prevent stale cross-contamination. The Devin evidence is encouraging — Nubank's **4x performance improvement** from detailed playbooks suggests that explicit knowledge curation beats automatic transfer.

---

## Memory compaction requires tiered consolidation, not just summarization

MemGPT handles memory overflow through recursive summarization when context fills — evicting ~50% of messages, generating a summary from existing summary plus evicted messages, and storing evicted messages in recall storage. The Letta team acknowledges this is "inherently lossy." More sophisticated approaches have emerged.

**Claude Code's Auto Dream** represents the most production-proven compaction system: a four-phase consolidation cycle (orient → gather → merge → finalize) that runs between sessions when triggered by sufficient elapsed time (≥24 hours) and accumulated changes. It resolves contradictions, converts relative dates to absolute, and removes stale entries. This mirrors biological memory consolidation during sleep.

The **Atlas Memory Kernel** (2025) proposes the most rigorous approach: "memory as distillation, not storage; delivery as instruction rewriting, not context injection." It uses a four-layer distillation model with **three-step verification** before facts are promoted into agent instructions. On CUAD contract analysis, evolved prompts improved GPT-4o token-level F1 by **+3.16 percentage points**.

**Phil Schmid's context engineering framework** (drawing from Manus) distinguishes compaction from summarization: **compaction is reversible** (strip redundant information that exists in the environment, like replacing file contents with file path references), while **summarization is lossy** (LLM-generated condensation). The principle is: "Prefer raw > compaction > summarization." Implementation should trigger before the "context rot threshold" — if a model has 1M context window, performance degrades around ~256K tokens.

For Stoke's memory tiers:

- **Hot (always loaded, <200 lines):** Core rules, active project context, critical conventions. Equivalent to CPU cache.
- **Warm (retrieved on demand):** Searchable archive of lessons, past decisions, architectural notes. FTS5 + optional embeddings. Equivalent to RAM.
- **Cold (archived, rarely accessed):** Historical session logs, deprecated lessons, past project context. Compressed monthly. Equivalent to disk.
- **Consolidation cycle:** Run between sessions (Auto Dream pattern). Promote validated warm entries to hot, compress old warm entries to cold, prune cold entries older than a configurable TTL. Resolve contradictions using recency as tiebreaker.

The KV-cache compaction research shows **50x compression** without accuracy loss is possible at the attention level, suggesting that as models improve their native context management, the need for application-level compaction may decrease — but for now, application-level tiering remains essential.

---

## Conclusion

Building Stoke's memory system so the 100th task is more autonomous than the first requires navigating a fundamental tension: **memory accumulation improves performance only when noise is actively managed**. The research points to five concrete architectural decisions.

First, adopt a **three-layer hybrid schema** — always-loaded structured rules (CLAUDE.md pattern with GitHub Copilot's citation verification), FTS5-searchable archive (surprisingly competitive with vector approaches when the LLM constructs queries), and a verified procedural skill library (Voyager pattern with SkillsBench-mandated quality gates). Second, invest in **retrieval quality over write quality** — the March 2026 diagnostic paper's finding that retrieval method spans 20 accuracy points versus 3–8 for write strategy means hybrid BM25+vector+reranking is the highest-leverage investment. Third, implement **memory lifecycle governance** with temporal metadata and source hash tracking — the `agentmem` pattern of hypothesis → active → validated → deprecated prevents both staleness and overfitting. Fourth, treat **memory as an attack surface** with layered defenses — MINJA's >95% injection rate with no elevated privileges makes this non-optional. Fifth, separate **project-specific memory from transferable skills** with explicit promotion boundaries and verification gates, using abstract guidance patterns that transfer while keeping codebase-specific gotchas isolated.

The most counterintuitive finding is that simpler systems often win. Claude Code's plain Markdown files, Letta's filesystem scoring 74% on LoCoMo, and the claude-memory plugin's FTS5-only approach all suggest that **LLMs compensate for storage simplicity through intelligent query construction**. Start with the simplest viable architecture — structured rules + SQLite FTS5 + lifecycle governance — and add vector search, graph traversal, and compaction only when empirical measurement on Stoke's actual workloads demonstrates the need.