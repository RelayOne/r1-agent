# LLM tool selection degrades predictably — and research shows how to fix it

**Tool selection accuracy follows a sigmoid decay curve, remaining stable below 10 tools, declining sharply between 30–50 tools, and collapsing beyond 100.** This finding, replicated across multiple studies and confirmed by Anthropic's internal data, establishes clear engineering thresholds for agent design. The good news: techniques like hierarchical retrieval, dynamic tool loading, and description optimization can recover most lost accuracy. For a coding agent with ~10 core tools, the research consensus is clear — no filtering is necessary, but the moment MCP servers push the count past 20–30, tool search becomes essential.

This report synthesizes findings from Anthropic's engineering blog and documentation, the Gorilla/BFCL project (UC Berkeley), ToolBench/ToolLLM (ICLR 2024), AnyTool (ICML 2024), LATM (ICLR 2024), and over a dozen additional papers and industry sources to answer ten specific questions about tool selection, scaling, and management.

---

## 1. The empirical accuracy curve is sigmoid, not linear

The most rigorous empirical study of tool selection accuracy versus tool count comes from "When Single-Agent with Skills Replace Multi-Agent Systems and When They Fail" (arXiv 2601.04748, January 2025, University of British Columbia / Vector Institute). Testing GPT-4o and GPT-4o-mini, the authors found that accuracy follows a **sigmoid (S-curve) decay** — stable at small library sizes, then plummeting through a phase transition.

The fitted scaling parameters show γ > 1 (specifically **1.71 for GPT-4o-mini and 1.65 for GPT-4o**), indicating faster-than-linear degradation beyond the capacity threshold. The steepest decline occurs near ~50 tools for both models. Crucially, the study found that when semantically similar "competitor" tools are absent, **accuracy remains at 100% regardless of library size** — degradation is driven by semantic confusability, not raw count.

**Approximate accuracy by tool count (synthesized across studies):**

| Tool count | Accuracy range | Phase |
|---|---|---|
| 1–10 | ~95–100% | Plateau — most models handle this well |
| 10–20 | ~90–95% | Gradual erosion, especially with overlapping descriptions |
| 20–50 | ~70–90% | Active decline; Anthropic identifies **30–50** as critical |
| 50–100 | ~40–70% | Steep cliff; severe degradation without mitigation |
| 100–200 | ~20–40% | Near-collapsed; tool search/retrieval essential |
| 200+ | Effectively random | Direct selection unusable |

**Anthropic's internal numbers** confirm this pattern. From their November 2025 engineering blog: "Claude's ability to correctly pick the right tool degrades significantly once you exceed 30–50 available tools." On their MCP evaluation benchmarks with large tool libraries, **Opus 4 achieved only 49% accuracy** with all tools loaded (improving to **74%** with Tool Search), while **Opus 4.5 went from 79.5% to 88.1%**. A 5-server setup (GitHub 35 tools, Slack 11, Sentry 5, Grafana 5, Splunk 2) consumed **~55,000 tokens** before any conversation began; Anthropic internally saw setups consuming **134,000 tokens** in tool definitions alone.

**OpenAI's official guidance** recommends fewer than **20 functions** at the start of any turn — described as a "soft suggestion." For their o3/o4-mini models specifically, fewer than **100 tools and fewer than 20 arguments per tool** is considered "in-distribution."

At massive scale, independent testing paints a stark picture. Arcade AI tested Anthropic's Tool Search against 4,027 tools and found **56–64% retrieval success** (whether the correct tool even appeared in results). Stacklok's comparison across 2,792 tools found Anthropic's BM25-based Tool Search achieved only **48% retrieval accuracy and ~34% end-to-end selection accuracy**, while their competing MCP Optimizer reached 98% and 94% respectively — though as a competitor, their benchmarks may carry bias.

The "Less is More" paper (arXiv 2411.15399, November 2024) tested smaller models on the BFCL benchmark and found that reducing available tools improved **every metric**: Qwen2-7b's success rate rose to 68%, tool accuracy hit 87%, execution time dropped 70%, and power consumption fell 27%.

---

## 2. Five techniques extend effective tool count past the cliff

### Dynamic tool loading via Tool Search

Anthropic's Tool Search Tool, released November 2025, is the most mature production solution. Instead of loading all tools upfront, tools are marked with `defer_loading: true` and discovered on-demand. Only the Tool Search Tool itself (~500 tokens) loads initially. Results: **85% reduction in token usage** (from ~77K to ~8.7K tokens), with accuracy gains of **25 percentage points** (Opus 4) and **8.6 points** (Opus 4.5). Anthropic recommends Tool Search when 10+ tools are available or tool definitions exceed 10K tokens. OpenAI introduced a parallel feature for gpt-5.4+ models.

### Hierarchical tool catalogs

AnyTool (Du et al., ICML 2024) navigates **16,000+ APIs** through a three-tier hierarchy: meta-agents identify relevant categories, category agents narrow to specific tools, and tool agents select final APIs. This approach outperformed ToolLLM by **+32.6 points** and GPT-4 with reference APIs by **+19.3 points** in pass rate. ToolLLM (ICLR 2024 spotlight) similarly structures RapidAPI's 49 categories into hierarchical trees with a neural API retriever selecting top-5 candidates.

### Tool description optimization

The EASYTOOL framework (NAACL 2025) transforms diverse tool documentation into standardized, concise instructions. The key result: **ChatGPT with EASYTOOL-optimized descriptions surpassed GPT-4 with original documentation** in success rate. Even small models (Vicuna-7B, Mistral-7B) outperformed fine-tuned ToolLLaMA when given optimized descriptions. The Artemis framework showed systematic description optimization improves agent performance by **9.3–13.6%**.

### Two-stage retrieve-then-select pipelines

The dominant paradigm uses embedding-based or keyword retrieval to narrow candidates to 5–10, then LLM reasoning for final selection. AutoTool (Zou et al., 2024) integrates this with reinforcement learning and Plackett-Luce ranking across 1,000+ tools. AWS Strands Agents uses FAISS-based vector filtering to narrow 29 tools to top-3, reporting **89% token reduction**.

### Few-shot tool use examples

Anthropic's `input_examples` feature embeds concrete usage patterns in tool definitions. Internal testing showed accuracy improved from **72% to 90%** on complex parameter handling. Token cost is modest: ~20–50 tokens for simple examples, ~100–200 for complex nested objects. Anthropic recommends 2–3 examples showing minimal, moderate, and full parameter usage.

---

## 3. Ten well-designed coding tools need no filtering

For a coding agent with ~10 core tools (Read, Write, Edit, Glob, Grep, Bash, Ls, plus a few more), the evidence strongly indicates that **filtering is unnecessary and would add complexity without benefit**. Anthropic explicitly states that Tool Search is "less beneficial when you have a small tool library (<10 tools) where all tools are used frequently." OpenAI considers <100 tools "in-distribution" for o3/o4-mini.

Claude Code itself operates with approximately **10–15 core built-in tools** and does not use dynamic tool filtering for its core toolset. All core tools load upfront. The architecture uses a skills system for on-demand loading of specialized knowledge and subagents with isolated contexts for specific tasks, but the fundamental tool set remains static and always available.

**The critical threshold appears at ~20–30 tools**, where description overlap and context consumption start degrading performance, or when tool definitions exceed ~10K tokens. For a coding agent, filtering becomes necessary when MCP servers push the total tool count past this threshold. Claude Code auto-enables tool search when MCP tool descriptions exceed **10% of context window**. A practical heuristic from AWS research: agents with **10+ semantically similar tools** experience "choice overload" causing both accuracy degradation and cost explosion.

Context rot compounds the problem for longer sessions. Research from Morph (2025) shows coding agent performance degrades after roughly **30K tokens** of context, with agents typically accumulating 80K–150K tokens within 35 minutes. The U-shaped attention curve means accuracy for information in the middle of context drops **30%+ lower** than at the start or end.

---

## 4. Description quality can matter more than model capability

A Queen's University empirical study (arXiv 2602.14878, February 2026) of **856 tools across 103 MCP servers** found that **97.1% of tool descriptions contain at least one quality defect**. Fifty-six percent fail to state their purpose clearly. Augmenting all description components improved task success rates by a **median 5.85 percentage points** and partial goal completion by **15.12%**, though it increased execution steps by 67.46% and regressed performance in 16.67% of cases — a meaningful trade-off.

Anthropic's guidelines for tool descriptions (published September 2025, "Writing effective tools for agents") emphasize several principles. First, **tool design matters more than tool count**: instead of wrapping every API endpoint, build thoughtful tools targeting specific workflows. Rather than offering `list_users`, `list_events`, and `create_event` separately, implement a unified `schedule_event`. Second, **return meaningful context**: use natural language names instead of cryptic IDs — "merely resolving arbitrary alphanumeric UUIDs to more semantically meaningful language significantly improves Claude's precision in retrieval tasks by reducing hallucinations." Third, treat tool descriptions and specs as **prompt engineering exercises**. Anthropic's web search team discovered Claude was needlessly appending "2025" to search queries, degrading results — fixed solely by improving the tool description.

OpenAI's guidance converges on similar points: enable strict mode (`strict: true`) always, write concise and coherent descriptions, and recognize that "when tools have overlapping purposes or vague descriptions, models may call the wrong one or hesitate to call any at all." The **Tool2Vec** approach represents each tool as the average embedding of real user queries, aligning retrieval with practical demand rather than documentation semantics.

---

## 5. Dynamic tool loading and prompt caching are in tension — but solvable

Anthropic's prompt caching follows a strict hierarchy: **tools → system → messages**. Tool definitions sit at the very top of the cached prefix. This creates a critical architectural constraint: **modifying tool definitions invalidates the entire cache** — tools, system, and messages caches are all destroyed. This is the most destructive cache invalidation possible.

| What changes | Tools cache | System cache | Messages cache |
|---|---|---|---|
| Tool definitions | ✘ Invalidated | ✘ Invalidated | ✘ Invalidated |
| Web search toggle | ✓ Preserved | ✘ Invalidated | ✘ Invalidated |
| Tool choice parameter | ✓ Preserved | ✓ Preserved | ✘ Invalidated |

Cache economics are significant. Cache reads cost only **0.1× base input token price** (90% cheaper), while 5-minute cache writes cost 1.25× and 1-hour writes cost 2×. For Claude Sonnet 4, that's $0.30 per million tokens on cache hits versus $3.00 for fresh input. Cache TTL is 5 minutes by default, refreshed on each hit, with a 1-hour option at additional cost. Maximum of **4 cache breakpoints** per request — recommended allocation: tools (1), system (2), RAG context (3), conversation history (4).

**Anthropic's Tool Search Tool resolves this tension.** Deferred tools are excluded from the initial prompt entirely — they're only added to context after Claude searches for them. So the system prompt and core tool definitions remain cacheable. The key architectural insight: keep 3–5 most-used tools always loaded (and cached), defer everything else via Tool Search. This preserves caching benefits while enabling access to large tool libraries.

Practical pitfalls to avoid: some programming languages (Swift, Go) randomize JSON key ordering during serialization, which silently breaks cache matching even when tool definitions haven't changed semantically.

---

## 6. MCP servers are the biggest source of tool bloat in production

MCP (Model Context Protocol) servers are the primary mechanism by which tool counts explode in production. A single GitHub MCP server exposes **35 tools consuming ~26K tokens**. Slack adds 11 tools and ~21K tokens. Jira alone adds ~17K tokens. Anthropic's internal data shows setups where tool definitions consumed **134K tokens** before any optimization — approaching the entire context window before a single user message.

The quality problem compounds the quantity problem. The Queen's University study of MCP servers found **97.1% of tool descriptions contain quality defects**, with 56% failing to state their purpose. This means MCP servers simultaneously inject many tools *and* poorly described tools — a double penalty for selection accuracy.

Anthropic recommends a layered approach to MCP management. Context bloat from definitions → Tool Search Tool. Large intermediate results polluting context → Programmatic Tool Calling (which achieved **37% token reduction** and improved GIA benchmarks from 46.5% to 51.2%). Parameter errors and malformed calls → Tool Use Examples (72% to 90% accuracy improvement). For Claude Code specifically, tool search auto-activates when MCP descriptions exceed **10% of context window**, tool descriptions are truncated at **2KB each**, and MCP output defaults to a maximum of **25,000 tokens** (configurable).

Enterprise MCP management provides two policy models: exclusive control via `managed-mcp.json` (fixed server set, users cannot modify) or policy-based control via allowlists and denylists. Per-agent tool visibility — showing only relevant tools per subagent role — is an actively requested feature (Claude Code issues #4380, #6915, #7328) that the community recognizes as a critical need.

---

## 7. Tool hallucination is pervasive and driven by four root causes

Tool hallucination — when agents call nonexistent tools or use wrong parameters — is systematically measured across several benchmarks. The Gorilla project (UC Berkeley, NeurIPS 2024) found that **GPT-4 exhibits significant hallucination when prompted zero-shot** to generate API calls, generating calls to models and functions that don't exist. Pairing GPT-4 with a high-quality retriever (GPT-Index) achieved a **91% reduction in hallucination**. The fine-tuned Gorilla model "virtually eliminated hallucinations" when combined with retrieval.

ToolBench's initial releases revealed severe quality issues: **up to 50% of queries and 75% of trajectories** suffered from incompleteness or hallucinations. StableToolBench found only **44.4% of API calls succeeded** in the original ToolBench. The Reflexion paper found a ReAct-only agent converged at a **22% hallucination rate** with no signs of long-term recovery. BFCL V4 weights hallucination at 10% of the overall score and includes 240 test cases specifically for Function Relevance Detection — scenarios where no provided function should be invoked.

The "Reducing Tool Hallucination via Reliability Alignment" paper (ICML 2024) established a systematic taxonomy with two categories: **tool selection hallucination** (calling nonexistent or irrelevant tools) and **tool usage hallucination** (correct tool, wrong parameters). They introduced a Reliable Pass Rate metric (Pass Rate minus Task Hallucination Rate) and found it "significantly lower than the pass rate," indicating substantial hidden hallucination in nominally passing results.

Root causes cluster into four categories. **Semantic confusability** between similar tools (e.g., `notification-send-user` vs. `notification-send-channel`) is the primary driver. **Prompt-based constraints treated as suggestions** means agents see "Maximum 10 guests" as context, not a hard boundary. **API evolution** creates stale training data — Gorilla noted 31 AWS API modifications in a single day. And **multi-step reasoning failures** cause cascading errors — when Tool A returns empty results, agents fabricate inputs for Tool B rather than stopping.

Detection methods include AST sub-tree matching (checking if generated calls match any valid API), function relevance detection (testing whether models hallucinate calls when no relevant function exists), schema validation before execution (OpenAI's strict mode), and state-based evaluation (checking system state after execution matches expectations).

---

## 8. Optimal error recovery combines informative feedback with structured retry

Production tool error handling follows a clear hierarchy of patterns across all major platforms. **Anthropic** uses an `is_error: true` flag in `tool_result` blocks with informative error messages — "Don't just return a generic 'Failed'; instead, return 'Error: Location Atlantis not found in weather database.'" This allows Claude to reason about the failure and attempt recovery. **OpenAI** recommends strict mode (`strict: true`) to prevent malformed calls entirely, classifies errors as transient (retry with backoff) vs. permanent (don't retry), and supports model fallback chains. **LangChain** provides the most comprehensive middleware stack: `ToolRetryMiddleware` with configurable max retries (default 2, meaning 3 total attempts), exponential backoff (factor 2.0), random jitter (±25%), and selective retry by exception type.

The ReAct pattern provides natural error recovery through its Thought→Action→Observation loop: failed tool execution feeds the error observation back into reasoning, allowing the LLM to retry with modified parameters, use a different tool, or modify its plan. Reflexion (Shinn et al., 2023) adds a self-reflection layer that generates structured feedback ("What failed? Why? What should change?") stored in persistent memory. Reflexion agents **learned to solve additional tasks over 12 consecutive trials**, while ReAct-only agents converged at 22% hallucination with no recovery.

Production best practices distilled from across the industry:

- **Validate before execution** — schema-validate all tool calls before running them
- **Return specific, actionable error messages** — enable LLM self-correction
- **Use exponential backoff with jitter** (1s, 2s, 4s… ±25%) for transient errors
- **Scope retries narrowly** — retry only the failing component, not the entire chain
- **Set iteration and time limits** (10–15 max iterations) to prevent infinite loops
- **Implement circuit breakers** — stop calling persistently failing services
- **Distinguish transient vs. permanent errors** — retry 5xx/network errors, not 4xx/validation

Industry data from LangChain's State of Agent Engineering report shows **94% of production agent teams run observability**, with **71.5% having full step-level tracing**.

---

## 9. Tool creation outperforms fixed tools but demands guardrails

The research consistently shows that agents capable of creating or composing tools outperform those limited to fixed tool sets. **LATM (LLMs as Tool Makers)** (Cai et al., ICLR 2024) demonstrated that GPT-4 as tool maker + GPT-3.5 as tool user achieves **performance equivalent to GPT-4 for both roles** at significantly reduced cost. On some tasks, GPT-3.5 with LATM tools (92.2%) actually **outperformed GPT-4 using LATM (87.5%)** and GPT-4 with chain-of-thought (63.6%). The key insight is "functional caching" — storing reusable functionality rather than regenerating it.

**CREATOR** (EMNLP 2023) showed that disentangling abstract tool creation from concrete execution outperforms CoT, program-of-thought, and tool-using baselines on math and tabular reasoning. **Chameleon** (NeurIPS 2023) achieved **86.54% on ScienceQA** (improving best published few-shot by 11.37%) and **98.78% on TabMWP** (17.0% improvement) through compositional tool use — dynamically combining heterogeneous tools into task-specific programs. **AnyTool** (ICML 2024) showed that hierarchical selection with self-reflection yields +35.4% over ToolLLM and +19.3% over GPT-4 with reference APIs. Self-reflection rounds alone contributed up to **20% improvement** across datasets.

| Approach | vs. Baseline | Key finding |
|---|---|---|
| LATM (tool creation) | GPT-3.5+tools ≈ GPT-4 alone | 10× cost reduction with matched performance |
| CREATOR (tool creation) | > CoT, PoT, tool-using | Disentangling creation/execution improves reasoning |
| Chameleon (composition) | +11.37% best few-shot | Compositional use exceeds single-tool approaches |
| SMITH (creation + memory) | +29% over basic CoT | Cross-task experience sharing amplifies creation |

Anthropic takes a **cautiously structured position**: they favor pre-built, well-tested tools and skills over fully autonomous runtime creation, with structured composition rather than free-form generation. Their Agent Skills framework provides modular, composable capabilities with strong warnings that "malicious Skills could lead to data exfiltration or unauthorized access." Their research on measuring agent autonomy found that 80% of tool calls come from agents with at least one safeguard, 73% have a human in the loop, and only **0.8% of actions appear irreversible**.

The safety concerns are real: dynamically generated tools are essentially arbitrary code requiring sandboxed execution. LATM's three-stage pipeline (proposing → verification via unit tests → wrapping with documentation) provides a template, but verification gaps remain. The consensus is to start with fixed, well-tested tools and add dynamic creation only when pre-built tools are insufficient, always with sandboxing and human oversight for high-stakes operations.

---

## 10. The optimal tool count depends on confusability, not just quantity

The cost-benefit analysis of tool set size is more nuanced than "fewer is always better." The scaling law paper's most important finding is that **semantic confusability between tools — not raw count — drives degradation**. When no two tools in a library could plausibly be confused, accuracy holds at 100% regardless of library size. This means the practical limit depends on how distinct your tools are.

Token economics create a hard cost floor. Each tool definition consumes tokens: a GitHub MCP server's 35 tools cost ~26K tokens, while Slack's 11 tools cost ~21K tokens. At $3/MTok for Claude Sonnet 4 input, 58 tools at ~55K tokens costs **$0.165 per request** just for tool definitions — before any conversation content. Tool Search reduces this by 85%, and prompt caching reduces read costs by 90%, but the baseline cost scales linearly with tool count.

The practical framework emerging from the research has three tiers. For **≤10 semantically distinct tools**, load all tools directly with no filtering — this is the plateau zone where accuracy is near-perfect and the overhead is manageable. For **10–30 tools**, consider Tool Search if tools have overlapping descriptions or definitions exceed 10K tokens, but well-designed distinct tools may still work without filtering. For **30+ tools**, Tool Search or hierarchical retrieval becomes essential — accuracy without it drops below 80% and token costs become prohibitive.

The "Less is More" paper's hierarchical search approach offers an elegant compromise: show few tools at Level 1, expand to more at Level 2, and fall back to all tools at Level 3 only if needed. This preserves capability while biasing toward the accuracy advantages of smaller sets. Anthropic's own recommendation — "keep your three to five most-used tools always loaded, defer the rest" — operationalizes this principle for production systems.

## Conclusion

The research landscape on LLM tool selection reveals a field that has moved rapidly from identifying the problem (2023) to engineering practical solutions (2025–2026). Three insights stand out as non-obvious. First, **the degradation curve is driven by tool similarity, not count** — a finding that transforms tool design from a quantity problem into a naming and description problem. Second, **description quality can compensate for model capability** — EASYTOOL showed ChatGPT with optimized descriptions beating GPT-4 with raw documentation, suggesting that engineering effort on descriptions may yield better returns than model upgrades. Third, **the caching-dynamism tension is a first-order architectural concern** — since tool definition changes invalidate the entire prompt cache, the decision of which tools to load statically versus dynamically has direct cost implications that compound across every request.

For practitioners building agents today, the data supports a clear architecture: a small, stable, always-cached core tool set (~5–10 tools); Tool Search or equivalent retrieval for extended capabilities; high-quality, standardized descriptions with few-shot examples; informative error messages enabling LLM self-correction; and monitoring for tool hallucination as a key quality metric. The tools exist to scale to thousands of APIs — the challenge is no longer whether it's possible, but engineering the layers of retrieval, caching, and description quality to make it reliable.