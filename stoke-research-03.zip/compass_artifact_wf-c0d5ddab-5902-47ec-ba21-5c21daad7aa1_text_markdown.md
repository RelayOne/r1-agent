# AI coding agents hit a wall after two hours — here's what the research says

**Frontier AI coding agents achieve near-100% success on tasks under 4 minutes but fall below 10% on tasks exceeding 4 hours of human-equivalent effort.** This asymmetry is the central design constraint for Stoke or any AI coding orchestrator aiming to handle genuinely long tasks. The research points to a consistent picture: agents degrade across every cognitive dimension simultaneously — context handling, planning, error recovery, and focus — but architectural patterns like hierarchical planning, sub-agent delegation, and episodic memory can extend effective horizons by **3–15×**. No production tool today sustains coherent autonomous work beyond a few hours in a single session; "multi-week" vendor claims describe parallelized fleets of agents, not individual sustained reasoning. This report synthesizes empirical findings from RE-Bench, SWE-Bench, METR evaluations, and production tools to establish realistic expectations and architectural guidance.

---

## 1. Everything degrades, but error recovery fails first

METR's RE-Bench paper (Wijk et al., arXiv:2411.15114, November 2024) tested AI agents against 61 human experts on 7 ML research engineering tasks across varying time budgets. The headline finding: **agents outperform humans at 2-hour budgets (achieving ~4× human scores) but plateau while humans continue improving**, with humans reaching 2× agent scores at 32 total hours. The degradation is not a single failure mode but a compound collapse.

**Error cascading** emerges as the most damaging mechanism. When agents encounter an error mid-task, their improvised workarounds become part of the context, and subsequent steps build on flawed intermediate state. METR's March 2025 follow-up paper ("Measuring AI Ability to Complete Long Tasks," arXiv:2503.14499) frames the bottleneck precisely: agents "struggle more with stringing together longer sequences of actions than they lack skills or knowledge needed to solve single steps." The AgentErrorBench taxonomy (arXiv:2509.25370) confirms this — a single root-cause failure cascades into successive errors across Planning, Action, Reflection, and Memory modules, with the compounding effect "especially acute in long-horizon tasks."

**Context handling** degrades predictably. The "Lost in the Middle" finding (Liu et al., 2023) shows models favor tokens at the start and end of context while losing middle information. A Gemini 2.5 Pokémon agent experiment demonstrated that beyond **~100K tokens**, the agent shifted toward "repeating actions from its vast history rather than synthesizing novel plans." Multiple industry analyses report performance degradation after **20–30 conversation turns**.

**Planning and strategic coherence** break down as agents fail to maintain and adapt long-term plans. RE-Bench found agents generated submissions 10× faster than humans but failed to strategically build on partial progress. The agents couldn't coordinate parallel workstreams, resolve ambiguous instructions, or adapt strategy based on intermediate results. METR's holistic evaluation of SWE-bench Verified PRs found that "roughly half of test-passing PRs would not be merged by repo maintainers" — agents can implement core functionality but fail on documentation, testing, and code quality standards that require sustained attention to detail.

**Focus and specification drift** rounds out the picture. Four documented degradation patterns include context window exhaustion, model drift (outputs diverging from established reasoning), repetition loops, and coherence degradation where the reasoning chain becomes internally inconsistent.

---

## 2. The empirical ceiling: 50% success at roughly one to two hours

The most rigorous measurement of AI agent time horizons comes from METR's ongoing evaluations across hundreds of software engineering and research tasks, calibrated against human expert completion times.

**The 50% success threshold by model (task duration measured in human-equivalent time):**

| Model | 50% time horizon | Date |
|-------|-----------------|------|
| GPT-4 (original) | ~1–2 minutes | March 2023 |
| Claude 3.5 Sonnet | ~15–30 minutes | October 2024 |
| Claude 3.7 Sonnet | **~50–60 minutes** | February 2025 |
| o3 | **~1.5 hours** | April 2025 |
| GPT-5 | **~2 hours 17 minutes** | Mid-2025 |

This horizon has been **doubling approximately every 7 months** over the past 6 years, though 2024 data suggests acceleration to ~3-month doublings. The critical finding: on tasks that take a human 90 minutes to 3 hours, even a model with a ~2-hour time horizon succeeds 100% of the time on one-third of tasks, fails 100% on another third, and is unpredictable on the rest. Task variability, not just duration, drives outcomes.

**Benchmark-specific performance reveals the horizon wall clearly.** On SWE-Bench Verified (500 real-world GitHub issues, mostly single-file Python fixes), top models in early 2026 score **76–81%** — Claude Opus 4.5 at 80.9%, GPT-5.2 at 80.0%, Gemini 3.1 Pro at 80.6%. But SWE-Bench Pro, which tests multi-file tasks averaging **107 lines of code across 4.1 files**, initially saw scores drop to just **23%** for the best models, rising to ~55% with improved scaffolding by early 2026. RefactorBench found that when three individually solvable refactoring tasks were combined into one longer task, SWE-agent solved **zero** of these composites, despite solving each component separately. The average successful coding trajectory on RefactorBench was ~46 actions with GPT-4.

The Aider Polyglot benchmark (225 exercises, 6 languages) shows raw coding ceiling: GPT-5 achieves **88%** but these are single-function, few-minute tasks — they measure coding skill, not sustained autonomous operation. RE-Bench shows the opposite end: on 8-hour ML R&D tasks, agents hit their optimal performance window at **30 minutes to 2 hours per attempt**, with no improvement from additional time.

---

## 3. Architectural patterns that push the horizon outward

Six architectural patterns have documented evidence of extending AI agent effective horizons, ranging from **2.5× to 15×** improvement over naive single-agent approaches.

**Hierarchical planning** delivers the largest measured gains. Microsoft Research's CORPGEN framework (arXiv:2602.14229, February 2026) implements multi-horizon planning across strategic (monthly), tactical (daily), and operational (per-cycle) scales. In experiments with 45+ interleaved tasks spanning 500–1,500+ steps over 6-hour sessions, CORPGEN achieved **3.5× improvement** over baselines (15.2% vs. 4.3% task completion). MetaGPT (Hong et al., ICLR 2024) encodes Standardized Operating Procedures into role-based agent pipelines, achieving **100% task completion** on software engineering benchmarks with an average of 4.71 code files per project. The key insight: mandating structured artifact outputs between agents reduces cascading hallucination errors.

**Sub-agent delegation** provides context isolation. Anthropic's multi-agent research system demonstrates the pattern: "Each subagent might explore extensively, using tens of thousands of tokens or more, but returns only a condensed, distilled summary of its work (often 1,000–2,000 tokens)." This keeps the orchestrator's context lean while allowing deep exploration. OpenDev's fleet architecture launches multiple sub-agents in parallel via Rust async I/O, each with independent context windows and tool access, using a fan-out/converge pattern.

**Episodic memory and self-reflection** enable learning within a task. Reflexion (Shinn et al., NeurIPS 2023) stores verbal self-reflections in a long-term memory buffer across attempts, achieving **91% pass@1 on HumanEval** versus 80% for GPT-4 without reflection, and solving 130/134 AlfWorld tasks. The 2026 Multi-Layered Memory Framework (arXiv:2603.29194) reduces false memory rates to **5.1%** and context usage to **58.4%** through adaptive retrieval gating across working, episodic, and semantic layers.

**Plan persistence across sessions** is exemplified by Voyager (Wang et al., May 2023), which maintains an ever-growing skill library of executable code indexed by natural-language descriptions. Voyager obtained **3.3× more unique items**, traveled **2.3× longer distances**, and unlocked milestones up to **15.3× faster** than prior state-of-the-art — with skills transferring to new environments. Anthropic's long-running agent harness uses an initializer agent to generate 200+ feature descriptions as JSON, with each coding session picking one feature, implementing it fully, and committing — solving the failure mode of agents trying to "one-shot" entire projects.

**Summarization checkpoints** prevent context overflow. OpenDev's Adaptive Context Compaction uses a five-stage graduated pipeline: warning at 70% capacity, observation masking at 80%, progressive compression at 85–90%, LLM summarization at 90%, and emergency compaction at 95%+. This "significantly outperforms the naive strategy of compacting everything when a hard limit is hit." Cursor's Composer 2 learns when and how to summarize through RL training, with outcome rewards propagated through summary chains.

**Structured journals** (CLAUDE.md files, progress.txt, CURRENT_TASK.md patterns) serve as external memory artifacts that survive context resets. Practitioners report writing checkpoints every 10–15 minutes in date-stamped, machine-readable formats. The pattern is consistent: agents that write structured notes before context compaction maintain higher coherence after resumption.

---

## 4. No production tool sustains autonomous work beyond a few hours

The gap between vendor marketing and independent evidence is stark. When tools claim "weeks of work," they mean parallelized fleets completing many bounded tasks — not single agents maintaining coherent reasoning across days.

**Devin** (Cognition) scored 13.86% on SWE-Bench at launch (March 2024) and has not published updated benchmark scores. Cognition's own 2025 performance review scopes Devin's sweet spot as "tasks with clear, upfront requirements that would take a junior engineer 4–8 hours." Answer.AI's independent month-long evaluation (January 2025) found **3 out of 20 tasks completed successfully (15%)**, with Devin "spending days pursuing impossible solutions rather than recognizing fundamental blockers." StepChange's analysis revealed Devin succeeded on only 11 tasks requiring multi-file changes versus 95 such tasks where it failed. Cognition's own admission: "It usually performs worse when you keep telling it more after it starts the task."

**Claude Code** provides the best empirical data on actual agent session durations. Anthropic's research shows the 99.9th percentile turn duration nearly doubled from under 25 minutes (October 2025) to over **45 minutes** (January 2026). This is session-based work — developers give a task, Claude works on it, then the developer reviews. Multi-day operation happens through repeated sessions with persistent context via CLAUDE.md files, not sustained autonomy.

**OpenAI Codex** (the agent product) completes tasks "typically between **1 and 30 minutes**" per OpenAI's own documentation. GPT-5.2-Codex added context compaction for "long-horizon work," and GPT-5.3-Codex claims to build "complex games and apps from scratch over the course of days" — but this uses the Codex Desktop App's multi-agent workflows with built-in worktrees, not single-agent sustained reasoning.

**Cursor's background agents** complete simple PRs in ~3 minutes and cap standard sessions at 25 tool calls (200 in Max mode). Cursor's own documentation acknowledges: "After many turns and summarizations, context accumulates noise. Starting a new session with a clean prompt almost always outperforms continuing a long one."

**GitHub Copilot's coding agent** "excels at low-to-medium complexity tasks in well-tested codebases." The VS Code team found that "refactorings across multiple files in large codebases is a tough challenge for any software engineering agent today." **Augment Code** offers the most explicit long-task support with its "Tasklist" feature and Remote Agent, claiming developers can "come back tomorrow and pick up exactly where you left off" — but no independent benchmark data validates multi-day performance.

---

## 5. Checkpoint at 80% context capacity, summarize every 10–20 turns

JetBrains Research (NeurIPS 2025 workshop) provides the most rigorous empirical guidance on summarization intervals. Testing on SWE-bench Verified with agents running up to 250 turns, they found the **optimal observation masking window was the last 10 turns**, with LLM summarization covering 21 turns at a time while retaining the most recent 10 in full. A surprising finding: simple observation masking (replacing older observations with placeholders) matched or slightly beat LLM summarization while being **52% cheaper on average**. Both approaches cut costs by **over 50%** compared to unmanaged context.

Production systems converge on **80–85% context capacity** as the compaction trigger. Claude Code auto-compacts at ~85–90% of the context window. Goose (Block's AI agent) defaults to 80%, configurable by users. The ACON framework (arXiv:2510.00615) validates threshold-based compression across multiple benchmarks, achieving **26–54% reduction in peak tokens** while preserving task success.

Factory.ai's analysis offers the most nuanced guidance on the tradeoff: narrow gaps between fill and drain thresholds cause frequent compression with higher summarization overhead and prompt cache invalidation, while wide gaps risk aggressive truncation. **Critical information to always preserve**: session intent, high-level play-by-play, artifact trail (files created/modified/deleted), and breadcrumbs (file paths, function names for re-accessing). The warning against over-compression is important: "Once key artifacts are summarized away, the agent must re-fetch them, adding extra inference calls that can outweigh the token savings."

Anthropic's context engineering guidance advocates "just-in-time" retrieval: maintain lightweight identifiers and load data dynamically via tools rather than pre-loading everything into context. Claude Code uses bash commands like `head` and `tail` to analyze files without loading full content — mimicking how humans use file systems as external memory.

---

## 6. Prompt caching degrades through three specific failure modes

Prompt caching offers dramatic savings — Anthropic charges **0.1× base price** for cache reads (90% discount), OpenAI offers **50% discount**, and Google provides **90% discount** on Gemini 2.5+ — but these benefits erode systematically as tasks lengthen.

Three specific failure modes cause cache degradation in long sessions, documented by kern.ai's engineering team. **Sliding window drift**: when old messages are trimmed to fit the token budget, the trim point shifts each turn, changing every message index and invalidating the entire prefix. **Summary churn**: when compressed conversation summaries are injected into the system prompt, any change to the summary text busts the system prompt cache. **Moving breakpoints**: cache_control markers placed on relative positions (e.g., "4th-to-last message") move every turn, preventing stable cache entries.

Anthropic's system has a specific **20-block lookback limitation** — the system only looks back ~20 content blocks to find prior cache entries, so growing conversations can push breakpoints beyond this window, causing cache misses. OpenAI has a **~15 RPM limit per prefix+cache_key combination** before overflow to other machines.

The solution is **stable, nested cache breakpoints**. kern.ai implemented three fixed breakpoints: BP1 on the system prompt (~75K tokens, changing roughly every ~100 messages), BP2 snapped to every 20th message (staying fixed for ~20 turns), and BP3 on the last user message. During multi-step turns with 5–10 tool calls, this achieved **99%+ cache hit rates** and a **10× cost reduction**. The key architectural principles: keep tools → system → messages order, never modify earlier content, only append, and avoid mid-session changes to instructions or tools. One OpenAI customer improved cache hit rates from **60% to 87%** using `prompt_cache_key` for stable routing.

For Stoke, the implication is clear: design the prompt architecture around cache stability from the start. Static content (system prompt, tool definitions, codebase context) goes at the beginning and changes rarely. Dynamic content appends at the end. Compaction must be cache-aware — summarizing context saves tokens but can bust caches if it modifies the prefix.

---

## 7. Goal drift is measurable and universal, but architecturally preventable

The first systematic empirical study of goal drift in LLM agents (Arike et al., AAAI/ACM AIES 2025, arXiv:2505.02709) found that **all evaluated models exhibit some degree of goal drift**, even the best. Scaffolded Claude 3.5 Sonnet maintained nearly perfect goal adherence for over **100,000 tokens** in the most difficult evaluation setting — but drift manifested more through **inaction** (failing to act on misaligned states) than through active misaligned decisions. Drift severity correlated with both the duration of instrumental goal pursuit and the presence of adversarial pressure.

The Agent Stability Index (Rath, January 2026) found **semantic drift in nearly half of multi-agent LLM workflows by 600 interactions**, with ASI scores dropping below 0.70. The follow-up study on "Inherited Goal Drift" (arXiv:2603.03258, 2026) identified a critical vulnerability: when agents are conditioned on pre-filled trajectories from weaker agents, they often inherit the drift. Only GPT-5.1 maintained consistent resilience to conditioning-induced drift among tested models.

METR's data provides indirect but powerful evidence: agent performance plateaus at around **200,000 tokens**, long before theoretical budget exhaustion, suggesting agents "lose their way" in longer contexts rather than lacking skills. The asymmetric coding agent study (arXiv:2603.03456, March 2026) extends these findings to realistic coding scenarios, showing that GPT-5 mini, Haiku 4.5, and Grok Code Fast 1 are more likely to violate system prompt constraints when constraints oppose strongly-held values like security.

Prevention strategies from the literature center on **explicit goal re-injection**. Zhao et al. (November 2025) demonstrated that goal-persistent architectures can reduce task drift to **near-zero**. Verdent's "todo list anchoring" approach — anchoring agent decisions to a clear, persistent todo list — achieved 76.1% on SWE-bench Verified while maintaining goal coherence. OpenDev injects periodic system reminders to counteract instruction fade-out during long sessions. For Stoke's convergence loop, the evidence strongly supports re-stating the original objective at every checkpoint or compaction event.

---

## 8. Wisdom store, event hub, and convergence loop: a research-grounded architecture

The three components of Stoke's proposed architecture map directly to documented patterns in the literature. The CoALA framework (Sumers et al., TMLR 2024, arXiv:2309.02427) provides the canonical taxonomy, dividing agent cognition into working memory (short-term scratchpad), and long-term memory subdivided into episodic (past experiences), semantic (world knowledge), and procedural (task execution skills).

**The wisdom store should implement tiered memory with agent-native curation.** ByteRover (arXiv:2604.01599, April 2026) demonstrates the strongest pattern: the same LLM that reasons also curates knowledge through structured operations (ADD, UPDATE, UPSERT, MERGE, DELETE) into a hierarchical Context Tree, rather than relying on external pipelines that "don't understand what they store." CORPGEN's ablation studies show that **experiential learning provides the largest performance gains** among all architectural components, increasing task completion from 8.7% to 15.2%. Anthropic recommends storing structured data as JSON rather than Markdown because "the model is less likely to inappropriately change or overwrite JSON files." The wisdom store should use just-in-time retrieval — maintain lightweight identifiers and load data dynamically — rather than pre-loading everything.

**The event hub should implement publish-subscribe with structured message passing and context compaction.** MetaGPT's shared environment model has agents publish standardized action outputs that other agents subscribe to based on role. CORPGEN coordinates through "standard communication channels without predefined coordination protocols." Critical event types for long-horizon tasks include task lifecycle events (created, started, blocked, completed, failed), knowledge events (insight discovered, architectural decision made), coordination events (delegation requested, result returned, context handoff), and system events (context pressure warning, compaction triggered, session boundary). Microsoft Azure's multi-agent patterns guidance: "Apply context compaction between agents to reduce token volume passed through the orchestration."

**The convergence loop should operate at three temporal scales.** The inner loop (per-action) follows OpenDev's Extended ReAct pattern: check context pressure → thinking phase → self-critique → act → observe → evaluate. The outer loop (per-session) follows Anthropic's long-running agent harness: read progress files and git log → run health check → select highest-priority incomplete feature → implement incrementally → self-verify with end-to-end testing → commit and update progress. The cross-session loop (days-scale) follows CORPGEN's Day Init/Day End cycle: load long-term memory, generate daily plan from strategic objectives, execute multiple task cycles, then reflect on actions and consolidate successful trajectories into experiential memory.

**Key design decisions from the literature.** First, incremental progress over one-shot attempts — never try to complete everything in one session. Second, graduated compaction (70% warning → 80% masking → 90% summarization → 95% emergency) over binary emergency compaction. Third, file-based state over in-context state — use progress files, feature lists, and git commits rather than relying on context window contents. Fourth, per-workflow model routing — strong models for planning and reasoning, cheaper models for compaction and summarization. Fifth, sub-agent isolation — complex operations must run in isolated contexts with only structured results flowing back to the orchestrator.

---

## 9. Agents abandon tasks at alarming rates — or loop until budget exhaustion

Task abandonment takes two opposite forms: premature quitting and infinite looping. Both are well-documented and frequent.

The most striking empirical finding comes from WebArena: **GPT-4 erroneously declared 54.9% of feasible tasks impossible**, outputting a stop action rather than exploring further. This was the single most prevalent failure mode, far exceeding any other error category. The agent would begin correctly but give up when default results didn't immediately show the answer. Overall success rate was **10.6–14.4%** versus 78.2% for humans.

The MAST framework (Cemri et al., arXiv:2503.13657, March 2025) analyzed 1,600+ execution traces across 7 multi-agent frameworks and identified 14 distinct failure modes. **Premature termination accounted for 6.2% of all failures**, incomplete verification for 8.2%, and incorrect verification for 9.1% — totaling **21.3% of all failures** in the task verification and termination category. AppWorld frequently suffered premature terminations while OpenManus and HyperAgent exhibited dominant step repetition.

The looping failure mode is equally dangerous. A documented Claude Code incident consumed **27 million tokens in an infinite loop over 4.6 hours** (GitHub Issue #15909). Production agents have been observed spinning **20+ steps on tasks that normally take 3–4 steps**, burning $12 on what should cost $0.08. Three types of stuck behavior are documented: The Repeater (same action repeatedly), The Wanderer (doing things that don't connect to the goal), and The Looper (alternating between a small set of actions without resolving).

**Failed trajectories are significantly longer than successful ones.** Analysis of SWE-agent shows failed trajectories are 12.6% longer on SWE-Bench Lite and 18.5% longer on SWE-Bench Verified. OpenHands failed trajectories are **82.5% longer** on SWE-Bench Verified — agents persist but unproductively when failing.

**Reliability improves with each model release but at a much slower rate than accuracy.** Princeton's "Towards a Science of AI Agent Reliability" (arXiv:2602.16666, February 2026) found reliability improvement was **half** the rate of accuracy improvement on GAIA and **one-seventh** on τ-bench. Best models achieved overall reliability of **85%** — meaning 15% unreliable behavior persists.

Prevention requires external enforcement, not reliance on the agent's own judgment. Effective strategies include loop guardrails (fingerprint recent tool calls; if fingerprint repeats N times, force strategy change), AgentDebug re-rollout (identify the critical error step and re-roll from that point rather than restarting, yielding **2.5–4× improvement** on ALFWorld), todo list anchoring, and model fallback chains.

---

## 10. Token budgets for multi-hour tasks: plan for $0.50–$8 per task with 70–90% optimization headroom

Real-world cost data from SWE-bench evaluations provides concrete baselines. Agentic coding workflows average **1–3.5 million tokens per task** including retries and self-correction loops. On the efficient end, MiniMax M2.5 achieves **$0.09/task** on SWE-rebench, while vexp-augmented Claude Code costs **$0.67/task** at 73% pass@1. On the expensive end, unconstrained agents run **$5–8 per task**, and o3-pro on Aider's benchmark costs **$146 per exercise**. Token usage shows **large variance** — some runs use up to 10× more tokens than others for identical tasks. Input tokens dominate: **>97% of total usage** is cache read tokens in agentic workflows. A Reflexion loop running 10 cycles can consume **50× the tokens** of a single linear pass.

**Four optimization strategies stack multiplicatively.** Model routing (routing simple sub-tasks to GPT-4o-mini at $0.15/M input, complex reasoning to frontier models) saves **40–60%** as a standalone strategy and achieves 97.7% of full-frontier accuracy at ~61% of cost. Prompt caching with 90% hit rates delivers **~81% reduction** on input token costs. Context compression through summarization and structured outputs achieves **50–90% token reduction**. Batch processing via OpenAI's Batch API offers a flat **50% discount** on non-interactive tasks. Combined, teams report **70–90% cost reduction** versus naive implementations.

**Budget allocation should follow a three-tier guardrail pattern**: per-request `max_tokens` limits, per-task total token budgets, and per-day/per-month spending caps with alerts at 50% and 80% thresholds. Apply a **1.7–2× multiplier** to base API costs for realistic budgeting (covering usage growth, infrastructure overhead, experimentation, and peak-to-average spikes). Claude Code's approach is instructive: hard context limits, automatic compaction at ~85–90% capacity, and pre-execution budget estimation using file size heuristics (~1 token per 4 characters for English, varying for code).

For Stoke specifically, dynamic tool loading is critical — MCP tool metadata alone can consume **40–50% of context windows**, and tool search with dynamic loading reduces this overhead by **85%**. The counterintuitive insight from Factory.ai: minimize tokens per task, not per request. Cutting context too aggressively causes re-fetching that adds extra inference calls, sometimes outweighing the savings. A more capable (expensive) model can actually be cheaper for complex tasks by reaching solutions in fewer iterations.

---

## Conclusion: design for 2-hour atoms in a multi-day pipeline

The research converges on a clear architectural strategy for Stoke. **The atomic unit of autonomous work should be roughly 30 minutes to 2 hours** — the window where current frontier models demonstrate reliable performance before degradation sets in. Multi-day tasks must be decomposed into sequences of these bounded work sessions, connected by persistent state (wisdom store), coordinated through structured events (event hub), and refined through explicit convergence criteria (convergence loop).

Three insights from this research are non-obvious. First, observation masking (simply hiding old observations with placeholders) performs as well as expensive LLM summarization at half the cost — Stoke should default to cheap masking and reserve LLM summarization for critical junctures. Second, goal drift is more dangerous through inaction than action — agents fail to correct misaligned states more often than they actively pursue wrong goals — meaning Stoke's convergence loop needs proactive validation checks, not just reactive error handling. Third, the largest architectural gain documented in the literature comes not from smarter models but from **experiential learning** (reusing verified successful trajectories), suggesting Stoke's wisdom store should prioritize recording and retrieving proven solution patterns over general knowledge.

The cost ceiling for a multi-hour Stoke task — with model routing, stable caching breakpoints, graduated compaction, and sub-agent isolation — should fall in the **$2–$15 range** rather than the $50–$150 range of naive implementations. Cache-friendly prompt architecture is not an optimization but a prerequisite: the difference between 60% and 99% cache hit rates represents a 10× cost difference. Build for cache stability from day one.