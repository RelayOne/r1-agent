# Designing the UX of autonomy for AI coding agents

**The central tension in autonomous coding UX is not how much to show, but when and at what grain.** Research consistently finds an inverted-U relationship between transparency and trust — moderate transparency outperforms both opacity and information dumps. For Stoke, this means the CLI and dashboard should default to structured, medium-granularity narration with progressive disclosure, interrupt developers only at semantic breakpoints, and use confidence-based escalation to route decisions to humans. The 10 questions below converge on a single design philosophy: **calibrate the interface to the stakes of each moment**, not to a fixed transparency setting.

The evidence draws on 60+ peer-reviewed papers (CHI, Human Factors, CSCW, IEEE TVCG), Nielsen Norman Group guidelines, and practitioner patterns from Cursor, Devin, Claude Code, and Aider. Each section closes with concrete design guidance for a CLI + dashboard harness.

---

## 1. Progress visibility: streaming beats silence, but step-lists beat progress bars

Nielsen Norman Group's research establishes three time thresholds: **0.1 seconds** (feels instant), **1 second** (flow maintained), and **10 seconds** (attention lost). Anything beyond 10 seconds demands a percent-done indicator and a way to interrupt. For multi-hour agent tasks, a spinner is catastrophically insufficient. NNg's 2021 field study of long-running professional tools found that users who see only a spinning icon interpret stalled progress as a crash. The key recommendation: show the **name of the current step**, percentage or step count, and estimated remaining time.

Streaming output reduces perceived wait time significantly. Users rate streaming responses as "faster" even when total elapsed time is identical — a finding replicated across ChatGPT, Claude, and multiple LLM interfaces. The psychological mechanism is simple: occupied time feels shorter than unoccupied time. Claude Code's tool-call-by-tool-call streaming exploits this effect, giving developers continuous evidence that the agent is working.

However, for multi-hour tasks, raw streaming creates a different problem. A 2023 PMC review of information overload in monitoring contexts found that continuous data streams overwhelm supervisory attention, and Endsley's situation awareness research (1995, 1996) documents how passive monitoring degrades comprehension. The solution is **step-based progress, not continuous streaming**: show completed subtasks as a checklist, display the current step name, and provide estimated remaining steps. NNg's long-wait guidelines explicitly warn against "overburdening users with overly detailed information about system actions" while still showing current step and percentage.

The research also reveals a counterintuitive finding: for very long tasks, a constant-speed progress bar can **increase** abandonment because it "underscores the longer-than-expected duration" (Conrad et al., 2010). Step-based progress avoids this by chunking time into discrete accomplishments rather than a discouraging slow crawl.

**Design guidance for Stoke.** In the CLI, show a step checklist that updates in real time: completed steps get checkmarks, the current step shows a spinner with its name, and upcoming steps are listed dimly. Offer background execution after 60 seconds with push notification on completion. In the dashboard, show a task timeline with expandable detail per step. Rich completion summaries should include start time, elapsed time, files changed, tests run, and errors encountered — the full context developers need to reorient after stepping away.

---

## 2. Trust builds on performance, not explanation — but progressive autonomy accelerates it

Hancock et al.'s meta-analyses (2011, 2016, 2021) across 29+ studies deliver a blunt finding: **system performance is the dominant driver of trust**, far outweighing human-related factors like personality or training. The overall effect size for robot/system performance on trust was r̄ = +0.26 (correlational) and d̄ = +0.71 (experimental). This means the single highest-leverage investment for trust is making the agent actually work well before worrying about UI polish.

Lee and See's foundational framework (2004, 2,300+ citations) defines trust as "an attitude that an agent will help achieve an individual's goals in a situation characterized by uncertainty and vulnerability." They identify three bases: **performance** (what it does), **process** (how it works), and **purpose** (why it was created). Trust and reliance form a dynamic feedback loop — outcomes update trust, which informs future reliance decisions. Miscalibrated trust leads to either **misuse** (overtrust: accepting buggy code) or **disuse** (undertrust: ignoring good suggestions).

Parasuraman, Sheridan, and Wickens (2000) established that automation is not all-or-nothing. Their four-function model — information acquisition, information analysis, decision selection, and action implementation — allows different autonomy levels per function. A coding harness can fully automate context gathering (Level 9–10) while requiring human approval for production code changes (Level 5). This maps directly to how Claude Code's permission system works: auto-approve file reads, require confirmation for edits.

The strongest practitioner pattern for trust-building is **progressive autonomy**. Smashing Magazine's 2026 survey of agentic AI patterns identifies six core UX patterns, with the most powerful being the **autonomy dial** (user-defined boundaries) and **action audit with undo** ("the single most powerful mechanism for building user confidence is the ability to easily reverse an agent's action"). The three current trust architectures in coding tools each represent a valid approach:

- **Real-time transparency** (Cursor): trust through continuous visibility of changes in the IDE
- **Delegation with checkpoints** (Devin): trust through structured review of completed work
- **Earned autonomy escalation** (Claude Code): trust through progressive permission grants, starting restrictive and loosening over time

Anthropic's empirical data validates the progressive model: experienced Claude Code users auto-approve **40%+ of sessions** (up from 20%) but also interrupt more often (9% vs 5% of turns). This shift from step-by-step approval to autonomous-with-intervention represents mature oversight, not abdication.

**Design guidance for Stoke.** Start new users in suggest-and-confirm mode. Track acceptance rate per user; when it exceeds 85%, offer to escalate autonomy. Surface historical performance metrics prominently ("87% of changes passed tests on first try"). Make git-based undo trivially accessible — one keystroke in CLI, one click in dashboard. Let users set different autonomy levels per function: fully autonomous for test generation, human-confirms for API changes, plan-only for database migrations.

---

## 3. Narration granularity: the SAT model points to structured events with reasoning

The Situation Awareness-based Agent Transparency (SAT) model (Chen et al., 2014, U.S. Army Research Laboratory) provides the most rigorous framework for agent narration. It defines three levels of information that should be communicated:

- **SAT Level 1**: What the agent is currently doing (actions, plans, perceptions)
- **SAT Level 2**: Why it chose that action (reasoning, rationale)
- **SAT Level 3**: What it expects to happen next (projections, uncertainty)

Experimental studies using this model (Mercado et al., 2016; Selkowitz et al., 2017) found that **all three levels together produced the greatest trust calibration** without increasing workload or decreasing usability. This is a critical finding: adding reasoning and projection to action narration helps without hurting.

Mapping the four major coding tools to this framework reveals that none fully implements all three levels:

| Tool | Level 1 (Actions) | Level 2 (Reasoning) | Level 3 (Projection) |
|---|---|---|---|
| Claude Code | ✅ Every tool call shown | ⚠️ Partial (thinking mode) | ❌ No projection |
| Devin | ✅ Step-by-step log | ✅ Design spec reasoning | ⚠️ Implicit via plan |
| Cursor | ✅ Agent steps shown | ⚠️ Limited | ❌ No projection |
| Aider | ❌ After-the-fact only | ❌ None real-time | ❌ None |

Endsley's situation awareness research (1995) warns that full automation reduces SA, with Level 2 (comprehension) most negatively impacted. Batch-only approaches like Aider's maximize the "out-of-the-loop" problem. But pure streaming like Claude Code's creates the opposite risk: information overload during multi-hour sessions leading to vigilance fatigue.

The CHI 2020 study by Gero et al. on mental models of AI agents found that **observing agent behavior** is necessary for building accurate mental models — understanding the technology alone is insufficient. This supports narration over silence, but the narration must help developers understand the agent's capabilities and limitations, not just its moment-to-moment actions.

**Design guidance for Stoke.** Implement a three-layer narration architecture. The **default CLI view** should show SAT Level 1+2: current action plus a one-line rationale ("Editing auth.py — adding input validation because login endpoint lacks sanitization"). The **expanded view** (toggled with a keystroke) should add SAT Level 3: upcoming planned steps and confidence. The **dashboard** should show all three levels in a collapsible timeline. This matches the progressive-disclosure pattern that NNg research shows reduces cognitive load by approximately 55%.

---

## 4. Checkpoint timing: semantic breakpoints, not fixed intervals

The cost of interrupting a developer is staggeringly high. Gloria Mark's research at UC Irvine found it takes **23 minutes and 15 seconds** on average to fully regain focus after an interruption, extending to **45 minutes** for complex coding tasks. Interrupted tasks take twice as long and contain twice as many errors. Sophie Leroy's "attention residue" concept shows that cognitive remnants of the previous task persist for 30–60 minutes.

This means every checkpoint request from the agent imposes a massive tax on developer productivity. The asymmetry is clear: **agent compute is cheap; developer attention is expensive**. The harness should bias heavily toward agent autonomy for routine decisions.

Iqbal and Bailey's research on breakpoints in task execution (2005–2008) provides the solution. Tasks have a hierarchical structure with three granularities of natural pauses: **coarse** (between major phases), **medium** (between subtasks), and **fine** (between micro-steps). Interrupting at coarse breakpoints causes the least disruption — lowest resumption lag, frustration, and error rate. Mental workload transiently decreases at subtask boundaries, creating natural windows for attention.

Horvitz's 12 principles of mixed-initiative interaction (CHI 1999) add nuance. Principle 3 urges consideration of "status of user's attention in timing" — defer non-urgent actions to less distracting moments. Principle 8 advocates "graceful degradation of service scope" — under uncertainty, the agent should do less with higher confidence rather than more with lower confidence. Principle 7 demands minimizing the cost of poor guesses through easy rejection and rollback.

Anthropic's empirical data on Claude Code validates these principles. Agent-initiated pauses for clarification already exceed human-initiated interruptions, especially on complex tasks (2× more frequent). As task complexity grows, step-by-step approval becomes impractical: only **67%** of tool calls on high-complexity tasks involve human interaction, versus 87% on simple tasks. The natural evolution is toward fewer, more meaningful checkpoints.

**Design guidance for Stoke.** Implement **event-driven checkpoints**, not time-driven ones. The agent should pause at semantic boundaries: after completing a logical subtask, after test results (pass or fail), before irreversible actions (deployments, database changes, external API calls), and when confidence drops below a threshold. Use a three-tier urgency model: **immediate** (irreversible/risky actions require approval now), **batched** (non-urgent decisions queued for next natural breakpoint), and **async** (informational updates sent to dashboard for review whenever convenient). Start with more frequent checkpoints for new users; reduce frequency as acceptance rate demonstrates trust calibration.

---

## 5. The transparency inverted-U: medium detail beats both opacity and full disclosure

Kizilcec's 2016 CHI study is the foundational finding here. In a MOOC peer-grading context with 103 participants, three transparency levels were tested. When expectations were violated (grade lower than expected), **medium transparency** (explanation of the algorithm) increased trust. But high transparency (explanation plus raw data) produced trust levels **equal to or lower than** low transparency. The mechanism: excessive information gave users more material to construct negative narratives.

This inverted-U has been replicated and extended. Ngo (2025) confirmed the quadratic relationship across 491 participants in two AI tasks, finding that "moderate transparency fosters trust and certainty, but excessive transparency leads to cognitive overload and heightened scrutiny." A parallel-mediation study (PMC, 2022) identified the dual pathway: transparency increases trust via perceived effectiveness but simultaneously decreases trust via discomfort. The net effect peaks at moderate levels.

A 2025 arXiv paper formalizes this as the "Transparency Paradox" through the HIAG framework. The key mechanism: information provision triggers metacognitive processing that depletes cognitive resources. Working memory capacity (approximately 4 items) creates a natural limit. Benefits of explanation plateau at about **2 explanation dimensions** — beyond this, performance degrades regardless of trust levels.

Lim and Dey's research (CHI 2009, UbiComp 2011) on intelligible AI adds an important caveat: **"Why" explanations provide the most benefit**, while "Why Not" is second-best. But when the system is highly uncertain about its actions, intelligibility can be actively harmful — explaining shaky reasoning highlights its shakiness.

The most actionable finding comes from the PMC review "How Transparency Modulates Trust in Artificial Intelligence" (2022): **giving users control does more for trust than giving them explanations**. "Provided that they can modify its forecasts, users are apparently willing to take an algorithm seriously even after seeing it make occasional mistakes. The precise degree of control seems irrelevant."

**Design guidance for Stoke.** Default to medium transparency: show what the agent did and why, but not internal chain-of-thought or token-level reasoning. Make detailed internals available through progressive disclosure (expand in dashboard, `--verbose` flag in CLI) but never force them. Prioritize editability and control over explanation depth — a "take over here" command does more for trust than any amount of reasoning display. Implement adaptive transparency: show more detail to users who request it, less to those who don't. Never show raw model internals by default.

---

## 6. Event filtering: a three-category taxonomy with role-based routing

For a hub-and-spoke agent architecture, the fundamental challenge is signal-to-noise ratio. Alert fatigue research consistently finds that **80–95% of monitoring alerts are false positives** (ScienceDirect, 2024; medical research). When alert volume is too high, operators start ignoring everything — including genuine critical events. The consequences compound: diminished trust, reduced productivity, increased errors, and burnout.

Signal Detection Theory provides the analytical framework. The optimization target is minimizing **misses** (critical events the user never sees) while tolerating **correct rejections** (routine events properly suppressed). For a coding harness, file corruption and test failures are high-miss-cost events; token usage updates and internal agent planning decisions are low-miss-cost events.

Synthesizing log-level patterns, monitoring tool practices (Datadog, Dynatrace, ServiceNow), and agent observability platforms (Langfuse), a three-category event taxonomy emerges:

- **Decision events** (agent reasoning, planning, strategy selection): Surface as collapsed summaries in CLI, expandable in dashboard. Example: "Chose to refactor auth.py before routes.py"
- **Execution events** (concrete actions on codebase/environment): Surface in real-time with progressive detail. Example: "Edited auth.py: added input validation (+12 lines)"
- **Diagnostic events** (internal health, performance, resources): Dashboard metrics only; surface only on threshold breach. Example: "Token consumption: 45K of 100K budget"

The mapping to traditional log levels: FATAL/ERROR → immediate user notification in CLI; WARN → collapsed/batched notification; major INFO milestones → CLI progress feed; detailed INFO → dashboard stream; DEBUG/TRACE → audit log only.

Dashboard information architecture research shows that users process **5–9 elements** effectively, and dashboards exceeding 12 KPIs show a **40% engagement drop**. Eye-tracking studies confirm the F-pattern: top-left receives 80% of attention. The 40-30-20-10 rule allocates screen real estate proportionally to information priority.

**Design guidance for Stoke.** In the CLI, show only execution events and high-severity decision events by default. Use color-coded prefixes: red for errors, yellow for warnings/decisions requiring input, green for completed steps, dim gray for informational. In the dashboard, implement a three-panel layout: left panel shows task tree (execution events), right panel shows live event stream (all categories, filterable), bottom panel shows diagnostics (metrics, cost, tokens). Support role-based views: the developer hands-on with the agent sees file changes and test results; the tech lead reviewing sees task completion and quality metrics; the platform engineer sees system health and cost trends.

---

## 7. Presenting uncertainty: categorical signals outperform numeric confidence

Zhang et al. (2020) found that calibrated confidence scores help users calibrate trust, but only when the scores themselves are well-calibrated. Ma et al. (2024) showed that miscalibrated confidence is actively dangerous: overconfident AI induces over-reliance, while underconfident AI causes underuse. The implication is stark — **if you can't calibrate confidence precisely, don't show precise numbers**.

The automation bias problem compounds this. Pearce and Tan's Black Hat 2022 analysis found that GitHub Copilot suggestions contained exploitable vulnerabilities approximately **40% of the time**, yet developers exhibit strong automation bias — blindly accepting top-ranked suggestions like clicking the first search result. GitClear's analysis of 153 million changed lines found "code churn" (lines reverted within two weeks) projected to double in 2024 versus pre-AI baselines, suggesting developers accept AI-generated code uncritically and fix it later.

Doula et al. (2022) found that most users would trust AI systems **more** when uncertainty is shown, but this interacts with the inverted-U: moderate uncertainty signals help, excessive detail hurts. The CURE2026 workshop at IUI confirms that uncertainty communication remains an active, unsolved research area, noting that users "often get confused or misinterpret uncertainty information due to poorly designed interfaces."

The distinction between epistemic and aleatory uncertainty matters for actionability. Epistemic uncertainty ("I don't know enough about this codebase") is reducible — the developer can provide more context. Aleatory uncertainty ("this approach might or might not work due to external factors") is irreducible — the developer should test. Communicating these differently enables appropriate responses.

Kornowicz (2025) found that confidence-based delegation at an optimal threshold (τ = 0.70) significantly improved human-AI team performance. A key recommendation: "Explanations could be shown for low-confidence cases to assist human judgment, and withheld for high-confidence cases to reduce cognitive load."

**Design guidance for Stoke.** Use **categorical confidence signals**, not percentages: ✓ (confident, proceeding), ⚠️ (uncertain, review recommended), ✗ (failed, action needed). Differentiate uncertainty types: "⚠️ Unfamiliar pattern — review recommended" (epistemic) versus "↺ Multiple valid approaches — chose X, but Y also viable" (aleatory). Implement confidence-based escalation: auto-proceed above threshold, pause for review below. In the CLI, color-code by confidence. In the dashboard, aggregate confidence across subtasks to show which parts of the work need the most review attention. Never express uniform high confidence across all actions — the variation itself is the trust-building signal.

---

## 8. Interruption handling: cooperative by default, preemptive as escape hatch

McFarlane's taxonomy (2002) identifies four interruption coordination methods: immediate, negotiated, mediated, and scheduled. His experimental finding is clear: **negotiated interruption is the best overall method** — lowest error rate, highest user satisfaction. The user is notified of the pending interruption and controls when to handle it.

For an autonomous agent, this translates to two modes. **Cooperative interruption** (negotiated): the user signals a desire to redirect, the agent acknowledges immediately but finishes its current atomic operation, then presents its state and asks how to proceed. **Preemptive interruption** (immediate): the user forces an instant halt via Ctrl+C, and the system preserves state via checkpoint. Both should auto-create a checkpoint.

Altmann and Trafton's Memory for Goals model (2002) explains why interruption handling matters so much. When a task is interrupted, the primary goal decays in memory while interfering goals from the new activity strengthen. An **8-second interruption lag** — letting the agent finish its current step — saved approximately 4 seconds at resumption. Environmental cues are critical: blatant cues (prominent markers showing "you were here, this was next") dramatically outperform subtle ones.

Parnin and DeLine (CHI 2010) surveyed 371 programmers on task resumption. Only **10% of sessions** resume programming in under a minute after interruption. Developers rely heavily on notes, open windows, and deliberate reminder cues (some even leave compile errors as bookmarks). Automated chronological code-change cues **doubled** task resumption success. Developers strongly preferred chronological change sequences over aggregated summaries.

For rollback, four patterns emerge from practice. Claude Code uses **checkpoint-and-rewind** (automatic snapshots before each edit). IBM Research's STRATUS system uses **transactional-no-regression** (only reversible changes allowed, each action has an undo operator), outperforming alternatives by 150%+ on benchmarks. The **compensating transaction** pattern from distributed systems handles irreversible external effects. And **selective/surgical rollback** (DiffBack) lets users accept or reject individual file changes.

**Design guidance for Stoke.** Support both interruption modes: single `Esc` for cooperative (finish current step, present state), double `Esc` for preemptive (immediate halt). On any interruption, auto-commit a git checkpoint and save a resumption context file containing: completed subtasks, current step, planned next steps, and key decisions made. Present a clear partial-completion view: task tree with ✓ (done), ⟳ (in-progress), and ○ (planned). When resuming, show chronological change history — not just a diff — with prominent "you were here" markers. Implement layered rollback: git commits per subtask, file-level snapshots, selective per-file revert, and compensating actions for external API calls.

---

## 9. Explanation design: contrastive, selective, and on-demand

Tim Miller's landmark 2019 paper "Explanation in Artificial Intelligence: Insights from the Social Sciences" establishes four principles drawn from decades of cognitive science. **Explanations are contrastive**: people ask "Why X rather than Y?" not just "Why X?" — the foil (the expected but non-occurring event) is essential. **Explanations are selected**: people pick one or two causes from potentially infinite causal chains; complete chains are useless. **Explanations are social**: they require shared understanding between explainer and audience. And **probabilities are secondary**: people prefer causal and mechanistic reasoning over statistical evidence.

Buçinca et al. (CHI 2025) validated contrastive explanations experimentally, finding they are "less complex and cognitively demanding than unilateral ones" and can improve knowledge acquisition from AI-assisted decisions.

The cost-benefit framework from Vasconcelos et al. (CSCW 2023, Stanford, N=731) formalizes when explanations work. Explanations reduce overreliance only when the **cognitive cost of checking the explanation is lower than the cost of evaluating the task directly**. If both the task and the explanation are complex, users default to trusting the AI without checking. The practical implication: make explanations cheaper to verify than reading the code.

Under realistic workloads, explanation usage drops to approximately **10%** (Alami et al., 2025, Human Factors). Users express appreciation for explanations in interviews but consistently ignore them in practice when cognitive resources are strained. Optional "explain" commands are insufficient — lightweight verification must be built into the default flow.

For developer-specific contexts, Yan et al.'s Ivie system (CHI 2024) demonstrates the power of **anchored explanations** — brief labels positioned adjacent to generated code, spatially linked rather than presented in a separate panel. In lab studies, Ivie improved comprehension while decreasing perceived task load. Mozannar et al. (CHI 2024) quantified the "explanation tax": programmers dedicate **22.4% of coding time** to verifying AI suggestions.

CopilotLens (2025) introduces a pragmatic two-level framework: Level 1 shows a high-level summary of file modifications, Level 2 shows specific codebase influences behind a single change. Crucially, explanations are generated **post-hoc** — after the agent acts — to avoid slowing execution.

**Design guidance for Stoke.** Frame all explanations contrastively: "Used async/await instead of callbacks because the codebase already uses Promises throughout." Keep to 1–2 causal factors, never full reasoning chains. Generate explanations post-hoc so they don't slow agent execution. In the CLI, show a one-line contrastive rationale per action by default; support `--explain` for full reasoning. In the dashboard, anchor explanations to specific code locations using the Ivie pattern. Don't rely on users seeking explanations — build lightweight verification into the default flow by showing compact diffs with annotations as the primary output format.

---

## 10. Benchmarking dashboards: separate model from harness, show multiple benchmarks, enable user-weighted comparison

SWE-bench (Jimenez et al., ICLR 2024 oral) is the standard, but a critical insight from Vals.ai reveals the evaluation's dual nature: it measures both the agent harness and the underlying model simultaneously. Different harnesses on the same model produce score differences of **~10 percentage points**. A benchmarking dashboard for Stoke must separate these dimensions.

Benchmark contamination is a serious threat. SpecWeave's 2026 analysis found that MiniMax M2.5 scored 80.2% on SWE-bench Verified but only **39.6% on SWE-rebench** (fresh, uncontaminated problems) — a 40-point gap invisible on the established benchmark. SWE-bench Pro (Scale Labs) shows similar compression: models scoring 70%+ on the verified version score only **23%** on harder tasks. A credible dashboard must show multiple independent benchmarks and flag contamination risk.

Goodhart's Law looms large. A comprehensive arXiv review (Feb 2025) concluded that AI benchmarks "promise too much, are gamed too easily, measure the wrong thing, and are ill-suited for practical use." The LMArena controversy demonstrated that model developers will game crowdsourced leaderboard scores when incentivized. Nisslmüller's four stress tests for metrics — "If we doubled the incentive, how would people game it?" — provide a practical framework for evaluating benchmark integrity.

Pandey et al.'s research on persuasive visualization (IEEE TVCG, 2014) found that charts are significantly more persuasive than tables for the same data, with the strongest effect on people with no prior opinion. A 2024 arXiv study showed that visual annotation (bounding boxes, trend lines) is more effective than highlighting (color manipulation) for guiding reader conclusions. These findings directly inform dashboard design choices.

Developer-facing benchmark comparisons (SitePoint, AIMultiple, Builder.io, Render) converge on seven primary metrics: **accuracy/correctness** (first-pass test pass rate), **speed** (wall-clock time), **cost** (per-task and monthly), **context window** (effective, not advertised), **autonomy level** (interventions needed), **multi-file capability**, and **language coverage**. Secondary metrics include token efficiency, cost-efficiency ratio (accuracy per dollar), and consistency across runs.

**Design guidance for Stoke.** Structure the benchmarking dashboard around three principles. First, **show multiple benchmarks** side by side (SWE-bench Verified, SWE-rebench, Aider Polyglot, custom internal benchmarks) with contamination flags and methodology links. Second, **separate model from harness** — let users see how the same model performs across different harnesses, and how the same harness performs across different models. Third, **enable user-weighted comparison** — provide sliders that let potential users weight accuracy vs. speed vs. cost based on their priorities, dynamically reranking harnesses. Use the F-pattern layout: primary accuracy comparison (bar chart) top-left, cost-efficiency scatter plot top-right, task-complexity breakdown middle, trend lines showing improvement trajectory bottom-left, and sortable detail table with methodology notes bottom-right. Include confidence intervals on all bars, version/date stamps on all data, and a persistent "Known Limitations" panel. Link to raw data and reproduction scripts — transparency about benchmarking methodology is itself a trust-building mechanism.

---

## Cross-cutting design principles for Stoke

Five principles emerge from the convergence of all ten research streams.

**Calibrate to stakes, not to a fixed setting.** The right amount of transparency, explanation, and interruption frequency depends on the consequence of the current action. A test file edit warrants minimal narration and no checkpoint; a database migration warrants full plan preview, explicit approval, and detailed rollback preparation. Confidence-based escalation (auto-proceed above threshold, pause below) operationalizes this in code.

**Control trumps explanation.** Across trust, transparency, and explanation research, the consistent finding is that user control — the ability to edit, revert, redirect, and take over — does more for trust than any amount of reasoning display. Git-based undo, selective file revert, cooperative interruption, and the autonomy dial are the foundational UX primitives.

**Progressive disclosure is the universal pattern.** From NNg's 55% cognitive load reduction to the SAT model's three transparency levels to CopilotLens's two-level explanation framework, the pattern recurs everywhere: show a scannable summary by default, make detail available on demand, never force full detail on passive monitors.

**Invest in performance before UI.** Hancock's meta-analyses show system performance dominates trust formation. The most beautiful dashboard cannot compensate for an agent that breaks code. Ship accuracy first, then polish the narration. Surface performance metrics (test pass rate, acceptance rate, reversion rate) prominently — these are the numbers that build trust.

**Design for resumption, not just execution.** Multi-hour tasks will be interrupted — by the user, by the system, by life. Every design decision should assume the developer will leave and come back. Chronological change logs, blatant resumption cues, rich completion summaries, and persistent context files are not nice-to-haves; they are core infrastructure for an autonomous harness operating at the multi-hour timescale.