# The economics of autonomous AI coding agents

**Autonomous AI coding agents cost $0.09–$20 per task on standard benchmarks, are 3–20× cheaper than human developers for well-scoped work, but costs grow exponentially with task complexity.** For Stoke's multi-agent architecture with orchestration, verification, and convergence loops, the realistic cost multiplier over a single-agent run is **2–5×** — reducible to **1.5–3×** with aggressive prompt caching (90% input savings), model routing, and dynamic turn limits. The critical variable is not per-token cost but *agent reliability half-life*: improving the half-life from 1 hour to 5 hours yields **10× more value than cutting per-step cost by 25×**, because it acts on the exponent of the success probability decay function.

This report synthesizes data from Epoch AI, METR, SWE-bench leaderboards, and 30+ academic papers to provide defensible cost data across all 12 requested dimensions.

---

## 1. Per-task costs span three orders of magnitude

Published benchmark data reveals enormous cost variation depending on model, scaffold, and caching configuration. On SWE-bench Verified and SWE-rebench, per-task costs range from **$0.01 to $20**:

| Agent / Model | Cost per Task | Resolve Rate | Benchmark |
|---|---|---|---|
| Moatless Tools + DeepSeek V3 | $0.01 | 30.7% | SWE-bench |
| MiniMax M2.5 | $0.09 | 80.2% | SWE-bench Verified |
| Moatless Tools + Claude 3.5 Sonnet | $0.14 | 39% | SWE-bench |
| Agentless | $0.34 | ~50.8% | SWE-bench |
| GPT-5 Codex | $0.51 | Strong | SWE-rebench |
| AutoCodeRover (GPT-4o) | $0.70 | 19% | SWE-bench Lite |
| Claude Sonnet 4 (with caching) | $0.91 | Strong | SWE-rebench |
| Claude Sonnet 4 (no caching) | $5.29 | Same | SWE-rebench |
| Claude Opus 4.5 | $1.15 | 80.8% | SWE-rebench |
| AIDE (SWE-search) | ~$20 | 62.2% | SWE-bench Verified |

Caching makes a **5.8× difference** on identical tasks — Claude Sonnet 4 drops from $5.29 to $0.91 per problem simply by enabling prompt caching. Epoch AI tracks token usage across benchmarks and reports the price for a given SWE-bench performance level has decreased **~5–10× annually**, though total evaluation costs have stayed flat because frontier models consume substantially more inference compute. The SWE-Effi paper found **failed tasks consume 4× more resources than successful ones**, creating a "token snowball effect" where context accumulates as the agent spirals.

For METR's RE-bench (AI R&D tasks), agents are evaluated under wall-clock time limits (30 minutes to 8 hours) with token budgets of 2–16M tokens. METR's key finding: **AI agents achieve 4× higher scores than human experts at 2-hour budgets**, but humans outperform at 32 hours. The full HCAST evaluation suite (131 tasks × 8 runs) cost $6,677 in GPT-4 API fees.

---

## 2. Cost grows exponentially with task duration — and the half-life is everything

METR's landmark paper (Kwa et al., arXiv:2503.14499) established that the **50% task-completion time horizon has been doubling every ~7 months** since 2019, possibly accelerating to ~4-month doublings. Current frontier models achieve near-100% success on tasks taking humans under 4 minutes but **below 10% on tasks exceeding 4 hours**.

Toby Ord's analysis of METR's data revealed model-specific cost "sweet spots" where hourly rates are minimized: **Grok 4 at $0.40/hour**, GPT-5 at $13/hour for 45-minute tasks, and o3 at ~$40/hour. At saturation, costs escalate dramatically — o3 reaches **$350/hour**, exceeding typical human developer rates of $120/hour. The pattern is clear: there exists a sweet spot, and pushing beyond it yields exponentially diminishing returns.

The exponential cost wall emerges from a constant-hazard-rate model of agent reliability. Margot Stakenborg's BOTEC model on the EA Forum quantifies this precisely:

| Task Length | P(success) | Agent Cost/Success | Human Cost | Ratio |
|---|---|---|---|---|
| 15 minutes | 96.6% | $9.90 | $37.50 | **0.26×** |
| 1 hour | 87.1% | $42.70 | $150 | **0.28×** |
| 4 hours | 57.4% | $194.91 | $600 | **0.32×** |
| 8 hours | 33.0% | $597.05 | $1,200 | **0.50×** |
| 16 hours | 10.9% | $3,286 | $2,400 | **1.37×** |
| 24 hours | 3.6% | $15,574 | $3,600 | **4.33×** |

**The crossover occurs around 12–16 hours** with a 5-hour half-life. Cutting cost per step from $0.25 to $0.01 (a 25× reduction) improves the ratio by ~9×, but improving half-life from 1 to 5 hours improves it by ~90×. For Stoke, this means engineering reliability — via the Honesty Judge and convergence loop — delivers roughly **10× more economic value than optimizing per-token costs**.

Gus Hamilton's Weibull reanalysis suggests actual hazard rates may be *declining* (κ ≈ 0.6–0.9), meaning agents that survive early steps become progressively less likely to fail. This creates fatter survival tails than the exponential model predicts — somewhat better news for longer tasks.

---

## 3. Fail fast beats try harder — with a narrow retry window

The pass@k framework quantifies the retry tradeoff directly. On SWE-bench Verified, **pass@1 = 76.1%** and **pass@3 = 81.2%** — a 5.1 percentage point gain from two additional attempts, with roughly two-thirds of the incremental gain coming from the first retry alone. Diminishing returns are inherent in the formula pass@k = 1 − (1−p)^k.

Kalayci et al. (arXiv:2510.01394) formalize this as a Pandora's Box optimal stopping problem. Their UCB-style adaptive stopping algorithm achieves the **same performance as non-adaptive Best-of-N while requiring 15–35% fewer generations**. The key insight: gains from retries are largest when per-attempt costs are low.

Production systems converge on three practical strategies. First, **parallel best-of-N**: Cursor runs hundreds of concurrent agents per project, and OpenAI recommends "run Codex four times on the same task, compare the outputs." Second, **fresh starts over continued retries**: context pollution and tunnel vision make restarting superior to persisting, because accumulated context compounds errors. Third, **budget-conditioned search**: the BAVT framework (arXiv:2603.12634) uses remaining resource ratio as a scaling exponent, providing parameter-free transition from exploration to exploitation as budget depletes.

The prompt engineering parallel is instructive: the first 5 hours of prompt optimization yield **35% improvement**, the next 20 hours yield 5%, and the next 40 yield 1%. When "whack-a-mole" failures appear — fixing case A breaks case B — the problem is architectural, not solvable through retries.

---

## 4. The cost-quality Pareto frontier is remarkably flat at the top

The documented gap between cheapest and most expensive frontier coding models is **25× in price** but only **0.6 percentage points in SWE-bench accuracy** (MiniMax M2.5 at $0.30/$1.20 per MTok achieving 80.2% versus Claude Opus 4.6 at $5/$25 achieving 80.8%). This near-flat Pareto frontier at the top means marginal accuracy gains are extraordinarily expensive.

The DataRobot syftr framework (2025) confirmed this pattern across broader GenAI workflows: **the "knee point" of the Pareto frontier loses just a few percentage points in accuracy while being 10× cheaper**. GPT-4o-mini frequently appears in Pareto-optimal flows. FrugalGPT (Stanford) demonstrated matching GPT-4 performance with **up to 98% cost reduction** through LLM cascades, sending only 16.6% of queries to the expensive model.

For Stoke's architecture, the practical implication is model routing. The documented "80/20 rule" — Sonnet for 80% of coding, Opus for the 20% requiring deep reasoning — reduces costs **60–80%** versus all-Opus. Claude Code's own `opusplan` mode implements this: Opus for planning, Sonnet for implementation. Morph Router classifies prompts by complexity in ~430ms at $0.001/request, routing 60% to Haiku, 30% to Sonnet, and 10% to Opus, achieving **40–60% cost savings**.

One critical caveat from Zellinger and Thomson (Caltech): most cascades **underperform standalone large models** once the cost of an error exceeds $0.10. Only cascades with excellent uncertainty calibration outperform. This means Stoke's Honesty Judge must be well-calibrated — not just accurate — for routing to work.

---

## 5. Eight subscriptions should use a hybrid API-plus-Max strategy

Anthropic's current pricing creates a stark arbitrage between subscription and API access. One developer tracked **10 billion tokens over 8 months costing $15,000+ at API rates but only ~$800 on the Max plan**. A Max 20× subscription at $200/month delivers approximately $3,650/month in equivalent API value. However, as of April 2026, subscription quotas **only cover official Anthropic tools** (Claude Code CLI, claude.ai, Desktop) — third-party tools require API keys or "extra usage" billing.

For 8 subscriptions, the optimal allocation depends on Stoke's architecture:

- **API organizations** provide independent rate limits (RPM, ITPM, OTPM per model). Eight API organizations with weighted round-robin load balancing and circuit breakers yield ~8× single-organization throughput. Cached tokens do not count toward ITPM limits, so with 80% cache hit rates, effective throughput is **10M total input tokens per minute** against a 2M ITPM limit.
- **Max subscriptions** make economic sense only for interactive Claude Code CLI work, not for programmatic agent orchestration.
- **The hybrid optimum**: 2–3 Max subscriptions for developers doing interactive work, 1 Tier 4 API organization for Stoke's automated agents, with workspace-level spend limits and per-model rate limit monitoring via response headers (`anthropic-ratelimit-tokens-remaining`).

Batch API processing (50% discount, separate rate limit pool) should handle any non-latency-sensitive workloads. Combined with prompt caching (90% on inputs) and model routing (40–60%), total savings can reach **85–95% versus naive all-Opus API usage**.

---

## 6. Prompt caching alone delivers 81% cost reduction — additional layers compound

Claude Code's production architecture proves the primacy of provider-level prompt caching: **92% cache hit rate, 81% cost reduction, 79% latency reduction**. Anthropic treats cache hit rate drops as SEV incidents. The architectural constraint is absolute: static content first, dynamic content last; never modify tools, model, or system prompt mid-session.

Beyond provider caching, three additional layers apply to autonomous coding agents. **Semantic caching** (GPTCache, Redis LangCache, AWS ElastiCache) achieves 60–87% hit rates on chatbot-style queries with **73–86% total cost reduction**, though its applicability to coding agents is limited by the context-dependent nature of code queries. AWS ElastiCache benchmarks on 63,796 real queries show a 0.95 similarity threshold achieves 56% hit rate at 92.6% accuracy and 51.9% cost savings.

**Agentic Plan Caching** (Zhang et al., NeurIPS 2025, arXiv:2506.14852) represents the frontier for agent-specific optimization: it extracts structured plan templates from completed agent executions and reuses them for similar tasks, achieving **50.3% cost reduction and 27.3% latency reduction** while retaining 96.6% of optimal performance at only 1.04% overhead. This is directly applicable to Stoke — recurring refactoring patterns, test generation, and bug-fix workflows would benefit from plan-level caching.

For coding-specific optimizations: sending diffs instead of full files yields **20–40× token savings**; `.claudeignore` files excluding build artifacts reduce tokens by 30–40%; periodic `/compact` commands prevent context bloat (at turn 50, typically 68% of context is dead weight). The layered approach — provider caching + file content caching + tool result caching + plan caching — compounds savings multiplicatively.

---

## 7. AI agents are already 3–20× cheaper for well-scoped tasks

METR's data shows **more than 80% of successful AI agent runs cost less than 10% of human equivalent cost** (benchmarked against $143.61/hour, the average L4 Google Engineer salary). For well-scoped migration and refactoring tasks, Cognition's Devin delivered **20× cost savings** at Nubank. GitHub Copilot studies show 55.8% faster task completion in controlled experiments.

However, METR's randomized controlled trial with 16 experienced open-source developers revealed a critical counter-finding: on mature codebases they deeply understood (1M+ lines), developers using AI tools took **19% longer** than without AI, despite perceiving a 20% speedup — a 39-point perception-reality gap. McKinsey reports more favorable aggregate data: 52% of organizations saw reduced engineering costs, with engineers writing code 35–45% faster and achieving 6 hours/week savings on average.

The task-type breakdown is decisive:

- **Boilerplate and migrations**: 10–20× cheaper with AI (strong evidence from Nubank, multiple studies)
- **Simple bug fixes**: 3–5× cheaper (moderate evidence)
- **Medium features**: Often cheaper but quality is variable
- **Complex tasks on mature codebases**: AI is NOT cheaper and may be slower (strong METR evidence)
- **Expert debugging on familiar code**: AI adds cost, not saves it

Epoch AI estimates inference costs at a fixed performance level are **halving every 2 months** (100× per year). This rate of deflation means the break-even frontier is shifting rapidly toward more complex tasks.

---

## 8. Stoke's multi-agent overhead will be 2–5×, reducible to 1.5–3×

Multi-agent systems consistently cost **2–5× more per task** than single-agent systems across academic and industry sources. Oracle reports agents consume 4× more tokens than standard chat, and multi-agent configurations can reach **15×**. Princeton NLP Group found single-agent systems matched or outperformed multi-agent systems on **64% of benchmarked tasks** when given equivalent tools and context.

For Stoke's specific architecture, each layer adds distinct overhead. The **hub orchestrator** adds one additional LLM call per task plus context marshaling; in AutoGen's conversational model, a 4-agent debate with 5 rounds is 20 LLM calls minimum, with context accumulating quadratically. The **Honesty Judge** verification layer effectively doubles the LLM cost for verified steps, though using a cheaper model (Haiku at $1/$5 versus Opus at $5/$25) reduces this to ~10–30% overhead. The **convergence loop** is the most dangerous cost amplifier: a Reflexion loop running 10 cycles can consume **50× the tokens of a single linear pass**, though dynamic turn limits cut costs by 24% while maintaining solve rates.

The optimized target for Stoke is **1.5–3×** over naked single-agent Claude Code, achievable through:

- **Prompt caching across all agents** (90% input savings, 75% latency reduction)
- **Dynamic critic selection** routing only relevant verification checks (30–50% savings on verification)
- **Convergence detection** to exit early when iterations stop improving
- **Model routing** within the system (Haiku for Honesty Judge, Sonnet for implementation, Opus for orchestration planning)
- **Maximum 3 convergence iterations** with hard budget caps

---

## 9. Over-conservative verification wastes 30–40% of compute on false positives

Roughly **one-third of AI code review suggestions require human verification** to determine relevance. An over-conservative verification layer that rejects 30% of valid outputs effectively increases costs by 1/(1−0.3) = **1.43× from rework alone**, before counting the verification computation itself. Combined with verification compute overhead (~1.5–2×), total cost impact of poorly calibrated verification reaches **2–3×**.

AI-assisted coding accuracy studies found popular AI assistants generate correct code only **31.1–65.2% of the time**, which creates pressure for aggressive verification — but over-calibrated quality thresholds in critic agents can trigger pathological behavior. In one documented CrewAI case, an agent's inner monologue began questioning whether additional filters should apply, triggering **35 tool calls instead of 5**.

For Stoke's Honesty Judge, three mitigation strategies are well-documented. **Dynamic critic selection** using keyword-based relevance scoring selects only applicable verification checks, achieving 30–50% cost savings. **Risk-tiered review** routes work by risk level — high-risk always escalates, low-risk relies on automated gates. Claude Code Review's approach uses multi-agent parallel analysis with a verification step that **checks candidates against actual code behavior** to filter false positives, rather than relying on LLM judgment alone. The **CheckEmbed** approach replaces full LLM verification with embedding-based comparison, reducing verification to embedding costs.

The target false positive rate for mature AI verification systems is **below 2%**. Organizations achieving this report 60% reduction in false positives and 40% faster incident response compared to uncalibrated systems.

---

## 10. Budget-aware agents outperform unlimited ones — the $10 threshold matters

**92% of businesses implementing agentic AI experience cost overruns**, with 71% lacking control and visibility into cost drivers (IDC Research). Linear cost models are too simplistic; costs must be modeled across best-, expected-, and worst-case scenarios including retries, context growth, and human review rates.

The BATS framework (Google/UC Santa Barbara, arXiv:2511.17006) demonstrates that providing agents with a continuous signal of resource availability **improves performance across budget constraints and pushes the cost-performance Pareto frontier outward**. Token-Budget-Aware LLM Reasoning (ACL 2025) shows that simply including a token budget in prompts can reduce reasoning token cost by "several times" with minimal performance loss.

The documented escalation framework that emerges from production deployments:

- **Under $1/task**: Fully autonomous, no intervention
- **$1–5/task**: Monitor and alert on anomalies
- **$5–10/task**: Flag for review, apply dynamic turn limits
- **Above $10/task**: Require human approval for continuation
- **Budget exhausted**: Hard stop and escalate

The **reserve-commit lifecycle pattern** (Cycles.io) provides the right architectural abstraction: before executing anything expensive, request a budget reservation for estimated cost; only proceed if the reservation succeeds; report actual cost after execution. This transforms budgets from billing metadata into runtime execution constraints. For Stoke, this means each agent within the convergence loop should have a pre-allocated token/dollar budget, with the orchestrator hub managing the global budget envelope.

Production stopping conditions should include maximum iteration limits, no-progress detection (exit when repeated iterations produce no new information), and goal-achievement checks. One critical heuristic from n8n's production AI playbook: "If a reviewer is approving 99% of outputs for a particular workflow, that's a strong signal you can move that step to autonomous with periodic spot-checks."

---

## 11. The break-even is task-dependent, but AI is already cheaper for most scoped work

At current pricing, AI coding assistants deliver **10× ROI nearly immediately** for any developer earning above $50K/year who saves more than 30 minutes per week. A developer making $120,000/year saving 2 hours/week recovers $2,400 in productivity against a ~$228/year Copilot subscription. Autonomous agents like Devin break even by replacing **3–4 hours/month** of developer work at $150/hour fully loaded cost.

The task-complexity break-even matrix, synthesized from METR and Toby Ord's analysis:

| Task Type | Human Cost | AI Agent Cost | AI Advantage |
|---|---|---|---|
| Boilerplate/migrations | $150–300 | $5–15 | 10–20× cheaper |
| Simple bug fixes | $75–300 | $10–50 | 3–5× cheaper |
| Medium features | $500–2,000 | $50–500 | Variable |
| Complex architecture | $2,000–10,000+ | $500–5,000+ | Not reliably cheaper |
| Greenfield prototyping | $5,000–20,000 | $200–2,000 | 5–10× cheaper with review |

Enterprise TCO is **2–3× the subscription sticker price** when accounting for integration ($50–150K), training (4–8 hours per developer at $75/hour), productivity dip during adoption (10–20% for 1–2 months), and CI/CD infrastructure updates. Realistic organizational productivity gains are **5–15%** — not the 50–100% claimed by vendors. McKinsey's Level 4 "AI agent factory" benchmark of "10× speed at half the cost" has been achieved at a large global bank, but represents the frontier, not the median outcome.

The decisive trend: inference costs falling 100× per year at fixed performance mean today's break-even frontier will shift dramatically within 6–12 months.

---

## 12. Report cost per success, not raw cost — the CLEAR framework sets the standard

The academic consensus is clear: **accuracy-only reporting creates a "distorted research landscape"** where expensive brittle solutions appear superior. The CLEAR framework (arXiv:2511.14136) proposes Cost-Normalized Accuracy (CNA = Accuracy / Cost × 100) and Cost Per Success (CPS = Total Cost / Successful Tasks) as primary metrics. Its validation showed CLEAR predicts production success with **ρ = 0.83 versus ρ = 0.41** for accuracy-only metrics.

The framework found agents with the highest raw accuracy cost **4.4–10.8× more** than Pareto-efficient alternatives, with a 2-point accuracy improvement potentially costing **$50,000 additional per 10,000 tasks**. SWE-Effi (arXiv:2509.09853) complements this with Effectiveness under Token/Cost/Time Budget curves, which plot resolution rate as a function of cumulative spending.

For Stoke's benchmarking, the defensible reporting standard should include:

- **Cost Per Success (CPS)**, not just cost per attempt — accounting for the cost of failures
- **Pareto frontier plots** of accuracy versus cost, identifying knee points
- **Token usage breakdown** separating input, output, reasoning, and cached tokens
- **pass@k metrics with minimum k=8** — single-run evaluations mask production-critical brittleness
- **Separate reporting of success and failure costs** — "expensive failures" are the critical deployment risk
- **Caching configuration disclosure** — a 5.8× cost impact demands transparency
- **Wall-clock time alongside dollar cost** — a $0.10 solution taking 2 hours may be worse than a $1 solution in 5 minutes

SWE-rebench (Nebius) operationalizes these standards, reporting pass@1, pass@5, tokens per problem, cost per problem, cached token percentage, and standard error of mean for every evaluated model. Epoch AI records input, output, reasoning, and cached token counts per run, computing costs using Artificial Analysis pricing data at the time of evaluation.

---

## Conclusion: Stoke's cost optimization playbook

Three findings should anchor Stoke's economic strategy. First, **reliability half-life dominates all other cost variables** — improving from 1-hour to 5-hour half-life is worth 10× more than cutting per-step costs by 25×. The Honesty Judge and convergence loop should be engineered primarily as reliability mechanisms, not quality mechanisms. Second, **prompt caching is the single highest-ROI optimization** at 81–90% cost reduction; Stoke's entire architecture should be designed around cache stability (static content first, never modify tools mid-session, cache-safe compaction). Third, **model routing within the multi-agent system** — Haiku for verification, Sonnet for implementation, Opus for planning — captures 80% of the Pareto frontier's value at 20% of all-Opus cost.

The 8-subscription setup should be split into a hybrid of 2–3 Max subscriptions for interactive development and a Tier 4 API organization for automated agent execution, with the Batch API handling non-urgent workloads at 50% discount. Budget-aware execution with reserve-commit lifecycle patterns and the $10/task escalation threshold will prevent the cost overruns that affect 92% of agentic AI deployments. When reporting Stoke's performance, lead with Cost Per Success and Pareto frontier analysis — these are the metrics that predict production viability with 2× the correlation of accuracy alone.