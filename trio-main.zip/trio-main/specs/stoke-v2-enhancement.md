<!-- STATUS: done -->
<!-- CREATED: 2026-04-03 -->
<!-- BUILD_STARTED: 2026-04-03 -->
<!-- BUILD_COMPLETED: 2026-04-03 -->
<!-- TYPE: enhancement -->
<!-- BUILD_ORDER: 1 -->

# Stoke v2 Enhancement Spec: Competitive Superiority

## Overview

This spec defines 20 enhancements across 6 categories to make Stoke the most capable, trustworthy, and complete AI coding orchestrator. Each feature is sourced from competitive research across 7 competing projects (claw-code, oh-my-openagent, claude-code-1, oh-my-claudecode, oh-my-codex, claw-code-parity) plus industry best practices analysis.

**Goal:** Every task given by the user is 100% properly, safely, completely finished without fake/slop or laziness. No competitor should exceed Stoke in any dimension.

**Research basis:** 8 research reports totaling 200+ pages of competitive analysis in `specs/research/raw/RT-*.md`.

---

## Category A: Trust & Verification (Anti-Laziness)

These enhancements strengthen our core differentiator: ensuring agent output is trustworthy.

### A1: Extended Hook Lifecycle

**Source:** claude-code-1 (9 events), oh-my-claudecode (11 events), oh-my-openagent (48 hooks)
**File:** `stoke/internal/hooks/hooks.go`
**Priority:** P0

Expand the hook system from 2 events to 9 events. This is the foundation for A2, A7, session management, and future extensibility.

- [ ] A1.1: Add `Stop` hook event — fires when the agent attempts to complete. The hook script receives the agent's final output on stdin as JSON `{"event":"stop","output":"..."}`. Exit 0 = allow stop. Exit 2 = block stop (agent continues). This enables completion promise verification (A2). Write the hook script template in `hooks.go` and wire it into `engine/claude.go` by parsing the result event before declaring the phase complete.
- [ ] A1.2: Add `SessionStart` hook event — fires once when `workflow.Engine.Run()` begins. Receives `{"event":"session_start","task":"...","task_type":"...","worktree":"..."}` on stdin. Used for context injection, notification triggers, and state initialization. Call from `workflow.Engine.Run()` before the plan phase. Hook return is informational only (no allow/deny).
- [ ] A1.3: Add `SessionEnd` hook event — fires when `workflow.Engine.Run()` returns (success or failure). Receives `{"event":"session_end","task":"...","success":bool,"duration_ms":int,"cost_usd":float}` on stdin. Used for cleanup, notifications, and metrics. Call from a deferred function in `workflow.Engine.Run()`.
- [ ] A1.4: Add `PostToolUseFailure` hook event — fires when a tool execution returns an error. Receives the tool name, error output, and exit code. Distinct from `PostToolUse` which fires on success. Pattern: separate success/failure paths for different hook logic. Add to the PostToolUse hook script with a conditional branch.
- [ ] A1.5: Add `PreCompact` hook event — fires before context compaction (in `context/context.go` `Compact()` method). Receives `{"event":"pre_compact","utilization":float,"level":"gentle|moderate|aggressive"}`. Hooks can inject critical context that must survive compaction by writing to stdout. The compacted context should include hook-injected content.
- [ ] A1.6: Update `HooksConfig()` in `hooks.go` to register all new events in the settings.json hooks section. Update `Install()` to write separate hook scripts per event type (not just pre-tool-use.sh and post-tool-use.sh). New files: `stop.sh`, `session-start.sh`, `session-end.sh`, `post-tool-failure.sh`, `pre-compact.sh`.
- [ ] A1.7: Update `GenerateSettings()` in `hooks.go` to include all new hook events in the generated claude-settings.json for interactive modes (yolo/scope). Test that Claude Code accepts the new hook event names.
- [ ] A1.8: Define hook timeout behavior for all events. Every hook script has a 5-second execution timeout (matching Claude Code's default). If a hook exceeds the timeout: for `Stop` hooks, treat as "allow stop" (fail-open — don't trap the agent forever). For `PreToolUse` hooks, treat as "allow" (fail-open — don't block tool execution on a hung hook). For informational hooks (`SessionStart`, `SessionEnd`, `PreCompact`, `PostToolUseFailure`), kill the hook process and log a warning. Implement timeout via `context.WithTimeout` wrapping `exec.CommandContext` in the hook runner. Add `HookTimeout time.Duration` field to the hook configuration with default 5s.
- [ ] A1.9: Add tests in `hooks_test.go` for each new hook event: verify JSON payload format, verify exit code handling (0=allow, 2=deny for Stop; informational for others), verify hook scripts are executable, verify symlink rejection still works for all new paths. Add timeout test: hook that sleeps 10s → verify it is killed after 5s and the correct fail-open behavior applies.

### A2: Completion Promise Verification

**Source:** claude-code-1 (ralph-wiggum), oh-my-claudecode (ralph PRD-driven persistence)
**File:** `stoke/internal/workflow/workflow.go`, `stoke/internal/hooks/hooks.go`
**Priority:** P1

Require the agent to assert a verifiable completion statement. The Stop hook (A1.1) intercepts the exit attempt and checks the promise. Prevents premature task abandonment.

- [ ] A2.1: Add a `CompletionPromise` field to `engine.PhaseSpec` (in `engine/types.go`) — a string template like `"All tests pass and the feature is implemented"`. This is set by the planner based on the task verification checklist. If empty, skip promise verification.
- [ ] A2.2: In `workflow.Engine.Run()`, after the execute phase completes, before declaring success: check if `CompletionPromise` is set. If so, scan the agent's final output (from `execResult.ResultText`) for the promise text. **Matching rules:** normalize both the promise and the output by: (1) collapsing all whitespace to single spaces, (2) trimming leading/trailing whitespace, (3) case-insensitive comparison. Also check for the `<promise>...</promise>` XML tag wrapping. The promise matches if EITHER the normalized text is found in the normalized output OR the `<promise>` tag contains the normalized text. If the promise is NOT found, treat as verification failure and retry with brief: `"Your previous attempt did not assert the completion promise. You must include: <promise>[promise text]</promise> when done."`.
- [ ] A2.3: Update `prompts.BuildExecutePrompt()` in `prompts/prompts.go` to append the completion promise requirement when `CompletionPromise` is non-empty: `"\n\n## Completion Promise\nWhen you are TRULY done (not before), you MUST include this exact statement in your final response:\n<promise>[promise text]</promise>\nDo NOT output this statement until ALL work is complete and verified. Outputting it prematurely is a policy violation."`.
- [ ] A2.4: Add integration test: mock agent that exits WITHOUT the promise string → verify workflow detects missing promise and retries. Mock agent that INCLUDES the promise string → verify workflow accepts and proceeds.

### A3: AI Slop Detection + Cleanup

**Source:** oh-my-codex (ai-slop-cleaner), oh-my-claudecode (mandatory deslop pass + regression re-verification)
**File:** `stoke/internal/scan/scan.go`, `stoke/internal/scan/slop.go` (new)
**Priority:** P0

Expand the forbidden-pattern scan with AI-specific code smell detection. Add patterns that catch the distinctive artifacts of AI-generated code.

- [ ] A3.1: Create `stoke/internal/scan/slop.go` with a `SlopRules()` function returning AI-specific scan rules. Patterns to detect (each is a `Rule` struct with ID, severity, regex pattern, message, fix suggestion, and applicable file extensions):
  1. `slop-verbose-comment` (medium): Comments that restate the code — regex `// (This|Here we|The following|We) (function|method|code|line|block)` in .go/.ts/.js/.py — Fix: "Remove comments that restate the code"
  2. `slop-unnecessary-else` (low): `} else { return` or `} else { throw` — Fix: "Use early return pattern"
  3. `slop-empty-error-message` (high): `fmt.Errorf("")` or `new Error("")` or `raise Exception("")` — Fix: "Provide a descriptive error message"
  4. `slop-generic-variable-name` (medium): Variables named `data`, `result`, `temp`, `tmp`, `val`, `item`, `obj` as standalone identifiers (not in compound names) — regex `\b(data|result|temp|tmp|val|item|obj)\b\s*[:=]` — Fix: "Use a descriptive variable name"
  5. `slop-apologetic-comment` (medium): `// Sorry`, `// Note:`, `// Important:`, `// Please note` — Fix: "Remove apologetic or instructional comments"
  6. `slop-redundant-type-assertion` (medium): TypeScript `as string` on a value that's already a string (from function return type) — simplified regex: `\.toString\(\)\s+as\s+string` — Fix: "Remove redundant type assertion"
  7. `slop-commented-out-code` (medium): Multi-line comment blocks containing code syntax (semicolons, braces, parentheses) — regex `(?m)^(\s*//.*[;{}()].*\n){3,}` — Fix: "Remove commented-out code blocks"
  8. `slop-excessive-logging` (low): More than 3 log statements in a single function body — heuristic: scan for `log\.|console\.|print\(|fmt\.Print` density — Fix: "Reduce logging density"
- [ ] A3.2: Integrate `SlopRules()` into the verification pipeline. In `workflow.go`, after the execute phase succeeds and standard scan passes, run a second scan with `scan.ScanFiles(handle.Path, scan.SlopRules(), modifiedFiles)`. If blocking findings exist (severity critical or high), inject them into the retry brief and retry. If only medium/low findings exist, record them as warnings in `evidence.Warnings` but don't block the merge.
- [ ] A3.3: Add `--slop-check` flag to `stoke scan` command in `main.go`. When set, include slop rules in the scan output alongside the standard rules. Default: include slop rules. Allow `--no-slop` to disable.
- [ ] A3.4: Add tests for each slop pattern: provide sample input that should match and sample input that should NOT match. Test the integration with the verify pipeline — slop findings should appear in the scan results.

### A4: Confidence-Based Finding Scoring

**Source:** claude-code-1 (code-review, 0-100 scoring with threshold)
**File:** `stoke/internal/scan/scan.go`, `stoke/internal/audit/audit.go`
**Priority:** P1

Add confidence scoring to scan findings and audit results. Filter output to only high-confidence findings.

- [ ] A4.1: Add `Confidence int` field (0-100) to `scan.Finding` struct in `scan/scan.go`. For deterministic rules, confidence is always 100 (the pattern matched or it didn't). For slop rules (A3), assign confidence based on pattern specificity: exact match patterns get 95, broad regex patterns get 70, heuristic density checks get 50.
- [ ] A4.2: Add `Confidence int` field to `audit.ReviewFinding` struct in `audit/audit.go`. Audit findings come from AI reviewers, so their confidence is model-assigned. Update `BuildPrompt()` to instruct the persona: `"For each finding, assign a confidence score 0-100: 0-25 = likely false positive, 26-50 = minor nitpick, 51-75 = valid but low-impact, 76-90 = important issue, 91-100 = critical or explicit rule violation. Only report findings with confidence >= 80."`.
- [ ] A4.3: Add `ConfidenceThreshold int` field to `config.Policy` struct (in `config/policy.go`) with a default of 80. In the scan result filtering, only include findings where `Confidence >= threshold`. Add `--confidence-threshold` flag to `stoke scan` and `stoke audit` commands.
- [ ] A4.4: Add `FilterByConfidence(findings []Finding, threshold int) []Finding` function to `scan/scan.go`. Update `ScanResult` to track both `AllFindings` (unfiltered) and `Findings` (filtered). The summary should note how many findings were filtered: `"Found 12 issues (5 filtered below confidence threshold 80)"`.
- [ ] A4.5: Add tests: verify deterministic rules get confidence 100, slop rules get appropriate confidence, filtering at threshold 80 removes low-confidence findings, threshold 0 returns all findings.

### A5: Fanout-Validate-Filter Audit

**Source:** claude-code-1 (code-review multi-agent pattern)
**File:** `stoke/internal/audit/audit.go`, `stoke/internal/audit/validate.go` (new)
**Priority:** P2

After the persona audit fans out and collects findings, spawn a second round of validation agents. Each validator independently confirms or denies a finding. Only findings validated by an independent agent pass through.

- [ ] A5.1: Create `stoke/internal/audit/validate.go` with a `ValidateFinding(finding ReviewFinding, codeContext string) ValidatedFinding` function. The `ValidatedFinding` struct adds `Validated bool`, `ValidatorConfidence int`, and `ValidatorNote string` fields to `ReviewFinding`.
- [ ] A5.2: Add `BuildValidationPrompt(finding ReviewFinding, codeContext string) string` function that generates a focused prompt: `"A code reviewer reported this issue:\n[finding details]\n\nRelevant code:\n[code context]\n\nIs this a REAL issue? Respond with JSON: {\"valid\": true|false, \"confidence\": 0-100, \"note\": \"why\"}\n\nFalse positive checklist:\n- Is this pre-existing (not from this change)?\n- Is this a style preference, not a bug?\n- Is this something a linter would catch?\n- Is the code actually correct despite looking suspicious?"`.
- [ ] A5.3: In `audit.go`, after collecting all persona findings, group them by file for context extraction. For each finding, read the relevant file section (10 lines before/after the finding line). Spawn validation agents (one per finding, parallel up to --workers limit). Use a cheaper model (Sonnet-tier) for validation to keep costs down.
- [ ] A5.4: Filter findings: only keep findings where `Validated == true && ValidatorConfidence >= 70`. Log filtered findings at debug level. Report final count: `"17 findings detected, 11 validated, 6 filtered as false positives"`.
- [ ] A5.5: Add `--skip-validation` flag to `stoke audit` to bypass the validation stage (faster but noisier). Default: validation enabled.
- [ ] A5.6: Add tests: mock finding + code context → validator confirms → finding passes. Mock finding + code context → validator rejects → finding filtered. Verify parallel validation respects worker limit.

### A6: Tiered Verification Scaling

**Source:** oh-my-codex (evidence-based verification protocol), oh-my-claudecode (LIGHT to THOROUGH)
**File:** `stoke/internal/verify/pipeline.go`, `stoke/internal/verify/tiers.go` (new)
**Priority:** P1

Scale verification depth based on change size. Don't run expensive Opus cross-model review on a one-line typo fix.

- [ ] A6.1: Create `stoke/internal/verify/tiers.go` with a `ClassifyChange(modifiedFiles []string, diffLines int) VerificationTier` function. Tiers:
  - `TierLight`: <3 files AND <50 diff lines → build + lint only (skip test + cross-model review)
  - `TierStandard`: <15 files AND <500 diff lines → build + test + lint + cross-model review (current behavior)
  - `TierThorough`: >=15 files OR >=500 diff lines → build + test + lint + cross-model review + security scan of ALL modified files + scope re-verification
  Define `VerificationTier` as a Go type with these three constants.
- [ ] A6.2: In `workflow.go`, after the execute phase, call `ClassifyChange()` using `worktree.ModifiedFiles()` and `worktree.DiffLineCount()` (new helper). Based on the tier:
  - `TierLight`: run only `Verifier.Run()`, skip cross-model review. Set `evidence.ReviewPass = true` with a warning `"review skipped: light tier (change too small to warrant cross-model review)"`.
  - `TierStandard`: current behavior (full pipeline).
  - `TierThorough`: current behavior PLUS run `scan.ScanFiles()` with full `DefaultRules() + SlopRules()` on all modified files (not just blocking check).
- [ ] A6.3: Add `DiffLineCount(ctx context.Context, handle Handle) int` function to `worktree/helpers.go`. Uses `git diff --stat BaseCommit..HEAD` and parses the total insertions+deletions count.
- [ ] A6.4: Add `--verification-tier light|standard|thorough|auto` flag to `stoke run` and `stoke build`. Default: `auto` (uses `ClassifyChange`). Override allows forcing thorough verification on small changes when needed.
- [ ] A6.5: Log the tier selection: `"[stoke] verification tier: standard (8 files, 234 diff lines)"`. Include tier in the build report `TaskReport`.
- [ ] A6.6: Add tests: 1 file + 20 lines → TierLight. 5 files + 200 lines → TierStandard. 20 files + 800 lines → TierThorough. Verify each tier runs the correct verification steps.

### A7: Hook Tool Input Modification

**Source:** claw-code-parity (hooks can rewrite tool inputs)
**File:** `stoke/internal/hooks/hooks.go`
**Priority:** P2

Enhance PreToolUse hooks to support input modification, not just allow/deny. Hooks can rewrite tool inputs for sanitization, path normalization, or policy enforcement.

- [ ] A7.1: Update the PreToolUse hook protocol. Currently hooks output `{"decision":"allow"}` or `{"decision":"block","reason":"..."}`. Add a third option: `{"decision":"modify","tool_input":"<modified JSON>"}`. When a hook returns `modify`, the workflow replaces the tool's input with the modified version before execution.
- [ ] A7.2: Update the PreToolUse hook script template in `hooks.go` to document the modify decision in a comment: `# To modify tool input: echo '{"decision":"modify","tool_input":"{\"file_path\":\"/safe/path\"}"}'`.
- [ ] A7.3: Add a concrete use case: path normalization hook. When a Write/Edit tool targets a symlink, resolve the symlink and modify the input to use the real path. This adds defense-in-depth to our existing symlink rejection. Implement as an optional section in the pre-tool-use.sh script.
- [ ] A7.4: Add tests: hook returns `modify` with new input → verify the modified input is used. Hook returns `modify` with invalid JSON → verify the tool is blocked (fail-safe). Hook returns `allow` → verify original input is used unchanged.

---

## Category B: Code Quality & Intelligence

Improve the quality of code that agents produce.

### B1: Hash-Anchored Editing Verification

**Source:** oh-my-openagent (hashline-edit, 6.7% → 68.3% success rate improvement)
**File:** `stoke/internal/hooks/hooks.go`, `stoke/internal/scan/hashline.go` (new)
**Priority:** P0

The single highest-impact improvement identified. Each line of a file gets a content hash. When an agent proposes an edit referencing a specific line, the hook verifies the content hash matches. If the file changed since the agent last read it, the hash mismatch rejects the edit BEFORE corruption occurs.

- [ ] B1.1: Create `stoke/internal/scan/hashline.go` with:
  - `HashLine(content string) string` — returns the first 8 characters of the xxHash32 of the trimmed line content (hex-encoded). Use a pure Go xxHash32 implementation (e.g. `github.com/cespare/xxhash/v2` or inline the algorithm — it's 30 lines). Zero dependencies preferred.
  - `HashFile(path string) map[int]string` — reads a file and returns a map of line number → hash. Line numbers are 1-indexed.
  - `VerifyEdit(path string, lineNum int, expectedHash string) (bool, string)` — reads line `lineNum` from the file, computes its hash, returns `(match, actualHash)`. If the line doesn't exist, returns `(false, "")`.
- [ ] B1.2: Integrate hash verification into the PreToolUse hook for Edit/Write tools. In `hooks.go`, add an optional hash verification section to the pre-tool-use.sh script. When the tool input contains a `line_hash` field (injected by the prompt), the hook:
  1. Reads the target file and line number from the tool input
  2. Computes the xxHash32 of the current line content
  3. Compares against the `line_hash` from the tool input
  4. If mismatch: block the edit with reason `"Stale edit: line content changed since last read (expected hash X, actual hash Y). Re-read the file before editing."`
  Since Claude Code's Edit tool uses `old_string` matching (not line numbers), this hook applies primarily to Write tool overwrites and to verify the file hasn't changed between Read and Edit operations.
- [ ] B1.3: Add a file-level hash verification: when the agent reads a file via the Read tool, compute an xxHash32 of the entire file content and inject it as a `file_hash` field in the PostToolUse hook output. When a subsequent Edit/Write targets the same file, the PreToolUse hook compares the stored file_hash against the current file hash. If different, block the edit with `"File changed since last read. Re-read before editing."` Store the hash map in a temporary file at `$RUNTIME_DIR/file-hashes.json`. **Concurrency protection:** Use `flock` (advisory file locking) on the JSON file to prevent race conditions when multiple hooks read/write simultaneously. The hook script should: `exec 200>"$HASH_FILE.lock"; flock 200; <read/write>; flock -u 200`. If `flock` is unavailable, fall back to atomic write (write to temp file + rename).
- [ ] B1.4: Update the PostToolUse hook to record file hashes after every Read operation. The hook writes to `$RUNTIME_DIR/file-hashes.json` (append/update, not overwrite). Format: `{"<file_path>": {"hash": "<xxhash32>", "timestamp": "<iso8601>"}}`.
- [ ] B1.5: Add the `xxhash` dependency to `go.mod`. Use `github.com/cespare/xxhash/v2` which provides xxHash64. For 32-bit hashes, truncate to 4 bytes and hex-encode (8 characters). Alternatively, implement xxHash32 inline (the algorithm is simple: prime multiplication + bit rotation, ~30 lines of Go).
- [ ] B1.6: Add tests: `HashLine("func main() {")` returns a deterministic 8-char hex string. `VerifyEdit` with matching content returns true. `VerifyEdit` with different content returns false. End-to-end: Read file → record hash → modify file externally → attempt Edit → hook blocks. Read file → record hash → attempt Edit without modification → hook allows.

### B2: Expanded AI Slop Scan Patterns

**Source:** oh-my-codex (ai-slop-cleaner), oh-my-claudecode (deslop pass)
**File:** `stoke/internal/scan/slop.go`
**Priority:** P0
**Depends on:** A3 (creates `scan/slop.go` and `SlopRules()` function that this task extends)

This extends A3 with additional patterns specific to AI-generated code. The distinction: A3 creates the infrastructure, B2 fills it with battle-tested patterns.

- [ ] B2.1: Add these additional slop rules to `SlopRules()` in `scan/slop.go`:
  9. `slop-wrapper-function` (medium): A function that just calls another function with the same arguments and returns the result — regex: function body contains only a single return statement calling another function. Fix: "Remove wrapper function and call the target directly."
  10. `slop-excessive-null-checks` (low): `if x != nil && x.Y != nil && x.Y.Z != nil` chains > 3 deep — Fix: "Use optional chaining or nil-safe accessor"
  11. `slop-god-function` (medium): Function with > 80 lines — Fix: "Break into smaller functions"
  12. `slop-unused-parameter` (medium): Go: function parameter that is never referenced in the body. Simple heuristic: parameter name doesn't appear after the signature line. Fix: "Remove unused parameter or use _ prefix"
  13. `slop-catch-and-log` (high): `catch (err) { console.error(err); }` or `catch (err) { log.error(err); }` without rethrowing — Fix: "Rethrow or handle the error properly"
  14. `slop-magic-number` (low): Numeric literal > 1 and < 1000 used directly (not in a constant) — regex: `[^0-9.]\b([2-9]|[1-9]\d{1,2})\b[^0-9.]` in non-test files — Fix: "Extract to a named constant"
- [ ] B2.2: Add tests for each new pattern with positive and negative test cases.

### B3: Intent Verbalization

**Source:** oh-my-openagent (surface form → true intent mapping)
**File:** `stoke/internal/prompts/prompts.go`
**Priority:** P2

Before routing a task, require the planning agent to explicitly map the user's stated request to the true underlying intent. This prevents literal misinterpretation.

- [ ] B3.1: Update `BuildPlanPrompt()` in `prompts/prompts.go` to add an intent verbalization step before the research loop: `"\n### Step 0: Intent Verbalization\nBefore planning, explicitly state:\n1. SURFACE FORM: What the user literally asked for\n2. TRUE INTENT: What the user actually needs (may differ from surface form)\n3. ROUTING DECISION: What type of task this is and why\n\nIf surface form and true intent differ, explain the gap. This prevents building the wrong thing."`.
- [ ] B3.2: In the plan phase output parsing (workflow.go), extract the intent verbalization section and include it in the retry brief if the task fails. This helps the retried agent understand what was actually intended.

### B4: Commit Decision Tracing

**Source:** oh-my-claudecode (structured git trailers)
**File:** `stoke/internal/worktree/helpers.go`
**Priority:** P2

Add structured git trailers to every Stoke-created commit. This creates an auditable decision trail in git log.

- [ ] B4.1: Update `CommitVerifiedTree()` in `worktree/helpers.go` to append structured git trailers to the commit message. Trailers to add:
  - `Stoke-Task-Type: <task_type>` (e.g., refactor, security, docs)
  - `Stoke-Engine: <engine_name>` (e.g., claude, codex)
  - `Stoke-Reviewer: <reviewer_engine>` (e.g., codex, claude)
  - `Stoke-Verification-Tier: <tier>` (light, standard, thorough)
  - `Stoke-Attempts: <n>` (number of attempts before success)
  - `Stoke-Cost-USD: <cost>` (total cost for this task)
  Format: `git commit -m "message" --trailer "Stoke-Engine:claude" --trailer "Stoke-Reviewer:codex" ...`.
- [ ] B4.2: Add tests: verify trailers appear in `git log --format=%B` output. Verify trailer values match the actual engine/reviewer/tier used.

### B5: Agent Self-Reflection Protocol

**Source:** RT-8 best practices (#1 ranked gap: agent self-reflection after each task)
**File:** `stoke/internal/workflow/workflow.go`, `stoke/internal/wisdom/wisdom.go`
**Priority:** P2

After each task completes (success or failure), the agent outputs a structured self-reflection. The harness parses this and feeds it into the wisdom store.

- [ ] B5.1: Update `prompts.BuildExecutePrompt()` to append a self-reflection requirement at the end: `"\n\n## Post-Task Reflection (mandatory)\nAfter completing your work, output a REFLECTION block:\n<reflection>\nWHAT_WORKED: [specific technique or approach that was effective]\nWHAT_FAILED: [approach that didn't work and why]\nSURPRISE: [anything unexpected about the codebase or task]\nFOR_NEXT_TASK: [one-sentence advice for the next agent working on this codebase]\n</reflection>\nThis block is parsed by the harness. Be specific and honest."`.
- [ ] B5.2: In `workflow.go`, after the execute phase, parse the agent's output for the `<reflection>` XML tag. Extract the four fields. Store each as a `wisdom.Learning` in the wisdom store with appropriate categories: WHAT_FAILED → Gotcha, WHAT_WORKED → Pattern, SURPRISE → Gotcha, FOR_NEXT_TASK → Decision. If no reflection block is found, log a warning but don't fail the task.
- [ ] B5.3: Update `wisdom.ForPrompt()` to include self-reflections from prior tasks. Prioritize: gotchas from failed tasks > patterns from successful tasks > decisions. Cap at 500 characters (existing limit).
- [ ] B5.4: Add tests: parse reflection from mock agent output. Verify wisdom store records the learnings. Verify ForPrompt includes them in subsequent prompts.

---

## Category C: Scope & Planning

Ensure we build the right thing before building anything.

### C1: Quantitative Ambiguity Scoring

**Source:** oh-my-codex (deep-interview), oh-my-claudecode (mathematical ambiguity gating)
**File:** `stoke/internal/prompts/prompts.go`, `stoke/cmd/stoke/main.go`
**Priority:** P1

Add quantitative ambiguity scoring to the scope command. The agent scores clarity across multiple dimensions and refuses to proceed until ambiguity drops below a configurable threshold.

- [ ] C1.1: Update `ScopeSystemPrompt()` in `prompts/prompts.go` to add ambiguity scoring between Steps 1 and 2. New section:
  ```
  ### Step 1.5: Ambiguity Assessment
  Rate the clarity of the current scope on these dimensions (0.0 = completely unclear, 1.0 = crystal clear):
  
  1. GOAL CLARITY: Is the desired outcome unambiguous?
  2. SCOPE BOUNDARIES: Are inclusion/exclusion boundaries defined?
  3. ACCEPTANCE CRITERIA: Are verifiable done-conditions specified?
  4. TECHNICAL APPROACH: Is the implementation path clear?
  5. NON-GOALS: Is what we're NOT doing explicitly stated?
  6. DEPENDENCIES: Are external dependencies and constraints identified?
  7. RISK FACTORS: Are known risks and mitigations documented?
  
  Compute the weighted average: GOAL(0.25) + BOUNDARIES(0.20) + CRITERIA(0.20) + APPROACH(0.15) + NON-GOALS(0.10) + DEPENDENCIES(0.05) + RISKS(0.05)
  
  If the weighted average is below 0.80 (i.e., ambiguity > 20%):
  - Identify the WEAKEST dimension
  - Ask ONE targeted clarifying question about that dimension
  - Re-score after the user answers
  - Repeat until ambiguity <= 20%
  
  Do NOT proceed to Step 2 until the ambiguity threshold is met.
  Output your scores in a structured format:
  AMBIGUITY_SCORE: [0.0-1.0]
  WEAKEST_DIMENSION: [dimension_name]
  ```
- [ ] C1.2: Add `--ambiguity-threshold` flag to `stoke scope` command in `main.go`. Default: 0.80 (20% ambiguity allowed). Range: 0.50-1.00. The flag value is injected into the scope prompt.
- [ ] C1.3: Add depth profiles matching oh-my-codex patterns: `--scope-depth quick` (threshold 0.70, max 5 rounds), `--scope-depth standard` (threshold 0.80, max 12 rounds), `--scope-depth deep` (threshold 0.85, max 20 rounds). Default: standard.
- [ ] C1.4: Add test: verify the scope prompt includes the ambiguity scoring section. Verify the threshold value from the flag appears in the generated prompt.

---

## Category D: Observability & UX

Let users monitor and control builds without watching the terminal.

### D1: Notification System

**Source:** oh-my-codex (multi-platform notifications), oh-my-claudecode (Discord, Telegram, Slack, webhook)
**File:** `stoke/internal/notify/notify.go` (new), `stoke/cmd/stoke/main.go`
**Priority:** P1

Add webhook-based notifications for task/build completion, failure, and idle events.

- [ ] D1.1: Create `stoke/internal/notify/notify.go` with:
  - `Notifier` interface: `Notify(event NotifyEvent) error`
  - `NotifyEvent` struct: `Type string` (task_complete, task_failed, build_complete, build_failed, rate_limited, idle), `TaskID string`, `Message string`, `Timestamp time.Time`, `Details map[string]string`
  - `WebhookNotifier` struct implementing `Notifier`: sends HTTP POST with JSON body to a configured URL. Timeout: 5 seconds. Retry: 1 attempt. Log failures but don't block execution.
  - `NewWebhookNotifier(url string, headers map[string]string) *WebhookNotifier`
- [ ] D1.2: Add platform-specific formatters:
  - `DiscordFormatter(event NotifyEvent) []byte` — formats as Discord webhook JSON with embeds (color: green for success, red for failure)
  - `SlackFormatter(event NotifyEvent) []byte` — formats as Slack Block Kit JSON
  - `TelegramFormatter(event NotifyEvent, chatID string) []byte` — formats as Telegram sendMessage JSON
  - `GenericFormatter(event NotifyEvent) []byte` — plain JSON
- [ ] D1.3: Add configuration to `config.Policy` struct (in `config/policy.go`): `Notifications` section with `WebhookURL string`, `Platform string` (discord, slack, telegram, generic), `Headers map[string]string`, `Events []string` (which events to notify on, default: all).
- [ ] D1.4: Wire notifications into the workflow: call `notifier.Notify()` at task completion, task failure, build completion, build failure, and rate limit events. In `workflow.go`, add a `Notifier notify.Notifier` field to `Engine` struct. In `main.go`, create the notifier from policy config and pass it to the workflow engine.
- [ ] D1.5: Add `stoke notify --test` command to send a test notification. Reads webhook config from policy file and sends a test event.
- [ ] D1.6: Add tests: mock HTTP server → verify webhook receives correct JSON format for each platform. Verify timeout handling. Verify notification failures don't block task execution.

### D2: HTTP/SSE Server

**Source:** claw-code (axum-based session server with SSE streaming)
**File:** `stoke/internal/server/server.go` (new), `stoke/cmd/stoke/main.go`
**Priority:** P2

Add an optional HTTP server for remote monitoring, web dashboards, and programmatic control.

- [ ] D2.1: Create `stoke/internal/server/server.go` with a minimal HTTP server using Go's `net/http` stdlib:
  - `GET /api/status` — returns JSON build status (plan state, task progress, pool utilization)
  - `GET /api/tasks` — returns JSON list of all tasks with current phase and evidence
  - `GET /api/tasks/{id}` — returns detailed task state including ClaimedVsVerified
  - `GET /api/pools` — returns pool snapshot (utilization, status, circuit breaker state)
  - `GET /api/events` — SSE endpoint streaming real-time events (task start, task complete, pool rotation, etc.)
  - `GET /api/report` — returns the latest build report JSON
- [ ] D2.2: Implement SSE using `text/event-stream` content type and Go channels. Create an `EventBus` that the workflow engine writes events to. SSE handler reads from the bus and writes to the HTTP response with `data:` prefix and double newline separators.
- [ ] D2.3: Add `stoke serve` command (or `--serve` flag on `stoke build`) that starts the HTTP server on `--port` (default: 8420). The server runs in a goroutine alongside the build. Graceful shutdown when the build completes.
- [ ] D2.4: Add CORS headers for local development. Add optional `--serve-token` flag for bearer token authentication on all endpoints (prevents unauthorized access to build state).
- [ ] D2.5: Add tests: start server, hit each endpoint, verify JSON response format. Verify SSE connection receives events when tasks are dispatched.

### D3: Enhanced TUI

**Source:** oh-my-codex (HUD), oh-my-openagent (real-time status)
**File:** `stoke/internal/tui/interactive.go`
**Priority:** P2

Enhance the existing Bubble Tea TUI with additional status displays.

- [ ] D3.1: Add a pool utilization bar display to the Dashboard mode. For each pool, show: `[pool-id] [=====>     ] 62% | 3/5hr reset | status: idle`. Use lipgloss styling for color: green (<50%), yellow (50-80%), red (>80%), gray (circuit-open).
- [ ] D3.2: Add a cost tracker to the Dashboard: `Total cost: $0.0342 | Avg per task: $0.0057`. Update in real-time as tasks complete.
- [ ] D3.3: Add a verification tier indicator in the Focus mode: `[TASK-3] Tier: THOROUGH (22 files, 847 lines)` displayed alongside the task status.
- [ ] D3.4: Add keyboard shortcut `n` in Dashboard mode to toggle notification status (shows last notification sent/failed). Shortcut `p` to show pool details expanded view.

---

## Category E: Extensibility

Let the community extend Stoke without forking.

### E1: Plugin System

**Source:** claw-code (manifest-based), claude-code-1 (marketplace), oh-my-codex (SDK)
**File:** `stoke/internal/plugins/plugins.go` (new), `stoke/cmd/stoke/main.go`
**Priority:** P3

Add a manifest-based plugin system that allows external tools and hooks to extend Stoke.

- [ ] E1.1: Create `stoke/internal/plugins/plugins.go` with:
  - Plugin manifest format: `.stoke-plugin/plugin.json` containing `name`, `version`, `description`, `hooks` (map of event → script path), `tools` (array of tool definitions), `scan_rules` (path to additional scan rules).
  - `PluginRegistry` struct with `Discover(dir string) []Plugin` — scans for plugin manifests in `~/.stoke/plugins/` and `.stoke/plugins/`.
  - `Plugin` struct with `Install(source string)`, `Enable()`, `Disable()`, `Uninstall()` methods.
  - Hook aggregation: collect hooks from all enabled plugins, merge with built-in hooks, execute all for each event.
- [ ] E1.2: Add `stoke plugin list|install|enable|disable|uninstall` commands to `main.go`.
- [ ] E1.3: Add plugin hook execution to the hook lifecycle. In `hooks.go`, after running built-in hooks for an event, run all plugin hooks for the same event. **Priority ordering:** Built-in hooks ALWAYS run first and their decisions take precedence. If a built-in hook allows an action, a plugin hook can still block it. But if a built-in hook blocks an action, plugin hooks are NOT run (short-circuit). **DoS prevention:** Plugin hooks are subject to the same 5-second timeout as built-in hooks. If a plugin hook hangs, it is killed and treated as "allow" (fail-open). Plugins cannot override built-in security hooks (PreToolUse protected file checks, secret leak detection). The `Install()` function ensures built-in hooks are always registered first in the hooks array.
- [ ] E1.4: Add plugin scan rule loading. In `scan/scan.go`, load additional rules from enabled plugins and merge with `DefaultRules()` and `SlopRules()`.
- [ ] E1.5: Add tests: install a test plugin from a local directory, verify its hooks are called, verify its scan rules are loaded, uninstall and verify cleanup.

### E2: Markdown-as-Agent Definitions

**Source:** claude-code-1 (YAML frontmatter + MD body)
**File:** `stoke/internal/audit/audit.go`
**Priority:** P3

Allow audit personas to be defined as Markdown files with YAML frontmatter instead of hardcoded Go structs.

- [ ] E2.1: Create a `personas/` directory under `stoke/internal/audit/`. Move the 17 default persona definitions to individual `.md` files: `security.md`, `performance.md`, etc. Each file has YAML frontmatter (`id`, `name`, `focus`, `model_tier`) and Markdown body (the detailed review prompt).
- [ ] E2.2: Update `DefaultPersonas()` in `audit/audit.go` to read from embedded `.md` files (using Go `embed` directive) instead of hardcoded structs. This allows users to add custom personas by placing `.md` files in `.stoke/personas/` which are loaded alongside the defaults.
- [ ] E2.3: Add `stoke audit --persona custom-persona.md` flag to use a single custom persona file for review.
- [ ] E2.4: Add tests: verify all 17 default personas load correctly from embedded files. Verify a custom persona file is discovered and loaded.

---

## Category F: Infrastructure

Production hardening and operational improvements.

### F1: Container-Aware Sandbox Detection

**Source:** claw-code (Docker/K8s/Podman detection), claw-code-parity (namespace isolation)
**File:** `stoke/internal/config/detect.go`
**Priority:** P3

Auto-detect container environments and adjust sandbox configuration accordingly.

- [ ] F1.1: Add `DetectContainerEnvironment() ContainerInfo` function to `config/detect.go`. Checks for:
  - `/.dockerenv` file exists → Docker
  - `/run/.containerenv` file exists → Podman
  - `KUBERNETES_SERVICE_HOST` env var set → Kubernetes
  - `/proc/1/cgroup` contains "docker" or "kubepods" → container
  - `CONTAINER` or `DOCKER` env vars set → container
  Returns `ContainerInfo{IsContainer bool, Runtime string, Namespace string}`.
- [ ] F1.2: In `app.go`, call `DetectContainerEnvironment()` at startup. If running in a container, log: `"[stoke] container detected: runtime=%s, adjusting sandbox strategy"`. Adjust sandbox behavior: in containers, `sandbox.failIfUnavailable` should be relaxed to a warning (containers often lack nested namespace support).
- [ ] F1.3: Add tests with mock filesystem: create `/.dockerenv` → verify Docker detected. Set `KUBERNETES_SERVICE_HOST` → verify K8s detected. No markers → verify IsContainer is false.

### F2: Session Recovery

**Source:** oh-my-openagent (auto-recovery from API failures, context limits)
**File:** `stoke/internal/workflow/workflow.go`, `stoke/internal/engine/claude.go`
**Priority:** P2

Auto-recover from transient failures without manual intervention.

- [ ] F2.1: In `engine/claude.go`, detect context window exceeded errors from the API response (look for `"context_length_exceeded"` or similar error subtype in the NDJSON stream). When detected, set `result.Subtype = "context_exceeded"`.
- [ ] F2.2: In `workflow.go`, when `execResult.Subtype == "context_exceeded"`, trigger a special recovery flow:
  1. Save the current progress (committed changes + plan state)
  2. Create a fresh worktree
  3. Inject a compressed retry brief with only: task description, changes made so far (from DiffSummary), what failed, and the remaining work
  4. Retry with the compressed context
  This is different from a normal retry (which starts from scratch) — it preserves progress.
- [ ] F2.3: Detect JSON parse errors from malformed NDJSON output (which occurs when the API connection drops mid-stream). In `stream/parser.go`, when a JSON parse error occurs after receiving some valid events, mark the result as `subtype: "stream_interrupted"` rather than treating it as a complete failure.
- [ ] F2.4: Add `MaxRecoveryAttempts int` field to `config.Policy` with default 2. Recovery attempts are separate from retry attempts (retry = verification failure, recovery = infrastructure failure). **Interaction with existing retry counter:** The `maxAttempts = 3` counter in workflow.go counts verification failures only. Recovery attempts have their own counter (`recoveryAttempts`). Total executions are capped at `maxAttempts + MaxRecoveryAttempts = 5` to prevent infinite loops. If both counters are exhausted, escalate to human with a clear message: `"Task failed after 3 verification retries and 2 recovery attempts."`.
- [ ] F2.5: Add tests: mock context_exceeded response → verify recovery flow triggered. Mock stream interruption → verify graceful handling.

### F3: Multi-Provider Expansion

**Source:** claw-code (xAI/Grok, OpenAI compat), oh-my-openagent (7 providers), oh-my-claudecode (tri-model)
**File:** `stoke/internal/engine/types.go`, `stoke/internal/model/router.go`
**Priority:** P3

Expand model routing to support additional AI providers beyond Claude and Codex.

- [ ] F3.1: Add `ProviderGemini Provider = "gemini"` to `model/router.go`. Add Gemini to fallback chains for appropriate task types. Gemini excels at visual-engineering and creative tasks per oh-my-openagent research.
- [ ] F3.2: Create `stoke/internal/engine/gemini.go` with a `GeminiRunner` that implements the `Runner` interface. Use the Gemini CLI (if available) or the Gemini API via HTTP. Initial implementation: API-based with `GEMINI_API_KEY` env var. Supports `Prepare()` and `Run()` with NDJSON-compatible output parsing.
- [ ] F3.3: Update `engine.Registry` to include `Gemini *GeminiRunner`. Update `pickRunner()` in `workflow.go` to support the new provider.
- [ ] F3.4: Add `ProviderGemini` to the pool system in `subscriptions/manager.go`. Allow Gemini API pools alongside Claude and Codex subscription pools.
- [ ] F3.5: Add tests: verify Gemini provider is selected for appropriate task types. Verify fallback works when Gemini is unavailable. Verify pool management handles Gemini pools.

---

## Cross-Phase Verification

After all enhancements are implemented, these system-level properties should hold:

1. Every task passes through the full state machine: Pending → Claimed → Executed → Verified → Reviewed → Committed
2. No task can merge without build + test + lint passing at the appropriate verification tier
3. Cross-model review is required for Standard and Thorough tiers
4. AI slop detection runs on every task's modified files
5. Hash-anchored editing prevents stale edits in worktrees
6. Hooks fire at all 9 lifecycle events
7. Notifications are sent for configured events
8. The HTTP server (if enabled) accurately reflects real-time build state
9. Plugins are isolated and cannot bypass built-in security hooks
10. Container detection adjusts sandbox behavior appropriately

## Ship Blockers

1. All existing tests (369 functions) must continue to pass
2. `go vet ./...` must pass with zero findings
3. `go build ./cmd/stoke` must succeed with no warnings
4. New features must not break backward compatibility with existing `stoke.policy.yaml` files
5. Hash-anchored editing must not degrade performance by more than 100ms per edit operation
6. The HTTP server must not leak sensitive information (API keys, OAuth tokens, policy internals)
