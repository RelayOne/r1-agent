# RT-1: Competitive Research -- claw-code (ultraworkers/claw-code)

Research date: 2026-04-03
Repository: https://github.com/ultraworkers/claw-code
Stars: 160,143 | Forks: 101,053
Created: 2026-03-31 | Primary language: Rust
Disk usage: ~6.4 MB

---

## 1. What Is It?

Claw-code is a clean-room reimplementation of the Claude Code agent harness. It originated when the Claude Code source was briefly exposed on March 31, 2026. The creator (Sigrid Jin / instructkr) reverse-engineered the architectural patterns into first a Python scaffold, then a full Rust port. The repo does NOT contain the original leaked source -- it is a from-scratch rewrite that mirrors the exposed system's design.

The project has two implementation surfaces:

- **Rust workspace** (`rust/crates/*`): The primary, actively-developed implementation. A full Cargo workspace with 8 crates covering API, runtime, CLI, tools, commands, plugins, server, and LSP.
- **Python workspace** (`src/`): A scaffolding/manifest layer used for parity auditing against the original system. Not a functional runtime -- it tracks which subsystems have been ported.

The project explicitly targets feature parity with Claude Code's agent harness, focusing on tool wiring, session orchestration, MCP integration, and plugin/hook extensibility.

---

## 2. Architecture

### Crate Organization (Rust workspace)

```
rust/crates/
  api/           -- API client with provider abstraction, OAuth, SSE streaming
  runtime/       -- Core engine: session, conversation loop, compaction, MCP,
                    permissions, sandbox, config, hooks, prompt builder, file ops
  tools/         -- Tool manifest, specs, execution framework, plugin tool integration
  commands/      -- Slash command registry, command parsing, plugin/config inspection
  plugins/       -- Plugin model, hook pipeline, bundled plugin support
  claw-cli/      -- Interactive REPL, markdown rendering, project bootstrap/init
  server/        -- HTTP/SSE server (axum-based) for session management
  lsp/           -- LSP client integration for diagnostics, go-to-definition, references
  compat-harness/-- Compatibility layer for extracting manifests from upstream TS source
```

### Key Architectural Patterns

1. **Trait-based abstraction**: `ApiClient`, `ToolExecutor`, `PermissionPrompter`, and `Provider` are all traits, enabling test doubles and swappable implementations.

2. **Generic conversation runtime**: `ConversationRuntime<C, T>` is parameterized over both the API client and tool executor, making the orchestration loop backend-agnostic.

3. **Layered configuration**: Three-level config merge (User -> Project -> Local) from `~/.claw/settings.json`, `.claw.json`, `.claw/settings.json`, and `.claw/settings.local.json`.

4. **Crate isolation**: Each concern is a separate Cargo crate with well-defined public APIs. The `runtime` crate is the dependency hub; `claw-cli` is the leaf binary.

5. **Compat-harness extraction**: A separate crate (`compat-harness`) can parse the original TypeScript source to extract command/tool/bootstrap manifests for parity tracking.

---

## 3. Features -- Complete List

### Core Runtime
- Agentic conversation loop with automatic tool calling
- Session state persistence (JSON serialization to disk)
- Session compaction with structured summarization
- Token estimation and compaction thresholds
- Usage tracking with per-model pricing (Haiku/Sonnet/Opus tiers)
- Cost estimation with cache-aware pricing (creation + read)
- Bootstrap phase pipeline (12 phases from CLI entry to main runtime)

### API / Provider System
- Anthropic Claude API client (Messages API, SSE streaming)
- OpenAI-compatible provider (xAI/Grok, OpenAI)
- Model alias resolution (opus -> claude-opus-4-6, grok -> grok-3, etc.)
- Provider auto-detection from model name or environment variables
- Automatic retry with exponential backoff (configurable retries, backoff, max delay)
- OAuth flow support (PKCE, token exchange, refresh, credential persistence)
- Bearer token + API key dual auth
- Configurable base URLs per provider

### Tools
- **bash**: Shell command execution with timeout, background mode, sandbox bypass
- **read_file**: File reading with offset/limit pagination
- **write_file**: File creation/update with structured patch output
- **edit_file**: String replacement with replace_all support, git diff output
- **glob_search**: Glob pattern matching sorted by modification time
- **grep_search**: Regex search with context lines, output modes, pagination, multiline
- **web_fetch**: URL content fetching
- **web_search**: Web search integration
- **todo_write**: TODO list management
- **skill**: Local skill file resolution and loading
- **agent**: Sub-agent spawning
- **config**: Configuration inspection
- **notebook_edit**: Jupyter notebook editing
- **repl**: REPL-style code execution
- **powershell**: Windows PowerShell execution
- Plugin-provided tools (dynamic registration from plugins)

### Slash Commands (26 commands)
- `/help` -- Command listing
- `/status` -- Session status display
- `/compact` -- Session compaction
- `/model [model]` -- Model switching
- `/permissions [mode]` -- Permission mode switching
- `/clear [--confirm]` -- Fresh session
- `/cost` -- Cumulative token usage
- `/resume <path>` -- Session restoration
- `/config [section]` -- Config inspection (env, hooks, model, plugins)
- `/memory` -- Instruction file inspection
- `/init` -- CLAW.md project bootstrap
- `/diff` -- Git diff display
- `/version` -- CLI version info
- `/export [file]` -- Conversation export
- `/session [list|switch]` -- Session management
- `/branch [list|create|switch]` -- Git branch management
- `/worktree [list|add|remove|prune]` -- Git worktree management
- `/commit` -- Auto-generated commit messages
- `/commit-push-pr [context]` -- Full commit-push-PR workflow
- `/pr [context]` -- Pull request drafting
- `/issue [context]` -- GitHub issue drafting
- `/ultraplan [task]` -- Deep multi-step planning
- `/teleport <symbol>` -- Workspace symbol/path jumping
- `/debug-tool-call` -- Last tool call replay with debug details
- `/plugin [list|install|enable|disable|uninstall|update]` -- Plugin management
- `/agents` -- Agent listing
- `/skills` -- Skill listing
- `/bughunter [scope]` -- Codebase bug inspection

### MCP (Model Context Protocol)
- Full MCP stdio process management (spawn, initialize, list tools, call tools, list/read resources)
- MCP server configuration via settings (stdio, SSE, HTTP, WebSocket, SDK, managed proxy)
- MCP tool namespacing (server_name__tool_name prefix convention)
- MCP OAuth config support
- CCR proxy URL unwrapping
- Server signature hashing for deduplication

### Session Management
- JSON-serialized session state with version tracking
- Session save/load to filesystem
- Session compaction with configurable preserved message count
- Incremental summary merging across multiple compactions
- Continuation message generation with suppressed follow-up questions
- Summary extraction (analysis stripping, tag block processing)
- Pending work inference from conversation history
- Key file reference tracking across sessions
- Current work inference for resume context

### Plugin System
- Three plugin kinds: Builtin, Bundled, External
- Plugin manifest format (`.claw-plugin/plugin.json`)
- Plugin registry with install/uninstall/enable/disable lifecycle
- Hook aggregation from enabled plugins (PreToolUse, PostToolUse)
- Plugin-provided custom tools with JSON schema definitions
- Plugin tool conflict detection (vs built-in tools)
- Marketplace concept (builtin/bundled/external sources)
- Plugin version tracking and update detection

### Hook System
- **PreToolUse hooks**: Run before any tool execution; can ALLOW, DENY, or WARN
- **PostToolUse hooks**: Run after tool execution; can retroactively deny results
- Hook execution via shell commands with environment variables:
  - `HOOK_EVENT`, `HOOK_TOOL_NAME`, `HOOK_TOOL_INPUT`, `HOOK_TOOL_OUTPUT`, `HOOK_TOOL_IS_ERROR`
- JSON payload piped to hook stdin (full tool context)
- Exit code protocol: 0 = allow, 2 = deny, other = warn (continue execution)
- Hook stdout captured as feedback messages injected into tool results
- Two independent hook systems:
  - Runtime hooks (from `settings.json` config)
  - Plugin hooks (from plugin manifests, aggregated across enabled plugins)
- Hook feedback merging into tool output

### LSP Integration
- Multi-server LSP manager with per-extension routing
- Go-to-definition support
- Find-references support (with include-declaration option)
- Workspace diagnostics collection
- Document lifecycle (open, change, save, close)
- Context enrichment for system prompt injection
- Lazy server initialization (connect on first use per language)
- Mock LSP server for testing

---

## 4. Unique Capabilities / What They Do Well

### A. Compaction System (Standout)
The compaction engine is notably sophisticated:
- Extracts recent user requests, pending work items, key file references, and current work direction
- Builds structured summaries with timeline reconstruction
- Supports incremental re-compaction (merging previous + new summaries)
- Generates continuation messages that suppress follow-up questions for seamless resume
- Uses tag-based formatting (analysis stripping, summary extraction)

This is better than a simple "summarize the conversation" approach. It preserves actionable state.

### B. Hook/Permission Architecture (Well-designed)
The hook system is genuinely extensible:
- Hooks run as arbitrary shell commands (not limited to JavaScript/Rust)
- Clear exit code protocol (0/2/other) avoids ambiguity
- Both pre and post hooks can inject feedback into the conversation
- Post hooks can retroactively deny tool results
- Plugin hooks and config hooks are independent systems that compose
- Permission system is trait-based with prompter injection for interactive escalation

### C. Provider Abstraction (Clean)
The multi-provider system is well-structured:
- Single `Provider` trait with `send_message` and `stream_message`
- Model alias registry maps friendly names to canonical IDs
- Auto-detection falls back through model name -> env vars -> default
- OpenAI-compatible provider covers xAI/Grok with minimal code
- Retry logic is provider-generic with configurable backoff

### D. Sandbox System (Thorough)
Full Linux sandbox implementation:
- Filesystem isolation modes: Off, WorkspaceOnly, AllowList
- Namespace restrictions via `unshare` (user, mount, IPC, PID, UTS, network)
- Container environment detection (Docker, Kubernetes, Podman markers)
- Fallback reasoning when sandbox features are unavailable
- Mount normalization (relative to CWD)
- Environment variable passthrough control

### E. Structured File Operations
All file operations produce structured output:
- Writes produce structured patches with hunk-level detail
- Edits include before/after content, git diff, user-modified flag
- Read operations support pagination (offset + limit)
- Grep supports multiple output modes (content, files_with_matches, count)

### F. HTTP/SSE Server (Novel)
The server crate provides a headless API:
- Session CRUD via REST endpoints
- Real-time SSE event streaming per session
- Broadcast-channel based event distribution
- Session snapshot on connect for state recovery
- This enables web dashboard or remote control patterns

---

## 5. Control Flow -- Agent Orchestration

### Conversation Loop (`ConversationRuntime::run_turn`)

```
User input
  |
  v
Append user message to session
  |
  v
LOOP (max_iterations guard):
  |
  +-> Build ApiRequest (system prompt + full message history)
  +-> Stream to API client
  +-> Parse events into assistant message + usage
  +-> Record usage in tracker
  +-> Append assistant message to session
  |
  +-> Extract pending tool uses from assistant blocks
  |
  +-- No tool uses? -> BREAK (turn complete)
  |
  +-- For each tool use:
  |     |
  |     +-> Check permission (PermissionPolicy.authorize)
  |     |     |
  |     |     +-- Denied? -> tool_result with denial reason
  |     |     |
  |     |     +-- Needs prompt? -> PermissionPrompter.decide()
  |     |     |
  |     |     +-- Allowed:
  |     |           |
  |     |           +-> Run PreToolUse hooks
  |     |           |     |
  |     |           |     +-- Hook denied? -> tool_result with hook message
  |     |           |     |
  |     |           |     +-- Hook allowed:
  |     |           |           |
  |     |           |           +-> Execute tool via ToolExecutor
  |     |           |           +-> Merge pre-hook feedback into output
  |     |           |           +-> Run PostToolUse hooks
  |     |           |           |     |
  |     |           |           |     +-- Hook denied? -> mark error, merge feedback
  |     |           |           |     +-- Hook allowed? -> merge feedback
  |     |           |           |
  |     |           |           +-> Append tool_result to session
  |     |
  +-> Continue loop (API sees tool results, generates next response)
  |
  v
Return TurnSummary (assistant messages, tool results, iterations, usage)
```

### Bootstrap Phases

The system has a 12-phase bootstrap pipeline:

1. **CliEntry** -- Parse CLI arguments
2. **FastPathVersion** -- Handle `--version` early exit
3. **StartupProfiler** -- Initialize profiling
4. **SystemPromptFastPath** -- Handle `--dump-system-prompt` early exit
5. **ChromeMcpFastPath** -- Handle Chrome MCP integration
6. **DaemonWorkerFastPath** -- Handle daemon worker mode
7. **BridgeFastPath** -- Handle remote-control bridge
8. **DaemonFastPath** -- Handle daemon mode
9. **BackgroundSessionFastPath** -- Handle background sessions
10. **TemplateFastPath** -- Handle template mode
11. **EnvironmentRunnerFastPath** -- Handle environment runner
12. **MainRuntime** -- Full interactive runtime

This suggests the original system supports multiple execution modes beyond the interactive CLI.

---

## 6. Quality Assurance

### Permission System
Five permission modes with escalation logic:
- **ReadOnly**: Can only read files
- **WorkspaceWrite**: Can read and write within workspace
- **DangerFullAccess**: Full system access
- **Prompt**: Interactive approval per tool call
- **Allow**: Auto-approve everything

Per-tool permission requirements are declared in tool specs. The system:
- Auto-allows when current mode >= required mode
- Prompts for escalation from WorkspaceWrite to DangerFullAccess
- Hard-denies ReadOnly to WorkspaceWrite escalations without a prompter
- Records all prompt decisions

### Hook-based Verification
- PreToolUse hooks can block dangerous operations before they execute
- PostToolUse hooks can retroactively reject results
- Hook messages are injected into the conversation for LLM awareness
- Non-zero exit codes (other than 2) produce warnings but don't block

### Iteration Guards
- `max_iterations` guard on the conversation loop (default: `usize::MAX`, configurable)
- Prevents infinite tool-calling loops

### Test Coverage
The Rust codebase includes integration tests for:
- Permission policy authorization (all escalation paths)
- Hook execution (allow/deny/warn exit codes)
- Plugin hook aggregation and execution
- Session compaction (incremental merging, summary formatting)
- API client retry logic
- Config loader (three-level merge)
- Sandbox detection (container markers)
- LSP manager (mock server integration)
- Server endpoints (create/list/get sessions, message sending, SSE streaming)

---

## 7. Hook/Plugin System

### Hooks (Two layers)

**Layer 1 -- Runtime Hooks** (from `settings.json`):
```json
{
  "hooks": {
    "PreToolUse": ["path/to/script.sh"],
    "PostToolUse": ["path/to/script.sh"]
  }
}
```

**Layer 2 -- Plugin Hooks** (from plugin manifests):
```json
{
  "hooks": {
    "PreToolUse": ["./hooks/pre.sh"],
    "PostToolUse": ["./hooks/post.sh"]
  }
}
```

Both layers use the same protocol:
- **stdin**: JSON payload with `hook_event_name`, `tool_name`, `tool_input`, `tool_output`, `tool_result_is_error`
- **env vars**: `HOOK_EVENT`, `HOOK_TOOL_NAME`, `HOOK_TOOL_INPUT`, `HOOK_TOOL_OUTPUT`, `HOOK_TOOL_IS_ERROR`
- **Exit 0**: Allow (stdout = feedback message)
- **Exit 2**: Deny (stdout = denial reason)
- **Other exit**: Warn (continue execution, log warning)

### Plugins

**Plugin Manifest** (`.claw-plugin/plugin.json`):
```json
{
  "name": "my-plugin",
  "version": "1.0.0",
  "description": "...",
  "hooks": {
    "PreToolUse": ["./hooks/pre.sh"],
    "PostToolUse": ["./hooks/post.sh"]
  }
}
```

**Plugin Lifecycle**:
- Install from local directory path
- Enable/disable per plugin
- Uninstall
- Update detection
- Registry persistence (`installed.json`)
- Plugin settings in `settings.json`

**Plugin Tools**:
Plugins can provide custom tools with JSON schema definitions. These are merged into the global tool registry with:
- Conflict detection against built-in tools
- Duplicate name detection across plugins
- Permission mode declaration
- Full tool execution delegation

---

## 8. Configuration System

### Config File Hierarchy (priority: Local > Project > User)

| Source  | Paths                                                      |
|---------|------------------------------------------------------------|
| User    | `~/.claw.json`, `~/.claw/settings.json`                   |
| Project | `./.claw.json`, `./.claw/settings.json`                    |
| Local   | `./.claw/settings.local.json`                              |

All files are JSON. Deep merge is applied with later sources overriding earlier.

### Config Sections

- **model**: Default model name
- **permissionMode**: Default permission level
- **hooks**: PreToolUse/PostToolUse command arrays
- **plugins**: Enabled plugins map, external directories, install root
- **mcpServers**: MCP server configurations (per-scope)
- **oauth**: OAuth client config (client_id, authorize_url, token_url, etc.)
- **sandbox**: Sandbox config (enabled, namespace, network, filesystem mode, allowed mounts)

### Instruction Files (CLAW.md discovery)

The system walks from CWD to filesystem root, collecting:
- `CLAW.md`
- `CLAW.local.md`
- `.claw/CLAW.md`
- `.claw/instructions.md`

All discovered instruction files are injected into the system prompt (up to 4,000 chars per file, 12,000 total).

---

## 9. Multi-Model Support

### Supported Providers

| Provider | Models                                          | Auth Env Var       |
|----------|-------------------------------------------------|--------------------|
| Claude   | opus, sonnet, haiku (+ versioned IDs)           | ANTHROPIC_API_KEY  |
| xAI      | grok, grok-3, grok-mini, grok-3-mini, grok-2   | XAI_API_KEY        |
| OpenAI   | (any model via compat endpoint)                 | OPENAI_API_KEY     |

### Provider Resolution

1. Check model name against registry (explicit mapping)
2. Check for Anthropic auth -> ClawApi
3. Check for OpenAI API key -> OpenAI
4. Check for xAI API key -> Xai
5. Fallback to ClawApi

### Model Aliases
- `opus` -> `claude-opus-4-6`
- `sonnet` -> `claude-sonnet-4-6`
- `haiku` -> `claude-haiku-4-5-20251213`
- `grok` / `grok-3` -> `grok-3`
- `grok-mini` / `grok-3-mini` -> `grok-3-mini`

### Token Limits
- Opus models: 32,000 max output tokens
- All others: 64,000 max output tokens

### Pricing Tiers
- Opus: $15/M input, $75/M output, $18.75/M cache write, $1.50/M cache read
- Sonnet: Same as Opus (default tier)
- Haiku: $1/M input, $5/M output, $1.25/M cache write, $0.10/M cache read

---

## 10. Session Management

### Session Format
```json
{
  "version": 1,
  "messages": [
    {
      "role": "user|assistant|system|tool",
      "blocks": [
        { "type": "text", "text": "..." },
        { "type": "tool_use", "id": "...", "name": "...", "input": "..." },
        { "type": "tool_result", "tool_use_id": "...", "tool_name": "...", "output": "...", "is_error": false }
      ],
      "usage": { "input_tokens": 0, "output_tokens": 0, "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0 }
    }
  ]
}
```

### Persistence
- Sessions save to JSON files on disk
- Load from path for resume
- Export to arbitrary file path

### Compaction Strategy
- Configurable: `preserve_recent_messages` (default: 4), `max_estimated_tokens` (default: 10,000)
- Compaction triggers when compactable messages exceed both count and token thresholds
- Summary includes: scope, tools mentioned, recent user requests, pending work, key files, current work, timeline
- Incremental: multiple compactions merge "previously compacted" and "newly compacted" contexts
- Continuation message suppresses follow-up questions for direct resume

### Server-Managed Sessions
The HTTP server crate provides:
- `POST /sessions` -- Create session
- `GET /sessions` -- List sessions with summary
- `GET /sessions/{id}` -- Get session details (full message history)
- `POST /sessions/{id}/message` -- Send message
- `GET /sessions/{id}/events` -- SSE event stream (snapshot on connect, live updates)

---

## 11. UI/UX

### CLI Interface
- Interactive REPL with line editor
- Shift+Enter / Ctrl+J for newline insertion
- Tab completion for slash commands
- Spinner animations for streaming and tool execution
- Markdown rendering for tool output
- Multiple output formats: Text (default), JSON, NDJSON
- Color theme support

### System Prompt Construction
- Dynamic boundary marker separating static/dynamic sections
- Environment context injection (model, CWD, date, platform)
- Git status and diff injection
- Instruction file discovery and injection
- Runtime config rendering
- LSP context enrichment (diagnostics, definitions, references)
- Output style customization

### Project Bootstrap
- `/init` command creates starter CLAW.md files
- `/memory` inspects discovered instruction files
- `/config` inspects merged configuration

---

## 12. Security Model

### Sandbox (Linux)
- **Namespace isolation** via `unshare`: user, mount, IPC, PID, UTS namespaces
- **Network isolation**: Optional network namespace (disabled by default)
- **Filesystem isolation** modes:
  - `off`: No restrictions
  - `workspace-only` (default): Restrict to workspace directory
  - `allow-list`: Only explicitly allowed mount paths
- **Container detection**: Checks `/.dockerenv`, `/run/.containerenv`, environment variables (`CONTAINER`, `DOCKER`, `PODMAN`, `KUBERNETES_SERVICE_HOST`), `/proc/1/cgroup` markers
- **Sandbox home/tmp**: Isolated HOME and TMPDIR within workspace
- **Fallback reasoning**: Reports why sandbox features are unavailable

### Permissions
- Five-level hierarchy: ReadOnly < WorkspaceWrite < DangerFullAccess < Prompt < Allow
- Per-tool permission requirements declared in tool specs
- Interactive escalation prompting with accept/deny
- Bash tool requires DangerFullAccess
- Read/grep/glob tools require ReadOnly
- Write/edit tools require WorkspaceWrite

### Auth Security
- OAuth PKCE flow with S256 code challenge
- Credential persistence to disk with scoped paths
- Token expiry checking
- API key redaction in logs (`masked_authorization_header`)
- No plaintext credential logging

---

## 13. Parity Assessment (vs Original Claude Code)

Based on the PARITY.md self-assessment and source analysis:

### What's at parity or near-parity:
- Core conversation loop
- API client with streaming
- Session persistence and compaction
- Tool execution framework (MVP set)
- Config system (three-level merge)
- Permission model
- Hook execution (both config and plugin)
- CLAW.md discovery
- MCP stdio bootstrapping

### What's NOT at parity:
- No remote/structured IO transport layer
- Missing many TS tools: AskUserQuestion, LSPTool, MCPTool, McpAuth, RemoteTrigger, ScheduleCron, Task*, Team*
- No TS-style handler decomposition (auth/plugins/MCP/agents)
- Plugins are config-only in many flows; no full marketplace
- Skills are local-file only (no bundled skill registry)
- Missing broader service ecosystem (analytics, settings sync, policy limits, team memory)
- JSON output cleanliness still imperfect for tool-capable mode

---

## 14. Competitive Insights

### What They Do Better Than Expected

1. **Rust implementation quality**: The crate structure is clean, idiomatic Rust. Trait-based abstractions, proper error handling, `#[must_use]` annotations, comprehensive tests. This is not a quick hack.

2. **Two-layer hook system**: Having both config-level and plugin-level hooks that compose independently is more flexible than a single hook system.

3. **Compaction with incremental merging**: The ability to re-compact already-compacted sessions while preserving previous context is sophisticated.

4. **HTTP server for headless operation**: The SSE-based server crate enables web dashboards, remote control, and multi-session management without the CLI.

5. **Container-aware sandbox**: Auto-detecting Docker/K8s/Podman and adjusting sandbox strategy is production-ready thinking.

6. **Compat-harness for parity tracking**: Building a separate crate that can parse the original TS source for automated parity auditing is clever engineering discipline.

### What They Do Worse / Gaps

1. **No anti-laziness measures**: No output quality verification, no self-review loops, no verification of agent work. The system trusts the LLM output.

2. **No multi-agent orchestration**: While there's an "agent" tool concept, there's no team mode, parallel agent coordination, or agent-to-agent communication.

3. **No wisdom/learning accumulation**: No mechanism to learn from past sessions or accumulate project-specific knowledge beyond CLAW.md files.

4. **No cost controls**: Usage tracking exists but no budget limits, alerts, or automatic session termination at cost thresholds.

5. **Limited output verification**: No build/test/lint verification after code changes. The agent can write code but nothing checks if it compiles.

6. **160K stars, 101K forks**: Extreme virality driven by the leak controversy, not necessarily by technical merit. The actual active contributor base appears small (primarily 2-3 people).

---

## 15. Key Source Files Reference

| File | Purpose |
|------|---------|
| `rust/crates/runtime/src/conversation.rs` | Agentic conversation loop |
| `rust/crates/runtime/src/session.rs` | Session state model |
| `rust/crates/runtime/src/compact.rs` | Compaction engine |
| `rust/crates/runtime/src/config.rs` | Three-level config system |
| `rust/crates/runtime/src/permissions.rs` | Permission model |
| `rust/crates/runtime/src/sandbox.rs` | Linux sandbox |
| `rust/crates/runtime/src/prompt.rs` | System prompt builder |
| `rust/crates/runtime/src/hooks.rs` | Runtime hook execution |
| `rust/crates/runtime/src/mcp.rs` | MCP naming/routing |
| `rust/crates/runtime/src/mcp_stdio.rs` | MCP process management |
| `rust/crates/runtime/src/usage.rs` | Cost tracking |
| `rust/crates/runtime/src/file_ops.rs` | File operation tools |
| `rust/crates/api/src/providers/mod.rs` | Multi-provider routing |
| `rust/crates/api/src/providers/claw_provider.rs` | Anthropic API client |
| `rust/crates/api/src/providers/openai_compat.rs` | OpenAI/xAI compat client |
| `rust/crates/plugins/src/lib.rs` | Plugin registry/lifecycle |
| `rust/crates/plugins/src/hooks.rs` | Plugin hook execution |
| `rust/crates/tools/src/lib.rs` | Tool specs and execution |
| `rust/crates/commands/src/lib.rs` | Slash command registry |
| `rust/crates/claw-cli/src/app.rs` | REPL and CLI app |
| `rust/crates/server/src/lib.rs` | HTTP/SSE server |
| `rust/crates/lsp/src/manager.rs` | LSP client manager |
| `rust/crates/compat-harness/src/lib.rs` | TS parity extraction |
| `PARITY.md` | Self-assessed gap analysis |
