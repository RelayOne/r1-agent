# RT-4: Competitive Research -- oh-my-claudecode (OMC)

**Source:** https://github.com/Yeachan-Heo/oh-my-claudecode
**Date:** 2026-04-03
**Status:** Complete

---

## 1. What Is It?

**oh-my-claudecode** (OMC) is a multi-agent orchestration layer for Claude Code. It transforms Claude Code from a single-agent CLI into a full team-based AI coding system with 19 specialized agents, multiple orchestration modes, and persistent execution loops.

| Attribute | Value |
|-----------|-------|
| **Language** | TypeScript (primary), JavaScript, Shell, Python |
| **Code size** | ~13.3 MB source (7.4 MB TS, 5.7 MB JS, 132 KB Shell, 116 KB Python) |
| **Repo size** | 34 MB (includes assets, benchmarks, translations) |
| **Stars** | 22,923 |
| **Forks** | 2,025 |
| **License** | MIT |
| **npm package** | `oh-my-claude-sisyphus` |
| **Current version** | v4.10.1 (released 2026-04-03) |
| **Created** | 2026-01-09 |
| **Creator** | Yeachan Heo (@Yeachan-Heo) |
| **Key dependencies** | `@anthropic-ai/claude-agent-sdk`, `@modelcontextprotocol/sdk`, `@ast-grep/napi`, `better-sqlite3`, `commander`, `zod` |

**One-liner:** "Teams-first multi-agent orchestration for Claude Code. Zero learning curve."

The project is a Claude Code plugin (marketplace-installable) that hooks into Claude Code's lifecycle events to inject orchestration behaviors -- magic keyword detection, agent delegation, persistent execution loops, and team coordination -- entirely through prompt injection via `<system-reminder>` tags and MCP tool servers.

---

## 2. Architecture

### 2.1 Four-System Architecture

OMC is built on four interlocking systems:

```
User Input --> Hooks (event detection) --> Skills (behavior injection)
           --> Agents (task execution) --> State (progress tracking)
```

1. **Hooks** -- React to Claude Code lifecycle events (11 events: UserPromptSubmit, SessionStart, PreToolUse, PermissionRequest, PostToolUse, PostToolUseFailure, SubagentStart, SubagentStop, PreCompact, Stop, SessionEnd). Implemented as Node.js scripts with timeouts, registered in `hooks/hooks.json`.

2. **Skills** -- Behavior injections that modify orchestrator operation. Not agent swaps; they add capabilities on top of existing agents. 31+ skills organized in three layers:
   - **Guarantee Layer** (optional): ralph persistence ("cannot stop until verified done")
   - **Enhancement Layer** (0-N): ultrawork (parallel), git-master (commits), etc.
   - **Execution Layer** (primary): default (build), orchestrate (coordinate), planner (plan)

3. **Agents** -- 19 specialized agents in 4 lanes, each with dedicated prompt files in `agents/*.md`:
   - Build/Analysis: explore, analyst, planner, architect, debugger, executor, verifier, tracer
   - Review: security-reviewer, code-reviewer
   - Domain: test-engineer, designer, writer, qa-tester, scientist, git-master, document-specialist, code-simplifier
   - Coordination: critic

4. **State** -- Persistent `.omc/` directory with mode state, notepad, project memory, plans, session logs. Survives context compaction and session restarts.

### 2.2 Directory Structure (Source)

```
src/
  agents/          -- Agent prompt generation and preamble injection
  autoresearch/    -- Autonomous research runtime
  cli/             -- CLI entry points (omc command, ask, team, hud)
  commands/        -- CLI subcommands
  config/          -- Configuration loading, model resolution, plan output
  constants/       -- Shared constants
  features/        -- Feature modules (model-routing, delegation, magic-keywords, state-manager, etc.)
  hooks/           -- Hook implementations (45+ hooks across 11 lifecycle events)
  hud/             -- Heads-up display rendering and state management
  installer/       -- Setup and installation logic
  interop/         -- Cross-tool interoperability
  lib/             -- Core utilities (atomic-write, file-lock, security-config, session-isolation)
  mcp/             -- MCP server implementations (tools server, team server)
  notifications/   -- Telegram, Discord, Slack, webhook, file dispatchers
  openclaw/        -- OpenClaw gateway integration
  planning/        -- Planning system
  platform/        -- Platform-specific code
  providers/       -- Git platform providers (GitHub, GitLab, Bitbucket, Azure DevOps, Gitea)
  ralphthon/       -- Ralph marathon runtime
  shared/          -- Shared types
  skills/          -- Skill runtime and built-in skills
  team/            -- Team orchestration (60+ files: runtime, tmux, worker management, state, etc.)
  tools/           -- MCP tool definitions (LSP, AST, state, notepad, memory, trace)
  types/           -- TypeScript type definitions
  utils/           -- Shared utilities
  verification/    -- Verification tier selection

bridge/            -- Entry points: cli.cjs, mcp-server.cjs, team-bridge.cjs, team-mcp.cjs
hooks/             -- hooks.json (lifecycle event registration)
skills/            -- 36 skill directories, each with SKILL.md prompt files
agents/            -- 19 agent prompt markdown files
scripts/           -- Hook scripts (keyword-detector, persistent-mode, session management, etc.)
```

### 2.3 Plugin Architecture

OMC installs as a Claude Code plugin via `.claude-plugin/plugin.json`:
```json
{
  "name": "oh-my-claudecode",
  "version": "4.10.1",
  "skills": "./skills/",
  "mcpServers": "./.mcp.json"
}
```

The MCP server (`bridge/mcp-server.cjs`) provides tools (state, notepad, memory, LSP, AST, trace), while hooks inject behavior via `<system-reminder>` tags on every lifecycle event.

---

## 3. Features -- Complete List

### 3.1 Orchestration Modes

| Mode | Type | Description |
|------|------|-------------|
| **Team** | Multi-agent, staged pipeline | Canonical mode. `team-plan -> team-prd -> team-exec -> team-verify -> team-fix` loop. N Claude agents on shared task list. |
| **omc team (CLI)** | tmux workers | Real `claude`/`codex`/`gemini` CLI processes in tmux split-panes. On-demand spawn, die when done. |
| **ccg** | Tri-model | `/ask codex` + `/ask gemini`, Claude synthesizes. Cross-model advisory. |
| **Autopilot** | Single-lead autonomous | 5-stage pipeline: Expansion -> Planning -> Execution -> QA -> Validation. End-to-end from idea to verified code. |
| **Ralph** | Persistent loop | PRD-driven persistence loop. Keeps working until ALL user stories have `passes: true` and reviewer-verified. Includes mandatory deslop pass + regression re-verification. |
| **Ultrawork** | Maximum parallelism | Burst parallel agents for independent tasks. Non-team. |
| **Pipeline** | Sequential stages | Multi-step transformations with strict ordering. |
| **UltraQA** | QA cycling | Test -> verify -> fix -> repeat until all pass. |
| **Ralplan** | Consensus planning | Planner + Architect + Critic loop until consensus. Supports `--deliberate` for high-risk. |
| **Deep Interview** | Requirements gathering | Ouroboros-inspired Socratic questioning with mathematical ambiguity scoring. Refuses to proceed until ambiguity drops below threshold (default 20%). |

### 3.2 Agent Catalog (19 Agents)

| Agent | Default Tier | Model | Role |
|-------|-------------|-------|------|
| explore | LOW | Haiku | Codebase discovery, file/symbol mapping |
| analyst | HIGH | Opus | Requirements analysis, hidden constraint discovery |
| planner | HIGH | Opus | Task sequencing, execution plan creation |
| architect | HIGH | Opus | System design, interfaces, trade-off analysis (READ-ONLY) |
| debugger | MEDIUM | Sonnet | Root-cause analysis, build error resolution |
| executor | MEDIUM | Sonnet | Code implementation, refactoring |
| verifier | MEDIUM | Sonnet | Completion verification, test adequacy |
| tracer | MEDIUM | Sonnet | Evidence-driven causal tracing, competing hypothesis analysis |
| security-reviewer | MEDIUM | Sonnet | Vulnerability scanning, trust boundary review |
| code-reviewer | HIGH | Opus | Comprehensive code review, API contracts |
| test-engineer | MEDIUM | Sonnet | Test strategy, coverage, flaky-test hardening |
| designer | MEDIUM | Sonnet | UI/UX architecture, interaction design |
| writer | LOW | Haiku | Documentation, migration notes |
| qa-tester | MEDIUM | Sonnet | Interactive CLI/service runtime validation |
| scientist | MEDIUM | Sonnet | Data analysis, statistical research |
| git-master | MEDIUM | Sonnet | Git operations, history management |
| document-specialist | MEDIUM | Sonnet | External documentation, API/SDK reference lookup |
| code-simplifier | HIGH | Opus | Code clarity, simplification, maintainability |
| critic | HIGH | Opus | Gap analysis of plans and designs, multi-angle review |

### 3.3 Skill Catalog (36+ Skills)

**Workflow skills:** autopilot, ralph, ultrawork, team, ccg, ultraqa, plan, ralplan, deep-interview, sciomc, external-context, deepinit, visual-verdict, ai-slop-cleaner, self-improve, skillify, verify

**Utility skills:** cancel, hud, omc-setup, omc-doctor, learner, skill, trace, release, project-session-manager, writer-memory, configure-notifications, mcp-setup, remember, omc-reference, ask, setup, debug, deep-dive, omc-teams

### 3.4 Tool Catalog (MCP Tools)

**State & Memory:**
- `state_read`, `state_write`, `state_clear`, `state_list_active`, `state_get_status`
- `project_memory_read`, `project_memory_write`, `project_memory_add_note`, `project_memory_add_directive`
- `notepad_read`, `notepad_write_priority`, `notepad_write_working`, `notepad_write_manual`, `notepad_prune`, `notepad_stats`

**Code Intelligence:**
- LSP: `lsp_hover`, `lsp_goto_definition`, `lsp_find_references`, `lsp_diagnostics`, `lsp_diagnostics_directory`, `lsp_document_symbols`, `lsp_workspace_symbols`, `lsp_servers`
- AST: `ast_grep_search`, `ast_grep_replace` (via @ast-grep/napi)
- `python_repl` (sandboxed)

**Trace:**
- `trace_timeline`, `trace_summary`

**Team (native Claude Code):**
- `TeamCreate`, `TeamDelete`, `SendMessage`, `TaskCreate`, `TaskList`, `TaskGet`, `TaskUpdate`

### 3.5 Additional Features

- **Magic Keywords** -- 15+ trigger words/phrases that auto-activate skills (e.g., "autopilot", "ralph", "ulw", "ralplan", "deep-interview", "deepsearch", "ultrathink", "tdd")
- **HUD Statusline** -- Real-time tmux status bar showing agent activity, token usage, model quotas, background tasks, elapsed time, worktree detection, current phase, last tool used
- **Skill Learning** -- `/learner` extracts reusable patterns from sessions with quality gates; skills stored in `.omc/skills/` (project) or `~/.omc/skills/` (user)
- **Auto-inject skills** -- Matching skills loaded into context automatically based on trigger patterns
- **Notifications** -- Telegram, Discord, Slack, file, and webhook notification dispatchers with tag lists, session summaries, and rate-limit callbacks
- **OpenClaw Integration** -- Forward session events to OpenClaw gateway for automated responses/workflows
- **Provider Advisor (`omc ask`)** -- Run local Claude/Codex/Gemini CLIs, save markdown artifacts to `.omc/artifacts/ask/`
- **Rate Limit Wait** -- Auto-resume daemon for Claude Code rate limits via tmux session detection
- **Autoresearch** -- Autonomous research runtime with guided sessions and timed evaluations
- **Session History** -- Session summaries (`.omc/sessions/*.json`), replay logs (`.omc/state/agent-replay-*.jsonl`)
- **Codebase Map** -- Startup codebase indexing (max 200 files, 4 depth)
- **Task Size Detection** -- Auto-classifies task complexity and suppresses heavy modes for small tasks
- **Prompt Prerequisites** -- Enforces memory/skills/verify-first/context sections before blocking tool use
- **Context Guard** -- Monitors context usage and warns when approaching limits
- **Pre-compact Memory Save** -- Saves critical information to notepad before context compaction
- **Code Simplifier** -- Optional auto-simplification of modified files on session stop
- **Benchmark Suite** -- Prompt benchmarks with baseline comparison
- **Multi-language README** -- 11 languages (EN, KO, ZH, JA, ES, VI, PT, DE, FR, IT, RU, TR)
- **Git Platform Providers** -- GitHub, GitLab, Bitbucket, Azure DevOps, Gitea support

---

## 4. Unique Capabilities / Novel Design

### 4.1 PRD-Driven Persistence (Ralph)

Ralph is genuinely novel. It structures work into discrete user stories with testable acceptance criteria (`prd.json`), iterates story-by-story, requires fresh reviewer verification against specific criteria, and includes a mandatory deslop pass + regression re-verification. This is not just "retry until done" -- it is requirements-traceable persistence.

Key innovation: The auto-generated PRD scaffold has generic criteria that the system is explicitly instructed to REPLACE with task-specific, verifiable criteria. This prevents "PRD theater."

### 4.2 Mathematical Ambiguity Gating (Deep Interview)

The deep-interview skill uses Ouroboros-inspired Socratic questioning with a mathematical clarity scoring system across weighted dimensions (Goal Clarity, Constraint Clarity, Success Criteria, Context Clarity, Scope). Each round targets the weakest dimension. Execution is blocked until ambiguity drops below a configurable threshold (default 20%). This is a formal quality gate on requirements, not just "ask questions."

### 4.3 Three-Stage Pipeline

The recommended full pipeline chains three quality gates:
```
deep-interview (ambiguity <= 20%)
  -> ralplan (Planner/Architect/Critic consensus)
    -> autopilot (skips Phase 0+1, starts at Execution)
```
This ensures maximum clarity at every stage -- requirements are validated, architecture is reviewed, and quality is checked before any code is written.

### 4.4 Tiered Verification

Verification effort scales with change size:
- LIGHT (<5 files, <100 lines, full tests): Haiku-tier agent, only needs clean diagnostics
- STANDARD (default): Sonnet-tier, needs diagnostics + build pass
- THOROUGH (>20 files or security/arch): Opus-tier, full architect review + all tests + regression check

This is cost-conscious -- small changes get cheap verification, large changes get thorough review.

### 4.5 Skill Composability (Three-Layer Model)

Skills compose in layers:
```
[Execution Skill] + [0-N Enhancements] + [Optional Guarantee]
```
Example: `ralph` + `ultrawork` + `git-master` = persistent parallel execution with atomic commits. This compositional model is more flexible than simple mode switching.

### 4.6 Prompt Injection via Hooks

OMC does not modify Claude Code's internals. It operates entirely through lifecycle hooks that inject `<system-reminder>` tags, MCP tool servers, and skill prompt files. This is architecturally clean -- it is a plugin, not a fork. The hook system covers all 11 Claude Code lifecycle events with 20+ individual hook scripts.

### 4.7 Commit Protocol with Decision Tracing

Structured git trailers capture decision context:
```
Constraint: Auth service does not support token introspection
Rejected: Extend token TTL to 24h | security policy violation
Confidence: high
Scope-risk: narrow
Directive: Error handling is intentionally broad -- do not narrow without verifying upstream
Not-tested: Auth service cold-start latency >500ms
```
This preserves architectural intent in the commit history, not just what changed.

### 4.8 Anti-Slop System

The `ai-slop-cleaner` skill identifies and removes AI-generated code patterns: duplicate code, dead code, needless abstractions, boundary violations. It uses separate writer/reviewer passes and can be invoked standalone or as part of Ralph's mandatory deslop pass.

---

## 5. Control Flow -- Agent Orchestration

### 5.1 Team Pipeline (Canonical Mode)

```
team-plan -> team-prd -> team-exec -> team-verify -> team-fix (loop)
```

1. **team-plan**: Decompose task into subtasks, assign to agents
2. **team-prd**: Generate acceptance criteria and scope
3. **team-exec**: N agents execute in parallel via tmux split-panes, sharing a task list (file-based, `.omc/state/team/{name}/tasks/`)
4. **team-verify**: Verification agent checks all work against criteria
5. **team-fix**: Fix loop (bounded by max attempts) feeds back into exec or verify

Workers are real CLI processes (claude, codex, gemini) spawned in tmux panes. They communicate via file-based inbox/outbox messaging. A watchdog monitors heartbeats and detects dead workers for task requeuing.

### 5.2 Autopilot Pipeline

```
Phase 0: Expansion (Analyst + Architect -> spec.md)
Phase 1: Planning (Architect creates plan, Critic validates)
Phase 2: Execution (Ralph + Ultrawork parallel agents)
Phase 3: QA (UltraQA cycling: build -> lint -> test -> fix, up to 5 cycles)
Phase 4: Validation (Architect + Security-reviewer + Code-reviewer in parallel)
Phase 5: Cleanup (state file deletion)
```

If a ralplan consensus plan exists, Phase 0 and Phase 1 are skipped entirely.

### 5.3 Ralph Persistence Loop

```
1. PRD Setup (generate/refine prd.json with task-specific acceptance criteria)
2. Pick next story (highest priority with passes: false)
3. Implement (delegate to executor at appropriate tier)
4. Verify story acceptance criteria (fresh evidence)
5. Mark story complete (passes: true, record in progress.txt)
6. Check PRD completion (all stories done? -> architect verification)
7. Reviewer verification (tiered: STANDARD minimum for Ralph)
7.5. Mandatory deslop pass (ai-slop-cleaner on changed files)
7.6. Regression re-verification (post-deslop)
8. On approval: cancel and clean up
9. On rejection: fix and re-verify
```

The "boulder never stops" hook on the Stop event prevents Claude from stopping when ralph/ultrawork is active.

### 5.4 Delegation Rules

```
Delegate for: multi-file changes, refactors, debugging, reviews, planning, research, verification
Work directly for: trivial ops, small clarifications, single commands
Route code to executor (use model=opus for complex work)
Uncertain SDK usage -> document-specialist (repo docs first, web fallback)
```

Model routing: Haiku for quick lookups, Sonnet for standard work, Opus for architecture/deep analysis. Escalation keywords trigger tier upgrades (e.g., "critical", "security", "architecture").

---

## 6. Quality Assurance

### 6.1 Verification Protocol

Standard checks before completion:
- BUILD: Compilation passes
- TEST: All tests pass
- LINT: No linting errors
- FUNCTIONALITY: Feature works as expected
- ARCHITECT: Opus-tier review approval (for significant changes)
- TODO: All tasks completed
- ERROR_FREE: No unresolved errors

Evidence must be fresh (within 5 minutes) and include actual command output.

### 6.2 Tiered Verification (Automatic)

The `selectVerificationTier()` function in `src/verification/tier-selector.ts` automatically selects verification effort:
- Detects architectural changes (config files, schemas, types, package.json, tsconfig)
- Detects security implications (auth, permissions, credentials, secrets, tokens, OAuth, JWT patterns)
- Scales from LIGHT to THOROUGH based on file count, line count, and pattern detection

### 6.3 Multi-Perspective Validation (Autopilot Phase 4)

Three parallel reviewers must all approve:
1. Architect: Functional completeness
2. Security-reviewer: Vulnerability check
3. Code-reviewer: Quality review

Rejection triggers fix + re-validation.

### 6.4 Post-Tool Verification

The `verify-deliverables.mjs` hook fires on `SubagentStop` to verify agent output. The `post-tool-verifier.mjs` hook fires on every `PostToolUse` event.

### 6.5 Anti-Slop Quality Gate

Ralph's mandatory deslop pass (`ai-slop-cleaner`) identifies AI-generated code patterns and cleans them, followed by regression re-verification to ensure the cleanup did not break anything.

### 6.6 Prompt Prerequisites

The `promptPrerequisites` feature enforces that memory, skills, verify-first, and context sections are present before allowing blocking tools (Edit, Write, Agent, Task) to execute.

---

## 7. Hook/Plugin System -- Extensibility Points

### 7.1 Lifecycle Hooks (11 Events)

| Event | When | OMC Hook Scripts |
|-------|------|-----------------|
| `UserPromptSubmit` | User submits prompt | keyword-detector, skill-injector |
| `SessionStart` | Session begins | session-start, project-memory-session, setup-init, setup-maintenance |
| `PreToolUse` | Before tool use | pre-tool-enforcer |
| `PermissionRequest` | Permission requested | permission-handler |
| `PostToolUse` | After tool use | post-tool-verifier, project-memory-posttool |
| `PostToolUseFailure` | After tool failure | post-tool-use-failure |
| `SubagentStart` | Subagent starts | subagent-tracker start |
| `SubagentStop` | Subagent stops | subagent-tracker stop, verify-deliverables |
| `PreCompact` | Before compaction | pre-compact, project-memory-precompact |
| `Stop` | About to stop | context-guard-stop, persistent-mode, code-simplifier |
| `SessionEnd` | Session ends | session-end |

### 7.2 Custom Skills

Users can create custom skills at two scopes:
- **Project scope:** `.omc/skills/` (version-controlled, higher priority)
- **User scope:** `~/.omc/skills/` (all projects, lower priority)

Skills are YAML frontmatter + markdown files with trigger patterns for auto-injection:
```yaml
---
name: Fix Proxy Crash
description: aiohttp proxy crashes on ClientDisconnectedError
triggers: ["proxy", "aiohttp", "disconnected"]
source: extracted
---
Wrap handler at server.py:42 in try/except...
```

Managed via: `/skill list | add | remove | edit | search`

### 7.3 MCP Server Extensibility

The `.mcp.json` config registers MCP servers. OMC provides:
- `t` (main tools server): state, notepad, memory, LSP, AST, trace tools
- Optional: Exa (web search), Context7 (external docs)

### 7.4 Kill Switches

- `DISABLE_OMC=1` -- Disable all hooks
- `OMC_SKIP_HOOKS="keyword-detector,persistent-mode"` -- Skip specific hooks
- `cancelomc` / `stopomc` -- Cancel active execution modes

### 7.5 OpenClaw Integration

6 hook events can forward to an external OpenClaw gateway: session-start, stop, keyword-detector, ask-user-question, pre-tool-use, post-tool-use.

---

## 8. Configuration System

### 8.1 Config File Locations

| Location | Scope | Format |
|----------|-------|--------|
| `~/.config/claude-omc/config.jsonc` | User | JSONC |
| `.claude/omc.jsonc` | Project | JSONC |
| Environment variables | Process | Various |

Project config overrides user config via `deepMerge`.

### 8.2 Configuration Categories

**Agent models:** Per-agent model assignment (19 agents, each configurable)
```jsonc
{
  "agents": {
    "explore": { "model": "claude-haiku-4-5" },
    "architect": { "model": "claude-opus-4-6" },
    "executor": { "model": "claude-sonnet-4-6" }
  }
}
```

**Feature flags:**
- `parallelExecution`, `lspTools`, `astTools`, `continuationEnforcement`, `autoContextInjection`

**Model routing:**
- Tier models (LOW/MEDIUM/HIGH), agent overrides, escalation keywords, simplification keywords
- Escalation enabled/disabled, max escalations, force inherit

**External models:**
- Codex/Gemini default models, fallback policy (provider_chain, cross-provider order)

**Delegation routing:**
- Optional external model routing per agent role

**Magic keywords:**
- Configurable trigger word lists for ultrawork, search, analyze, ultrathink categories

**Plan output:**
- Directory and filename template for plans

**Task size detection:**
- Word limits for small/large classification, suppress heavy modes for small tasks

**Security:**
- `restrictToolPaths`, `pythonSandbox`, `disableRemoteMcp`, `disableExternalLLM`, `disableAutoUpdate`, `hardMaxIterations`

### 8.3 Environment Variables (Key Ones)

| Variable | Purpose |
|----------|---------|
| `OMC_MODEL_HIGH` | Override HIGH tier model |
| `OMC_MODEL_MEDIUM` | Override MEDIUM tier model |
| `OMC_MODEL_LOW` | Override LOW tier model |
| `OMC_SECURITY=strict` | Enable all security features |
| `OMC_STATE_DIR` | Centralized state directory |
| `DISABLE_OMC` | Disable all hooks |
| `OMC_SKIP_HOOKS` | Skip specific hooks |
| `OMC_TRUSTED_CLI_DIRS` | Additional trusted binary paths |
| `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` | Enable native teams |
| `OMC_CODEX_DEFAULT_MODEL` | Default Codex model |
| `OMC_GEMINI_DEFAULT_MODEL` | Default Gemini model |

---

## 9. Multi-Model Support

### 9.1 Claude Model Tiers

Three tiers with configurable models:
- **LOW** (Haiku): Fast lookups, exploration, writing
- **MEDIUM** (Sonnet): Implementation, debugging, testing, most agent work
- **HIGH** (Opus): Architecture, planning, critical review, code review

Default models (v4.10.1): claude-haiku-4-5, claude-sonnet-4-6, claude-opus-4-6

### 9.2 External AI Providers

| Provider | Integration | What It Enables |
|----------|-------------|-----------------|
| **Claude** | Native (primary) | All agent work |
| **Codex (OpenAI)** | CLI worker via tmux, `/ask codex` | Architecture validation, code review cross-check |
| **Gemini (Google)** | CLI worker via tmux, `/ask gemini` | Design review, UI consistency (1M token context) |

Multi-model orchestration via:
- `omc team N:codex "..."` -- N Codex CLI workers in tmux
- `omc team N:gemini "..."` -- N Gemini CLI workers in tmux
- `/ccg` -- Tri-model advisory (Codex + Gemini + Claude synthesis)

### 9.3 Model Resolution Precedence (Team Workers)

1. Explicit `--model` in worker launch args
2. Direct provider model env (`ANTHROPIC_MODEL` / `CLAUDE_MODEL`)
3. Provider tier envs (`CLAUDE_CODE_BEDROCK_SONNET_MODEL`, etc.)
4. OMC tier env (`OMC_MODEL_MEDIUM`)
5. Claude Code default

### 9.4 Provider-Specific Support

- **AWS Bedrock**: Recognizes Bedrock model IDs, passes as-is (no alias normalization)
- **Google Vertex AI**: Recognizes Vertex model IDs, passes as-is
- Fallback policy: `provider_chain` with optional cross-provider fallback

---

## 10. Session Management

### 10.1 State Persistence

**Directory:** `.omc/` (per-project)

```
.omc/
  state/                    -- Per-mode state files (JSON)
    autopilot-state.json
    ralph-state.json
    team/{teamName}/        -- Team task state
    sessions/{sessionId}/   -- Per-session isolated state
  notepad.md                -- Compaction-resistant memo pad
  project-memory.json       -- Cross-session project knowledge
  plans/                    -- Execution plans
  notepads/{plan-name}/     -- Per-plan knowledge capture
  autopilot/spec.md         -- Autopilot spec output
  research/                 -- Research results
  logs/                     -- Execution logs
  skills/                   -- Project-scoped custom skills
  sessions/*.json           -- Session summaries
  artifacts/ask/            -- Provider advisor artifacts
```

### 10.2 Context Compaction Survival

The `PreCompact` hook saves critical information to the notepad before context window compression. After compaction, notepad contents are re-injected into context.

### 10.3 Persistent Memory Tags

```xml
<remember>API endpoint changed to /v2</remember>          <!-- 7 days -->
<remember priority>Never access production DB</remember>    <!-- Permanent -->
```

### 10.4 Project Memory

Cross-session knowledge store (`project-memory.json`):
- Loaded on SessionStart
- Updated on PostToolUse (auto-extract knowledge)
- Saved on PreCompact
- Supports notes, directives, and free-form entries

### 10.5 Session Isolation

Per-session state stored in `.omc/state/sessions/{sessionId}/` prevents conflicts between concurrent sessions on the same project.

### 10.6 Centralized State (Optional)

`OMC_STATE_DIR` preserves state across worktree deletions:
```bash
export OMC_STATE_DIR="$HOME/.claude/omc"
```
Project identifier is a hash of Git remote URL, so the same repo shares state across worktrees.

### 10.7 Resume Capability

Skills like autopilot and ralph detect existing state and resume from the last incomplete stage. Team mode resumes from the last incomplete pipeline phase.

---

## 11. UI/UX

### 11.1 CLI (`omc` command)

Main entry point: `bridge/cli.cjs` (3 binary names: `oh-my-claudecode`, `omc`, `omc-cli`)

Subcommands:
- `omc team N:type "task"` -- Team orchestration
- `omc ask claude|codex|gemini "query"` -- Provider advisor
- `omc wait [--start|--stop]` -- Rate limit auto-resume
- `omc hud` -- Live HUD rendering
- `omc config-stop-callback` -- Notification configuration

### 11.2 HUD (Heads-Up Display)

Real-time tmux statusline showing:
- Agent activity and counts
- Token usage and per-model weekly quotas (sn:/op:)
- Background task status
- Elapsed time since prompt
- Worktree detection
- Current phase (autopilot/ralph/team)
- Last tool name used
- OSC 8 terminal hyperlinks for cwd

Configurable presets: `"focused"`, etc.

### 11.3 Magic Keywords (Natural Language)

No commands to memorize. Include a keyword in natural language and the skill activates:
- "autopilot build me a todo app" -> activates autopilot
- "ralph: refactor the auth module" -> activates ralph
- "ulw fix all errors" -> activates ultrawork
- "deep-interview I have a vague idea" -> activates Socratic interview

### 11.4 Slash Commands

All skills invocable as `/oh-my-claudecode:<name>` or via Claude Code skill aliases.

### 11.5 Notifications

Session summaries and events dispatched to:
- Telegram (with @mention tags)
- Discord (user IDs, role IDs, @here/@everyone)
- Slack (member IDs, channels, subteams)
- File output
- Generic webhooks

---

## 12. Security Model

### 12.1 Strict Mode

`OMC_SECURITY=strict` enables all security features at once:
- Tool path restriction (AST tools confined to project root)
- Python REPL sandbox (blocks os, subprocess, shutil, socket, etc.)
- Remote MCP server disable (no Exa/Context7 queries)
- External LLM disable (only Claude workers in team mode)
- Auto-update disable
- Hard max iterations (200 cap vs 500 default)

### 12.2 Granular Security Controls

Each feature individually configurable in `.claude/omc.jsonc`:
```jsonc
{
  "security": {
    "restrictToolPaths": true,
    "pythonSandbox": true,
    "disableRemoteMcp": true,
    "disableExternalLLM": true,
    "disableAutoUpdate": true,
    "hardMaxIterations": 200
  }
}
```

Strict mode precedence: config can only TIGHTEN, never relax.

### 12.3 CLI Binary Validation

The `model-contract.ts` system validates CLI binary paths:
- Resolves via `which`/`where`
- Rejects untrusted paths (`/tmp`, `/var/tmp`, `/dev/shm`)
- Warns on non-standard paths
- Trusts: `/usr/local/bin`, `/usr/bin`, `/opt/homebrew/`, `~/.local/bin`, `~/.nvm/`, `~/.cargo/bin`
- Custom trust via `OMC_TRUSTED_CLI_DIRS`

### 12.4 Worker Environment Isolation

Worker processes get sanitized environments. The `getWorkerEnv()` function allowlists specific env vars for spawned workers. Sensitive variables (API keys, tokens) are controlled.

### 12.5 Known Limitations

| Limitation | Severity |
|------------|----------|
| No OS-level process sandbox | Medium |
| No security boundary between agents | Medium |
| Background agent monitoring gap | Low |

---

## 13. Competitive Analysis -- Implications for Trio

### 13.1 Strengths to Learn From

1. **Lifecycle hook architecture** -- OMC's non-invasive plugin model (hooks + MCP tools + prompt injection) is architecturally clean. It does not fork Claude Code; it layers on top.

2. **PRD-driven persistence** -- Ralph's structured story tracking with testable acceptance criteria is more rigorous than simple retry loops. The explicit "refine generic criteria into task-specific ones" instruction prevents superficial planning.

3. **Mathematical ambiguity gating** -- Deep Interview's weighted dimension scoring and threshold gating is a formal quality gate on requirements. This is a genuine innovation for AI-assisted specification.

4. **Tiered verification** -- Automatic scaling of verification effort based on change size, security implications, and architectural impact is cost-efficient and practical.

5. **Anti-slop system** -- Dedicated tooling to clean AI-generated code patterns is a real workflow need. The mandatory deslop pass in Ralph is well-integrated.

6. **Multi-model orchestration** -- Real tmux-based multi-provider orchestration (Claude + Codex + Gemini) with cross-validation is a genuine differentiator.

7. **Notification system** -- Telegram/Discord/Slack/webhook dispatchers with tag lists enable team awareness of AI agent activity.

8. **Commit decision tracing** -- Structured git trailers preserving constraints, rejected alternatives, confidence, and scope-risk are valuable for code review and future maintenance.

### 13.2 Weaknesses / Gaps

1. **No OS-level sandbox** -- Agents share filesystem and process space. The Python blocklist is defense-in-depth, not a security boundary.

2. **Complexity** -- 60+ files in the team module alone. 36+ skills. 19 agents. This is a large surface area to maintain and debug. The docs acknowledge "zero learning curve" but the system itself is very complex.

3. **tmux dependency** -- Core features (team, rate-limit detection, HUD) require tmux. Windows support requires psmux or WSL.

4. **File-based state** -- Team task coordination uses JSON files on disk, not a proper database or message queue. This limits concurrency patterns.

5. **Hook-injection model** -- Everything operates via `<system-reminder>` prompt injection, which consumes context window space. Heavy hook injection reduces available context for actual work.

6. **Single plugin point** -- All tools via a single MCP server (`t`). No modularity in tool provision.

7. **No web UI** -- CLI and tmux only. No dashboard for monitoring multi-agent activity across projects.

### 13.3 Features We Should Consider

| Feature | Priority | Rationale |
|---------|----------|-----------|
| PRD-driven persistence loop | High | Ralph's structured story tracking is more rigorous than simple retry |
| Tiered verification scaling | High | Cost-efficient verification that scales with change scope |
| Mathematical ambiguity gating | Medium | Formal quality gate on requirements before execution |
| Anti-slop pass | Medium | AI-specific code quality gate |
| Commit decision tracing | Medium | Preserves architectural intent in commit history |
| Multi-model cross-validation | Medium | Use Codex/Gemini as verification layer |
| Notification dispatchers | Low | Team awareness of agent activity |
| Task size detection | Low | Suppress heavy modes for trivial tasks |

### 13.4 Architectural Decisions to Note

- **Plugin, not fork**: OMC does not modify Claude Code internals. This is a deliberate architectural choice that makes it resilient to Claude Code updates.
- **Prompt files as agent definitions**: Each agent is a markdown file with structured XML-like sections (Role, Constraints, Investigation_Protocol, Tool_Usage, Execution_Policy, Output_Format, Failure_Modes_To_Avoid). This is a well-structured approach to agent persona definition.
- **Three-layer skill composition**: Execution + Enhancement + Guarantee layers enable combinatorial skill activation without explosion of mode variants.
- **File-based team coordination**: Tasks, inbox/outbox, heartbeats, and done signals are all JSON files. Simple, debuggable, but limits scalability.

---

## 14. Key Metrics

| Metric | Value |
|--------|-------|
| GitHub stars | 22,923 |
| Forks | 2,025 |
| Contributors | 10+ active |
| Releases (recent) | 5 in ~10 days (v4.9.1 through v4.10.1) |
| Open issues | 22 |
| Created | 2026-01-09 (~3 months old) |
| Merged PRs (v4.10.0 alone) | 35+ |
| npm package | oh-my-claude-sisyphus |
| Supported platforms | macOS, Linux, Windows (via psmux/WSL) |
| Languages in README | 11 translations |
| Discord | Active community |

---

## Appendix A: File Tree Summary

Total files in repository: ~1,500+
Key directories by file count:
- `src/team/` -- 60+ files (team orchestration, tmux, workers, state)
- `src/hooks/` -- 45+ subdirectories (lifecycle hook implementations)
- `src/features/` -- 20+ subdirectories (model routing, delegation, state management)
- `skills/` -- 36 skill directories (each with SKILL.md)
- `agents/` -- 19 agent prompt files
- `scripts/` -- 50+ hook scripts and utilities
- `benchmark/` -- Full benchmark suite with Docker support
- `src/tools/` -- MCP tool definitions (LSP, AST, memory, state, trace)

## Appendix B: Dependencies

**Runtime:**
- `@anthropic-ai/claude-agent-sdk` -- Claude Agent SDK integration
- `@modelcontextprotocol/sdk` -- MCP protocol implementation
- `@ast-grep/napi` -- AST-based code search and replace (native binding)
- `better-sqlite3` -- SQLite for job state database
- `commander` -- CLI framework
- `zod` -- Schema validation
- `ajv` -- JSON Schema validation
- `chalk` -- Terminal colors
- `jsonc-parser` -- JSONC file parsing
- `safe-regex` -- Regex safety validation
- `vscode-languageserver-protocol` -- LSP protocol types

**Build:**
- TypeScript, esbuild, vitest, eslint, prettier, tsx
