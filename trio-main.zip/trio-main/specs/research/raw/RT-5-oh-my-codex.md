# RT-5: oh-my-codex (OMX) -- Competitive Research

**Date:** 2026-04-03
**Repo:** https://github.com/Yeachan-Heo/oh-my-codex
**Version analyzed:** 0.11.12
**Stars:** 13,642 | **Forks:** 1,249
**Created:** 2026-02-02 | **Last updated:** 2026-04-03

---

## 1. Overview

**oh-my-codex (OMX)** is a workflow orchestration layer built on top of OpenAI Codex CLI. It does NOT replace Codex -- it wraps it, adding structured workflows, multi-agent coordination, persistent state, quality verification loops, and a real-time HUD. Think "oh-my-zsh for Codex" but with substantially more architectural ambition: multi-agent team execution, pipeline orchestration, and a full hook/plugin system.

**Primary language:** TypeScript (CLI and orchestration) + Rust (native runtime engine, explore harness, sparkshell, mux)
**Size:** ~7.4 MB on disk. Approximately 400+ source files across TypeScript and Rust crates.
**Dependencies:** Minimal -- `@iarna/toml`, `@modelcontextprotocol/sdk`, `zod`. No heavy framework.
**License:** MIT

**Tagline:** "Your codex is not alone. Add hooks, agent teams, HUDs, and so much more."

---

## 2. Architecture

### 2.1 High-Level Structure

```
oh-my-codex/
  src/                    # TypeScript source (bulk of the system)
    cli/                  # CLI entry points and command handlers
    agents/               # Agent role definitions and native config
    hooks/                # Hook system (keyword detection, extensibility, session)
      extensibility/      # Plugin system (loader, dispatcher, SDK, events)
      code-simplifier/    # Post-execution code cleanup hook
    team/                 # Multi-agent team orchestration
      state/              # Team state management (tasks, workers, mailbox, locks)
    pipeline/             # Pipeline orchestrator (sequential stage execution)
    ralph/                # Persistent completion loop subsystem
    ralplan/              # Planning + approval workflow runtime
    modes/                # Base mode lifecycle (all modes share this)
    hud/                  # Real-time terminal status display
    mcp/                  # MCP servers (state, memory, team, code-intel, trace)
    notifications/        # Multi-platform notification dispatch
    openclaw/             # External notification gateway integration
    verification/         # Evidence-based verification protocol
    visual/               # Visual verdict (screenshot comparison)
    autoresearch/         # Research supervisor mode
    session-history/      # Session search and replay
    state/                # Shared state management
    config/               # Model and MCP configuration
    utils/                # Shared utilities
    subagents/            # Subagent tracker
    planning/             # Planning artifact management
    scripts/              # Build/eval/hook scripts
  crates/                 # Rust native binaries
    omx-runtime-core/     # Core runtime engine (authority, dispatch, mailbox, replay)
    omx-runtime/          # Runtime CLI binary
    omx-explore/          # Read-only codebase exploration harness
    omx-mux/              # tmux multiplexer abstraction
    omx-sparkshell/       # Native shell execution sidecar
  prompts/                # 30+ agent role prompt files (markdown)
  skills/                 # 35+ skill definitions (SKILL.md files)
  templates/              # AGENTS.md template, catalog manifest
  missions/               # Eval/benchmark mission definitions
  playground/             # Demo configs (ML, sort, Bayesian optimization)
  docs/                   # Documentation, contracts, QA reports, release notes
```

### 2.2 Dual-Language Architecture

OMX uses a **TypeScript + Rust** split:
- **TypeScript**: All orchestration logic, CLI, hooks, MCP servers, state management, notifications. This is the primary codebase.
- **Rust** (4 crates): Performance-critical native components:
  - `omx-runtime-core`: Event-sourced runtime engine with authority leasing, dispatch queuing, mailbox messaging, and replay. Uses file-based persistence with exclusive file locks (`fs2`).
  - `omx-runtime`: Binary wrapper for the runtime core.
  - `omx-explore`: Native read-only codebase exploration harness with language-specific registries.
  - `omx-sparkshell`: Native shell execution sidecar with language-specific command registries (Python, Rust, Go, Node, Ruby, Swift, C/C++, C#, Java/Kotlin, Git, generic shell).
  - `omx-mux`: tmux abstraction layer.

### 2.3 MCP Server Architecture

OMX runs multiple MCP (Model Context Protocol) servers as sidecar processes:

| Server | Purpose |
|--------|---------|
| `omx-state` | Mode state read/write/clear/list for all workflow modes |
| `omx-memory` | Persistent project memory and session notepad |
| `omx-team` | Team worker coordination (deprecated in favor of CLI interop) |
| `omx-code-intel` | Code intelligence for agents |
| `omx-trace` | Execution tracing |

The state server supports 7 modes: `autopilot`, `team`, `ralph`, `ultrawork`, `ultraqa`, `ralplan`, `deep-interview`. State is stored as JSON in `.omx/state/{mode}-state.json` with session-scoped variants. Writes are serialized via per-path write queues and use atomic file operations (write to tmp + rename).

---

## 3. Complete Feature List

### 3.1 Core Workflow Skills (35+)

| Skill | Description |
|-------|-------------|
| `$deep-interview` | Socratic ambiguity-scoring interview before execution |
| `$ralplan` | Structured planning and approval workflow |
| `$ralph` | Persistent completion loop with architect verification |
| `$team` | Parallel worker coordination via tmux/worktrees |
| `$autopilot` | End-to-end pipeline: plan -> exec -> verify |
| `$ultrawork` | Parallel execution mode |
| `$ultraqa` | Quality assurance mode |
| `$swarm` | Swarm-style multi-agent execution |
| `$pipeline` | Configurable stage pipeline |
| `$worker` | Individual worker execution |
| `$plan` | Lightweight planning |
| `$analyze` | Analysis mode |
| `$review` | Code review |
| `$code-review` | Comprehensive code review |
| `$security-review` | Security-focused review |
| `$tdd` | Test-driven development workflow |
| `$build-fix` | Build failure resolution |
| `$frontend-ui-ux` | Frontend UI/UX workflow |
| `$git-master` | Git operation expertise |
| `$deepsearch` | Deep codebase search |
| `$note` | Session notepad |
| `$help` | In-session help |
| `$skill` | Skill browser |
| `$hud` | HUD status display |
| `$doctor` | Installation health check |
| `$omx-setup` | Setup wizard |
| `$cancel` | Cancel active modes |
| `$ecomode` | Resource-efficient mode |
| `$visual-verdict` | Screenshot comparison and scoring |
| `$web-clone` | URL-based website cloning |
| `$ai-slop-cleaner` | Post-execution AI slop removal |
| `$ask-claude` | Cross-provider query (Claude) |
| `$ask-gemini` | Cross-provider query (Gemini) |
| `$configure-notifications` | Notification setup |
| `$trace` | Execution tracing |
| `$ralph-init` | Ralph initialization |
| `$ralplan` | Plan approval workflow |

### 3.2 Agent Roles (28 defined)

Agents are categorized by lane and posture:

**Build Lane:** explore, analyst, planner, architect, debugger, executor, team-executor, verifier
**Review Lane:** style-reviewer, quality-reviewer, api-reviewer, security-reviewer, performance-reviewer, code-reviewer
**Domain Specialists:** dependency-expert, test-engineer, quality-strategist, build-fixer, designer, writer, qa-tester, git-master, code-simplifier, researcher
**Product Lane:** product-manager, ux-researcher, information-architect, product-analyst
**Coordination:** critic, vision

Each agent has metadata:
- `reasoningEffort`: low / medium / high
- `posture`: frontier-orchestrator / deep-worker / fast-lane
- `modelClass`: frontier / standard / fast
- `routingRole`: leader / specialist / executor
- `tools`: read-only / analysis / execution / data
- `category`: build / review / domain / product / coordination

### 3.3 CLI Commands

```
omx              # Launch Codex with OMX overlay
omx setup        # Install skills, prompts, MCP servers, AGENTS.md
omx uninstall    # Remove OMX config
omx doctor       # Health check (--team for team diagnostics)
omx cleanup      # Kill orphaned MCP processes
omx team         # Spawn parallel worker panes
omx ralph        # Launch persistent completion mode
omx autoresearch # Thin-supervisor research mode
omx explore      # Read-only codebase exploration
omx sparkshell   # Native shell sidecar
omx ask          # Cross-provider query
omx resume       # Resume previous session
omx session      # Search session history
omx agents-init  # Bootstrap AGENTS.md
omx agents       # Manage agent TOML files
omx hud          # Real-time status display
omx tmux-hook    # tmux prompt injection
omx hooks        # Hook plugin management
omx exec         # Non-interactive execution with overlay
omx status       # Show active modes
omx cancel       # Cancel active execution
omx reasoning    # Show/set model reasoning effort
omx version      # Version info
```

### 3.4 Notification System

Multi-platform notifications with:
- **Discord** (webhook + bot modes)
- **Telegram**
- **Slack**
- **Custom webhook**
- **OpenClaw gateway** (external notification gateway)

Features: cooldown management, idle detection, worker-aware dispatch, session-scoped registry, template engine, temporary notification contracts, verbosity profiles.

---

## 4. Unique Capabilities and Novel Design

### 4.1 Socratic Deep Interview with Ambiguity Scoring

The `$deep-interview` skill is genuinely novel. Rather than just asking "what do you want?", it:
- Applies quantitative ambiguity scoring (0.0 to 1.0) across multiple clarity dimensions
- Uses configurable depth profiles: Quick (threshold 0.30, max 5 rounds), Standard (0.20, 12 rounds), Deep (0.15, 20 rounds)
- Asks ONE question per round, targeting the weakest clarity dimension
- Pressure-tests every answer before moving on
- Blocks auto-approval inputs while active (input lock mechanism)
- Refuses to hand off to execution while ambiguity exceeds threshold
- Specifically gates on Non-goals and Decision Boundaries being resolved
- Writes structured output to `.omx/context/{slug}-{timestamp}.md` and `.omx/interviews/`

**Takeaway for Trio:** The ambiguity scoring with hard gates before execution is a strong pattern. Our deep-interview equivalent should adopt quantitative scoring.

### 4.2 Ralph: Persistent Completion Loop with Verification

Ralph is a sophisticated "keep going until actually done" loop:
- Pre-context intake (creates `.omx/context/` snapshots)
- Parallel agent delegation with tiered verification
- Visual task gating via screenshot comparison (score 0-100, threshold 90)
- Mandatory deslop pass (AI slop cleaner on all changed files)
- Post-deslop regression verification
- Architect verification at tiered levels (STANDARD to THOROUGH)
- PRD mode for structured product requirements
- State persistence via MCP across iterations
- Fix-verify loop with configurable max retries

**Takeaway for Trio:** The mandatory deslop pass and visual verdict integration within the completion loop are unique. We should consider post-execution quality gates.

### 4.3 Event-Sourced Rust Runtime Engine

The `omx-runtime-core` Rust crate implements a genuine event-sourced runtime:
- **Authority leasing:** Exclusive ownership with lease expiration and stale detection
- **Dispatch log:** Queue -> Notify -> Deliver/Fail lifecycle with metadata
- **Mailbox:** Worker-to-worker messaging with delivery tracking
- **Replay:** Event log replay for state reconstruction
- **Persistence:** File-based with exclusive locks (`fs2`)
- **Compaction:** Removes terminal dispatch events from the log
- **Compatibility view:** Writes individual section JSON files for TypeScript readers

**Takeaway for Trio:** Event sourcing for the runtime is architecturally sound. The authority leasing pattern prevents split-brain in multi-worker scenarios.

### 4.4 Pipeline Orchestrator

The autopilot pipeline sequences configurable stages:
- RALPLAN (planning + approval) -> Team Exec (parallel workers) -> Ralph Verify (completion verification)
- Each stage receives accumulated artifacts from previous stages
- State persistence after each transition
- Resume support from last persisted state
- Stage skip conditions
- Failure handling with stage identification

### 4.5 Sparkshell: Native Shell Sidecar

A Rust-based shell execution sidecar with:
- Language-specific command registries (Python, Rust, Go, Node, Ruby, Swift, C/C++, C#, Java/Kotlin)
- Codex bridge for AI-assisted shell operations
- Safety thresholds for command execution
- tmux pane tail/summarization

---

## 5. Control Flow: Agent Orchestration

### 5.1 Canonical Workflow

```
User -> $deep-interview -> Clarity artifact
     -> $ralplan         -> Approved plan with tradeoffs
     -> $ralph OR $team  -> Execution + verification
     -> Completion
```

### 5.2 Team Orchestration (Multi-Agent)

The team system is the most complex subsystem:

**Phases:** `team-plan` -> `team-prd` -> `team-exec` -> `team-verify` -> `team-fix` (loop)

**Phase-Agent Mapping:**
| Phase | Agents |
|-------|--------|
| team-plan | analyst, planner |
| team-prd | product-manager, analyst |
| team-exec | executor, designer, test-engineer |
| team-verify | verifier, quality-reviewer, security-reviewer |
| team-fix | executor, build-fixer, debugger |

**Infrastructure:**
- tmux sessions for durable worker panes (macOS/Linux) or psmux (Windows)
- Git worktrees for filesystem isolation between workers
- Inbox/task state per worker
- Mailbox for inter-worker messaging
- Dispatch queue with delivery tracking
- Heartbeat monitoring
- Idle nudge system
- Rebalance policy for worker reallocation
- Phase controller for automatic phase transitions
- Followup planner for post-execution work
- Scaling support for dynamic worker count
- Leader activity tracking
- Shutdown fallback with graceful cleanup

**Worker Bootstrap:**
1. Create tmux session with worker panes
2. Generate worker overlay (AGENTS.md + role instructions)
3. Write worker identity and inbox
4. Create tasks and assign to workers
5. Monitor heartbeats and progress
6. Deliver mailbox messages for coordination
7. Phase transitions based on task completion

### 5.3 Mode Lifecycle

All modes share a base lifecycle (`src/modes/base.ts`):
- `startMode()`: Creates state, checks exclusive mode conflicts
- `readModeState()`: Reads current state with session scope preference
- `updateModeState()`: Merges updates into existing state
- `cancelMode()`: Sets active=false, phase=cancelled
- `advanceIteration()`: Increments iteration counter
- Exclusive modes: autopilot, autoresearch, ralph, ultrawork (only one active at a time)

---

## 6. Quality Assurance: Verification of Agent Output

### 6.1 Evidence-Based Verification Protocol

The verifier (`src/verification/verifier.ts`) implements tiered verification:

**Small tasks** (<3 files, <100 lines): Type check + related tests + basic confirmation
**Standard tasks** (<15 files, <500 lines): Full type check + test suite + linter + e2e + regression
**Large tasks** (>15 files, >500 lines): Full type check + complete test suite + linter + security review (OWASP top 10) + performance assessment + API compatibility + e2e + regression

The verifier generates structured evidence:
```typescript
interface VerificationEvidence {
  type: 'test' | 'typecheck' | 'lint' | 'build' | 'manual' | 'runtime';
  passed: boolean;
  command?: string;
  output?: string;
}
```

A heuristic function `hasStructuredVerificationEvidence()` checks if a completion summary actually contains real verification evidence (not just claims).

### 6.2 Fix-Verify Loop

When verification fails:
1. Identify root cause
2. Apply minimal fix
3. Re-run verification
4. Repeat up to N times (configurable, default 3)
5. Escalate with what was attempted, what failed, and recommendations

### 6.3 Visual Verdict

For UI/screenshot tasks, OMX includes a visual scoring system:
- Score: 0-100 integer
- Verdict: structured status enum
- Category match: boolean
- Differences: string array
- Suggestions: string array
- Reasoning: non-empty string
- Default pass threshold: 90
- Results persisted to ralph-progress.json

### 6.4 AI Slop Cleaner

Post-execution pass that removes AI-generated code smell patterns from all changed files. Runs after architect verification passes, followed by mandatory regression re-verification.

---

## 7. Hook/Plugin System

### 7.1 Architecture

The extensibility system (`src/hooks/extensibility/`) is well-designed:

**Plugin Discovery:** Scans `.omx/hooks/` for `.mjs` files. Plugins are ON by default.

**Event System:** Hook events have an envelope structure:
```typescript
interface HookEventEnvelope {
  schema_version: '1';
  event: HookEventName;  // session-start, session-end, turn-complete, blocked, etc.
  timestamp: string;
  source: 'native' | 'derived';
  context: Record<string, unknown>;
  session_id?: string;
  thread_id?: string;
  turn_id?: string;
  mode?: string;
  confidence?: number;
}
```

**Event Types:** session-start, session-end, session-idle, turn-complete, blocked, finished, failed, retry-needed, pr-created, test-started, test-finished, test-failed, handoff-needed, needs-input, pre-tool-use, post-tool-use (plus extensible string union).

**Plugin SDK:** Each plugin receives a rich SDK:
```typescript
interface HookPluginSdk {
  tmux: { sendKeys(options) };           // tmux pane interaction
  log: { info, warn, error };            // Structured logging
  state: { read, write, delete, all };   // Per-plugin persistent state
  omx: {                                 // OMX runtime state access
    session: { read() };
    hud: { read() };
    notifyFallback: { read() };
    updateCheck: { read() };
  };
}
```

**Dispatch:** Plugins run in forked processes with configurable timeout (default 1500ms, min 100ms, max 60s). Results include per-plugin status, duration, exit code.

### 7.2 Built-in Hooks

- Keyword detector (magic keyword -> skill routing)
- Task size detector (file/line count -> verification tier)
- Session management (start/end tracking, metrics)
- Agents overlay (dynamic AGENTS.md generation)
- Codebase map generation
- Explore routing (adaptive backend selection)
- Prompt guidance (catalog-driven prompt injection)
- Code simplifier (post-edit cleanup)
- Notify hooks (tmux scrollback, worker idle, team dispatch, visual verdict, etc.)
- Consensus execution handoff

### 7.3 Keyword Detection Engine

Detects "magic keywords" in user prompts (e.g., `$deep-interview`, `$ralph`, `$team`) and injects corresponding skill prompts. Includes:
- Priority-based matching
- Skill active state tracking
- Deep interview input lock (blocks auto-approval while interview is active)
- Planning artifact awareness
- Task size classification

---

## 8. Configuration System

### 8.1 Configuration Hierarchy

```
~/.codex/.omx-config.json     # User-level configuration
  env: { OMX_DEFAULT_*_MODEL }  # Environment variable overrides
  models: { mode: model-name }  # Per-mode model overrides

.omx/                          # Project-level state directory
  state/                       # Mode state files
  plans/                       # PRD and planning artifacts
  context/                     # Context snapshots
  interviews/                  # Interview transcripts
  hooks/                       # Plugin directory
  project-memory.json          # Persistent project memory
  notepad.md                   # Session notepad

AGENTS.md                      # Project-level agent guidance (generated)
config.toml                    # Codex config (managed by OMX)
```

### 8.2 Setup System

`omx setup` installs:
- Skills to Codex home directory
- Prompt files for all agent roles
- MCP server configurations
- AGENTS.md scaffolding
- Scopes: user-level or project-level

Setup supports: `--force` (overwrite), `--dry-run`, `--scope user|project`, `--skill-target codex-home`.

### 8.3 CLI Flags

```
--madmax          # Bypass Codex approvals and sandbox (dangerous)
--high / --xhigh  # Set reasoning effort level
--spark           # Use fast model for team workers
--madmax-spark    # Combine spark + madmax
--worktree        # Launch in git worktree
--notify-temp     # Temporary notification routing
--discord/--slack/--telegram/--custom  # Notification provider selection
```

---

## 9. Multi-Model Support

### 9.1 Model Configuration

OMX supports per-mode model selection with a clear resolution chain:

```
Mode-specific override (models.team: "gpt-4.1")
  -> "default" key (models.default: "o4-mini")
    -> OMX_DEFAULT_FRONTIER_MODEL env var
      -> Hardcoded default (gpt-5.4)
```

**Default models (as of v0.11.12):**
- Frontier: `gpt-5.4`
- Standard: `gpt-5.4-mini`
- Spark (fast): `gpt-5.3-codex-spark`

**Environment variables:**
- `OMX_DEFAULT_FRONTIER_MODEL`
- `OMX_DEFAULT_STANDARD_MODEL`
- `OMX_DEFAULT_SPARK_MODEL` / `OMX_SPARK_MODEL`

**Per-agent model routing:** Each agent definition has a `modelClass` (frontier/standard/fast) that maps to the configured model for that class. The team system has a separate low-complexity model for workers.

### 9.2 Cross-Provider Queries

The `$ask-claude` and `$ask-gemini` skills allow querying non-OpenAI providers from within an OMX session, enabling cross-verification of AI output.

### 9.3 Limitation

OMX is fundamentally an OpenAI Codex CLI wrapper. It does NOT directly support other AI backends as the primary execution engine. The model configuration is for OpenAI models only. Cross-provider queries are a secondary verification mechanism, not a primary execution path.

---

## 10. Session Management

### 10.1 Session State

- Sessions tracked in `.omx/state/` with timestamps and session IDs
- Session metrics: turn count, token usage (input/output/total), quota tracking (5h and weekly)
- Session search across history artifacts (`omx session`)
- Resume support (`omx resume`) for interrupted sessions

### 10.2 Mode State Persistence

Each mode stores JSON state with:
```typescript
interface ModeState {
  active: boolean;
  mode: string;
  iteration: number;
  max_iterations: number;
  current_phase: string;
  task_description?: string;
  started_at: string;
  completed_at?: string;
  last_turn_at?: string;
  error?: string;
}
```

State is scoped: global scope or session-scoped (using session ID). Reads check session-scoped first, then fall back to global.

### 10.3 Team State Persistence

Team state is more complex:
- Config, worker identities, heartbeats, status
- Task state with claims, releases, expirations
- Mailbox with delivery/notification tracking
- Dispatch requests with lifecycle (queue -> notify -> deliver/fail)
- Phase state and transitions
- Monitor snapshots
- Event log
- Shutdown requests/acknowledgments
- Approval state

### 10.4 Ralph Persistence

Ralph maintains:
- Canonical PRD files (`.omx/plans/prd-{slug}.md`)
- Progress ledger (`.omx/state/{scope}/ralph-progress.json`) with schema version, entries, visual feedback
- Legacy migration from `.omx/prd.json` and `.omx/progress.txt` (one-way, non-destructive)
- Visual feedback history (last 30 entries)
- Migration markers

---

## 11. UI/UX

### 11.1 CLI Interface

Primary interaction via `omx` CLI. Supports both interactive (launch Codex with overlay) and non-interactive (`omx exec`) modes.

### 11.2 HUD (Heads-Up Display)

Real-time tmux statusline with three presets:

**Minimal:** git branch, active modes, turn count
**Focused (default):** + tokens, quota, session duration, last activity
**Full:** + total turns

Elements rendered:
- Git branch (cyan)
- Ralph iteration counter (color-coded by progress)
- Ultrawork, autopilot, ralplan, deep-interview, autoresearch, ultraqa status
- Team worker count
- Token usage (formatted: k/M)
- Quota percentages (5h and weekly)
- Session duration
- Last activity timestamp

Output: ANSI-colored statusline with `[OMX#version]` prefix and pipe-separated elements. Auto-attaches when inside tmux.

### 11.3 Monitoring

- `omx hud --watch` for continuous monitoring
- `omx hud --json` for machine-readable output
- `omx hud --preset=NAME` for preset selection
- `omx doctor --team` for team health diagnostics
- `omx team status <name>` for team status
- tmux pane-based worker monitoring

---

## 12. Security Model

### 12.1 Sandboxing

OMX inherits Codex CLI's sandboxing. The `--madmax` flag explicitly bypasses it (documented as DANGEROUS).

### 12.2 Filesystem Isolation

- Git worktrees for team worker isolation
- Each worker gets its own filesystem checkout
- Leader workspace cleanliness assertion before provisioning worktrees
- Worktree rollback on provisioning failure

### 12.3 State Security

- Atomic file writes (tmp + rename) prevent corruption
- Exclusive file locks on Rust runtime engine state
- Per-path write queues for MCP state server
- Session ID validation on state access
- Path traversal tests in test suite (`src/mcp/__tests__/path-traversal.test.ts`)

### 12.4 Notification Security

- Discord webhook URL validation (allowed hosts only)
- Telegram bot token format validation
- Slack webhook URL validation (hooks.slack.com only)
- Generic webhooks require HTTPS
- Send timeouts (10s) and dispatch timeouts (15s)

### 12.5 Plugin Security

- Plugins run in forked processes (isolation from main process)
- Configurable timeout (default 1500ms, max 60s)
- Side effects can be disabled per dispatch
- Team worker plugins can be independently gated
- Plugin file validation (must export `onHookEvent`)

### 12.6 Limitations

- No container-level sandboxing
- No capability-based permission model for agents
- `--madmax` mode has no guardrails
- Worker isolation is filesystem-level only (shared network, processes)

---

## 13. Competitive Assessment for Trio

### 13.1 Strengths (What OMX Does Well)

1. **Workflow sophistication:** The deep-interview -> ralplan -> ralph/team pipeline is the most structured AI coding workflow in the ecosystem. The ambiguity scoring with hard gates is particularly strong.

2. **Persistent completion loops:** Ralph's "keep going until actually done" with mandatory verification is a real differentiator vs. single-shot AI coding tools.

3. **Multi-agent team execution:** tmux-based durable workers with git worktree isolation is practical and works today. The phase-based orchestration (plan -> prd -> exec -> verify -> fix) provides real structure.

4. **Plugin extensibility:** The hook system with process-isolated plugins, rich SDK, and typed events is well-designed and production-grade.

5. **Quality gates:** Tiered verification, visual verdict scoring, mandatory deslop pass, and regression re-verification create meaningful quality assurance.

6. **State management:** Session-scoped state with MCP server access, atomic writes, and mode exclusivity prevents common orchestration bugs.

7. **Rust performance layer:** Using Rust for the runtime engine, explore harness, and sparkshell is a smart architecture decision for performance-critical paths.

### 13.2 Weaknesses (Opportunities for Trio)

1. **OpenAI lock-in:** OMX is exclusively an OpenAI Codex CLI wrapper. It cannot use Claude, Gemini, or local models as the primary engine. Cross-provider support is limited to verification queries.

2. **tmux dependency:** The team system requires tmux (or psmux on Windows). This is a significant deployment constraint and fragile in CI/headless environments.

3. **Complexity budget:** 400+ source files, 35+ skills, 28 agents, 7 modes. The surface area is enormous. Configuration and mental model overhead is high.

4. **No container sandboxing:** Security isolation is filesystem-level only. No Docker/container-based sandboxing for agents.

5. **Prompt-based orchestration:** Despite the TypeScript infrastructure, the actual agent behavior is driven by prompt templates (SKILL.md files). The orchestration is more "prompt injection" than programmatic control flow.

6. **Limited testing intelligence:** Verification is heuristic (regex-based evidence detection). There's no deep understanding of what tests cover or whether they're meaningful.

7. **No incremental learning:** No mechanism for the system to get better over time based on past failures or successes.

### 13.3 Key Ideas to Adopt or Improve On

| OMX Feature | Trio Opportunity |
|-------------|-----------------|
| Ambiguity scoring in deep-interview | Adopt quantitative clarity gating. Add configurable thresholds. |
| Ralph persistent loop | Our completion loops should include mandatory verification + deslop. |
| Visual verdict scoring | Screenshot comparison for frontend tasks is valuable. Consider integration. |
| Event-sourced runtime | Our runtime should be event-sourced for replay/debug. |
| Authority leasing | Adopt for multi-agent coordination to prevent split-brain. |
| Hook plugin SDK | Our plugin system should offer tmux, logging, state, and runtime state APIs. |
| Per-agent model routing | Agent -> model class -> configured model chain is clean. Adopt. |
| Phase-based team orchestration | plan -> prd -> exec -> verify -> fix is a solid default pipeline. |
| Fix-verify loop with escalation | Bounded retry with structured escalation is better than unbounded or single-shot. |
| Session-scoped state | State isolation per session prevents cross-contamination. |

### 13.4 Key Ideas to Avoid

| OMX Pattern | Why Avoid |
|-------------|-----------|
| Single-provider lock-in | Trio should remain provider-agnostic. |
| tmux as infrastructure | Prefer process-based isolation that works in all environments. |
| Prompt-template orchestration | Prefer programmatic control flow with prompt templates as data, not logic. |
| 35+ skills as separate files | Prefer composable primitives over a large skill catalog. |
| `.omx/` as the only state store | Support both local and remote state for team scenarios. |

---

## 14. Summary

oh-my-codex is the most feature-complete workflow layer for AI coding agents in the current ecosystem. Its key innovations -- ambiguity-scored interviews, persistent completion loops with verification gates, event-sourced runtime, and tmux-based multi-agent teams -- represent the state of the art for orchestrating Codex CLI.

Its primary limitations are OpenAI lock-in, tmux dependency, and the inherent fragility of prompt-template-driven orchestration. For Trio, OMX validates that structured workflows (interview -> plan -> execute -> verify) with mandatory quality gates significantly improve AI coding outcomes. The specific implementation patterns around quantitative ambiguity scoring, authority leasing, and tiered verification are directly adoptable.
