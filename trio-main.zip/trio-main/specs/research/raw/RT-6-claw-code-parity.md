# RT-6: Claw Code Parity -- Competitive Research Report

**Date:** 2026-04-03
**Repository:** https://github.com/Yeachan-Heo/claw-code-parity
**Primary Author:** Sigrid Jin (instructkr) + Yeachan Heo (bellman_ych)
**Stars:** 7 (parity repo) / 50K+ (parent instructkr/claw-code, reached 50K in 2 hours)
**Last Updated:** 2026-04-03
**License:** None specified (MIT in Cargo.toml workspace)

---

## 1. What Is It?

Claw Code Parity is a **clean-room Rust reimplementation** of Claude Code's agent harness. It originated as a Python port of the Claude Code agent system after the source was leaked on March 31, 2026, and has since been actively rewritten in Rust for performance and memory safety.

**Key facts:**
- **Language:** Rust (primary, ~20K lines across 6 crates), Python (legacy scaffolding)
- **Disk size:** 5.7 MB
- **Binary name:** `claw`
- **Default model:** `claude-opus-4-6`
- **Architecture:** Workspace monorepo with 6 Rust crates
- **Status:** Active development; Rust port is the primary effort. Created 2026-04-02.

**Origin story:** The creators studied Claude Code's exposed harness architecture and rebuilt the core patterns from scratch in Python, then Rust. The Python rewrite was orchestrated using oh-my-codex (OmX) with `$team` mode for parallel code review and `$ralph` mode for persistent execution loops.

The parent repo (instructkr/claw-code) claims to be the fastest repo in history to surpass 50K stars (2 hours). This parity repo is a focused work-in-progress fork for the Rust port.

---

## 2. Architecture

### Crate Structure

```
rust/
  crates/
    api/              -- Anthropic API client, SSE streaming, multi-provider support
    commands/         -- Slash command registry, help generation, plugin/skill/agent subcommands
    compat-harness/   -- TS manifest extraction (reads upstream source for parity tracking)
    plugins/          -- Plugin lifecycle: discover, install, validate, enable/disable, hooks
    runtime/          -- ConversationRuntime, config hierarchy, sessions, permissions, MCP, sandbox
    rusty-claude-cli/ -- Main binary: REPL, one-shot mode, streaming display, tool rendering
    telemetry/        -- Session tracing, analytics events, JSONL sink, request profiling
    tools/            -- 19+ built-in tool implementations with GlobalToolRegistry
```

### Crate Dependency Graph

```
rusty-claude-cli (binary)
  -> api (HTTP, SSE, providers)
  -> commands (slash commands)
  -> plugins (plugin manager)
  -> runtime (core engine)
  -> tools (tool implementations)
  -> compat-harness (parity tracking)

tools -> api, runtime, plugins
commands -> runtime, plugins
plugins -> runtime (hooks)
api -> runtime (pricing), telemetry
```

### Key Architectural Patterns

1. **Trait-based extensibility:** Core abstractions are traits -- `ApiClient`, `ToolExecutor`, `PermissionPrompter`, `HookProgressReporter`, `TelemetrySink`, `Provider`. This makes the system testable and swappable.

2. **Hierarchical config merging:** User-level, project-level, and local-level configs are merged with well-defined precedence (User < Project < Local). Config files live at `~/.claw/settings.json`, `.claw/settings.json`, and `.claw/settings.local.json`.

3. **Session-based state:** All conversation state is persisted to `.claude/sessions/` as JSON/JSONL files with versioning, compaction records, and fork metadata.

4. **Agentic loop in runtime crate:** The `ConversationRuntime` struct owns the loop: send request -> receive events -> extract tool calls -> check permissions -> run hooks -> execute tools -> append results -> repeat until no more tool calls or max iterations.

---

## 3. Complete Feature List

### Implemented (Rust)

| Category | Features |
|----------|----------|
| **API** | Anthropic Messages API, SSE streaming, OAuth login/logout, API key auth, bearer token auth, dual auth (key + bearer), configurable base URL, prompt caching with break detection |
| **Multi-provider** | Anthropic (Claude), xAI (Grok), OpenAI -- automatic provider detection from model name or env vars |
| **Model aliases** | `opus` -> `claude-opus-4-6`, `sonnet` -> `claude-sonnet-4-6`, `haiku` -> `claude-haiku-4-5-20251213`, `grok` -> `grok-3`, `grok-mini` -> `grok-3-mini` |
| **Tools** | bash, read_file, write_file, edit_file, glob_search, grep_search, WebFetch, WebSearch, TodoWrite, Skill, Agent (sub-agent), ToolSearch (deferred tool loading), NotebookEdit, Sleep, SendUserMessage, Config, StructuredOutput, REPL, PowerShell |
| **REPL** | Interactive line editor (rustyline), slash-command tab completion, Shift+Enter for newlines, history |
| **Slash commands** | /help, /status, /sandbox, /compact, /model, /permissions, /cost, /config, /memory, /diff, /export, /session, /version, /clear, /agents, /skills, /plugins |
| **Hooks** | PreToolUse, PostToolUse, PostToolUseFailure -- full execution pipeline with stdin payload, JSON output parsing, permission override, input rewriting, abort signals, progress reporting |
| **Plugins** | Plugin discovery (builtin/bundled/external), manifest loading, enable/disable, validation, hook aggregation from plugins, plugin-provided tools |
| **Permissions** | 5 modes: ReadOnly, WorkspaceWrite, DangerFullAccess, Prompt, Allow. Rule-based allow/deny/ask with tool name + input pattern matching. Hook-driven overrides. Interactive prompting. |
| **Session mgmt** | Create, persist (JSONL with rotation at 256KB, max 3 rotated files), resume, list, switch, fork with parent tracking, compaction records |
| **Compaction** | Auto-compaction at configurable token threshold (default 100K input tokens), preserves recent messages, merges prior compacted summaries, extracts key files, pending work, timeline |
| **Sandbox** | Linux namespace isolation via `unshare` (user, mount, IPC, PID, UTS, optional net), filesystem isolation modes (off/workspace-only/allow-list), container detection (Docker, Podman, Kubernetes), configurable allowed mounts |
| **Config** | 3-tier hierarchy (User/Project/Local), `.claw/settings.json` format, merged at load time, supports hooks, plugins, MCP, OAuth, model, permission mode, permission rules, sandbox config |
| **CLAUDE.md** | Full instruction file discovery up the directory tree: `CLAUDE.md`, `CLAUDE.local.md`, `.claw/CLAUDE.md`, `.claw/instructions.md`. Content deduplication, truncation budget (4K per file, 12K total) |
| **System prompt** | Builder pattern with sections: intro, output style, system rules, doing tasks, actions/care, environment context, project context (git status/diff), instruction files, runtime config |
| **MCP** | Server config for Stdio, SSE, HTTP, WebSocket, SDK, and ManagedProxy transports. Tool name normalization, server signature hashing, CCR proxy URL unwrapping, OAuth config for remote servers |
| **Cost tracking** | Per-model pricing (Haiku/Sonnet/Opus), per-turn and cumulative token tracking, cost breakdown (input/output/cache_write/cache_read), USD formatting |
| **Prompt caching** | Local completion cache with TTL, cache break detection (unexpected vs expected), request fingerprinting (FNV hash), stats persistence, session-scoped cache directories |
| **Telemetry** | Session tracing with sequence numbers, HTTP request profiling (started/succeeded/failed), analytics events, JSONL file sink, memory sink for testing |
| **Git integration** | Git status snapshot, git diff snapshot (staged + unstaged), branch detection in system prompt |
| **CLI modes** | Interactive REPL, one-shot prompt (text or JSON output), login, logout, init, doctor, self-update, resume session, manifest dump, system prompt dump |
| **Markdown rendering** | Terminal rendering with ANSI: headings, bold/italic, code blocks with syntect highlighting, tables, blockquotes, lists, links |
| **Extended thinking** | Thinking block support in API types (Thinking, RedactedThinking content blocks), ThinkingDelta and SignatureDelta in streaming |

### Planned / Missing (per PARITY.md gap analysis)

| Gap | Status |
|-----|--------|
| Full hook execution integration in agentic loop | Hooks exist as standalone runner; not yet wired into conversation loop |
| Plan mode (EnterPlanMode/ExitPlanMode tools) | Missing |
| Worktree tools (EnterWorktree/ExitWorktree) | Missing |
| Task management tools (Create/Get/List/Output) | Missing |
| Remote trigger / schedule cron tools | Missing |
| AskUserQuestion tool | Missing |
| MCP resource listing/reading tools | Missing |
| LSP management service | Missing |
| Analytics service layer | Missing |
| Team memory sync | Missing |
| Remote structured IO / SSE / WebSocket / CCR transport layers | Missing |
| Full-screen TUI mode | Planned (detailed TUI-ENHANCEMENT-PLAN.md) |
| Skills registry / bundled skills | Partial (loads SKILL.md files, no bundled registry) |

---

## 4. Unique Capabilities / Novel Design

### 4a. Prompt Cache Break Detection

The `prompt_cache.rs` module implements a sophisticated cache monitoring system that tracks request fingerprints (model, system prompt, tools, messages) using FNV-1a hashing, detects when prompt cache read tokens drop significantly between requests, and classifies breaks as "expected" (prompt changed, model changed, TTL expired) vs "unexpected" (fingerprint stable but tokens dropped). This gives the user visibility into cache utilization anomalies. This is a direct port of Claude Code's internal cache monitoring.

### 4b. Hierarchical Hook System with Input Rewriting

The hook system goes beyond simple pre/post interceptors. Hook scripts receive structured JSON payloads via stdin and environment variables, and can return JSON responses that:
- Block tool execution (exit code 2 or `"decision": "block"`)
- Override permission decisions (allow/deny/ask)
- Provide a reason for the decision
- **Rewrite the tool input** via `hookSpecificOutput.updatedInput`
- Send system messages to the conversation

This enables powerful policy enforcement patterns -- e.g., a hook that rewrites dangerous bash commands, or one that adds safety constraints to file operations.

### 4c. Plugin-Provided Tools

The plugin system (in `plugins/` crate) discovers plugins from multiple sources (builtin, bundled directories, external marketplace), loads their manifests (`.claude-plugin/plugin.json`), aggregates their hooks into the runtime hook config, and exposes plugin-defined tools to the model via `GlobalToolRegistry`. Plugins can ship their own tool definitions with custom input schemas.

### 4d. Multi-Layer Sandbox Isolation

The sandbox system offers three levels of filesystem isolation:
- **Off** -- no restrictions
- **WorkspaceOnly** -- restrict to current workspace
- **AllowList** -- only explicitly permitted mount paths

Combined with Linux namespace isolation (user, mount, IPC, PID, UTS, optional network), container environment detection, and graceful fallback when namespaces are unavailable (e.g., inside Docker).

### 4e. Session Compaction with Context Preservation

The compaction system doesn't just summarize -- it:
- Extracts key file references from tool calls
- Infers pending work from recent messages
- Collects recent user requests
- Builds a structured timeline
- When re-compacting, preserves the *previous* compacted context alongside the *new* context, creating a layered summary history

### 4f. Rust Performance Characteristics

As a native Rust binary:
- Zero garbage collection pauses during streaming
- Memory-safe without runtime overhead
- `unsafe_code = "forbid"` workspace-wide
- Clippy pedantic linting enforced
- ~20K lines across 6 crates with clear boundaries

---

## 5. Control Flow -- Agent Orchestration

### The Agentic Loop (`ConversationRuntime::run_turn`)

```
User message arrives
  |
  v
Build API request (system prompt + messages + tools)
  |
  v
Stream response from API (AssistantEvent stream)
  |
  v
Collect text deltas and tool_use blocks
  |
  v
For each tool_use block:
  |
  +-> Run PreToolUse hooks (HookRunner)
  |     |
  |     +-> If denied: return denial as tool_result
  |     +-> If input rewritten: use updated input
  |     +-> Extract permission override (allow/deny/ask)
  |
  +-> Check permissions (PermissionPolicy.authorize_with_context)
  |     |
  |     +-> Evaluate deny rules first (short-circuit)
  |     +-> Evaluate hook permission override
  |     +-> Evaluate ask rules (force prompt even if mode allows)
  |     +-> Evaluate allow rules
  |     +-> Compare active mode vs required mode
  |     +-> If escalation needed: prompt user via PermissionPrompter trait
  |
  +-> Execute tool (ToolExecutor.execute)
  |
  +-> Run PostToolUse hooks (or PostToolUseFailure on error)
  |
  +-> Append tool_result to conversation
  |
  v
Check auto-compaction threshold
  |
  +-> If over threshold: compact session, emit AutoCompactionEvent
  |
  v
If assistant response contains tool_use and iterations < max:
  -> Loop back to "Build API request"
Else:
  -> Return TurnSummary
```

### Sub-Agent Orchestration

The `Agent` tool creates a nested execution context. The parent passes a prompt to the sub-agent, which runs its own tool loop with its own scope. Results are returned as the tool_result to the parent conversation.

### One-Shot vs Interactive

- **One-shot** (`claw prompt "..."`) -- runs a single turn with tools enabled, returns text or JSON output
- **Interactive** (`claw` with no args) -- REPL loop, persistent session, slash commands, session resume

---

## 6. Quality Assurance

### Verification Mechanisms

1. **Permission system as guardrail:** Every tool call passes through `PermissionPolicy.authorize_with_context` which enforces mode-based access control (ReadOnly < WorkspaceWrite < DangerFullAccess) plus configurable allow/deny/ask rules.

2. **Hook-based validation:** PreToolUse hooks can inspect and block/rewrite tool inputs before execution. PostToolUse hooks can validate outputs. Scripts receive full context (tool name, input, output, error status) and return structured decisions.

3. **Sandbox isolation:** Bash commands can be wrapped in `unshare` for namespace/filesystem/network isolation. Container detection prevents double-nesting issues.

4. **Auto-compaction prevents context overflow:** When input tokens exceed the threshold, the system automatically compacts older messages while preserving recent context, preventing context window exhaustion.

5. **Prompt cache monitoring:** Detects unexpected cache breaks that could indicate prompt corruption or API-side issues.

### Test Coverage

The codebase has extensive unit tests across all crates:
- **Runtime crate:** Tests for config loading/merging, permission policy (9 tests covering all escalation paths), hook execution (6 tests including abort/cancel), session persistence, compaction (5 tests including re-compaction), prompt building (10+ tests), sandbox detection, MCP naming/hashing, OAuth, usage tracking
- **API crate:** Provider detection, model alias resolution, SSE parsing, prompt cache (5 tests including expiration, collision, round-trip), request profiling
- **Tools crate:** Tool spec validation, registry construction
- **Plugins crate:** Plugin discovery, manifest loading, hook aggregation, enable/disable state
- **Commands crate:** Slash command parsing, help rendering, plugin/agent/skill subcommands, session compaction via commands
- **Telemetry crate:** Event recording, JSONL persistence, session tracing

### CI/Verification Commands

```bash
cargo fmt                                          # Formatting
cargo clippy --workspace --all-targets -- -D warnings  # Linting (pedantic)
cargo test --workspace                             # All tests
```

---

## 7. Hook / Plugin System -- Extensibility Points

### Hooks

**Three hook events:**
1. `PreToolUse` -- runs before tool execution, can block/rewrite/override permissions
2. `PostToolUse` -- runs after successful tool execution
3. `PostToolUseFailure` -- runs after failed tool execution

**Hook configuration** (in settings.json):
```json
{
  "hooks": {
    "PreToolUse": ["./hooks/pre.sh"],
    "PostToolUse": ["./hooks/post.sh"],
    "PostToolUseFailure": ["./hooks/failure.sh"]
  }
}
```

**Hook execution protocol:**
- Hooks are shell commands executed via `sh -lc` (Unix) or `cmd /C` (Windows)
- Receive JSON payload via stdin with: hook_event_name, tool_name, tool_input, tool_input_json, tool_output (post only), tool_result_is_error
- Environment variables also set: HOOK_EVENT, HOOK_TOOL_NAME, HOOK_TOOL_INPUT, HOOK_TOOL_IS_ERROR, HOOK_TOOL_OUTPUT
- Exit code 0 = allow, exit code 2 = deny, other = warn and continue
- Stdout JSON can include: systemMessage, reason, continue (false=block), decision ("block"), hookSpecificOutput.permissionDecision, hookSpecificOutput.permissionDecisionReason, hookSpecificOutput.updatedInput
- Abort signal support for cancelling long-running hooks
- Progress reporting via HookProgressReporter trait

### Plugins

**Plugin types:**
- **Builtin** -- compiled into the binary
- **Bundled** -- shipped in a `bundled/` directory alongside the binary
- **External** -- installed from external sources

**Plugin manifest** (`.claude-plugin/plugin.json`):
```json
{
  "name": "example-plugin",
  "version": "1.0.0",
  "description": "Example plugin",
  "hooks": {
    "PreToolUse": ["hooks/pre.sh"],
    "PostToolUse": ["hooks/post.sh"]
  },
  "tools": [
    {
      "name": "custom_tool",
      "description": "A custom tool",
      "input_schema": { "type": "object", "properties": { ... } }
    }
  ]
}
```

**Plugin lifecycle:**
- Discovery from configured directories (bundled root, external directories)
- Manifest validation
- Enable/disable state tracked per-plugin
- Hook aggregation -- plugin hooks are merged into the runtime hook config
- Tool registration -- plugin tools are added to GlobalToolRegistry
- CLI management via `/plugins` slash command and `claw plugins` subcommand

### Tool Registry Extensibility

The `GlobalToolRegistry` in the tools crate combines:
1. Built-in tool specs (static, compiled in)
2. Plugin-provided tools (dynamic, loaded at runtime)
3. MCP server tools (dynamic, discovered via MCP protocol)

Tools are defined as `ToolSpec` with name, description, input_schema (JSON Schema), and required_permission level.

---

## 8. Configuration System

### Config File Hierarchy

```
~/.claw/settings.json          # User-level (ConfigSource::User)
.claw/settings.json            # Project-level (ConfigSource::Project)
.claw/settings.local.json      # Local-level (ConfigSource::Local, gitignored)
```

Merging order: User < Project < Local (later wins).

### Configuration Shape

```rust
RuntimeFeatureConfig {
    hooks: RuntimeHookConfig {
        pre_tool_use: Vec<String>,      // Shell commands
        post_tool_use: Vec<String>,
        post_tool_use_failure: Vec<String>,
    },
    plugins: RuntimePluginConfig {
        enabled_plugins: BTreeMap<String, bool>,
        external_directories: Vec<String>,
        install_root: Option<String>,
        registry_path: Option<String>,
        bundled_root: Option<String>,
    },
    mcp: McpConfigCollection {
        servers: BTreeMap<String, ScopedMcpServerConfig>,
    },
    oauth: Option<OAuthConfig>,
    model: Option<String>,
    permission_mode: Option<ResolvedPermissionMode>,
    permission_rules: RuntimePermissionRuleConfig {
        allow: Vec<String>,   // e.g. "bash(git:*)"
        deny: Vec<String>,    // e.g. "bash(rm -rf:*)"
        ask: Vec<String>,     // Forces prompt even in DangerFullAccess
    },
    sandbox: SandboxConfig {
        enabled: Option<bool>,
        namespace_restrictions: Option<bool>,
        network_isolation: Option<bool>,
        filesystem_mode: Option<FilesystemIsolationMode>,
        allowed_mounts: Vec<String>,
    },
}
```

### Environment Variables

| Variable | Purpose |
|----------|---------|
| `ANTHROPIC_API_KEY` | Anthropic API authentication |
| `ANTHROPIC_AUTH_TOKEN` | OAuth bearer token |
| `ANTHROPIC_BASE_URL` | Custom API endpoint (proxy support) |
| `XAI_API_KEY` | xAI/Grok authentication |
| `XAI_BASE_URL` | Custom xAI endpoint |
| `OPENAI_API_KEY` | OpenAI authentication |
| `OPENAI_BASE_URL` | Custom OpenAI endpoint |
| `CLAUDE_CODE_AUTO_COMPACT_INPUT_TOKENS` | Auto-compaction threshold (default 100K) |
| `CLAUDE_CONFIG_HOME` | Override config/cache root directory |
| `HOME` | Fallback for config root (`~/.claude/`) |

---

## 9. Multi-Model Support

### Provider Architecture

The `api` crate implements a **provider abstraction** with three backends:

1. **Anthropic** (`AnthropicClient`) -- Full support: streaming, OAuth, bearer tokens, prompt caching, extended thinking, cache break detection
2. **xAI** (`OpenAiCompatClient` with xAI config) -- Grok models via OpenAI-compatible API
3. **OpenAI** (`OpenAiCompatClient` with OpenAI config) -- OpenAI models via native API

### Provider Detection

```
1. Check model name prefix:
   - "claude*" -> Anthropic
   - "grok*"  -> xAI
2. Fall back to checking env vars:
   - ANTHROPIC_API_KEY present -> Anthropic
   - OPENAI_API_KEY present -> OpenAI
   - XAI_API_KEY present -> xAI
3. Default -> Anthropic
```

### Unified Client (`ProviderClient`)

All providers expose the same interface:
- `send_message(request)` -> `MessageResponse`
- `stream_message(request)` -> `MessageStream`

The `MessageStream` enum wraps provider-specific streams and provides a unified `next_event()` -> `StreamEvent` interface.

### Model-Specific Behavior

- **Max tokens:** Opus models get 32K, all others get 64K
- **Pricing:** Model-specific cost tables (Haiku/Sonnet/Opus tiers)
- **Prompt caching:** Only Anthropic provider supports prompt caching; stats return None for xAI/OpenAI
- **Extended thinking:** Supported in API types but provider-specific

---

## 10. Session Management

### Session Data Model

```rust
Session {
    version: u32,              // Currently 1
    session_id: String,        // Unique identifier
    created_at_ms: u64,        // Unix timestamp
    updated_at_ms: u64,        // Updated on every message
    messages: Vec<ConversationMessage>,
    compaction: Option<SessionCompaction>,
    fork: Option<SessionFork>,
    persistence: Option<SessionPersistence>,
}

ConversationMessage {
    role: MessageRole,         // System, User, Assistant, Tool
    blocks: Vec<ContentBlock>, // Text, ToolUse, ToolResult
    usage: Option<TokenUsage>, // Token counts per message
}
```

### Persistence

- **Format:** JSONL (one JSON object per line) with newline-delimited append
- **Location:** `.claude/sessions/session-{timestamp}.jsonl`
- **Rotation:** Files rotate at 256KB, keeping max 3 rotated files
- **Resume:** Load session from file path, reconstruct UsageTracker from message usage data
- **Fork:** Sessions can fork with parent reference and optional branch name

### Session Commands

| Command | Action |
|---------|--------|
| `/session` | Show current session info |
| `/session list` | List all saved sessions |
| `/session switch <id>` | Switch to a different session |
| `/session resume <path>` | Resume from a specific session file |
| `/export [path]` | Export conversation to file |
| `/compact` | Manually trigger compaction |

### Compaction

- **Trigger:** Auto-compaction when input tokens exceed threshold (default 100K, configurable via env var)
- **Preservation:** Most recent N messages kept verbatim (default 4)
- **Summary format:** Structured with scope, tools mentioned, recent user requests, pending work, key files, current work, and full timeline
- **Re-compaction:** When compacting an already-compacted session, previous summaries are preserved as "Previously compacted context" alongside "Newly compacted context"

---

## 11. UI/UX

### CLI Interface

**Binary:** `claw`

**Modes:**
1. **Interactive REPL** -- default mode, rustyline-based editor with tab completion
2. **One-shot prompt** -- `claw prompt "..."` with text or JSON output
3. **Management commands** -- `claw login`, `claw logout`, `claw init`, `claw doctor`, `claw self-update`

### Terminal Rendering

- **Markdown rendering:** Full terminal Markdown with ANSI codes -- headings, bold/italic, code blocks with syntect syntax highlighting, tables, blockquotes, nested lists, links
- **Tool call display:** Box-drawing borders (`--name--`), checkmark/cross icons for success/failure
- **Spinner:** Braille-pattern animated spinner during thinking
- **Streaming:** Character-by-character streaming with 8ms delay per chunk (known issue, planned to be removed)

### Planned TUI Enhancements (TUI-ENHANCEMENT-PLAN.md)

A detailed 6-phase enhancement plan exists:
- Phase 0: Structural cleanup (break 3,159-line main.rs monolith)
- Phase 1: Status bar with live token counter, turn duration, git branch
- Phase 2: Enhanced streaming with live markdown rendering, thinking indicator, progress bar
- Phase 3: Tool call visualization with collapsible output, syntax highlighting, diff-aware edits
- Phase 4: Enhanced slash commands with colored diff, pager, search, undo, interactive session picker
- Phase 5: Color themes (dark/light/solarized/catppuccin)
- Phase 6: Full-screen TUI mode with ratatui (split-pane layout, scrollable conversation, mouse support)

---

## 12. Security Model

### Permission Modes (5 levels)

| Mode | Access | Description |
|------|--------|-------------|
| ReadOnly | File reading only | No writes, no bash |
| WorkspaceWrite | Read + workspace writes | Can write files in workspace |
| DangerFullAccess | Everything | No restrictions |
| Prompt | Ask for each | Interactive approval required |
| Allow | Auto-allow all | Skip all checks |

### Permission Rules

Fine-grained rules that can override mode-based decisions:
- **Allow rules:** `bash(git:*)` -- allow bash commands starting with "git"
- **Deny rules:** `bash(rm -rf:*)` -- deny regardless of mode
- **Ask rules:** `bash(git:*)` -- force interactive prompt even in DangerFullAccess mode

Rules match on tool name and input content. Input matching extracts the "subject" from JSON (command, path, file_path, filePath, url, pattern, code, message fields).

### Permission Enforcement Flow

```
1. Check deny rules -> if match, DENY (short-circuit)
2. Check hook permission override:
   - Deny -> DENY
   - Ask -> PROMPT
   - Allow -> continue
3. Check ask rules -> if match, PROMPT (even if mode allows)
4. Check allow rules -> if match, ALLOW
5. Compare mode: active_mode >= required_mode -> ALLOW
6. If Prompt mode or WorkspaceWrite->DangerFullAccess: -> PROMPT
7. Default -> DENY
```

### Sandbox Isolation

- **Linux namespaces** via `unshare`: user, mount, IPC, PID, UTS, optional network
- **Filesystem isolation:** workspace-only or explicit allow-list
- **Container detection:** Checks /.dockerenv, /run/.containerenv, CONTAINER/DOCKER/PODMAN/KUBERNETES_SERVICE_HOST env vars, /proc/1/cgroup markers
- **Graceful degradation:** Falls back with reason when namespaces unavailable
- **Sandbox home:** Creates `.sandbox-home` and `.sandbox-tmp` in workspace

### Hook-Based Security

Hooks can enforce custom security policies:
- PreToolUse hooks can inspect and block dangerous operations
- Hooks can rewrite tool inputs to add safety constraints
- PostToolUse hooks can audit outputs for sensitive data
- Exit code 2 from any hook = hard deny

---

## 13. Competitive Analysis -- Implications for Trio

### Strengths to Learn From

1. **Comprehensive permission system:** The 5-mode + rule-based + hook-override permission system is very well-designed. The ability to have deny rules that override everything, ask rules that force prompts even in full-access mode, and hooks that can rewrite inputs gives fine-grained control.

2. **Prompt cache monitoring:** The cache break detection system provides operational visibility that most agent harnesses lack. Worth considering for cost optimization.

3. **Session compaction with context preservation:** The layered compaction that preserves previous summaries, extracts key files, and infers pending work is more sophisticated than simple truncation.

4. **Hook input rewriting:** Allowing hooks to modify tool inputs (not just block/allow) is a powerful pattern for policy enforcement and safety guardrails.

5. **Plugin-provided tools:** Plugins that can register their own tools with the model is a clean extensibility pattern.

6. **Multi-provider support with unified streaming:** The trait-based provider abstraction with Anthropic, xAI, and OpenAI support through a single interface is clean.

### Weaknesses / Gaps (Opportunities for Trio)

1. **No multi-agent orchestration layer:** Claw has sub-agents (`Agent` tool) but no equivalent to Trio's team mode, parallel execution, or inter-agent communication.

2. **No wisdom/learning accumulation:** No mechanism for the system to learn from past sessions or accumulate knowledge across runs.

3. **No incremental merge detection:** No awareness of git merge patterns or code conflict resolution.

4. **No category routing:** No intelligent routing of tasks to specialized agents based on task type.

5. **No spec-driven workflows:** No equivalent to Trio's /scope -> /build -> /verify pipeline.

6. **No cross-verification:** No mechanism to validate agent output using a different model.

7. **No audit system:** No multi-persona audit capability.

8. **Single-session focus:** No support for multiple concurrent sessions or parallel agent execution.

9. **Hook execution not wired into agentic loop:** PARITY.md acknowledges hooks exist as standalone runner but aren't integrated into the conversation loop yet. This is their #1 parity gap.

10. **Plugin system incomplete:** Plugin install/update/validation lifecycle is mostly scaffolded but not fully operational.

11. **Main binary is a monolith:** The 3,159-line main.rs is acknowledged as a maintenance risk in their TUI plan.

12. **No remote transport stack:** Missing SSE/WebSocket/CCR transport layers for remote agent execution.

### Key Takeaways

- Claw Code Parity demonstrates that the core Claude Code agent harness can be reimplemented in ~20K lines of Rust with full tool system, permissions, sessions, hooks, MCP, and multi-provider support.
- The permission and hook systems are the most mature parts and worth studying for design patterns.
- The project is very young (created April 2, 2026) but moves fast due to AI-assisted development (OmX orchestration).
- The Rust implementation prioritizes correctness (forbid unsafe, pedantic clippy) and testability (trait-based abstractions, extensive unit tests).
- The parity gap analysis (PARITY.md) is refreshingly honest about what's missing and serves as a de facto roadmap.

---

## Appendix A: File Sizes (Estimated from API Responses)

| File | Approx Size |
|------|-------------|
| `rust/crates/rusty-claude-cli/src/main.rs` | ~3,159 lines |
| `rust/crates/tools/src/lib.rs` | ~3,500 lines |
| `rust/crates/plugins/src/lib.rs` | ~2,100 lines |
| `rust/crates/runtime/src/conversation.rs` | ~1,100 lines |
| `rust/crates/runtime/src/config.rs` | ~1,000 lines |
| `rust/crates/runtime/src/session.rs` | ~850 lines |
| `rust/crates/runtime/src/prompt.rs` | ~600 lines |
| `rust/crates/runtime/src/permissions.rs` | ~500 lines |
| `rust/crates/runtime/src/hooks.rs` | ~550 lines |
| `rust/crates/runtime/src/sandbox.rs` | ~350 lines |
| `rust/crates/runtime/src/compact.rs` | ~600 lines |
| `rust/crates/api/src/providers/anthropic.rs` | ~950 lines |
| `rust/crates/api/src/providers/openai_compat.rs` | ~750 lines |
| `rust/crates/api/src/prompt_cache.rs` | ~500 lines |
| `rust/crates/api/src/client.rs` | ~200 lines |
| `rust/crates/commands/src/lib.rs` | ~1,500 lines |
| `rust/crates/telemetry/src/lib.rs` | ~400 lines |
| **Total Rust** | **~20K lines** |

## Appendix B: Python Legacy Surface

The `src/` directory contains a Python porting workspace with reference data snapshots (subsystem JSON files, command/tool inventories) and parity tracking modules. This is the original Python port that preceded the Rust rewrite. It contains:
- `port_manifest.py` -- workspace structure summary
- `models.py` -- dataclasses for subsystems/modules/backlog
- `commands.py` -- command port metadata
- `tools.py` -- tool port metadata
- `query_engine.py` -- porting summary renderer
- `parity_audit.py` -- audit against archived source
- `reference_data/` -- 27 subsystem JSON snapshots from the original TypeScript source

The Python surface is no longer the active development target.
