# RT-9: Competitor & Stoke Update Check (April 3, 2026)

Scan date: 2026-04-03. Window: last 48 hours (April 2-3).

---

## 1. ericmacdougall/Stoke (our repo)

**Last commit:** `797b861` (Apr 2, 01:33 UTC) -- "Code formatting and prior review fixes"

All 7 commits landed on Apr 2 as a single push covering the initial code upload and hardening passes:
- `b95cfa6` Add stoke project source code
- `5849b81` Fix critical bugs: error handling, race conditions, security
- `ace6753` Fix concurrency, security, correctness (second-pass review)
- `70270ae` GPT review: fail-closed gitignored files, ship gates, repo hygiene
- `8513012` Fix attempt numbering, add SaveState locking, regression tests
- `d3705dd` Auto-upgrade to SQLite store for parallel builds and ship mode
- `6bde62c` Production hardening: check all error returns, fix resource leaks
- `797b861` Code formatting and prior review fixes

**No issues, PRs, releases, or discussions.** Repo is code-only so far.

---

## 2. ultraworkers/claw-code

**Last commit:** `95e1290` (Apr 1, 21:05 UTC) -- merge release/0.1.0

**No new commits since Apr 1.** The 0.1.0 release merge was the last activity. No new releases published. Appears dormant for the past 48 hours.

Key Apr 1 activity was a release REPL hardening push and CLI redesign convergence. Nothing new since then.

---

## 3. code-yeongyu/oh-my-openagent

**VERY ACTIVE -- 20+ commits on Apr 3 alone.**

Notable changes (Apr 3):
- `141881a` **fix(tmux): re-attempt isolated container on deferred session retry** -- tmux session isolation improvements
- `cab8451` **fix(hooks): replace empty catch blocks with debug logging** -- transcript debugging
- `6acca09` **fix(ci): resolve mock.module() cross-file leakage** in test suite
- `f547cd0` **refactor(shared): consolidate plugin entry migration and detection utilities** -- shared plugin detection
- `fd252ea` **refactor: remove AI-generated code smells** from prepublish changes
- Multiple prepublish fix PRs merged (#3087-#3092): MCP regressions, security hardening, background regressions, tmux regressions, quality checks, legacy config

**Pattern:** Aggressive prepublish stabilization. Fixing real bugs found by automated quality checks before cutting a release. Heavy on tmux session management and plugin migration.

---

## 4. Yeachan-Heo/oh-my-claudecode

**RELEASED v4.10.0 and v4.10.1 (Apr 2-3).**

### v4.10.0 Highlights (actionable for Stoke v2):
- **HUD: worktree detection + configurable element ordering** -- layout customization, worktree-aware context
- **HUD: elapsed time since prompt** (not clock time), per-model weekly quota display, last tool name display, OSC 8 terminal hyperlinks
- **feat(skill): self-improve autonomous code improvement skill** -- autonomous improvement loops
- **feat(lsp): LSP 3.17 pull diagnostics for kotlin-lsp**
- **Security:** hardened Python sandbox blocklist, blocked tmux send-keys in worker bash, enforced disableExternalLLM in team worker contracts
- **Runtime fixes:** persistent-mode edge cases, stale skill state blocking session stop, Ralph stop-hook cancels trapping sessions

### v4.10.1 (Apr 3):
- Patch: rebuilt missing dist/ HUD layout artifacts from v4.10.0 packaging mistake

### New Issues (Apr 3):
- **#2142** feat(observability): emit session usage threshold events for prompt turns and context% -- structured events when sessions cross turn/context thresholds (for external alerting via Discord etc.)
- **#2141** feat(agents): safety protocols for orchestrator AGENTS.md
- **#2140** feat(verifier): detection gates for false-positive verification -- stub detection, phantom completion detection, cross-phase regression gates. Catches empty shells that compile but have no logic.
- **#2139** feat(executor): governance guardrails for multi-agent orchestration
- **#2134** feat(skills): inject Codex availability for ralplan/plan/ralph

### Open PRs:
- **#2146** fix: explicit overwrite choice + omc launch profile (follows #2143 about not overwriting user config)

---

## 5. Yeachan-Heo/oh-my-codex

**RELEASED v0.11.12 (Apr 2).**

### v0.11.12 Highlights:
- Windows terminal flicker fixes (windowsHide, filesystem git-info reads)
- Team/runtime seam hardening (manifest.v2 cwd resolution, dispatch/mailbox transitions)
- tmux readiness + auto-nudge restricted to OMX-managed sessions
- Cross-platform Node test runner for release portability
- Workflow docs standardized around deep-interview -> ralplan -> team/ralph

### New Issues/PRs (Apr 2-3):
- **#1204** fix(team): reap detached worker descendants on shutdown
- **#1203** fix: stop fallback tmux auto-answers during deep interview
- **#1193** fix: warn when uninstall leaves legacy ~/.agents/skills
- **#1188** Refactor Discord and Telegram probe functions
- **#1165** Vietnamese getting started docs
- **#1162** fix: bound same-session Ralph adoption to empty current scope

---

## 6. Yeachan-Heo/claw-code-parity (Rust)

**Last commit:** `765635b` (Apr 2, 05:00 UTC) -- "clean up post-merge compiler warnings"

Recent Apr 2 activity:
- `de228ee` fix: forward prompt cache events through clients
- `0bd0914` fix: stabilize merge fallout test fixtures
- `12c364d` fix: align session tests with jsonl persistence
- `ffb1338` fix: cover merged prompt cache behavior
- `de589d4` fix: restore anthropic request profile integration

**Pattern:** Integration branch stabilization. Merging cache tracking, telemetry, and parity fixes into a cleanroom integration branch. No new releases.

---

## Actionable Takeaways for Stoke v2

### Worth adopting / studying:

1. **Verifier false-positive detection** (oh-my-claudecode #2140) -- Stub detection (EXISTS/SUBSTANTIVE/WIRED levels), phantom completion detection (cross-ref claims against git diff), cross-phase regression gates. Directly relevant to Stoke's verify phase.

2. **Session usage threshold events** (oh-my-claudecode #2142) -- Structured events when context% or turn count crosses thresholds. Useful for Stoke's resource-aware scheduling.

3. **Autonomous self-improve skill** (oh-my-claudecode v4.10.0) -- Built-in autonomous code improvement loops. Relates to Stoke's iterative refinement goals.

4. **Configurable HUD element ordering** (oh-my-claudecode v4.10.0) -- Layout customization with worktree awareness. Pattern worth considering for Stoke's status display.

5. **Plugin migration consolidation** (oh-my-openagent) -- Shared utilities for detecting and migrating legacy plugin configs atomically. Relevant if Stoke will have a plugin/extension model.

6. **Worker descendant reaping** (oh-my-codex #1204) -- Proper shutdown of detached worker descendants. Critical for multi-agent orchestration reliability.

7. **Prompt cache event forwarding** (claw-code-parity) -- Forwarding cache events through client layers. Relevant for Stoke's API pool/cost optimization.

### Not immediately relevant:
- Windows flicker fixes (we target Linux/macOS)
- Korean/Vietnamese/Polish i18n
- Kotlin LSP support
- Discord/Telegram probe refactoring
