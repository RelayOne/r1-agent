# RT-8: State of the Art in AI Coding Agent Orchestration (April 2026)

Research ticket for Stoke orchestrator enhancement. Findings from 30+ web sources cross-referenced against Stoke's existing architecture (19 internal packages, 14K lines Go, 206 tests).

---

## Executive Summary

Stoke is ahead of most production tools in this space. The PLAN->EXECUTE->VERIFY->COMMIT phase machine, cross-model review, 11-layer policy engine, subscription pool rotation with circuit breakers, and git worktree isolation put it in the top tier. However, the landscape has matured rapidly in Q1 2026 and several patterns have emerged that Stoke should adopt, refine, or explicitly decide against.

**What Stoke already does better than most:**
- Deterministic phase enforcement (most tools still use ReAct loops)
- Cross-model adversarial review (only Metaswarm and Taskplane also do this)
- 10-class failure analysis with structured retry briefs (unique depth)
- Subscription pool rotation with circuit breakers and OAuth usage polling
- Wisdom accumulation across sessions
- GRPW priority scheduling with file-scope conflict detection

**What Stoke is missing or could improve (ranked by impact):**
1. Agent self-reflection / REFLECTION.md protocol after each task
2. Tiered model routing for cost optimization (frontier for planning, mid-tier for execution)
3. Deterministic pre-merge quality scanning (SonarQube/Codacy integration)
4. Compound learning validation (research shows LLM-generated wisdom degrades performance)
5. Progressive context disclosure (load context in tiers, not all at once)
6. Oracle-based parallel conflict resolution (Carlini's GCC trick)
7. Background task execution (non-blocking build/test runs)
8. MCP-based tool extension surface
9. Canary deployment validation gates
10. Session cost attribution and ROI dashboards

---

## 1. Claude Code Orchestration: Best Practices and Common Patterns

### Sources
- [Anthropic Agent Teams Docs](https://code.claude.com/docs/en/agent-teams)
- [Shipyard: Multi-agent orchestration for Claude Code](https://shipyard.build/blog/claude-code-multi-agent/)
- [Addy Osmani: The Code Agent Orchestra](https://addyosmani.com/blog/code-agent-orchestra/)
- [Claude Code Swarm Orchestration Skill](https://gist.github.com/kieranklaassen/4f2aba89594a4aea4ad64d753984b2ea)
- [BSWEN: Multi-Agent AI Coding Teams](https://docs.bswen.com/blog/2026-03-28-multi-agent-coding-team/)

### Proven Patterns

**Three-tier orchestration model (industry consensus as of March 2026):**

| Tier | Description | Best For |
|------|-------------|----------|
| Tier 1: Subagents | Single terminal, Task tool spawns child agents | Quick research, isolated subtasks, 1-3 agents |
| Tier 2: Machine orchestrators | Isolated worktrees, dashboards, merge control | Feature development, 3-10 agents |
| Tier 3: Cloud agents | VMs, no terminal, remote progress | CI/CD pipelines, 10+ agents |

Stoke operates at Tier 2 with Tier 3 ambitions (Ember integration). This is the right positioning.

**Agent Teams coordination primitives (Claude Code native):**
- Shared task list with dependency tracking
- Peer-to-peer messaging between teammates
- File locking to prevent conflicts
- One session as team lead, others as teammates

**Key finding:** Claude Code Agent Teams are still experimental and disabled by default. They are sequential, not parallel. Stoke's goroutine + worktree approach is architecturally superior for throughput.

**Production scaling guidance:** Keep agent teams to 3-4 specialists maximum. Beyond that, coordination overhead eats productivity gains faster than parallel execution provides them. 86% of organizations deploy agents for production code in 2026, with 57% running multi-stage workflows.

### Gap Analysis vs Stoke

Stoke already exceeds Claude Code's native orchestration. The main gap is that Claude Code's Agent Teams have a built-in messaging protocol between agents that Stoke lacks -- agents can ask each other questions mid-task. Stoke's agents are currently fire-and-forget within a phase. Adding lightweight inter-agent messaging (via the session store or a dedicated channel) could help for complex interdependent tasks.

**Recommendation:** LOW PRIORITY. Inter-agent messaging adds complexity for marginal gain when tasks are properly decomposed. Monitor whether Claude Code's Agent Teams stabilize in Q2 2026.

---

## 2. Codex CLI Orchestration: Tools and Strategies

### Sources
- [OpenAI Codex Subagents](https://developers.openai.com/codex/subagents)
- [Building Consistent Workflows with Codex CLI & Agents SDK](https://developers.openai.com/cookbook/examples/codex/codex_mcp_agents_sdk/building_consistent_workflows_codex_cli_agents_sdk)
- [Codex macOS: Orchestration-First Agent Desktop](https://alexlavaee.me/blog/codex-macos-orchestration-desktop/)
- [OmX for Codex CLI: Multi-Agent Orchestration](https://addrom.com/omx-for-codex-cli-a-practical-guide-to-multi-agent-orchestration-hooks-and-huds/)

### Proven Patterns

**Codex as MCP server + Agents SDK orchestration:**
OpenAI's recommended pattern exposes Codex CLI as an MCP server, then orchestrates it with the Agents SDK to create deterministic, reviewable workflows. This gives:
- Structured tool definitions for each agent capability
- Handoff protocols between agents
- Guardrails via `output_guardrails` on the agent definition
- Tracing and observability built into the SDK

**Codex app (macOS, launched Feb 2026):**
- Command center for agents, not just a coding tool
- Parallel agent management with visual review
- Background long-running tasks
- Skills system for extending agent capabilities beyond code generation
- 1M+ developers using it monthly

**Key technical detail:** Codex handles subagent orchestration natively -- spawning, routing follow-ups, waiting for results, and closing threads. The CLI as MCP server pattern means any orchestrator (including Stoke) can drive Codex through a standard protocol.

### Gap Analysis vs Stoke

Stoke already drives Codex CLI as an execution engine via `engine/codex.go`. The gap is that Stoke doesn't use Codex's MCP server mode -- it drives Codex via CLI subprocess. Adopting the MCP protocol would give:
- Structured tool call interception (not just stdout parsing)
- Native handoff between Codex subagents
- Built-in guardrails from the Agents SDK

**Recommendation:** MEDIUM PRIORITY. The MCP server approach is cleaner than subprocess management for Codex. Consider adding an `MCPBackend` to the engine interface alongside the existing `CLIBackend`. However, this is an optimization, not a gap -- Stoke's subprocess approach works.

---

## 3. Multi-Model AI Agent Orchestration Architectures

### Sources
- [Chanl: The Multi-Agent Pattern That Actually Works in Production](https://www.chanl.ai/blog/multi-agent-orchestration-patterns-production-2026)
- [Microsoft Azure: AI Agent Design Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)
- [Agix: Conductor vs Swarm Architecture](https://agixtech.com/conductor-vs-swarm-multi-agent-ai-orchestration/)
- [Deloitte: Unlocking exponential value with AI agent orchestration](https://www.deloitte.com/us/en/insights/industry/technology/technology-media-and-telecom-predictions/2026/ai-agent-orchestration.html)
- [Codebridge: Multi-Agent Systems & AI Orchestration Guide](https://www.codebridge.tech/articles/mastering-multi-agent-orchestration-coordination-is-the-new-scale-frontier)

### Proven Patterns

**Two dominant production architectures:**

1. **Hierarchical Orchestration (Conductor)** -- A central orchestrator agent assigns tasks, monitors progress, and handles failures. Prioritizes control and predictability. This is what Stoke uses.

2. **Swarm Intelligence** -- Agents communicate peer-to-peer, self-organize, and emerge solutions. Prioritizes speed and resilience. Higher risk of divergence.

**Industry consensus: Conductor wins for coding tasks.** Swarm patterns work for research and exploration but fail for deterministic code quality. Stoke's hierarchical model is correct.

**Cost optimization via heterogeneous model routing (emerging best practice):**
The Plan-and-Execute pattern uses a capable frontier model for planning and cheaper models for execution. This can reduce costs by 90% vs using frontier models for everything. Three tiers:
- **Frontier models** (Opus 4.6, GPT-5.4): Complex reasoning, planning, architecture decisions
- **Mid-tier models** (Sonnet 4.6, GPT-5.2-Codex): Standard implementation tasks
- **Small/local models** (Haiku, Ollama): High-frequency mechanical tasks (formatting, simple refactors)

**MCP as the integration standard:** Anthropic's Model Context Protocol is emerging as the standard for agents from different providers to share tools and context. Every major framework in 2026 supports it.

**Market context:** Gartner predicts 40% of enterprise applications will embed AI agents by end of 2026, up from <5% in 2025. 1,445% surge in multi-agent system inquiries from Q1 2024 to Q2 2025.

### Gap Analysis vs Stoke

Stoke's `model/router.go` already routes by 9 task types with benchmark-backed routes and a 5-provider fallback chain. This is ahead of most tools. The gap is **tiered cost optimization** -- Stoke routes by task type (planning vs refactoring vs review) but doesn't route by task complexity within a type. A simple rename refactor doesn't need Opus; Sonnet would suffice.

**Recommendation:** MEDIUM PRIORITY. Add a complexity estimator to the model router. Use file count, estimated line changes, and dependency depth to decide between frontier and mid-tier models for the same task type. This could cut costs 40-60% without quality loss on simple tasks.

---

## 4. Anti-Laziness / Anti-Slop Verification Strategies

### Sources
- [DEV Community: How we prevent AI agent drift & code slop generation](https://dev.to/singhdevhub/how-we-prevent-ai-agents-drift-code-slop-generation-2eb7)
- [Addy Osmani: The 80% Problem in Agentic Coding](https://addyo.substack.com/p/the-80-problem-in-agentic-coding)
- [Vadim's Blog: The Agent That Says No](https://vadim.blog/verification-gate-research-to-practice)
- [SonarQube Remediation Agent Beta](https://www.sonarsource.com/blog/join-the-sonarqube-remediation-agent-beta)
- [Codacy Guardrails for AI Code](https://www.codacy.com/guardrails)
- [Columbia DAPLab: 9 Critical Failure Patterns of Coding Agents](https://daplab.cs.columbia.edu/general/2026/01/08/9-critical-failure-patterns-of-coding-agents.html)
- [Lars Janssen: Verification Debt](https://fazy.medium.com/agentic-coding-ais-adolescence-b0d13452f981)
- [TFIR: AI Code Quality Guardrails 2026](https://tfir.io/ai-code-quality-2026-guardrails/)

### Proven Patterns

**The "80% Problem" (Osmani, 2026):**
AI agents consistently deliver code that works 80% of the way but fails on edge cases, error handling, and production hardening. The last 20% requires verification systems, not better prompts.

**Columbia DAPLab's 9 Critical Failure Patterns:**
Research from Columbia University classified hundreds of failures into 9 patterns:
1. Error handling suppression (agents suppress exceptions to make code run)
2. Business logic errors (plausible but wrong)
3. Silent failures (no user notification when things go wrong)
4. Half-finished implementations (works for happy path only)
5. Security shortcuts (hardcoded credentials, missing validation)
6. Test quality degradation (tests that pass but don't verify)
7. Dependency confusion (wrong versions, incompatible packages)
8. State management bugs (especially in async/concurrent code)
9. Configuration drift (works locally, fails in production)

**Key insight:** Agents prioritize runnable code over correctness. They will suppress exceptions, add `@ts-ignore`, use `as any`, and create stub implementations to make builds pass. The solution is deterministic verification that catches these patterns.

**Multi-agent validation chains (emerging best practice):**
One agent writes code, another critiques it, a third tests it, a fourth validates compliance and architectural alignment. This matches Stoke's PLAN->EXECUTE->VERIFY->COMMIT + cross-model review.

**External deterministic tools (production-proven 2026):**
- **SonarQube Remediation Agent:** AI-powered automatic fix proposals for code quality and security issues. Deterministic detection + AI remediation.
- **Codacy Guardrails:** Deterministic code analysis inside agentic workflows. Agent follows rules defined by the tool, not its own judgment.
- **Agent skills as verifiable contracts:** Skills should define completion criteria (e.g., `npm run lint`, `npm test`, `git diff --name-only --exit-code`) so completion is objective, not subjective.

**"Verification debt" concept (Janssen, 2026):**
AI-generated code creates a new category of technical debt: code that passed automated checks but was never truly understood by a human. The speed increase from AI coding should come with a proportional increase in test coverage.

### Gap Analysis vs Stoke

Stoke's `verify/pipeline.go` already runs build/test/lint + CheckProtectedFiles + CheckScope + AnalyzeOutcomes. The `failure/analyzer.go` classifies into 10 classes with language-specific parsers and 9 policy patterns. The `hooks/hooks.go` has PreToolUse guards and PostToolUse monitors.

**Gaps:**
1. **No integration with external static analysis tools.** SonarQube/Codacy could catch patterns that Stoke's regex-based scan doesn't (security anti-patterns, complexity metrics, code duplication).
2. **No "verification debt" tracking.** Stoke tracks whether tests pass but doesn't track whether test coverage increased proportionally to code changes.
3. **Missing Columbia failure pattern #6 (test quality degradation).** Stoke verifies tests pass but doesn't verify test assertions are meaningful (e.g., a test that passes with `expect(true).toBe(true)` is technically green but useless).

**Recommendation:**
- HIGH PRIORITY: Add test coverage delta tracking to the verify pipeline. If code changes add 200 lines but tests add 0 assertions, flag it.
- MEDIUM PRIORITY: Add optional SonarQube/Codacy integration as a verify pipeline stage. Many teams already run these tools.
- LOW PRIORITY: Add assertion quality heuristics (detect `expect(true)`, empty test bodies, commented-out assertions).

---

## 5. Parallel Agent Coordination Patterns

### Sources
- [BSWEN: Worktree Isolation in AI Agents](https://docs.bswen.com/blog/2026-03-18-ai-agent-worktree-isolation/)
- [Augment Code: How to Run a Multi-Agent Coding Workspace](https://www.augmentcode.com/guides/how-to-run-a-multi-agent-coding-workspace)
- [Superset IDE](https://superset.sh)
- [Vibecoding: Agentmaxxing](https://vibecoding.app/blog/agentmaxxing)
- [Composio Agent Orchestrator](https://github.com/ComposioHQ/agent-orchestrator)

### Proven Patterns

**Six coordination patterns that prevent file collisions (Augment Code, 2026):**
1. Spec-driven decomposition -- break work into non-overlapping file scopes before dispatch
2. Worktree isolation -- each agent in its own git worktree
3. Coordinator/specialist/verifier role split
4. Per-task model routing
5. Automated quality gates
6. Sequential merges (serialize merge-to-main)

**Scaling limits (production consensus):**
5-10 parallel agents is typical. Beyond that, merging becomes a bottleneck. Start small and scale up.

**Key tools in production:**
- **Superset IDE** (Apache 2.0, launched March 2026): Agent-agnostic terminal for 10+ parallel agents, git worktree isolation, built-in review. 
- **Composio Agent Orchestrator**: Plans tasks, spawns agents, handles CI fixes, merge conflicts, and code reviews autonomously. Each agent in isolated git worktree.
- **Overstory**: Multi-agent orchestration with pluggable runtime adapters (11 runtimes), SQLite mail system for inter-agent communication, tiered conflict resolution.

**Oracle-based parallel conflict resolution (Carlini, 2026):**
When 16 parallel agents kept overwriting each other's fixes on the same files, Carlini introduced a GCC "oracle" -- compile most files with GCC, only a random subset with the agent's compiler. If the build breaks, the bug is in the agent's subset. This turned one monolithic problem into many smaller, parallelizable ones.

This pattern generalizes: use a known-good reference (existing passing tests, main branch behavior) to isolate which parallel agent introduced a regression, without running a full merge-and-test cycle.

### Gap Analysis vs Stoke

Stoke's `worktree/manager.go` already provides worktree creation with BaseCommit, `git merge-tree --write-tree` for zero-side-effect conflict validation, mergeMu serialization, and force cleanup. The `scheduler/scheduler.go` does GRPW priority with file-scope conflict detection.

**Gaps:**
1. **No oracle-based regression isolation.** When multiple worktrees merge and something breaks, Stoke re-verifies but doesn't isolate which merge caused the regression. Carlini's oracle pattern would help.
2. **No inter-agent communication channel.** Overstory's SQLite mail system is lightweight and could help when agents discover information relevant to other running tasks.
3. **Merge serialization is a bottleneck at scale.** `mergeMu sync.Mutex` means merges are fully serialized. At 10+ agents, this becomes the limiting factor.

**Recommendation:**
- MEDIUM PRIORITY: Add oracle-based regression isolation. After a merge causes test failure, bisect by re-running tests with each merged worktree's changes individually against the base.
- LOW PRIORITY: Inter-agent messaging. Only valuable for deeply interdependent tasks, which proper spec-driven decomposition should minimize.
- FUTURE: Optimistic parallel merges with rollback. Replace mutex serialization with optimistic concurrency -- merge in parallel, detect conflicts, rollback the losing merge. Only matters at 10+ agent scale.

---

## 6. Self-Reflection / Chain-of-Thought Verification Loops

### Sources
- [StackViv: Agent Reflection -- How AI Agents Self-Improve](https://stackviv.ai/blog/reflection-ai-agents-self-improvement)
- [Hugging Face: AI Trends 2026 -- Test-Time Reasoning and Reflective Agents](https://huggingface.co/blog/aufklarer/ai-trends-2026-test-time-reasoning-reflective-agen)
- [Addy Osmani: Self-Improving Coding Agents](https://addyosmani.com/blog/self-improving-agents/)
- [The Ralph Wiggum AI Coding Loop](https://www.leanware.co/insights/ralph-wiggum-ai-coding)
- [Matt James: Autonomous AI Coding with Ralph](https://mattjames.dev/posts/2026-01-21-autonomous-ai-coding-with-ralph)
- [Galileo: Self-Evaluation in AI Agents](https://galileo.ai/blog/self-evaluation-ai-agents-performance-reasoning-reflection)
- [Owain Lewis: The 10x Skill for AI Engineers -- Agent Feedback Loops](https://newsletter.owainlewis.com/p/the-10x-skill-for-ai-engineers-in)

### Proven Patterns

**The Ralph Loop (industry-standard pattern, Jan 2026):**
Named after "Ralph Wiggum" -- an agent that runs in a stateless-but-iterative loop:
1. Pick task from queue
2. Implement in isolated context
3. Validate (build/test/lint)
4. If pass: commit and move to next task
5. If fail: analyze, generate retry context, loop back to step 2
6. Reset context between tasks (prevents context overflow)

This is architecturally identical to Stoke's workflow. Stoke predates the Ralph Loop's popularization but implements the same pattern with more sophisticated failure analysis.

**Self-reflection protocol (Osmani, 2026):**
After every task completion, the agent writes a `REFLECTION.md` noting:
1. What surprised it during the task
2. One pattern to add to AGENTS.md / CLAUDE.md
3. One prompt improvement suggestion

This forces structured learning. External verification signals (test execution, tool validation) combined with verbal reflection consistently outperform either approach alone.

**CodeCoR Framework (academic, 2026):**
Adds dedicated reflection agents between code generation, testing, and repair stages. The reflection agent is a separate model invocation specifically prompted to analyze what went wrong, distinct from the implementation agent.

**Evaluator-Reflector pattern:**
- **Evaluator:** Scores the actor's output (could be binary from unit test, heuristic check, or another LLM)
- **Self-Reflection Model:** Takes the evaluation result and generates natural language explanation of what went wrong and how to fix it
- **Actor:** Receives reflection and retries with enriched context

### Gap Analysis vs Stoke

Stoke's `failure/analyzer.go` and retry brief generation already implement the Evaluator-Reflector pattern. The `wisdom/wisdom.go` accumulates cross-session learning. What's missing:

**Gaps:**
1. **No structured self-reflection after successful tasks.** Stoke only reflects on failures. Successful tasks also produce learnable patterns ("this codebase uses X pattern", "imports from Y need Z").
2. **No REFLECTION.md protocol.** The agent doesn't write what surprised it. This meta-learning is valuable for both the wisdom store and for improving prompt templates.
3. **No separate reflection model invocation.** Stoke uses the same model for implementation and failure analysis. Using a different model (or even the same model with a dedicated reflection prompt) for post-task reflection could catch blind spots.

**Recommendation:**
- HIGH PRIORITY: Add a post-task reflection step for both successes and failures. After COMMIT, invoke a brief reflection prompt: "What did you learn about this codebase? What patterns should future tasks know?" Feed results into wisdom store.
- MEDIUM PRIORITY: Use a different model for reflection than implementation. This creates a cross-model learning loop in addition to the cross-model review gate.
- LOW PRIORITY: REFLECTION.md file per session. Useful for human review but the wisdom store already captures this programmatically.

---

## 7. Cross-Model Review Gates

### Sources
- [Zylos Research: Multi-Model AI Code Review](https://zylos.ai/research/2026-02-17-multi-model-ai-code-review)
- [DEV Community: The Case for Adversarial Cross-Model Review](https://dev.to/john_wade_dev/when-one-model-reviews-its-own-work-the-case-for-adversarial-cross-model-review-37k1)
- [Metaswarm: Multi-Agent Orchestration](https://github.com/dsifry/metaswarm)
- [Taskplane: Multi-agent AI orchestration](https://github.com/HenryLach/taskplane)
- [Ry Walker: Autonomous Agentic Engineering Tools Compared](https://rywalker.com/research/autonomous-agentic-engineering-tools)

### Proven Patterns

**Metaswarm's cross-model review (Dave Sifry, production-proven):**
- 18 specialized agents, 13 skills, 15 commands
- Rule: the writer is ALWAYS reviewed by a different model
- The writer never reviews its own output
- 9-phase workflow: Research -> Plan -> Design Review Gate -> Work Unit Decomposition -> Orchestrated Execution -> Final Review -> PR Creation -> PR Shepherd -> Closure & Learning
- 4-phase execution loop per work unit: IMPLEMENT -> VALIDATE -> ADVERSARIAL REVIEW -> COMMIT
- 100% test coverage mandate, mandatory TDD

**Taskplane's approach:**
- Cross-model review recommended but not enforced
- Independent quality gate before merge
- Focus on transparency ("light-factory not dark-factory")

**Ensemble review (emerging):**
- Run multiple review models in parallel
- Use voting/consensus to reduce false positives
- Specialized reviewer models fine-tuned for specific bug categories
- Adaptive round budgets (more review rounds for riskier changes)

**Key insight from research:** "Confidence in LLM output is a stylistic feature, not an epistemic one." Models reproduce patterns without underlying verification. Cross-model review catches these confidence-without-competence blind spots.

### Gap Analysis vs Stoke

Stoke's `model/router.go` already has `CrossModelReviewer()` that ensures the reviewer is from a different model family than the implementer. This is ahead of most tools.

**Gaps:**
1. **No ensemble review.** Stoke uses one reviewer. Running two reviewers in parallel and taking the union of findings would increase detection rate.
2. **No adaptive review depth.** All changes get the same review intensity. High-risk changes (security, auth, payments) should get deeper multi-round review.
3. **No PR shepherding.** Metaswarm's PR Shepherd phase monitors the PR after creation, responds to CI failures and reviewer comments. Stoke's workflow ends at COMMIT.

**Recommendation:**
- MEDIUM PRIORITY: Add risk-based review depth. Use file path patterns and change size to classify risk (high/medium/low). High-risk changes get ensemble review (two models). Low-risk changes get standard single-model review.
- LOW PRIORITY: Ensemble review for all changes. Adds cost and latency for marginal gain on low-risk changes.
- FUTURE: PR shepherding. Relevant when Stoke integrates with GitHub/GitLab PR workflows.

---

## 8. Progressive Context Management for Long AI Sessions

### Sources
- [SwirlAI: State of Context Engineering in 2026](https://www.newsletter.swirlai.com/p/state-of-context-engineering-in-2026)
- [Blake Crosley: Context Window Management -- What 50 Sessions Taught Me](https://blakecrosley.com/blog/context-window-management)
- [Substratia: Ultimate Guide to Claude Code Context Management](https://substratia.io/blog/context-management-guide/)
- [Martin Fowler: Context Engineering for Coding Agents](https://martinfowler.com/articles/exploring-gen-ai/context-engineering-coding-agents.html)
- [Manus: Context Engineering for AI Agents](https://manus.im/blog/Context-Engineering-for-AI-Agents-Lessons-from-Building-Manus)
- [Faros: Context Engineering for Developers](https://www.faros.ai/blog/context-engineering-for-developers)
- [InfoQ: New Research Reassesses the Value of AGENTS.md Files](https://www.infoq.com/news/2026/03/agents-context-file-value-review/)
- [OPENDEV Paper (arxiv 2603.05344)](https://arxiv.org/abs/2603.05344)
- [Anthropic: Building a C Compiler](https://www.anthropic.com/engineering/building-c-compiler)

### Proven Patterns

**Progressive context disclosure (Manus, production-proven):**
Load context in three stages:
1. **Discovery:** Just names and descriptions of available tools/files
2. **Activation:** Full instructions when a tool/file becomes relevant
3. **Execution:** Scripts and reference materials only during the task

This prevents context overload while ensuring the agent has what it needs when it needs it.

**OPENDEV's four-subsystem context architecture:**
1. System Reminders -- context-aware behavioral guidance (event-driven, not static)
2. Prompt Composer -- modular system-prompt assembly per phase
3. Memory -- cross-session continuity with relevance scoring
4. Compaction -- token-budget reclamation (progressive, not destructive)

Design principles: separation of concerns (independent configurability), progressive degradation (graceful with exhausted resources), transparency over magic (observable and overridable).

**Quality degrades at ~60% context utilization** (multiple sources confirm this threshold). Proactive compaction should trigger well before this.

**Carlini's context hygiene lesson:** Context pollution kills productivity. Agents that dump verbose output into their context windows degrade faster. Concise logging and aggregate statistics, rather than raw test output, keep context clean.

**Critical research finding on AGENTS.md / CLAUDE.md files (InfoQ, March 2026):**
> LLM-generated context files degrade performance, reducing task success rate by an average of 3% and increasing inference costs by 20%+. Human-written files offer a marginal 4% increase in task success rate but also increase steps taken and costs by up to 19%.

**Recommendation from the research:** Omit LLM-generated context files entirely. Limit human-written instructions to non-inferable details (specific tooling, custom build commands, unconventional patterns).

**Specification-driven development (consensus best practice):**
Before starting any feature, write a plan document with goals, acceptance criteria, technical constraints, and implementation notes. Not a Jira ticket with three bullet points -- a real markdown file. This front-loads context so the agent starts with the right information.

**Session and git isolation:** Always use a feature branch. Running an agent on main is asking for trouble. (Stoke already does this with worktrees.)

### Gap Analysis vs Stoke

Stoke's `context/context.go` already implements three-tier budget (active/session/project), progressive compaction (gentle/moderate/aggressive), and 6 event-driven reminders. This is architecturally aligned with OPENDEV's approach.

**Gaps:**
1. **No progressive context disclosure.** Stoke loads full context at phase start. It should load discovery-level context first and promote to full detail only when relevant.
2. **Wisdom accumulation may be counterproductive.** The research shows LLM-generated context files hurt performance. Stoke's `wisdom/wisdom.go` accumulates session learnings and injects them into future tasks. This needs validation -- are the injected wisdom entries actually improving task success, or adding noise?
3. **No context utilization metrics.** Stoke tracks budget thresholds but doesn't report how much context is actually being used per task. This data would inform compaction tuning.
4. **Verbose output in context.** Need to verify that build/test/lint output is being summarized before injection, not dumped raw.

**Recommendation:**
- HIGH PRIORITY: Validate wisdom accumulation impact. A/B test: run the same task set with and without wisdom injection. Measure success rate and cost. If wisdom hurts, limit it to human-verified entries only.
- HIGH PRIORITY: Add progressive context disclosure to phase prompts. Start with file names and summaries. Promote to full content only when the agent requests it or the phase requires it.
- MEDIUM PRIORITY: Add context utilization telemetry. Track tokens used per task, per phase. Use this data to tune compaction thresholds.
- LOW PRIORITY: Output summarization verification. Ensure `verify/pipeline.go` outputs are summarized before being included in retry briefs.

---

## 9. Subscription Pool Rotation and Rate Limit Handling

### Sources
- [pi-multi-pass: Multi-subscription extension](https://github.com/hjanuschka/pi-multi-pass)
- [CCS: Claude account switching proxy](https://github.com/kaitranntt/ccs)
- [LiteLLM: Routing & Load Balancing](https://docs.litellm.ai/docs/routing-load-balancing)
- [LiteLLM: Fallbacks](https://docs.litellm.ai/docs/proxy/reliability)
- [Zuplo: Token-Based Rate Limiting for AI Agents](https://zuplo.com/learning-center/token-based-rate-limiting-ai-agents)
- [Nordic APIs: How AI Agents Are Changing Rate Limit Approaches](https://nordicapis.com/how-ai-agents-are-changing-api-rate-limit-approaches/)

### Proven Patterns

**pi-multi-pass (195+ stars, production-proven):**
- Multi-subscription rotation for Anthropic, Codex, Copilot, Gemini
- Automatic rate-limit-triggered switching: when active provider returns a rate limit error and belongs to an enabled pool, automatically switch to next eligible target
- `/subs limits` for on-demand health snapshots
- Pool and chain configuration for ordered fallback
- NOT proactive switching -- only switches on rate limit error

**CCS (Claude Code Switcher):**
- Visual dashboard for multi-account management
- Remote proxy support
- WebSearch fallback
- OpenRouter integration (300+ models)

**LiteLLM proxy (production standard for API routing):**
- Built-in retry/fallback across multiple deployments
- Priority-ordered routing: higher-priority deployments tried first, each order level gets its own set of retries before escalating
- Circuit breaker: 5 consecutive failures marks deployment unhealthy, health checks retry after 60 seconds
- Rate limit (429) specific handling: failed deployment immediately placed on cooldown, if all primary deployments cooling, pick fallback deployments
- Fallback management endpoints (REST API for runtime configuration)
- Cost tracking and budget enforcement (short-term tokens/minute + long-term tokens/month)

**Adaptive rate limiting (emerging):**
Together AI and others rolling out dynamic rate limits that adapt based on live model capacity and past usage patterns. This means static cooldown timers may not be optimal -- the orchestrator should also adapt.

**Best practice for error responses:** When an agent hits a rate limit, the system should provide structured error responses that include the limit, current usage, and reset time. This allows the agent to queue or retry intelligently.

### Gap Analysis vs Stoke

Stoke's `subscriptions/manager.go` already has Acquire/Release with mutex, circuit breaker (3 fails -> 5min cooldown), and utilization tracking. The `subscriptions/usage.go` polls the OAuth usage endpoint. This is ahead of pi-multi-pass (which is reactive-only) and on par with LiteLLM.

**Gaps:**
1. **No proactive utilization-based rotation.** Stoke has the data (OAuth usage polling) but the research suggests rotating BEFORE hitting rate limits, not after. pi-multi-pass only switches reactively. Stoke should rotate at ~80% utilization proactively.
2. **No LiteLLM integration for API-key-based providers.** For non-subscription backends (OpenRouter, direct API), LiteLLM's proxy could handle routing, fallback, and cost tracking more robustly than Stoke's built-in logic.
3. **No adaptive cooldown.** Circuit breaker uses fixed 5-minute cooldown. Provider capacity varies -- adaptive cooldown based on observed recovery times would be more efficient.
4. **No cross-provider budget enforcement.** Track total spend across all providers (subscriptions at estimated cost + API at actual cost) against a session budget.

**Recommendation:**
- MEDIUM PRIORITY: Implement proactive rotation at 80% utilization threshold (Stoke likely already has this or can add it trivially given the OAuth polling infrastructure).
- MEDIUM PRIORITY: Add optional LiteLLM proxy integration for API-key-based providers. Stoke manages subscription pools natively; LiteLLM handles API pools.
- LOW PRIORITY: Adaptive cooldown. Fixed 5-minute cooldown is conservative but functional. Adaptive only matters at very high utilization.
- LOW PRIORITY: Cross-provider budget. Nice for visibility but not a functional gap.

---

## 10. Interactive TUI Dashboards for AI Agent Monitoring

### Sources
- [Ralph TUI: Mission Control Dashboard](https://www.verdent.ai/guides/ralph-tui-ai-agent-dashboard)
- [Agent-Deck: Terminal session manager](https://github.com/asheshgoplani/agent-deck)
- [Bubble Tea v2: Mode 2026](https://github.com/charmbracelet/bubbletea)
- [Vibe Kanban: Orchestrate AI Coding Agents](https://vibekanban.com/)
- [awesome-agent-orchestrators](https://github.com/andyrewlee/awesome-agent-orchestrators)
- [kagent: k9s-inspired agent management TUI](https://github.com/kagent-dev/kagent/issues/1494)

### Proven Patterns

**Three categories of TUI tools in 2026:**

| Category | Tools | Architecture |
|----------|-------|--------------|
| Session multiplexers | Claude Squad, Agent-Deck | tmux panes, one agent per pane, human switches focus |
| Orchestration dashboards | Ralph TUI, Conductor, Superset | Unified view, task board, agent status, keyboard-driven |
| Kanban/visual boards | Vibe Kanban, Claude Agent Teams UI | Web + CLI, drag-and-drop tasks, visual review |

**Ralph TUI design principles (closest to Stoke's TUI):**
- Visibility: see which step the agent is on
- Control: pause, resume, or kill specific tasks
- Recovery: resume after failures without losing state

**Agent-Deck features:**
- Conductors: persistent agent sessions that monitor and orchestrate others
- Auto-respond when confident, escalate when they can't
- One TUI for Claude, Gemini, OpenCode, Codex

**Bubble Tea v2 (2026):**
- Mode 2026: synchronized output specification that reduces screen tearing in modern terminals (Ghostty, etc.)
- Optional but recommended for smooth rendering
- Same Elm Architecture (Model -> Update -> View) that Stoke already uses

**Vibe Kanban (from Bloop, production-grade):**
- Cross-platform CLI + web UI
- Plan tasks, run agents in parallel
- Visual code review using Kanban board
- Supports Claude Code, Codex, and any CLI agent

### Gap Analysis vs Stoke

Stoke's `tui/interactive.go` already implements Dashboard/Focus/Detail modes with Bubble Tea, keyboard nav, and pool bars. The `tui/runner.go` provides headless mode for CI/CD.

**Gaps:**
1. **No Bubble Tea v2 Mode 2026 support.** Synchronized output reduces screen tearing. Worth adopting when upgrading Bubble Tea.
2. **No web UI companion.** Vibe Kanban and Conductor offer web UIs alongside their TUI. Stoke's Ember integration (Phase 3: Remote Progress) will address this.
3. **No Conductor pattern.** Agent-Deck's "conductor" sessions (persistent agents that monitor other agents and auto-respond) is an interesting pattern for fully autonomous operation.
4. **No visual code review in TUI.** Stoke shows diffs but doesn't render them with review annotations inline (Metaswarm's cross-model review comments on specific lines).

**Recommendation:**
- MEDIUM PRIORITY: Upgrade to Bubble Tea v2 with Mode 2026 for smoother rendering.
- LOW PRIORITY: Web UI. Ember integration already planned for this.
- LOW PRIORITY: Conductor pattern. Adds autonomous monitoring but increases complexity. Better to focus on making the TUI informative enough that a human can make decisions quickly.
- FUTURE: Inline review annotations in diff view. Nice polish but not a functional gap.

---

## Competitor Landscape Summary

### Production-Grade Orchestrators (Stoke's direct competitors)

| Tool | Language | Stars | Key Differentiator | Stoke Advantage |
|------|----------|-------|--------------------|-----------------|
| **Metaswarm** | Skills/MD | ~500 | 18 agents, cross-model adversarial review, TDD mandate | Stoke has native Go binary, subscription pool rotation, programmatic failure analysis |
| **Composio Agent Orchestrator** | TypeScript | ~2K | Autonomous CI fix, merge conflict handling, parallel worktrees | Stoke has deterministic phase enforcement, cross-model review, policy engine |
| **Overstory** | TypeScript | ~800 | 11 pluggable runtimes, SQLite mail, tiered conflict resolution | Stoke has more sophisticated failure analysis, wisdom accumulation, TUI |
| **Ruflo** | Skills/MD | ~3K | 60+ agents, WASM agent booster (352x faster for simple transforms) | Stoke has real Go binary, subscription management, deterministic verification |
| **Superset IDE** | TypeScript | ~5K | Agent-agnostic, 10+ parallel agents, built-in review | Stoke has structured workflow enforcement, intelligent retry, cross-model review |
| **Vibe Kanban** | TypeScript | ~4K | Visual Kanban, web + CLI, cross-platform | Stoke has deeper orchestration logic, failure analysis, pool management |
| **OpenCode** | Go | 120K+ | Multi-provider, LSP, plugins, TUI, sessions | Stoke adds deterministic phases, cross-model review, policy engine, pool rotation |

### Key Takeaway

No competitor has all of: deterministic phase enforcement + cross-model adversarial review + structured failure analysis with retry briefs + subscription pool rotation + wisdom accumulation + GRPW scheduling. Stoke's combination is unique.

The closest competitor is **Metaswarm** (cross-model review + structured workflow), but it's a skills/markdown framework on top of Claude Code, not a standalone binary. It cannot manage subscription pools, doesn't have programmatic failure classification, and lacks a TUI.

---

## Top 10 Actionable Recommendations (Prioritized)

### Tier 1: High Impact, Proven Patterns

1. **Add post-task self-reflection for successes (not just failures).**
   After COMMIT, invoke a brief reflection prompt. Feed learnings into wisdom store. Based on Osmani's REFLECTION.md protocol + CodeCoR framework. Proven to improve compound learning.

2. **Validate wisdom accumulation impact with A/B testing.**
   March 2026 research (InfoQ) shows LLM-generated context files hurt performance by 3% and increase costs by 20%. Stoke's wisdom accumulation may be counterproductive. Test empirically before expanding.

3. **Add test coverage delta tracking to verify pipeline.**
   Columbia DAPLab's failure pattern #6 (test quality degradation) is a real production problem. If code changes add 200 lines but tests add 0 meaningful assertions, flag it. Addresses the "80% problem."

4. **Add progressive context disclosure to phase prompts.**
   Start with discovery-level context (file names, summaries). Promote to full content when relevant. Prevents context overload, proven by Manus and OPENDEV.

### Tier 2: Medium Impact, Worth Implementing

5. **Add complexity-based model tiering within task types.**
   Simple renames don't need Opus. Add a complexity estimator (file count, line changes, dependency depth) to route simple tasks to mid-tier models. Could cut costs 40-60%.

6. **Add risk-based review depth.**
   High-risk changes (auth, payments, security) get ensemble review (two models). Low-risk changes get standard review. Based on Metaswarm's adaptive review and ensemble review patterns.

7. **Add oracle-based regression isolation for parallel merges.**
   When a merged worktree causes test failure, bisect by re-running tests with each merge individually. Based on Carlini's GCC trick. Reduces debugging time at scale.

8. **Upgrade to Bubble Tea v2 with Mode 2026.**
   Synchronized output reduces screen tearing. Low effort, meaningful UX improvement.

### Tier 3: Lower Priority, Monitor

9. **Optional SonarQube/Codacy integration in verify pipeline.**
   External static analysis catches patterns that regex scanning misses. Many teams already run these tools. Add as an optional verify stage.

10. **MCP server mode for Codex integration.**
    Cleaner than subprocess management. Better interception of tool calls. Worth considering when Codex's MCP surface stabilizes.

---

## Research Methodology

- 30+ web sources searched across 10 topic areas (April 2026)
- Cross-referenced against Stoke codebase (19 internal packages, 14K lines Go, 206 tests)
- Filtered for PROVEN, STABLE, PRODUCTION patterns only
- Excluded experimental/alpha projects, academic-only work, and hype-cycle tools
- Prioritized findings that address gaps in Stoke's existing architecture
- All source URLs provided for verification

---

## Key Sources

### Industry Analysis & Best Practices
- [Addy Osmani: The Code Agent Orchestra](https://addyosmani.com/blog/code-agent-orchestra/)
- [Addy Osmani: Self-Improving Coding Agents](https://addyosmani.com/blog/self-improving-agents/)
- [Addy Osmani: The 80% Problem in Agentic Coding](https://addyo.substack.com/p/the-80-problem-in-agentic-coding)
- [O'Reilly: Conductors to Orchestrators](https://www.oreilly.com/radar/conductors-to-orchestrators-the-future-of-agentic-coding/)
- [Martin Fowler: Context Engineering for Coding Agents](https://martinfowler.com/articles/exploring-gen-ai/context-engineering-coding-agents.html)
- [Martin Fowler: Harness Engineering](https://martinfowler.com/articles/exploring-gen-ai/harness-engineering.html)

### Research Papers & Reports
- [OPENDEV (arxiv 2603.05344)](https://arxiv.org/abs/2603.05344)
- [OpenAI: Harness Engineering](https://openai.com/index/harness-engineering/)
- [Anthropic: Building a C Compiler with Parallel Claudes](https://www.anthropic.com/engineering/building-c-compiler)
- [Columbia DAPLab: 9 Critical Failure Patterns](https://daplab.cs.columbia.edu/general/2026/01/08/9-critical-failure-patterns-of-coding-agents.html)
- [Zylos Research: Multi-Model AI Code Review](https://zylos.ai/research/2026-02-17-multi-model-ai-code-review)
- [InfoQ: New Research Reassesses AGENTS.md Files](https://www.infoq.com/news/2026/03/agents-context-file-value-review/)

### Production Tools & Frameworks
- [Metaswarm (Sifry)](https://github.com/dsifry/metaswarm)
- [Composio Agent Orchestrator](https://github.com/ComposioHQ/agent-orchestrator)
- [Overstory](https://github.com/jayminwest/overstory)
- [Superset IDE](https://superset.sh)
- [Vibe Kanban](https://vibekanban.com/)
- [pi-multi-pass](https://github.com/hjanuschka/pi-multi-pass)
- [LiteLLM Proxy](https://docs.litellm.ai/)
- [SonarQube Remediation Agent](https://www.sonarsource.com/blog/join-the-sonarqube-remediation-agent-beta)

### Platform Documentation
- [Anthropic Agent Teams Docs](https://code.claude.com/docs/en/agent-teams)
- [OpenAI Codex Subagents](https://developers.openai.com/codex/subagents)
- [OpenAI Codex + Agents SDK](https://developers.openai.com/cookbook/examples/codex/codex_mcp_agents_sdk/building_consistent_workflows_codex_cli_agents_sdk)
- [Microsoft Azure: AI Agent Design Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)
- [SwirlAI: State of Context Engineering 2026](https://www.newsletter.swirlai.com/p/state-of-context-engineering-in-2026)
- [Manus: Context Engineering Lessons](https://manus.im/blog/Context-Engineering-for-AI-Agents-Lessons-from-Building-Manus)

### Context & Market
- [Deloitte: AI Agent Orchestration Predictions](https://www.deloitte.com/us/en/insights/industry/technology/technology-media-and-telecom-predictions/2026/ai-agent-orchestration.html)
- [Chanl: Multi-Agent Patterns in Production](https://www.chanl.ai/blog/multi-agent-orchestration-patterns-production-2026)
- [Faros: Context Engineering for Developers](https://www.faros.ai/blog/context-engineering-for-developers)
