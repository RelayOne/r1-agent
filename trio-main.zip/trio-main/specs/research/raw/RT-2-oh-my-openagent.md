# RT-2: oh-my-openagent (Oh My OpenCode) -- Competitive Research

**Date:** 2026-04-03
**Source:** https://github.com/code-yeongyu/oh-my-openagent
**Default Branch:** dev
**Version at time of analysis:** 3.14.1

---

## 1. What Is It?

**Description:** Oh My OpenAgent (published as `oh-my-opencode`) is an OpenCode plugin that transforms a single-model AI coding assistant into a multi-agent, multi-model orchestration system. It is the most popular plugin in the OpenCode ecosystem with 47,682 GitHub stars and 3,676 forks as of April 2026.

**Purpose:** Provide a batteries-included AI coding harness that:
- Orchestrates multiple AI models (Claude, GPT, Gemini, Kimi, GLM, Minimax, Grok) as specialized agents
- Runs agents in parallel with background task management
- Delivers IDE-grade tooling (LSP, AST-grep) to AI agents
- Ships opinionated defaults so users type one command (`ultrawork`) and get results

**Language:** TypeScript (100% of source), built with Bun runtime

**Size:** 1,268 TypeScript files, approximately 160,000 lines of code. 53MB on disk. Published as an npm package with native platform binaries for 11 targets (darwin-arm64/x64, linux-arm64/x64/musl, windows-x64).

**License:** Sustainable Use License v1.0 (SUL-1.0) -- allows internal business use and non-commercial distribution, but prohibits commercial redistribution. NOT open source by OSI definition.

**Author:** YeonGyu Kim (code-yeongyu). Built with significant AI assistance ("Jobdori" agent). Commercial entity: Sisyphus Labs (sisyphuslabs.ai).

**Created:** December 3, 2025
**Last Updated:** April 3, 2026 (very active development)

---

## 2. Architecture

### High-Level Structure

```
oh-my-openagent/
├── src/
│   ├── index.ts                  # Plugin entry point
│   ├── plugin-config.ts          # JSONC config loader with Zod validation
│   ├── agents/                   # 11 agent definitions
│   ├── hooks/                    # 48 lifecycle hooks
│   ├── tools/                    # 26 tools across 15 directories
│   ├── features/                 # 19 feature modules
│   ├── shared/                   # 95+ utility files
│   ├── config/                   # Zod v4 schema system (24 schema files)
│   ├── cli/                      # CLI: install, run, doctor
│   ├── mcp/                      # 3 built-in remote MCP servers
│   ├── plugin/                   # 8 OpenCode hook handlers
│   └── plugin-handlers/          # 6-phase config loading pipeline
├── packages/                     # 11 platform-specific native binary packages
└── tests/                        # Test fixtures
```

### Initialization Flow

```
OhMyOpenCodePlugin(ctx)
  ├── loadPluginConfig()          # JSONC parse -> project/user merge -> Zod validate -> migrate
  ├── createManagers()            # TmuxSessionManager, BackgroundManager, SkillMcpManager, ConfigHandler
  ├── createTools()               # SkillContext + AvailableCategories + ToolRegistry (26 tools)
  ├── createHooks()               # 3-tier: Core(39) + Continuation(7) + Skill(2) = 48 hooks
  └── createPluginInterface()     # 8 OpenCode hook handlers -> PluginInterface
```

### Plugin Interface (8 OpenCode Hook Handlers)

| Handler                                    | Purpose                                                    |
| ------------------------------------------ | ---------------------------------------------------------- |
| `config`                                   | 6-phase: provider -> plugin-components -> agents -> tools -> MCPs -> commands |
| `tool`                                     | 26 registered tools                                        |
| `chat.message`                             | First-message variant, session setup, keyword detection    |
| `chat.params`                              | Anthropic effort level adjustment                          |
| `chat.headers`                             | Copilot x-initiator header injection                       |
| `event`                                    | Session lifecycle (created, deleted, idle, error)          |
| `tool.execute.before`                      | Pre-tool hooks (file guard, label truncator, rules injector) |
| `tool.execute.after`                       | Post-tool hooks (output truncation, metadata store)        |
| `experimental.chat.messages.transform`     | Context injection, thinking block validation               |

### Key Dependencies

- `@opencode-ai/plugin` + `@opencode-ai/sdk` -- OpenCode plugin API
- `@ast-grep/napi` + `@ast-grep/cli` -- AST-aware code search/rewriting (25 languages)
- `@modelcontextprotocol/sdk` -- MCP protocol support
- `vscode-jsonrpc` -- LSP client communication
- `zod` v4 -- Config schema validation
- `commander` -- CLI framework
- `diff` -- Patch/diff computation
- `picocolors` -- Terminal coloring

---

## 3. Features -- Complete List

### Agent System (11 agents)

| Agent | Default Model | Role |
|-------|--------------|------|
| **Sisyphus** | claude-opus-4-6 | Primary orchestrator. Plans, delegates, verifies. Extended thinking (32k budget). |
| **Hephaestus** | gpt-5.4 | Autonomous deep worker. Goal-oriented, no hand-holding. Inspired by AmpCode's deep mode. |
| **Oracle** | gpt-5.4 | Architecture advisor, debugging consultant. Read-only -- cannot edit or delegate. |
| **Librarian** | minimax-m2.7 | External docs lookup, OSS implementation search. Read-only. |
| **Explore** | grok-code-fast-1 | Fast codebase grep and pattern discovery. Read-only. |
| **Multimodal-Looker** | gpt-5.4 | Visual content analysis (PDFs, images, diagrams). Read-only, single tool (`read`). |
| **Prometheus** | claude-opus-4-6 | Strategic planner. Interview mode. Read-only (markdown in `.sisyphus/` only). |
| **Metis** | claude-opus-4-6 | Plan consultant. Gap analysis before Prometheus writes plans. |
| **Momus** | gpt-5.4 | Plan reviewer. Validates clarity, verifiability, completeness. |
| **Atlas** | claude-sonnet-4-6 | Todo-list conductor. Executes planned tasks systematically. Cannot delegate. |
| **Sisyphus-Junior** | category-dependent | Category-spawned executor. Cannot re-delegate (prevents infinite loops). |

### Category System (8 built-in)

| Category | Default Model | Use Case |
|----------|--------------|----------|
| `visual-engineering` | gemini-3.1-pro | Frontend, UI/UX, design, animation |
| `ultrabrain` | gpt-5.4 (xhigh) | Deep logical reasoning, complex architecture |
| `deep` | gpt-5.4 (medium) | Autonomous research + execution |
| `artistry` | gemini-3.1-pro (high) | Creative/artistic tasks |
| `quick` | gpt-5.4-mini | Trivial tasks, typo fixes |
| `unspecified-low` | claude-sonnet-4-6 | General tasks, low effort |
| `unspecified-high` | claude-opus-4-6 (max) | General tasks, high effort |
| `writing` | gemini-3-flash | Documentation, prose |

### Tools (26 across 15 modules)

- **hashline-edit** -- Hash-anchored file editing (content hash per line prevents stale edits)
- **lsp** -- Full LSP integration: rename, goto-definition, find-references, diagnostics, symbols
- **ast-grep** -- AST-aware search and rewrite across 25 languages
- **interactive-bash** -- Full terminal via tmux (REPLs, debuggers, TUI apps)
- **background-task** -- Launch/monitor/cancel parallel agent sessions
- **delegate-task** -- Category-based agent delegation
- **call-omo-agent** -- Direct named agent invocation
- **session-manager** -- List, read, search, analyze session history
- **skill** -- Skill activation and management
- **skill-mcp** -- Skill-embedded MCP server management
- **slashcommand** -- Slash command execution
- **task** -- Task system tools
- **glob** -- File pattern matching
- **grep** -- Content search
- **look-at** -- Multimodal file viewing
- **shared** -- Common tool utilities

### Hooks (48 lifecycle hooks)

**Core Hooks (39):**
- `todo-continuation-enforcer` -- Yanks idle agents back to incomplete todos
- `context-window-monitor` -- Tracks and warns about context usage
- `session-recovery` -- Auto-recovers from API failures, context limits, JSON errors
- `session-notification` -- Desktop notifications on completion/idle
- `comment-checker` -- Rejects AI-generated code comments (enforces human-quality comments)
- `tool-output-truncator` -- Manages output size
- `directory-agents-injector` -- Auto-loads hierarchical AGENTS.md files
- `directory-readme-injector` -- Auto-loads README.md context
- `think-mode` -- Controls extended thinking behavior
- `model-fallback` -- Automatic model switching on API errors
- `anthropic-context-window-limit-recovery` -- Graceful context overflow handling
- `preemptive-compaction` -- Proactive context compaction before hitting limits
- `rules-injector` -- Injects conditional rules into context
- `background-notification` -- Notifies when background tasks complete
- `auto-update-checker` -- Checks for plugin updates
- `keyword-detector` -- Detects special keywords for routing
- `agent-usage-reminder` -- Reminds about available agents
- `non-interactive-env` -- Adapts for headless/CI environments
- `interactive-bash-session` -- Tmux session management for bash
- `thinking-block-validator` -- Validates extended thinking outputs
- `tool-pair-validator` -- Ensures tool call/result pairing
- `category-skill-reminder` -- Suggests skills for categories
- `ralph-loop` -- Self-referential loop until task is 100% done
- `no-sisyphus-gpt` -- Prevents Sisyphus on GPT models (wrong model for orchestration)
- `no-hephaestus-non-gpt` -- Prevents Hephaestus on non-GPT models
- `auto-slash-command` -- Automatic slash command detection
- `edit-error-recovery` -- Recovers from failed file edits
- `json-error-recovery` -- Recovers from malformed JSON tool outputs
- `delegate-task-retry` -- Retries failed delegations
- `prometheus-md-only` -- Restricts Prometheus to markdown-only output
- `sisyphus-junior-notepad` -- Working memory for junior agents
- `task-resume-info` -- Preserves task state for resumption
- `start-work` -- `/start-work` command handler
- `atlas` -- Atlas orchestrator hook
- `unstable-agent-babysitter` -- Monitors unstable model agents
- `stop-continuation-guard` -- Prevents unnecessary continuations
- `tasks-todowrite-disabler` -- Disables TodoWrite when task system active
- `runtime-fallback` -- Runtime model fallback on errors (400, 429, etc.)
- `write-existing-file-guard` -- Prevents overwriting without reading first
- `bash-file-read-guard` -- Prevents using bash to read files (use read tool instead)
- `hashline-read-enhancer` -- Adds hash annotations to file reads
- `read-image-resizer` -- Optimizes image size for context
- `todo-description-override` -- Customizes todo descriptions
- `webfetch-redirect-guard` -- Prevents infinite redirect chains
- `legacy-plugin-toast` -- Migration warnings
- `anthropic-effort` -- Adjusts reasoning effort levels
- `question-label-truncator` -- Truncates question labels

**Continuation Hooks (7):**
- `compaction-context-injector` -- Preserves context during compaction
- `compaction-todo-preserver` -- Preserves todos during compaction
- `claude-code-hooks` -- Claude Code compatibility hooks

**Skill Hooks (2):**
- Additional skill-specific hook slots

### Skills (6 built-in)

| Skill | Description |
|-------|-------------|
| **git-master** | Atomic commits, rebase surgery, history archaeology. Auto-detects commit style from last 30 commits. |
| **playwright** | Browser automation via Playwright MCP. Screenshots, testing, scraping. |
| **playwright-cli** | Browser automation through Playwright CLI. |
| **agent-browser** | Browser automation via agent-browser CLI. Navigation, snapshots, scripting. |
| **dev-browser** | Stateful browser scripting with persistent page state. |
| **frontend-ui-ux** | Designer-turned-developer persona. Design-first UI/UX without mockups. |

### Built-in MCPs (3)

| MCP | Purpose |
|-----|---------|
| **websearch (Exa)** | Web search integration |
| **context7** | Official documentation lookup |
| **grep_app** | GitHub code search |

### Built-in Commands

Slash commands including: `ultrawork`/`ulw`, `start-work`, `init-deep`, `ulw-loop`, and more via the command template system.

### CLI Features

- `oh-my-opencode install` -- Guided TUI installation
- `oh-my-opencode doctor` -- Diagnostics (plugin registration, config, models, environment)
- `oh-my-opencode run` -- Run agents from CLI
- MCP OAuth management

---

## 4. Unique Capabilities / Novel Design

### Hash-Anchored Editing (Hashline)

The standout innovation. Inspired by oh-my-pi (can1357). Every line the agent reads is tagged with a content hash:

```
11#VK| function hello() {
22#XJ|   return "world";
33#MB| }
```

Implementation:
- Uses xxHash32 for fast hashing
- Hash computed from normalized line content (trimmed, CR-stripped)
- Line number used as seed for whitespace-only lines
- 256-entry hash dictionary (2-character codes)
- Agent references lines by hash tag when editing
- If file changed since last read, hash mismatch rejects the edit before corruption
- Eliminates stale-line errors that plague other coding agents

**Impact claimed:** Grok Code Fast 1 success rate went from 6.7% to 68.3% just from changing the edit tool. This is the single most impactful feature for code editing reliability.

### IntentGate

Before classifying or acting on any user message, the agent performs intent verbalization -- explicitly mapping the surface-level request to the true intent and announcing the routing decision. This prevents literal misinterpretations common with LLMs.

Intent routing map:
| Surface Form | True Intent | Routing |
|---|---|---|
| "explain X" | Research | explore/librarian -> synthesize -> answer |
| "implement X" | Implementation | plan -> delegate or execute |
| "look into X" | Investigation | explore -> report findings |
| "what do you think?" | Evaluation | evaluate -> propose -> WAIT |
| "seeing error X" | Fix needed | diagnose -> fix minimally |
| "refactor" | Open-ended change | assess codebase first -> propose |

### Ralph Loop / ulw-loop

A self-referential execution loop that does not stop until the task is 100% complete. Includes:
- Completion promise detection
- Verification failure handling
- Session recovery within the loop
- Pending verification handler
- Stale timeout detection
- Race condition protection for reset strategies

### Model-Specific Prompt Optimization

The system generates model-specific prompt variants:
- **Gemini models** get: tool mandate, delegation override, verification override, intent gate enforcement, tool guide, tool call examples -- placed in high-attention zones (not prompt end, due to "lost in the middle" phenomenon)
- **GPT-5.4** gets: a separate dedicated prompt builder (`buildGpt54SisyphusPrompt`)
- **GPT models** generally get: `reasoningEffort: "medium"` instead of thinking budget
- **Claude models** get: `thinking: { type: "enabled", budgetTokens: 32000 }`

### Dynamic Agent Prompt Builder

Agent prompts are not static templates. They are dynamically assembled based on:
- Which agents are actually available (not disabled)
- Which tools are registered
- Which skills are loaded
- Which categories are configured
- The specific model being used

This means the Sisyphus orchestrator prompt always reflects the actual system state.

### Anti-Duplication System

Prevents agents from launching redundant explore/librarian searches that overlap with work already done. Ensures efficient parallel execution without wasted tokens.

---

## 5. Control Flow -- Agent Orchestration

### Three Orchestration Modes

1. **Direct prompting** -- Simple tasks, single agent handles it
2. **`ultrawork`/`ulw`** -- One-command activation. Sisyphus orchestrates everything automatically.
3. **`@plan` -> `/start-work`** -- Full planning pipeline: Prometheus interviews user, Metis validates, Momus reviews, Atlas executes.

### Detailed Orchestration Flow

```
User -> Sisyphus (claude-opus-4-6)
  |
  ├── Phase 0: Intent Gate
  │     Every message goes through intent verbalization and classification
  │     (Trivial | Explicit | Exploratory | Open-ended | Ambiguous)
  │
  ├── Phase 1: Codebase Assessment (for open-ended tasks)
  │     Quick assessment -> State classification (Disciplined | Transitional | Legacy | Greenfield)
  │
  ├── Phase 2A: Exploration & Research (parallel)
  │     ├── explore agents (background, parallel) -- internal codebase grep
  │     ├── librarian agents (background, parallel) -- external docs search
  │     └── direct tool usage for known locations
  │
  ├── Phase 2B: Implementation
  │     ├── Create todo list (for 2+ step tasks)
  │     ├── Delegation via category + skills
  │     │     Sisyphus -> task(category="visual-engineering", load_skills=["frontend-ui-ux"])
  │     │              -> Sisyphus-Junior spawned with gemini-3.1-pro + skill context
  │     ├── Session continuity via session_id (saves 70%+ tokens on follow-ups)
  │     └── Verification: lsp_diagnostics on changed files, build/test commands
  │
  ├── Phase 2C: Failure Recovery
  │     After 3 consecutive failures: STOP -> REVERT -> DOCUMENT -> consult Oracle -> ask user
  │
  └── Phase 3: Completion
        All todos done, diagnostics clean, build passes, original request addressed
```

### Planning Pipeline (Prometheus)

```
User describes work
  -> Prometheus interviews (questions, identifies scope, ambiguities)
  -> Explore/Librarian agents gather codebase context (parallel)
  -> Clearance check (objective defined? scope established? no ambiguities?)
  -> Metis gap analysis (hidden intentions, AI-slop patterns, missing criteria)
  -> Write plan to .sisyphus/plans/*.md
  -> [Optional] Momus high-accuracy review loop (OKAY or REJECT)
  -> Guide to /start-work -> Atlas executes plan
```

### Background Agent System

- Agents spawn as separate OpenCode sessions
- Managed by BackgroundManager with concurrency limits per provider/model
- Circuit breaker for error protection
- Loop detection to prevent infinite spawning
- Task history tracking
- Session status classification (active, idle, complete, error)
- Polling system for status updates
- Compaction-aware message resolution

### Delegation Model

Sisyphus delegates by **category**, not by model name:

```typescript
task(category="visual-engineering", load_skills=["frontend-ui-ux"], 
     prompt="...", run_in_background=false)
```

The category maps to the right model automatically. Custom categories are fully supported.

---

## 6. Quality Assurance -- How It Verifies Agent Output

### Multi-Layer Verification

1. **Hash-Anchored Edits** -- Every file edit is validated against content hashes. Stale edits are rejected before they corrupt files.

2. **LSP Diagnostics** -- After every logical task unit, changed files are checked via LSP for type errors, lint issues, etc.

3. **Comment Checker** -- External tool (`@code-yeongyu/comment-checker`) rejects AI-generated comments. Enforces human-quality code commentary.

4. **Todo Continuation Enforcer** -- If an agent goes idle with incomplete todos, the system injects a reminder and forces continuation. Includes:
   - Stagnation detection
   - Compaction guard (prevents loss during context compaction)
   - Pending question detection
   - Abort detection
   - Session state tracking

5. **Unstable Agent Babysitter** -- Monitors agents on unstable models (auto-enabled for Gemini/Minimax). Forces background mode for monitoring.

6. **Momus Plan Review** -- For high-accuracy mode, plans must pass:
   - 100% file references verified
   - >= 80% tasks have clear reference sources
   - >= 90% tasks have concrete acceptance criteria
   - Zero tasks require business logic assumptions
   - Zero critical red flags

7. **Build/Test Verification** -- After task completion, build commands and test suites are run. Exit code 0 required.

8. **Evidence Requirements** (task NOT complete without):
   - File edit -> `lsp_diagnostics` clean
   - Build command -> Exit code 0
   - Test run -> Pass
   - Delegation -> Agent result received and verified

9. **Tool-Pair Validator** -- Ensures every tool call has a corresponding result.

10. **Thinking Block Validator** -- Validates extended thinking outputs from Claude.

### Error Recovery Hooks

- `session-recovery` -- Auto-recovers from missing tool results, thinking block violations, empty messages, context window limits, JSON parse errors
- `edit-error-recovery` -- Recovers from failed file edits
- `json-error-recovery` -- Recovers from malformed tool outputs
- `delegate-task-retry` -- Retries failed delegations
- `runtime-fallback` -- Switches to fallback model on API errors (400, 429)
- `anthropic-context-window-limit-recovery` -- Handles context overflow gracefully

---

## 7. Hook/Plugin System -- Extensibility Points

### Plugin Architecture

The system is itself a plugin for OpenCode (the Claude Code fork). It implements 8 OpenCode hook handlers that intercept every phase of the AI agent lifecycle:

- **config** -- 6-phase initialization pipeline
- **tool** -- Tool registration
- **chat.message** -- Message interception
- **chat.params** -- Parameter modification
- **chat.headers** -- Header injection
- **event** -- Session lifecycle events
- **tool.execute.before/after** -- Pre/post tool execution

### Hook System (48 hooks)

Hooks are organized in 3 tiers:
1. **Core hooks** (39) -- Essential functionality
2. **Continuation hooks** (7) -- Context preservation across compaction
3. **Skill hooks** (2) -- Skill-specific behavior

All hooks are individually disableable via `disabled_hooks` config array. Each hook is a standalone module in `src/hooks/{name}/` with its own AGENTS.md documentation.

Hook creation is wrapped in try/catch by default (`experimental.safe_hook_creation`) to prevent one failing hook from crashing the entire plugin.

### Skill System

Skills are the primary extensibility mechanism:

**What a skill provides:**
- Domain-tuned system instructions (prompt context)
- Embedded MCP servers that spin up on-demand
- Scoped permissions (agents stay in bounds)

**Built-in skill locations:**
- `src/features/builtin-skills/skills/` -- System-provided skills
- `.opencode/skills/*/SKILL.md` -- Project-level custom skills
- `~/.config/opencode/skills/*/SKILL.md` -- User-level custom skills

Skills are loaded and merged at plugin initialization via `createSkillContext()`.

### MCP Integration

- 3 built-in remote MCPs (websearch, context7, grep_app)
- Skill-embedded MCPs (spin up on demand, gone when done -- saves context budget)
- Full MCP OAuth support for authenticated services
- Claude Code MCP compatibility layer

### Claude Code Compatibility

Full backward compatibility with Claude Code ecosystem:
- Hooks
- Commands
- Skills
- MCPs
- Plugins
- `claude-code-hooks`, `claude-code-agent-loader`, `claude-code-command-loader`, `claude-code-mcp-loader`, `claude-code-plugin-loader`, `claude-code-session-state` feature modules

### Custom Commands

Template-based command system in `src/features/builtin-commands/templates/`. Commands are registered via the `commands` configuration.

---

## 8. Configuration System

### Config Locations (priority order)

1. **Project config:** `.opencode/oh-my-openagent.json[c]` (or legacy `.opencode/oh-my-opencode.json[c]`)
2. **User config:** `~/.config/opencode/oh-my-openagent.json[c]` (or legacy)

Project config overrides user config. Both JSONC formats supported (comments, trailing commas).

### Config Merge Strategy

- `agents`, `categories`, `claude_code` -- Deep merged recursively
- `disabled_*` arrays -- Set union (concatenated + deduplicated)
- All other fields -- Override replaces base value

### Schema Validation

Full Zod v4 schema validation with 24 schema files covering:

| Config Section | Controls |
|---------------|----------|
| `agents` | Per-agent model, prompt, temperature, permissions, fallbacks |
| `categories` | Category model assignments, descriptions, tool restrictions |
| `disabled_hooks/agents/skills/commands/tools/mcps` | Granular feature toggling |
| `hashline_edit` | Enable hash-anchored editing (default: false) |
| `model_fallback` | Enable automatic model switching on errors |
| `ralph_loop` | Self-referential loop configuration |
| `background_task` | Concurrency limits per provider/model, circuit breaker |
| `notification` | Desktop notification settings |
| `tmux` | Tmux integration and layout |
| `skills` | Skill configuration |
| `comment_checker` | Comment quality enforcement |
| `experimental` | Aggressive truncation, auto-resume, preemptive compaction, max tools |
| `runtime_fallback` | Runtime model switching on specific error codes |
| `babysitting` | Unstable agent monitoring |
| `git_master` | Commit footer, co-authored-by |
| `browser_automation_engine` | Browser automation provider selection |
| `websearch` | Web search configuration |
| `sisyphus` | Sisyphus-specific configuration |
| `start_work` | Planning pipeline configuration |
| `model_capabilities` | Model-specific capability declarations |
| `openclaw` | OpenClaw integration |

### Partial Config Loading

Invalid config sections are gracefully skipped -- the plugin loads what it can and logs warnings about invalid sections. This prevents a single typo from breaking the entire plugin.

### Migration System

Config files are auto-migrated for version upgrades. Migration history tracked in `_migrations` array to prevent re-applying.

### Environment Variables

- `OPENCODE_DEFAULT_AGENT` -- Default agent for CLI run
- Provider-specific API keys
- Various internal flags

---

## 9. Multi-Model Support

### Supported Providers and Models

The system is designed from the ground up for multi-model orchestration. Each agent has a curated default model and a fallback chain:

**Provider Support:**
- Anthropic (Claude Opus 4.6, Claude Sonnet 4.6, Claude Haiku 4.5)
- OpenAI (GPT-5.4, GPT-5.4-mini, GPT-5-nano, GPT-5.3-codex)
- Google (Gemini 3.1 Pro, Gemini 3 Flash)
- Moonshot/Kimi (Kimi K2.5)
- ZhipuAI (GLM-5, GLM-4.6v)
- MiniMax (M2.7, M2.7-highspeed)
- xAI (Grok Code Fast 1)
- GitHub Copilot (as proxy)
- OpenCode proxy
- Ollama
- OpenRouter
- AiHubMix
- Custom LiteLLM proxies

### Model-Specific Adaptations

The codebase contains explicit model detection and adaptation:

```typescript
isGptModel(model)          // All GPT variants
isGpt5_4Model(model)       // GPT-5.4 specifically
isGpt5_3CodexModel(model)  // GPT-5.3 Codex
isGeminiModel(model)       // All Gemini variants (google/, google-vertex/, github-copilot/gemini-*)
isMiniMaxModel(model)      // MiniMax variants
isGlmModel(model)          // GLM variants
```

Prompt construction varies by model family:
- Claude: XML-tagged structure, extended thinking with budget
- GPT: Separate prompt builder, reasoning effort instead of thinking budget
- Gemini: Extra enforcement sections placed in high-attention zones (not at prompt end)

### Fallback Chain System

Per-agent fallback chains with mixed string/object entries:

```jsonc
"fallback_models": [
  "opencode/glm-5",                                               // Simple string
  { "model": "openai/gpt-5.4", "variant": "high" },              // With variant
  { "model": "anthropic/claude-sonnet-4-6",                       // With thinking config
    "thinking": { "type": "enabled", "budgetTokens": 64000 } }
]
```

Runtime fallback triggers on API errors (400, 429, timeouts). The system attempts each fallback in order.

### Model Capability System

- Model capabilities are tracked and cached
- Available models are fetched and compared against connected providers
- First-run handling when no cache exists
- CLI `doctor` command includes model resolution checks
- `refresh-model-capabilities` for updating capability data

---

## 10. Session Management

### Session Lifecycle

Sessions are managed through OpenCode's session system with significant enhancements:

- **Session creation** -- Event handler sets up initial state, context injection
- **Session messages** -- First-message variant gate, keyword detection, session setup
- **Session idle** -- Notification scheduling, todo continuation enforcement
- **Session error** -- Recovery hooks, model fallback
- **Session deletion** -- Cleanup of background agents, tmux panes, MCP connections

### Session Recovery System

Automatic recovery from multiple failure modes:
- Missing tool results -- Reconstructs recoverable tool state, skips invalid IDs
- Thinking block violations -- Recovers from API thinking block mismatches
- Empty messages -- Reconstructs message history
- Context window limits -- Graceful compaction
- JSON parse errors -- Recovers from malformed outputs
- Unavailable tools -- Handles missing tool references

Recovery storage tracks: detection, attempts, and outcomes per session.

### Session Continuity

Background task sessions preserve full conversation context via `session_id`:
- Subagent resumes with full prior conversation
- No repeated file reads or setup
- Claimed 70%+ token savings on follow-ups
- System explicitly mandates session_id usage for all task continuations

### Context Window Management

- **Context window monitor** -- Tracks token usage
- **Preemptive compaction** -- Compacts context before hitting model limits, with degradation monitoring and AWS Bedrock support
- **Compaction context injector** -- Preserves essential context through compaction
- **Compaction todo preserver** -- Preserves todo state through compaction
- **Dynamic context pruning** -- Configurable pruning strategies
- **Aggressive truncation** (experimental) -- More aggressive output trimming

### Session Tools

The session-manager tool provides:
- List sessions
- Read session messages
- Search session history
- Analyze session patterns
- Session formatter for readable output

### Run Continuation State

Feature module that tracks continuation state across runs, enabling task resumption after interruption.

---

## 11. UI/UX

### Primary Interface: TUI (Terminal UI)

Oh My OpenAgent operates as a plugin within OpenCode, which provides the TUI. The plugin enhances it with:

- **Agent tab cycling** -- Deterministic tab order (Sisyphus: 1, Hephaestus: 2, Prometheus: 3, Atlas: 4)
- **Color-coded agents** -- Each agent has a distinct UI color (Sisyphus: #00CED1 turquoise)
- **Desktop notifications** -- Session completion/idle notifications (macOS, Linux, Windows supported)
- **Sound notifications** -- Platform-specific notification sounds

### Tmux Integration

When `tmux.enabled` is true:
- Background agents spawn in separate tmux panes
- Real-time visibility into multiple parallel agents
- Grid layout planning for pane arrangement
- Pane state parsing and querying
- Zombie pane detection and cleanup
- Session-created event handling
- Configurable layouts (main-vertical, grid, etc.)

### CLI Interface

- `oh-my-opencode install` -- Guided TUI installation with prompts
- `oh-my-opencode doctor` -- Comprehensive diagnostics
- `oh-my-opencode run` -- Headless agent execution

### One-Command UX (`ultrawork`/`ulw`)

The flagship UX innovation: a single command that activates all agents and drives the task to completion. The user types `ultrawork` and walks away.

### Internationalization

README available in 4 languages: English, Korean, Japanese, Chinese (Simplified).

---

## 12. Security Model

### Tool Restrictions by Agent

Strict permission boundaries per agent:

| Agent | Restrictions |
|-------|-------------|
| Oracle | Read-only: blocked from write, edit, task, call_omo_agent |
| Librarian | Read-only: blocked from write, edit, task, call_omo_agent |
| Explore | Read-only: blocked from write, edit, task, call_omo_agent |
| Multimodal-Looker | Allowlist: `read` only |
| Atlas | Cannot delegate: blocked from task, call_omo_agent |
| Momus | Read-only: blocked from write, edit, task |
| Sisyphus-Junior | Cannot re-delegate (prevents infinite delegation loops) |

### Permission System

Per-agent, per-tool permission control:

```json
{
  "permission": {
    "edit": "ask",        // ask | allow | deny
    "bash": "allow",      // or per-command: { "git": "allow", "rm": "deny" }
    "webfetch": "deny",
    "doom_loop": "deny",
    "external_directory": "ask"
  }
}
```

### Sandboxing and Isolation

- **Delegation loop prevention** -- Sisyphus-Junior cannot re-delegate, preventing infinite recursion
- **Background agent isolation** -- Each background agent runs in a separate OpenCode session
- **Tmux pane isolation** -- Visual separation of parallel agents
- **MCP environment cleaning** -- Environment variable sanitization for MCP connections
- **Write-existing-file guard** -- Prevents file overwrites without prior read
- **Bash-file-read guard** -- Forces agents to use the read tool instead of bash cat/head
- **WebFetch redirect guard** -- Prevents infinite redirect chains
- **Stop continuation guard** -- Prevents unnecessary agent continuations
- **Circuit breaker** -- Background task manager includes circuit breaker for error protection

### No Process Sandboxing

Importantly, there is no OS-level sandboxing (no containers, no seccomp, no chroot). All agents run with the same filesystem and process permissions as the parent OpenCode process. Security is enforced at the tool/permission layer only.

---

## 13. Competitive Analysis -- Implications for Trio

### Strengths to Learn From

1. **Hash-anchored editing is the killer feature.** The Hashline system eliminates the #1 failure mode of AI coding agents (stale line references). This is worth studying closely -- the implementation is clean (xxHash32, 256-entry dictionary, 2-char codes). Consider whether Trio's edit system could benefit from a similar approach.

2. **Category-based delegation** is more elegant than model-based delegation. The agent says "this is visual-engineering work" and the system picks the right model. This decouples intent from model selection.

3. **Dynamic prompt assembly** based on actual system state is sophisticated. The Sisyphus prompt is not a static template -- it reflects which agents are available, which tools are loaded, which skills are active.

4. **Model-specific prompt optimization** is production-tested. They have separate prompt builders for GPT, Gemini, and Claude, with Gemini getting special attention placement due to "lost in the middle" issues.

5. **The planning pipeline** (Prometheus -> Metis -> Momus -> Atlas) is a well-designed separation of concerns: interview, gap analysis, review, execution.

6. **48 hooks** covering every lifecycle phase is comprehensive. The granularity of control is impressive.

7. **Session continuity via session_id** for background agents is a practical token-saving technique.

### Weaknesses / Gaps

1. **No OS-level sandboxing.** All agents share the same process permissions. Security is entirely at the tool permission layer.

2. **Massive complexity.** 160K LOC, 1,268 files, 48 hooks, 26 tools, 11 agents. The cognitive overhead for contributors is enormous.

3. **Tight coupling to OpenCode.** The plugin is designed specifically for the OpenCode fork of Claude Code. Not portable.

4. **License is restrictive.** SUL-1.0 prohibits commercial redistribution. Cannot be used in commercial products without separate licensing.

5. **Single-developer risk.** The primary contributor is code-yeongyu, with an AI bot (sisyphus-dev-ai) as the second contributor. Bus factor is 1.

6. **No structured output verification.** QA is based on LSP diagnostics and comment checking, but there is no formal assertion framework for agent output correctness.

7. **Heavy prompt engineering.** The Sisyphus prompt alone is thousands of tokens of detailed instructions. This is fragile -- model behavior updates could break assumptions.

### Ideas Worth Stealing

| Feature | Priority for Trio | Effort | Notes |
|---------|------------------|--------|-------|
| Hash-anchored editing | HIGH | Medium | Core edit reliability improvement |
| Intent verbalization before routing | HIGH | Low | Simple prompt technique, big impact |
| Category-based delegation | MEDIUM | Medium | Cleaner than model-name routing |
| Dynamic prompt assembly | MEDIUM | High | Reflects actual system state |
| Todo continuation enforcer | MEDIUM | Low | Prevents agent idle drift |
| Comment checker hook | LOW | Low | Nice-to-have quality gate |
| Session continuity (session_id) | HIGH | Medium | Major token savings |
| Model-specific prompt variants | MEDIUM | Medium | Per-model optimization |
| Preemptive compaction | MEDIUM | Medium | Prevents context overflow |
| Background agent concurrency limits | LOW | Low | Already partially implemented |

---

## 14. Key Metrics Summary

| Metric | Value |
|--------|-------|
| GitHub Stars | 47,682 |
| Forks | 3,676 |
| Open Issues | 414 |
| Language | TypeScript (Bun runtime) |
| LOC | ~160,000 |
| Files | 1,268 |
| Agents | 11 |
| Hooks | 48 |
| Tools | 26 |
| Skills | 6 built-in |
| MCPs | 3 built-in |
| Categories | 8 built-in |
| Config Schema Files | 24 |
| Platform Binaries | 11 |
| Version | 3.14.1 |
| License | SUL-1.0 (not OSI open source) |
| Primary Contributor | code-yeongyu |
| Created | 2025-12-03 |
| Active Development | Yes (last update: today) |

---

*Research conducted 2026-04-03 from GitHub API, README, source code, and documentation.*
