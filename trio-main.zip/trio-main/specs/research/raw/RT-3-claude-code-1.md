# RT-3: claude-code-1 (Anthropic Official Claude Code) -- Competitive Research

**Source:** https://github.com/code-yeongyu/claude-code-1
**Date:** 2026-04-03
**Status:** Complete

---

## 1. What Is It?

**Description:** This is a near-complete mirror of Anthropic's official Claude Code repository (originally at `anthropics/claude-code`). Claude Code is Anthropic's agentic coding tool -- a CLI/IDE agent that lives in the terminal, understands codebases, and performs development tasks through natural language commands.

**Key Facts:**
- **Primary Language:** Shell (plugin system), Python (hooks), Markdown (commands/agents/skills)
- **Runtime:** Node.js 18+ (core binary is `@anthropic-ai/claude-code` npm package, now also distributed via native installers)
- **Repo Size:** ~27 MB (mostly documentation, plugins, and workflow configs -- the actual binary is distributed as a compiled npm package)
- **License:** Proprietary -- "Anthropic PBC. All rights reserved. Use is subject to Commercial Terms of Service."
- **Created:** 2026-03-31
- **Version at time of research:** 2.1.87 (based on CHANGELOG)
- **No source code exposed:** The core agent binary is a compiled/bundled npm package. This repo exposes only the plugin ecosystem, examples, CI workflows, and issue templates.

**Critical Insight:** This is NOT an open-source codebase. The repo is a plugin/extension ecosystem around a closed-source binary. The actual orchestration engine, tool dispatch, model interaction, and session management code is inside the compiled `@anthropic-ai/claude-code` npm package (or native installers). What we can study is the plugin architecture, hook system, and the prompt engineering patterns in the plugins.

---

## 2. Architecture

### 2.1 Repository Structure

```
.
├── .claude-plugin/marketplace.json    # Plugin marketplace registry
├── .claude/commands/                  # Repo-level slash commands (triage-issue, dedupe)
├── .devcontainer/                     # Docker sandbox environment
├── .github/workflows/                 # 12+ GitHub Action workflows
├── examples/                          # Settings presets & hook examples
├── plugins/                           # 13 official plugins (the main content)
│   ├── agent-sdk-dev/                # Agent SDK development kit
│   ├── claude-opus-4-5-migration/    # Model migration tool
│   ├── code-review/                  # Multi-agent PR review
│   ├── commit-commands/              # Git workflow automation
│   ├── explanatory-output-style/     # Output style plugin
│   ├── feature-dev/                  # 7-phase feature development
│   ├── frontend-design/              # Frontend design guidance
│   ├── hookify/                      # User-configurable hook system
│   ├── learning-output-style/        # Interactive learning mode
│   ├── plugin-dev/                   # Plugin development toolkit
│   ├── pr-review-toolkit/            # 6-agent PR review suite
│   ├── ralph-wiggum/                 # Self-referential iteration loops
│   └── security-guidance/            # Security pattern detection
└── scripts/                           # CI/automation scripts (TS)
```

### 2.2 Plugin Architecture

Each plugin follows a standardized structure:

```
plugin-name/
├── .claude-plugin/plugin.json     # Manifest (name, version, description, author)
├── commands/                      # Slash commands (Markdown with YAML frontmatter)
├── agents/                        # Subagent definitions (Markdown with frontmatter)
├── skills/                        # Auto-activated skills (SKILL.md per skill)
│   └── skill-name/SKILL.md
├── hooks/hooks.json               # Event handler configuration
├── .mcp.json                      # MCP server definitions (optional)
└── scripts/                       # Helper scripts
```

**Auto-discovery:** Claude Code scans standard directories for components. No registration code needed -- drop a `.md` file in `commands/` and it becomes a slash command.

**Portable paths:** All intra-plugin references use `${CLAUDE_PLUGIN_ROOT}` environment variable for cross-platform portability.

### 2.3 Component Types

| Component | Format | Discovery | Purpose |
|-----------|--------|-----------|---------|
| Commands | Markdown + YAML frontmatter | Auto (commands/*.md) | User-invoked slash commands |
| Agents | Markdown + YAML frontmatter | Auto (agents/*.md) | Specialized subagent definitions |
| Skills | SKILL.md in subdirectory | Auto (skills/*/SKILL.md) | Auto-activated contextual knowledge |
| Hooks | JSON config + scripts | hooks/hooks.json | Event-driven automation |
| MCP Servers | JSON config | .mcp.json | External tool integration |

---

## 3. Features -- Complete List

### 3.1 Core Agent Capabilities (from CHANGELOG/README)
- Natural language coding in terminal
- Codebase understanding and navigation
- Code generation, modification, and refactoring
- Git workflow management (commit, push, PR)
- Multi-file editing
- Web search and fetch
- Session persistence and resume (`--resume`)
- Context compaction (PreCompact hook event)
- Multi-session support (parallel instances)
- Model selection (`/model` command, `--model` flag)
- `--bare` mode for programmatic use
- Notebook support (read/edit Jupyter notebooks)
- MCP (Model Context Protocol) integration
- GitHub integration (issues, PRs, comments via `@claude`)
- IDE integration (VS Code extension)
- Cowork Dispatch (multi-session coordination, referenced in v2.1.87)
- Ultra-think hint support

### 3.2 Plugin Ecosystem (13 Official Plugins)

1. **agent-sdk-dev** -- Agent SDK development kit with `/new-sdk-app` command and verification agents
2. **claude-opus-4-5-migration** -- Automated migration of model strings, beta headers, prompts to Opus 4.5
3. **code-review** -- Multi-agent PR review with 5 parallel Sonnet agents, confidence scoring, inline GitHub comments
4. **commit-commands** -- `/commit`, `/commit-push-pr`, `/clean_gone` -- streamlined git operations
5. **explanatory-output-style** -- SessionStart hook injecting educational context about implementation choices
6. **feature-dev** -- 7-phase guided development: Discovery, Codebase Exploration, Clarifying Questions, Architecture Design, Implementation, Quality Review, Summary
7. **frontend-design** -- Auto-activated skill for distinctive, production-grade UI design
8. **hookify** -- User-configurable hook creation from conversation analysis or explicit instructions
9. **learning-output-style** -- Interactive learning mode requesting user code contributions at decision points
10. **plugin-dev** -- 7 expert skills for building plugins: hook dev, MCP integration, commands, agents, skills, settings, structure
11. **pr-review-toolkit** -- 6 specialized review agents: comment-analyzer, pr-test-analyzer, silent-failure-hunter, type-design-analyzer, code-reviewer, code-simplifier
12. **ralph-wiggum** -- Self-referential iteration loops with completion promises
13. **security-guidance** -- PreToolUse hook monitoring 9 security patterns (command injection, XSS, eval, pickle, os.system, etc.)

### 3.3 CI/Automation Workflows
- `claude.yml` -- @claude mentions in issues/PRs trigger Claude Code Action
- `claude-issue-triage.yml` -- Automated issue labeling via Claude with `/triage-issue` command
- `claude-dedupe-issues.yml` -- Duplicate issue detection via parallel search agents
- `sweep.yml` -- Automated sweep operations
- `auto-close-duplicates.yml` -- Auto-close confirmed duplicates
- `lock-closed-issues.yml` -- Lock stale closed issues
- `issue-lifecycle-comment.yml` -- Lifecycle management comments
- `non-write-users-check.yml` -- Permission verification

---

## 4. Unique Capabilities / Novel Design

### 4.1 Prompt-as-Code Architecture

The most distinctive design pattern is **Markdown-as-agent-definition**. Agents, commands, and skills are all defined as Markdown files with YAML frontmatter. This means:
- Agent behavior is version-controlled and diffable
- Non-developers can read and modify agent prompts
- No compilation step -- drop a file and it works
- Frontmatter controls model selection, tool access, color coding

Example agent frontmatter:
```yaml
---
name: code-reviewer
description: [trigger conditions and examples]
model: opus
color: green
---
[System prompt for the agent]
```

### 4.2 Ralph Wiggum -- Self-Referential Agent Loops

This is the most novel plugin. It creates an autonomous iteration loop where:
1. User provides a task and optional completion promise
2. Claude works on the task
3. When Claude tries to stop, the Stop hook intercepts
4. The hook reads the transcript, checks for a `<promise>` tag
5. If the promise statement is not found (or is false), it feeds the SAME prompt back
6. The agent sees its previous work in files/git and iterates

**Key design elements:**
- State tracked in `.claude/ralph-loop.local.md` (YAML frontmatter + prompt body)
- Strict anti-lying enforcement: "ONLY output completion promise when TRUE -- do not lie to exit"
- Max iteration safety valve
- Iteration counter in state file
- Reads transcript via JSONL parsing for last assistant message

**Relevance to Trio:** This is essentially a built-in retry/iterate loop pattern. Our wisdom accumulation system could learn from this -- particularly the completion promise concept.

### 4.3 Multi-Agent Orchestration Patterns

The code-review plugin demonstrates sophisticated parallel agent dispatch:
1. Haiku agent pre-screens (is PR draft? already reviewed?)
2. Haiku agent maps CLAUDE.md files
3. Sonnet agent summarizes changes
4. 4 agents in parallel (2 Sonnet for CLAUDE.md compliance, 2 Opus for bugs)
5. Parallel validation agents verify each finding (reduces false positives)
6. Confidence filtering (only report issues >= 80/100 confidence)
7. Optional inline GitHub comments with suggestionable fixes

This is a **fanout-validate-filter** pattern -- worth studying.

### 4.4 Hookify -- User-Configurable Rule Engine

The hookify plugin is a meta-plugin that lets users create hooks without writing code:
- Rules defined as `.claude/hookify.*.local.md` Markdown files
- Custom YAML frontmatter parser (no external YAML library needed)
- Rule conditions support: `regex_match`, `contains`, `equals`, `not_contains`, `starts_with`, `ends_with`
- Rules can target specific tools via `tool_matcher`
- Actions: `warn` (show message, allow) or `block` (deny operation)
- Works on all hook events: PreToolUse, PostToolUse, Stop, UserPromptSubmit
- Cached regex compilation with `@lru_cache(maxsize=128)`

### 4.5 Feature-Dev 7-Phase Methodology

The feature-dev plugin encodes a complete development methodology:
1. **Discovery** -- Understand requirements, create todo list
2. **Codebase Exploration** -- Launch 2-3 parallel code-explorer agents
3. **Clarifying Questions** -- Explicitly marked CRITICAL phase, cannot skip
4. **Architecture Design** -- 2-3 parallel code-architect agents with different focuses
5. **Implementation** -- Requires explicit user approval
6. **Quality Review** -- 3 parallel code-reviewer agents
7. **Summary** -- Document what was built

Uses three specialized agents: code-explorer (analysis), code-architect (design), code-reviewer (quality). Each agent outputs lists of key files to read, creating a knowledge accumulation pattern.

---

## 5. Control Flow -- Agent Orchestration

### 5.1 Agent Dispatch Model

Claude Code uses a **Task-based subagent dispatch** model:
- The main agent (Claude) dispatches subagents via the `Task` tool
- Subagents are defined as Markdown files specifying role, model, tools, and system prompt
- Subagents can be launched in parallel (multiple Task calls in one turn)
- Each subagent has limited tool access (specified in frontmatter `tools:` and command `allowed-tools:`)

### 5.2 Model Routing

Agents specify their model tier in frontmatter:
- `model: opus` -- For deep analysis, bug detection, architecture decisions
- `model: sonnet` -- For routine tasks, exploration, CLAUDE.md compliance
- `model: haiku` -- For quick screening, pre-checks, simple lookups
- `model: inherit` -- Use parent agent's model

This enables **cost-optimized orchestration**: expensive Opus for high-value decisions, cheap Haiku for screening.

### 5.3 Tool Access Control

Commands and agents declare allowed tools:
```yaml
allowed-tools: ["Bash", "Glob", "Grep", "Read", "Task"]
```

Some commands restrict even Bash to specific patterns:
```yaml
allowed-tools: Bash(git add:*), Bash(git status:*), Bash(git commit:*)
```

This provides fine-grained sandboxing of what each agent can do.

### 5.4 Hook-Based Event Flow

The lifecycle hook events form a control flow pipeline:
```
SessionStart -> UserPromptSubmit -> PreToolUse -> [Tool Execution] -> PostToolUse -> ... -> Stop
```

Each event can:
- **Allow** -- Proceed normally
- **Block** -- Prevent the action
- **Modify** -- Alter tool inputs (`updatedInput` in PreToolUse)
- **Inject context** -- Add `systemMessage` visible to Claude

Multiple hooks at the same event run in **parallel** (not sequential), and any blocking hook wins.

---

## 6. Quality Assurance

### 6.1 Confidence-Based Filtering

The code-review plugin uses a 0-100 confidence scoring system:
- **0-25:** Likely false positive
- **26-50:** Minor nitpick
- **51-75:** Valid but low-impact
- **76-90:** Important issue
- **91-100:** Critical bug or explicit rule violation
- **Threshold:** Only report issues >= 80 confidence

### 6.2 Multi-Stage Validation Pipeline

Code-review implements a multi-stage pipeline to reduce false positives:
1. **Detection** -- Multiple agents independently find issues
2. **Validation** -- Separate agents verify each issue is real
3. **Filtering** -- Remove unvalidated issues
4. **Reporting** -- Only high-signal issues reach the user

Explicit false positive list in prompt:
- Pre-existing issues
- Pedantic nitpicks
- Issues a linter would catch
- General quality concerns unless in CLAUDE.md
- Issues explicitly silenced in code

### 6.3 Feature-Dev Quality Gate

The feature-dev plugin has a mandatory quality review phase (Phase 6) with three parallel reviewer agents focusing on:
- Simplicity / DRY / elegance
- Bugs / functional correctness
- Project conventions / abstractions

### 6.4 Ralph-Wiggum Iteration Verification

The completion promise system provides quality verification:
- Agent cannot exit until a factual statement is true
- Anti-lying instructions prevent premature completion claims
- Forces the agent to actually complete the work before stopping

---

## 7. Hook/Plugin System -- Extensibility

### 7.1 Hook Events (9 Total)

| Event | When | Capabilities |
|-------|------|-------------|
| PreToolUse | Before any tool | Allow/deny/modify tool input |
| PostToolUse | After tool completes | Feedback, logging, react to results |
| Stop | Main agent stopping | Block exit, verify completeness |
| SubagentStop | Subagent stopping | Validate subagent task completion |
| UserPromptSubmit | User submits prompt | Add context, validate, block |
| SessionStart | Session begins | Load context, set env vars |
| SessionEnd | Session ends | Cleanup, state preservation |
| PreCompact | Before compaction | Preserve critical context |
| Notification | User notified | React to notifications |

### 7.2 Hook Types

1. **Command Hooks** -- Execute shell commands (deterministic, fast)
2. **Prompt Hooks** -- LLM-driven decisions (context-aware, flexible) -- available for Stop, SubagentStop, UserPromptSubmit, PreToolUse

### 7.3 Plugin Marketplace

The marketplace uses a `marketplace.json` schema:
```json
{
  "$schema": "https://anthropic.com/claude-code/marketplace.schema.json",
  "plugins": [
    {
      "name": "plugin-name",
      "description": "...",
      "source": "./plugins/plugin-name",
      "category": "development|productivity|security|learning"
    }
  ]
}
```

Categories: development, productivity, security, learning.

### 7.4 Plugin Settings

Three-level settings hierarchy:
1. **Enterprise managed settings** -- Org-wide policies (cannot be overridden)
2. **User settings** -- `~/.claude/settings.json`
3. **Project settings** -- `.claude/settings.json`

Enterprise settings can enforce:
- `disableBypassPermissionsMode` -- Prevent `--dangerously-skip-permissions`
- `allowManagedPermissionRulesOnly` -- Block user/project permission rules
- `allowManagedHooksOnly` -- Block user/project hooks
- `strictKnownMarketplaces` -- Restrict plugin sources

### 7.5 MCP Integration

Plugins can define MCP (Model Context Protocol) servers:
```json
{
  "mcpServers": {
    "server-name": {
      "command": "node",
      "args": ["${CLAUDE_PLUGIN_ROOT}/servers/server.js"],
      "env": { "API_KEY": "${API_KEY}" }
    }
  }
}
```

MCP servers support stdio, SSE, and HTTP transport types.

---

## 8. Configuration System

### 8.1 Settings Presets

Three example presets are provided:

**Lax (`settings-lax.json`):**
- Disables `--dangerously-skip-permissions`
- Blocks plugin marketplaces

**Strict (`settings-strict.json`):**
- All of lax, plus:
- Only managed permission rules
- Only managed hooks
- Deny WebSearch and WebFetch tools
- Bash requires approval

**Bash Sandbox (`settings-bash-sandbox.json`):**
- Only managed permission rules
- Sandbox enabled with full lockdown
- No auto-allow bash
- No unsandboxed commands
- Network restrictions (allowedDomains, unix sockets, local binding)

### 8.2 Sandbox Configuration

```json
{
  "sandbox": {
    "enabled": true,
    "autoAllowBashIfSandboxed": false,
    "allowUnsandboxedCommands": false,
    "excludedCommands": [],
    "network": {
      "allowUnixSockets": [],
      "allowAllUnixSockets": false,
      "allowLocalBinding": false,
      "allowedDomains": [],
      "httpProxyPort": null,
      "socksProxyPort": null
    },
    "enableWeakerNestedSandbox": false
  }
}
```

### 8.3 Permission Rules

```json
{
  "permissions": {
    "disableBypassPermissionsMode": "disable",
    "ask": ["Bash"],
    "deny": ["WebSearch", "WebFetch"]
  }
}
```

### 8.4 CLAUDE.md System

Project instructions are loaded from `CLAUDE.md` files at multiple directory levels:
- Root `CLAUDE.md` -- Project-wide instructions
- Directory-level `CLAUDE.md` files -- Scoped to that directory
- `~/.claude/CLAUDE.md` -- User-wide instructions

These are injected into the agent's context and can be referenced by review agents for compliance checking.

---

## 9. Multi-Model Support

### 9.1 Model Tiers in Agent Definitions

Agents declare model requirements in frontmatter:
```yaml
model: opus      # Deep reasoning, architecture, bug detection
model: sonnet    # Routine analysis, exploration, compliance
model: haiku     # Quick screening, pre-checks
model: inherit   # Use parent agent's model
```

### 9.2 CLI Model Selection

- `--model` flag on command line
- `/model` command during session
- Default model configurable

### 9.3 Model-Specific Features

- `ultrathink` hint support for extended thinking
- Model migration plugin (`claude-opus-4-5-migration`) for upgrading prompts/code to new model versions
- Claude Code Action supports model specification: `claude_args: "--model claude-sonnet-4-5-20250929"`

### 9.4 Cost-Optimized Routing

The code-review plugin demonstrates tiered model routing:
- **Haiku** for pre-screening (is PR draft? already reviewed?)
- **Sonnet** for CLAUDE.md compliance (2 parallel agents)
- **Opus** for bug detection (2 parallel agents)
- **Opus** for validation of flagged issues
- **Sonnet** for summaries

This optimizes cost by using expensive models only where they add value.

---

## 10. Session Management

### 10.1 Session Persistence

Based on CHANGELOG entries:
- `--resume` flag to resume previous sessions
- Session ID tracked and sent as `X-Claude-Code-Session-Id` header
- Transcript files stored (JSONL format per the ralph-wiggum code)
- Session state survives across context compaction (PreCompact hook)

### 10.2 State Files

Plugins manage state via local files:
- `.claude/ralph-loop.local.md` -- Ralph iteration state (YAML frontmatter)
- `.claude/hookify.*.local.md` -- User-defined hook rules
- `~/.claude/security_warnings_state_{session_id}.json` -- Per-session security warning state
- `~/.claude/.claude` volume mount in devcontainer for config persistence

### 10.3 Cowork Dispatch

Referenced in v2.1.87: "Fixed messages in Cowork Dispatch not getting delivered." This suggests a multi-session coordination system where multiple Claude Code instances can communicate, but details are not exposed in this repo.

### 10.4 Context Compaction

- PreCompact hook event allows plugins to inject critical information before compaction
- Memory growth fixes in recent versions (v2.1.86: "Fixed memory growth in long sessions from markdown/highlight render caches")

---

## 11. UI/UX

### 11.1 Terminal CLI

- Primary interface is terminal CLI (`claude` command)
- Rich terminal output with markdown rendering
- Scroll following for new messages
- Statusline showing current model
- Masked input for sensitive data (OAuth codes)
- Click-to-select in transcript
- `--bare` mode for programmatic/scripted use

### 11.2 IDE Integration

- VS Code extension (`anthropic.claude-code`)
- GitHub integration (`@claude` mentions in issues/PRs)
- DevContainer support for sandboxed development

### 11.3 Slash Commands

User-facing commands prefixed with `/`:
- `/commit`, `/commit-push-pr` -- Git operations
- `/feature-dev` -- 7-phase development
- `/code-review`, `/review-pr` -- Code review
- `/hookify` -- Create custom hooks
- `/plugin` -- Install/manage plugins
- `/model` -- Switch models
- `/bug` -- Report issues
- `/ralph-loop` -- Start iteration loop
- `/hooks` -- Review loaded hooks
- `/feedback` -- Submit feedback

### 11.4 Agent Color Coding

Agents are assigned terminal colors in frontmatter for visual distinction:
- `color: green` (code-reviewer, code-architect)
- `color: yellow` (code-explorer, silent-failure-hunter)
- `color: pink` (type-design-analyzer)

---

## 12. Security Model

### 12.1 DevContainer Sandbox

The `.devcontainer/` provides a full Docker-based sandbox:

**Container setup:**
- Node.js 20 base image
- `NET_ADMIN` and `NET_RAW` capabilities for firewall control
- Workspace bind mount with delegated consistency
- Persistent volumes for bash history and Claude config
- 4GB Node.js memory limit

**Network firewall (`init-firewall.sh`):**
- Flushes all iptables rules
- Default policy: DROP all inbound, outbound, forward
- Whitelists specific domains only:
  - GitHub (dynamic IP ranges from `api.github.com/meta`)
  - npm registry
  - Anthropic API
  - Sentry
  - Statsig
  - VS Code marketplace/updates
- Blocks ALL other network access
- Verification step: confirms `example.com` is blocked, `api.github.com` works
- Uses `ipset` with CIDR support for efficient IP matching

### 12.2 Permission System

Three-tier permission model:
1. **Allow** -- Tool executes without asking
2. **Ask** -- User must approve each invocation
3. **Deny** -- Tool cannot be used at all

Fine-grained Bash permissions:
```yaml
allowed-tools: Bash(git add:*), Bash(git status:*)
```

This restricts Bash to specific command prefixes only.

### 12.3 Security Hook

The security-guidance plugin monitors 9 vulnerability patterns in PreToolUse:
1. GitHub Actions workflow injection (path-based)
2. `child_process.exec()` (prefer `execFileNoThrow`)
3. `new Function()` injection
4. `eval()` injection
5. `dangerouslySetInnerHTML` (XSS)
6. `document.write()` (XSS)
7. `.innerHTML =` (XSS)
8. `pickle` deserialization
9. `os.system` injection

Per-session deduplication: each warning shown only once per file+pattern combination.

### 12.4 Enterprise Controls

- `disableBypassPermissionsMode: "disable"` -- Cannot skip permissions
- `allowManagedPermissionRulesOnly: true` -- Only admin-defined rules
- `allowManagedHooksOnly: true` -- Only admin-defined hooks
- `strictKnownMarketplaces: []` -- Block all third-party plugins

---

## 13. Analysis for Trio Competitive Positioning

### 13.1 What Claude Code Does Well

1. **Plugin architecture is clean.** Markdown-as-code for agents/commands/skills is elegant, versioned, and accessible.
2. **Multi-agent orchestration patterns are mature.** The fanout-validate-filter pattern in code-review is sophisticated.
3. **Cost-optimized model routing.** Haiku for screening, Sonnet for routine, Opus for deep analysis.
4. **Hook system is comprehensive.** 9 event types, both prompt and command hooks, parallel execution.
5. **Security sandbox is thorough.** Network-level firewall, fine-grained tool permissions, enterprise controls.
6. **Self-referential loops (ralph-wiggum).** Completion promise pattern is novel for ensuring task completion.
7. **Ecosystem breadth.** 13 official plugins covering development, review, security, learning.

### 13.2 What Claude Code Does NOT Have (Trio Opportunities)

1. **No multi-model backend support.** Claude Code is locked to Anthropic models (Claude only). No OpenAI, Gemini, local model, or LiteLLM gateway support. Trio's API pool and cross-model support is a differentiator.
2. **No wisdom accumulation.** Each session starts fresh (except `--resume`). No persistent learning across sessions. Trio's wisdom system is unique.
3. **No incremental merge detection.** No awareness of code merges or conflict patterns.
4. **No cross-verify system.** Code-review uses multiple Claude agents but never cross-verifies with a different LLM vendor. Trio's Codex/GPT cross-verification is unique.
5. **No spec-driven development.** Claude Code has feature-dev but no spec system. Trio's spec-build-verify pipeline is more structured.
6. **No deterministic security scanning.** The security-guidance plugin is purely string-matching. No data flow analysis, no input tracing. Trio's security-scan with deterministic phase is deeper.
7. **No plan file system.** Claude Code uses TodoWrite for progress tracking but has no structured plan file that survives session boundaries.
8. **No audit persona system.** Trio's 17-persona audit is broader than Claude Code's review agents.
9. **Closed source core.** The binary is opaque. Trio's open architecture allows users to understand and modify the orchestration layer.

### 13.3 Patterns Worth Adopting

1. **Markdown-as-agent-definition.** Consider defining Trio agents/skills as Markdown files with YAML frontmatter. This is more accessible than code.
2. **Confidence-based filtering.** The 0-100 scoring with threshold filtering in code-review is a good pattern for reducing false positives in our audit system.
3. **Completion promise pattern.** Ralph-wiggum's `<promise>` tag system could enhance our build loops -- instead of checking off plan items, require the agent to assert a verifiable completion statement.
4. **Model tier routing.** Explicit `model: opus/sonnet/haiku` in agent definitions is cleaner than runtime model selection.
5. **Tool access sandboxing per agent.** Fine-grained `allowed-tools` with Bash command prefix restrictions is worth replicating.
6. **Hook-based event pipeline.** The 9-event hook lifecycle (especially PreToolUse modify, Stop block, SessionStart context injection) is a clean extensibility pattern.
7. **Parallel agent dispatch with validation.** The code-review pattern of "detect in parallel, then validate each finding in parallel" is excellent for QA.
8. **YAML frontmatter for command metadata.** Using frontmatter for `description`, `allowed-tools`, `argument-hint`, `model`, `color` is a clean metadata pattern.

### 13.4 Key Takeaways for Trio Development

| Area | Claude Code | Trio | Action |
|------|------------|------|--------|
| Multi-model | Claude only | Multi-backend | Keep -- major differentiator |
| Wisdom/learning | None | Wisdom accumulation | Keep -- unique capability |
| Cross-verify | Same-vendor only | Cross-vendor LLM | Keep -- unique capability |
| Plugin system | Mature, clean | N/A | Consider adopting Markdown-as-agent pattern |
| Hook system | 9 events, prompt+command | N/A | Consider event-driven hooks |
| Security | Network sandbox + string matching | Deterministic + AI scan | Keep -- deeper analysis |
| Agent orchestration | Task-based dispatch | Spec-based build | Keep spec system, add Task dispatch |
| QA pipeline | Confidence scoring + validation | Persona-based audit | Add confidence scoring to audit |
| Iteration loops | Ralph-wiggum | Rate-limit resume | Consider completion promises |
| Plan persistence | TodoWrite (session-scoped) | Plan files (persistent) | Keep -- more robust |

---

## 14. Appendix: CHANGELOG Highlights (v2.1.86-87)

Notable recent features/fixes indicating active development:
- Cowork Dispatch (multi-session messaging)
- `X-Claude-Code-Session-Id` header for proxy session aggregation
- VCS directory exclusion (.jj, .sl for Jujutsu/Sapling)
- `--resume` session recovery
- `--bare` mode fixes for MCP tools
- Memory growth fixes for long sessions
- Plugin marketplace permissions
- Scroll/UI fixes
- Ultra-think hint support
