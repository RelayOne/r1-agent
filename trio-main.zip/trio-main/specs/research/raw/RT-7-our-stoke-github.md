# RT-7: Stoke GitHub Public Presence Analysis

**Date:** 2026-04-03
**Repo:** https://github.com/ericmacdougall/Stoke
**Status:** PRIVATE (not publicly visible)

---

## 1. Critical Finding: Repo Is Private

The repository `ericmacdougall/Stoke` is **currently set to private**. This means:

- Zero public visibility. Nobody can see it.
- Not indexed by GitHub search, Google, or any crawler.
- Not discoverable by potential users, contributors, or reviewers.
- The README, docs, spec, and all code are invisible to the outside world.
- The install script references `https://stoke.dev/install` (no such domain resolves) and `github.com/good-ventures/stoke` (no such repo exists).

**If the intent is open-source distribution, the repo needs to be made public.** Everything below analyzes what the public *would* see if it were flipped.

---

## 2. README Presentation

The README is strong -- professional, dense, and technically credible. It presents Stoke as:

> An AI coding orchestrator that drives Claude Code and Codex CLI as execution engines with deterministic PLAN->EXECUTE->VERIFY->COMMIT phases, multi-model routing, intelligent retry, parallel agent coordination, and structured quality layers.

### Strengths

- **Clear thesis statement** up front: "SWE-bench Pro shows the same model jumps ~15 points when you optimize the scaffold. The harness is the product."
- **Quick start** with practical commands, not just `go build`.
- **Command table** covering all 9 commands with purpose descriptions.
- **Detailed architecture diagram** in ASCII showing the full execution flow.
- **What's enforced section** -- rare for an open-source tool to document its security model this explicitly. Covers protected files, auth isolation, MCP isolation, sandbox, 11-layer policy engine, retry intelligence.
- **Architecture section** with per-package descriptions.
- **Concrete stats:** 19 packages, 6,500+ lines source, 3,400+ lines tests, 182 test functions, 60 Go files.
- **MIT License** -- permissive, good for adoption.

### Weaknesses

- **No badges** (CI status, Go version, license, test coverage).
- **No screenshots or GIFs** of the TUI, which is a major differentiator.
- **No "Why Stoke?" section** that positions against alternatives. The thesis is there but it's one sentence, not a comparison.
- **No link to a demo, video, or blog post.**
- **Install script broken:** references `stoke.dev` (not registered) and `github.com/good-ventures/stoke` (doesn't exist). The actual repo is `ericmacdougall/Stoke`.
- **No description set** on the GitHub repo itself (the "About" sidebar is blank).
- **No topics/tags** set on the repo. It won't appear in GitHub topic searches for `ai-orchestrator`, `claude-code`, `coding-agent`, etc.
- **"Forge" references still present** in `stoke.policy.yaml` (`files.protected` mentions `.forge/` and `forge.policy.yaml`) and in the spec (`docs/stoke-spec-final.md` titled "Forge: Complete Specification"). Several docs still have `forge-` prefixed filenames.

---

## 3. Commit History / Activity

**Created:** 2026-04-02 (yesterday)
**Total commits:** 8 (all on the same day)
**Last push:** 2026-04-03

| Commit | Date | Message |
|--------|------|---------|
| 797b861 | 2026-04-02 | Code formatting and prior review fixes: brace style, error handling, tests |
| 6bde62c | 2026-04-02 | Production hardening: check all error returns, fix resource leaks |
| d3705dd | 2026-04-02 | Auto-upgrade to SQLite store for parallel builds and ship mode |
| 8513012 | 2026-04-02 | Fix attempt numbering, add SaveState locking, add regression tests |
| 70270ae | 2026-04-02 | Address GPT review: fail-closed gitignored files, ship gates, repo hygiene |
| ace6753 | 2026-04-02 | Fix second-pass review: concurrency, security, correctness |
| 5849b81 | 2026-04-02 | Fix critical bugs: error handling, race conditions, security |
| b95cfa6 | 2026-04-02 | Add stoke project source code |
| b8c6679 | 2026-04-02 | Add files via upload |
| 344ffc7 | 2026-04-02 | Initial commit |

**Assessment:** The entire codebase was uploaded in a single day with rapid-fire fix commits. This reads as a one-shot upload-then-fix pattern, not organic development history. A public viewer would see:
- No feature-by-feature development arc.
- All code appeared at once.
- All fixes landed within hours.
- Commit messages reference "GPT review" which is transparent but signals the code was AI-generated.

---

## 4. Issues, PRs, Community

| Metric | Value |
|--------|-------|
| Open issues | 0 |
| Closed issues | 0 |
| Open PRs | 0 |
| Closed PRs | 0 |
| Stars | 0 |
| Forks | 0 |
| Watchers | 0 |
| Releases | 0 |
| Tags | 0 |

**Contributors:**
- `claude` (Anthropic bot): 8 contributions
- `ericmacdougall`: 2 contributions

**Assessment:** Zero community engagement. The contributor breakdown shows Claude as the primary author (8 of 10 commits). This is honest but notable -- potential users may question whether the code has been manually vetted.

---

## 5. Traffic / Engagement

| Metric | 14-day Total | Unique |
|--------|-------------|--------|
| Views | 4 | 1 |
| Clones | 4 | 1 |

**Referrers:** Only `github.com` (2 views, 1 unique).
**Top paths:** Repo overview (2 views), upload page (1 view).

**Assessment:** The only traffic is from the repo owner. Nobody else has seen or cloned this repo.

---

## 6. External Mentions / Discussion

**Web search results: ZERO mentions of Stoke anywhere.**

Searched for:
- `ericmacdougall Stoke AI coding orchestrator GitHub` -- no results
- `"stoke" AI coding orchestrator Claude Code Codex CLI` -- no results
- `stoke SWE-bench scaffold harness AI coding tool 2026` -- no results
- `site:reddit.com stoke AI coding orchestrator` -- no results
- `site:news.ycombinator.com stoke AI coding agent orchestrator` -- no results
- `stoke.dev AI coding tool install` -- no results
- `awesome-agent-orchestrators` list -- Stoke is NOT listed

**Assessment:** Stoke has absolutely zero web presence. It has not been submitted to Hacker News, Reddit, Product Hunt, awesome lists, or any community. No blog posts, no tweets, no reviews. The project is invisible.

---

## 7. Local vs. GitHub: What's Ahead Locally

The local codebase (`/home/eric/repos/trio/stoke/`) has diverged from GitHub with additional work:

### New packages (local only, not on GitHub)
- `internal/wisdom/` -- wisdom accumulation (wisdom.go, wisdom_test.go)
- Additional test files: `pools_test.go`, `managed/proxy_test.go`, `remote/session_test.go`, `repl/repl_test.go`, `scan/security_test.go`, `subscriptions/usage_test.go`, `tui/interactive_test.go`

### README differences (local is ahead)
The local README includes:
- 10 additional commands (`pools`, `add-claude`, `add-codex`, `remove-pool`, `yolo`, `scope`, `repair`, `ship`, `print-default-policy`, `help`) -- up from 9 to 19 commands.
- Ember integration environment variables table.
- Prerequisites section noting CGO-free build.
- Updated package count (26 vs 19).
- Additional package descriptions in architecture section.

### File counts

| Metric | GitHub | Local |
|--------|--------|-------|
| Go files | ~60 | 81 |
| Test functions | 182 (claimed) | 369 |
| Source lines | ~6,500 (claimed) | 12,583 |
| Test lines | ~3,400 (claimed) | 6,638 |
| Internal packages | 19 | 26+ (includes wisdom, pools, taskstate, managed, remote, repl, compute) |

The local codebase is roughly **2x the size** of what's on GitHub. The README stats on GitHub are stale.

---

## 8. Documentation on GitHub

### Published docs (on GitHub)
| File | Description |
|------|-------------|
| `docs/operator-guide.md` | Comprehensive. Covers Mode 1/2, pool setup, macOS caveats, troubleshooting, CI/CD, all flags. Production-quality. |
| `docs/stoke-spec-final.md` | 1,091-line frozen spec. Still titled "Forge: Complete Specification." Contains thesis, problem statement, architecture, all 16 sections. |
| `docs/ROADMAP.md` | Product stack (Stoke/Ember/Flare), 4-phase Ember integration plan. Reveals commercial strategy. |
| `docs/forge-feedback-loop.md` | Legacy "Forge" naming. |
| `docs/forge-research-synthesis.md` | Legacy "Forge" naming. Research backing. |
| `docs/forge-tui.md` | Legacy "Forge" naming. TUI design. |
| `docs/forge-vs-claude-code.md` | Legacy "Forge" naming. Competitive positioning. |
| `docs/harness-architecture.md` | Architecture deep-dive. |

### Doc issues
- 4 of 8 docs still have `forge-` prefix filenames, revealing the rename history.
- The frozen spec is titled "Forge" not "Stoke."
- The roadmap reveals the full commercial strategy (Ember SaaS, Flare infrastructure, OpenRouter markup). If this goes public, competitors see the playbook.

---

## 9. Competitive Landscape Context

The search results revealed a **crowded and active** competitive space. Major orchestrators found:

| Project | Stars | Description |
|---------|-------|-------------|
| ComposioHQ/agent-orchestrator | Active | Parallel coding agents with worktrees, CI handling |
| mco-org/mco | Active | Neutral orchestration for Claude/Codex/Gemini/OpenCode |
| stellarlinkco/myclaude | Active | Multi-agent orchestration (Claude/Codex/Gemini) |
| nxtg-ai/forge-orchestrator | Active | Multi-AI task orchestration with file locking (Rust) |
| hoangsonww/AI-Agents-Orchestrator | Active | Claude/Codex/Gemini/Copilot coordination |
| 23blocks-OS/ai-maestro | Active | Agent management dashboard |
| ruvnet/ruflo | Active | Multi-agent swarm platform for Claude |
| AlessioZazzarini/claude-codex-collab | Active | Dual AI agent orchestrator |

Recent Hacker News Show HNs:
- **Stoneforge** -- open-source parallel AI coding agent orchestration
- **Agent Orchestrator** -- local-first harness engineering control plane
- **Optio** -- AI agents in K8s, ticket-to-PR

**Key insight:** The Martin Fowler article on "Harness Engineering" and the arxiv paper on terminal-based AI coding agents validate Stoke's thesis. But at least 8-10 competitors are already public and building community. Stoke has zero presence.

---

## 10. Naming Issue: "Forge" Artifacts

Artifacts still referencing the old "Forge" name:

| Location | Issue |
|----------|-------|
| `stoke.policy.yaml` | `files.protected` lists `.forge/` and `forge.policy.yaml` |
| `docs/stoke-spec-final.md` | Title: "Forge: Complete Specification" |
| `docs/forge-feedback-loop.md` | Filename |
| `docs/forge-research-synthesis.md` | Filename |
| `docs/forge-tui.md` | Filename |
| `docs/forge-vs-claude-code.md` | Filename |

---

## 11. Install Script Issues

The `install.sh` file has incorrect references:
- Clones from `github.com/good-ventures/stoke` -- this org/repo does not exist.
- References `https://stoke.dev/install` -- domain not registered.
- Documentation link at bottom points to `github.com/good-ventures/stoke/blob/main/docs/operator-guide.md` -- broken.

---

## 12. Recommendations

### Immediate (before going public)
1. **Decide on visibility timing.** The repo is private. Making it public is a deliberate launch moment.
2. **Fix install.sh** to reference `ericmacdougall/Stoke` (or whatever the final org will be).
3. **Rename forge-* docs** or delete them. Having "Forge" artifacts in a "Stoke" repo looks sloppy.
4. **Fix stoke.policy.yaml** to reference `.stoke/` instead of `.forge/`.
5. **Update README stats** -- they're stale (local is 2x the size of what's claimed).
6. **Add repo description and topics** on GitHub (About sidebar, tags).
7. **Consider whether ROADMAP.md should be public** -- it reveals the Ember/Flare commercial strategy.
8. **Push local changes** -- GitHub is significantly behind local state.

### For launch
9. **Add CI** (GitHub Actions for `go test ./...`, `go vet ./...`, `go build ./cmd/stoke`).
10. **Add badges** (CI, Go version, license, coverage).
11. **Add TUI screenshots/GIF** to README.
12. **Create a release** with tagged version (v0.1.0 or v1.0.0).
13. **Submit to awesome-agent-orchestrators** list.
14. **Write a launch blog post** or Show HN.
15. **Register stoke.dev** if planned, or remove references.

### Strategic
16. **Clean up commit history** before going public (optional but the single-day all-at-once upload pattern is suboptimal optics).
17. **Decide on org:** `ericmacdougall/Stoke` vs a dedicated org like `stoke-dev/stoke` or `good-ventures/stoke`.
18. **License file says MIT** which is consistent with README and ROADMAP claims.

---

## 13. Summary

| Dimension | Status |
|-----------|--------|
| Repo visibility | PRIVATE -- invisible to public |
| README quality | Strong technical content, needs polish (badges, screenshots, broken links) |
| Codebase | Substantial (12.5K source + 6.6K test lines, 369 test functions, 81 Go files locally) |
| GitHub state | Stale -- local is ~2x ahead |
| Community | Zero (0 stars, 0 forks, 0 issues, 0 PRs) |
| External mentions | Zero -- not mentioned anywhere on the web |
| Competition | Crowded space with 8-10 active public alternatives |
| Naming | "Forge" artifacts still present in docs and config |
| Install script | Broken (references nonexistent org and domain) |
| Documentation | Comprehensive but partially outdated and reveals commercial strategy |

**Bottom line:** Stoke is a technically strong project with zero public presence. The repo is private, the install script is broken, legacy naming persists, and the competitive space is getting crowded fast. Every week this stays private, competitors are shipping and building community. The code and docs are good enough to launch -- the blocking issues are operational (visibility, broken links, naming cleanup), not technical.
