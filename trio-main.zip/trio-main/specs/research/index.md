# Research Index — Stoke v2 Enhancement

**Date:** 2026-04-03
**Scope:** Competitive analysis of 7 AI coding orchestration projects + industry best practices

## Raw Research

| ID | Project | Stars | Key Finding | File |
|----|---------|-------|-------------|------|
| RT-1 | [claw-code](https://github.com/ultraworkers/claw-code) | 160K | Rust reimpl: plugin system, HTTP/SSE server, LSP, structured compaction | [RT-1](raw/RT-1-claw-code.md) |
| RT-2 | [oh-my-openagent](https://github.com/code-yeongyu/oh-my-openagent) | 47.6K | Hash-anchored editing (68% success improvement), 48 hooks, AST-grep | [RT-2](raw/RT-2-oh-my-openagent.md) |
| RT-3 | [claude-code-1](https://github.com/code-yeongyu/claude-code-1) | N/A | 9-event hooks, ralph-wiggum completion promises, fanout-validate-filter | [RT-3](raw/RT-3-claude-code-1.md) |
| RT-4 | [oh-my-claudecode](https://github.com/Yeachan-Heo/oh-my-claudecode) | 22.9K | Mathematical ambiguity gating, tiered verification, tri-model advisory | [RT-4](raw/RT-4-oh-my-claudecode.md) |
| RT-5 | [oh-my-codex](https://github.com/Yeachan-Heo/oh-my-codex) | 13.6K | Socratic deep-interview, AI slop cleaner, event-sourced runtime | [RT-5](raw/RT-5-oh-my-codex.md) |
| RT-6 | [claw-code-parity](https://github.com/Yeachan-Heo/claw-code-parity) | N/A | Hook input rewriting, prompt cache detection, namespace sandbox | [RT-6](raw/RT-6-claw-code-parity.md) |
| RT-7 | Our Stoke (GitHub) | 0 | PRIVATE repo, 2x behind local, broken links, legacy naming | [RT-7](raw/RT-7-our-stoke-github.md) |
| RT-8 | Best Practices | N/A | Industry consensus: Stoke in top tier, gaps in self-reflection + MCP | [RT-8](raw/RT-8-best-practices.md) |

## Synthesized Research

| Topic | File |
|-------|------|
| Competitive Synthesis | [competitive-synthesis.md](synthesized/competitive-synthesis.md) |

## Spec

| Name | Status | File |
|------|--------|------|
| Stoke v2 Enhancement | ready | [specs/stoke-v2-enhancement.md](/home/eric/repos/trio/specs/stoke-v2-enhancement.md) |
