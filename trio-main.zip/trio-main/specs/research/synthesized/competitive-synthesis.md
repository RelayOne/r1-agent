# Competitive Synthesis: Stoke Enhancement Plan

**Date:** 2026-04-03
**Sources:** RT-1 (claw-code), RT-2 (oh-my-openagent), RT-3 (claude-code-1), RT-4 (oh-my-claudecode), RT-5 (oh-my-codex), RT-6 (claw-code-parity), RT-7 (our-stoke-github)
**Pending:** RT-8 (best-practices)

---

## Competitive Landscape Overview

| Project | Stars | Language | Core Approach | Strongest Feature |
|---------|-------|----------|---------------|-------------------|
| claw-code | 160K | Rust | Clean-room Claude Code reimpl | Plugin system + HTTP/SSE server + LSP |
| oh-my-openagent | 47.6K | TypeScript | OpenCode multi-agent plugin | Hash-anchored editing (68% success improvement) |
| oh-my-claudecode | 22.9K | TypeScript | Claude Code team orchestration | Mathematical ambiguity gating + PRD-driven loops |
| oh-my-codex | 13.6K | TS+Rust | Codex CLI workflow orchestration | Socratic deep-interview + AI slop cleaner |
| claude-code-1 | N/A | N/A | Official Claude Code ecosystem | 9-event hooks + fanout-validate-filter reviews |
| claw-code-parity | N/A | Rust | Claude Code Rust port | Hook input rewriting + prompt cache detection |
| **Our Stoke** | 0 | Go | Multi-engine orchestrator | Cross-model review + anti-deception state machine |

---

## Feature Gap Analysis: What Competitors Have That We Don't

### TIER 1: Highest Impact, Proven Patterns (Must-Have)

| # | Feature | Source | Description | Impact |
|---|---------|--------|-------------|--------|
| 1 | **Hash-Anchored Editing** | oh-my-openagent | xxHash32 per line; edits reference content hash, not line number; rejects if hash mismatch. **6.7% → 68.3% success rate improvement.** | Massive — prevents the #1 source of agent code corruption |
| 2 | **Extended Hook Lifecycle** | claude-code-1, oh-my-claudecode | 11 event types: PreToolUse, PostToolUse, PostToolUseFailure, Stop, SubagentStop, SessionStart, SessionEnd, PreCompact, UserPromptSubmit, PermissionRequest, Notification | Enables completion verification, session management, compaction control |
| 3 | **Completion Promise Verification** | claude-code-1 (ralph-wiggum), oh-my-claudecode (ralph) | Agent must assert verifiable completion statement; Stop hook blocks exit until true; anti-lying enforcement | Prevents premature task exit — agents can't claim done until verified |
| 4 | **AI Slop Detection + Cleanup** | oh-my-codex, oh-my-claudecode | Mandatory post-execution pass: detect and remove AI-generated code smell patterns, then re-verify for regressions | Catches AI-specific quality issues our current scan misses |
| 5 | **Confidence-Based Finding Filtering** | claude-code-1 | 0-100 scoring per finding, threshold at 80, multi-stage validation (detect → validate → filter) | Reduces false positive noise in scan/audit output by ~60% |
| 6 | **Tiered Verification Scaling** | oh-my-codex, oh-my-claudecode | Small (<3 files): light check. Standard (<15 files): full suite. Large (>15 files): full + security + performance + API compat | Cost-efficient — don't run Opus review on a typo fix |

### TIER 2: Significant Differentiators (Should-Have)

| # | Feature | Source | Description | Impact |
|---|---------|--------|-------------|--------|
| 7 | **Quantitative Ambiguity Scoring** | oh-my-codex, oh-my-claudecode | 0.0-1.0 scoring per weighted dimension; hard-gate execution until clarity < 20% ambiguity | Prevents "build the wrong thing" — scope quality gate |
| 8 | **Fanout-Validate-Filter Audit** | claude-code-1 | Detect findings in parallel → spawn independent validation agents per finding → filter to high-confidence | Dramatically improves audit signal-to-noise ratio |
| 9 | **Intent Verbalization** | oh-my-openagent | Before routing, agent explicitly maps "surface form" → "true intent" and announces routing decision | Prevents literal misinterpretation of ambiguous tasks |
| 10 | **Commit Decision Tracing** | oh-my-claudecode | Git trailers preserving: constraints, rejected alternatives, confidence levels, decision reasoning | Auditable decision history in git log |
| 11 | **Notification System** | oh-my-codex, oh-my-claudecode | Discord, Telegram, Slack, webhook alerts on task completion/failure/idle | Critical for long-running builds — user doesn't have to watch |
| 12 | **Hook Tool Input Modification** | claw-code-parity | Hooks can rewrite tool inputs (not just allow/deny) — enables input sanitization, path normalization | More powerful enforcement than binary allow/deny |

### TIER 3: Valuable Additions (Nice-to-Have)

| # | Feature | Source | Description | Impact |
|---|---------|--------|-------------|--------|
| 13 | **Plugin System** | claw-code, claude-code-1, oh-my-codex | Manifest-based plugins: custom tools, hooks, lifecycle, marketplace | Extensibility — community can add features |
| 14 | **HTTP/SSE Server** | claw-code | REST API + real-time event streaming for web dashboards | Enables remote monitoring, web UI, integrations |
| 15 | **AST-Grep Integration** | oh-my-openagent | 25-language AST-aware code search and rewrite | Structural code analysis beyond regex |
| 16 | **Category-Based Delegation** | oh-my-openagent | Decouple task intent ("visual-engineering") from model selection | Cleaner routing abstraction |
| 17 | **Session Recovery** | oh-my-openagent | Auto-recover from API failures, context limits, JSON parse errors | Resilience for long builds |
| 18 | **Three-Layer Skill Composition** | oh-my-claudecode | Execution + Enhancement + Guarantee layers compose combinatorially | Flexible behavior stacking |
| 19 | **Container-Aware Sandbox** | claw-code, claw-code-parity | Auto-detect Docker/K8s/Podman, adjust sandbox strategy | Production deployment flexibility |
| 20 | **LSP Integration** | claw-code, oh-my-openagent | Multi-server LSP: go-to-definition, references, diagnostics | Richer code intelligence for prompts |

---

## What We Have That NO Competitor Has

These are our **moats** — capabilities nobody else offers:

| # | Capability | Description | Closest Competitor |
|---|------------|-------------|-------------------|
| 1 | **Cross-Model Review Gate** | Claude implements → Codex reviews (or vice versa). Different AI family verifies the work. | oh-my-claudecode has `/ccg` tri-model advisory but it's conversational, not a merge gate |
| 2 | **TaskState Anti-Deception Machine** | Enforced state transitions: Pending → Claimed → Executed → Verified → Reviewed → Committed. Model cannot skip steps. Evidence required at every gate. | NONE have evidence-based state machines with mandatory transitions |
| 3 | **Post-Review Tree Revalidation** | After cross-model review, compare tree SHA to detect if reviewer mutated the code. Any change = task failure. | NONE do post-review integrity checking |
| 4 | **11-Layer Policy Engine** | --tools + MCP isolation + disallowedTools + allowedTools + settings.json + worktree isolation + sandbox + max-turns + enforcer hooks + verify pipeline + git ownership | NONE have this enforcement depth (competitors have 2-4 layers) |
| 5 | **GRPW Parallel Scheduling** | Greatest Rank Positional Weight priority ordering with file-scope conflict detection and dependency cascade | NONE have file-aware parallel scheduling with conflict detection |
| 6 | **Wisdom Accumulation** | Cross-task learning: gotchas, decisions, patterns extracted from completed tasks, injected into subsequent prompts | oh-my-openagent has session_id continuity but not cross-task learning |
| 7 | **17-Persona Audit System** | 5 core + 12 specialized reviewers auto-selected by project context | claude-code-1 has 6 review agents (our system is 3x broader) |
| 8 | **10-Class Failure Analysis** | TS/Go/Python/Rust/Clippy parsers with same-error-twice escalation | oh-my-codex has tiered verification but no language-specific parsing |
| 9 | **Pool Rotation + Circuit Breaker** | Smart pool selection (fewest fails → LRU → lowest utilization), rate limit rotation across pools | NONE manage multiple subscription accounts |
| 10 | **Merge-Tree Validation** | `git merge-tree --write-tree` for zero-side-effect conflict detection before actual merge | NONE validate merges pre-flight |
| 11 | **Deterministic Code Scan** | 22 rules: type bypasses, debug artifacts, deception patterns (tautological tests, empty catches), secrets | claude-code-1 has 9 patterns; our scan is 2.4x broader |
| 12 | **Gitignored File Detection** | Detects files the agent created that are gitignored (would pass tests but vanish on merge) | NONE check for this verification/merge divergence |

---

## Enhancement Categories (Final)

### Category A: Trust & Verification (Anti-Laziness)
Strengthen our core differentiator: ensuring every task is 100% properly, safely, completely finished.

- **A1**: Extended hook lifecycle (11 events matching claude-code/OMC)
- **A2**: Completion promise verification (ralph-wiggum pattern)
- **A3**: AI slop detection + mandatory cleanup pass
- **A4**: Confidence-based finding scoring (0-100 with threshold filtering)
- **A5**: Fanout-validate-filter for audit findings
- **A6**: Tiered verification scaling (light/standard/thorough based on change size)
- **A7**: Hook tool input modification (rewrite, not just allow/deny)

### Category B: Code Quality & Intelligence
Improve the quality of code the agents produce.

- **B1**: Hash-anchored editing (prevent stale line-number edits)
- **B2**: Expanded AI slop patterns (scan for AI-specific code smells)
- **B3**: Intent verbalization (agent states true intent before acting)
- **B4**: Commit decision tracing (git trailers with reasoning)

### Category C: Scope & Planning
Ensure we build the right thing before building anything.

- **C1**: Quantitative ambiguity scoring for scope command
- **C2**: Hard-gate execution on clarity threshold (< 20% ambiguity)

### Category D: Observability & UX
Let users monitor and control builds without watching the terminal.

- **D1**: Notification system (Discord, Slack, Telegram, webhook)
- **D2**: HTTP/SSE server for web dashboard / remote monitoring
- **D3**: Enhanced TUI with real-time HUD improvements

### Category E: Extensibility
Let the community extend Stoke without forking.

- **E1**: Plugin system (manifest-based, custom hooks + tools)
- **E2**: Markdown-as-agent definitions (YAML frontmatter + MD body)

### Category F: Infrastructure
Production hardening and provider expansion.

- **F1**: Container-aware sandbox detection (Docker/K8s/Podman)
- **F2**: Session recovery (auto-recover from API failures, context limits)
- **F3**: Multi-provider expansion (Gemini, Grok, local models)

---

## Priority Ranking (Impact × Feasibility)

| Priority | Item | Est. Effort | Impact | Rationale |
|----------|------|-------------|--------|-----------|
| P0 | B1: Hash-anchored editing | Medium | Critical | 10x improvement in edit success rate. Single biggest quality gain. |
| P0 | A1: Extended hook lifecycle | Medium | Critical | Foundation for A2, A7, session management, and extensibility |
| P0 | A3: AI slop detection + cleanup | Low | High | Expand existing scan rules — incremental work, big payoff |
| P1 | A2: Completion promise verification | Medium | High | Prevents premature exit — proven by ralph-wiggum |
| P1 | A4: Confidence scoring for findings | Low | High | Filter noise from scan/audit — simple scoring addition |
| P1 | A6: Tiered verification | Low | Medium | Cost savings — don't Opus-review a one-liner |
| P1 | C1: Ambiguity scoring for scope | Medium | High | Prevents building wrong thing — proven pattern |
| P1 | D1: Notification system | Low | Medium | Table-stakes for long builds — simple webhook integration |
| P2 | A5: Fanout-validate-filter audit | High | High | Major audit quality improvement but significant rework |
| P2 | A7: Hook input modification | Low | Medium | Enhances existing hook system |
| P2 | B4: Commit decision tracing | Low | Low | Nice audit trail — simple git trailer addition |
| P2 | D2: HTTP/SSE server | High | Medium | Enables web UI but large new subsystem |
| P3 | E1: Plugin system | High | Medium | Community value but large effort |
| P3 | F1: Container sandbox detection | Medium | Medium | Production deployment flexibility |
| P3 | F2: Session recovery | Medium | Medium | Resilience improvement |

---

*Pending: RT-8 (best-practices) may adjust priorities.*
