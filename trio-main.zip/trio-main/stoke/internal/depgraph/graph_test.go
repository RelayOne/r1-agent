package depgraph

import (
	"os"
	"path/filepath"
	"testing"
)

func setupTestRepo(t *testing.T) string {
	dir := t.TempDir()

	// main.go imports utils
	os.WriteFile(filepath.Join(dir, "main.go"), []byte(`package main

import "myapp/utils"

func main() {
	utils.Hello()
}
`), 0644)

	// utils.go has no imports
	os.MkdirAll(filepath.Join(dir, "utils"), 0755)
	os.WriteFile(filepath.Join(dir, "utils", "helpers.go"), []byte(`package utils

func Hello() {}
`), 0644)

	// config.go imports utils too
	os.WriteFile(filepath.Join(dir, "config.go"), []byte(`package main

import "myapp/utils"

func loadConfig() {
	utils.Hello()
}
`), 0644)

	return dir
}

func TestBuild(t *testing.T) {
	dir := setupTestRepo(t)
	g, err := Build(dir, []string{".go"})
	if err != nil {
		t.Fatal(err)
	}

	if len(g.Nodes) != 3 {
		t.Errorf("expected 3 nodes, got %d", len(g.Nodes))
	}
	if len(g.Edges) < 2 {
		t.Errorf("expected at least 2 edges, got %d", len(g.Edges))
	}
}

func TestDependencies(t *testing.T) {
	dir := setupTestRepo(t)
	g, _ := Build(dir, []string{".go"})

	deps := g.Dependencies("main.go")
	if len(deps) != 1 || deps[0] != "myapp/utils" {
		t.Errorf("expected [myapp/utils], got %v", deps)
	}
}

func TestLeaves(t *testing.T) {
	dir := setupTestRepo(t)
	g, _ := Build(dir, []string{".go"})

	leaves := g.Leaves()
	found := false
	for _, l := range leaves {
		if l == filepath.Join("utils", "helpers.go") {
			found = true
		}
	}
	if !found {
		t.Errorf("utils/helpers.go should be a leaf, got %v", leaves)
	}
}

func TestExtractGoImports(t *testing.T) {
	src := `package main

import (
	"fmt"
	"os"
	"myapp/utils"
)

import "strings"
`
	imports := extractGoImports(src)
	if len(imports) != 4 {
		t.Errorf("expected 4 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractPyImports(t *testing.T) {
	src := `import os
import sys
from pathlib import Path
from collections import defaultdict, OrderedDict
`
	imports := extractPyImports(src)
	if len(imports) < 4 {
		t.Errorf("expected at least 4 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractTSImports(t *testing.T) {
	src := `import { foo } from './utils'
import * as bar from 'lodash'
const x = require('path')
`
	imports := extractTSImports(src)
	if len(imports) != 3 {
		t.Errorf("expected 3 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractRustImports(t *testing.T) {
	src := `use std::io;
use crate::config;
mod helpers;
`
	imports := extractRustImports(src)
	if len(imports) != 3 {
		t.Errorf("expected 3 imports, got %d: %v", len(imports), imports)
	}
}

func TestShouldSkip(t *testing.T) {
	if !shouldSkip("vendor/pkg/foo.go") {
		t.Error("should skip vendor")
	}
	if !shouldSkip("node_modules/express/index.js") {
		t.Error("should skip node_modules")
	}
	if shouldSkip("internal/pkg/foo.go") {
		t.Error("should not skip internal")
	}
}

func TestStats(t *testing.T) {
	dir := setupTestRepo(t)
	g, _ := Build(dir, []string{".go"})
	s := g.Stats()
	if s == "" {
		t.Error("stats should not be empty")
	}
}

func TestDedup(t *testing.T) {
	result := dedup([]string{"a", "b", "a", "c", "b"})
	if len(result) != 3 {
		t.Errorf("expected 3, got %d", len(result))
	}
}

func TestRoots(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
			"b": {Path: "b", Imports: nil},
		},
		Edges: []Edge{{From: "a", To: "b"}},
	}

	roots := g.Roots()
	if len(roots) != 1 || roots[0] != "a" {
		t.Errorf("expected [a] as root, got %v", roots)
	}
}

func TestDetectCycles(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
			"b": {Path: "b", Imports: []string{"a"}},
		},
		Edges: []Edge{
			{From: "a", To: "b"},
			{From: "b", To: "a"},
		},
	}

	cycles := g.DetectCycles()
	if len(cycles) == 0 {
		t.Error("should detect cycle between a and b")
	}
}

// --- Multi-language import extraction ---

func TestExtractGoImportsSingle(t *testing.T) {
	src := `package main
import "fmt"
`
	imports := extractGoImports(src)
	if len(imports) != 1 {
		t.Fatalf("expected 1 import, got %d: %v", len(imports), imports)
	}
	if imports[0] != "fmt" {
		t.Errorf("expected fmt, got %q", imports[0])
	}
}

func TestExtractGoImportsBlockDedups(t *testing.T) {
	src := `package main
import (
	"fmt"
	"os"
	"fmt"
)
`
	imports := extractGoImports(src)
	if len(imports) != 2 {
		t.Errorf("expected 2 unique imports (deduped), got %d: %v", len(imports), imports)
	}
}

func TestExtractGoImportsEmpty(t *testing.T) {
	src := `package main

func main() {}
`
	imports := extractGoImports(src)
	if len(imports) != 0 {
		t.Errorf("expected 0 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractGoImportsMixed(t *testing.T) {
	// Both single and block imports in the same file
	src := `package main

import "strings"

import (
	"fmt"
	"os"
)
`
	imports := extractGoImports(src)
	if len(imports) != 3 {
		t.Errorf("expected 3 imports (strings, fmt, os), got %d: %v", len(imports), imports)
	}
}

func TestExtractPyImportsFrom(t *testing.T) {
	src := `from os.path import join, exists
from collections import defaultdict
`
	imports := extractPyImports(src)
	if len(imports) != 2 {
		t.Errorf("expected 2 imports (os.path, collections), got %d: %v", len(imports), imports)
	}
	found := false
	for _, imp := range imports {
		if imp == "os.path" {
			found = true
		}
	}
	if !found {
		t.Errorf("expected os.path in imports, got %v", imports)
	}
}

func TestExtractPyImportsPlain(t *testing.T) {
	src := `import os
import sys
import json
`
	imports := extractPyImports(src)
	if len(imports) != 3 {
		t.Errorf("expected 3 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractPyImportsEmpty(t *testing.T) {
	src := `def hello():
    return "hi"
`
	imports := extractPyImports(src)
	if len(imports) != 0 {
		t.Errorf("expected 0 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractPyImportsMultipleOnLine(t *testing.T) {
	src := `import os, sys, json
`
	imports := extractPyImports(src)
	if len(imports) != 3 {
		t.Errorf("expected 3 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractTSImportsESM(t *testing.T) {
	src := `import { useState } from 'react'
import * as path from 'path'
import './styles.css'
`
	imports := extractTSImports(src)
	if len(imports) != 3 {
		t.Errorf("expected 3 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractTSImportsRequire(t *testing.T) {
	src := `const fs = require('fs')
const path = require('path')
`
	imports := extractTSImports(src)
	if len(imports) != 2 {
		t.Errorf("expected 2 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractTSImportsMixed(t *testing.T) {
	src := `import { foo } from './utils'
const bar = require('lodash')
`
	imports := extractTSImports(src)
	if len(imports) != 2 {
		t.Errorf("expected 2 imports (ESM + require), got %d: %v", len(imports), imports)
	}
}

func TestExtractTSImportsEmpty(t *testing.T) {
	src := `export function hello() { return "hi" }
`
	imports := extractTSImports(src)
	if len(imports) != 0 {
		t.Errorf("expected 0 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractTSImportsDedups(t *testing.T) {
	src := `import { a } from './utils'
import { b } from './utils'
`
	imports := extractTSImports(src)
	if len(imports) != 1 {
		t.Errorf("expected 1 unique import (deduped), got %d: %v", len(imports), imports)
	}
}

func TestExtractRustImportsUse(t *testing.T) {
	src := `use std::io;
use std::collections::HashMap;
use crate::config;
`
	imports := extractRustImports(src)
	if len(imports) != 3 {
		t.Errorf("expected 3 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractRustImportsMod(t *testing.T) {
	src := `mod helpers;
mod config;
`
	imports := extractRustImports(src)
	if len(imports) != 2 {
		t.Errorf("expected 2 mod imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractRustImportsEmpty(t *testing.T) {
	src := `fn main() {
    println!("hello");
}
`
	imports := extractRustImports(src)
	if len(imports) != 0 {
		t.Errorf("expected 0 imports, got %d: %v", len(imports), imports)
	}
}

func TestExtractRustImportsMixed(t *testing.T) {
	src := `use std::io;
mod helpers;
use crate::utils;
`
	imports := extractRustImports(src)
	if len(imports) != 3 {
		t.Errorf("expected 3 imports (use + mod), got %d: %v", len(imports), imports)
	}
}

func TestExtractImportsUnknownExtension(t *testing.T) {
	imports := extractImports("some content", ".unknown")
	if imports != nil {
		t.Errorf("unknown extension should return nil, got %v", imports)
	}
}

func TestExtractImportsDispatchesJS(t *testing.T) {
	src := `import { foo } from './bar'`
	for _, ext := range []string{".js", ".jsx", ".ts", ".tsx"} {
		imports := extractImports(src, ext)
		if len(imports) != 1 {
			t.Errorf("ext=%s: expected 1 import, got %d", ext, len(imports))
		}
	}
}

// --- Cycle detection edge cases ---

func TestDetectCyclesNoCycles(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
			"b": {Path: "b", Imports: []string{"c"}},
			"c": {Path: "c", Imports: nil},
		},
		Edges: []Edge{
			{From: "a", To: "b"},
			{From: "b", To: "c"},
		},
	}
	cycles := g.DetectCycles()
	if len(cycles) != 0 {
		t.Errorf("expected no cycles in DAG, got %d: %v", len(cycles), cycles)
	}
}

func TestDetectCyclesSelfReference(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"a"}},
		},
		Edges: []Edge{
			{From: "a", To: "a"},
		},
	}
	cycles := g.DetectCycles()
	if len(cycles) == 0 {
		t.Error("should detect self-referencing cycle")
	}
}

func TestDetectCyclesTriangle(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
			"b": {Path: "b", Imports: []string{"c"}},
			"c": {Path: "c", Imports: []string{"a"}},
		},
		Edges: []Edge{
			{From: "a", To: "b"},
			{From: "b", To: "c"},
			{From: "c", To: "a"},
		},
	}
	cycles := g.DetectCycles()
	if len(cycles) == 0 {
		t.Error("should detect 3-node cycle a->b->c->a")
	}
}

func TestDetectCyclesEdgeToExternalNode(t *testing.T) {
	// Edge points to a node not in the graph (external dependency)
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"external"}},
		},
		Edges: []Edge{
			{From: "a", To: "external"},
		},
	}
	cycles := g.DetectCycles()
	if len(cycles) != 0 {
		t.Errorf("should not detect cycles when edge goes to external node, got %v", cycles)
	}
}

// --- Impact analysis ---

func TestImpactSetDirect(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
			"b": {Path: "b", Imports: nil},
			"c": {Path: "c", Imports: []string{"b"}},
		},
		Edges: []Edge{
			{From: "a", To: "b"},
			{From: "c", To: "b"},
		},
	}
	impact := g.ImpactSet("b")
	if len(impact) != 2 {
		t.Errorf("expected 2 impacted files, got %d: %v", len(impact), impact)
	}
}

func TestImpactSetTransitive(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
			"b": {Path: "b", Imports: []string{"c"}},
			"c": {Path: "c", Imports: nil},
		},
		Edges: []Edge{
			{From: "a", To: "b"},
			{From: "b", To: "c"},
		},
	}
	// Changing c impacts b (directly) and a (transitively through b)
	impact := g.ImpactSet("c")
	if len(impact) != 2 {
		t.Errorf("expected 2 transitively impacted files, got %d: %v", len(impact), impact)
	}
	foundA, foundB := false, false
	for _, f := range impact {
		if f == "a" {
			foundA = true
		}
		if f == "b" {
			foundB = true
		}
	}
	if !foundA || !foundB {
		t.Errorf("impact set should contain a and b, got %v", impact)
	}
}

func TestImpactSetNoImpact(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
			"b": {Path: "b", Imports: nil},
		},
		Edges: []Edge{
			{From: "a", To: "b"},
		},
	}
	// Changing a impacts nothing (nobody imports a)
	impact := g.ImpactSet("a")
	if len(impact) != 0 {
		t.Errorf("expected 0 impacted files for root node, got %d: %v", len(impact), impact)
	}
}

func TestImpactSetExcludesSource(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
			"b": {Path: "b", Imports: nil},
		},
		Edges: []Edge{
			{From: "a", To: "b"},
		},
	}
	impact := g.ImpactSet("b")
	for _, f := range impact {
		if f == "b" {
			t.Error("impact set should exclude the source file itself")
		}
	}
}

// --- Root and leaf node identification ---

func TestRootsMultiple(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"c"}},
			"b": {Path: "b", Imports: []string{"c"}},
			"c": {Path: "c", Imports: nil},
		},
		Edges: []Edge{
			{From: "a", To: "c"},
			{From: "b", To: "c"},
		},
	}
	roots := g.Roots()
	if len(roots) != 2 {
		t.Errorf("expected 2 roots (a, b), got %d: %v", len(roots), roots)
	}
}

func TestRootsAllRoots(t *testing.T) {
	// No edges, all nodes are roots
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: nil},
			"b": {Path: "b", Imports: nil},
		},
		Edges: nil,
	}
	roots := g.Roots()
	if len(roots) != 2 {
		t.Errorf("expected 2 roots (all disconnected), got %d: %v", len(roots), roots)
	}
}

func TestLeavesMultiple(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b", "c"}},
			"b": {Path: "b", Imports: nil},
			"c": {Path: "c", Imports: nil},
		},
		Edges: []Edge{
			{From: "a", To: "b"},
			{From: "a", To: "c"},
		},
	}
	leaves := g.Leaves()
	if len(leaves) != 2 {
		t.Errorf("expected 2 leaves (b, c), got %d: %v", len(leaves), leaves)
	}
}

func TestLeavesNone(t *testing.T) {
	// All nodes have imports (cycle)
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
			"b": {Path: "b", Imports: []string{"a"}},
		},
		Edges: []Edge{
			{From: "a", To: "b"},
			{From: "b", To: "a"},
		},
	}
	leaves := g.Leaves()
	if len(leaves) != 0 {
		t.Errorf("expected 0 leaves in cycle graph, got %d: %v", len(leaves), leaves)
	}
}

// --- Edge cases: empty graph, disconnected nodes ---

func TestEmptyGraph(t *testing.T) {
	g := &Graph{
		Nodes: make(map[string]*Node),
		Edges: nil,
	}
	if len(g.Roots()) != 0 {
		t.Errorf("empty graph should have 0 roots, got %d", len(g.Roots()))
	}
	if len(g.Leaves()) != 0 {
		t.Errorf("empty graph should have 0 leaves, got %d", len(g.Leaves()))
	}
	if len(g.DetectCycles()) != 0 {
		t.Errorf("empty graph should have 0 cycles, got %d", len(g.DetectCycles()))
	}
	if g.Stats() == "" {
		t.Error("Stats on empty graph should return non-empty string")
	}
}

func TestDisconnectedNodes(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: nil},
			"b": {Path: "b", Imports: nil},
			"c": {Path: "c", Imports: nil},
		},
		Edges: nil,
	}
	roots := g.Roots()
	if len(roots) != 3 {
		t.Errorf("all disconnected nodes should be roots, got %d: %v", len(roots), roots)
	}
	leaves := g.Leaves()
	if len(leaves) != 3 {
		t.Errorf("all disconnected nodes should be leaves, got %d: %v", len(leaves), leaves)
	}
	impact := g.ImpactSet("a")
	if len(impact) != 0 {
		t.Errorf("disconnected node should have 0 impact, got %d: %v", len(impact), impact)
	}
}

func TestDependenciesUnknownNode(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
		},
		Edges: []Edge{{From: "a", To: "b"}},
	}
	deps := g.Dependencies("nonexistent")
	if deps != nil {
		t.Errorf("dependencies of unknown node should be nil, got %v", deps)
	}
}

func TestDependentsWithBasenameMatch(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"src/main.go":    {Path: "src/main.go", Imports: []string{"pkg/utils"}},
			"pkg/utils.go":   {Path: "pkg/utils.go", Imports: nil},
		},
		Edges: []Edge{
			{From: "src/main.go", To: "pkg/utils"},
		},
	}
	// Dependents checks both exact match and basename suffix
	deps := g.Dependents("pkg/utils")
	if len(deps) != 1 {
		t.Errorf("expected 1 dependent, got %d: %v", len(deps), deps)
	}
	if deps[0] != "src/main.go" {
		t.Errorf("dependent should be src/main.go, got %q", deps[0])
	}
}

func TestDependentsNone(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: nil},
		},
		Edges: nil,
	}
	deps := g.Dependents("a")
	if len(deps) != 0 {
		t.Errorf("expected 0 dependents, got %d: %v", len(deps), deps)
	}
}

func TestStatsFormat(t *testing.T) {
	g := &Graph{
		Nodes: map[string]*Node{
			"a": {Path: "a", Imports: []string{"b"}},
			"b": {Path: "b", Imports: nil},
		},
		Edges: []Edge{{From: "a", To: "b"}},
	}
	s := g.Stats()
	if s == "" {
		t.Fatal("Stats should not return empty string")
	}
	if !containsSubstr(s, "2 nodes") {
		t.Errorf("Stats should mention 2 nodes, got %q", s)
	}
	if !containsSubstr(s, "1 edges") {
		t.Errorf("Stats should mention 1 edges, got %q", s)
	}
}

// --- shouldSkip and matchExt ---

func TestShouldSkipDotGitDir(t *testing.T) {
	if !shouldSkip(".git/config") {
		t.Error("should skip .git directory")
	}
}

func TestShouldSkipTarget(t *testing.T) {
	if !shouldSkip("target/debug/main") {
		t.Error("should skip target directory (Rust)")
	}
}

func TestShouldSkipPycache(t *testing.T) {
	if !shouldSkip("__pycache__/module.pyc") {
		t.Error("should skip __pycache__ directory")
	}
}

func TestShouldSkipNested(t *testing.T) {
	if !shouldSkip("src/vendor/pkg/foo.go") {
		t.Error("should skip nested vendor directory")
	}
}

func TestShouldSkipNormalPath(t *testing.T) {
	if shouldSkip("src/pkg/handler.go") {
		t.Error("should not skip normal source path")
	}
}

func TestMatchExtAllowed(t *testing.T) {
	if !matchExt(".go", []string{".go", ".py"}) {
		t.Error("should match .go in allowed list")
	}
}

func TestMatchExtNotAllowed(t *testing.T) {
	if matchExt(".rs", []string{".go", ".py"}) {
		t.Error("should not match .rs when not in allowed list")
	}
}

func TestMatchExtEmptyAllowsAll(t *testing.T) {
	if !matchExt(".anything", nil) {
		t.Error("empty extensions should allow all")
	}
	if !matchExt(".go", []string{}) {
		t.Error("empty extensions slice should allow all")
	}
}

func TestDedupEmpty(t *testing.T) {
	result := dedup(nil)
	if len(result) != 0 {
		t.Errorf("dedup(nil) should return empty, got %v", result)
	}
}

func TestDedupAllUnique(t *testing.T) {
	result := dedup([]string{"a", "b", "c"})
	if len(result) != 3 {
		t.Errorf("dedup of unique items should keep all, got %d: %v", len(result), result)
	}
}

func TestDedupAllSame(t *testing.T) {
	result := dedup([]string{"a", "a", "a"})
	if len(result) != 1 {
		t.Errorf("dedup of identical items should return 1, got %d: %v", len(result), result)
	}
}

// --- Build with file system ---

func TestBuildSkipsVendor(t *testing.T) {
	dir := t.TempDir()
	os.MkdirAll(filepath.Join(dir, "vendor", "pkg"), 0755)
	os.WriteFile(filepath.Join(dir, "vendor", "pkg", "dep.go"), []byte(`package pkg
import "fmt"
`), 0644)
	os.WriteFile(filepath.Join(dir, "main.go"), []byte(`package main
import "fmt"
func main() { fmt.Println("hi") }
`), 0644)

	g, err := Build(dir, []string{".go"})
	if err != nil {
		t.Fatal(err)
	}
	if len(g.Nodes) != 1 {
		t.Errorf("expected 1 node (vendor skipped), got %d", len(g.Nodes))
	}
}

func TestBuildMultipleExtensions(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "main.go"), []byte(`package main
import "fmt"
`), 0644)
	os.WriteFile(filepath.Join(dir, "app.py"), []byte(`import os
`), 0644)
	os.WriteFile(filepath.Join(dir, "readme.txt"), []byte("just text"), 0644)

	g, err := Build(dir, []string{".go", ".py"})
	if err != nil {
		t.Fatal(err)
	}
	if len(g.Nodes) != 2 {
		t.Errorf("expected 2 nodes (.go + .py, not .txt), got %d", len(g.Nodes))
	}
}

func TestBuildNoExtensionFilter(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "main.go"), []byte(`package main
`), 0644)
	os.WriteFile(filepath.Join(dir, "app.py"), []byte(`x = 1
`), 0644)

	g, err := Build(dir, nil)
	if err != nil {
		t.Fatal(err)
	}
	if len(g.Nodes) < 2 {
		t.Errorf("expected at least 2 nodes with no ext filter, got %d", len(g.Nodes))
	}
}

func TestBuildTypeScript(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "index.ts"), []byte(`import { foo } from './utils'
import * as bar from 'lodash'
`), 0644)
	os.WriteFile(filepath.Join(dir, "utils.ts"), []byte(`export const foo = 42
`), 0644)

	g, err := Build(dir, []string{".ts"})
	if err != nil {
		t.Fatal(err)
	}
	if len(g.Nodes) != 2 {
		t.Errorf("expected 2 TS nodes, got %d", len(g.Nodes))
	}
	if len(g.Edges) < 2 {
		t.Errorf("expected at least 2 edges from index.ts, got %d", len(g.Edges))
	}
}

func TestBuildRust(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "main.rs"), []byte(`use std::io;
mod helpers;
`), 0644)
	os.WriteFile(filepath.Join(dir, "helpers.rs"), []byte(`pub fn help() {}
`), 0644)

	g, err := Build(dir, []string{".rs"})
	if err != nil {
		t.Fatal(err)
	}
	if len(g.Nodes) != 2 {
		t.Errorf("expected 2 Rust nodes, got %d", len(g.Nodes))
	}
}

func TestBuildPython(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "app.py"), []byte(`import os
from pathlib import Path
`), 0644)

	g, err := Build(dir, []string{".py"})
	if err != nil {
		t.Fatal(err)
	}
	if len(g.Nodes) != 1 {
		t.Errorf("expected 1 Python node, got %d", len(g.Nodes))
	}
	node := g.Nodes["app.py"]
	if node == nil {
		t.Fatal("expected app.py node")
	}
	if len(node.Imports) < 2 {
		t.Errorf("expected at least 2 imports, got %d: %v", len(node.Imports), node.Imports)
	}
}

func TestBuildEmptyDir(t *testing.T) {
	dir := t.TempDir()
	g, err := Build(dir, []string{".go"})
	if err != nil {
		t.Fatal(err)
	}
	if len(g.Nodes) != 0 {
		t.Errorf("expected 0 nodes in empty dir, got %d", len(g.Nodes))
	}
}

func containsSubstr(s, sub string) bool {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
