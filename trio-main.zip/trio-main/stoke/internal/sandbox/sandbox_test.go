package sandbox

import (
	"fmt"
	"os"
	"strings"
	"sync"
	"testing"
)

// ---------------------------------------------------------------------------
// Helper: mock filesystem hooks for detect() testing
// ---------------------------------------------------------------------------

var errNotExist = fmt.Errorf("not found")

func withMockedFS(t *testing.T, mStat func(string) (os.FileInfo, error), mRead func(string) ([]byte, error), mGetenv func(string) string) {
	t.Helper()
	origStat, origRead, origGetenv := statFile, readFile, getenv
	t.Cleanup(func() {
		statFile = origStat
		readFile = origRead
		getenv = origGetenv
	})
	statFile = mStat
	readFile = mRead
	getenv = mGetenv
}

// ---------------------------------------------------------------------------
// Environment detection -- basic
// ---------------------------------------------------------------------------

func TestDetect(t *testing.T) {
	env := Detect()
	if env.Platform == "" {
		t.Error("expected non-empty platform")
	}
	if env.ContainerType == "" {
		t.Error("expected non-empty container type")
	}
}

func TestDetectCachesResult(t *testing.T) {
	a := Detect()
	b := Detect()
	if a != b {
		t.Errorf("Detect() should return cached result; got %+v then %+v", a, b)
	}
}

func TestDetectViaOnceReset(t *testing.T) {
	oldEnv := detectedEnv
	t.Cleanup(func() {
		detectedEnv = oldEnv
		detectOnce = sync.Once{} // reset for next test
	})
	detectOnce = sync.Once{} // reset to force re-detection
	detectedEnv = nil

	env := Detect()
	if env.Platform == "" {
		t.Error("expected non-empty platform after reset")
	}
}

func TestDetectReturnsNonEmpty(t *testing.T) {
	env := detect()
	if env.Platform == "" {
		t.Error("expected non-empty Platform from detect()")
	}
	if env.ContainerType == "" {
		t.Error("expected non-empty ContainerType from detect()")
	}
}

// ---------------------------------------------------------------------------
// detect() -- mocked branches for every container type
// ---------------------------------------------------------------------------

func TestDetectDockerEnvFile(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/.dockerenv" || path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(string) ([]byte, error) { return nil, errNotExist },
		func(string) string { return "" },
	)
	env := detect()
	if !env.InContainer {
		t.Error("expected InContainer=true for docker env file")
	}
	if env.ContainerType != "docker" {
		t.Errorf("expected docker, got %s", env.ContainerType)
	}
	if env.Platform != "linux" {
		t.Errorf("expected linux platform, got %s", env.Platform)
	}
}

func TestDetectPodmanContainerEnv(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/run/.containerenv" || path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(string) ([]byte, error) { return nil, errNotExist },
		func(string) string { return "" },
	)
	env := detect()
	if !env.InContainer {
		t.Error("expected InContainer=true for podman")
	}
	if env.ContainerType != "podman" {
		t.Errorf("expected podman, got %s", env.ContainerType)
	}
}

func TestDetectCgroupDocker(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(path string) ([]byte, error) {
			if path == "/proc/1/cgroup" {
				return []byte("12:memory:/docker/abc123\n"), nil
			}
			return nil, errNotExist
		},
		func(string) string { return "" },
	)
	env := detect()
	if !env.InContainer {
		t.Error("expected InContainer=true for cgroup docker")
	}
	if env.ContainerType != "docker" {
		t.Errorf("expected docker, got %s", env.ContainerType)
	}
}

func TestDetectCgroupLXC(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(path string) ([]byte, error) {
			if path == "/proc/1/cgroup" {
				return []byte("12:memory:/lxc/container1\n"), nil
			}
			return nil, errNotExist
		},
		func(string) string { return "" },
	)
	env := detect()
	if !env.InContainer {
		t.Error("expected InContainer=true for lxc")
	}
	if env.ContainerType != "lxc" {
		t.Errorf("expected lxc, got %s", env.ContainerType)
	}
}

func TestDetectCgroupKubernetes(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(path string) ([]byte, error) {
			if path == "/proc/1/cgroup" {
				return []byte("12:memory:/kubepods/burstable/pod-xyz\n"), nil
			}
			return nil, errNotExist
		},
		func(string) string { return "" },
	)
	env := detect()
	if !env.InContainer {
		t.Error("expected InContainer=true for kubernetes")
	}
	if env.ContainerType != "kubernetes" {
		t.Errorf("expected kubernetes, got %s", env.ContainerType)
	}
}

func TestDetectWSL(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(path string) ([]byte, error) {
			if path == "/proc/1/cgroup" {
				return nil, errNotExist
			}
			if path == "/proc/version" {
				return []byte("Linux version 5.15.0 Microsoft standard WSL2"), nil
			}
			return nil, errNotExist
		},
		func(string) string { return "" },
	)
	env := detect()
	if !env.InContainer {
		t.Error("expected InContainer=true for WSL")
	}
	if env.ContainerType != "wsl" {
		t.Errorf("expected wsl, got %s", env.ContainerType)
	}
}

func TestDetectContainerEnvVarMocked(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(string) ([]byte, error) { return nil, errNotExist },
		func(key string) string {
			if key == "container" {
				return "systemd-nspawn"
			}
			return ""
		},
	)
	env := detect()
	if !env.InContainer {
		t.Error("expected InContainer=true for env var")
	}
	if env.ContainerType != "systemd-nspawn" {
		t.Errorf("expected systemd-nspawn, got %s", env.ContainerType)
	}
}

func TestDetectNoContainer(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(string) ([]byte, error) { return nil, errNotExist },
		func(string) string { return "" },
	)
	env := detect()
	if env.InContainer {
		t.Error("expected InContainer=false when nothing detected")
	}
	if env.ContainerType != "none" {
		t.Errorf("expected none, got %s", env.ContainerType)
	}
}

func TestDetectCgroupNoMatch(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(path string) ([]byte, error) {
			if path == "/proc/1/cgroup" {
				return []byte("12:memory:/user.slice/user-1000.slice\n"), nil
			}
			return nil, errNotExist
		},
		func(string) string { return "" },
	)
	env := detect()
	if env.ContainerType != "none" {
		t.Errorf("expected none when cgroup has no container markers, got %s", env.ContainerType)
	}
}

func TestDetectProcVersionNonWSL(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(path string) ([]byte, error) {
			if path == "/proc/version" {
				return []byte("Linux version 6.1.0-generic (gcc 12.3)"), nil
			}
			return nil, errNotExist
		},
		func(string) string { return "" },
	)
	env := detect()
	if env.InContainer {
		t.Error("expected InContainer=false for non-WSL /proc/version")
	}
	if env.ContainerType != "none" {
		t.Errorf("expected none, got %s", env.ContainerType)
	}
}

// ---------------------------------------------------------------------------
// detectPlatform
// ---------------------------------------------------------------------------

func TestDetectPlatformLinux(t *testing.T) {
	withMockedFS(t,
		func(path string) (os.FileInfo, error) {
			if path == "/proc/version" {
				return nil, nil
			}
			return nil, errNotExist
		},
		func(string) ([]byte, error) { return nil, errNotExist },
		func(string) string { return "" },
	)
	p := detectPlatform()
	if p != "linux" {
		t.Errorf("expected linux, got %s", p)
	}
}

func TestDetectPlatformUnknown(t *testing.T) {
	withMockedFS(t,
		func(string) (os.FileInfo, error) { return nil, errNotExist },
		func(string) ([]byte, error) { return nil, errNotExist },
		func(string) string { return "" },
	)
	p := detectPlatform()
	if p != "unknown" {
		t.Errorf("expected unknown when /proc/version missing, got %s", p)
	}
}

// ---------------------------------------------------------------------------
// Environment struct
// ---------------------------------------------------------------------------

func TestEnvironmentZeroValue(t *testing.T) {
	var env Environment
	if env.InContainer {
		t.Error("zero Environment should not be InContainer")
	}
	if env.HasSandbox {
		t.Error("zero Environment should not HasSandbox")
	}
	if env.ContainerType != "" {
		t.Error("zero Environment should have empty ContainerType")
	}
	if env.Platform != "" {
		t.Error("zero Environment should have empty Platform")
	}
}

// ---------------------------------------------------------------------------
// DefaultPolicy
// ---------------------------------------------------------------------------

func TestDefaultPolicy(t *testing.T) {
	p := DefaultPolicy()
	if !p.Enabled {
		t.Error("expected sandbox enabled by default")
	}
	if !p.FailIfUnavailable {
		t.Error("expected fail-closed by default")
	}
	if len(p.AllowedDomains) == 0 {
		t.Error("expected default allowed domains")
	}
}

func TestDefaultPolicyDomains(t *testing.T) {
	p := DefaultPolicy()
	expected := []string{
		"api.anthropic.com",
		"api.openai.com",
		"api.github.com",
		"github.com",
		"registry.npmjs.org",
		"pypi.org",
	}
	if len(p.AllowedDomains) != len(expected) {
		t.Fatalf("expected %d domains, got %d", len(expected), len(p.AllowedDomains))
	}
	for i, d := range expected {
		if p.AllowedDomains[i] != d {
			t.Errorf("domain[%d]: expected %q, got %q", i, d, p.AllowedDomains[i])
		}
	}
}

func TestDefaultPolicyNoPaths(t *testing.T) {
	p := DefaultPolicy()
	if len(p.AllowedReadPaths) != 0 {
		t.Errorf("default should have no read paths, got %v", p.AllowedReadPaths)
	}
	if len(p.AllowedWritePaths) != 0 {
		t.Errorf("default should have no write paths, got %v", p.AllowedWritePaths)
	}
}

func TestDefaultPolicyNetworkAllowed(t *testing.T) {
	p := DefaultPolicy()
	if p.DenyNetworkAccess {
		t.Error("default policy should allow network access")
	}
}

func TestDefaultPolicyIsIndependent(t *testing.T) {
	a := DefaultPolicy()
	b := DefaultPolicy()
	a.AllowedDomains[0] = "mutated.example.com"
	if b.AllowedDomains[0] == "mutated.example.com" {
		t.Error("mutating one DefaultPolicy should not affect another")
	}
}

// ---------------------------------------------------------------------------
// ReadOnlyPolicy
// ---------------------------------------------------------------------------

func TestReadOnlyPolicy(t *testing.T) {
	p := ReadOnlyPolicy()
	if !p.DenyNetworkAccess {
		t.Error("expected network denied in read-only")
	}
}

func TestReadOnlyPolicyInheritsDefaults(t *testing.T) {
	p := ReadOnlyPolicy()
	d := DefaultPolicy()
	if !p.Enabled {
		t.Error("read-only policy should be enabled")
	}
	if !p.FailIfUnavailable {
		t.Error("read-only policy should fail-closed")
	}
	if len(p.AllowedDomains) != len(d.AllowedDomains) {
		t.Errorf("read-only policy should inherit default domains; got %d, want %d",
			len(p.AllowedDomains), len(d.AllowedDomains))
	}
}

func TestReadOnlyPolicyIsIndependent(t *testing.T) {
	a := ReadOnlyPolicy()
	b := ReadOnlyPolicy()
	a.AllowedDomains = append(a.AllowedDomains, "extra.com")
	if len(a.AllowedDomains) == len(b.AllowedDomains) {
		t.Error("mutating one ReadOnlyPolicy should not affect another")
	}
}

// ---------------------------------------------------------------------------
// Policy.Validate
// ---------------------------------------------------------------------------

func TestValidateReturnsNil(t *testing.T) {
	p := DefaultPolicy()
	if err := p.Validate(); err != nil {
		t.Errorf("Validate() should return nil, got %v", err)
	}
}

func TestValidateZeroPolicy(t *testing.T) {
	var p Policy
	if err := p.Validate(); err != nil {
		t.Errorf("Validate() on zero policy should return nil, got %v", err)
	}
}

func TestValidateDisabledPolicy(t *testing.T) {
	p := Policy{Enabled: false}
	if err := p.Validate(); err != nil {
		t.Errorf("Validate() on disabled policy should return nil, got %v", err)
	}
}

// ---------------------------------------------------------------------------
// Policy zero-value defaults
// ---------------------------------------------------------------------------

func TestPolicyFieldDefaults(t *testing.T) {
	var p Policy
	if p.Enabled {
		t.Error("zero Policy should not be enabled")
	}
	if p.FailIfUnavailable {
		t.Error("zero Policy should not FailIfUnavailable")
	}
	if p.DenyNetworkAccess {
		t.Error("zero Policy should not DenyNetworkAccess")
	}
	if p.AllowedDomains != nil {
		t.Error("zero Policy should have nil AllowedDomains")
	}
	if p.AllowedReadPaths != nil {
		t.Error("zero Policy should have nil AllowedReadPaths")
	}
	if p.AllowedWritePaths != nil {
		t.Error("zero Policy should have nil AllowedWritePaths")
	}
}

// ---------------------------------------------------------------------------
// SandboxArgs -- comprehensive
// ---------------------------------------------------------------------------

func TestSandboxArgs(t *testing.T) {
	p := Policy{
		Enabled:          true,
		AllowedDomains:   []string{"api.anthropic.com", "api.github.com"},
		AllowedReadPaths: []string{"/tmp"},
	}
	args := p.SandboxArgs()
	if len(args) != 6 {
		t.Errorf("expected 6 args, got %d: %v", len(args), args)
	}
}

func TestSandboxArgsDisabled(t *testing.T) {
	p := Policy{Enabled: false}
	args := p.SandboxArgs()
	if len(args) != 0 {
		t.Errorf("expected no args when disabled, got %v", args)
	}
}

func TestSandboxArgsWritePaths(t *testing.T) {
	p := Policy{
		Enabled:           true,
		AllowedWritePaths: []string{"/tmp/output", "/var/data"},
	}
	args := p.SandboxArgs()
	if len(args) != 4 {
		t.Fatalf("expected 4 args for 2 write paths, got %d: %v", len(args), args)
	}
	if args[0] != "--sandbox-allow-write" || args[1] != "/tmp/output" {
		t.Errorf("unexpected first write pair: %v %v", args[0], args[1])
	}
	if args[2] != "--sandbox-allow-write" || args[3] != "/var/data" {
		t.Errorf("unexpected second write pair: %v %v", args[2], args[3])
	}
}

func TestSandboxArgsAllTypes(t *testing.T) {
	p := Policy{
		Enabled:           true,
		AllowedDomains:    []string{"example.com"},
		AllowedReadPaths:  []string{"/r1", "/r2"},
		AllowedWritePaths: []string{"/w1"},
	}
	args := p.SandboxArgs()
	if len(args) != 8 {
		t.Fatalf("expected 8 args, got %d: %v", len(args), args)
	}
	joined := strings.Join(args, " ")
	if !strings.Contains(joined, "--sandbox-allow-domain example.com") {
		t.Error("missing domain arg")
	}
	if !strings.Contains(joined, "--sandbox-allow-read /r1") {
		t.Error("missing read /r1 arg")
	}
	if !strings.Contains(joined, "--sandbox-allow-read /r2") {
		t.Error("missing read /r2 arg")
	}
	if !strings.Contains(joined, "--sandbox-allow-write /w1") {
		t.Error("missing write /w1 arg")
	}
}

func TestSandboxArgsOrdering(t *testing.T) {
	p := Policy{
		Enabled:           true,
		AllowedDomains:    []string{"d"},
		AllowedReadPaths:  []string{"/r"},
		AllowedWritePaths: []string{"/w"},
	}
	args := p.SandboxArgs()
	if args[0] != "--sandbox-allow-domain" {
		t.Errorf("expected domains first, got %s", args[0])
	}
	if args[2] != "--sandbox-allow-read" {
		t.Errorf("expected reads second, got %s", args[2])
	}
	if args[4] != "--sandbox-allow-write" {
		t.Errorf("expected writes third, got %s", args[4])
	}
}

func TestSandboxArgsEmptyLists(t *testing.T) {
	p := Policy{
		Enabled:           true,
		AllowedDomains:    []string{},
		AllowedReadPaths:  []string{},
		AllowedWritePaths: []string{},
	}
	args := p.SandboxArgs()
	if len(args) != 0 {
		t.Errorf("expected no args for empty lists, got %v", args)
	}
}

func TestSandboxArgsNilLists(t *testing.T) {
	p := Policy{
		Enabled:           true,
		AllowedDomains:    nil,
		AllowedReadPaths:  nil,
		AllowedWritePaths: nil,
	}
	args := p.SandboxArgs()
	if args != nil {
		t.Errorf("expected nil args for nil lists, got %v", args)
	}
}

func TestSandboxArgsOnlyDomains(t *testing.T) {
	p := Policy{
		Enabled:        true,
		AllowedDomains: []string{"a.com", "b.com", "c.com"},
	}
	args := p.SandboxArgs()
	if len(args) != 6 {
		t.Fatalf("expected 6 args for 3 domains, got %d", len(args))
	}
	for i := 0; i < 6; i += 2 {
		if args[i] != "--sandbox-allow-domain" {
			t.Errorf("arg[%d] should be --sandbox-allow-domain, got %s", i, args[i])
		}
	}
}

func TestSandboxArgsOnlyReads(t *testing.T) {
	p := Policy{
		Enabled:          true,
		AllowedReadPaths: []string{"/a", "/b"},
	}
	args := p.SandboxArgs()
	if len(args) != 4 {
		t.Fatalf("expected 4 args for 2 read paths, got %d", len(args))
	}
	for i := 0; i < 4; i += 2 {
		if args[i] != "--sandbox-allow-read" {
			t.Errorf("arg[%d] should be --sandbox-allow-read, got %s", i, args[i])
		}
	}
}

func TestSandboxArgsOnlyWrites(t *testing.T) {
	p := Policy{
		Enabled:           true,
		AllowedWritePaths: []string{"/x"},
	}
	args := p.SandboxArgs()
	if len(args) != 2 {
		t.Fatalf("expected 2 args for 1 write path, got %d", len(args))
	}
	if args[0] != "--sandbox-allow-write" || args[1] != "/x" {
		t.Errorf("unexpected args: %v", args)
	}
}

// ---------------------------------------------------------------------------
// Edge cases: overlapping and duplicate paths/domains
// ---------------------------------------------------------------------------

func TestSandboxArgsOverlappingPaths(t *testing.T) {
	p := Policy{
		Enabled:           true,
		AllowedReadPaths:  []string{"/home", "/home/user", "/home/user/docs"},
		AllowedWritePaths: []string{"/home/user/docs"},
	}
	args := p.SandboxArgs()
	if len(args) != 8 {
		t.Fatalf("expected 8 args for overlapping paths, got %d: %v", len(args), args)
	}
}

func TestSandboxArgsDuplicateDomains(t *testing.T) {
	p := Policy{
		Enabled:        true,
		AllowedDomains: []string{"api.com", "api.com", "api.com"},
	}
	args := p.SandboxArgs()
	if len(args) != 6 {
		t.Fatalf("expected 6 args for 3 duplicate domains, got %d", len(args))
	}
}

func TestSandboxArgsSamePathReadAndWrite(t *testing.T) {
	p := Policy{
		Enabled:           true,
		AllowedReadPaths:  []string{"/shared"},
		AllowedWritePaths: []string{"/shared"},
	}
	args := p.SandboxArgs()
	if len(args) != 4 {
		t.Fatalf("expected 4 args, got %d: %v", len(args), args)
	}
	if args[0] != "--sandbox-allow-read" || args[1] != "/shared" {
		t.Errorf("expected read pair first, got %v %v", args[0], args[1])
	}
	if args[2] != "--sandbox-allow-write" || args[3] != "/shared" {
		t.Errorf("expected write pair second, got %v %v", args[2], args[3])
	}
}

func TestSandboxArgsManyEntries(t *testing.T) {
	var domains, reads, writes []string
	for i := 0; i < 50; i++ {
		domains = append(domains, "domain.example.com")
		reads = append(reads, "/read/path")
		writes = append(writes, "/write/path")
	}
	p := Policy{
		Enabled:           true,
		AllowedDomains:    domains,
		AllowedReadPaths:  reads,
		AllowedWritePaths: writes,
	}
	args := p.SandboxArgs()
	expected := 300
	if len(args) != expected {
		t.Errorf("expected %d args, got %d", expected, len(args))
	}
}

func TestSandboxArgsSingleDomain(t *testing.T) {
	p := Policy{
		Enabled:        true,
		AllowedDomains: []string{"one.example.com"},
	}
	args := p.SandboxArgs()
	if len(args) != 2 {
		t.Fatalf("expected 2 args, got %d", len(args))
	}
	if args[0] != "--sandbox-allow-domain" {
		t.Errorf("expected --sandbox-allow-domain, got %s", args[0])
	}
	if args[1] != "one.example.com" {
		t.Errorf("expected one.example.com, got %s", args[1])
	}
}

// ---------------------------------------------------------------------------
// Domain allowlist checking (via SandboxArgs output)
// ---------------------------------------------------------------------------

func TestDefaultPolicyDomainAllowlist(t *testing.T) {
	p := DefaultPolicy()
	args := p.SandboxArgs()

	allowed := map[string]bool{
		"api.anthropic.com":  false,
		"api.openai.com":     false,
		"api.github.com":     false,
		"github.com":         false,
		"registry.npmjs.org": false,
		"pypi.org":           false,
	}
	for i := 0; i < len(args)-1; i += 2 {
		if args[i] == "--sandbox-allow-domain" {
			if _, ok := allowed[args[i+1]]; ok {
				allowed[args[i+1]] = true
			}
		}
	}
	for d, found := range allowed {
		if !found {
			t.Errorf("expected domain %q in sandbox args", d)
		}
	}
}

func TestSandboxArgsDomainValues(t *testing.T) {
	domains := []string{"x.io", "y.io", "z.io"}
	p := Policy{Enabled: true, AllowedDomains: domains}
	args := p.SandboxArgs()
	var got []string
	for i := 0; i < len(args)-1; i += 2 {
		if args[i] == "--sandbox-allow-domain" {
			got = append(got, args[i+1])
		}
	}
	if len(got) != len(domains) {
		t.Fatalf("expected %d domains, got %d", len(domains), len(got))
	}
	for i, d := range domains {
		if got[i] != d {
			t.Errorf("domain[%d]: expected %q, got %q", i, d, got[i])
		}
	}
}
