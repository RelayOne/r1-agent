package snapshot

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func setupGitRepo(t *testing.T) string {
	t.Helper()
	dir := t.TempDir()

	cmds := [][]string{
		{"git", "init"},
		{"git", "config", "user.email", "test@test.com"},
		{"git", "config", "user.name", "Test"},
	}

	for _, c := range cmds {
		cmd := exec.Command(c[0], c[1:]...)
		cmd.Dir = dir
		if err := cmd.Run(); err != nil {
			t.Fatalf("setup %v: %v", c, err)
		}
	}

	// Create initial commit
	if err := os.WriteFile(filepath.Join(dir, "README.md"), []byte("# Test"), 0644); err != nil {
		t.Fatal(err)
	}
	cmd := exec.Command("git", "add", ".")
	cmd.Dir = dir
	if err := cmd.Run(); err != nil {
		t.Fatal(err)
	}
	cmd = exec.Command("git", "commit", "-m", "initial", "--no-gpg-sign")
	cmd.Dir = dir
	if err := cmd.Run(); err != nil {
		t.Fatalf("initial commit: %v", err)
	}

	return dir
}

func TestTake(t *testing.T) {
	dir := setupGitRepo(t)

	snap, err := Take(dir, "test-snap")
	if err != nil {
		t.Fatal(err)
	}

	if snap.Branch == "" {
		t.Error("branch should not be empty")
	}
	if snap.Commit == "" {
		t.Error("commit should not be empty")
	}
	if snap.Label != "test-snap" {
		t.Errorf("expected label test-snap, got %s", snap.Label)
	}
}

func TestTakeWithModifiedFiles(t *testing.T) {
	dir := setupGitRepo(t)

	// Modify a tracked file
	if err := os.WriteFile(filepath.Join(dir, "README.md"), []byte("# Modified"), 0644); err != nil {
		t.Fatal(err)
	}
	// Add an untracked file
	if err := os.WriteFile(filepath.Join(dir, "new.txt"), []byte("new"), 0644); err != nil {
		t.Fatal(err)
	}

	snap, err := Take(dir, "modified")
	if err != nil {
		t.Fatal(err)
	}

	if len(snap.Modified) == 0 {
		t.Error("should capture modified files")
	}
	if len(snap.Untracked) == 0 {
		t.Error("should capture untracked files")
	}
}

func TestSaveAndLoad(t *testing.T) {
	dir := setupGitRepo(t)

	snap, err := Take(dir, "save-load")
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "snap.json")

	if err := Save(snap, path); err != nil {
		t.Fatal(err)
	}

	loaded, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}

	if loaded.Branch != snap.Branch {
		t.Errorf("branch mismatch: %s vs %s", loaded.Branch, snap.Branch)
	}
	if loaded.Commit != snap.Commit {
		t.Errorf("commit mismatch")
	}
}

func TestLoadNotFound(t *testing.T) {
	_, err := Load("/nonexistent/path")
	if err == nil {
		t.Error("should error on missing file")
	}
}

func TestSummary(t *testing.T) {
	snap := &Snapshot{
		Label:    "test",
		Branch:   "main",
		Commit:   "abc123def456",
		Modified: []FileState{{Path: "a.go"}},
	}

	s := snap.Summary()
	if s == "" {
		t.Error("summary should not be empty")
	}
}

func TestDiff(t *testing.T) {
	a := &Snapshot{
		Branch:   "main",
		Commit:   "aaaa1111",
		Modified: []FileState{{Path: "a.go"}},
	}
	b := &Snapshot{
		Branch:   "feature",
		Commit:   "bbbb2222",
		Modified: []FileState{{Path: "a.go"}, {Path: "b.go"}},
	}

	diffs := Diff(a, b)
	if len(diffs) == 0 {
		t.Error("should detect differences")
	}

	hasBranch := false
	hasNew := false
	for _, d := range diffs {
		if d == "branch: main -> feature" {
			hasBranch = true
		}
		if d == "new modified: b.go" {
			hasNew = true
		}
	}
	if !hasBranch {
		// Check with Unicode arrow too
		for _, d := range diffs {
			if strings.Contains(d, "branch:") && strings.Contains(d, "main") && strings.Contains(d, "feature") {
				hasBranch = true
			}
		}
	}
	if !hasBranch {
		t.Errorf("should detect branch change, got diffs: %v", diffs)
	}
	if !hasNew {
		t.Error("should detect new modified file")
	}
}

func TestFileState(t *testing.T) {
	dir := setupGitRepo(t)

	// Create a file with specific content
	content := []byte("package main\nfunc main() {}\n")
	if err := os.WriteFile(filepath.Join(dir, "main.go"), content, 0644); err != nil {
		t.Fatal(err)
	}

	snap, err := Take(dir, "filestate")
	if err != nil {
		t.Fatal(err)
	}

	found := false
	for _, f := range snap.Modified {
		if f.Path == "main.go" {
			found = true
			if string(f.Content) != string(content) {
				t.Error("content mismatch")
			}
		}
	}
	if !found {
		t.Error("should capture main.go")
	}
}

// --- New tests below ---

func TestTakeCleanRepo(t *testing.T) {
	dir := setupGitRepo(t)

	snap, err := Take(dir, "clean")
	if err != nil {
		t.Fatal(err)
	}
	if len(snap.Modified) != 0 {
		t.Errorf("clean repo should have 0 modified files, got %d", len(snap.Modified))
	}
	if len(snap.Staged) != 0 {
		t.Errorf("clean repo should have 0 staged files, got %d", len(snap.Staged))
	}
	if len(snap.Untracked) != 0 {
		t.Errorf("clean repo should have 0 untracked files, got %d", len(snap.Untracked))
	}
}

func TestTakeCaptureStagedFiles(t *testing.T) {
	dir := setupGitRepo(t)

	// Create and stage a new file
	if err := os.WriteFile(filepath.Join(dir, "staged.txt"), []byte("staged content"), 0644); err != nil {
		t.Fatal(err)
	}
	cmd := exec.Command("git", "add", "staged.txt")
	cmd.Dir = dir
	if err := cmd.Run(); err != nil {
		t.Fatal(err)
	}

	snap, err := Take(dir, "staged")
	if err != nil {
		t.Fatal(err)
	}
	if len(snap.Staged) == 0 {
		t.Error("should capture staged files")
	}
	foundStaged := false
	for _, f := range snap.Staged {
		if f == "staged.txt" {
			foundStaged = true
		}
	}
	if !foundStaged {
		t.Errorf("staged.txt not found in staged list: %v", snap.Staged)
	}
}

func TestTakeCapturesEnvVars(t *testing.T) {
	dir := setupGitRepo(t)

	snap, err := Take(dir, "env-test")
	if err != nil {
		t.Fatal(err)
	}
	// PATH should always be present in the environment
	if _, ok := snap.Env["PATH"]; !ok {
		t.Error("should capture PATH environment variable")
	}
}

func TestTakeIDAndTimestamp(t *testing.T) {
	dir := setupGitRepo(t)

	snap, err := Take(dir, "id-test")
	if err != nil {
		t.Fatal(err)
	}
	if snap.ID == "" {
		t.Error("ID should not be empty")
	}
	if !strings.HasPrefix(snap.ID, "snap-") {
		t.Errorf("ID should start with snap-, got %q", snap.ID)
	}
	if snap.CreatedAt.IsZero() {
		t.Error("CreatedAt should not be zero")
	}
	if snap.Dir != dir {
		t.Errorf("Dir=%q, want %q", snap.Dir, dir)
	}
}

func TestTakeInvalidDir(t *testing.T) {
	_, err := Take("/nonexistent/dir/that/does/not/exist", "bad")
	if err == nil {
		t.Error("should error on nonexistent directory")
	}
}

func TestSaveAndLoadRoundtripWithModifiedFiles(t *testing.T) {
	dir := setupGitRepo(t)

	content := []byte("modified content here")
	if err := os.WriteFile(filepath.Join(dir, "README.md"), content, 0644); err != nil {
		t.Fatal(err)
	}

	snap, err := Take(dir, "roundtrip")
	if err != nil {
		t.Fatal(err)
	}

	savePath := filepath.Join(t.TempDir(), "snap.json")
	if err := Save(snap, savePath); err != nil {
		t.Fatal(err)
	}

	loaded, err := Load(savePath)
	if err != nil {
		t.Fatal(err)
	}

	if loaded.Label != "roundtrip" {
		t.Errorf("label=%q", loaded.Label)
	}
	if loaded.ID != snap.ID {
		t.Errorf("ID mismatch: %q vs %q", loaded.ID, snap.ID)
	}
	if len(loaded.Modified) != len(snap.Modified) {
		t.Errorf("modified count: %d vs %d", len(loaded.Modified), len(snap.Modified))
	}
	// Verify file content survives roundtrip
	for _, f := range loaded.Modified {
		if f.Path == "README.md" {
			if string(f.Content) != string(content) {
				t.Error("file content should survive save/load roundtrip")
			}
		}
	}
}

func TestLoadCorruptJSON(t *testing.T) {
	path := filepath.Join(t.TempDir(), "bad.json")
	if err := os.WriteFile(path, []byte("not valid json {{{"), 0644); err != nil {
		t.Fatal(err)
	}
	_, err := Load(path)
	if err == nil {
		t.Error("should error on corrupt JSON")
	}
}

func TestDiffIdenticalSnapshots(t *testing.T) {
	a := &Snapshot{
		Branch:   "main",
		Commit:   "aaaa1111",
		Modified: []FileState{{Path: "a.go"}},
	}
	b := &Snapshot{
		Branch:   "main",
		Commit:   "aaaa1111",
		Modified: []FileState{{Path: "a.go"}},
	}

	diffs := Diff(a, b)
	if len(diffs) != 0 {
		t.Errorf("identical snapshots should have no diffs, got %v", diffs)
	}
}

func TestDiffDetectsRemovedFile(t *testing.T) {
	a := &Snapshot{
		Branch:   "main",
		Commit:   "aaaa1111",
		Modified: []FileState{{Path: "a.go"}, {Path: "b.go"}},
	}
	b := &Snapshot{
		Branch:   "main",
		Commit:   "aaaa1111",
		Modified: []FileState{{Path: "a.go"}},
	}

	diffs := Diff(a, b)
	foundRemoved := false
	for _, d := range diffs {
		if strings.Contains(d, "no longer modified") && strings.Contains(d, "b.go") {
			foundRemoved = true
		}
	}
	if !foundRemoved {
		t.Errorf("should detect removed modified file, got %v", diffs)
	}
}

func TestDiffCommitChange(t *testing.T) {
	a := &Snapshot{Branch: "main", Commit: "aaaa1111bbbb"}
	b := &Snapshot{Branch: "main", Commit: "cccc2222dddd"}

	diffs := Diff(a, b)
	foundCommit := false
	for _, d := range diffs {
		if strings.Contains(d, "commit:") {
			foundCommit = true
		}
	}
	if !foundCommit {
		t.Errorf("should detect commit change, got %v", diffs)
	}
}

func TestDiffEmptySnapshots(t *testing.T) {
	a := &Snapshot{Branch: "main", Commit: "aaaa1111"}
	b := &Snapshot{Branch: "main", Commit: "aaaa1111"}

	diffs := Diff(a, b)
	if len(diffs) != 0 {
		t.Errorf("empty identical snapshots should have no diffs, got %v", diffs)
	}
}

func TestSummaryFormats(t *testing.T) {
	snap := &Snapshot{
		Label:     "pre-refactor",
		Branch:    "feature/auth",
		Commit:    "abc123def456789",
		Modified:  []FileState{{Path: "a.go"}, {Path: "b.go"}},
		Staged:    []string{"c.go"},
		Untracked: []string{"d.go", "e.go", "f.go"},
	}

	s := snap.Summary()
	if !strings.Contains(s, "pre-refactor") {
		t.Errorf("summary should contain label, got %q", s)
	}
	if !strings.Contains(s, "feature/auth") {
		t.Errorf("summary should contain branch, got %q", s)
	}
	if !strings.Contains(s, "2 modified") {
		t.Errorf("summary should show 2 modified, got %q", s)
	}
	if !strings.Contains(s, "1 staged") {
		t.Errorf("summary should show 1 staged, got %q", s)
	}
	if !strings.Contains(s, "3 untracked") {
		t.Errorf("summary should show 3 untracked, got %q", s)
	}
}

func TestSummaryShortCommit(t *testing.T) {
	// Commit shorter than 8 chars should not panic
	snap := &Snapshot{
		Label:  "short",
		Branch: "main",
		Commit: "abc",
	}
	s := snap.Summary()
	if !strings.Contains(s, "abc") {
		t.Errorf("summary should handle short commit, got %q", s)
	}
}

func TestSummaryEmptyCommit(t *testing.T) {
	snap := &Snapshot{
		Label:  "empty",
		Branch: "main",
		Commit: "",
	}
	// Should not panic on empty commit
	s := snap.Summary()
	if s == "" {
		t.Error("summary should not be empty even with empty commit")
	}
}

func TestRestoreAppliesFileContent(t *testing.T) {
	dir := setupGitRepo(t)

	// Take a snapshot of the clean state
	snap, err := Take(dir, "before-change")
	if err != nil {
		t.Fatal(err)
	}

	// Now modify a file
	if err := os.WriteFile(filepath.Join(dir, "README.md"), []byte("# Changed"), 0644); err != nil {
		t.Fatal(err)
	}

	// Restore should reset to the snapshot state
	if err := Restore(snap); err != nil {
		t.Fatal(err)
	}

	// Verify the file is back to original
	data, err := os.ReadFile(filepath.Join(dir, "README.md"))
	if err != nil {
		t.Fatal(err)
	}
	if string(data) != "# Test" {
		t.Errorf("file should be restored to original content, got %q", string(data))
	}
}

func TestRestoreWithModifiedSnapshot(t *testing.T) {
	dir := setupGitRepo(t)

	// Create modified state and snapshot it
	modContent := []byte("# Modified for snapshot")
	if err := os.WriteFile(filepath.Join(dir, "README.md"), modContent, 0644); err != nil {
		t.Fatal(err)
	}
	snap, err := Take(dir, "modified-state")
	if err != nil {
		t.Fatal(err)
	}

	// Commit to move HEAD forward
	cmd := exec.Command("git", "add", ".")
	cmd.Dir = dir
	if err := cmd.Run(); err != nil {
		t.Fatal(err)
	}
	cmd = exec.Command("git", "commit", "-m", "second commit", "--no-gpg-sign")
	cmd.Dir = dir
	if err := cmd.Run(); err != nil {
		t.Fatal(err)
	}

	// Change file again
	if err := os.WriteFile(filepath.Join(dir, "README.md"), []byte("# Changed again"), 0644); err != nil {
		t.Fatal(err)
	}

	// Restore to the snapshot -- this resets git to the original commit
	// and re-applies the modified files from the snapshot
	if err := Restore(snap); err != nil {
		t.Fatal(err)
	}

	data, err := os.ReadFile(filepath.Join(dir, "README.md"))
	if err != nil {
		t.Fatal(err)
	}
	if string(data) != string(modContent) {
		t.Errorf("file should be restored to snapshot content, got %q", string(data))
	}
}

func TestTakeMultipleFiles(t *testing.T) {
	dir := setupGitRepo(t)

	// Create several modified/untracked files
	files := map[string]string{
		"a.txt": "file a",
		"b.txt": "file b",
		"c.txt": "file c",
	}
	for name, content := range files {
		if err := os.WriteFile(filepath.Join(dir, name), []byte(content), 0644); err != nil {
			t.Fatal(err)
		}
	}

	snap, err := Take(dir, "multi")
	if err != nil {
		t.Fatal(err)
	}

	if len(snap.Untracked) < 3 {
		t.Errorf("should have at least 3 untracked files, got %d: %v", len(snap.Untracked), snap.Untracked)
	}

	// Verify file content captured
	capturedPaths := make(map[string]bool)
	for _, f := range snap.Modified {
		capturedPaths[f.Path] = true
	}
	for name := range files {
		if !capturedPaths[name] {
			t.Errorf("should capture %s in modified files", name)
		}
	}
}

func TestSaveToNestedDir(t *testing.T) {
	base := t.TempDir()
	dir := setupGitRepo(t)

	snap, err := Take(dir, "nested")
	if err != nil {
		t.Fatal(err)
	}

	nestedPath := filepath.Join(base, "deep", "nested", "snap.json")
	// Save should fail because the parent directory doesn't exist
	// (Save does not create parent dirs)
	err = Save(snap, nestedPath)
	if err == nil {
		t.Error("should fail when parent directory doesn't exist")
	}
}

func TestSaveOverwritesExisting(t *testing.T) {
	dir := setupGitRepo(t)

	snap1, err := Take(dir, "first")
	if err != nil {
		t.Fatal(err)
	}

	savePath := filepath.Join(t.TempDir(), "snap.json")
	if err := Save(snap1, savePath); err != nil {
		t.Fatal(err)
	}

	// Modify and take second snapshot
	if err := os.WriteFile(filepath.Join(dir, "new.txt"), []byte("new"), 0644); err != nil {
		t.Fatal(err)
	}
	snap2, err := Take(dir, "second")
	if err != nil {
		t.Fatal(err)
	}

	// Save to same path should overwrite
	if err := Save(snap2, savePath); err != nil {
		t.Fatal(err)
	}

	loaded, err := Load(savePath)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.Label != "second" {
		t.Errorf("should load overwritten snapshot, got label %q", loaded.Label)
	}
}

func TestTakeSubdirectoryFiles(t *testing.T) {
	dir := setupGitRepo(t)

	// Create and commit a file in a subdirectory so it becomes tracked
	subdir := filepath.Join(dir, "pkg", "auth")
	if err := os.MkdirAll(subdir, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(subdir, "auth.go"), []byte("package auth"), 0644); err != nil {
		t.Fatal(err)
	}
	cmd := exec.Command("git", "add", ".")
	cmd.Dir = dir
	if err := cmd.Run(); err != nil {
		t.Fatal(err)
	}
	cmd = exec.Command("git", "commit", "-m", "add auth", "--no-gpg-sign")
	cmd.Dir = dir
	if err := cmd.Run(); err != nil {
		t.Fatal(err)
	}

	// Now modify the tracked file -- git status will report it as a file path
	if err := os.WriteFile(filepath.Join(subdir, "auth.go"), []byte("package auth\n// updated"), 0644); err != nil {
		t.Fatal(err)
	}

	snap, err := Take(dir, "subdir")
	if err != nil {
		t.Fatal(err)
	}

	foundSubdirFile := false
	for _, f := range snap.Modified {
		if strings.Contains(f.Path, "auth.go") {
			foundSubdirFile = true
			if !strings.Contains(string(f.Content), "// updated") {
				t.Error("subdirectory file content mismatch")
			}
		}
	}
	if !foundSubdirFile {
		t.Error("should capture modified files in subdirectories")
	}
}
