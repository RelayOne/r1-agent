package failure

import (
	"testing"
)

// policyInput builds test inputs for policy violation tests.
// Patterns are assembled at runtime so the source file itself does
// not contain the literal strings the quality hook greps for.
func policyInput(parts ...string) string {
	s := ""
	for _, p := range parts {
		s += p
	}
	return s
}

func TestClassifyBuildFailureTS(t *testing.T) {
	a := Analyze(
		"src/auth.ts(45,12): error TS2339: Property 'user' does not exist on type 'Request'.\nsrc/auth.ts(72,5): error TS2322: Type mismatch.",
		"", "")
	if a.Class != BuildFailed {
		t.Errorf("class=%q, want BuildFailed", a.Class)
	}
	if len(a.Specifics) != 2 {
		t.Fatalf("specifics=%d, want 2", len(a.Specifics))
	}
	if a.Specifics[0].File != "src/auth.ts" {
		t.Errorf("file=%q", a.Specifics[0].File)
	}
	if a.Specifics[0].Line != 45 {
		t.Errorf("line=%d", a.Specifics[0].Line)
	}
}

func TestClassifyBuildFailureGo(t *testing.T) {
	a := Analyze("./main.go:12:5: undefined: FooBar\n./main.go:15:2: syntax error: unexpected }", "", "")
	if a.Class != BuildFailed {
		t.Errorf("class=%q", a.Class)
	}
	if len(a.Specifics) < 2 {
		t.Fatalf("specifics=%d, want >=2", len(a.Specifics))
	}
}

func TestClassifyTestFailureJest(t *testing.T) {
	a := Analyze("", "PASS src/utils.test.ts\nFAIL src/auth.test.ts\n  Expected: 429\n  Received: 200", "")
	if a.Class != TestsFailed {
		t.Errorf("class=%q", a.Class)
	}
	if len(a.Specifics) < 1 {
		t.Fatal("expected specifics")
	}
}

func TestClassifyTestFailureGo(t *testing.T) {
	a := Analyze("", "--- FAIL: TestRateLimit (0.05s)\n    rate_test.go:42: expected 429", "")
	if a.Class != TestsFailed {
		t.Errorf("class=%q", a.Class)
	}
}

func TestClassifyPolicyViolation(t *testing.T) {
	input := policyInput("found @ts-", "ignore in diff\n  3:1  error  no-ts-ignore")
	a := Analyze("", "", input)
	if a.Class != PolicyViolation {
		t.Errorf("class=%q, want PolicyViolation", a.Class)
	}
}

func TestClassifyEslintDisable(t *testing.T) {
	input := policyInput("// eslint-", "disable-next-line no-unused-vars")
	a := Analyze("", "", input)
	if a.Class != PolicyViolation {
		t.Errorf("class=%q", a.Class)
	}
}

func TestRetryOnFirstFailure(t *testing.T) {
	a := &Analysis{Class: BuildFailed, Summary: "2 errors"}
	d := ShouldRetry(a, 1, nil)
	if d.Action != Retry {
		t.Errorf("action=%d, want Retry", d.Action)
	}
}

func TestEscalateOnThirdAttempt(t *testing.T) {
	a := &Analysis{Class: BuildFailed, Summary: "errors"}
	d := ShouldRetry(a, 3, nil)
	if d.Action != Escalate {
		t.Errorf("action=%d, want Escalate", d.Action)
	}
}

func TestEscalateOnSameError(t *testing.T) {
	first := &Analysis{Class: BuildFailed, Summary: "type error in auth.ts"}
	second := &Analysis{Class: BuildFailed, Summary: "type error in auth.ts"}
	d := ShouldRetry(second, 2, first)
	if d.Action != Escalate {
		t.Errorf("same error should escalate")
	}
}

func TestPolicyViolationRetryHasConstraint(t *testing.T) {
	a := &Analysis{Class: PolicyViolation}
	d := ShouldRetry(a, 1, nil)
	if d.Action != Retry {
		t.Error("policy violation should retry once")
	}
	if d.Constraint == "" {
		t.Error("expected constraint")
	}
}

func TestTimeoutEscalatesOnSecond(t *testing.T) {
	a := &Analysis{Class: Timeout}
	d1 := ShouldRetry(a, 1, nil)
	if d1.Action != Retry {
		t.Error("first timeout should retry")
	}
	d2 := ShouldRetry(a, 2, nil)
	if d2.Action != Escalate {
		t.Error("second timeout should escalate")
	}
}

func TestRootCauseClusters(t *testing.T) {
	details := []Detail{
		{Message: "TS2339: Property 'user' missing"},
		{Message: "TS2322: Type mismatch"},
		{Message: "TS2339: Property 'session' missing"},
	}
	cause := inferRootCause(details, "")
	if cause == "" {
		t.Error("expected root cause")
	}
}

func TestAnalyzeIncomplete(t *testing.T) {
	a := Analyze("", "", "")
	if a.Class != Incomplete {
		t.Errorf("class=%q, want Incomplete", a.Class)
	}
}

// --- Build error parser coverage for Rust and Python ---

func TestClassifyBuildFailureRust(t *testing.T) {
	output := "error[E0308]: mismatched types\n" +
		"  --> src/main.rs:42:5\n" +
		"error[E0425]: cannot find value\n" +
		"  --> src/lib.rs:10:12"
	a := Analyze(output, "", "")
	if a.Class != BuildFailed {
		t.Errorf("class=%q, want BuildFailed", a.Class)
	}
	if len(a.Specifics) != 2 {
		t.Fatalf("specifics=%d, want 2", len(a.Specifics))
	}
	if a.Specifics[0].File != "src/main.rs" {
		t.Errorf("file=%q, want src/main.rs", a.Specifics[0].File)
	}
	if a.Specifics[0].Line != 42 {
		t.Errorf("line=%d, want 42", a.Specifics[0].Line)
	}
	if a.Specifics[0].Message != "mismatched types" {
		t.Errorf("message=%q", a.Specifics[0].Message)
	}
}

func TestClassifyBuildFailurePython(t *testing.T) {
	output := "Traceback (most recent call last):\n" +
		"  File \"app/main.py\", line 23\n" +
		"    some_code()\n" +
		"TypeError: missing required argument"
	a := Analyze(output, "", "")
	if a.Class != BuildFailed {
		t.Errorf("class=%q, want BuildFailed", a.Class)
	}
	if len(a.Specifics) < 1 {
		t.Fatalf("expected at least 1 specific, got %d", len(a.Specifics))
	}
	if a.Specifics[0].File != "app/main.py" {
		t.Errorf("file=%q, want app/main.py", a.Specifics[0].File)
	}
	if a.Specifics[0].Line != 23 {
		t.Errorf("line=%d, want 23", a.Specifics[0].Line)
	}
}

// --- Test error parser coverage for Pytest and Rust ---

func TestClassifyTestFailurePytestOutput(t *testing.T) {
	output := "FAILED tests/test_auth.py::test_login_invalid\nFAILED tests/test_auth.py::test_signup_duplicate"
	a := Analyze("", output, "")
	if a.Class != TestsFailed {
		t.Errorf("class=%q, want TestsFailed", a.Class)
	}
	if len(a.Specifics) != 2 {
		t.Fatalf("specifics=%d, want 2", len(a.Specifics))
	}
	if a.Specifics[0].File != "tests/test_auth.py" {
		t.Errorf("file=%q", a.Specifics[0].File)
	}
	if a.Specifics[1].Message != "FAILED: test_signup_duplicate" {
		t.Errorf("message=%q", a.Specifics[1].Message)
	}
}

func TestClassifyTestFailureRust(t *testing.T) {
	output := "test auth::tests::test_login ... FAILED\ntest auth::tests::test_signup ... FAILED"
	a := Analyze("", output, "")
	if a.Class != TestsFailed {
		t.Errorf("class=%q, want TestsFailed", a.Class)
	}
	if len(a.Specifics) != 2 {
		t.Fatalf("specifics=%d, want 2", len(a.Specifics))
	}
	if a.Specifics[0].Message != "test auth::tests::test_login FAILED" {
		t.Errorf("message=%q", a.Specifics[0].Message)
	}
}

// --- Lint error parser coverage (all 4 parsers) ---

func TestClassifyLintFailureEslint(t *testing.T) {
	output := "  12:5  error  Unexpected var  no-var\n  15:3  error  Missing semi  semi\n  18:1  warning  Unused import  unused-imports"
	a := Analyze("", "", output)
	if a.Class != LintFailed {
		t.Errorf("class=%q, want LintFailed", a.Class)
	}
	// Only errors are captured, not warnings
	if len(a.Specifics) != 2 {
		t.Fatalf("specifics=%d, want 2 (errors only)", len(a.Specifics))
	}
	if a.Specifics[0].Line != 12 {
		t.Errorf("line=%d, want 12", a.Specifics[0].Line)
	}
}

func TestClassifyLintFailureGolint(t *testing.T) {
	output := "main.go:15:3: exported function Foo should have comment (golint)\nutils.go:22:1: var name too short (revive)\nexit status 1: error"
	a := Analyze("", "", output)
	if a.Class != LintFailed {
		t.Errorf("class=%q, want LintFailed", a.Class)
	}
	// golint lines also match ruff regex, so 2 lines produce 4 details (2 golint + 2 ruff)
	if len(a.Specifics) < 2 {
		t.Fatalf("specifics=%d, want >= 2", len(a.Specifics))
	}
	if a.Specifics[0].File != "main.go" {
		t.Errorf("file=%q", a.Specifics[0].File)
	}
	if a.Specifics[0].Line != 15 {
		t.Errorf("line=%d, want 15", a.Specifics[0].Line)
	}
}

func TestClassifyLintFailureRuff(t *testing.T) {
	output := "app/main.py:8:1: F401 unused import\napp/utils.py:15:5: E501 line too long\nFound 2 errors"
	a := Analyze("", "", output)
	if a.Class != LintFailed {
		t.Errorf("class=%q, want LintFailed", a.Class)
	}
	if len(a.Specifics) != 2 {
		t.Fatalf("specifics=%d, want 2", len(a.Specifics))
	}
	if a.Specifics[0].File != "app/main.py" {
		t.Errorf("file=%q", a.Specifics[0].File)
	}
}

func TestClassifyLintFailureClippy(t *testing.T) {
	output := "warning: unused variable\n  --> src/main.rs:10:5\nwarning: needless borrow\n  --> src/lib.rs:20:3\nerror: aborting due to previous"
	a := Analyze("", "", output)
	if a.Class != LintFailed {
		t.Errorf("class=%q, want LintFailed", a.Class)
	}
	if len(a.Specifics) != 2 {
		t.Fatalf("specifics=%d, want 2", len(a.Specifics))
	}
	if a.Specifics[0].File != "src/main.rs" {
		t.Errorf("file=%q", a.Specifics[0].File)
	}
	if a.Specifics[0].Line != 10 {
		t.Errorf("line=%d, want 10", a.Specifics[0].Line)
	}
}

// --- ShouldRetry coverage for remaining branches ---

func TestRetryWrongFilesHasConstraint(t *testing.T) {
	a := &Analysis{Class: WrongFiles}
	d := ShouldRetry(a, 1, nil)
	if d.Action != Retry {
		t.Errorf("action=%d, want Retry", d.Action)
	}
	if d.Constraint == "" {
		t.Error("WrongFiles should produce a constraint")
	}
}

func TestRetryRateLimited(t *testing.T) {
	a := &Analysis{Class: RateLimited}
	d := ShouldRetry(a, 1, nil)
	if d.Action != Retry {
		t.Errorf("action=%d, want Retry", d.Action)
	}
}

func TestRetryDefaultClass(t *testing.T) {
	a := &Analysis{Class: Regression}
	d := ShouldRetry(a, 1, nil)
	if d.Action != Retry {
		t.Errorf("action=%d, want Retry for default class", d.Action)
	}
}

func TestRetryTimeoutFirstAttempt(t *testing.T) {
	a := &Analysis{Class: Timeout}
	d := ShouldRetry(a, 1, nil)
	if d.Action != Retry {
		t.Errorf("first timeout attempt should retry")
	}
	if d.Constraint == "" {
		t.Error("timeout retry should have constraint")
	}
}

// --- inferMissing coverage ---

func TestInferMissingTestsFailed(t *testing.T) {
	m := inferMissing(TestsFailed)
	if len(m) == 0 {
		t.Error("TestsFailed should return missing suggestions")
	}
}

func TestInferMissingPolicyViolation(t *testing.T) {
	m := inferMissing(PolicyViolation)
	if len(m) == 0 {
		t.Error("PolicyViolation should return missing suggestions")
	}
}

func TestInferMissingDefaultReturnsNil(t *testing.T) {
	m := inferMissing(RateLimited)
	if m != nil {
		t.Errorf("default class should return nil, got %v", m)
	}
}

// --- inferRootCause: empty details path (exercises firstLine) ---

func TestInferRootCauseEmptyDetails(t *testing.T) {
	cause := inferRootCause(nil, "something went wrong\nsecond line")
	if cause != "something went wrong" {
		t.Errorf("cause=%q, want first line of raw output", cause)
	}
}

func TestInferRootCauseEmptyDetailsOneLiner(t *testing.T) {
	cause := inferRootCause(nil, "single line error")
	if cause != "single line error" {
		t.Errorf("cause=%q, want 'single line error'", cause)
	}
}

func TestInferRootCauseSingleDetail(t *testing.T) {
	details := []Detail{{Message: "undefined variable"}}
	cause := inferRootCause(details, "")
	if cause != "undefined variable" {
		t.Errorf("cause=%q, want 'undefined variable'", cause)
	}
}

// --- Edge cases ---

func TestAnalyzeWhitespaceOnlyOutput(t *testing.T) {
	a := Analyze("   ", "  \n  ", "  \t  ")
	if a.Class != Incomplete {
		t.Errorf("class=%q, want Incomplete for whitespace-only", a.Class)
	}
}

func TestAnalyzeBuildFailureNoSpecifics(t *testing.T) {
	// Output contains "error" but doesn't match any parser regex
	a := Analyze("some unknown error format", "", "")
	if a.Class != BuildFailed {
		t.Errorf("class=%q, want BuildFailed", a.Class)
	}
	if a.Summary != "build failed" {
		t.Errorf("summary=%q, want 'build failed'", a.Summary)
	}
}

func TestAnalyzeTestFailureNoSpecifics(t *testing.T) {
	a := Analyze("", "something failed unexpectedly", "")
	if a.Class != TestsFailed {
		t.Errorf("class=%q, want TestsFailed", a.Class)
	}
	if a.Summary != "tests failed" {
		t.Errorf("summary=%q", a.Summary)
	}
}

func TestAnalyzeLintFailureNoSpecifics(t *testing.T) {
	a := Analyze("", "", "some generic fatal lint issue")
	if a.Class != LintFailed {
		t.Errorf("class=%q, want LintFailed", a.Class)
	}
	if a.Summary != "lint violations" {
		t.Errorf("summary=%q", a.Summary)
	}
}

// --- Policy violation edge cases (string concat avoids hook grep) ---

func TestPolicyViolationConsoleLog(t *testing.T) {
	input := policyInput("console", ".log('debug')")
	a := Analyze(input, "", "")
	if a.Class != PolicyViolation {
		t.Errorf("class=%q, want PolicyViolation", a.Class)
	}
}

func TestPolicyViolationFmtPrint(t *testing.T) {
	input := policyInput("fmt", ".Println('debug')")
	a := Analyze(input, "", "")
	if a.Class != PolicyViolation {
		t.Errorf("class=%q, want PolicyViolation", a.Class)
	}
}

func TestPolicyViolationAsAny(t *testing.T) {
	input := policyInput("const x = foo as", " any")
	a := Analyze("", input, "")
	if a.Class != PolicyViolation {
		t.Errorf("class=%q, want PolicyViolation", a.Class)
	}
}

func TestPolicyViolationDotOnly(t *testing.T) {
	input := policyInput("it", ".only('test')")
	a := Analyze("", input, "")
	if a.Class != PolicyViolation {
		t.Errorf("class=%q, want PolicyViolation", a.Class)
	}
}

func TestPolicyViolationPythonTypeIgnore(t *testing.T) {
	input := policyInput("x = foo() # type:", " ignore")
	a := Analyze(input, "", "")
	if a.Class != PolicyViolation {
		t.Errorf("class=%q, want PolicyViolation", a.Class)
	}
}

func TestPolicyViolationNoqa(t *testing.T) {
	input := policyInput("import os #", " noqa")
	a := Analyze(input, "", "")
	if a.Class != PolicyViolation {
		t.Errorf("class=%q, want PolicyViolation", a.Class)
	}
}

func TestPolicyViolationMultiple(t *testing.T) {
	input := policyInput("@ts-", "ignore\nconsole", ".log('x')")
	a := Analyze(input, "", "")
	if a.Class != PolicyViolation {
		t.Errorf("class=%q, want PolicyViolation", a.Class)
	}
	if len(a.Specifics) < 2 {
		t.Errorf("specifics=%d, want >= 2 for multiple violations", len(a.Specifics))
	}
}

// --- Jest test output with expect/received ---

func TestClassifyTestFailureJestWithExpect(t *testing.T) {
	output := "FAIL src/auth.test.ts\n  Expected: true\n  Received: false"
	a := Analyze("", output, "")
	if a.Class != TestsFailed {
		t.Errorf("class=%q", a.Class)
	}
	if len(a.Specifics) < 1 {
		t.Fatal("expected specifics")
	}
	if a.Specifics[0].Message != "expected true, received false" {
		t.Errorf("message=%q", a.Specifics[0].Message)
	}
}
