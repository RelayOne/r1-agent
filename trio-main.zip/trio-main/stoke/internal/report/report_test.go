package report

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestSaveAndLoadLatest(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{
		Version:     "0.1.0",
		PlanID:      "test-plan",
		StartedAt:   time.Now().Add(-5 * time.Minute),
		CompletedAt: time.Now(),
		DurationSec: 300,
		TotalCost:   1.23,
		TasksDone:   3,
		TasksFailed: 1,
		TasksTotal:  4,
		Success:     false,
		Tasks: []TaskReport{
			{ID: "T1", Description: "first", Status: "done", CostUSD: 0.50},
			{ID: "T2", Description: "second", Status: "failed", Error: "build failed",
				Failure: &FailureReport{Class: "BuildFailed", Summary: "2 TS errors"}},
		},
	}

	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	if err := r.Save(dir); err != nil {
		t.Fatal(err)
	}

	loaded, err := LoadLatest(dir)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.PlanID != "test-plan" {
		t.Errorf("plan_id=%q", loaded.PlanID)
	}
	if loaded.TasksDone != 3 {
		t.Errorf("tasks_done=%d", loaded.TasksDone)
	}
	if len(loaded.Tasks) != 2 {
		t.Fatalf("tasks=%d", len(loaded.Tasks))
	}
	if loaded.Tasks[1].Failure == nil {
		t.Error("task 2 should have failure report")
	}
	if loaded.Tasks[1].Failure.Class != "BuildFailed" {
		t.Errorf("class=%q", loaded.Tasks[1].Failure.Class)
	}
}

func TestReportRoundtrip(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{
		Version:   "0.1.0",
		PlanID:    "roundtrip",
		StartedAt: time.Now(),
		Tasks: []TaskReport{
			{
				ID:      "T1",
				Status:  "done",
				Review:  &ReviewReport{Engine: "codex", Approved: true, Summary: "LGTM"},
				FilesChanged: []string{"src/auth.ts", "src/types/auth.ts"},
			},
		},
	}
	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	loaded, err := LoadLatest(dir)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.Tasks[0].Review == nil || !loaded.Tasks[0].Review.Approved {
		t.Error("review should roundtrip")
	}
	if len(loaded.Tasks[0].FilesChanged) != 2 {
		t.Errorf("files=%d", len(loaded.Tasks[0].FilesChanged))
	}
}

// --- New tests below ---

func TestBuildReportEmptyTasks(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{
		Version:     "0.1.0",
		PlanID:      "empty",
		StartedAt:   time.Now(),
		CompletedAt: time.Now(),
		DurationSec: 0,
		TotalCost:   0,
		TasksDone:   0,
		TasksFailed: 0,
		TasksTotal:  0,
		Success:     true,
		Tasks:       []TaskReport{},
	}

	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	loaded, err := LoadLatest(dir)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.PlanID != "empty" {
		t.Errorf("plan_id=%q", loaded.PlanID)
	}
	if len(loaded.Tasks) != 0 {
		t.Errorf("expected 0 tasks, got %d", len(loaded.Tasks))
	}
	if !loaded.Success {
		t.Error("success should be true for empty report")
	}
}

func TestBuildReportNilTasks(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{
		Version: "0.1.0",
		PlanID:  "nil-tasks",
		Tasks:   nil,
	}
	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	loaded, err := LoadLatest(dir)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.Tasks != nil && len(loaded.Tasks) != 0 {
		t.Errorf("expected nil/empty tasks, got %d", len(loaded.Tasks))
	}
}

func TestBuildReportAllFailed(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{
		Version:     "0.1.0",
		PlanID:      "all-failed",
		StartedAt:   time.Now().Add(-10 * time.Minute),
		CompletedAt: time.Now(),
		DurationSec: 600,
		TotalCost:   5.00,
		TasksDone:   0,
		TasksFailed: 3,
		TasksTotal:  3,
		Success:     false,
		Tasks: []TaskReport{
			{
				ID: "T1", Status: "failed", Error: "build error",
				Failure: &FailureReport{
					Class:     "BuildFailed",
					Summary:   "missing import",
					RootCause: "forgot to add dependency",
					Details: []Detail{
						{File: "main.go", Line: 10, Message: "undefined: foo", Fix: "import the foo package"},
					},
				},
			},
			{
				ID: "T2", Status: "failed", Error: "test failed",
				Failure: &FailureReport{Class: "TestFailed", Summary: "3 tests failing"},
			},
			{
				ID: "T3", Status: "failed", Error: "lint error",
				Failure: &FailureReport{Class: "LintFailed", Summary: "unused variable"},
			},
		},
	}

	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	loaded, err := LoadLatest(dir)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.TasksFailed != 3 {
		t.Errorf("tasks_failed=%d, want 3", loaded.TasksFailed)
	}
	if loaded.Success {
		t.Error("success should be false when all tasks failed")
	}
	// Check failure details roundtrip
	f := loaded.Tasks[0].Failure
	if f.RootCause != "forgot to add dependency" {
		t.Errorf("root_cause=%q", f.RootCause)
	}
	if len(f.Details) != 1 {
		t.Fatalf("details=%d", len(f.Details))
	}
	if f.Details[0].File != "main.go" {
		t.Errorf("file=%q", f.Details[0].File)
	}
	if f.Details[0].Line != 10 {
		t.Errorf("line=%d", f.Details[0].Line)
	}
	if f.Details[0].Fix != "import the foo package" {
		t.Errorf("fix=%q", f.Details[0].Fix)
	}
}

func TestTaskReportWithWarnings(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{
		Version: "0.1.0",
		PlanID:  "warnings",
		Tasks: []TaskReport{
			{
				ID:       "T1",
				Status:   "done",
				Warnings: []string{"deprecated API usage", "large file detected"},
			},
		},
	}
	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	loaded, err := LoadLatest(dir)
	if err != nil {
		t.Fatal(err)
	}
	if len(loaded.Tasks[0].Warnings) != 2 {
		t.Errorf("warnings=%d, want 2", len(loaded.Tasks[0].Warnings))
	}
	if loaded.Tasks[0].Warnings[0] != "deprecated API usage" {
		t.Errorf("warning[0]=%q", loaded.Tasks[0].Warnings[0])
	}
}

func TestTaskReportSkippedStatus(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{
		Version: "0.1.0",
		PlanID:  "skipped",
		Tasks: []TaskReport{
			{ID: "T1", Status: "done"},
			{ID: "T2", Status: "skipped"},
			{ID: "T3", Status: "failed", Error: "timeout"},
		},
	}
	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	loaded, err := LoadLatest(dir)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.Tasks[1].Status != "skipped" {
		t.Errorf("status=%q, want skipped", loaded.Tasks[1].Status)
	}
}

func TestReportJSONSerialization(t *testing.T) {
	r := &BuildReport{
		Version:     "0.1.0",
		PlanID:      "json-test",
		StartedAt:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		CompletedAt: time.Date(2024, 1, 1, 0, 5, 0, 0, time.UTC),
		DurationSec: 300,
		TotalCost:   2.50,
		TasksDone:   1,
		TasksFailed: 0,
		TasksTotal:  1,
		Success:     true,
		Tasks: []TaskReport{
			{
				ID:          "T1",
				Description: "implement auth",
				Type:        "feature",
				Status:      "done",
				Attempts:    2,
				CostUSD:     2.50,
				DurationSec: 300,
			},
		},
	}
	data, err := json.MarshalIndent(r, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	var loaded BuildReport
	if err := json.Unmarshal(data, &loaded); err != nil {
		t.Fatal(err)
	}
	if loaded.TotalCost != 2.50 {
		t.Errorf("total_cost=%f", loaded.TotalCost)
	}
	if loaded.Tasks[0].Attempts != 2 {
		t.Errorf("attempts=%d", loaded.Tasks[0].Attempts)
	}
	if loaded.Tasks[0].Type != "feature" {
		t.Errorf("type=%q", loaded.Tasks[0].Type)
	}
}

func TestReportOmitsEmptyOptionalFields(t *testing.T) {
	r := &BuildReport{
		Version: "0.1.0",
		PlanID:  "omit-test",
		Tasks: []TaskReport{
			{ID: "T1", Status: "done"},
		},
	}
	data, err := json.Marshal(r)
	if err != nil {
		t.Fatal(err)
	}
	var raw map[string]interface{}
	json.Unmarshal(data, &raw)

	tasks := raw["tasks"].([]interface{})
	task := tasks[0].(map[string]interface{})
	if _, exists := task["error"]; exists {
		t.Error("empty error should be omitted")
	}
	if _, exists := task["failure"]; exists {
		t.Error("nil failure should be omitted")
	}
	if _, exists := task["review"]; exists {
		t.Error("nil review should be omitted")
	}
	if _, exists := task["warnings"]; exists {
		t.Error("nil warnings should be omitted")
	}
	if _, exists := task["files_changed"]; exists {
		t.Error("nil files_changed should be omitted")
	}
}

func TestSaveCreatesReportsDirectory(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{
		Version:   "0.1.0",
		PlanID:    "mkdir-test",
		StartedAt: time.Date(2024, 6, 15, 12, 0, 0, 0, time.UTC),
	}
	if err := r.Save(dir); err != nil {
		t.Fatal(err)
	}
	reportsDir := filepath.Join(dir, ".stoke", "reports")
	info, err := os.Stat(reportsDir)
	if err != nil {
		t.Fatalf("reports dir not created: %v", err)
	}
	if !info.IsDir() {
		t.Error("reports path should be a directory")
	}
}

func TestSaveLatestCreatesReportsDirectory(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{Version: "0.1.0", PlanID: "mkdir-latest"}
	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	latestPath := filepath.Join(dir, ".stoke", "reports", "latest.json")
	if _, err := os.Stat(latestPath); err != nil {
		t.Fatalf("latest.json not created: %v", err)
	}
}

func TestLoadLatestMissingFile(t *testing.T) {
	dir := t.TempDir()
	_, err := LoadLatest(dir)
	if err == nil {
		t.Fatal("should error when no latest.json exists")
	}
}

func TestLoadLatestCorruptJSON(t *testing.T) {
	dir := t.TempDir()
	reportsDir := filepath.Join(dir, ".stoke", "reports")
	os.MkdirAll(reportsDir, 0755)
	os.WriteFile(filepath.Join(reportsDir, "latest.json"), []byte("not json at all {{{"), 0644)

	_, err := LoadLatest(dir)
	if err == nil {
		t.Fatal("should error on corrupt JSON")
	}
}

func TestSaveAndLoadPreservesTimestamps(t *testing.T) {
	dir := t.TempDir()
	start := time.Date(2024, 3, 15, 10, 0, 0, 0, time.UTC)
	end := time.Date(2024, 3, 15, 10, 5, 0, 0, time.UTC)
	r := &BuildReport{
		Version:     "0.1.0",
		PlanID:      "time-test",
		StartedAt:   start,
		CompletedAt: end,
		DurationSec: 300,
	}
	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	loaded, err := LoadLatest(dir)
	if err != nil {
		t.Fatal(err)
	}
	if !loaded.StartedAt.Equal(start) {
		t.Errorf("start time mismatch: %v vs %v", loaded.StartedAt, start)
	}
	if !loaded.CompletedAt.Equal(end) {
		t.Errorf("end time mismatch: %v vs %v", loaded.CompletedAt, end)
	}
}

func TestReviewReportRoundtrip(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{
		Version: "0.1.0",
		PlanID:  "review-test",
		Tasks: []TaskReport{
			{
				ID:     "T1",
				Status: "done",
				Review: &ReviewReport{Engine: "claude", Approved: false, Summary: "needs refactor"},
			},
		},
	}
	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	loaded, err := LoadLatest(dir)
	if err != nil {
		t.Fatal(err)
	}
	rev := loaded.Tasks[0].Review
	if rev == nil {
		t.Fatal("review should not be nil")
	}
	if rev.Engine != "claude" {
		t.Errorf("engine=%q", rev.Engine)
	}
	if rev.Approved {
		t.Error("approved should be false")
	}
	if rev.Summary != "needs refactor" {
		t.Errorf("summary=%q", rev.Summary)
	}
}

func TestSaveGeneratesUniqueFilenames(t *testing.T) {
	dir := t.TempDir()
	r1 := &BuildReport{
		Version:   "0.1.0",
		PlanID:    "plan-a",
		StartedAt: time.Date(2024, 1, 1, 12, 0, 0, 0, time.UTC),
	}
	r2 := &BuildReport{
		Version:   "0.1.0",
		PlanID:    "plan-b",
		StartedAt: time.Date(2024, 1, 1, 13, 0, 0, 0, time.UTC),
	}
	if err := r1.Save(dir); err != nil {
		t.Fatal(err)
	}
	if err := r2.Save(dir); err != nil {
		t.Fatal(err)
	}
	entries, _ := os.ReadDir(filepath.Join(dir, ".stoke", "reports"))
	count := 0
	for _, e := range entries {
		if !e.IsDir() {
			count++
		}
	}
	if count != 2 {
		t.Errorf("expected 2 report files, got %d", count)
	}
}

func TestSaveToInvalidPath(t *testing.T) {
	r := &BuildReport{
		Version:   "0.1.0",
		PlanID:    "bad-path",
		StartedAt: time.Now(),
	}
	// /dev/null is a file, not a dir, so MkdirAll will fail when trying to create subdirs under it
	err := r.Save("/dev/null")
	if err == nil {
		t.Fatal("should error when saving to invalid path")
	}
}

func TestSaveLatestToInvalidPath(t *testing.T) {
	r := &BuildReport{
		Version: "0.1.0",
		PlanID:  "bad-path",
	}
	err := r.SaveLatest("/dev/null")
	if err == nil {
		t.Fatal("should error when saving latest to invalid path")
	}
}

func TestBuildReportMultipleAttemptsField(t *testing.T) {
	dir := t.TempDir()
	r := &BuildReport{
		Version: "0.1.0",
		PlanID:  "retry-test",
		Tasks: []TaskReport{
			{ID: "T1", Status: "done", Attempts: 3, DurationSec: 120, CostUSD: 1.50},
		},
	}
	if err := r.SaveLatest(dir); err != nil {
		t.Fatal(err)
	}
	loaded, err := LoadLatest(dir)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.Tasks[0].Attempts != 3 {
		t.Errorf("attempts=%d, want 3", loaded.Tasks[0].Attempts)
	}
	if loaded.Tasks[0].DurationSec != 120 {
		t.Errorf("duration=%f, want 120", loaded.Tasks[0].DurationSec)
	}
}
