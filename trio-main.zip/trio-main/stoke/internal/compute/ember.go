package compute

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

var validWorkerID = regexp.MustCompile(`^[a-zA-Z0-9_-]+$`)

// EmberBackend spawns Flare microVMs via the Ember API.
type EmberBackend struct {
	endpoint    string
	apiKey      string
	defaultSize string
	httpClient  *http.Client
}

func NewEmberBackend(endpoint, apiKey string) (*EmberBackend, error) {
	endpoint = strings.TrimRight(endpoint, "/")
	if !strings.HasPrefix(endpoint, "https://") && !strings.HasPrefix(endpoint, "http://localhost") {
		log.Printf("[WARN] Ember endpoint %q does not use HTTPS — API key will be sent in cleartext", endpoint)
	}
	if _, err := url.Parse(endpoint); err != nil {
		return nil, fmt.Errorf("invalid ember endpoint URL %q: %w", endpoint, err)
	}
	return &EmberBackend{
		endpoint:    endpoint,
		apiKey:      apiKey,
		defaultSize: "performance-4x",
		httpClient:  &http.Client{Timeout: 60 * time.Second},
	}, nil
}

func (b *EmberBackend) Name() string { return "ember" }

// DefaultTTLMinutes is the default worker time-to-live. Ember's server-side
// default is 30 minutes which is too short for complex Stoke tasks.
const DefaultTTLMinutes = 60

// mapEmberWorkerState translates Ember's worker status vocabulary to Stoke's
// internal state names. Ember uses: pending, active, needs_cleanup, completed,
// failed, expired, cancelled. Stoke uses: starting, running, stopped, error.
func mapEmberWorkerState(status string) string {
	switch status {
	case "active":
		return "running"
	case "failed":
		return "error"
	case "completed", "expired", "cancelled":
		return "stopped"
	case "pending":
		return "starting"
	default:
		return status
	}
}

func (b *EmberBackend) Spawn(ctx context.Context, opts SpawnOpts) (Worker, error) {
	if opts.Size == "" {
		opts.Size = b.defaultSize
	}
	// Ember expects sizes like "performance-4x". If caller passes bare "4x", prefix it.
	if !strings.HasPrefix(opts.Size, "performance-") {
		opts.Size = "performance-" + opts.Size
	}

	ttl := opts.TTLMinutes
	if ttl <= 0 {
		ttl = DefaultTTLMinutes
	}

	body, err := json.Marshal(map[string]any{
		"name":        fmt.Sprintf("stoke-%s", opts.TaskID),
		"size":        opts.Size,
		"ttl_minutes": ttl,
		"repo_url":    opts.RepoURL,
		"branch":      opts.Branch,
		"env":         opts.Env,
		"metadata": map[string]any{
			"stoke":             true,
			"parent_machine_id": opts.ParentID,
			"task_id":           opts.TaskID,
			"auto_destroy":      opts.AutoDestroy,
		},
	})
	if err != nil {
		return nil, fmt.Errorf("marshal spawn request: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, "POST", b.endpoint+"/v1/workers", bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+b.apiKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := b.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("spawn worker: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != 201 {
		respBody, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("spawn worker: HTTP %d: %s", resp.StatusCode, string(respBody))
	}

	var result struct {
		ID       string `json:"id"`
		Hostname string `json:"hostname"`
		Status   string `json:"status"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("parse spawn response: %w", err)
	}

	if !validWorkerID.MatchString(result.ID) {
		return nil, fmt.Errorf("ember returned invalid worker ID %q", result.ID)
	}

	w := &flareWorker{
		id:       result.ID,
		hostname: result.Hostname,
		endpoint: b.endpoint,
		apiKey:   b.apiKey,
		client:   b.httpClient,
	}

	// Poll until running (max 60s), respecting context cancellation
	deadline := time.Now().Add(60 * time.Second)
	for time.Now().Before(deadline) {
		select {
		case <-ctx.Done():
			return nil, fmt.Errorf("context cancelled while waiting for worker: %w", ctx.Err())
		default:
		}
		state, rawState, err := w.getState(ctx)
		if err != nil {
			return nil, err
		}
		if state == "running" {
			return w, nil
		}
		if rawState == "expired" {
			return nil, fmt.Errorf("worker expired (TTL exceeded) before becoming ready: consider increasing TTLMinutes (current: %d)", ttl)
		}
		if state == "error" || state == "destroyed" || state == "stopped" {
			return nil, fmt.Errorf("worker failed to start: state=%s (ember: %s)", state, rawState)
		}
		select {
		case <-ctx.Done():
			return nil, fmt.Errorf("context cancelled while waiting for worker: %w", ctx.Err())
		case <-time.After(500 * time.Millisecond):
		}
	}
	return nil, fmt.Errorf("worker did not start within 60s")
}

type flareWorker struct {
	id       string
	hostname string
	endpoint string
	apiKey   string
	client   *http.Client
}

func (w *flareWorker) ID() string        { return w.id }
func (w *flareWorker) Hostname() string  { return w.hostname }
// Stdout returns an empty reader. For ember workers, stdout comes from Claude Code's
// output running on the worker machine, not from the worker API itself.
func (w *flareWorker) Stdout() io.Reader { return strings.NewReader("") }

func (w *flareWorker) doReq(ctx context.Context, method, path string, body any) (*http.Response, error) {
	// Validate worker ID is safe before embedding in URL path.
	// STOKE-012: url.PathEscape is applied at call sites; we additionally validate
	// the ID matches the expected character class as a defense-in-depth measure.
	if strings.ContainsRune(w.id, '/') || strings.ContainsRune(w.id, '\\') || w.id == "" {
		return nil, fmt.Errorf("invalid worker ID %q: must match ^[a-zA-Z0-9_-]+$", w.id)
	}

	var bodyReader io.Reader
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return nil, fmt.Errorf("marshal request body: %w", err)
		}
		bodyReader = bytes.NewReader(b)
	}
	req, err := http.NewRequestWithContext(ctx, method, w.endpoint+path, bodyReader)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+w.apiKey)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	return w.client.Do(req)
}

// getState fetches the current worker status from Ember and returns the
// mapped (Stoke-vocabulary) state along with the raw Ember status.
func (w *flareWorker) getState(ctx context.Context) (mapped string, raw string, err error) {
	resp, err := w.doReq(ctx, "GET", "/v1/workers/"+url.PathEscape(w.id)+"/status", nil)
	if err != nil {
		return "", "", err
	}
	defer resp.Body.Close()
	var result struct {
		Status string `json:"status"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", "", fmt.Errorf("decode worker state: %w", err)
	}
	return mapEmberWorkerState(result.Status), result.Status, nil
}

func (w *flareWorker) Exec(_ context.Context, _ string, _ ...string) (ExecResult, error) {
	// Ember workers do not expose a remote exec endpoint. Execution happens
	// through Claude Code running directly on the worker machine.
	return ExecResult{}, fmt.Errorf("ember workers do not expose a remote exec endpoint: execution happens through Claude Code running on the worker")
}

func (w *flareWorker) Upload(_ context.Context, _, _ string) error {
	// Ember workers do not expose an upload endpoint. Files reach the worker
	// via git clone at spawn time; additional files are managed by Claude Code.
	return fmt.Errorf("ember workers do not expose an upload endpoint: files are delivered via git clone at spawn")
}

func (w *flareWorker) Download(_ context.Context, _, _ string) error {
	// Ember workers do not expose a download endpoint. Results are committed
	// to git by Claude Code running on the worker and pulled back via git.
	return fmt.Errorf("ember workers do not expose a download endpoint: results are delivered via git commits")
}

func (w *flareWorker) Stop(ctx context.Context) error {
	resp, err := w.doReq(ctx, "POST", "/v1/workers/"+url.PathEscape(w.id)+"/stop", nil)
	if err != nil {
		return err
	}
	resp.Body.Close()
	return nil
}

func (w *flareWorker) Destroy(ctx context.Context) error {
	resp, err := w.doReq(ctx, "DELETE", "/v1/workers/"+url.PathEscape(w.id), nil)
	if err != nil {
		return err
	}
	resp.Body.Close()
	return nil
}
