package compute

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

// ---------------------------------------------------------------------------
// Interface compliance: both backends must satisfy Backend; workers satisfy Worker
// ---------------------------------------------------------------------------

var _ Backend = (*EmberBackend)(nil)
var _ Backend = (*LocalBackend)(nil)

// ---------------------------------------------------------------------------
// EmberBackend constructor tests
// ---------------------------------------------------------------------------

func TestNewEmberBackend_ValidHTTPS(t *testing.T) {
	b, err := NewEmberBackend("https://api.ember.example.com", "sk-test-key")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if b.endpoint != "https://api.ember.example.com" {
		t.Errorf("endpoint = %q, want %q", b.endpoint, "https://api.ember.example.com")
	}
	if b.apiKey != "sk-test-key" {
		t.Errorf("apiKey = %q, want %q", b.apiKey, "sk-test-key")
	}
	if b.defaultSize != "performance-4x" {
		t.Errorf("defaultSize = %q, want %q", b.defaultSize, "performance-4x")
	}
}

func TestNewEmberBackend_TrimsTrailingSlash(t *testing.T) {
	b, err := NewEmberBackend("https://api.ember.example.com///", "key")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if b.endpoint != "https://api.ember.example.com" {
		t.Errorf("endpoint = %q, want trailing slashes trimmed", b.endpoint)
	}
}

func TestNewEmberBackend_LocalhostHTTPAllowed(t *testing.T) {
	b, err := NewEmberBackend("http://localhost:8080", "key")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if b.endpoint != "http://localhost:8080" {
		t.Errorf("endpoint = %q, want %q", b.endpoint, "http://localhost:8080")
	}
}

func TestNewEmberBackend_HTTPClientTimeout(t *testing.T) {
	b, err := NewEmberBackend("https://api.ember.example.com", "key")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if b.httpClient == nil {
		t.Fatal("httpClient is nil")
	}
	if b.httpClient.Timeout != 60*time.Second {
		t.Errorf("httpClient.Timeout = %v, want %v", b.httpClient.Timeout, 60*time.Second)
	}
}

func TestNewEmberBackend_Name(t *testing.T) {
	b, err := NewEmberBackend("https://api.ember.example.com", "key")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if b.Name() != "ember" {
		t.Errorf("Name() = %q, want %q", b.Name(), "ember")
	}
}

// ---------------------------------------------------------------------------
// LocalBackend constructor and basic operations
// ---------------------------------------------------------------------------

func TestNewLocalBackend(t *testing.T) {
	b := NewLocalBackend("/tmp/repo")
	if b.RepoRoot != "/tmp/repo" {
		t.Errorf("RepoRoot = %q, want %q", b.RepoRoot, "/tmp/repo")
	}
}

func TestLocalBackend_Name(t *testing.T) {
	b := NewLocalBackend("/tmp/repo")
	if b.Name() != "local" {
		t.Errorf("Name() = %q, want %q", b.Name(), "local")
	}
}

func TestLocalBackend_Spawn(t *testing.T) {
	b := NewLocalBackend("/tmp/repo")
	w, err := b.Spawn(context.Background(), SpawnOpts{TaskID: "TASK-42"})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if w.ID() != "local-TASK-42" {
		t.Errorf("ID() = %q, want %q", w.ID(), "local-TASK-42")
	}
	if w.Hostname() != "localhost" {
		t.Errorf("Hostname() = %q, want %q", w.Hostname(), "localhost")
	}
}

func TestLocalWorker_Stdout(t *testing.T) {
	b := NewLocalBackend("/tmp/repo")
	w, _ := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	data, err := io.ReadAll(w.Stdout())
	if err != nil {
		t.Fatalf("unexpected error reading stdout: %v", err)
	}
	if len(data) != 0 {
		t.Errorf("Stdout() returned %d bytes, want 0", len(data))
	}
}

func TestLocalWorker_StopAndDestroy(t *testing.T) {
	b := NewLocalBackend("/tmp/repo")
	w, _ := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	if err := w.Stop(context.Background()); err != nil {
		t.Errorf("Stop() returned error: %v", err)
	}
	if err := w.Destroy(context.Background()); err != nil {
		t.Errorf("Destroy() returned error: %v", err)
	}
}

func TestLocalWorker_UploadDownloadNoOp(t *testing.T) {
	b := NewLocalBackend("/tmp/repo")
	w, _ := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	if err := w.Upload(context.Background(), "/a", "/b"); err != nil {
		t.Errorf("Upload() returned error: %v", err)
	}
	if err := w.Download(context.Background(), "/a", "/b"); err != nil {
		t.Errorf("Download() returned error: %v", err)
	}
}

func TestLocalWorker_Exec(t *testing.T) {
	b := NewLocalBackend("/tmp")
	w, _ := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	res, err := w.Exec(context.Background(), "echo", "hello")
	if err != nil {
		t.Fatalf("Exec() returned error: %v", err)
	}
	if res.ExitCode != 0 {
		t.Errorf("ExitCode = %d, want 0", res.ExitCode)
	}
	if res.Stdout != "hello" {
		t.Errorf("Stdout = %q, want %q", res.Stdout, "hello")
	}
	if res.Duration <= 0 {
		t.Errorf("Duration = %d, want > 0", res.Duration)
	}
}

func TestLocalWorker_ExecNonZeroExitCode(t *testing.T) {
	b := NewLocalBackend("/tmp")
	w, _ := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	res, err := w.Exec(context.Background(), "sh", "-c", "echo fail >&2; exit 2")
	if err != nil {
		t.Fatalf("Exec() returned error for non-zero exit: %v", err)
	}
	if res.ExitCode != 2 {
		t.Errorf("ExitCode = %d, want 2", res.ExitCode)
	}
	if res.Stderr != "fail" {
		t.Errorf("Stderr = %q, want %q", res.Stderr, "fail")
	}
}

// ---------------------------------------------------------------------------
// mapEmberWorkerState
// ---------------------------------------------------------------------------

func TestMapEmberWorkerState(t *testing.T) {
	cases := []struct {
		input, want string
	}{
		{"active", "running"},
		{"failed", "error"},
		{"completed", "stopped"},
		{"expired", "stopped"},
		{"cancelled", "stopped"},
		{"pending", "starting"},
		{"some_unknown_state", "some_unknown_state"},
	}
	for _, tc := range cases {
		got := mapEmberWorkerState(tc.input)
		if got != tc.want {
			t.Errorf("mapEmberWorkerState(%q) = %q, want %q", tc.input, got, tc.want)
		}
	}
}

// ---------------------------------------------------------------------------
// validWorkerID regex
// ---------------------------------------------------------------------------

func TestValidWorkerID(t *testing.T) {
	valid := []string{"abc", "worker-1", "W_123", "a1b2c3"}
	for _, id := range valid {
		if !validWorkerID.MatchString(id) {
			t.Errorf("validWorkerID rejected %q, want accepted", id)
		}
	}
	invalid := []string{"", "has space", "has/slash", "a\nb"}
	for _, id := range invalid {
		if validWorkerID.MatchString(id) {
			t.Errorf("validWorkerID accepted %q, want rejected", id)
		}
	}
}

// ---------------------------------------------------------------------------
// EmberBackend.Spawn — request building and server interaction via httptest
// ---------------------------------------------------------------------------

func TestEmberBackend_Spawn_BuildsCorrectRequest(t *testing.T) {
	var capturedReq map[string]any
	var capturedAuth string

	// Phase 1: spawn POST returns 201 with a valid worker
	// Phase 2: status poll returns "active" immediately
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		capturedAuth = r.Header.Get("Authorization")

		if r.Method == "POST" && strings.HasSuffix(r.URL.Path, "/v1/workers") {
			json.NewDecoder(r.Body).Decode(&capturedReq)
			w.WriteHeader(201)
			json.NewEncoder(w).Encode(map[string]string{
				"id":       "wrk-abc123",
				"hostname": "wrk-abc123.ember.dev",
				"status":   "pending",
			})
			return
		}

		// Status endpoint: immediately return active
		if r.Method == "GET" && strings.Contains(r.URL.Path, "/status") {
			json.NewEncoder(w).Encode(map[string]string{"status": "active"})
			return
		}

		w.WriteHeader(404)
	}))
	defer srv.Close()

	b, err := NewEmberBackend(srv.URL, "test-api-key")
	if err != nil {
		t.Fatalf("NewEmberBackend: %v", err)
	}

	w, err := b.Spawn(context.Background(), SpawnOpts{
		TaskID:      "TASK-7",
		RepoURL:     "https://github.com/example/repo.git",
		Branch:      "stoke/TASK-7",
		Size:        "8x",
		Env:         map[string]string{"FOO": "bar"},
		AutoDestroy: true,
		ParentID:    "parent-1",
		TTLMinutes:  45,
	})
	if err != nil {
		t.Fatalf("Spawn() error: %v", err)
	}

	// Verify returned worker
	if w.ID() != "wrk-abc123" {
		t.Errorf("worker ID = %q, want %q", w.ID(), "wrk-abc123")
	}
	if w.Hostname() != "wrk-abc123.ember.dev" {
		t.Errorf("worker Hostname = %q, want %q", w.Hostname(), "wrk-abc123.ember.dev")
	}

	// Verify auth header
	if capturedAuth != "Bearer test-api-key" {
		t.Errorf("Authorization = %q, want %q", capturedAuth, "Bearer test-api-key")
	}

	// Verify request body
	if capturedReq["name"] != "stoke-TASK-7" {
		t.Errorf("name = %v, want %q", capturedReq["name"], "stoke-TASK-7")
	}
	if capturedReq["size"] != "performance-8x" {
		t.Errorf("size = %v, want %q", capturedReq["size"], "performance-8x")
	}
	if capturedReq["ttl_minutes"] != float64(45) {
		t.Errorf("ttl_minutes = %v, want 45", capturedReq["ttl_minutes"])
	}
	if capturedReq["repo_url"] != "https://github.com/example/repo.git" {
		t.Errorf("repo_url = %v, want correct URL", capturedReq["repo_url"])
	}
	if capturedReq["branch"] != "stoke/TASK-7" {
		t.Errorf("branch = %v, want %q", capturedReq["branch"], "stoke/TASK-7")
	}

	// Verify metadata
	meta, ok := capturedReq["metadata"].(map[string]any)
	if !ok {
		t.Fatalf("metadata not a map: %T", capturedReq["metadata"])
	}
	if meta["task_id"] != "TASK-7" {
		t.Errorf("metadata.task_id = %v, want %q", meta["task_id"], "TASK-7")
	}
	if meta["auto_destroy"] != true {
		t.Errorf("metadata.auto_destroy = %v, want true", meta["auto_destroy"])
	}
	if meta["parent_machine_id"] != "parent-1" {
		t.Errorf("metadata.parent_machine_id = %v, want %q", meta["parent_machine_id"], "parent-1")
	}
}

func TestEmberBackend_Spawn_DefaultSizeAndTTL(t *testing.T) {
	var capturedReq map[string]any

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			json.NewDecoder(r.Body).Decode(&capturedReq)
			w.WriteHeader(201)
			json.NewEncoder(w).Encode(map[string]string{
				"id":       "wrk-def",
				"hostname": "wrk-def.ember.dev",
				"status":   "pending",
			})
			return
		}
		// Status: active
		json.NewEncoder(w).Encode(map[string]string{"status": "active"})
	}))
	defer srv.Close()

	b, _ := NewEmberBackend(srv.URL, "key")
	_, err := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	if err != nil {
		t.Fatalf("Spawn() error: %v", err)
	}

	// Empty Size should default to performance-4x
	if capturedReq["size"] != "performance-4x" {
		t.Errorf("default size = %v, want %q", capturedReq["size"], "performance-4x")
	}
	// Zero TTL should default to DefaultTTLMinutes (60)
	if capturedReq["ttl_minutes"] != float64(DefaultTTLMinutes) {
		t.Errorf("default ttl = %v, want %v", capturedReq["ttl_minutes"], DefaultTTLMinutes)
	}
}

func TestEmberBackend_Spawn_SizePrefixAlreadyPresent(t *testing.T) {
	var capturedReq map[string]any

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			json.NewDecoder(r.Body).Decode(&capturedReq)
			w.WriteHeader(201)
			json.NewEncoder(w).Encode(map[string]string{
				"id":       "wrk-x",
				"hostname": "h",
				"status":   "pending",
			})
			return
		}
		json.NewEncoder(w).Encode(map[string]string{"status": "active"})
	}))
	defer srv.Close()

	b, _ := NewEmberBackend(srv.URL, "key")
	_, err := b.Spawn(context.Background(), SpawnOpts{
		TaskID: "T1",
		Size:   "performance-16x",
	})
	if err != nil {
		t.Fatalf("Spawn() error: %v", err)
	}
	// Should NOT double-prefix
	if capturedReq["size"] != "performance-16x" {
		t.Errorf("size = %v, want %q (no double prefix)", capturedReq["size"], "performance-16x")
	}
}

func TestEmberBackend_Spawn_HTTP500Error(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(500)
		w.Write([]byte("internal server error"))
	}))
	defer srv.Close()

	b, _ := NewEmberBackend(srv.URL, "key")
	_, err := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	if err == nil {
		t.Fatal("expected error from 500 response, got nil")
	}
	if !strings.Contains(err.Error(), "HTTP 500") {
		t.Errorf("error = %q, want it to contain 'HTTP 500'", err.Error())
	}
}

func TestEmberBackend_Spawn_InvalidWorkerID(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(201)
		json.NewEncoder(w).Encode(map[string]string{
			"id":       "bad/id",
			"hostname": "h",
			"status":   "active",
		})
	}))
	defer srv.Close()

	b, _ := NewEmberBackend(srv.URL, "key")
	_, err := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	if err == nil {
		t.Fatal("expected error for invalid worker ID, got nil")
	}
	if !strings.Contains(err.Error(), "invalid worker ID") {
		t.Errorf("error = %q, want it to contain 'invalid worker ID'", err.Error())
	}
}

func TestEmberBackend_Spawn_WorkerFailedState(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			w.WriteHeader(201)
			json.NewEncoder(w).Encode(map[string]string{
				"id":       "wrk-fail",
				"hostname": "h",
				"status":   "pending",
			})
			return
		}
		// Status endpoint: return "failed"
		json.NewEncoder(w).Encode(map[string]string{"status": "failed"})
	}))
	defer srv.Close()

	b, _ := NewEmberBackend(srv.URL, "key")
	_, err := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	if err == nil {
		t.Fatal("expected error when worker enters failed state, got nil")
	}
	if !strings.Contains(err.Error(), "failed to start") {
		t.Errorf("error = %q, want it to contain 'failed to start'", err.Error())
	}
}

func TestEmberBackend_Spawn_WorkerExpiredState(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			w.WriteHeader(201)
			json.NewEncoder(w).Encode(map[string]string{
				"id":       "wrk-exp",
				"hostname": "h",
				"status":   "pending",
			})
			return
		}
		json.NewEncoder(w).Encode(map[string]string{"status": "expired"})
	}))
	defer srv.Close()

	b, _ := NewEmberBackend(srv.URL, "key")
	_, err := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	if err == nil {
		t.Fatal("expected error when worker expires, got nil")
	}
	if !strings.Contains(err.Error(), "expired") {
		t.Errorf("error = %q, want it to contain 'expired'", err.Error())
	}
}

func TestEmberBackend_Spawn_ContextCancelled(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			w.WriteHeader(201)
			json.NewEncoder(w).Encode(map[string]string{
				"id":       "wrk-ctx",
				"hostname": "h",
				"status":   "pending",
			})
			return
		}
		// Always return pending so the poll loop keeps going
		json.NewEncoder(w).Encode(map[string]string{"status": "pending"})
	}))
	defer srv.Close()

	b, _ := NewEmberBackend(srv.URL, "key")
	ctx, cancel := context.WithCancel(context.Background())
	// Cancel immediately so the poll loop hits the context check
	cancel()

	_, err := b.Spawn(ctx, SpawnOpts{TaskID: "T1"})
	if err == nil {
		t.Fatal("expected error when context is cancelled, got nil")
	}
	if !strings.Contains(err.Error(), "context cancelled") && !strings.Contains(err.Error(), "context canceled") {
		t.Errorf("error = %q, want it to mention context cancellation", err.Error())
	}
}

// ---------------------------------------------------------------------------
// flareWorker methods — Exec, Upload, Download return errors
// ---------------------------------------------------------------------------

func TestFlareWorker_ExecReturnsError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" && strings.HasSuffix(r.URL.Path, "/v1/workers") {
			w.WriteHeader(201)
			json.NewEncoder(w).Encode(map[string]string{
				"id": "wrk-1", "hostname": "h", "status": "pending",
			})
			return
		}
		json.NewEncoder(w).Encode(map[string]string{"status": "active"})
	}))
	defer srv.Close()

	b, _ := NewEmberBackend(srv.URL, "key")
	w, err := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	if err != nil {
		t.Fatalf("Spawn() error: %v", err)
	}

	_, execErr := w.Exec(context.Background(), "ls")
	if execErr == nil {
		t.Error("expected Exec() to return error for ember worker")
	}

	if err := w.Upload(context.Background(), "/a", "/b"); err == nil {
		t.Error("expected Upload() to return error for ember worker")
	}

	if err := w.Download(context.Background(), "/a", "/b"); err == nil {
		t.Error("expected Download() to return error for ember worker")
	}
}

func TestFlareWorker_Stdout(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			w.WriteHeader(201)
			json.NewEncoder(w).Encode(map[string]string{
				"id": "wrk-1", "hostname": "h", "status": "pending",
			})
			return
		}
		json.NewEncoder(w).Encode(map[string]string{"status": "active"})
	}))
	defer srv.Close()

	b, _ := NewEmberBackend(srv.URL, "key")
	w, _ := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})

	data, err := io.ReadAll(w.Stdout())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(data) != 0 {
		t.Errorf("Stdout() returned %d bytes, want 0", len(data))
	}
}

// ---------------------------------------------------------------------------
// flareWorker.Stop and .Destroy via httptest
// ---------------------------------------------------------------------------

func TestFlareWorker_StopAndDestroy(t *testing.T) {
	var stopCalled, destroyCalled bool

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" && strings.HasSuffix(r.URL.Path, "/v1/workers") {
			w.WriteHeader(201)
			json.NewEncoder(w).Encode(map[string]string{
				"id": "wrk-sd", "hostname": "h", "status": "pending",
			})
			return
		}
		if r.Method == "GET" && strings.Contains(r.URL.Path, "/status") {
			json.NewEncoder(w).Encode(map[string]string{"status": "active"})
			return
		}
		if r.Method == "POST" && strings.Contains(r.URL.Path, "/stop") {
			stopCalled = true
			w.WriteHeader(200)
			return
		}
		if r.Method == "DELETE" {
			destroyCalled = true
			w.WriteHeader(200)
			return
		}
		w.WriteHeader(404)
	}))
	defer srv.Close()

	b, _ := NewEmberBackend(srv.URL, "key")
	w, err := b.Spawn(context.Background(), SpawnOpts{TaskID: "T1"})
	if err != nil {
		t.Fatalf("Spawn() error: %v", err)
	}

	if err := w.Stop(context.Background()); err != nil {
		t.Errorf("Stop() error: %v", err)
	}
	if !stopCalled {
		t.Error("Stop() did not call the stop endpoint")
	}

	if err := w.Destroy(context.Background()); err != nil {
		t.Errorf("Destroy() error: %v", err)
	}
	if !destroyCalled {
		t.Error("Destroy() did not call the delete endpoint")
	}
}

// ---------------------------------------------------------------------------
// DefaultTTLMinutes constant
// ---------------------------------------------------------------------------

func TestDefaultTTLMinutes(t *testing.T) {
	if DefaultTTLMinutes != 60 {
		t.Errorf("DefaultTTLMinutes = %d, want 60", DefaultTTLMinutes)
	}
}
