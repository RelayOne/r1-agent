package harness

import (
	"context"
	"testing"
	"time"
)

func TestAllScenariosPass(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()

	scenarios := DefaultScenarios()
	report := Run(ctx, scenarios)

	for _, r := range report.Results {
		if !r.Pass {
			t.Errorf("FAIL: %s: %s", r.Name, r.Error)
		}
	}

	if report.Failed > 0 {
		t.Errorf("%d/%d scenarios failed", report.Failed, report.Total)
	}
	t.Logf("Harness: %d/%d passed in %s", report.Passed, report.Total, report.Duration)
}

func TestNewTestEnvCreatesRepo(t *testing.T) {
	env, err := NewTestEnv()
	if err != nil {
		t.Fatal(err)
	}
	defer env.Cleanup()

	if env.RepoRoot == "" {
		t.Error("RepoRoot should be set")
	}
	if env.APIBaseURL == "" {
		t.Error("APIBaseURL should be set")
	}
	if env.APIKey == "" {
		t.Error("APIKey should be set")
	}
}

func TestMockAPIRecordsRequests(t *testing.T) {
	env, err := NewTestEnv()
	if err != nil {
		t.Fatal(err)
	}
	defer env.Cleanup()

	before := len(env.Requests())
	// Make a request
	testMockAPIAuthRequired(context.Background(), env)
	after := len(env.Requests())

	if after <= before {
		t.Errorf("expected requests to be recorded, before=%d after=%d", before, after)
	}
}

func TestSetResponseChangesOutput(t *testing.T) {
	env, err := NewTestEnv()
	if err != nil {
		t.Fatal(err)
	}
	defer env.Cleanup()

	env.SetResponse(apiResponse{
		Model: "test-model",
		Text:  "custom response",
	})

	// The response is stored — we verify the setter doesn't panic
	// Full SSE parsing would require more infrastructure
}

func TestChunkText(t *testing.T) {
	chunks := chunkText("hello world", 5)
	if len(chunks) != 3 { // "hello", " worl", "d"
		t.Errorf("expected 3 chunks, got %d: %v", len(chunks), chunks)
	}
	joined := ""
	for _, c := range chunks {
		joined += c
	}
	if joined != "hello world" {
		t.Errorf("chunks don't reconstruct: %q", joined)
	}
}

func TestChunkTextSingleChunk(t *testing.T) {
	chunks := chunkText("hi", 100)
	if len(chunks) != 1 {
		t.Errorf("expected 1 chunk, got %d", len(chunks))
	}
}

func TestChunkTextEmpty(t *testing.T) {
	chunks := chunkText("", 10)
	if len(chunks) != 0 {
		t.Errorf("expected 0 chunks for empty, got %d", len(chunks))
	}
}
