package repl

import (
	"testing"
)

func TestNewCreatesREPL(t *testing.T) {
	r := New("/tmp/repo")
	if r == nil {
		t.Fatal("New() should return non-nil")
	}
	if r.RepoRoot != "/tmp/repo" {
		t.Errorf("RepoRoot=%q", r.RepoRoot)
	}
	if r.Commands == nil {
		t.Error("Commands map should be initialized")
	}
}

func TestRegisterAddsCommand(t *testing.T) {
	r := New("/tmp/repo")
	r.Register(Command{
		Name:        "test",
		Description: "A test command",
		Usage:       "/test <arg>",
		Run:         func(args string) {},
	})

	if len(r.Commands) != 1 {
		t.Errorf("Commands count=%d, want 1", len(r.Commands))
	}
	cmd, ok := r.Commands["test"]
	if !ok {
		t.Fatal("command 'test' not registered")
	}
	if cmd.Description != "A test command" {
		t.Errorf("Description=%q", cmd.Description)
	}
	if cmd.Usage != "/test <arg>" {
		t.Errorf("Usage=%q", cmd.Usage)
	}
}

func TestRegisterOverwrites(t *testing.T) {
	r := New("/tmp/repo")
	calls := 0
	r.Register(Command{Name: "echo", Run: func(args string) { calls++ }})
	r.Register(Command{Name: "echo", Run: func(args string) { calls += 10 }})
	if calls != 0 {
		t.Error("Register should not execute Run")
	}
	if len(r.Commands) != 1 {
		t.Errorf("Commands count=%d, want 1", len(r.Commands))
	}
}

func TestRegisterMultipleCommands(t *testing.T) {
	r := New("/tmp/repo")
	r.Register(Command{Name: "cmd1", Description: "First"})
	r.Register(Command{Name: "cmd2", Description: "Second"})

	if len(r.Commands) != 2 {
		t.Errorf("Commands count=%d, want 2", len(r.Commands))
	}
}

func TestNewRepoRootPassed(t *testing.T) {
	r := New("/home/user/my-project")
	if r.RepoRoot != "/home/user/my-project" {
		t.Errorf("RepoRoot=%q", r.RepoRoot)
	}
}

func TestNewOnChatNil(t *testing.T) {
	r := New("/tmp/repo")
	if r.OnChat != nil {
		t.Error("OnChat should be nil by default")
	}
}
