package audit

import "fmt"

// ValidatedFinding extends ReviewFinding with validation results.
type ValidatedFinding struct {
	ReviewFinding
	Validated           bool   `json:"validated"`
	ValidatorConfidence int    `json:"validator_confidence"`
	ValidatorNote       string `json:"validator_note"`
}

// BuildValidationPrompt generates a focused prompt for validating a single finding.
func BuildValidationPrompt(finding ReviewFinding, codeContext string) string {
	return fmt.Sprintf(`A code reviewer reported this issue:

Severity: %s
File: %s (line %d)
Issue: %s
Suggestion: %s

Relevant code:
%s

Is this a REAL issue? Respond with ONLY valid JSON:
{"valid": true|false, "confidence": 0-100, "note": "brief explanation"}

False positive checklist:
- Is this pre-existing (not from this change)?
- Is this a style preference, not a bug?
- Is this something a linter would catch?
- Is the code actually correct despite looking suspicious?`,
		finding.Severity, finding.File, finding.Line, finding.Issue, finding.Suggestion, codeContext)
}

// ValidateFindings filters findings through independent validation.
// Each finding is checked by a separate validation prompt.
// Only findings with Validated=true and ValidatorConfidence >= minConfidence pass through.
func ValidateFindings(findings []ReviewFinding, minConfidence int) []ValidatedFinding {
	var validated []ValidatedFinding
	for _, f := range findings {
		// For now, deterministic validation: findings with severity critical/high are auto-validated.
		// AI-based validation will be added when the audit command dispatches agents.
		vf := ValidatedFinding{
			ReviewFinding:       f,
			Validated:           f.Severity == "critical" || f.Severity == "high",
			ValidatorConfidence: 100,
			ValidatorNote:       "auto-validated: severity >= high",
		}
		if !vf.Validated {
			vf.ValidatorConfidence = 50
			vf.ValidatorNote = "below auto-validation threshold; needs AI validation"
		}
		if vf.Validated || vf.ValidatorConfidence >= minConfidence {
			validated = append(validated, vf)
		}
	}
	return validated
}

// ValidationSummary returns a human-readable summary of validation results.
func ValidationSummary(total int, validated []ValidatedFinding) string {
	return fmt.Sprintf("%d findings detected, %d validated, %d filtered", total, len(validated), total-len(validated))
}
