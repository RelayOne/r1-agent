package audit

import (
	"strings"
	"testing"
)

func TestBuildValidationPrompt(t *testing.T) {
	finding := ReviewFinding{
		PersonaID:  "security",
		Severity:   "high",
		File:       "src/auth.ts",
		Line:       42,
		Issue:      "SQL injection via unsanitized input",
		Suggestion: "Use parameterized queries",
		Confidence: 90,
	}
	code := `rows := db.Query("SELECT * FROM users WHERE id=" + input)`

	prompt := BuildValidationPrompt(finding, code)

	if !strings.Contains(prompt, "high") {
		t.Error("prompt should contain severity")
	}
	if !strings.Contains(prompt, "src/auth.ts") {
		t.Error("prompt should contain file path")
	}
	if !strings.Contains(prompt, "42") {
		t.Error("prompt should contain line number")
	}
	if !strings.Contains(prompt, "SQL injection via unsanitized input") {
		t.Error("prompt should contain issue description")
	}
	if !strings.Contains(prompt, "Use parameterized queries") {
		t.Error("prompt should contain suggestion")
	}
	if !strings.Contains(prompt, "SELECT * FROM users") {
		t.Error("prompt should contain code context")
	}
	if !strings.Contains(prompt, "False positive checklist") {
		t.Error("prompt should contain false positive checklist")
	}
}

func TestValidateFindingsCriticalAutoValidated(t *testing.T) {
	findings := []ReviewFinding{
		{
			PersonaID:  "security",
			Severity:   "critical",
			File:       "src/auth.ts",
			Line:       10,
			Issue:      "hardcoded secret",
			Confidence: 95,
		},
	}

	validated := ValidateFindings(findings, 70)

	if len(validated) != 1 {
		t.Fatalf("expected 1 validated finding, got %d", len(validated))
	}
	if !validated[0].Validated {
		t.Error("critical finding should be auto-validated")
	}
	if validated[0].ValidatorConfidence != 100 {
		t.Errorf("expected confidence 100, got %d", validated[0].ValidatorConfidence)
	}
	if validated[0].ValidatorNote != "auto-validated: severity >= high" {
		t.Errorf("unexpected note: %s", validated[0].ValidatorNote)
	}
}

func TestValidateFindingsLowFiltered(t *testing.T) {
	findings := []ReviewFinding{
		{
			PersonaID:  "maintainability",
			Severity:   "low",
			File:       "src/utils.ts",
			Line:       5,
			Issue:      "consider renaming variable",
			Confidence: 40,
		},
	}

	validated := ValidateFindings(findings, 70)

	if len(validated) != 0 {
		t.Fatalf("expected 0 validated findings (low severity filtered at minConfidence=70), got %d", len(validated))
	}
}

func TestValidationSummary(t *testing.T) {
	validated := []ValidatedFinding{
		{
			ReviewFinding: ReviewFinding{Severity: "critical", Issue: "a"},
			Validated:     true,
		},
		{
			ReviewFinding: ReviewFinding{Severity: "high", Issue: "b"},
			Validated:     true,
		},
	}

	summary := ValidationSummary(5, validated)

	expected := "5 findings detected, 2 validated, 3 filtered"
	if summary != expected {
		t.Errorf("summary = %q, want %q", summary, expected)
	}
}
