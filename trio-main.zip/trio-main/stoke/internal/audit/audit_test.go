package audit

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/ericmacdougall/stoke/internal/scan"
)

func TestDefaultPersonas(t *testing.T) {
	personas := DefaultPersonas()
	if len(personas) != 17 {
		t.Fatalf("personas=%d, want 17", len(personas))
	}
	ids := map[string]bool{}
	for _, p := range personas {
		ids[p.ID] = true
		if p.Name == "" {
			t.Errorf("persona %s has no name", p.ID)
		}
		if p.Focus == "" {
			t.Errorf("persona %s has no focus", p.ID)
		}
	}
	// Core 5 must always be present
	for _, required := range []string{"security", "performance", "reliability", "maintainability", "ops"} {
		if !ids[required] {
			t.Errorf("missing core persona: %s", required)
		}
	}
	// Specialized must be present
	for _, required := range []string{"api-design", "concurrency", "testing", "privacy", "compliance"} {
		if !ids[required] {
			t.Errorf("missing specialized persona: %s", required)
		}
	}
}

func TestBuildPromptIncludesContext(t *testing.T) {
	p := Persona{ID: "security", Name: "Security Reviewer", Focus: "auth, injection"}
	req := ReviewRequest{
		Persona:     p,
		Files:       []string{"src/auth.ts"},
		DiffSummary: "+++ new auth code",
		ScanResult: &scan.ScanResult{
			Findings: []scan.Finding{
				{Rule: "no-eval", Severity: "high", File: "src/auth.ts", Line: 10, Message: "eval() is dangerous"},
			},
		},
		SecurityMap: &scan.SecurityMap{
			Surfaces: []scan.SecuritySurface{
				{Category: "auth", File: "src/auth.ts", Line: 5, Note: "JWT usage", Risk: "high"},
			},
		},
	}

	prompt := BuildPrompt(p, req)

	if !strings.Contains(prompt, "Security Reviewer") {
		t.Error("prompt should mention persona")
	}
	if !strings.Contains(prompt, "src/auth.ts") {
		t.Error("prompt should list modified files")
	}
	if !strings.Contains(prompt, "new auth code") {
		t.Error("prompt should include diff")
	}
	if !strings.Contains(prompt, "eval()") {
		t.Error("security persona should see eval finding")
	}
	if !strings.Contains(prompt, "JWT") {
		t.Error("security persona should see security surface")
	}
	if !strings.Contains(prompt, "JSON array") {
		t.Error("prompt should specify output format")
	}
}

func TestBuildPromptPerformance(t *testing.T) {
	p := Persona{ID: "performance", Name: "Performance Reviewer", Focus: "N+1, allocations"}
	req := ReviewRequest{Persona: p, DiffSummary: "changes"}

	prompt := BuildPrompt(p, req)
	if !strings.Contains(prompt, "Performance Reviewer") {
		t.Error("should mention performance")
	}
}

func TestSelectPersonasWithSecurity(t *testing.T) {
	all := DefaultPersonas()
	secMap := &scan.SecurityMap{
		Surfaces: []scan.SecuritySurface{
			{Category: "auth", Risk: "high"},
			{Category: "crypto", Risk: "high"},
		},
	}

	selected := SelectPersonas(all, secMap, nil)
	found := false
	for _, p := range selected {
		if p.ID == "security" {
			found = true
		}
	}
	if !found {
		t.Error("security persona should be selected when auth surface exists")
	}
}

func TestSelectPersonasMinimum(t *testing.T) {
	all := DefaultPersonas()
	// No scan results or security map -- should return core 5
	selected := SelectPersonas(all, nil, nil)
	if len(selected) != 5 {
		t.Errorf("should return 5 core personas when no context, got %d", len(selected))
	}
	ids := map[string]bool{}
	for _, p := range selected {
		ids[p.ID] = true
	}
	for _, core := range []string{"security", "performance", "reliability", "maintainability", "ops"} {
		if !ids[core] {
			t.Errorf("missing core persona: %s", core)
		}
	}
}

func TestFilterFindingsSecurityPersona(t *testing.T) {
	findings := []scan.Finding{
		{Rule: "no-eval", Severity: "high"},
		{Rule: "no-console-log", Severity: "medium"},
		{Rule: "no-hardcoded-secret", Severity: "critical"},
	}
	filtered := filterFindings(findings, "security")
	if len(filtered) != 2 {
		t.Errorf("security persona should see 2 findings (eval + secret), got %d", len(filtered))
	}
}

func TestFilterFindingsMaintainability(t *testing.T) {
	findings := []scan.Finding{
		{Rule: "no-console-log", Severity: "medium"},
		{Rule: "no-eval", Severity: "high"},
		{Rule: "no-todo-fixme", Severity: "low"},
	}
	filtered := filterFindings(findings, "maintainability")
	if len(filtered) != 2 {
		t.Errorf("maintainability should see console-log + todo, got %d", len(filtered))
	}
}

func TestLoadPersonasFromDir(t *testing.T) {
	dir := t.TempDir()

	// Write a valid persona file
	content := "# Custom Security Expert\nInjection, XSS, CSRF, secrets management\nExtra body text here.\n"
	if err := os.WriteFile(filepath.Join(dir, "custom-sec.md"), []byte(content), 0644); err != nil {
		t.Fatal(err)
	}

	// Write a non-md file that should be skipped
	if err := os.WriteFile(filepath.Join(dir, "notes.txt"), []byte("not a persona"), 0644); err != nil {
		t.Fatal(err)
	}

	// Write a file with only one line (should be skipped)
	if err := os.WriteFile(filepath.Join(dir, "incomplete.md"), []byte("# Only Name"), 0644); err != nil {
		t.Fatal(err)
	}

	personas, err := LoadPersonasFromDir(dir)
	if err != nil {
		t.Fatalf("LoadPersonasFromDir: %v", err)
	}

	if len(personas) != 1 {
		t.Fatalf("expected 1 persona, got %d", len(personas))
	}

	p := personas[0]
	if p.ID != "custom-sec" {
		t.Errorf("ID=%q, want %q", p.ID, "custom-sec")
	}
	if p.Name != "Custom Security Expert" {
		t.Errorf("Name=%q, want %q", p.Name, "Custom Security Expert")
	}
	if p.Focus != "Injection, XSS, CSRF, secrets management" {
		t.Errorf("Focus=%q, want %q", p.Focus, "Injection, XSS, CSRF, secrets management")
	}
}

func TestLoadPersonasFromDirNotExist(t *testing.T) {
	_, err := LoadPersonasFromDir("/nonexistent/path/to/personas")
	if err == nil {
		t.Error("expected error for nonexistent directory")
	}
}

func TestLoadPersonasFromDirEmpty(t *testing.T) {
	dir := t.TempDir()
	personas, err := LoadPersonasFromDir(dir)
	if err != nil {
		t.Fatalf("LoadPersonasFromDir: %v", err)
	}
	if len(personas) != 0 {
		t.Errorf("expected 0 personas from empty dir, got %d", len(personas))
	}
}
func TestFindRelatedCodeReturnsResults(t *testing.T) {
	dir := t.TempDir()
	authContent := `package auth

func ValidateJWT(token string) error {
	return nil
}
`
	dbContent := `package db

func QueryUsers(limit int) []string {
	return nil
}
`
	if err := os.WriteFile(filepath.Join(dir, "auth.go"), []byte(authContent), 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "db.go"), []byte(dbContent), 0644); err != nil {
		t.Fatal(err)
	}

	finding := ReviewFinding{
		Issue: "JWT token validation is missing expiry check",
	}
	related := FindRelatedCode(finding, dir)
	if len(related) == 0 {
		t.Fatal("expected at least one related file")
	}
	if related[0] != "auth.go" {
		t.Errorf("expected auth.go as top result, got %q", related[0])
	}
}

func TestFindRelatedCodeEmptyDir(t *testing.T) {
	dir := t.TempDir()
	finding := ReviewFinding{Issue: "some issue"}
	related := FindRelatedCode(finding, dir)
	if related != nil {
		t.Errorf("expected nil for empty dir, got %v", related)
	}
}

func TestFindRelatedCodeNonexistentDir(t *testing.T) {
	finding := ReviewFinding{Issue: "some issue"}
	related := FindRelatedCode(finding, "/nonexistent/path/that/does/not/exist")
	if related != nil {
		t.Errorf("expected nil for nonexistent dir, got %v", related)
	}
}

