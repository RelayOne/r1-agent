package model

import "testing"

func TestInferTaskType(t *testing.T) {
	tests := map[string]TaskType{
		"design the service architecture": TaskTypeArchitecture,
		"fix docker deployment":           TaskTypeDevOps,
		"debug a race condition":          TaskTypeConcurrency,
		"update the README":               TaskTypeDocs,
		"tighten auth checks":             TaskTypeSecurity,
		"remove type errors":              TaskTypeTypeSafety,
		"review this patch":               TaskTypeReview,
		"refactor the handler":            TaskTypeRefactor,
	}
	for in, want := range tests {
		if got := InferTaskType(in); got != want {
			t.Fatalf("InferTaskType(%q) = %q, want %q", in, got, want)
		}
	}
}

func TestResolvePrimaryAvailable(t *testing.T) {
	p := Resolve(TaskTypeRefactor, func(p Provider) bool { return true })
	if p != ProviderClaude {
		t.Errorf("refactor primary should be claude, got %s", p)
	}
}

func TestResolveFallbackWhenPrimaryUnavailable(t *testing.T) {
	p := Resolve(TaskTypeRefactor, func(p Provider) bool { return p != ProviderClaude })
	if p != ProviderCodex {
		t.Errorf("should fall back to codex, got %s", p)
	}
}

func TestResolveAllUnavailableFallsToLintOnly(t *testing.T) {
	p := Resolve(TaskTypeRefactor, func(p Provider) bool { return false })
	if p != ProviderLintOnly {
		t.Errorf("should fall back to lint-only, got %s", p)
	}
}

func TestResolveLintOnlyInChain(t *testing.T) {
	// Docs and Review have lint-only in their fallback chain
	p := Resolve(TaskTypeDocs, func(p Provider) bool { return false })
	if p != ProviderLintOnly {
		t.Errorf("docs should have lint-only fallback, got %s", p)
	}
}

func TestCrossModelReviewer(t *testing.T) {
	if CrossModelReviewer(ProviderClaude) != ProviderCodex {
		t.Error("claude execute -> codex review")
	}
	if CrossModelReviewer(ProviderCodex) != ProviderClaude {
		t.Error("codex execute -> claude review")
	}
}

func TestInferCategory(t *testing.T) {
	tests := []struct {
		task     string
		taskType TaskType
		want     Category
	}{
		// Description-based inference takes priority.
		{"fix SQL injection vulnerability", TaskTypeRefactor, CategorySecurity},
		{"write tests for the handler", TaskTypeRefactor, CategoryTest},
		{"fix typo in config", TaskTypeRefactor, CategoryQuickFix},
		{"refactor across all services", TaskTypeRefactor, CategoryDeepRefactor},
		{"update the readme", TaskTypeRefactor, CategoryDocs},
		// Falls back to task type when description has no signal.
		{"improve the module", TaskTypeSecurity, CategorySecurity},
		{"improve the module", TaskTypeDocs, CategoryDocs},
		{"improve the module", TaskTypeRefactor, CategoryDeepRefactor},
		{"improve the module", TaskTypeTypeSafety, CategoryQuickFix},
		{"improve the module", TaskTypeReview, CategoryTest},
		{"improve the module", TaskTypeDevOps, CategoryDeepRefactor},
	}
	for _, tt := range tests {
		got := InferCategory(tt.task, tt.taskType)
		if got != tt.want {
			t.Errorf("InferCategory(%q, %q) = %q, want %q", tt.task, tt.taskType, got, tt.want)
		}
	}
}

func TestResolveByCategoryPrimary(t *testing.T) {
	allAvailable := func(p Provider) bool { return true }

	cases := []struct {
		cat  Category
		want Provider
	}{
		{CategoryDeepRefactor, ProviderClaude},
		{CategoryQuickFix, ProviderOpenRouter},
		{CategorySecurity, ProviderClaude},
		{CategoryDocs, ProviderGemini},
		{CategoryTest, ProviderCodex},
	}
	for _, c := range cases {
		got := ResolveByCategory(c.cat, allAvailable)
		if got != c.want {
			t.Errorf("ResolveByCategory(%q) primary = %q, want %q", c.cat, got, c.want)
		}
	}
}

func TestResolveByCategoryFallback(t *testing.T) {
	// Primary unavailable for deep-refactor (Claude), should fall to Codex.
	p := ResolveByCategory(CategoryDeepRefactor, func(p Provider) bool { return p != ProviderClaude })
	if p != ProviderCodex {
		t.Errorf("deep-refactor fallback should be codex, got %s", p)
	}
}

func TestResolveByCategoryAllUnavailable(t *testing.T) {
	p := ResolveByCategory(CategoryDeepRefactor, func(p Provider) bool { return false })
	if p != ProviderLintOnly {
		t.Errorf("should fall back to lint-only, got %s", p)
	}
}

func TestResolveByCategoryUnknown(t *testing.T) {
	// Unknown category should use deep-refactor default (Claude).
	p := ResolveByCategory(Category("unknown"), func(p Provider) bool { return true })
	if p != ProviderClaude {
		t.Errorf("unknown category should default to claude, got %s", p)
	}
}

func TestGeminiInFallbackChain(t *testing.T) {
	// Verify Gemini appears in the fallback chain for Docs task type.
	route, ok := Routes[TaskTypeDocs]
	if !ok {
		t.Fatal("no route for TaskTypeDocs")
	}
	found := false
	for _, fb := range route.FallbackChain {
		if fb == ProviderGemini {
			found = true
			break
		}
	}
	if !found {
		t.Error("ProviderGemini should be in Docs fallback chain")
	}

	// Also verify Gemini appears in Review fallback chain.
	route, ok = Routes[TaskTypeReview]
	if !ok {
		t.Fatal("no route for TaskTypeReview")
	}
	found = false
	for _, fb := range route.FallbackChain {
		if fb == ProviderGemini {
			found = true
			break
		}
	}
	if !found {
		t.Error("ProviderGemini should be in Review fallback chain")
	}
}

func TestResolveGeminiAvailable(t *testing.T) {
	// When Gemini is available, it should be selected as primary for CategoryDocs.
	allAvailable := func(p Provider) bool { return true }
	got := ResolveByCategory(CategoryDocs, allAvailable)
	if got != ProviderGemini {
		t.Errorf("CategoryDocs primary = %q, want %q", got, ProviderGemini)
	}
}

func TestResolveGeminiFallback(t *testing.T) {
	// When Gemini is unavailable, CategoryDocs should fall through to OpenRouter.
	noGemini := func(p Provider) bool { return p != ProviderGemini }
	got := ResolveByCategory(CategoryDocs, noGemini)
	if got != ProviderOpenRouter {
		t.Errorf("CategoryDocs with Gemini unavailable = %q, want %q", got, ProviderOpenRouter)
	}
}

func TestAllRoutesHaveFallbackChain(t *testing.T) {
	for tt, route := range Routes {
		if len(route.FallbackChain) == 0 {
			t.Errorf("route %s has no fallback chain", tt)
		}
		if route.Primary == "" {
			t.Errorf("route %s has no primary", tt)
		}
	}
}
