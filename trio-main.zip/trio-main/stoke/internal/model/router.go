// Package model routes task types to execution providers using benchmark-backed
// rankings and a multi-provider fallback chain. It also selects cross-model
// reviewers for implementation verification.
package model

import "strings"

type TaskType string

const (
	TaskTypePlan         TaskType = "plan"
	TaskTypeRefactor     TaskType = "refactor"
	TaskTypeTypeSafety   TaskType = "typesafety"
	TaskTypeDocs         TaskType = "docs"
	TaskTypeSecurity     TaskType = "security"
	TaskTypeArchitecture TaskType = "architecture"
	TaskTypeDevOps       TaskType = "devops"
	TaskTypeConcurrency  TaskType = "concurrency"
	TaskTypeReview       TaskType = "review"
)

// Provider identifies an execution engine.
type Provider string

const (
	ProviderClaude     Provider = "claude"     // Claude Code headless (subscription, $0 marginal)
	ProviderCodex      Provider = "codex"      // Codex CLI (subscription, $0 marginal)
	ProviderOpenRouter Provider = "openrouter" // OpenRouter API (multi-model, pay-per-token)
	ProviderGemini     Provider = "gemini"     // Gemini API (multi-modal, creative tasks)
	ProviderDirectAPI  Provider = "direct-api"  // Direct Anthropic/OpenAI API (pay-per-token)
	ProviderNativeAPI  Provider = "native-api"  // Native API runner via apiclient (no subprocess)
	ProviderLintOnly   Provider = "lint-only"   // No model: just run build/test/lint
)

// Route defines the primary engine and full fallback chain per task type.
// Spec §10: Claude -> Codex -> OpenRouter -> Direct API -> lint-only
type Route struct {
	Primary       Provider
	FallbackChain []Provider // tried in order when primary is unavailable
	Reason        string
}

// Routes is the benchmark-backed routing table.
// Data sources: YUV.AI benchmarks, Terminal-Bench, Milvus code review study.
var Routes = map[TaskType]Route{
	TaskTypePlan: {
		Primary:       ProviderClaude,
		FallbackChain: []Provider{ProviderCodex, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI},
		Reason:        "best at ambiguous prompts",
	},
	TaskTypeRefactor: {
		Primary:       ProviderClaude,
		FallbackChain: []Provider{ProviderCodex, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI},
		Reason:        "4.9/5 refactoring (YUV.AI)",
	},
	TaskTypeTypeSafety: {
		Primary:       ProviderClaude,
		FallbackChain: []Provider{ProviderCodex, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI},
		Reason:        "4.7/5 vs 4.2/5 (YUV.AI)",
	},
	TaskTypeDocs: {
		Primary:       ProviderClaude,
		FallbackChain: []Provider{ProviderCodex, ProviderGemini, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI, ProviderLintOnly},
		Reason:        "4.9/5 vs 4.4/5 (YUV.AI)",
	},
	TaskTypeSecurity: {
		Primary:       ProviderClaude,
		FallbackChain: []Provider{ProviderCodex, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI},
		Reason:        "53% solo detection, 100% precision (Milvus)",
	},
	TaskTypeArchitecture: {
		Primary:       ProviderCodex,
		FallbackChain: []Provider{ProviderClaude, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI},
		Reason:        "4.8/5 vs 4.3/5 (YUV.AI)",
	},
	TaskTypeDevOps: {
		Primary:       ProviderCodex,
		FallbackChain: []Provider{ProviderClaude, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI},
		Reason:        "Terminal-Bench 77.3% vs 65.4%",
	},
	TaskTypeConcurrency: {
		Primary:       ProviderCodex,
		FallbackChain: []Provider{ProviderClaude, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI},
		Reason:        "Claude blind spot: 0/2 in Milvus study",
	},
	TaskTypeReview: {
		Primary:       ProviderCodex,
		FallbackChain: []Provider{ProviderClaude, ProviderGemini, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI, ProviderLintOnly},
		Reason:        "GPT high recall first, Claude high precision second (BSWEN pipeline)",
	},
}

// Resolve returns the provider to use for a task type, considering availability.
// isAvailable is called for each provider in order until one returns true.
func Resolve(taskType TaskType, isAvailable func(Provider) bool) Provider {
	route, ok := Routes[taskType]
	if !ok {
		route = Routes[TaskTypeRefactor] // safe default
	}

	if isAvailable(route.Primary) {
		return route.Primary
	}

	for _, fb := range route.FallbackChain {
		if fb == ProviderLintOnly || isAvailable(fb) {
			return fb
		}
	}

	return ProviderLintOnly
}

// CrossModelReviewer returns the review provider for a given execute provider.
// Spec: "Claude implements -> GPT reviews. GPT implements -> Claude reviews."
func CrossModelReviewer(executeProvider Provider) Provider {
	switch executeProvider {
	case ProviderClaude:
		return ProviderCodex
	case ProviderCodex:
		return ProviderClaude
	default:
		return ProviderClaude // default reviewer
	}
}

func InferTaskType(task string) TaskType {
	s := strings.ToLower(task)
	switch {
	case containsAny(s, "architecture", "design", "schema", "topology"):
		return TaskTypeArchitecture
	case containsAny(s, "docker", "kubernetes", "k8s", "terraform", "deploy", "devops", "ci", "cd"):
		return TaskTypeDevOps
	case containsAny(s, "race", "concurrent", "deadlock", "mutex", "parallel"):
		return TaskTypeConcurrency
	case containsAny(s, "documentation", "readme", "docs", "comment"):
		return TaskTypeDocs
	case containsAny(s, "security", "auth", "oauth", "csrf", "xss", "secret"):
		return TaskTypeSecurity
	case containsAny(s, "types", "type", "typescript", "tsc", "typing"):
		return TaskTypeTypeSafety
	case containsAny(s, "review", "audit"):
		return TaskTypeReview
	default:
		return TaskTypeRefactor
	}
}

// Category describes the semantic intent of a task, orthogonal to TaskType.
// Categories map to model tiers: strongest, mid-tier, or fast/cheap.
type Category string

const (
	CategoryDeepRefactor Category = "deep-refactor" // complex multi-file reasoning
	CategoryQuickFix     Category = "quick-fix"     // single-file trivial changes
	CategorySecurity     Category = "security"       // security review and fixes
	CategoryDocs         Category = "docs"           // documentation and comments
	CategoryTest         Category = "test"           // test writing
)

// categoryRoutes maps each category to a preferred provider chain.
// Strongest = Claude, Mid-tier = Codex, Fast/cheap = OpenRouter.
var categoryRoutes = map[Category]Route{
	CategoryDeepRefactor: {
		Primary:       ProviderClaude,
		FallbackChain: []Provider{ProviderCodex, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI},
		Reason:        "complex reasoning needs strongest model",
	},
	CategoryQuickFix: {
		Primary:       ProviderOpenRouter,
		FallbackChain: []Provider{ProviderCodex, ProviderClaude, ProviderDirectAPI, ProviderNativeAPI, ProviderLintOnly},
		Reason:        "trivial fix, optimize for speed/cost",
	},
	CategorySecurity: {
		Primary:       ProviderClaude,
		FallbackChain: []Provider{ProviderCodex, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI},
		Reason:        "security requires highest precision",
	},
	CategoryDocs: {
		Primary:       ProviderGemini,
		FallbackChain: []Provider{ProviderOpenRouter, ProviderCodex, ProviderClaude, ProviderDirectAPI, ProviderNativeAPI, ProviderLintOnly},
		Reason:        "Gemini excels at documentation and creative writing",
	},
	CategoryTest: {
		Primary:       ProviderCodex,
		FallbackChain: []Provider{ProviderClaude, ProviderOpenRouter, ProviderDirectAPI, ProviderNativeAPI},
		Reason:        "test writing is mid-tier complexity",
	},
}

// InferCategory determines the semantic category from a task description and type.
// It checks the description for signal words first, then falls back to the task type.
func InferCategory(task string, taskType TaskType) Category {
	s := strings.ToLower(task)

	// Description-based signals take priority.
	switch {
	case containsAny(s, "security", "vulnerability", "cve", "exploit", "auth bypass", "injection"):
		return CategorySecurity
	case containsAny(s, "test", "spec", "coverage", "assert"):
		return CategoryTest
	case containsAny(s, "typo", "rename", "one-liner", "quick fix", "simple fix", "trivial"):
		return CategoryQuickFix
	case containsAny(s, "refactor across", "multi-file", "large refactor", "rewrite", "migrate"):
		return CategoryDeepRefactor
	case containsAny(s, "doc", "readme", "comment", "changelog"):
		return CategoryDocs
	}

	// Fall back to task type mapping.
	switch taskType {
	case TaskTypeSecurity:
		return CategorySecurity
	case TaskTypeDocs:
		return CategoryDocs
	case TaskTypeRefactor, TaskTypePlan, TaskTypeArchitecture:
		return CategoryDeepRefactor
	case TaskTypeConcurrency, TaskTypeDevOps:
		return CategoryDeepRefactor
	case TaskTypeTypeSafety:
		return CategoryQuickFix
	case TaskTypeReview:
		return CategoryTest
	default:
		return CategoryDeepRefactor
	}
}

// ResolveByCategory picks the optimal provider for a category, respecting availability.
func ResolveByCategory(category Category, isAvailable func(Provider) bool) Provider {
	route, ok := categoryRoutes[category]
	if !ok {
		route = categoryRoutes[CategoryDeepRefactor] // safe default
	}

	if isAvailable(route.Primary) {
		return route.Primary
	}

	for _, fb := range route.FallbackChain {
		if fb == ProviderLintOnly || isAvailable(fb) {
			return fb
		}
	}

	return ProviderLintOnly
}

func containsAny(s string, needles ...string) bool {
	for _, needle := range needles {
		if strings.Contains(s, needle) {
			return true
		}
	}
	return false
}
