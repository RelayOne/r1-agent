// Package surfacemap maps API endpoints to consumers across languages.
// It performs deterministic regex-based extraction of HTTP route definitions
// and HTTP client call sites from Go, TypeScript/JavaScript, and Python source
// files, then matches consumers to endpoints by URL pattern and HTTP method.
package surfacemap

import (
	"os"
	"path/filepath"
	"strings"
)

// Endpoint is an API route definition found in source code.
type Endpoint struct {
	Method   string `json:"method"`   // GET, POST, PUT, DELETE
	Path     string `json:"path"`     // /api/users/:id
	File     string `json:"file"`     // source file
	Line     int    `json:"line"`
	Handler  string `json:"handler"`  // handler function name
	Language string `json:"language"` // go, typescript, python
}

// Consumer is a call site that hits an API endpoint.
type Consumer struct {
	URL      string `json:"url"`    // the URL being called
	Method   string `json:"method"` // HTTP method
	File     string `json:"file"`
	Line     int    `json:"line"`
	Language string `json:"language"`
}

// Binding links a consumer to a specific endpoint.
type Binding struct {
	Consumer   Consumer  `json:"consumer"`
	Endpoint   *Endpoint `json:"endpoint,omitempty"` // nil if no match found
	Confidence float64   `json:"confidence"`         // 0-1 match confidence
}

// ContractGap is a mismatch between consumer and provider.
type ContractGap struct {
	Consumer Consumer  `json:"consumer"`
	Endpoint *Endpoint `json:"endpoint,omitempty"`
	Issue    string    `json:"issue"`    // "no matching endpoint", "method mismatch"
	Severity string    `json:"severity"` // "blocking", "warning"
}

// SurfaceMap is the complete cross-surface dependency map.
type SurfaceMap struct {
	Endpoints []Endpoint    `json:"endpoints"`
	Consumers []Consumer    `json:"consumers"`
	Bindings  []Binding     `json:"bindings"`
	Gaps      []ContractGap `json:"gaps"`
}

// Build scans the repo at root and builds the surface map.
func Build(root string) (*SurfaceMap, error) {
	sm := &SurfaceMap{}

	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil // skip unreadable entries
		}
		if info.IsDir() {
			base := info.Name()
			switch base {
			case "node_modules", ".git", "vendor", "__pycache__",
				"dist", "build", ".next", ".turbo", ".cache",
				"coverage", ".nyc_output", ".stoke":
				return filepath.SkipDir
			}
			return nil
		}

		ext := strings.ToLower(filepath.Ext(path))
		rel, _ := filepath.Rel(root, path)
		base := info.Name()

		// Skip test files — they contain mock routes/consumers that add noise
		if strings.HasSuffix(base, "_test.go") || strings.HasSuffix(base, ".test.ts") ||
			strings.HasSuffix(base, ".test.js") || strings.HasSuffix(base, ".spec.ts") ||
			strings.HasSuffix(base, ".spec.js") || strings.HasSuffix(base, "_test.py") {
			return nil
		}

		switch ext {
		case ".go":
			endpoints, consumers := extractGo(path, rel)
			sm.Endpoints = append(sm.Endpoints, endpoints...)
			sm.Consumers = append(sm.Consumers, consumers...)
		case ".ts", ".tsx", ".js", ".jsx":
			endpoints, consumers := extractTS(path, rel)
			sm.Endpoints = append(sm.Endpoints, endpoints...)
			sm.Consumers = append(sm.Consumers, consumers...)
		case ".py":
			endpoints, consumers := extractPy(path, rel)
			sm.Endpoints = append(sm.Endpoints, endpoints...)
			sm.Consumers = append(sm.Consumers, consumers...)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}

	// Filter out consumers that call external third-party APIs.
	// These are not internal surface gaps — they're expected external dependencies.
	var internalConsumers []Consumer
	for _, c := range sm.Consumers {
		if !isExternalURL(c.URL) {
			internalConsumers = append(internalConsumers, c)
		}
	}
	sm.Consumers = internalConsumers

	sm.Bindings, sm.Gaps = matchConsumers(sm.Endpoints, sm.Consumers)
	return sm, nil
}

// isExternalURL returns true for URLs pointing to third-party APIs.
func isExternalURL(url string) bool {
	externalDomains := []string{
		"github.com", "api.github.com", "googleapis.com",
		"openidconnect.googleapis.com", "api.stripe.com",
		"api.openai.com", "api.anthropic.com", "openrouter.ai",
		"api.voyageai.com", "pkg.go.dev",
	}
	for _, domain := range externalDomains {
		if strings.Contains(url, domain) {
			return true
		}
	}
	// Template variables that clearly reference external services
	if strings.Contains(url, "${FLY_API}") || strings.Contains(url, "${STRIPE_") {
		return true
	}
	// HTTP header names misdetected as URLs
	// HTTP header names and short tokens misdetected as URLs
	if len(url) < 5 || !strings.Contains(url, "/") {
		return true // not a URL path
	}
	return false
}

// matchConsumers matches each consumer to the best endpoint by URL and method.
func matchConsumers(endpoints []Endpoint, consumers []Consumer) ([]Binding, []ContractGap) {
	var bindings []Binding
	var gaps []ContractGap
	matched := make(map[int]bool) // tracks which endpoints were matched

	for _, c := range consumers {
		best, bestConf, bestIdx := findBestEndpoint(c, endpoints)
		if best != nil && bestConf > 0 {
			ep := *best
			bindings = append(bindings, Binding{
				Consumer:   c,
				Endpoint:   &ep,
				Confidence: bestConf,
			})
			matched[bestIdx] = true
		} else {
			// Check if there's a path match but method mismatch.
			pathMatch := findPathOnlyMatch(c, endpoints)
			if pathMatch != nil {
				ep := *pathMatch
				gaps = append(gaps, ContractGap{
					Consumer: c,
					Endpoint: &ep,
					Issue:    "method mismatch",
					Severity: "warning",
				})
			} else {
				gaps = append(gaps, ContractGap{
					Consumer: c,
					Issue:    "no matching endpoint",
					Severity: "blocking",
				})
			}
		}
	}

	// Dead endpoints: defined but never consumed.
	for i, ep := range endpoints {
		if !matched[i] {
			epCopy := ep
			gaps = append(gaps, ContractGap{
				Endpoint: &epCopy,
				Issue:    "dead endpoint",
				Severity: "warning",
			})
		}
	}

	return bindings, gaps
}

// findBestEndpoint returns the best-matching endpoint for a consumer.
func findBestEndpoint(c Consumer, endpoints []Endpoint) (*Endpoint, float64, int) {
	var best *Endpoint
	bestConf := 0.0
	bestIdx := -1

	for i := range endpoints {
		ep := &endpoints[i]
		conf := matchScore(c, ep)
		if conf > bestConf {
			best = ep
			bestConf = conf
			bestIdx = i
		}
	}
	return best, bestConf, bestIdx
}

// matchScore computes a 0-1 confidence for a consumer-endpoint pair.
func matchScore(c Consumer, ep *Endpoint) float64 {
	pathConf := pathMatch(c.URL, ep.Path)
	if pathConf == 0 {
		return 0
	}

	methodConf := 0.0
	cm := strings.ToUpper(c.Method)
	em := strings.ToUpper(ep.Method)
	if cm == em {
		methodConf = 1.0
	} else if cm == "" || em == "" {
		// Unknown method — partial credit.
		methodConf = 0.5
	}

	return pathConf * methodConf
}

// pathMatch compares a consumer URL to an endpoint path pattern.
// Returns 0 for no match, 0-1 for partial/full match.
func pathMatch(url, pattern string) float64 {
	// Normalise: strip scheme/host, get just the path.
	urlPath := extractPath(url)
	patPath := extractPath(pattern)

	if urlPath == "" || patPath == "" {
		return 0
	}

	urlParts := splitPath(urlPath)
	patParts := splitPath(patPath)

	if len(urlParts) != len(patParts) {
		return 0
	}

	matchedSegments := 0
	for i, pp := range patParts {
		up := urlParts[i]
		if isParam(pp) {
			// :id, {id}, <id> — matches anything.
			matchedSegments++
		} else if strings.EqualFold(up, pp) {
			matchedSegments++
		} else if isParam(up) {
			// Consumer uses a variable too — plausible match.
			matchedSegments++
		} else {
			return 0
		}
	}

	if len(patParts) == 0 {
		return 0
	}
	return float64(matchedSegments) / float64(len(patParts))
}

// extractPath strips scheme, host, and query from a URL, returning just the path.
func extractPath(raw string) string {
	s := raw
	// Strip template literals markers.
	s = strings.ReplaceAll(s, "${", "")
	s = strings.ReplaceAll(s, "}", "")

	// Strip scheme+host.
	if idx := strings.Index(s, "://"); idx != -1 {
		s = s[idx+3:]
		if idx2 := strings.Index(s, "/"); idx2 != -1 {
			s = s[idx2:]
		} else {
			return "/"
		}
	}

	// Strip query string.
	if idx := strings.Index(s, "?"); idx != -1 {
		s = s[:idx]
	}

	// Ensure leading slash.
	if s == "" || s[0] != '/' {
		return ""
	}

	return strings.TrimRight(s, "/")
}

// splitPath splits a path into segments, ignoring empty parts.
func splitPath(p string) []string {
	var parts []string
	for _, seg := range strings.Split(p, "/") {
		if seg != "" {
			parts = append(parts, seg)
		}
	}
	return parts
}

// isParam detects path-parameter segments like :id, {id}, <id>, and $id.
func isParam(seg string) bool {
	return strings.HasPrefix(seg, ":") ||
		strings.HasPrefix(seg, "{") ||
		strings.HasPrefix(seg, "<") ||
		strings.HasPrefix(seg, "$")
}
