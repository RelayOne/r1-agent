package surfacemap

import (
	"os"
	"regexp"
	"strings"
)

// Go route-definition patterns.
var goRoutePatterns = []*regexp.Regexp{
	// http.HandleFunc("/path", handler) or mux.HandleFunc("/path", handler)
	regexp.MustCompile(`(?:http|mux)\.\s*HandleFunc\(\s*"([^"]+)"\s*,\s*(\w+)`),

	// http.Handle("/path", handler) or mux.Handle("/path", handler)
	regexp.MustCompile(`(?:http|mux)\.\s*Handle\(\s*"([^"]+)"\s*,\s*(\w+)`),

	// r.GET("/path", handler) / r.POST(...) / r.PUT(...) / r.DELETE(...) — Gin/Echo style
	regexp.MustCompile(`\b\w+\.(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\(\s*"([^"]+)"\s*,\s*(\w+)`),

	// router.Handle("METHOD", "/path", handler) — Chi style
	regexp.MustCompile(`\b\w+\.Handle\(\s*"(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)"\s*,\s*"([^"]+)"\s*,\s*(\w+)`),
}

// Go consumer patterns.
var goConsumerPatterns = []*regexp.Regexp{
	// http.Get("url")
	regexp.MustCompile(`http\.\s*Get\(\s*"([^"]+)"\s*\)`),

	// http.Post("url", ...)
	regexp.MustCompile(`http\.\s*Post\(\s*"([^"]+)"\s*,`),

	// http.NewRequest("METHOD", "url", ...)
	regexp.MustCompile(`http\.\s*NewRequest\(\s*"(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)"\s*,\s*"([^"]+)"`),

	// client.Get("url") / client.Post("url", ...) etc.
	regexp.MustCompile(`\b\w+\.\s*(Get|Post|Put|Delete|Patch)\(\s*"([^"]+)"`),
}

// extractGo extracts endpoints and consumers from a Go source file.
func extractGo(absPath, relPath string) ([]Endpoint, []Consumer) {
	data, err := os.ReadFile(absPath)
	if err != nil {
		return nil, nil
	}
	content := string(data)
	lines := strings.Split(content, "\n")

	var endpoints []Endpoint
	var consumers []Consumer

	for lineNum, line := range lines {
		ln := lineNum + 1 // 1-indexed

		// --- Route definitions ---

		// http.HandleFunc / mux.HandleFunc
		if m := goRoutePatterns[0].FindStringSubmatch(line); m != nil {
			endpoints = append(endpoints, Endpoint{
				Method:   "",
				Path:     m[1],
				File:     relPath,
				Line:     ln,
				Handler:  m[2],
				Language: "go",
			})
			continue
		}

		// http.Handle / mux.Handle
		if m := goRoutePatterns[1].FindStringSubmatch(line); m != nil {
			endpoints = append(endpoints, Endpoint{
				Method:   "",
				Path:     m[1],
				File:     relPath,
				Line:     ln,
				Handler:  m[2],
				Language: "go",
			})
			continue
		}

		// r.GET(...) Gin/Echo style — capture group 1=method, 2=path, 3=handler
		if m := goRoutePatterns[2].FindStringSubmatch(line); m != nil {
			endpoints = append(endpoints, Endpoint{
				Method:   strings.ToUpper(m[1]),
				Path:     m[2],
				File:     relPath,
				Line:     ln,
				Handler:  m[3],
				Language: "go",
			})
			continue
		}

		// router.Handle("METHOD", "/path", handler) Chi style
		if m := goRoutePatterns[3].FindStringSubmatch(line); m != nil {
			endpoints = append(endpoints, Endpoint{
				Method:   strings.ToUpper(m[1]),
				Path:     m[2],
				File:     relPath,
				Line:     ln,
				Handler:  m[3],
				Language: "go",
			})
			continue
		}

		// --- Consumer patterns ---

		// http.Get("url")
		if m := goConsumerPatterns[0].FindStringSubmatch(line); m != nil {
			consumers = append(consumers, Consumer{
				URL:      m[1],
				Method:   "GET",
				File:     relPath,
				Line:     ln,
				Language: "go",
			})
			continue
		}

		// http.Post("url", ...)
		if m := goConsumerPatterns[1].FindStringSubmatch(line); m != nil {
			consumers = append(consumers, Consumer{
				URL:      m[1],
				Method:   "POST",
				File:     relPath,
				Line:     ln,
				Language: "go",
			})
			continue
		}

		// http.NewRequest("METHOD", "url", ...)
		if m := goConsumerPatterns[2].FindStringSubmatch(line); m != nil {
			consumers = append(consumers, Consumer{
				URL:      m[2],
				Method:   strings.ToUpper(m[1]),
				File:     relPath,
				Line:     ln,
				Language: "go",
			})
			continue
		}

		// client.Get/Post/Put/Delete("url")
		if m := goConsumerPatterns[3].FindStringSubmatch(line); m != nil {
			method := strings.ToUpper(m[1])
			consumers = append(consumers, Consumer{
				URL:      m[2],
				Method:   method,
				File:     relPath,
				Line:     ln,
				Language: "go",
			})
			continue
		}
	}

	return endpoints, consumers
}

// findPathOnlyMatch checks if any endpoint has a matching path but different method.
func findPathOnlyMatch(c Consumer, endpoints []Endpoint) *Endpoint {
	for i := range endpoints {
		ep := &endpoints[i]
		p := pathMatch(c.URL, ep.Path)
		if p > 0 {
			cm := strings.ToUpper(c.Method)
			em := strings.ToUpper(ep.Method)
			if cm != em && cm != "" && em != "" {
				return ep
			}
		}
	}
	return nil
}
