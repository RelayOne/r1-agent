package surfacemap

import (
	"os"
	"path/filepath"
	"testing"
)

// --- Go endpoint extraction ---

func TestExtractGoEndpoints(t *testing.T) {
	src := `package main

import "net/http"

func main() {
	http.HandleFunc("/api/users", listUsers)
	mux.HandleFunc("/api/users/:id", getUser)
	http.Handle("/static/", fileServer)
	r.GET("/api/items", listItems)
	r.POST("/api/items", createItem)
	r.PUT("/api/items/:id", updateItem)
	r.DELETE("/api/items/:id", deleteItem)
	router.Handle("GET", "/api/health", healthCheck)
}
`
	dir := t.TempDir()
	fp := filepath.Join(dir, "main.go")
	writeFile(t, fp, src)

	endpoints, _ := extractGo(fp, "main.go")

	expect := []struct {
		method  string
		path    string
		handler string
	}{
		{"", "/api/users", "listUsers"},
		{"", "/api/users/:id", "getUser"},
		{"", "/static/", "fileServer"},
		{"GET", "/api/items", "listItems"},
		{"POST", "/api/items", "createItem"},
		{"PUT", "/api/items/:id", "updateItem"},
		{"DELETE", "/api/items/:id", "deleteItem"},
		{"GET", "/api/health", "healthCheck"},
	}

	if len(endpoints) != len(expect) {
		t.Fatalf("expected %d endpoints, got %d: %+v", len(expect), len(endpoints), endpoints)
	}
	for i, e := range expect {
		got := endpoints[i]
		if got.Method != e.method || got.Path != e.path || got.Handler != e.handler {
			t.Errorf("endpoint[%d]: expected (%s %s %s), got (%s %s %s)",
				i, e.method, e.path, e.handler, got.Method, got.Path, got.Handler)
		}
		if got.Language != "go" {
			t.Errorf("endpoint[%d]: expected language=go, got %s", i, got.Language)
		}
	}
}

// --- Go consumer extraction ---

func TestExtractGoConsumers(t *testing.T) {
	src := `package main

import "net/http"

func doStuff() {
	resp, _ := http.Get("http://localhost:8080/api/users")
	resp2, _ := http.Post("http://localhost:8080/api/items", "application/json", body)
	req, _ := http.NewRequest("PUT", "http://localhost:8080/api/items/42", body)
	client.Get("http://localhost:8080/api/health")
	client.Delete("http://localhost:8080/api/items/99")
}
`
	dir := t.TempDir()
	fp := filepath.Join(dir, "client.go")
	writeFile(t, fp, src)

	_, consumers := extractGo(fp, "client.go")

	expect := []struct {
		method string
		url    string
	}{
		{"GET", "http://localhost:8080/api/users"},
		{"POST", "http://localhost:8080/api/items"},
		{"PUT", "http://localhost:8080/api/items/42"},
		{"GET", "http://localhost:8080/api/health"},
		{"DELETE", "http://localhost:8080/api/items/99"},
	}

	if len(consumers) != len(expect) {
		t.Fatalf("expected %d consumers, got %d: %+v", len(expect), len(consumers), consumers)
	}
	for i, e := range expect {
		got := consumers[i]
		if got.Method != e.method || got.URL != e.url {
			t.Errorf("consumer[%d]: expected (%s %s), got (%s %s)",
				i, e.method, e.url, got.Method, got.URL)
		}
		if got.Language != "go" {
			t.Errorf("consumer[%d]: expected language=go, got %s", i, got.Language)
		}
	}
}

// --- TypeScript endpoint extraction ---

func TestExtractTSEndpoints(t *testing.T) {
	src := `import express from 'express';
const app = express();
const router = express.Router();

app.get('/api/users', (req, res) => {});
app.post('/api/users', createUser);
router.get('/api/items/:id', getItem);
router.delete('/api/items/:id', deleteItem);
router.put('/api/items/:id', updateItem);
`
	dir := t.TempDir()
	fp := filepath.Join(dir, "app.ts")
	writeFile(t, fp, src)

	endpoints, _ := extractTS(fp, "app.ts")

	expect := []struct {
		method string
		path   string
	}{
		{"GET", "/api/users"},
		{"POST", "/api/users"},
		{"GET", "/api/items/:id"},
		{"DELETE", "/api/items/:id"},
		{"PUT", "/api/items/:id"},
	}

	if len(endpoints) != len(expect) {
		t.Fatalf("expected %d TS endpoints, got %d: %+v", len(expect), len(endpoints), endpoints)
	}
	for i, e := range expect {
		got := endpoints[i]
		if got.Method != e.method || got.Path != e.path {
			t.Errorf("ts endpoint[%d]: expected (%s %s), got (%s %s)",
				i, e.method, e.path, got.Method, got.Path)
		}
		if got.Language != "typescript" {
			t.Errorf("ts endpoint[%d]: expected language=typescript, got %s", i, got.Language)
		}
	}
}

// --- TypeScript consumer extraction ---

func TestExtractTSConsumers(t *testing.T) {
	src := `async function load() {
  const res = await fetch('/api/users');
  const items = await fetch('/api/items', { method: 'POST' });
  const data = await axios.get('/api/health');
  const created = await axios.post('/api/items');
  $.ajax({ url: '/api/legacy' });
}
`
	dir := t.TempDir()
	fp := filepath.Join(dir, "client.tsx")
	writeFile(t, fp, src)

	_, consumers := extractTS(fp, "client.tsx")

	expect := []struct {
		method string
		url    string
	}{
		{"GET", "/api/users"},
		{"POST", "/api/items"},
		{"GET", "/api/health"},
		{"POST", "/api/items"},
		{"", "/api/legacy"},
	}

	if len(consumers) != len(expect) {
		t.Fatalf("expected %d TS consumers, got %d: %+v", len(expect), len(consumers), consumers)
	}
	for i, e := range expect {
		got := consumers[i]
		if got.Method != e.method || got.URL != e.url {
			t.Errorf("ts consumer[%d]: expected (%s %q), got (%s %q)",
				i, e.method, e.url, got.Method, got.URL)
		}
	}
}

// --- Python endpoint extraction ---

func TestExtractPyEndpoints(t *testing.T) {
	src := `from flask import Flask
app = Flask(__name__)

@app.route("/api/users", methods=["GET", "POST"])
def list_users():
    return []

@app.get("/api/users/<id>")
def get_user(id):
    return {}

@app.post("/api/items")
def create_item():
    return {}

# Django
urlpatterns = [
    path("api/health/", health_view),
]
`
	dir := t.TempDir()
	fp := filepath.Join(dir, "views.py")
	writeFile(t, fp, src)

	endpoints, _ := extractPy(fp, "views.py")

	expect := []struct {
		method  string
		path    string
		handler string
	}{
		{"GET", "/api/users", "list_users"},
		{"GET", "/api/users/<id>", "get_user"},
		{"POST", "/api/items", "create_item"},
		{"", "/api/health/", ""},
	}

	if len(endpoints) != len(expect) {
		t.Fatalf("expected %d Python endpoints, got %d: %+v", len(expect), len(endpoints), endpoints)
	}
	for i, e := range expect {
		got := endpoints[i]
		if got.Method != e.method {
			t.Errorf("py endpoint[%d]: expected method=%s, got %s", i, e.method, got.Method)
		}
		if got.Path != e.path {
			t.Errorf("py endpoint[%d]: expected path=%s, got %s", i, e.path, got.Path)
		}
		if e.handler != "" && got.Handler != e.handler {
			t.Errorf("py endpoint[%d]: expected handler=%s, got %s", i, e.handler, got.Handler)
		}
		if got.Language != "python" {
			t.Errorf("py endpoint[%d]: expected language=python, got %s", i, got.Language)
		}
	}
}

// --- Python consumer extraction ---

func TestExtractPyConsumers(t *testing.T) {
	src := `import requests
import httpx

def call_apis():
    r = requests.get("http://localhost:5000/api/users")
    r2 = requests.post("http://localhost:5000/api/items")
    r3 = httpx.get("http://localhost:5000/api/health")
    r4 = requests.delete("http://localhost:5000/api/items/42")
`
	dir := t.TempDir()
	fp := filepath.Join(dir, "client.py")
	writeFile(t, fp, src)

	_, consumers := extractPy(fp, "client.py")

	expect := []struct {
		method string
		url    string
	}{
		{"GET", "http://localhost:5000/api/users"},
		{"POST", "http://localhost:5000/api/items"},
		{"GET", "http://localhost:5000/api/health"},
		{"DELETE", "http://localhost:5000/api/items/42"},
	}

	if len(consumers) != len(expect) {
		t.Fatalf("expected %d Python consumers, got %d: %+v", len(expect), len(consumers), consumers)
	}
	for i, e := range expect {
		got := consumers[i]
		if got.Method != e.method || got.URL != e.url {
			t.Errorf("py consumer[%d]: expected (%s %s), got (%s %s)",
				i, e.method, e.url, got.Method, got.URL)
		}
	}
}

// --- Full Build integration test ---

func TestBuildSurfaceMap(t *testing.T) {
	dir := t.TempDir()

	// Go server defining endpoints.
	goServer := `package main

import "net/http"

func main() {
	http.HandleFunc("/api/users", listUsers)
	r.GET("/api/items", listItems)
	r.POST("/api/items", createItem)
}
`
	writeFile(t, filepath.Join(dir, "server.go"), goServer)

	// TypeScript client consuming endpoints.
	tsClient := `async function load() {
  const users = await fetch('/api/users');
  const items = await axios.get('/api/items');
  const created = await axios.post('/api/items');
}
`
	writeFile(t, filepath.Join(dir, "client.ts"), tsClient)

	sm, err := Build(dir)
	if err != nil {
		t.Fatalf("Build failed: %v", err)
	}

	if len(sm.Endpoints) != 3 {
		t.Errorf("expected 3 endpoints, got %d: %+v", len(sm.Endpoints), sm.Endpoints)
	}
	if len(sm.Consumers) != 3 {
		t.Errorf("expected 3 consumers, got %d: %+v", len(sm.Consumers), sm.Consumers)
	}
	if len(sm.Bindings) == 0 {
		t.Error("expected at least one binding, got 0")
	}
}

// --- Matching logic ---

func TestMatchConsumersToEndpoints(t *testing.T) {
	endpoints := []Endpoint{
		{Method: "GET", Path: "/api/users", File: "server.go", Language: "go"},
		{Method: "POST", Path: "/api/users", File: "server.go", Language: "go"},
		{Method: "GET", Path: "/api/items/:id", File: "server.go", Language: "go"},
	}

	consumers := []Consumer{
		{URL: "http://localhost/api/users", Method: "GET", File: "client.ts", Language: "typescript"},
		{URL: "/api/items/42", Method: "GET", File: "client.ts", Language: "typescript"},
		{URL: "/api/users", Method: "POST", File: "client.ts", Language: "typescript"},
	}

	bindings, _ := matchConsumers(endpoints, consumers)

	if len(bindings) != 3 {
		t.Fatalf("expected 3 bindings, got %d", len(bindings))
	}

	// First binding: GET /api/users
	if bindings[0].Endpoint.Method != "GET" || bindings[0].Endpoint.Path != "/api/users" {
		t.Errorf("binding[0] wrong endpoint: %+v", bindings[0].Endpoint)
	}
	if bindings[0].Confidence != 1.0 {
		t.Errorf("binding[0] confidence: expected 1.0, got %f", bindings[0].Confidence)
	}

	// Second binding: GET /api/items/:id matched via param
	if bindings[1].Endpoint.Path != "/api/items/:id" {
		t.Errorf("binding[1] wrong endpoint path: %s", bindings[1].Endpoint.Path)
	}

	// Third binding: POST /api/users
	if bindings[2].Endpoint.Method != "POST" {
		t.Errorf("binding[2] wrong method: %s", bindings[2].Endpoint.Method)
	}
}

// --- Contract gap detection ---

func TestContractGapDetection(t *testing.T) {
	endpoints := []Endpoint{
		{Method: "GET", Path: "/api/users", File: "server.go", Language: "go"},
		{Method: "DELETE", Path: "/api/admin", File: "server.go", Language: "go"},
	}

	consumers := []Consumer{
		// Matches GET /api/users.
		{URL: "/api/users", Method: "GET", File: "client.ts", Language: "typescript"},
		// No endpoint exists.
		{URL: "/api/unknown", Method: "GET", File: "client.ts", Language: "typescript"},
		// Path matches but method differs.
		{URL: "/api/users", Method: "PUT", File: "client.ts", Language: "typescript"},
	}

	_, gaps := matchConsumers(endpoints, consumers)

	// We expect:
	// 1. "no matching endpoint" for /api/unknown
	// 2. "method mismatch" for PUT /api/users (endpoint is GET)
	// 3. "dead endpoint" for DELETE /api/admin (never consumed)
	if len(gaps) < 3 {
		t.Fatalf("expected at least 3 gaps, got %d: %+v", len(gaps), gaps)
	}

	issueMap := map[string]int{}
	for _, g := range gaps {
		issueMap[g.Issue]++
	}

	if issueMap["no matching endpoint"] < 1 {
		t.Error("expected a 'no matching endpoint' gap")
	}
	if issueMap["method mismatch"] < 1 {
		t.Error("expected a 'method mismatch' gap")
	}
	if issueMap["dead endpoint"] < 1 {
		t.Error("expected a 'dead endpoint' gap")
	}
}

// --- Path matching unit tests ---

func TestPathMatch(t *testing.T) {
	tests := []struct {
		url     string
		pattern string
		want    float64
	}{
		{"/api/users", "/api/users", 1.0},
		{"http://localhost/api/users", "/api/users", 1.0},
		{"/api/items/42", "/api/items/:id", 1.0},
		{"/api/items", "/api/items/:id", 0},    // segment count mismatch
		{"/api/wrong", "/api/users", 0},         // path mismatch
		{"/completely/different", "/api/users", 0},
	}
	for _, tt := range tests {
		got := pathMatch(tt.url, tt.pattern)
		if got != tt.want {
			t.Errorf("pathMatch(%q, %q) = %f, want %f", tt.url, tt.pattern, got, tt.want)
		}
	}
}

func TestExtractPath(t *testing.T) {
	tests := []struct {
		input string
		want  string
	}{
		{"/api/users", "/api/users"},
		{"http://localhost:8080/api/users", "/api/users"},
		{"http://example.com/api/users?page=1", "/api/users"},
		{"/api/users/", "/api/users"},
	}
	for _, tt := range tests {
		got := extractPath(tt.input)
		if got != tt.want {
			t.Errorf("extractPath(%q) = %q, want %q", tt.input, got, tt.want)
		}
	}
}

// --- helpers ---

func writeFile(t *testing.T, path, content string) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}
}
