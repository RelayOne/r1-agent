package surfacemap

import (
	"os"
	"regexp"
	"strings"
)

// TypeScript/JavaScript route-definition patterns.
var tsRoutePatterns = []*regexp.Regexp{
	// app.get("/path", handler) / app.post(...) / router.get(...) — Express
	regexp.MustCompile(`\b(?:app|router)\.(get|post|put|delete|patch|all)\(\s*['"]([^'"]+)['"]\s*,`),
	// Also handle backtick template: app.get(`/path`, handler)
	regexp.MustCompile("\\b(?:app|router)\\.(get|post|put|delete|patch|all)\\(\\s*`([^`]+)`\\s*,"),
}

// TypeScript/JavaScript consumer patterns.
var tsConsumerPatterns = []*regexp.Regexp{
	// fetch("url") or fetch('url')
	regexp.MustCompile(`\bfetch\(\s*['"]([^'"]+)['"]\s*[,)]`),
	// fetch(`url`)
	regexp.MustCompile("\\bfetch\\(\\s*`([^`]+)`\\s*[,)]"),

	// axios.get("url") / axios.post("url") etc.
	regexp.MustCompile(`\baxios\.(get|post|put|delete|patch)\(\s*['"]([^'"]+)['"]\s*[,)]`),
	// axios.get(`url`)
	regexp.MustCompile("\\baxios\\.(get|post|put|delete|patch)\\(\\s*`([^`]+)`\\s*[,)]"),

	// $.ajax({url: "..."})
	regexp.MustCompile(`\$\.ajax\(\s*\{\s*(?:[^}]*\burl\s*:\s*['"]([^'"]+)['"])`),

	// fetch("url", { method: "POST" }) — extract method from options
	regexp.MustCompile(`\bfetch\(\s*['"]([^'"]+)['"].*?method\s*:\s*['"](\w+)['"]`),
	// fetch(`url`, { method: "POST" })
	regexp.MustCompile("\\bfetch\\(\\s*`([^`]+)`.*?method\\s*:\\s*['\"]([^'\"]+)['\"]"),
}

// extractTS extracts endpoints and consumers from TypeScript/JavaScript files.
func extractTS(absPath, relPath string) ([]Endpoint, []Consumer) {
	data, err := os.ReadFile(absPath)
	if err != nil {
		return nil, nil
	}
	content := string(data)
	lines := strings.Split(content, "\n")

	var endpoints []Endpoint
	var consumers []Consumer

	for lineNum, line := range lines {
		ln := lineNum + 1

		// --- Route definitions ---
		for _, re := range tsRoutePatterns {
			if m := re.FindStringSubmatch(line); m != nil {
				method := strings.ToUpper(m[1])
				if method == "ALL" {
					method = ""
				}
				endpoints = append(endpoints, Endpoint{
					Method:   method,
					Path:     m[2],
					File:     relPath,
					Line:     ln,
					Handler:  "", // inline handlers are common in Express
					Language: "typescript",
				})
			}
		}

		// --- Consumers ---

		// fetch with method option (more specific — check first)
		if m := tsConsumerPatterns[5].FindStringSubmatch(line); m != nil {
			consumers = append(consumers, Consumer{
				URL:      m[1],
				Method:   strings.ToUpper(m[2]),
				File:     relPath,
				Line:     ln,
				Language: "typescript",
			})
			continue
		}
		if m := tsConsumerPatterns[6].FindStringSubmatch(line); m != nil {
			consumers = append(consumers, Consumer{
				URL:      m[1],
				Method:   strings.ToUpper(m[2]),
				File:     relPath,
				Line:     ln,
				Language: "typescript",
			})
			continue
		}

		// fetch("url") — default GET
		if m := tsConsumerPatterns[0].FindStringSubmatch(line); m != nil {
			consumers = append(consumers, Consumer{
				URL:      m[1],
				Method:   "GET",
				File:     relPath,
				Line:     ln,
				Language: "typescript",
			})
			continue
		}
		if m := tsConsumerPatterns[1].FindStringSubmatch(line); m != nil {
			consumers = append(consumers, Consumer{
				URL:      m[1],
				Method:   "GET",
				File:     relPath,
				Line:     ln,
				Language: "typescript",
			})
			continue
		}

		// axios.METHOD("url")
		if m := tsConsumerPatterns[2].FindStringSubmatch(line); m != nil {
			consumers = append(consumers, Consumer{
				URL:      m[2],
				Method:   strings.ToUpper(m[1]),
				File:     relPath,
				Line:     ln,
				Language: "typescript",
			})
			continue
		}
		if m := tsConsumerPatterns[3].FindStringSubmatch(line); m != nil {
			consumers = append(consumers, Consumer{
				URL:      m[2],
				Method:   strings.ToUpper(m[1]),
				File:     relPath,
				Line:     ln,
				Language: "typescript",
			})
			continue
		}

		// $.ajax
		if m := tsConsumerPatterns[4].FindStringSubmatch(line); m != nil {
			consumers = append(consumers, Consumer{
				URL:      m[1],
				Method:   "",
				File:     relPath,
				Line:     ln,
				Language: "typescript",
			})
			continue
		}
	}

	return endpoints, consumers
}
