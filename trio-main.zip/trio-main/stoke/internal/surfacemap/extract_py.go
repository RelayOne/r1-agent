package surfacemap

import (
	"os"
	"regexp"
	"strings"
)

// Python route-definition patterns.
var pyRoutePatterns = []*regexp.Regexp{
	// @app.route("/path") or @app.route("/path", methods=["GET", "POST"])
	regexp.MustCompile(`@\w+\.route\(\s*['"]([^'"]+)['"]`),

	// @app.get("/path") / @app.post("/path") — Flask/FastAPI
	regexp.MustCompile(`@\w+\.(get|post|put|delete|patch)\(\s*['"]([^'"]+)['"]`),

	// path("pattern", view) — Django
	regexp.MustCompile(`\bpath\(\s*['"]([^'"]+)['"]`),
}

// pyRouteMethods extracts methods from a @app.route(..., methods=[...]) decorator.
var pyRouteMethodsRe = regexp.MustCompile(`methods\s*=\s*\[([^\]]+)\]`)

// Python consumer patterns.
var pyConsumerPatterns = []*regexp.Regexp{
	// requests.get("url") / requests.post("url") etc.
	regexp.MustCompile(`\brequests\.(get|post|put|delete|patch|head|options)\(\s*['"]([^'"]+)['"]`),

	// httpx.get("url") / httpx.post("url") etc.
	regexp.MustCompile(`\bhttpx\.(get|post|put|delete|patch|head|options)\(\s*['"]([^'"]+)['"]`),

	// requests.get(f"url") — f-string
	regexp.MustCompile(`\brequests\.(get|post|put|delete|patch|head|options)\(\s*f['"]([^'"]+)['"]`),

	// httpx.get(f"url") — f-string
	regexp.MustCompile(`\bhttpx\.(get|post|put|delete|patch|head|options)\(\s*f['"]([^'"]+)['"]`),
}

// extractPy extracts endpoints and consumers from Python files.
func extractPy(absPath, relPath string) ([]Endpoint, []Consumer) {
	data, err := os.ReadFile(absPath)
	if err != nil {
		return nil, nil
	}
	content := string(data)
	lines := strings.Split(content, "\n")

	var endpoints []Endpoint
	var consumers []Consumer

	// Track decorator state for function name extraction.
	pendingDecorator := false
	var pendingEndpoint Endpoint

	for lineNum, line := range lines {
		ln := lineNum + 1
		trimmed := strings.TrimSpace(line)

		// If we had a decorator on previous line(s), the next def is the handler.
		if pendingDecorator {
			if strings.HasPrefix(trimmed, "def ") {
				// Extract function name.
				parts := strings.SplitN(trimmed[4:], "(", 2)
				if len(parts) > 0 {
					pendingEndpoint.Handler = strings.TrimSpace(parts[0])
				}
				// Line stays at the decorator position (already set).
				endpoints = append(endpoints, pendingEndpoint)
				pendingDecorator = false
				continue
			} else if strings.HasPrefix(trimmed, "@") {
				// Stacked decorators — keep waiting.
				continue
			} else if trimmed == "" {
				// blank line between decorator and def — keep waiting.
				continue
			} else {
				// Non-def line after decorator — emit what we have.
				endpoints = append(endpoints, pendingEndpoint)
				pendingDecorator = false
			}
		}

		// --- Route definitions ---

		// @app.get("/path") / @app.post("/path") — method-specific decorators
		if m := pyRoutePatterns[1].FindStringSubmatch(line); m != nil {
			pendingDecorator = true
			pendingEndpoint = Endpoint{
				Method:   strings.ToUpper(m[1]),
				Path:     m[2],
				File:     relPath,
				Line:     ln,
				Language: "python",
			}
			continue
		}

		// @app.route("/path") — general route decorator
		if m := pyRoutePatterns[0].FindStringSubmatch(line); m != nil {
			method := ""
			if mm := pyRouteMethodsRe.FindStringSubmatch(line); mm != nil {
				// Parse methods=["GET", "POST"] — take first.
				methodStr := strings.ReplaceAll(mm[1], "'", "")
				methodStr = strings.ReplaceAll(methodStr, "\"", "")
				methodStr = strings.TrimSpace(methodStr)
				parts := strings.Split(methodStr, ",")
				if len(parts) > 0 {
					method = strings.TrimSpace(parts[0])
				}
			}
			pendingDecorator = true
			pendingEndpoint = Endpoint{
				Method:   strings.ToUpper(method),
				Path:     m[1],
				File:     relPath,
				Line:     ln,
				Language: "python",
			}
			continue
		}

		// path("pattern", view) — Django
		if m := pyRoutePatterns[2].FindStringSubmatch(line); m != nil {
			endpoints = append(endpoints, Endpoint{
				Method:   "",
				Path:     "/" + strings.TrimLeft(m[1], "/"),
				File:     relPath,
				Line:     ln,
				Handler:  "",
				Language: "python",
			})
			continue
		}

		// --- Consumers ---
		matched := false
		for _, re := range pyConsumerPatterns {
			if m := re.FindStringSubmatch(line); m != nil {
				consumers = append(consumers, Consumer{
					URL:      m[2],
					Method:   strings.ToUpper(m[1]),
					File:     relPath,
					Line:     ln,
					Language: "python",
				})
				matched = true
				break
			}
		}
		if matched {
			continue
		}
	}

	// Flush pending decorator at EOF.
	if pendingDecorator {
		endpoints = append(endpoints, pendingEndpoint)
	}

	return endpoints, consumers
}
