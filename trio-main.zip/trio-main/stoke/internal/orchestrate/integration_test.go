package orchestrate

import (
	"strings"
	"testing"

	"github.com/ericmacdougall/stoke/internal/convergence"
	"github.com/ericmacdougall/stoke/internal/handoff"
	"github.com/ericmacdougall/stoke/internal/mission"
	"github.com/ericmacdougall/stoke/internal/research"
)

// TestMissionLifecycleIntegration exercises the full mission lifecycle through
// the orchestrator with real SQLite stores, real phase transitions, real
// convergence checks, consensus recording, handoffs, and completion.
func TestMissionLifecycleIntegration(t *testing.T) {
	// 1. Create orchestrator with real SQLite stores in a temp directory.
	orch, err := New(Config{
		StoreDir:          t.TempDir(),
		RequiredConsensus: 2,
	})
	if err != nil {
		t.Fatalf("New orchestrator: %v", err)
	}
	t.Cleanup(func() { orch.Close() })

	// 2. Create a mission with title, intent, and acceptance criteria.
	criteria := []string{
		"Users can authenticate with JWT tokens",
		"Invalid tokens return HTTP 401",
		"Tokens expire after configured TTL",
	}
	m, err := orch.CreateMission("JWT Authentication", "Implement JWT-based auth for the REST API", criteria)
	if err != nil {
		t.Fatalf("CreateMission: %v", err)
	}
	if m.ID == "" {
		t.Fatal("mission should have a generated ID")
	}
	if m.Phase != mission.PhaseCreated {
		t.Fatalf("initial phase = %s, want created", m.Phase)
	}
	if len(m.Criteria) != 3 {
		t.Fatalf("criteria count = %d, want 3", len(m.Criteria))
	}
	t.Logf("created mission %s", m.ID)

	// Verify mission is retrievable from the store.
	got, err := orch.GetMission(m.ID)
	if err != nil {
		t.Fatalf("GetMission: %v", err)
	}
	if got.Title != "JWT Authentication" {
		t.Fatalf("retrieved title = %q", got.Title)
	}

	// Verify mission appears in list.
	all, err := orch.ListMissions("")
	if err != nil {
		t.Fatalf("ListMissions: %v", err)
	}
	if len(all) != 1 {
		t.Fatalf("list count = %d, want 1", len(all))
	}

	// 3. Advance through phases: created -> researching -> planning -> executing -> validating.
	phases := []struct {
		to     mission.Phase
		reason string
	}{
		{mission.PhaseResearching, "starting research on JWT libraries"},
		{mission.PhasePlanning, "research complete, generating task plan"},
		{mission.PhaseExecuting, "plan approved, beginning implementation"},
		{mission.PhaseValidating, "implementation complete, running validation"},
	}
	for _, p := range phases {
		if err := orch.AdvanceMission(m.ID, p.to, p.reason, "test-agent"); err != nil {
			t.Fatalf("advance to %s: %v", p.to, err)
		}
		got, err := orch.GetMission(m.ID)
		if err != nil {
			t.Fatalf("GetMission after advance: %v", err)
		}
		if got.Phase != p.to {
			t.Fatalf("phase after advance = %s, want %s", got.Phase, p.to)
		}
		t.Logf("advanced to %s", p.to)
	}

	// Verify invalid transition is rejected (validating -> completed is not allowed).
	if err := orch.AdvanceMission(m.ID, mission.PhaseCompleted, "skip", "test"); err == nil {
		t.Fatal("should reject direct transition from validating to completed")
	}

	// 4. Add research linked to the mission.
	err = orch.AddResearch(m.ID, &research.Entry{
		ID:      "r-jwt-1",
		Topic:   "JWT",
		Query:   "Go JWT library comparison",
		Content: "golang-jwt/jwt is the maintained fork of dgrijalva/jwt-go with HMAC and RSA support",
		Source:  "https://github.com/golang-jwt/jwt",
		Tags:    []string{"jwt", "auth", "golang"},
	})
	if err != nil {
		t.Fatalf("AddResearch: %v", err)
	}

	// Verify research is searchable.
	results, err := orch.SearchResearch("JWT", 10)
	if err != nil {
		t.Fatalf("SearchResearch: %v", err)
	}
	if len(results) == 0 {
		t.Fatal("should find JWT research entry")
	}
	if results[0].Entry.Topic != "JWT" {
		t.Fatalf("research topic = %q", results[0].Entry.Topic)
	}

	// 5. Run convergence validation against test files.
	// Provide clean files that address the criteria keywords so the criteria check passes.
	files := []convergence.FileInput{
		{
			Path: "auth/jwt.go",
			Content: []byte(
				"package auth\n\n" +
					"// Authenticate validates JWT tokens for users.\n" +
					"// Invalid tokens cause the handler to return HTTP 401.\n" +
					"// Tokens have a configurable TTL that controls expiration.\n" +
					"func Authenticate(token string) error {\n" +
					"\tif err := validateSignature(token); err != nil {\n" +
					"\t\treturn err\n" +
					"\t}\n" +
					"\treturn nil\n" +
					"}\n\n" +
					"func validateSignature(token string) error { return nil }\n",
			),
		},
		{
			Path: "auth/jwt_test.go",
			Content: []byte(
				"package auth\n\n" +
					"import \"testing\"\n\n" +
					"func TestAuthenticate(t *testing.T) {\n" +
					"\tif err := Authenticate(\"valid-token\"); err != nil {\n" +
					"\t\tt.Fatalf(\"unexpected error: %v\", err)\n" +
					"\t}\n" +
					"}\n",
			),
		},
	}

	report, err := orch.RunConvergence(m.ID, files)
	if err != nil {
		t.Fatalf("RunConvergence: %v", err)
	}
	t.Logf("convergence: score=%.2f converged=%v findings=%d", report.Score, report.IsConverged, len(report.Findings))

	// The report should have run rules against the files.
	if report.RulesApplied == 0 {
		t.Fatal("should have applied convergence rules")
	}
	if report.MissionID != m.ID {
		t.Fatalf("report mission ID = %q, want %q", report.MissionID, m.ID)
	}

	// 6. Satisfy all criteria so convergence can pass.
	for i, c := range m.Criteria {
		evidence := "verified by integration test"
		if err := orch.Store().SetCriteriaSatisfied(m.ID, c.ID, evidence, "test-agent"); err != nil {
			t.Fatalf("SetCriteriaSatisfied criterion %d: %v", i, err)
		}
	}

	// Check convergence status with all criteria satisfied.
	status, err := orch.CheckConvergence(m.ID)
	if err != nil {
		t.Fatalf("CheckConvergence: %v", err)
	}
	if status.TotalCriteria != 3 {
		t.Fatalf("total criteria = %d, want 3", status.TotalCriteria)
	}
	if status.SatisfiedCriteria != 3 {
		t.Fatalf("satisfied criteria = %d, want 3", status.SatisfiedCriteria)
	}
	t.Logf("convergence status: converged=%v consensus=%v", status.IsConverged, status.HasConsensus)

	// 7. Record consensus from two models.
	// First model: claude.
	err = orch.RecordConsensus(m.ID, "claude", "complete", "All criteria verified with tests and clean code", nil)
	if err != nil {
		t.Fatalf("RecordConsensus claude: %v", err)
	}

	has, err := orch.HasConsensus(m.ID)
	if err != nil {
		t.Fatalf("HasConsensus after 1 vote: %v", err)
	}
	if has {
		t.Fatal("should not have consensus with only 1 vote (need 2)")
	}

	// Second model: codex.
	err = orch.RecordConsensus(m.ID, "codex", "complete", "Confirmed: JWT auth implemented with proper error handling", nil)
	if err != nil {
		t.Fatalf("RecordConsensus codex: %v", err)
	}

	// 8. Check consensus status - should now have consensus.
	has, err = orch.HasConsensus(m.ID)
	if err != nil {
		t.Fatalf("HasConsensus after 2 votes: %v", err)
	}
	if !has {
		t.Fatal("should have consensus with 2 complete votes")
	}

	// Verify convergence status reflects consensus.
	status, err = orch.CheckConvergence(m.ID)
	if err != nil {
		t.Fatalf("CheckConvergence after consensus: %v", err)
	}
	if status.CompleteVotes != 2 {
		t.Fatalf("complete votes = %d, want 2", status.CompleteVotes)
	}
	if !status.HasConsensus {
		t.Fatal("convergence status should report consensus")
	}

	// 9. Record a handoff between agents.
	err = orch.RecordHandoff(handoff.Record{
		MissionID:    m.ID,
		FromAgent:    "claude-impl",
		ToAgent:      "codex-review",
		Summary:      "JWT authentication fully implemented with token validation and expiry",
		PendingWork:  []string{"Final review pass", "Update API docs"},
		KeyDecisions: []string{"Used golang-jwt for token signing", "HMAC-SHA256 for signature algorithm"},
		FilesChanged: []string{"auth/jwt.go", "auth/jwt_test.go"},
		TestStatus:   "passing",
		Phase:        string(mission.PhaseValidating),
	})
	if err != nil {
		t.Fatalf("RecordHandoff: %v", err)
	}

	// Verify handoff context is retrievable and contains key information.
	ctx, err := orch.GetHandoffContext(m.ID, 4000)
	if err != nil {
		t.Fatalf("GetHandoffContext: %v", err)
	}
	if !strings.Contains(ctx, "JWT") {
		t.Fatal("handoff context should mention JWT")
	}
	if !strings.Contains(ctx, "claude-impl") {
		t.Fatal("handoff context should mention the handing-off agent")
	}

	// Verify handoff count in convergence status.
	status, err = orch.CheckConvergence(m.ID)
	if err != nil {
		t.Fatalf("CheckConvergence after handoff: %v", err)
	}
	if status.HandoffCount < 1 {
		t.Fatalf("handoff count = %d, want >= 1", status.HandoffCount)
	}

	// 10. Build full agent context (combines mission, criteria, gaps, research, handoffs).
	agentCtx, err := orch.BuildAgentContext(m.ID, mission.DefaultContextConfig())
	if err != nil {
		t.Fatalf("BuildAgentContext: %v", err)
	}
	// Agent context should contain mission info, criteria, and handoff references.
	for _, needle := range []string{"JWT Authentication", "3/3", "[x]"} {
		if !strings.Contains(agentCtx, needle) {
			t.Errorf("agent context missing %q", needle)
		}
	}

	// 11. Advance to converged, then complete.
	// Move from validating -> converged.
	err = orch.AdvanceMission(m.ID, mission.PhaseConverged, "all gaps closed, consensus reached", "test-agent")
	if err != nil {
		t.Fatalf("advance to converged: %v", err)
	}

	// Move from converged -> completed.
	err = orch.AdvanceMission(m.ID, mission.PhaseCompleted, "mission complete with full consensus", "test-agent")
	if err != nil {
		t.Fatalf("advance to completed: %v", err)
	}

	// Verify final state.
	final, err := orch.GetMission(m.ID)
	if err != nil {
		t.Fatalf("GetMission final: %v", err)
	}
	if final.Phase != mission.PhaseCompleted {
		t.Fatalf("final phase = %s, want completed", final.Phase)
	}

	// Verify completed mission appears in filtered list.
	completed, err := orch.ListMissions(mission.PhaseCompleted)
	if err != nil {
		t.Fatalf("ListMissions completed: %v", err)
	}
	if len(completed) != 1 {
		t.Fatalf("completed missions = %d, want 1", len(completed))
	}
	if completed[0].ID != m.ID {
		t.Fatalf("completed mission ID = %q, want %q", completed[0].ID, m.ID)
	}

	t.Logf("mission %s completed successfully through full lifecycle", m.ID)
}
