// Package consensus implements a multi-model adversarial consensus engine.
//
// It dispatches mission completion verification to N models in parallel,
// each analyzing independently whether a mission is truly complete.
// Consensus requires a minimum number of models to agree "complete."
//
// This is distinct from convergence (which detects code quality issues).
// The consensus engine verifies MISSION COMPLETION by having independent
// models act as skeptical reviewers.
package consensus

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"github.com/ericmacdougall/stoke/internal/apiclient"
)

// Engine orchestrates multi-model adversarial consensus.
// It dispatches to N models in parallel, each analyzing independently
// whether a mission is truly complete. Consensus requires a minimum
// number of models to agree "complete."
type Engine struct {
	models   []ModelConfig
	required int           // how many must agree "complete"
	timeout  time.Duration // per-model timeout
}

// Config for the consensus engine.
type Config struct {
	Models   []ModelConfig
	Required int           // minimum votes for "complete" (default: 2)
	Timeout  time.Duration // per-model timeout (default: 3 min)
}

// ModelConfig configures a single consensus voter.
type ModelConfig struct {
	Name     string             // human label: "claude", "gpt", "gemini"
	Provider apiclient.Provider // API provider
	APIKey   string
	BaseURL  string
	Model    string // specific model ID
}

// Vote is a single model's verdict.
type Vote struct {
	Model      string        `json:"model"`
	Verdict    string        `json:"verdict"`    // "complete" or "incomplete"
	Confidence float64       `json:"confidence"`  // 0.0 to 1.0
	Reasoning  string        `json:"reasoning"`
	GapsFound  []string      `json:"gaps_found"`
	Duration   time.Duration `json:"duration"`
	Error      string        `json:"error,omitempty"`
}

// Result is the consensus outcome.
type Result struct {
	Votes     []Vote `json:"votes"`
	Consensus bool   `json:"consensus"` // true if enough models voted "complete"
	Summary   string `json:"summary"`
}

// New creates a consensus engine with the given configuration.
// Defaults: required=2, timeout=3min.
func New(cfg Config) *Engine {
	required := cfg.Required
	if required <= 0 {
		required = 2
	}
	timeout := cfg.Timeout
	if timeout <= 0 {
		timeout = 3 * time.Minute
	}
	return &Engine{
		models:   cfg.Models,
		required: required,
		timeout:  timeout,
	}
}

// Run dispatches all configured models concurrently to verify mission completion.
// Each model independently evaluates the mission intent, criteria, validation report,
// and file contents. Returns the collected votes and whether consensus was reached.
func (e *Engine) Run(ctx context.Context, missionIntent string, criteria []string, validationReport string, fileContents map[string]string) (*Result, error) {
	if len(e.models) == 0 {
		return nil, fmt.Errorf("consensus: no models configured")
	}

	userPrompt := buildUserPrompt(missionIntent, criteria, validationReport, fileContents)

	votes := make([]Vote, len(e.models))
	var wg sync.WaitGroup

	for i, mc := range e.models {
		wg.Add(1)
		go func(idx int, model ModelConfig) {
			defer wg.Done()

			modelCtx, cancel := context.WithTimeout(ctx, e.timeout)
			defer cancel()

			start := time.Now()
			vote := e.queryModel(modelCtx, model, userPrompt)
			vote.Model = model.Name
			vote.Duration = time.Since(start)

			votes[idx] = vote
		}(i, mc)
	}

	wg.Wait()

	// Count "complete" verdicts from successful votes
	completeCount := 0
	var summaryParts []string
	for _, v := range votes {
		if v.Error != "" {
			summaryParts = append(summaryParts, fmt.Sprintf("%s: error (%s)", v.Model, v.Error))
			continue
		}
		if v.Verdict == "complete" {
			completeCount++
		}
		summaryParts = append(summaryParts, fmt.Sprintf("%s: %s (%.0f%%)", v.Model, v.Verdict, v.Confidence*100))
	}

	consensus := completeCount >= e.required

	return &Result{
		Votes:     votes,
		Consensus: consensus,
		Summary:   fmt.Sprintf("consensus=%v (%d/%d complete): %s", consensus, completeCount, e.required, strings.Join(summaryParts, ", ")),
	}, nil
}

// queryModel calls a single model and parses its vote.
func (e *Engine) queryModel(ctx context.Context, mc ModelConfig, userPrompt string) Vote {
	client := apiclient.NewClient(apiclient.Config{
		Provider:  mc.Provider,
		APIKey:    mc.APIKey,
		BaseURL:   mc.BaseURL,
		Model:     mc.Model,
		MaxTokens: 4096,
		Timeout:   e.timeout,
	})

	resp, err := client.Complete(ctx, apiclient.Request{
		System: systemPrompt,
		Messages: []apiclient.Message{
			{Role: "user", Content: userPrompt},
		},
	})
	if err != nil {
		log.Printf("[consensus] model %s error: %v", mc.Name, err)
		return Vote{Error: err.Error()}
	}

	vote, err := parseVote(resp.Content)
	if err != nil {
		log.Printf("[consensus] model %s parse error: %v (raw: %s)", mc.Name, err, resp.Content)
		return Vote{
			Error: fmt.Sprintf("parse error: %v", err),
		}
	}

	return vote
}

// parseVote extracts a Vote from a model's JSON response.
// It handles responses that may have surrounding text or markdown code fences.
func parseVote(raw string) (Vote, error) {
	// Strip markdown code fences if present
	cleaned := raw
	cleaned = strings.TrimSpace(cleaned)
	if strings.HasPrefix(cleaned, "```json") {
		cleaned = strings.TrimPrefix(cleaned, "```json")
		if idx := strings.LastIndex(cleaned, "```"); idx >= 0 {
			cleaned = cleaned[:idx]
		}
	} else if strings.HasPrefix(cleaned, "```") {
		cleaned = strings.TrimPrefix(cleaned, "```")
		if idx := strings.LastIndex(cleaned, "```"); idx >= 0 {
			cleaned = cleaned[:idx]
		}
	}
	cleaned = strings.TrimSpace(cleaned)

	// Try to find JSON object boundaries if there's surrounding text
	if !strings.HasPrefix(cleaned, "{") {
		start := strings.Index(cleaned, "{")
		if start < 0 {
			return Vote{}, fmt.Errorf("no JSON object found in response")
		}
		cleaned = cleaned[start:]
	}
	if end := strings.LastIndex(cleaned, "}"); end >= 0 {
		cleaned = cleaned[:end+1]
	}

	var vote Vote
	if err := json.Unmarshal([]byte(cleaned), &vote); err != nil {
		return Vote{}, fmt.Errorf("invalid JSON: %w", err)
	}

	// Validate verdict
	if vote.Verdict != "complete" && vote.Verdict != "incomplete" {
		return Vote{}, fmt.Errorf("invalid verdict %q: must be 'complete' or 'incomplete'", vote.Verdict)
	}

	// Clamp confidence to [0, 1]
	if vote.Confidence < 0 {
		vote.Confidence = 0
	}
	if vote.Confidence > 1 {
		vote.Confidence = 1
	}

	// Ensure gaps_found is not nil
	if vote.GapsFound == nil {
		vote.GapsFound = []string{}
	}

	return vote, nil
}
