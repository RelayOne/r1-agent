package consensus

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/ericmacdougall/stoke/internal/apiclient"
)

// anthropicResponse builds a canned Anthropic API response with the given text content.
func anthropicResponse(content string) map[string]any {
	return map[string]any{
		"content": []map[string]any{
			{"type": "text", "text": content},
		},
		"stop_reason": "end_turn",
		"model":       "claude-sonnet-4-20250514",
		"usage": map[string]any{
			"input_tokens":  500,
			"output_tokens": 100,
		},
	}
}

// voteJSON builds a valid vote JSON string.
func voteJSON(verdict string, confidence float64, reasoning string, gaps []string) string {
	v := map[string]any{
		"verdict":    verdict,
		"confidence": confidence,
		"reasoning":  reasoning,
		"gaps_found": gaps,
	}
	b, _ := json.Marshal(v)
	return string(b)
}

func TestNewDefaults(t *testing.T) {
	e := New(Config{
		Models: []ModelConfig{
			{Name: "m1"},
			{Name: "m2"},
		},
	})

	if e.required != 2 {
		t.Errorf("default required = %d, want 2", e.required)
	}
	if e.timeout != 3*time.Minute {
		t.Errorf("default timeout = %v, want 3m", e.timeout)
	}
	if len(e.models) != 2 {
		t.Errorf("models = %d, want 2", len(e.models))
	}
}

func TestNewCustomConfig(t *testing.T) {
	e := New(Config{
		Models:   []ModelConfig{{Name: "m1"}},
		Required: 1,
		Timeout:  5 * time.Minute,
	})

	if e.required != 1 {
		t.Errorf("required = %d, want 1", e.required)
	}
	if e.timeout != 5*time.Minute {
		t.Errorf("timeout = %v, want 5m", e.timeout)
	}
}

func TestRunAllComplete(t *testing.T) {
	completeVote := voteJSON("complete", 0.95, "All criteria satisfied", []string{})

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(anthropicResponse(completeVote))
	}))
	defer server.Close()

	e := New(Config{
		Models: []ModelConfig{
			{Name: "model-a", Provider: apiclient.ProviderAnthropic, APIKey: "test-key", BaseURL: server.URL, Model: "claude-test"},
			{Name: "model-b", Provider: apiclient.ProviderAnthropic, APIKey: "test-key", BaseURL: server.URL, Model: "claude-test"},
		},
		Required: 2,
	})

	result, err := e.Run(context.Background(), "Build auth system", []string{"Login works"}, "All tests pass", nil)
	if err != nil {
		t.Fatalf("Run: %v", err)
	}

	if !result.Consensus {
		t.Error("expected consensus=true when all models vote complete")
	}
	if len(result.Votes) != 2 {
		t.Errorf("votes = %d, want 2", len(result.Votes))
	}
	for _, v := range result.Votes {
		if v.Verdict != "complete" {
			t.Errorf("model %s verdict = %q, want complete", v.Model, v.Verdict)
		}
		if v.Confidence != 0.95 {
			t.Errorf("model %s confidence = %f, want 0.95", v.Model, v.Confidence)
		}
		if v.Error != "" {
			t.Errorf("model %s unexpected error: %s", v.Model, v.Error)
		}
		if v.Duration == 0 {
			t.Errorf("model %s duration should be >0", v.Model)
		}
	}
}

func TestRunOneIncomplete(t *testing.T) {
	completeVote := voteJSON("complete", 0.9, "Looks good", []string{})
	incompleteVote := voteJSON("incomplete", 0.8, "Missing edge case", []string{"no error handling for nil input"})

	// Use separate servers so routing is deterministic regardless of goroutine scheduling
	completeServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(anthropicResponse(completeVote))
	}))
	defer completeServer.Close()

	incompleteServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(anthropicResponse(incompleteVote))
	}))
	defer incompleteServer.Close()

	e := New(Config{
		Models: []ModelConfig{
			{Name: "model-a", Provider: apiclient.ProviderAnthropic, APIKey: "key", BaseURL: completeServer.URL, Model: "test"},
			{Name: "model-b", Provider: apiclient.ProviderAnthropic, APIKey: "key", BaseURL: incompleteServer.URL, Model: "test"},
		},
		Required: 2,
	})

	result, err := e.Run(context.Background(), "Build auth", []string{"Login works"}, "", nil)
	if err != nil {
		t.Fatalf("Run: %v", err)
	}

	if result.Consensus {
		t.Error("expected consensus=false when only 1 of 2 required models vote complete")
	}

	// Verify we got both votes
	completeCount := 0
	incompleteCount := 0
	for _, v := range result.Votes {
		switch v.Verdict {
		case "complete":
			completeCount++
		case "incomplete":
			incompleteCount++
			if len(v.GapsFound) == 0 {
				t.Error("incomplete vote should have gaps")
			}
		}
	}
	if completeCount != 1 || incompleteCount != 1 {
		t.Errorf("expected 1 complete + 1 incomplete, got %d complete + %d incomplete", completeCount, incompleteCount)
	}
}

func TestRunModelError(t *testing.T) {
	completeVote := voteJSON("complete", 0.9, "All good", []string{})

	// Use separate servers so routing is deterministic regardless of goroutine scheduling
	okServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(anthropicResponse(completeVote))
	}))
	defer okServer.Close()

	errServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(`{"error": {"message": "internal server error"}}`))
	}))
	defer errServer.Close()

	e := New(Config{
		Models: []ModelConfig{
			{Name: "model-ok", Provider: apiclient.ProviderAnthropic, APIKey: "key", BaseURL: okServer.URL, Model: "test"},
			{Name: "model-err", Provider: apiclient.ProviderAnthropic, APIKey: "key", BaseURL: errServer.URL, Model: "test"},
		},
		Required: 2,
	})

	result, err := e.Run(context.Background(), "Build auth", nil, "", nil)
	if err != nil {
		t.Fatalf("Run should not return error for individual model failures: %v", err)
	}

	if result.Consensus {
		t.Error("expected consensus=false when one model errors (only 1 complete, need 2)")
	}

	// Check that the error model has an error recorded
	errorFound := false
	for _, v := range result.Votes {
		if v.Model == "model-err" {
			if v.Error == "" {
				t.Error("model-err should have an error")
			}
			errorFound = true
		}
		if v.Model == "model-ok" {
			if v.Verdict != "complete" {
				t.Errorf("model-ok should be complete, got %q", v.Verdict)
			}
		}
	}
	if !errorFound {
		t.Error("should have a vote for model-err")
	}
}

func TestRunParallel(t *testing.T) {
	// Each model sleeps 100ms. If run sequentially, total >= 300ms.
	// If parallel, total should be ~100ms (with some overhead).
	completeVote := voteJSON("complete", 0.9, "ok", []string{})

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(100 * time.Millisecond)
		json.NewEncoder(w).Encode(anthropicResponse(completeVote))
	}))
	defer server.Close()

	e := New(Config{
		Models: []ModelConfig{
			{Name: "m1", Provider: apiclient.ProviderAnthropic, APIKey: "key", BaseURL: server.URL, Model: "test"},
			{Name: "m2", Provider: apiclient.ProviderAnthropic, APIKey: "key", BaseURL: server.URL, Model: "test"},
			{Name: "m3", Provider: apiclient.ProviderAnthropic, APIKey: "key", BaseURL: server.URL, Model: "test"},
		},
		Required: 2,
	})

	start := time.Now()
	result, err := e.Run(context.Background(), "Build auth", nil, "", nil)
	elapsed := time.Since(start)

	if err != nil {
		t.Fatalf("Run: %v", err)
	}
	if !result.Consensus {
		t.Error("expected consensus=true")
	}

	// If parallel, should take ~100ms. If sequential, ~300ms.
	// Use 250ms as threshold to confirm parallelism.
	if elapsed > 250*time.Millisecond {
		t.Errorf("models should run in parallel: took %v (expected <250ms)", elapsed)
	}
}

func TestParseVoteValid(t *testing.T) {
	tests := []struct {
		name    string
		input   string
		verdict string
		conf    float64
		gaps    int
	}{
		{
			name:    "clean JSON",
			input:   `{"verdict":"complete","confidence":0.95,"reasoning":"all good","gaps_found":[]}`,
			verdict: "complete",
			conf:    0.95,
			gaps:    0,
		},
		{
			name:    "incomplete with gaps",
			input:   `{"verdict":"incomplete","confidence":0.6,"reasoning":"missing auth","gaps_found":["no JWT","no rate limit"]}`,
			verdict: "incomplete",
			conf:    0.6,
			gaps:    2,
		},
		{
			name:    "with markdown fences",
			input:   "```json\n{\"verdict\":\"complete\",\"confidence\":0.9,\"reasoning\":\"ok\",\"gaps_found\":[]}\n```",
			verdict: "complete",
			conf:    0.9,
			gaps:    0,
		},
		{
			name:    "with surrounding text",
			input:   "Here is my analysis:\n{\"verdict\":\"complete\",\"confidence\":0.85,\"reasoning\":\"verified\",\"gaps_found\":[]}\nEnd.",
			verdict: "complete",
			conf:    0.85,
			gaps:    0,
		},
		{
			name:    "confidence clamped to 1",
			input:   `{"verdict":"complete","confidence":1.5,"reasoning":"ok","gaps_found":[]}`,
			verdict: "complete",
			conf:    1.0,
			gaps:    0,
		},
		{
			name:    "null gaps_found becomes empty",
			input:   `{"verdict":"complete","confidence":0.9,"reasoning":"ok","gaps_found":null}`,
			verdict: "complete",
			conf:    0.9,
			gaps:    0,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			v, err := parseVote(tt.input)
			if err != nil {
				t.Fatalf("parseVote: %v", err)
			}
			if v.Verdict != tt.verdict {
				t.Errorf("verdict = %q, want %q", v.Verdict, tt.verdict)
			}
			if v.Confidence != tt.conf {
				t.Errorf("confidence = %f, want %f", v.Confidence, tt.conf)
			}
			if len(v.GapsFound) != tt.gaps {
				t.Errorf("gaps = %d, want %d", len(v.GapsFound), tt.gaps)
			}
		})
	}
}

func TestParseVoteInvalid(t *testing.T) {
	tests := []struct {
		name  string
		input string
	}{
		{"empty string", ""},
		{"no JSON", "This is just plain text with no JSON"},
		{"invalid JSON", "{verdict: complete}"},
		{"bad verdict", `{"verdict":"maybe","confidence":0.5,"reasoning":"unsure","gaps_found":[]}`},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := parseVote(tt.input)
			if err == nil {
				t.Error("expected parseVote to return error")
			}
		})
	}
}

func TestRunNoModels(t *testing.T) {
	e := New(Config{
		Models: []ModelConfig{},
	})

	_, err := e.Run(context.Background(), "Build auth", nil, "", nil)
	if err == nil {
		t.Error("expected error when no models configured")
	}
}

func TestRunWithFileContents(t *testing.T) {
	// Verify file contents are passed through in the prompt
	var receivedBody []byte
	completeVote := voteJSON("complete", 0.9, "code looks good", []string{})

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Capture the request body for inspection
		buf := make([]byte, 1024*64)
		n, _ := r.Body.Read(buf)
		receivedBody = buf[:n]
		json.NewEncoder(w).Encode(anthropicResponse(completeVote))
	}))
	defer server.Close()

	e := New(Config{
		Models: []ModelConfig{
			{Name: "reviewer", Provider: apiclient.ProviderAnthropic, APIKey: "key", BaseURL: server.URL, Model: "test"},
		},
		Required: 1,
	})

	files := map[string]string{
		"auth.go": "package auth\n\nfunc Login() string { return \"token\" }",
	}

	result, err := e.Run(context.Background(), "Add JWT auth", []string{"Login returns token"}, "All tests pass", files)
	if err != nil {
		t.Fatalf("Run: %v", err)
	}

	if !result.Consensus {
		t.Error("expected consensus=true with required=1 and 1 complete vote")
	}

	// Verify the request included file contents
	if len(receivedBody) == 0 {
		t.Fatal("should have captured request body")
	}
	bodyStr := string(receivedBody)
	if !contains(bodyStr, "auth.go") {
		t.Error("request should contain file path")
	}
}

// contains checks if s contains substr (helper to avoid importing strings in test).
func contains(s, substr string) bool {
	return len(s) >= len(substr) && searchString(s, substr)
}

func searchString(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}
