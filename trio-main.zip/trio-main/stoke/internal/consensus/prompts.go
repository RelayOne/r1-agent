package consensus

import (
	"fmt"
	"strings"
)

// systemPrompt is the adversarial verifier system prompt.
// This is distinct from convergence (which finds code issues) — this verifies MISSION COMPLETION.
const systemPrompt = `You are an independent verification agent. A different AI completed this coding mission.
Your job is to determine whether the mission is TRULY complete — not to rubber-stamp it.

You must be skeptical. The implementing model claims the work is done. VERIFY independently.

Check:
1. Does the code ACTUALLY satisfy every stated criterion? Trace the logic, don't just look at names.
2. Are there ANY gaps, stubs, or incomplete implementations?
3. Would you ship this to production?
4. Are edge cases handled?
5. Is error handling correct — not just present, but actually correct?

You MUST respond with ONLY a JSON object in the following format — no markdown, no code fences, no explanation outside the JSON:

{
  "verdict": "complete" or "incomplete",
  "confidence": 0.0 to 1.0,
  "reasoning": "your detailed reasoning here",
  "gaps_found": ["gap 1", "gap 2"]
}

If the mission is complete, gaps_found should be an empty array.
If you have any doubt, vote "incomplete" and explain why.`

// buildUserPrompt constructs the user prompt for a consensus voter.
func buildUserPrompt(missionIntent string, criteria []string, validationReport string, fileContents map[string]string) string {
	var b strings.Builder

	b.WriteString("## Mission Intent\n\n")
	b.WriteString(missionIntent)
	b.WriteString("\n\n")

	if len(criteria) > 0 {
		b.WriteString("## Acceptance Criteria\n\n")
		for i, c := range criteria {
			fmt.Fprintf(&b, "%d. %s\n", i+1, c)
		}
		b.WriteString("\n")
	}

	if validationReport != "" {
		b.WriteString("## Validation Report (from prior analysis)\n\n")
		b.WriteString(validationReport)
		b.WriteString("\n\n")
	}

	if len(fileContents) > 0 {
		b.WriteString("## Files to Review\n\n")
		for path, content := range fileContents {
			fmt.Fprintf(&b, "### %s\n```\n%s\n```\n\n", path, content)
		}
	}

	b.WriteString("Analyze the above and provide your verdict as JSON.")
	return b.String()
}
