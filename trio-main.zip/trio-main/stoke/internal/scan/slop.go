package scan

import "regexp"

// SlopRules returns AI-specific code smell detection rules.
// Confidence levels vary by pattern specificity:
//   - 95: exact pattern matches (low false-positive rate)
//   - 80: specific regex patterns (moderate false-positive rate)
//   - 60: broad heuristic patterns (higher false-positive rate)
func SlopRules() []Rule {
	return []Rule{
		{
			ID:         "slop-verbose-comment",
			Severity:   "medium",
			Pattern:    regexp.MustCompile(`// (This|Here we|The following|We) (function|method|code|line|block)`),
			Message:    "Comment restates the code",
			Fix:        "Remove comments that restate the code",
			FileExts:   []string{".go", ".ts", ".js", ".py"},
			Confidence: 80,
		},
		{
			ID:         "slop-unnecessary-else",
			Severity:   "low",
			Pattern:    regexp.MustCompile(`\} else \{\s*(return|throw|raise)`),
			Message:    "Unnecessary else after return/throw/raise",
			Fix:        "Use early return pattern",
			FileExts:   []string{".go", ".ts", ".js", ".py"},
			Confidence: 60,
		},
		{
			ID:         "slop-empty-error-message",
			Severity:   "high",
			Pattern:    regexp.MustCompile(`fmt\.Errorf\(""\)|new Error\(""\)|raise Exception\(""\)`),
			Message:    "Empty error message provides no context",
			Fix:        "Provide a descriptive error message",
			FileExts:   []string{".go", ".ts", ".js", ".py"},
			Confidence: 95,
		},
		{
			ID:         "slop-generic-variable-name",
			Severity:   "medium",
			Pattern:    regexp.MustCompile(`\b(data|result|temp|tmp|val|item|obj)\b\s*[:=]`),
			Message:    "Generic variable name obscures intent",
			Fix:        "Use a descriptive variable name",
			FileExts:   []string{".go", ".ts", ".js", ".py"},
			Confidence: 60,
		},
		{
			ID:         "slop-apologetic-comment",
			Severity:   "medium",
			Pattern:    regexp.MustCompile(`// (Sorry|Note:|Important:|Please note)`),
			Message:    "Apologetic or instructional comment",
			Fix:        "Remove apologetic or instructional comments",
			FileExts:   []string{".go", ".ts", ".js", ".py", ".rs"},
			Confidence: 80,
		},
		{
			ID:         "slop-redundant-type-assertion",
			Severity:   "medium",
			Pattern:    regexp.MustCompile(`\.toString\(\)\s+as\s+string`),
			Message:    "Redundant type assertion on toString()",
			Fix:        "Remove redundant type assertion",
			FileExts:   []string{".ts", ".tsx"},
			Confidence: 80,
		},
		{
			ID:         "slop-commented-out-code",
			Severity:   "medium",
			Pattern:    regexp.MustCompile(`(?m)^(\s*//.*[;{}()].*\n){3,}`),
			Message:    "Block of commented-out code",
			Fix:        "Remove commented-out code blocks",
			FileExts:   []string{".go", ".ts", ".js", ".py"},
			Confidence: 60,
		},
		{
			ID:         "slop-excessive-logging",
			Severity:   "low",
			Pattern:    regexp.MustCompile(`(log\.|console\.|print\(|fmt\.Print)`),
			Message:    "Excessive logging density",
			Fix:        "Reduce logging density",
			FileExts:   []string{".go", ".ts", ".js", ".py"},
			Confidence: 60,
		},
		{
			ID:         "slop-catch-and-log",
			Severity:   "high",
			Pattern:    regexp.MustCompile(`catch\s*\([^)]*\)\s*\{[^}]*(?:console|logger|log)\.\w+\(`),
			Message:    "Catch block only logs without rethrowing",
			Fix:        "Rethrow or handle the error, don't just log",
			FileExts:   []string{".ts", ".tsx", ".js", ".jsx"},
			Confidence: 95,
		},
		{
			ID:         "slop-import-star",
			Severity:   "medium",
			Pattern:    regexp.MustCompile(`import\s+\*\s+(?:as\s+\w+\s+)?from`),
			Message:    "Wildcard import hinders tree-shaking",
			Fix:        "Use named imports for better tree-shaking",
			FileExts:   []string{".ts", ".tsx", ".js", ".jsx"},
			Confidence: 80,
		},
	}
}
