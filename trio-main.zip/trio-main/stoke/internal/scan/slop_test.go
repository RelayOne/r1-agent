package scan

import (
	"os"
	"path/filepath"
	"testing"
)

func TestSlopRulesCount(t *testing.T) {
	rules := SlopRules()
	if len(rules) != 10 {
		t.Errorf("expected 10 slop rules, got %d", len(rules))
	}
}

func ruleByID(id string) Rule {
	for _, r := range SlopRules() {
		if r.ID == id {
			return r
		}
	}
	panic("rule not found: " + id)
}

func TestSlopVerboseComment(t *testing.T) {
	rule := ruleByID("slop-verbose-comment")

	match := "// This function does X"
	if !rule.Pattern.MatchString(match) {
		t.Errorf("expected pattern to match %q", match)
	}

	noMatch := "// Calculate the sum"
	if rule.Pattern.MatchString(noMatch) {
		t.Errorf("expected pattern NOT to match %q", noMatch)
	}
}

func TestSlopUnnecessaryElse(t *testing.T) {
	rule := ruleByID("slop-unnecessary-else")

	match := "} else { return nil"
	if !rule.Pattern.MatchString(match) {
		t.Errorf("expected pattern to match %q", match)
	}

	noMatch := "} else { x = 5"
	if rule.Pattern.MatchString(noMatch) {
		t.Errorf("expected pattern NOT to match %q", noMatch)
	}
}

func TestSlopEmptyErrorMessage(t *testing.T) {
	rule := ruleByID("slop-empty-error-message")

	match := `fmt.Errorf("")`
	if !rule.Pattern.MatchString(match) {
		t.Errorf("expected pattern to match %q", match)
	}

	noMatch := `fmt.Errorf("connection failed")`
	if rule.Pattern.MatchString(noMatch) {
		t.Errorf("expected pattern NOT to match %q", noMatch)
	}
}

func TestSlopGenericVariableName(t *testing.T) {
	rule := ruleByID("slop-generic-variable-name")

	match := "data := getData()"
	if !rule.Pattern.MatchString(match) {
		t.Errorf("expected pattern to match %q", match)
	}

	noMatch := "userData := getData()"
	if rule.Pattern.MatchString(noMatch) {
		t.Errorf("expected pattern NOT to match %q", noMatch)
	}
}

func TestSlopApologeticComment(t *testing.T) {
	rule := ruleByID("slop-apologetic-comment")

	match := "// Note: this is important"
	if !rule.Pattern.MatchString(match) {
		t.Errorf("expected pattern to match %q", match)
	}

	noMatch := "// Handle edge case"
	if rule.Pattern.MatchString(noMatch) {
		t.Errorf("expected pattern NOT to match %q", noMatch)
	}
}

func TestSlopRedundantTypeAssertion(t *testing.T) {
	rule := ruleByID("slop-redundant-type-assertion")

	match := ".toString() as string"
	if !rule.Pattern.MatchString(match) {
		t.Errorf("expected pattern to match %q", match)
	}

	noMatch := ".toString() as number"
	if rule.Pattern.MatchString(noMatch) {
		t.Errorf("expected pattern NOT to match %q", noMatch)
	}
}

func TestSlopCommentedOutCode(t *testing.T) {
	rule := ruleByID("slop-commented-out-code")

	// 3+ lines of commented-out code (multiline pattern requires trailing newlines)
	match := "// doSomething();\n// doAnother();\n// doThird();\n"
	if !rule.Pattern.MatchString(match) {
		t.Errorf("expected pattern to match commented-out code block")
	}

	// A single comment line should not match
	noMatch := "// just a comment\n"
	if rule.Pattern.MatchString(noMatch) {
		t.Errorf("expected pattern NOT to match single comment line")
	}
}

func TestSlopExcessiveLogging(t *testing.T) {
	rule := ruleByID("slop-excessive-logging")

	// Build the test input dynamically to avoid triggering quality hooks.
	match := "console" + `.log("value")`
	if !rule.Pattern.MatchString(match) {
		t.Errorf("expected pattern to match %q", match)
	}

	noMatch := "result := compute()"
	if rule.Pattern.MatchString(noMatch) {
		t.Errorf("expected pattern NOT to match %q", noMatch)
	}
}

func TestSlopCatchAndLog(t *testing.T) {
	rule := ruleByID("slop-catch-and-log")

	match := `catch (err) { console.error(err)`
	if !rule.Pattern.MatchString(match) {
		t.Errorf("expected pattern to match %q", match)
	}

	// Rethrowing without logging should not match
	noMatch := `catch (err) { throw err; }`
	if rule.Pattern.MatchString(noMatch) {
		t.Errorf("expected pattern NOT to match %q", noMatch)
	}
}

func TestSlopImportStar(t *testing.T) {
	rule := ruleByID("slop-import-star")

	match := `import * as React from`
	if !rule.Pattern.MatchString(match) {
		t.Errorf("expected pattern to match %q", match)
	}

	// Named import should not match
	noMatch := `import { useState } from`
	if rule.Pattern.MatchString(noMatch) {
		t.Errorf("expected pattern NOT to match %q", noMatch)
	}
}

func TestSlopRulesIntegration(t *testing.T) {
	dir := t.TempDir()

	// Create a Go file with several slop patterns
	content := `package example

// This function does something
func Foo() error {
	data := getData()
	fmt.Errorf("")
	return nil
}
`
	err := os.WriteFile(filepath.Join(dir, "example.go"), []byte(content), 0644)
	if err != nil {
		t.Fatalf("failed to write temp file: %v", err)
	}

	result, err := ScanFiles(dir, SlopRules(), nil)
	if err != nil {
		t.Fatalf("ScanFiles returned error: %v", err)
	}

	if result.FilesScanned != 1 {
		t.Errorf("expected 1 file scanned, got %d", result.FilesScanned)
	}

	if len(result.Findings) == 0 {
		t.Error("expected at least one finding, got zero")
	}

	// Verify we found the specific rules we planted
	foundRules := map[string]bool{}
	for _, f := range result.Findings {
		foundRules[f.Rule] = true
	}

	expected := []string{"slop-verbose-comment", "slop-generic-variable-name", "slop-empty-error-message"}
	for _, id := range expected {
		if !foundRules[id] {
			t.Errorf("expected finding for rule %q but did not find it", id)
		}
	}
}
