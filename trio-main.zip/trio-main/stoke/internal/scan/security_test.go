package scan

import (
	"os"
	"path/filepath"
	"testing"
)

func TestMapSecuritySurface(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "auth.go"), []byte(`
package main

import (
    "github.com/golang-jwt/jwt/v5"
    "golang.org/x/crypto/bcrypt"
)

func hashPassword(pw string) error {
    return bcrypt.GenerateFromPassword([]byte(pw), bcrypt.DefaultCost)
}
`), 0644)

	m, err := MapSecuritySurface(dir, nil)
	if err != nil {
		t.Fatal(err)
	}
	if m.FilesScanned != 1 {
		t.Errorf("FilesScanned=%d, want 1", m.FilesScanned)
	}
	if len(m.Surfaces) == 0 {
		t.Error("expected at least one security surface finding")
	}
}

func TestMapSecuritySurfaceModifiedOnly(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "auth.go"), []byte(`import "crypto/aes"`), 0644)
	os.WriteFile(filepath.Join(dir, "main.go"), []byte(`import "fmt"`), 0644)

	m, err := MapSecuritySurface(dir, []string{"auth.go"})
	if err != nil {
		t.Fatal(err)
	}
	if m.FilesScanned != 1 {
		t.Errorf("FilesScanned=%d, want 1 (only auth.go)", m.FilesScanned)
	}
}

func TestExtMatch(t *testing.T) {
	if !extMatch(".ts", []string{".ts", ".tsx"}) {
		t.Error(".ts should match .ts/.tsx")
	}
	if extMatch(".go", []string{".ts", ".tsx"}) {
		t.Error(".go should not match .ts/.tsx")
	}
	if extMatch(".ts", nil) {
		t.Error("nil exts means match all, so .ts should not be excluded")
	}
	if extMatch(".py", []string{".ts", ".tsx"}) {
		t.Error(".py should not match .ts/.tsx")
	}
}

func TestSecurityMapSummaryEmpty(t *testing.T) {
	m := &SecurityMap{}
	s := m.Summary()
	if s != "No security-relevant code found" {
		t.Errorf("empty summary=%q", s)
	}
}

func TestSecurityMapSummaryWithFindings(t *testing.T) {
	m := &SecurityMap{
		Surfaces: []SecuritySurface{
			{Category: "auth", Risk: "high"},
			{Category: "auth", Risk: "medium"},
			{Category: "crypto", Risk: "high"},
			{Category: "network", Risk: "medium"},
		},
	}
	s := m.Summary()
	if s == "" {
		t.Error("Summary() should not be empty")
	}
}

func TestScanSecurityFileOpenError(t *testing.T) {
	findings, err := scanSecurityFile("/nonexistent/file.go", "nonexistent/file.go")
	if err == nil {
		t.Error("expected error opening nonexistent file")
	}
	if len(findings) != 0 {
		t.Errorf("open error should yield 0 findings, got %d", len(findings))
	}
}

func TestScanSecurityFileAuthJWT(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "jwt.go")
	os.WriteFile(path, []byte(`import "github.com/golang-jwt/jwt"`), 0644)

	surfaces, err := scanSecurityFile(path, "jwt.go")
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, s := range surfaces {
		if s.Category == "auth" {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected auth finding for JWT usage")
	}
}

func TestScanSecurityFileInjectionRisk(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "exec.py")
	// The security rule pattern is \b(exec|spawn|system|popen)\( -- needs word boundary
	os.WriteFile(path, []byte("import os\nos.system('ls')\n"), 0644)

	surfaces, err := scanSecurityFile(path, "exec.py")
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, s := range surfaces {
		if s.Category == "injection" {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected injection finding for os.system usage")
	}
}

func TestScanSecurityFileSecretsEnv(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "env.go")
	os.WriteFile(path, []byte(`os.Getenv("DATABASE_URL")`), 0644)

	surfaces, err := scanSecurityFile(path, "env.go")
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, s := range surfaces {
		if s.Category == "secrets" {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected secrets finding for env access")
	}
}
