package scan

import (
	"os"
	"path/filepath"
	"regexp"
	"testing"
)

func TestScanTSIgnore(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "bad.ts"), []byte("// @ts-ignore\nconst x: any = 1;\n"), 0644)

	result, err := ScanFiles(dir, DefaultRules(), nil)
	if err != nil {
		t.Fatal(err)
	}
	if result.FilesScanned != 1 {
		t.Errorf("scanned=%d", result.FilesScanned)
	}
	found := false
	for _, f := range result.Findings {
		if f.Rule == "no-ts-ignore" { found = true }
	}
	if !found {
		t.Error("expected no-ts-ignore finding")
	}
}

func TestScanAsAny(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "cast.ts"), []byte("const x = foo as any;\n"), 0644)

	result, _ := ScanFiles(dir, DefaultRules(), nil)
	found := false
	for _, f := range result.Findings {
		if f.Rule == "no-as-any" { found = true }
	}
	if !found {
		t.Error("expected no-as-any finding")
	}
}

func TestScanConsoleLog(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "debug.js"), []byte("console.log('debug');\n"), 0644)

	result, _ := ScanFiles(dir, DefaultRules(), nil)
	found := false
	for _, f := range result.Findings {
		if f.Rule == "no-console-log" { found = true }
	}
	if !found {
		t.Error("expected no-console-log finding")
	}
}

func TestScanTestOnly(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "test.ts"), []byte("it.only('should work', () => {});\n"), 0644)

	result, _ := ScanFiles(dir, DefaultRules(), nil)
	found := false
	for _, f := range result.Findings {
		if f.Rule == "no-test-only" { found = true }
	}
	if !found {
		t.Error("expected no-test-only finding")
	}
}

func TestScanHardcodedSecret(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "config.go"), []byte(`password := "supersecretpassword123"`+"\n"), 0644)

	result, _ := ScanFiles(dir, DefaultRules(), nil)
	found := false
	for _, f := range result.Findings {
		if f.Rule == "no-hardcoded-secret" { found = true }
	}
	if !found {
		t.Error("expected no-hardcoded-secret finding")
	}
}

func TestScanCleanFile(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "clean.go"), []byte("package main\n\nfunc main() {}\n"), 0644)

	result, _ := ScanFiles(dir, DefaultRules(), nil)
	if len(result.Findings) != 0 {
		t.Errorf("clean file should have 0 findings, got %d", len(result.Findings))
	}
}

func TestScanModifiedOnly(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "bad.ts"), []byte("// @ts-ignore\n"), 0644)
	os.WriteFile(filepath.Join(dir, "also_bad.ts"), []byte("// @ts-ignore\n"), 0644)

	// Only scan bad.ts
	result, _ := ScanFiles(dir, DefaultRules(), []string{"bad.ts"})
	if result.FilesScanned != 1 {
		t.Errorf("should only scan 1 file, scanned %d", result.FilesScanned)
	}
}

func TestScanPythonNoqa(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "bad.py"), []byte("x = 1  # noqa: E501\n"), 0644)

	result, _ := ScanFiles(dir, DefaultRules(), nil)
	found := false
	for _, f := range result.Findings {
		if f.Rule == "no-noqa" { found = true }
	}
	if !found {
		t.Error("expected no-noqa finding")
	}
}

func TestScanGoNolint(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "bad.go"), []byte("package main\n\nvar x = 1 // nolint:unused\n"), 0644)

	result, _ := ScanFiles(dir, DefaultRules(), nil)
	found := false
	for _, f := range result.Findings {
		if f.Rule == "no-nolint" { found = true }
	}
	if !found {
		t.Error("expected no-nolint finding")
	}
}

func TestHasBlocking(t *testing.T) {
	r := &ScanResult{Findings: []Finding{{Severity: "low"}}}
	if r.HasBlocking() {
		t.Error("low severity should not block")
	}
	r.Findings = append(r.Findings, Finding{Severity: "critical"})
	if !r.HasBlocking() {
		t.Error("critical severity should block")
	}
}

func TestScanSkipsNodeModules(t *testing.T) {
	dir := t.TempDir()
	os.MkdirAll(filepath.Join(dir, "node_modules", "pkg"), 0755)
	os.WriteFile(filepath.Join(dir, "node_modules", "pkg", "bad.js"), []byte("eval('x')\n"), 0644)
	os.WriteFile(filepath.Join(dir, "src.js"), []byte("var x = 1;\n"), 0644)

	result, _ := ScanFiles(dir, DefaultRules(), nil)
	for _, f := range result.Findings {
		if f.File == "node_modules/pkg/bad.js" {
			t.Error("should skip node_modules")
		}
	}
}

func TestFilterByConfidence(t *testing.T) {
	findings := []Finding{
		{Rule: "a", Confidence: 50},
		{Rule: "b", Confidence: 80},
		{Rule: "c", Confidence: 100},
	}
	got := FilterByConfidence(findings, 80)
	if len(got) != 2 {
		t.Errorf("expected 2 findings at threshold 80, got %d", len(got))
	}
	for _, f := range got {
		if f.Confidence < 80 {
			t.Errorf("finding %q has confidence %d, below threshold 80", f.Rule, f.Confidence)
		}
	}
}

func TestFilterByConfidenceZeroThreshold(t *testing.T) {
	findings := []Finding{
		{Rule: "a", Confidence: 10},
		{Rule: "b", Confidence: 50},
		{Rule: "c", Confidence: 90},
	}
	got := FilterByConfidence(findings, 0)
	if len(got) != 3 {
		t.Errorf("expected all 3 findings at threshold 0, got %d", len(got))
	}
}

func TestFilterByConfidenceAllFiltered(t *testing.T) {
	findings := []Finding{
		{Rule: "a", Confidence: 20},
		{Rule: "b", Confidence: 50},
		{Rule: "c", Confidence: 99},
	}
	got := FilterByConfidence(findings, 100)
	if len(got) != 0 {
		t.Errorf("expected 0 findings at threshold 100 with all below, got %d", len(got))
	}
}

// --- Additional coverage tests ---

func TestScanFilesSkipsNonMatchingExtensions(t *testing.T) {
	dir := t.TempDir()
	// Write a .go file. Use a rule that only targets .ts files.
	os.WriteFile(filepath.Join(dir, "code.go"), []byte("package main\n\n// @ts-ignore\n"), 0644)

	tsOnlyRule := []Rule{
		{ID: "ts-only", Severity: "critical", Pattern: regexp.MustCompile(`@ts-ignore`), Message: "ts-ignore", FileExts: []string{".ts"}, Confidence: 100},
	}
	result, err := ScanFiles(dir, tsOnlyRule, nil)
	if err != nil {
		t.Fatal(err)
	}
	if len(result.Findings) != 0 {
		t.Errorf("expected 0 findings for .go file with .ts-only rule, got %d", len(result.Findings))
	}
}

func TestScanResultHasBlockingCritical(t *testing.T) {
	r := &ScanResult{
		Findings: []Finding{
			{Rule: "critical-rule", Severity: "critical", Confidence: 100},
		},
	}
	if !r.HasBlocking() {
		t.Error("result with critical finding should have blocking=true")
	}
}

func TestScanResultHasBlockingHigh(t *testing.T) {
	r := &ScanResult{
		Findings: []Finding{
			{Rule: "high-rule", Severity: "high", Confidence: 100},
		},
	}
	if !r.HasBlocking() {
		t.Error("result with high finding should have blocking=true")
	}
}

func TestScanResultHasBlockingMediumOnly(t *testing.T) {
	r := &ScanResult{
		Findings: []Finding{
			{Rule: "med-rule", Severity: "medium", Confidence: 100},
		},
	}
	if r.HasBlocking() {
		t.Error("result with only medium finding should have blocking=false")
	}
}

func TestScanResultSummaryNoFindings(t *testing.T) {
	r := &ScanResult{FilesScanned: 5, Findings: nil}
	s := r.Summary()
	if s != "Scanned 5 files: no issues found" {
		t.Errorf("unexpected summary for empty result: %q", s)
	}
}

func TestScanResultSummaryWithFindings(t *testing.T) {
	r := &ScanResult{
		FilesScanned: 3,
		Findings: []Finding{
			{Severity: "critical"},
			{Severity: "critical"},
			{Severity: "high"},
			{Severity: "medium"},
			{Severity: "low"},
		},
	}
	s := r.Summary()
	expected := "Scanned 3 files: 2 critical, 1 high, 1 medium, 1 low"
	if s != expected {
		t.Errorf("Summary() = %q, want %q", s, expected)
	}
}

func TestSecuritySurfaceMapping(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "auth.py"), []byte("from passlib.hash import bcrypt\noauth_flow()\n"), 0644)

	m, err := MapSecuritySurface(dir, nil)
	if err != nil {
		t.Fatal(err)
	}
	if len(m.Surfaces) == 0 {
		t.Error("expected security surfaces for auth patterns")
	}
	foundAuth := false
	for _, s := range m.Surfaces {
		if s.Category == "auth" {
			foundAuth = true
			break
		}
	}
	if !foundAuth {
		t.Error("expected auth category in security surfaces")
	}
}

func TestFilterByConfidenceEdgeCases(t *testing.T) {
	findings := []Finding{
		{Rule: "exact", Confidence: 75},
		{Rule: "above", Confidence: 76},
		{Rule: "below", Confidence: 74},
	}

	// Threshold exactly equal to confidence: finding should be included
	got := FilterByConfidence(findings, 75)
	foundExact := false
	for _, f := range got {
		if f.Rule == "exact" {
			foundExact = true
		}
		if f.Rule == "below" {
			t.Error("finding with confidence below threshold should be excluded")
		}
	}
	if !foundExact {
		t.Error("finding with confidence exactly equal to threshold should be included")
	}
	if len(got) != 2 {
		t.Errorf("expected 2 findings (exact + above), got %d", len(got))
	}

	// Threshold one above: "exact" should be excluded
	got2 := FilterByConfidence(findings, 76)
	for _, f := range got2 {
		if f.Rule == "exact" {
			t.Error("finding with confidence below threshold+1 should be excluded")
		}
	}
	if len(got2) != 1 {
		t.Errorf("expected 1 finding at threshold 76, got %d", len(got2))
	}
}
