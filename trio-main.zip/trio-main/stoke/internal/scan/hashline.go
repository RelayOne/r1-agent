package scan

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

// HashLine returns the first 8 characters of an FNV-1a 32-bit hash of the trimmed line content.
// Uses FNV-1a as a simpler alternative to xxHash32 (pure Go, no dependencies, similar
// collision resistance for short strings).
func HashLine(content string) string {
	// FNV-1a 32-bit hash
	// Offset basis: 2166136261, Prime: 16777619
	h := uint32(2166136261)
	trimmed := strings.TrimSpace(content)
	for i := 0; i < len(trimmed); i++ {
		h ^= uint32(trimmed[i])
		h *= 16777619
	}
	return fmt.Sprintf("%08x", h)
}

// HashFile reads a file and returns a map of line number (1-indexed) to hash.
func HashFile(path string) (map[int]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	result := make(map[int]string)
	scanner := bufio.NewScanner(f)
	lineNum := 1
	for scanner.Scan() {
		result[lineNum] = HashLine(scanner.Text())
		lineNum++
	}
	return result, scanner.Err()
}

// HashFileContent computes a single hash for the entire file content.
func HashFileContent(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	h := uint32(2166136261)
	for i := 0; i < len(data); i++ {
		h ^= uint32(data[i])
		h *= 16777619
	}
	return fmt.Sprintf("%08x", h), nil
}

// VerifyEdit checks if a specific line still has the expected content hash.
// Returns (matches bool, actualHash string).
func VerifyEdit(path string, lineNum int, expectedHash string) (bool, string) {
	hashes, err := HashFile(path)
	if err != nil {
		return false, ""
	}
	actual, exists := hashes[lineNum]
	if !exists {
		return false, ""
	}
	return actual == expectedHash, actual
}
