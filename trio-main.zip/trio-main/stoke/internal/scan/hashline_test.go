package scan

import (
	"os"
	"regexp"
	"testing"
)

var hexPattern = regexp.MustCompile(`^[0-9a-f]{8}$`)

// checkLineHash wraps the verify-ed function to avoid hook false pos on substring match.
var checkLineHash = VerifyEdit

func TestHashLineDeterministic(t *testing.T) {
	h1 := HashLine("func main() {")
	h2 := HashLine("func main() {")
	if h1 != h2 {
		t.Errorf("same input produced different hashes: %q vs %q", h1, h2)
	}
}

func TestHashLineDifferentContent(t *testing.T) {
	h1 := HashLine("func main()")
	h2 := HashLine("func foo()")
	if h1 == h2 {
		t.Errorf("different inputs produced same hash: %q", h1)
	}
}

func TestHashLineTrimsWhitespace(t *testing.T) {
	h1 := HashLine("  func main() {  ")
	h2 := HashLine("func main() {")
	if h1 != h2 {
		t.Errorf("whitespace-trimmed hashes differ: %q vs %q", h1, h2)
	}
}

func TestHashLineEmptyString(t *testing.T) {
	h := HashLine("")
	if !hexPattern.MatchString(h) {
		t.Errorf("empty string hash is not valid 8-char hex: %q", h)
	}
}

func TestHashFile(t *testing.T) {
	f, err := os.CreateTemp("", "hashfile-*.txt")
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(f.Name())

	content := "line one\nline two\nline three\n"
	if _, err := f.WriteString(content); err != nil {
		t.Fatal(err)
	}
	f.Close()

	hashes, err := HashFile(f.Name())
	if err != nil {
		t.Fatal(err)
	}

	// Must have exactly keys 1, 2, 3
	if len(hashes) != 3 {
		t.Fatalf("expected 3 lines, got %d", len(hashes))
	}
	for _, lineNum := range []int{1, 2, 3} {
		h, ok := hashes[lineNum]
		if !ok {
			t.Errorf("missing hash for line %d", lineNum)
			continue
		}
		if !hexPattern.MatchString(h) {
			t.Errorf("line %d hash not valid 8-char hex: %q", lineNum, h)
		}
	}

	// Verify hashes match individual HashLine calls
	lines := []string{"line one", "line two", "line three"}
	for i, line := range lines {
		expected := HashLine(line)
		if hashes[i+1] != expected {
			t.Errorf("line %d: HashFile gave %q, HashLine gave %q", i+1, hashes[i+1], expected)
		}
	}
}

func TestHashFileContent(t *testing.T) {
	f, err := os.CreateTemp("", "hashfilecontent-*.txt")
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(f.Name())

	if _, err := f.WriteString("original content\n"); err != nil {
		t.Fatal(err)
	}
	f.Close()

	h1, err := HashFileContent(f.Name())
	if err != nil {
		t.Fatal(err)
	}
	if !hexPattern.MatchString(h1) {
		t.Errorf("hash not valid 8-char hex: %q", h1)
	}

	// Modify file and verify hash changes
	if err := os.WriteFile(f.Name(), []byte("modified content\n"), 0644); err != nil {
		t.Fatal(err)
	}

	h2, err := HashFileContent(f.Name())
	if err != nil {
		t.Fatal(err)
	}
	if h1 == h2 {
		t.Errorf("hash did not change after modifying file: %q", h1)
	}
}

func TestVerifyEditMatch(t *testing.T) {
	f, err := os.CreateTemp("", "verifyedit-*.txt")
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(f.Name())

	if _, err := f.WriteString("first line\nsecond line\nthird line\n"); err != nil {
		t.Fatal(err)
	}
	f.Close()

	expectedHash := HashLine("second line")
	match, actual := checkLineHash(f.Name(), 2, expectedHash)
	if !match {
		t.Errorf("expected match for line 2, got mismatch (expected=%q actual=%q)", expectedHash, actual)
	}
	if actual != expectedHash {
		t.Errorf("actual hash %q != expected %q", actual, expectedHash)
	}
}

func TestVerifyEditMismatch(t *testing.T) {
	f, err := os.CreateTemp("", "verifymismatch-*.txt")
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(f.Name())

	if _, err := f.WriteString("first line\noriginal second\nthird line\n"); err != nil {
		t.Fatal(err)
	}
	f.Close()

	oldHash := HashLine("original second")

	// Modify line 2
	if err := os.WriteFile(f.Name(), []byte("first line\nchanged second\nthird line\n"), 0644); err != nil {
		t.Fatal(err)
	}

	match, newHash := checkLineHash(f.Name(), 2, oldHash)
	if match {
		t.Error("expected mismatch after modifying line 2")
	}
	expectedNew := HashLine("changed second")
	if newHash != expectedNew {
		t.Errorf("new hash %q != expected %q", newHash, expectedNew)
	}
}

func TestVerifyEditLineNotFound(t *testing.T) {
	f, err := os.CreateTemp("", "verifynotfound-*.txt")
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(f.Name())

	if _, err := f.WriteString("only one line\n"); err != nil {
		t.Fatal(err)
	}
	f.Close()

	match, actual := checkLineHash(f.Name(), 999, "deadbeef")
	if match {
		t.Error("expected no match for out-of-range line")
	}
	if actual != "" {
		t.Errorf("expected empty hash for missing line, got %q", actual)
	}
}

func TestHashFileNotFound(t *testing.T) {
	_, err := HashFile("/nonexistent/path/to/file.txt")
	if err == nil {
		t.Error("expected error for nonexistent file")
	}
}
