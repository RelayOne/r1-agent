package pools

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestLoadManifestFileNotExist(t *testing.T) {
	// Use a temp HOME so ManifestPath() returns a path in that directory
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	// ~/.stoke/pools/manifest.json definitely does not exist
	m, err := LoadManifest()
	if err != nil {
		t.Fatal(err)
	}
	if len(m.Pools) != 0 {
		t.Errorf("empty manifest: got %d pools", len(m.Pools))
	}
}

func TestLoadManifestParseError(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	// Create the manifest file with invalid JSON
	store := filepath.Join(tmp, ".stoke", "pools")
	if err := os.MkdirAll(store, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(store, "manifest.json"), []byte("{ invalid json"), 0600); err != nil {
		t.Fatal(err)
	}

	_, err := LoadManifest()
	if err == nil {
		t.Error("expected parse error")
	}
}

func TestManifestSaveAndReload(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	m := &Manifest{Pools: []Pool{
		{ID: "claude-1", Label: "Primary", ConfigDir: "/cfg/1", Provider: "claude", AccountID: "acct-1"},
		{ID: "codex-1", Label: "Secondary", ConfigDir: "/cfg/2", Provider: "codex", AccountID: "acct-2"},
	}}

	if err := m.Save(); err != nil {
		t.Fatal(err)
	}

	m2, err := LoadManifest()
	if err != nil {
		t.Fatal(err)
	}
	if len(m2.Pools) != 2 {
		t.Errorf("got %d pools, want 2", len(m2.Pools))
	}
	if m2.Pools[0].AccountID != "acct-1" {
		t.Errorf("AccountID=%q", m2.Pools[0].AccountID)
	}
}

func TestManifestFindByAccount(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "c1", AccountID: "a1"},
		{ID: "c2", AccountID: "a2"},
	}}

	p := m.FindByAccount("a2")
	if p == nil || p.ID != "c2" {
		t.Errorf("FindByAccount(a2)=%v, want c2", p)
	}

	p = m.FindByAccount("nonexistent")
	if p != nil {
		t.Error("FindByAccount(nonexistent) should return nil")
	}
}

func TestManifestClaudeDirs(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "c1", Provider: "claude", ConfigDir: "/cfg/1"},
		{ID: "cx1", Provider: "codex", ConfigDir: "/cfg/2"},
		{ID: "c2", Provider: "claude", ConfigDir: "/cfg/3"},
	}}

	dirs := m.ClaudeDirs()
	if len(dirs) != 2 {
		t.Errorf("ClaudeDirs()=%v, want 2", dirs)
	}
}

func TestManifestCodexDirs(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "cx1", Provider: "codex", ConfigDir: "/cfg/1"},
		{ID: "c1", Provider: "claude", ConfigDir: "/cfg/2"},
	}}

	dirs := m.CodexDirs()
	if len(dirs) != 1 || dirs[0] != "/cfg/1" {
		t.Errorf("CodexDirs()=%v", dirs)
	}
}

func TestManifestNextIDEmpty(t *testing.T) {
	m := &Manifest{}
	id := m.NextID("claude")
	if id != "claude-1" {
		t.Errorf("NextID(claude) on empty manifest=%q, want claude-1", id)
	}
}

func TestManifestNextIDSequential(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "claude-1"}, {ID: "claude-3"},
	}}
	id := m.NextID("claude")
	if id != "claude-4" {
		t.Errorf("NextID(claude)=%q, want claude-4", id)
	}
}

func TestManifestNextIDWrongProvider(t *testing.T) {
	m := &Manifest{Pools: []Pool{{ID: "claude-5"}}}
	id := m.NextID("codex")
	if id != "codex-1" {
		t.Errorf("NextID(codex)=%q, want codex-1", id)
	}
}

func TestReadAccountIDNoFile(t *testing.T) {
	result := readAccountID("/nonexistent/path")
	if result != "" {
		t.Errorf("readAccountID(nonexistent)=%q, want empty", result)
	}
}

func TestReadAccountIDEmail(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, ".credentials.json")
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{
			"email": "alice@example.com",
		},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readAccountID(dir)
	if result != "alice@example.com" {
		t.Errorf("readAccountID()=%q, want alice@example.com", result)
	}
}

func TestReadAccountIDAccountId(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, ".credentials.json")
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{
			"accountId": "acct_12345",
		},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readAccountID(dir)
	if result != "acct_12345" {
		t.Errorf("readAccountID()=%q, want acct_12345", result)
	}
}

func TestReadAccountIDTokenFallback(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, ".credentials.json")
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{
			"accessToken": "sk-ant-something",
		},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readAccountID(dir)
	// Token should be hashed, not returned raw
	if result == "" || result == "sk-ant-something" {
		t.Errorf("readAccountID()=%q — token should be hashed, not raw", result)
	}
}

func TestReadTokenNoFile(t *testing.T) {
	result := readToken("/nonexistent")
	if result != "" {
		t.Errorf("readToken(nonexistent)=%q, want empty", result)
	}
}

func TestReadTokenValid(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, ".credentials.json")
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{
			"accessToken": "sk-ant-test-token",
		},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readToken(dir)
	if result != "sk-ant-test-token" {
		t.Errorf("readToken()=%q", result)
	}
}

func TestReadCodexAccountIDEmail(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, "credentials.json")
	creds := map[string]interface{}{"email": "bob@example.com"}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readCodexAccountID(dir)
	if result != "bob@example.com" {
		t.Errorf("readCodexAccountID()=%q, want bob@example.com", result)
	}
}

func TestReadCodexAccountIDToken(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, "credentials.json")
	creds := map[string]interface{}{"api_key": "sk-codex-test"}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readCodexAccountID(dir)
	// Token should be hashed
	if result == "" || result == "sk-codex-test" {
		t.Errorf("readCodexAccountID()=%q — token should be hashed", result)
	}
}

func TestReadCodexAccountIDNoCreds(t *testing.T) {
	result := readCodexAccountID("/nonexistent")
	if result != "" {
		t.Errorf("readCodexAccountID()=%q, want empty", result)
	}
}

func TestCopyCredentials(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()

	os.WriteFile(filepath.Join(src, "auth.json"), []byte(`{"token":"abc"}`), 0600)
	os.WriteFile(filepath.Join(src, "config.json"), []byte(`{"key":"val"}`), 0600)
	os.MkdirAll(filepath.Join(src, "subdir"), 0700)
	os.WriteFile(filepath.Join(src, "subdir", "nested.json"), []byte(`{}`), 0600)

	if err := copyCredentials(src, dst); err != nil {
		t.Fatal(err)
	}

	for _, name := range []string{"auth.json", "config.json"} {
		if _, err := os.Stat(filepath.Join(dst, name)); err != nil {
			t.Errorf("file %s not copied: %v", name, err)
		}
	}

	// subdir should be skipped
	if _, err := os.Stat(filepath.Join(dst, "subdir")); !os.IsNotExist(err) {
		t.Error("subdirectories should be skipped by copyCredentials")
	}
}

func TestRemovePoolFound(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	m := &Manifest{Pools: []Pool{
		{ID: "c1", ConfigDir: filepath.Join(tmp, "cfg1")},
		{ID: "c2", ConfigDir: filepath.Join(tmp, "cfg2")},
	}}
	os.MkdirAll(filepath.Join(tmp, "cfg1"), 0755)
	os.MkdirAll(filepath.Join(tmp, "cfg2"), 0755)

	if err := m.Save(); err != nil {
		t.Fatal(err)
	}

	if err := RemovePool("c1"); err != nil {
		t.Fatal(err)
	}

	m2, _ := LoadManifest()
	if len(m2.Pools) != 1 || m2.Pools[0].ID != "c2" {
		t.Errorf("after remove: got %v", m2.Pools)
	}
}

func TestRemovePoolNotFound(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	err := RemovePool("nonexistent")
	if err == nil {
		t.Error("expected error for nonexistent pool")
	}
}

// ---------------------------------------------------------------------------
// AddAPIPool tests
// ---------------------------------------------------------------------------

func TestAddAPIPoolNewPool(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	id, err := AddAPIPool("My LiteLLM", "sk-test-key-1", "http://localhost:4000", "claude")
	if err != nil {
		t.Fatal(err)
	}
	if id != "claude-1" {
		t.Errorf("got id=%q, want claude-1", id)
	}

	m, err := LoadManifest()
	if err != nil {
		t.Fatal(err)
	}
	if len(m.Pools) != 1 {
		t.Fatalf("got %d pools, want 1", len(m.Pools))
	}
	p := m.Pools[0]
	if p.Label != "My LiteLLM" {
		t.Errorf("label=%q, want My LiteLLM", p.Label)
	}
	if p.APIKey != "sk-test-key-1" {
		t.Errorf("api_key=%q", p.APIKey)
	}
	if p.BaseURL != "http://localhost:4000" {
		t.Errorf("base_url=%q", p.BaseURL)
	}
	if p.Provider != "claude" {
		t.Errorf("provider=%q", p.Provider)
	}
	// AccountID should be sha256 hash based
	h := sha256.Sum256([]byte("sk-test-key-1"))
	wantAccountID := "api-" + hex.EncodeToString(h[:8])
	if p.AccountID != wantAccountID {
		t.Errorf("account_id=%q, want %q", p.AccountID, wantAccountID)
	}
}

func TestAddAPIPoolDefaultProvider(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	id, err := AddAPIPool("", "sk-key-2", "", "")
	if err != nil {
		t.Fatal(err)
	}
	// Empty provider should default to "claude"
	if !strings.HasPrefix(id, "claude-") {
		t.Errorf("id=%q should start with claude-", id)
	}

	m, _ := LoadManifest()
	if m.Pools[0].Provider != "claude" {
		t.Errorf("provider=%q, want claude", m.Pools[0].Provider)
	}
}

func TestAddAPIPoolDefaultLabel(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	_, err := AddAPIPool("", "sk-key-3", "", "claude")
	if err != nil {
		t.Fatal(err)
	}

	m, _ := LoadManifest()
	// Default label is "API Pool #1"
	if m.Pools[0].Label != "API Pool #1" {
		t.Errorf("label=%q, want 'API Pool #1'", m.Pools[0].Label)
	}
}

func TestAddAPIPoolNoBaseURL(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	_, err := AddAPIPool("Direct API", "sk-key-4", "", "claude")
	if err != nil {
		t.Fatal(err)
	}

	m, _ := LoadManifest()
	if m.Pools[0].BaseURL != "" {
		t.Errorf("base_url=%q, want empty", m.Pools[0].BaseURL)
	}
}

func TestAddAPIPoolDedupUpdateExisting(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	// Add pool first time
	id1, err := AddAPIPool("First Label", "sk-dedup-key", "http://old-url", "claude")
	if err != nil {
		t.Fatal(err)
	}

	// Add again with same API key -- should dedup and update
	id2, err := AddAPIPool("Updated Label", "sk-dedup-key", "http://new-url", "claude")
	if err != nil {
		t.Fatal(err)
	}

	// Should return the same pool ID
	if id1 != id2 {
		t.Errorf("dedup should return same ID: got %q and %q", id1, id2)
	}

	m, _ := LoadManifest()
	if len(m.Pools) != 1 {
		t.Fatalf("dedup should not add extra pool: got %d", len(m.Pools))
	}
	// Fields should be updated
	if m.Pools[0].BaseURL != "http://new-url" {
		t.Errorf("base_url not updated: %q", m.Pools[0].BaseURL)
	}
	if m.Pools[0].Label != "Updated Label" {
		t.Errorf("label not updated: %q", m.Pools[0].Label)
	}
}

func TestAddAPIPoolDedupKeepsLabelWhenEmpty(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	AddAPIPool("Original Label", "sk-keep-label", "", "claude")
	// Re-add with empty label -- should keep the original
	AddAPIPool("", "sk-keep-label", "", "claude")

	m, _ := LoadManifest()
	if m.Pools[0].Label != "Original Label" {
		t.Errorf("label should be preserved when empty: %q", m.Pools[0].Label)
	}
}

func TestAddAPIPoolMultiplePools(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	id1, _ := AddAPIPool("Pool A", "sk-key-a", "", "claude")
	id2, _ := AddAPIPool("Pool B", "sk-key-b", "", "claude")
	id3, _ := AddAPIPool("Pool C", "sk-key-c", "", "codex")

	if id1 != "claude-1" || id2 != "claude-2" || id3 != "codex-1" {
		t.Errorf("sequential IDs: got %q %q %q", id1, id2, id3)
	}

	m, _ := LoadManifest()
	if len(m.Pools) != 3 {
		t.Fatalf("got %d pools, want 3", len(m.Pools))
	}
}

// ---------------------------------------------------------------------------
// RemovePool additional edge cases
// ---------------------------------------------------------------------------

func TestRemovePoolCleansUpConfigDir(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	cfgDir := filepath.Join(tmp, "pool-cfg")
	os.MkdirAll(cfgDir, 0755)
	os.WriteFile(filepath.Join(cfgDir, "creds.json"), []byte("{}"), 0600)

	m := &Manifest{Pools: []Pool{
		{ID: "c1", ConfigDir: cfgDir, AccountID: "acct-1"},
	}}
	if err := m.Save(); err != nil {
		t.Fatal(err)
	}

	if err := RemovePool("c1"); err != nil {
		t.Fatal(err)
	}

	// Config dir should be removed
	if _, err := os.Stat(cfgDir); !os.IsNotExist(err) {
		t.Error("RemovePool should delete the config directory")
	}
}

func TestRemovePoolFromManifestWithManyPools(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	m := &Manifest{Pools: []Pool{
		{ID: "c1", ConfigDir: filepath.Join(tmp, "cfg1"), AccountID: "a1"},
		{ID: "c2", ConfigDir: filepath.Join(tmp, "cfg2"), AccountID: "a2"},
		{ID: "c3", ConfigDir: filepath.Join(tmp, "cfg3"), AccountID: "a3"},
	}}
	for _, p := range m.Pools {
		os.MkdirAll(p.ConfigDir, 0755)
	}
	m.Save()

	// Remove the middle one
	RemovePool("c2")

	m2, _ := LoadManifest()
	if len(m2.Pools) != 2 {
		t.Fatalf("got %d pools, want 2", len(m2.Pools))
	}
	for _, p := range m2.Pools {
		if p.ID == "c2" {
			t.Error("c2 should have been removed")
		}
	}
}

func TestRemovePoolFromEmptyManifest(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	// No manifest file exists -- RemovePool should still fail gracefully
	err := RemovePool("anything")
	if err == nil {
		t.Error("expected error removing from empty manifest")
	}
}

// ---------------------------------------------------------------------------
// Manifest persistence round-trip edge cases
// ---------------------------------------------------------------------------

func TestManifestSaveCreatesDirectory(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	// Ensure ~/.stoke/pools does not exist yet
	storePath := filepath.Join(tmp, ".stoke", "pools")
	if _, err := os.Stat(storePath); !os.IsNotExist(err) {
		t.Fatal("store path should not exist yet")
	}

	m := &Manifest{Pools: []Pool{{ID: "test-1"}}}
	if err := m.Save(); err != nil {
		t.Fatal(err)
	}

	// Directory should now exist
	if _, err := os.Stat(storePath); err != nil {
		t.Errorf("Save should create directory: %v", err)
	}
}

func TestManifestSaveAndReloadPreservesAllFields(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	m := &Manifest{Pools: []Pool{
		{
			ID:        "claude-1",
			Label:     "Main",
			ConfigDir: "/home/user/.stoke/pools/claude-1",
			Provider:  "claude",
			AccountID: "alice@example.com",
			APIKey:    "sk-my-key",
			BaseURL:   "http://localhost:4000",
		},
	}}
	m.Save()

	m2, _ := LoadManifest()
	p := m2.Pools[0]
	if p.ID != "claude-1" {
		t.Errorf("ID=%q", p.ID)
	}
	if p.Label != "Main" {
		t.Errorf("Label=%q", p.Label)
	}
	if p.ConfigDir != "/home/user/.stoke/pools/claude-1" {
		t.Errorf("ConfigDir=%q", p.ConfigDir)
	}
	if p.Provider != "claude" {
		t.Errorf("Provider=%q", p.Provider)
	}
	if p.AccountID != "alice@example.com" {
		t.Errorf("AccountID=%q", p.AccountID)
	}
	if p.APIKey != "sk-my-key" {
		t.Errorf("APIKey=%q", p.APIKey)
	}
	if p.BaseURL != "http://localhost:4000" {
		t.Errorf("BaseURL=%q", p.BaseURL)
	}
}

func TestManifestEmptyPoolList(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	m := &Manifest{Pools: []Pool{}}
	m.Save()

	m2, err := LoadManifest()
	if err != nil {
		t.Fatal(err)
	}
	if len(m2.Pools) != 0 {
		t.Errorf("empty pool list not preserved: got %d", len(m2.Pools))
	}
}

// ---------------------------------------------------------------------------
// readAccountID edge cases
// ---------------------------------------------------------------------------

func TestReadAccountIDInvalidJSON(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, ".credentials.json"), []byte("not json"), 0600)

	result := readAccountID(dir)
	if result != "" {
		t.Errorf("readAccountID(invalid json)=%q, want empty", result)
	}
}

func TestReadAccountIDEmptyOAuth(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, ".credentials.json"), data, 0600)

	result := readAccountID(dir)
	if result != "" {
		t.Errorf("readAccountID(empty oauth)=%q, want empty", result)
	}
}

func TestReadAccountIDNoOAuthKey(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{
		"someOtherField": "value",
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, ".credentials.json"), data, 0600)

	result := readAccountID(dir)
	if result != "" {
		t.Errorf("readAccountID(no oauth)=%q, want empty", result)
	}
}

func TestReadAccountIDPrefersEmailOverAccountId(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{
			"email":     "user@example.com",
			"accountId": "acct-123",
		},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, ".credentials.json"), data, 0600)

	result := readAccountID(dir)
	if result != "user@example.com" {
		t.Errorf("readAccountID should prefer email: got %q", result)
	}
}

// ---------------------------------------------------------------------------
// readToken edge cases
// ---------------------------------------------------------------------------

func TestReadTokenInvalidJSON(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, ".credentials.json"), []byte("broken"), 0600)

	result := readToken(dir)
	if result != "" {
		t.Errorf("readToken(invalid json)=%q, want empty", result)
	}
}

func TestReadTokenNoAccessToken(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{
			"email": "user@example.com",
		},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, ".credentials.json"), data, 0600)

	result := readToken(dir)
	if result != "" {
		t.Errorf("readToken(no accessToken)=%q, want empty", result)
	}
}

// ---------------------------------------------------------------------------
// readCodexAccountID edge cases
// ---------------------------------------------------------------------------

func TestReadCodexAccountIDInvalidJSON(t *testing.T) {
	dir := t.TempDir()
	// Use the first filename that readCodexAccountID checks
	os.WriteFile(filepath.Join(dir, ".codex-credentials.json"), []byte("{{bad"), 0600)

	result := readCodexAccountID(dir)
	if result != "" {
		t.Errorf("readCodexAccountID(invalid json)=%q, want empty", result)
	}
}

func TestReadCodexAccountIDAccountIdField(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{
		"accountId": "codex-acct-42",
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, "credentials.json"), data, 0600)

	result := readCodexAccountID(dir)
	if result != "codex-acct-42" {
		t.Errorf("readCodexAccountID()=%q, want codex-acct-42", result)
	}
}

func TestReadCodexAccountIDAccountUnderscoreIdField(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{
		"account_id": "codex-acct-99",
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, "auth.json"), data, 0600)

	result := readCodexAccountID(dir)
	if result != "codex-acct-99" {
		t.Errorf("readCodexAccountID()=%q, want codex-acct-99", result)
	}
}

func TestReadCodexAccountIDUserIdField(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{
		"user_id": "user-007",
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, "credentials.json"), data, 0600)

	result := readCodexAccountID(dir)
	if result != "user-007" {
		t.Errorf("readCodexAccountID()=%q, want user-007", result)
	}
}

func TestReadCodexAccountIDAccessTokenFallback(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{
		"accessToken": "codex-tok-secret",
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, "credentials.json"), data, 0600)

	result := readCodexAccountID(dir)
	if result == "" || result == "codex-tok-secret" {
		t.Errorf("readCodexAccountID()=%q -- should be hashed, not empty or raw", result)
	}
	if !strings.HasPrefix(result, "codex-tok-") {
		t.Errorf("readCodexAccountID()=%q, should have codex-tok- prefix", result)
	}
}

func TestReadCodexAccountIDAccessTokenField(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{
		"access_token": "at-secret",
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, ".codex-credentials.json"), data, 0600)

	result := readCodexAccountID(dir)
	if result == "" || result == "at-secret" {
		t.Errorf("readCodexAccountID()=%q -- should be hashed", result)
	}
}

func TestReadCodexAccountIDTokenField(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{
		"token": "plain-token",
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, "credentials.json"), data, 0600)

	result := readCodexAccountID(dir)
	if result == "" || result == "plain-token" {
		t.Errorf("readCodexAccountID()=%q -- should be hashed", result)
	}
}

func TestReadCodexAccountIDEmptyCreds(t *testing.T) {
	dir := t.TempDir()
	creds := map[string]interface{}{}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, "credentials.json"), data, 0600)

	result := readCodexAccountID(dir)
	if result != "" {
		t.Errorf("readCodexAccountID(empty)=%q, want empty", result)
	}
}

func TestReadCodexAccountIDChecksMultipleFiles(t *testing.T) {
	dir := t.TempDir()
	// Only write to auth.json (the third filename checked)
	creds := map[string]interface{}{
		"email": "auth-file@example.com",
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(filepath.Join(dir, "auth.json"), data, 0600)

	result := readCodexAccountID(dir)
	if result != "auth-file@example.com" {
		t.Errorf("readCodexAccountID()=%q, want auth-file@example.com", result)
	}
}

// ---------------------------------------------------------------------------
// copyCredentials error paths
// ---------------------------------------------------------------------------

func TestCopyCredentialsSrcNotExist(t *testing.T) {
	dst := t.TempDir()
	err := copyCredentials("/nonexistent/src/dir", dst)
	if err == nil {
		t.Error("expected error when source dir does not exist")
	}
}

func TestCopyCredentialsEmptySrc(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()

	// Empty source dir should succeed with no files copied
	err := copyCredentials(src, dst)
	if err != nil {
		t.Errorf("copyCredentials(empty src) should succeed: %v", err)
	}
}

func TestCopyCredentialsFileContentsMatch(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()

	content := []byte(`{"token":"secret-value-123"}`)
	os.WriteFile(filepath.Join(src, "creds.json"), content, 0600)

	if err := copyCredentials(src, dst); err != nil {
		t.Fatal(err)
	}

	got, err := os.ReadFile(filepath.Join(dst, "creds.json"))
	if err != nil {
		t.Fatal(err)
	}
	if string(got) != string(content) {
		t.Errorf("content mismatch: got %q", string(got))
	}
}

// ---------------------------------------------------------------------------
// Manifest filter helpers with empty/nil pools
// ---------------------------------------------------------------------------

func TestClaudeDirsEmpty(t *testing.T) {
	m := &Manifest{}
	dirs := m.ClaudeDirs()
	if len(dirs) != 0 {
		t.Errorf("ClaudeDirs() on empty manifest: got %v", dirs)
	}
}

func TestCodexDirsEmpty(t *testing.T) {
	m := &Manifest{}
	dirs := m.CodexDirs()
	if len(dirs) != 0 {
		t.Errorf("CodexDirs() on empty manifest: got %v", dirs)
	}
}

func TestClaudeDirsNoClaudePools(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "codex-1", Provider: "codex", ConfigDir: "/cfg/1"},
		{ID: "codex-2", Provider: "codex", ConfigDir: "/cfg/2"},
	}}
	dirs := m.ClaudeDirs()
	if len(dirs) != 0 {
		t.Errorf("ClaudeDirs() with only codex pools: got %v", dirs)
	}
}

func TestCodexDirsNoCodexPools(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "claude-1", Provider: "claude", ConfigDir: "/cfg/1"},
	}}
	dirs := m.CodexDirs()
	if len(dirs) != 0 {
		t.Errorf("CodexDirs() with only claude pools: got %v", dirs)
	}
}

// ---------------------------------------------------------------------------
// NextID edge cases
// ---------------------------------------------------------------------------

func TestNextIDWithGaps(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "claude-1"},
		{ID: "claude-5"},
		{ID: "claude-3"},
	}}
	id := m.NextID("claude")
	// Should be max+1 = 6, not fill gaps
	if id != "claude-6" {
		t.Errorf("NextID with gaps=%q, want claude-6", id)
	}
}

func TestNextIDMixedProviders(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "claude-10"},
		{ID: "codex-3"},
		{ID: "claude-7"},
	}}
	claudeID := m.NextID("claude")
	codexID := m.NextID("codex")
	if claudeID != "claude-11" {
		t.Errorf("NextID(claude)=%q, want claude-11", claudeID)
	}
	if codexID != "codex-4" {
		t.Errorf("NextID(codex)=%q, want codex-4", codexID)
	}
}

// ---------------------------------------------------------------------------
// FindByAccount edge cases
// ---------------------------------------------------------------------------

func TestFindByAccountEmptyManifest(t *testing.T) {
	m := &Manifest{}
	p := m.FindByAccount("anything")
	if p != nil {
		t.Errorf("FindByAccount on empty manifest should return nil")
	}
}

func TestFindByAccountMutatesThroughPointer(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "c1", AccountID: "acct-1", Label: "Original"},
	}}
	p := m.FindByAccount("acct-1")
	if p == nil {
		t.Fatal("expected pool")
	}
	// Modifying through the returned pointer should affect the manifest
	p.Label = "Modified"
	if m.Pools[0].Label != "Modified" {
		t.Error("FindByAccount should return pointer into manifest slice")
	}
}

// ---------------------------------------------------------------------------
// StorePath / ManifestPath
// ---------------------------------------------------------------------------

func TestStorePathUsesHome(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	sp := StorePath()
	if !strings.HasPrefix(sp, tmp) {
		t.Errorf("StorePath()=%q, should start with HOME=%q", sp, tmp)
	}
	if !strings.HasSuffix(sp, filepath.Join(".stoke", "pools")) {
		t.Errorf("StorePath()=%q, should end with .stoke/pools", sp)
	}
}

func TestManifestPathDerived(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	mp := ManifestPath()
	want := filepath.Join(tmp, ".stoke", "pools", "manifest.json")
	if mp != want {
		t.Errorf("ManifestPath()=%q, want %q", mp, want)
	}
}

// ---------------------------------------------------------------------------
// Save overwrites existing manifest (not append)
// ---------------------------------------------------------------------------

func TestManifestSaveOverwrites(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	m1 := &Manifest{Pools: []Pool{
		{ID: "c1", AccountID: "a1"},
		{ID: "c2", AccountID: "a2"},
	}}
	m1.Save()

	// Save a smaller manifest -- should overwrite, not append
	m2 := &Manifest{Pools: []Pool{
		{ID: "c1", AccountID: "a1"},
	}}
	m2.Save()

	loaded, _ := LoadManifest()
	if len(loaded.Pools) != 1 {
		t.Errorf("Save should overwrite: got %d pools, want 1", len(loaded.Pools))
	}
}

// ---------------------------------------------------------------------------
// Pool JSON serialization
// ---------------------------------------------------------------------------

func TestPoolJSONOmitsEmptyOptionalFields(t *testing.T) {
	p := Pool{
		ID:        "claude-1",
		Label:     "Test",
		ConfigDir: "/cfg",
		Provider:  "claude",
		AccountID: "acct-1",
	}
	data, err := json.Marshal(p)
	if err != nil {
		t.Fatal(err)
	}
	s := string(data)
	if strings.Contains(s, "api_key") {
		t.Error("empty api_key should be omitted (omitempty)")
	}
	if strings.Contains(s, "base_url") {
		t.Error("empty base_url should be omitted (omitempty)")
	}
}

func TestPoolJSONIncludesOptionalFieldsWhenSet(t *testing.T) {
	p := Pool{
		ID:        "claude-1",
		Label:     "Test",
		ConfigDir: "/cfg",
		Provider:  "claude",
		AccountID: "acct-1",
		APIKey:    "sk-key",
		BaseURL:   "http://proxy",
	}
	data, err := json.Marshal(p)
	if err != nil {
		t.Fatal(err)
	}
	s := string(data)
	if !strings.Contains(s, "api_key") {
		t.Error("non-empty api_key should be included")
	}
	if !strings.Contains(s, "base_url") {
		t.Error("non-empty base_url should be included")
	}
}

// ---------------------------------------------------------------------------
// LoadManifest error paths
// ---------------------------------------------------------------------------

func TestLoadManifestOpenPermissionError(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	// Create the manifest file but make its parent directory non-readable
	store := filepath.Join(tmp, ".stoke", "pools")
	os.MkdirAll(store, 0755)
	mpath := filepath.Join(store, "manifest.json")
	os.WriteFile(mpath, []byte(`{"pools":[]}`), 0600)

	// Remove read permission from the file itself
	os.Chmod(mpath, 0000)
	defer os.Chmod(mpath, 0600) // restore so cleanup works

	_, err := LoadManifest()
	if err == nil {
		t.Error("expected permission error when manifest is unreadable")
	}
}

// ---------------------------------------------------------------------------
// Save error paths
// ---------------------------------------------------------------------------

func TestSaveFailsWhenDirUnwritable(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	// Create the .stoke dir but make it read-only so pools/ can't be created
	stokeDir := filepath.Join(tmp, ".stoke")
	os.MkdirAll(stokeDir, 0755)
	// Create a file at the pools path to block MkdirAll
	os.WriteFile(filepath.Join(stokeDir, "pools"), []byte("blocker"), 0444)

	m := &Manifest{Pools: []Pool{{ID: "test"}}}
	err := m.Save()
	if err == nil {
		t.Error("expected error when pools dir path is blocked by a file")
	}
}

// ---------------------------------------------------------------------------
// RemovePool with corrupt manifest
// ---------------------------------------------------------------------------

func TestRemovePoolWithCorruptManifest(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	store := filepath.Join(tmp, ".stoke", "pools")
	os.MkdirAll(store, 0755)
	os.WriteFile(filepath.Join(store, "manifest.json"), []byte("{corrupt"), 0600)

	err := RemovePool("c1")
	if err == nil {
		t.Error("expected error when manifest is corrupt")
	}
}

// ---------------------------------------------------------------------------
// AddAPIPool with corrupt manifest
// ---------------------------------------------------------------------------

func TestAddAPIPoolWithCorruptManifest(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	store := filepath.Join(tmp, ".stoke", "pools")
	os.MkdirAll(store, 0755)
	os.WriteFile(filepath.Join(store, "manifest.json"), []byte("not-json"), 0600)

	_, err := AddAPIPool("test", "key", "", "claude")
	if err == nil {
		t.Error("expected error when manifest is corrupt")
	}
}

// ---------------------------------------------------------------------------
// copyCredentials with unreadable source file
// ---------------------------------------------------------------------------

func TestCopyCredentialsUnreadableFile(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()

	// Create a file in src but make it unreadable
	f := filepath.Join(src, "secret.json")
	os.WriteFile(f, []byte("data"), 0600)
	os.Chmod(f, 0000)
	defer os.Chmod(f, 0600)

	err := copyCredentials(src, dst)
	if err == nil {
		t.Error("expected error when source file is unreadable")
	}
}

func TestCopyCredentialsUnwritableDst(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()

	os.WriteFile(filepath.Join(src, "creds.json"), []byte("data"), 0600)

	// Make destination read-only
	os.Chmod(dst, 0500)
	defer os.Chmod(dst, 0755)

	err := copyCredentials(src, dst)
	if err == nil {
		t.Error("expected error when destination is read-only")
	}
}

func TestCopyCredentialsDstNotExist(t *testing.T) {
	src := t.TempDir()
	os.WriteFile(filepath.Join(src, "creds.json"), []byte("data"), 0600)

	// Destination parent doesn't exist -- copyCredentials should create it
	dst := filepath.Join(t.TempDir(), "new", "subdir")
	err := copyCredentials(src, dst)
	if err != nil {
		t.Errorf("copyCredentials should create dst dir: %v", err)
	}

	got, err := os.ReadFile(filepath.Join(dst, "creds.json"))
	if err != nil {
		t.Fatal(err)
	}
	if string(got) != "data" {
		t.Errorf("content=%q", string(got))
	}
}
