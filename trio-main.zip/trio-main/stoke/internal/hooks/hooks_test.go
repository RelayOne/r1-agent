package hooks

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestInstallCreatesHookFiles(t *testing.T) {
	dir := t.TempDir()
	if err := Install(dir); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"pre-tool-use.sh", "post-tool-use.sh", "stop.sh", "session-start.sh", "session-end.sh", "post-tool-failure.sh", "pre-compact.sh"} {
		path := filepath.Join(dir, "hooks", name)
		info, err := os.Stat(path)
		if err != nil {
			t.Fatalf("hook %s missing: %v", name, err)
		}
		if info.Mode()&0111 == 0 {
			t.Errorf("hook %s not executable", name)
		}
	}
}

func TestHooksConfig(t *testing.T) {
	cfg := HooksConfig("/tmp/runtime")
	hooks, ok := cfg["hooks"].(map[string]interface{})
	if !ok {
		t.Fatal("no hooks key")
	}
	pre, ok := hooks["PreToolUse"]
	if !ok {
		t.Fatal("no PreToolUse")
	}
	arr, ok := pre.([]map[string]interface{})
	if !ok || len(arr) == 0 {
		t.Fatal("PreToolUse should have entries")
	}
	if arr[0]["type"] != "command" {
		t.Error("hook type should be command")
	}
}

func TestCleanup(t *testing.T) {
	dir := t.TempDir()
	Install(dir)
	Cleanup(dir)
	_, err := os.Stat(filepath.Join(dir, "hooks"))
	if !os.IsNotExist(err) {
		t.Error("hooks dir should be removed")
	}
}

// --- ParseHookOutput tests ---

func TestParseHookOutputAllow(t *testing.T) {
	d := ParseHookOutput(`{"decision":"allow"}`, 0)
	if d.Decision != "allow" {
		t.Errorf("expected decision=allow, got %q", d.Decision)
	}
}

func TestParseHookOutputBlock(t *testing.T) {
	d := ParseHookOutput(`{"decision":"block","reason":"bad tool"}`, 2)
	if d.Decision != "block" {
		t.Errorf("expected decision=block, got %q", d.Decision)
	}
	if d.Reason != "bad tool" {
		t.Errorf("expected reason='bad tool', got %q", d.Reason)
	}
}

func TestParseHookOutputWarn(t *testing.T) {
	d := ParseHookOutput("something went wrong", 1)
	if d.Decision != "warn" {
		t.Errorf("expected decision=warn, got %q", d.Decision)
	}
	if !strings.Contains(d.Output, "something went wrong") {
		t.Errorf("expected output to contain 'something went wrong', got %q", d.Output)
	}
}

func TestParseHookOutputAllowNoJSON(t *testing.T) {
	d := ParseHookOutput("all good here", 0)
	if d.Decision != "allow" {
		t.Errorf("expected decision=allow for exit 0 with non-JSON, got %q", d.Decision)
	}
}

func TestParseHookOutputBlockNoJSON(t *testing.T) {
	d := ParseHookOutput("blocked for reasons", 2)
	if d.Decision != "block" {
		t.Errorf("expected decision=block for exit 2 with non-JSON, got %q", d.Decision)
	}
}

func TestParseHookOutputModify(t *testing.T) {
	stdout := `{"decision":"modify","tool_input":"{\"file_path\":\"/tmp/safe.txt\"}"}`
	d := ParseHookOutput(stdout, 0)
	if d.Decision != "modify" {
		t.Errorf("expected decision=modify, got %q", d.Decision)
	}
	if d.ModifiedInput != `{"file_path":"/tmp/safe.txt"}` {
		t.Errorf("expected ModifiedInput to be rewritten JSON, got %q", d.ModifiedInput)
	}
}

func TestParseHookOutputModifyNoInput(t *testing.T) {
	stdout := `{"decision":"modify"}`
	d := ParseHookOutput(stdout, 0)
	if d.Decision != "block" {
		t.Errorf("expected decision=block (fail-safe) when tool_input missing, got %q", d.Decision)
	}
}

func TestParseHookOutputModifyInvalidJSON(t *testing.T) {
	stdout := `{"decision":"modify","tool_input":"not valid json {{"}`
	d := ParseHookOutput(stdout, 0)
	if d.Decision != "block" {
		t.Errorf("expected decision=block (fail-safe) when tool_input is invalid JSON, got %q", d.Decision)
	}
}

// --- RunHook tests ---

// writeScript creates an executable temp script and returns its path.
func writeScript(t *testing.T, content string) string {
	t.Helper()
	dir := t.TempDir()
	path := filepath.Join(dir, "hook.sh")
	if err := os.WriteFile(path, []byte(content), 0755); err != nil {
		t.Fatal(err)
	}
	return path
}

func TestRunHookSuccess(t *testing.T) {
	script := writeScript(t, "#!/bin/bash\necho ok\nexit 0\n")
	out, err := RunHook(script, nil, 5*time.Second, "test-success")
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if !strings.Contains(out, "ok") {
		t.Errorf("expected output to contain 'ok', got %q", out)
	}
}

func TestRunHookTimeout(t *testing.T) {
	// Use exec so bash replaces itself with sleep; the context kill
	// reaches the sleep process directly instead of orphaning it.
	script := writeScript(t, "#!/bin/bash\nexec sleep 60\n")
	_, err := RunHook(script, nil, 1*time.Second, "test-timeout")
	if err == nil {
		t.Fatal("expected error for timed-out hook, got nil")
	}
	errMsg := err.Error()
	if !strings.Contains(errMsg, "timed out") && !strings.Contains(errMsg, "deadline") && !strings.Contains(errMsg, "killed") {
		t.Errorf("expected timeout-related error, got %q", errMsg)
	}
}

func TestRunHookBlockExit(t *testing.T) {
	script := writeScript(t, "#!/bin/bash\necho 'hook blocked this'\nexit 2\n")
	out, err := RunHook(script, nil, 5*time.Second, "test-block")
	if err == nil {
		t.Fatal("expected error for exit 2, got nil")
	}
	if !strings.Contains(out, "hook blocked this") {
		t.Errorf("expected stdout to contain 'hook blocked this', got %q", out)
	}
}

// --- HooksConfig completeness test ---

func TestHooksConfigIncludesAllEvents(t *testing.T) {
	cfg := HooksConfig("/tmp/test-runtime")
	hooks, ok := cfg["hooks"].(map[string]interface{})
	if !ok {
		t.Fatal("no hooks key in config")
	}
	expected := []string{
		"PreToolUse",
		"PostToolUse",
		"Stop",
		"SessionStart",
		"SessionEnd",
		"PostToolUseFailure",
		"PreCompact",
	}
	for _, key := range expected {
		if _, ok := hooks[key]; !ok {
			t.Errorf("HooksConfig missing expected event key %q", key)
		}
	}
	if len(hooks) != len(expected) {
		t.Errorf("expected %d hook events, got %d", len(expected), len(hooks))
	}
}

// --- InstallInRepo tests ---

func TestInstallInRepo(t *testing.T) {
	dir := t.TempDir()
	if err := InstallInRepo(dir); err != nil {
		t.Fatal(err)
	}
	hookDir := filepath.Join(dir, ".stoke", "hooks")
	for _, name := range []string{"pre-tool-use.sh", "post-tool-use.sh", "stop.sh", "session-start.sh", "session-end.sh", "post-tool-failure.sh", "pre-compact.sh"} {
		path := filepath.Join(hookDir, name)
		info, err := os.Stat(path)
		if err != nil {
			t.Fatalf("hook %s missing in .stoke/hooks/: %v", name, err)
		}
		if info.Mode()&0111 == 0 {
			t.Errorf("hook %s not executable", name)
		}
	}
}

// --- GenerateSettings tests ---

func TestGenerateSettingsYolo(t *testing.T) {
	dir := t.TempDir()
	// Install hooks first so the hook dir exists
	if err := InstallInRepo(dir); err != nil {
		t.Fatal(err)
	}
	path, err := GenerateSettings(dir, "yolo", "")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(path); err != nil {
		t.Fatalf("settings file does not exist: %v", err)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	content := string(data)
	// Yolo mode should allow Write, Edit, and Bash
	for _, tool := range []string{"Write", "Edit", "Bash"} {
		if !strings.Contains(content, tool) {
			t.Errorf("yolo settings should contain %q in allow list", tool)
		}
	}
}

func TestGenerateSettingsScope(t *testing.T) {
	dir := t.TempDir()
	if err := InstallInRepo(dir); err != nil {
		t.Fatal(err)
	}
	path, err := GenerateSettings(dir, "scope", "plan.json")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(path); err != nil {
		t.Fatalf("settings file does not exist: %v", err)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	content := string(data)
	// Scope mode: Write is allowed (for plan output)
	if !strings.Contains(content, "Write") {
		t.Error("scope settings should allow Write")
	}
	// Scope mode: Edit and Bash should be denied
	if !strings.Contains(content, `"deny"`) {
		t.Error("scope settings should have a deny list")
	}
	// Check Edit appears in deny context (it's in the deny array)
	if !strings.Contains(content, "Edit") {
		t.Error("scope settings should mention Edit (in deny)")
	}
	if !strings.Contains(content, "Bash") {
		t.Error("scope settings should mention Bash (in deny)")
	}
}

// --- GenerateCLAUDEmd tests ---

func TestGenerateCLAUDEmd(t *testing.T) {
	dir := t.TempDir()
	if err := GenerateCLAUDEmd(dir, "yolo", ""); err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(filepath.Join(dir, "CLAUDE.md"))
	if err != nil {
		t.Fatal(err)
	}
	content := string(data)
	if !strings.Contains(content, "Non-negotiable") {
		t.Error("CLAUDE.md should contain 'Non-negotiable' rules")
	}
	if !strings.Contains(content, "Do NOT") {
		t.Error("CLAUDE.md should contain 'Do NOT' rules")
	}
}

func TestGenerateCLAUDEmdScope(t *testing.T) {
	dir := t.TempDir()
	if err := GenerateCLAUDEmd(dir, "scope", "stoke-plan.json"); err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(filepath.Join(dir, "CLAUDE.md"))
	if err != nil {
		t.Fatal(err)
	}
	content := string(data)
	if !strings.Contains(content, "SCOPE mode") {
		t.Error("scope CLAUDE.md should contain 'SCOPE mode'")
	}
	if !strings.Contains(content, "stoke-plan.json") {
		t.Error("scope CLAUDE.md should mention the plan output file")
	}
}

// --- safeWrite symlink rejection ---

func TestSafeWriteRejectsSymlink(t *testing.T) {
	dir := t.TempDir()
	// Create a symlink inside the temp dir
	target := filepath.Join(dir, "real-file.txt")
	os.WriteFile(target, []byte("real"), 0644)
	link := filepath.Join(dir, "link-file.txt")
	if err := os.Symlink(target, link); err != nil {
		t.Skipf("symlink not supported: %v", err)
	}
	// safeWrite should reject writing to a path where any component is a symlink
	err := safeWrite(link, []byte("malicious"), 0644)
	if err == nil {
		t.Error("safeWrite should reject symlink target")
	}
	if err != nil && !strings.Contains(err.Error(), "symlink rejected") {
		t.Errorf("expected 'symlink rejected' error, got: %v", err)
	}
}

// --- Cleanup after Install ---

func TestCleanupRemovesHooksDir(t *testing.T) {
	dir := t.TempDir()
	if err := Install(dir); err != nil {
		t.Fatal(err)
	}
	// Verify hooks directory exists before cleanup
	hookDir := filepath.Join(dir, "hooks")
	if _, err := os.Stat(hookDir); err != nil {
		t.Fatal("hooks dir should exist after Install")
	}
	Cleanup(dir)
	if _, err := os.Stat(hookDir); !os.IsNotExist(err) {
		t.Error("hooks dir should be removed after Cleanup")
	}
}
