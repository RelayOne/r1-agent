// Package app is the top-level orchestrator that wires together configuration,
// execution engines, worktrees, verification, and event handling to drive
// autonomous coding tasks from plan through merge.
package app

import (
	"context"
	"fmt"
	"log"
	"os/exec"
	"path/filepath"
	"strings"

	"github.com/ericmacdougall/stoke/internal/config"
	"github.com/ericmacdougall/stoke/internal/consent"
	"github.com/ericmacdougall/stoke/internal/critic"
	"github.com/ericmacdougall/stoke/internal/engine"
	"github.com/ericmacdougall/stoke/internal/flowtrack"
	"github.com/ericmacdougall/stoke/internal/logging"
	"github.com/ericmacdougall/stoke/internal/memory"
	"github.com/ericmacdougall/stoke/internal/microcompact"
	"github.com/ericmacdougall/stoke/internal/model"
	"github.com/ericmacdougall/stoke/internal/promptcache"
	"github.com/ericmacdougall/stoke/internal/rbac"
	"github.com/ericmacdougall/stoke/internal/sandguard"
	"github.com/ericmacdougall/stoke/internal/subscriptions"
	"github.com/ericmacdougall/stoke/internal/taskstate"
	"github.com/ericmacdougall/stoke/internal/verify"
	"github.com/ericmacdougall/stoke/internal/workflow"
	"github.com/ericmacdougall/stoke/internal/worktree"
)

type AuthMode string

const (
	// AuthModeSubscription uses subscription pool credentials.
	AuthModeSubscription AuthMode = "mode1"

	// AuthModeAPIKey uses the caller's own API key.
	AuthModeAPIKey AuthMode = "mode2"
)

type RunConfig struct {
	RepoRoot         string
	PolicyPath       string
	Task             string
	TaskType         string
	TaskVerification []string // per-task verification checklist from planner
	WorktreeName     string
	AllowedFiles     []string
	DryRun           bool
	AuthMode         AuthMode
	ClaudeBinary     string
	CodexBinary      string
	ClaudeConfigDir  string
	CodexHome        string
	Pools            *subscriptions.Manager
	Worktrees        *worktree.Manager
	State            *taskstate.TaskState
	PlanOnly         bool
	BuildCommand     string
	TestCommand      string
	LintCommand      string
	OnEvent          engine.OnEventFunc
}

type Orchestrator struct {
	cfg      RunConfig
	policy   config.Policy
	guard    *sandguard.Guard
	consent  *consent.Workflow
	rbac     *rbac.Policy
}

func New(cfg RunConfig) (*Orchestrator, error) {
	// Initialize structured logging early so all subsequent log calls use it.
	logging.Init("info", nil)
	logger := logging.Component("app")

	if cfg.State == nil {
		return nil, fmt.Errorf("task state is required (anti-deception: no legacy mode)")
	}
	if cfg.AuthMode == "" {
		cfg.AuthMode = AuthModeSubscription
	}
	policy, err := config.LoadPolicy(cfg.PolicyPath)
	if err != nil {
		return nil, err
	}
	// Validate policy structure
	for _, ve := range config.ValidatePolicy(policy) {
		if ve.Fatal {
			return nil, fmt.Errorf("policy error: %s", ve)
		}
	}
	// Initialize sandguard with default strict config, scoped to repo root.
	sgCfg := sandguard.DefaultConfig()
	if cfg.RepoRoot != "" {
		sgCfg.AllowedPaths = []string{cfg.RepoRoot}
	}
	guard := sandguard.NewGuard(sgCfg)

	containerInfo := config.DetectContainerEnvironment()
	if containerInfo.IsContainer {
		log.Printf("[stoke] sandbox: container detected (runtime=%s)", containerInfo.Runtime)
	}
	log.Printf("[stoke] sandguard: initialized (allowed_paths=%v, allow_network=%v, allow_exec=%v)",
		sgCfg.AllowedPaths, sgCfg.AllowNetwork, sgCfg.AllowExec)

	// Initialize consent workflow for human-in-the-loop approval of dangerous operations.
	consentWf := consent.NewWorkflow(nil)
	logger.Info("consent workflow initialized", "classifiers", len(consent.DefaultClassifiers()))

	// Initialize RBAC policy with admin default (single-user default: full access).
	rbacPolicy := rbac.NewPolicy("admin")
	logger.Info("rbac policy initialized", "default_role", "admin")

	return &Orchestrator{cfg: cfg, policy: policy, guard: guard, consent: consentWf, rbac: rbacPolicy}, nil
}

func DefaultPolicyYAML() string {
	return config.DefaultPolicyYAML()
}

func (o *Orchestrator) Run(ctx context.Context) (workflow.Result, error) {
	// Auto-detect commands if not specified
	buildCmd, testCmd, lintCmd := o.cfg.BuildCommand, o.cfg.TestCommand, o.cfg.LintCommand
	if buildCmd == "" || testCmd == "" || lintCmd == "" {
		detected := config.DetectCommands(o.cfg.RepoRoot)
		if buildCmd == "" {
			buildCmd = detected.Build
		}
		if testCmd == "" {
			testCmd = detected.Test
		}
		if lintCmd == "" {
			lintCmd = detected.Lint
		}
	}

	verifier := verify.NewPipeline(buildCmd, testCmd, lintCmd)

	// Use shared worktree manager if provided (critical for parallel builds:
	// the merge mutex must be shared across all tasks in a build session).
	// If not provided, create a per-task manager (fine for single-task `stoke run`).
	worktrees := o.cfg.Worktrees
	if worktrees == nil {
		worktrees = worktree.NewManager(o.cfg.RepoRoot)
	}

	// Use provided pool manager (multi-pool) or create default single-pool
	pools := o.cfg.Pools
	if pools == nil {
		pools = subscriptions.NewManager([]subscriptions.Pool{
			{ID: "claude-1", Provider: subscriptions.ProviderClaude, ConfigDir: o.cfg.ClaudeConfigDir},
			{ID: "codex-1", Provider: subscriptions.ProviderCodex, ConfigDir: o.cfg.CodexHome},
		})
	}

	runners := engine.Registry{
		Claude: engine.NewClaudeRunner(o.cfg.ClaudeBinary),
		Codex:  engine.NewCodexRunner(o.cfg.CodexBinary),
	}

	taskType := model.InferTaskType(o.cfg.Task)
	if strings.TrimSpace(o.cfg.TaskType) != "" {
		taskType = model.TaskType(strings.ToLower(strings.TrimSpace(o.cfg.TaskType)))
	}

	// Initialize optional convergence subsystems
	stokeDir := filepath.Join(o.cfg.RepoRoot, ".stoke")
	memStore, memErr := memory.NewStore(memory.Config{Path: filepath.Join(stokeDir, "memory", "store.json")})
	if memErr != nil {
		log.Printf("[stoke] memory store init failed (non-fatal): %v", memErr)
	}
	crit := critic.New(critic.Config{})
	ft := flowtrack.NewTracker(flowtrack.Config{})
	po := promptcache.New()
	comp := microcompact.NewCompactor(microcompact.Config{})

	wf := workflow.Engine{
		RepoRoot:         o.cfg.RepoRoot,
		Task:             o.cfg.Task,
		TaskType:         taskType,
		TaskVerification: o.cfg.TaskVerification,
		WorktreeName:     o.cfg.WorktreeName,
		AllowedFiles:     o.cfg.AllowedFiles,
		AuthMode:         engine.AuthMode(o.cfg.AuthMode),
		Policy:           o.policy,
		DryRun:           o.cfg.DryRun,
		Pools:            pools,
		Worktrees:        worktrees,
		Runners:          runners,
		Verifier:         verifier,
		ClaudeConfigDir:  o.cfg.ClaudeConfigDir,
		CodexHome:        o.cfg.CodexHome,
		OnEvent:          o.cfg.OnEvent,
		State:            o.cfg.State,
		PlanOnly:         o.cfg.PlanOnly,
		Critic:           crit,
		Memory:           memStore,
		FlowTracker:      ft,
		PromptOptimizer:  po,
		Compactor:        comp,
	}
	return wf.Run(ctx)
}

func Doctor(claudeBin, codexBin string) string {
	var b strings.Builder
	check := func(label, bin string) {
		if path, err := exec.LookPath(bin); err == nil {
			fmt.Fprintf(&b, "[ok] %s: %s\n", label, path)
		} else {
			fmt.Fprintf(&b, "[missing] %s: %v\n", label, err)
		}
	}
	check("claude", claudeBin)
	check("codex", codexBin)
	return b.String()
}
