package app

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"github.com/ericmacdougall/stoke/internal/taskstate"
)

func TestNewWithDefaultPolicy(t *testing.T) {
	o, err := New(RunConfig{
		RepoRoot: t.TempDir(),
		Task:     "test task",
		AuthMode: AuthModeSubscription,
		State:    taskstate.NewTaskState("test"),
	})
	if err != nil {
		t.Fatal(err)
	}
	if o == nil {
		t.Fatal("expected non-nil orchestrator")
	}
	if len(o.policy.Phases) != 3 {
		t.Errorf("phases=%d, want 3", len(o.policy.Phases))
	}
}

func TestNewWithCustomPolicy(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "custom.yaml"), []byte(`
phases:
  plan:
    builtin_tools: [Read]
    mcp_enabled: false
verification:
  build: required
  tests: required
  lint: optional
`), 0644)

	o, err := New(RunConfig{
		RepoRoot:   dir,
		PolicyPath: filepath.Join(dir, "custom.yaml"),
		Task:       "test",
		AuthMode:   AuthModeSubscription,
		State:      taskstate.NewTaskState("test"),
	})
	if err != nil {
		t.Fatal(err)
	}
	plan := o.policy.Phases["plan"]
	if len(plan.BuiltinTools) != 1 || plan.BuiltinTools[0] != "Read" {
		t.Errorf("plan tools=%v", plan.BuiltinTools)
	}
}

func TestNewDefaultsToMode1(t *testing.T) {
	o, err := New(RunConfig{
		RepoRoot: t.TempDir(),
		Task:     "test",
		State:    taskstate.NewTaskState("test"),
	})
	if err != nil {
		t.Fatal(err)
	}
	if o.cfg.AuthMode != AuthModeSubscription {
		t.Errorf("authMode=%q, want mode1", o.cfg.AuthMode)
	}
}

func TestNewRejectsNilState(t *testing.T) {
	_, err := New(RunConfig{
		RepoRoot: t.TempDir(),
		Task:     "test",
	})
	if err == nil {
		t.Fatal("MUST reject nil State -- no legacy mode allowed")
	}
	if !strings.Contains(err.Error(), "task state is required") {
		t.Errorf("unexpected error message: %s", err.Error())
	}
}

func TestDoctor(t *testing.T) {
	result := Doctor("nonexistent-claude", "nonexistent-codex")
	if result == "" {
		t.Error("Doctor should produce output")
	}
}

// --- New tests below ---

func TestNewOrchestratorFields(t *testing.T) {
	dir := t.TempDir()
	o, err := New(RunConfig{
		RepoRoot: dir,
		Task:     "implement feature X",
		AuthMode: AuthModeAPIKey,
		State:    taskstate.NewTaskState("t1"),
	})
	if err != nil {
		t.Fatal(err)
	}
	if o.guard == nil {
		t.Error("sandguard should be initialized")
	}
	if o.consent == nil {
		t.Error("consent workflow should be initialized")
	}
	if o.rbac == nil {
		t.Error("RBAC policy should be initialized")
	}
	if o.cfg.RepoRoot != dir {
		t.Errorf("RepoRoot=%q, want %q", o.cfg.RepoRoot, dir)
	}
	if o.cfg.AuthMode != AuthModeAPIKey {
		t.Errorf("AuthMode=%q, want mode2", o.cfg.AuthMode)
	}
}

func TestNewWithInvalidPolicyPath(t *testing.T) {
	_, err := New(RunConfig{
		RepoRoot:   t.TempDir(),
		PolicyPath: "/nonexistent/path/policy.yaml",
		Task:       "test",
		State:      taskstate.NewTaskState("test"),
	})
	if err == nil {
		t.Fatal("should error on invalid policy path")
	}
}

func TestNewWithMalformedPolicy(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "bad.yaml"), []byte(`
this is not valid yaml at all {{{
  broken: [[[
`), 0644)

	_, err := New(RunConfig{
		RepoRoot:   dir,
		PolicyPath: filepath.Join(dir, "bad.yaml"),
		Task:       "test",
		State:      taskstate.NewTaskState("test"),
	})
	if err == nil {
		t.Fatal("should error on malformed policy")
	}
}

func TestNewSandguardScopedToRepoRoot(t *testing.T) {
	dir := t.TempDir()
	o, err := New(RunConfig{
		RepoRoot: dir,
		Task:     "test",
		State:    taskstate.NewTaskState("test"),
	})
	if err != nil {
		t.Fatal(err)
	}
	if o.guard == nil {
		t.Fatal("guard should not be nil")
	}
}

func TestNewWithEmptyRepoRoot(t *testing.T) {
	// Empty RepoRoot is allowed; sandguard just won't scope to a directory.
	o, err := New(RunConfig{
		Task:  "test",
		State: taskstate.NewTaskState("test"),
	})
	if err != nil {
		t.Fatal(err)
	}
	if o == nil {
		t.Fatal("orchestrator should still be created with empty RepoRoot")
	}
}

func TestDefaultPolicyYAML(t *testing.T) {
	yaml := DefaultPolicyYAML()
	if yaml == "" {
		t.Fatal("DefaultPolicyYAML should return non-empty YAML")
	}
	if !strings.Contains(yaml, "phases:") {
		t.Error("YAML should contain phases section")
	}
	if !strings.Contains(yaml, "plan:") {
		t.Error("YAML should contain plan phase")
	}
	if !strings.Contains(yaml, "execute:") {
		t.Error("YAML should contain execute phase")
	}
	if !strings.Contains(yaml, "verify:") {
		t.Error("YAML should contain verify phase")
	}
	if !strings.Contains(yaml, "verification:") {
		t.Error("YAML should contain verification section")
	}
	if !strings.Contains(yaml, "files:") {
		t.Error("YAML should contain files section")
	}
}

func TestDoctorWithMissingTools(t *testing.T) {
	result := Doctor("nonexistent-claude-tool-xyz", "nonexistent-codex-tool-xyz")
	if !strings.Contains(result, "[missing]") {
		t.Error("should report missing tools")
	}
	if !strings.Contains(result, "claude") {
		t.Error("should mention claude")
	}
	if !strings.Contains(result, "codex") {
		t.Error("should mention codex")
	}
}

func TestDoctorWithRealBinary(t *testing.T) {
	// "ls" exists on all systems -- use it to exercise the [ok] path.
	result := Doctor("ls", "nonexistent-codex-xyz")
	if !strings.Contains(result, "[ok]") {
		t.Error("should report found tool as [ok]")
	}
	if !strings.Contains(result, "[missing]") {
		t.Error("should report missing tool")
	}
}

func TestNewPolicyDefaultPhases(t *testing.T) {
	o, err := New(RunConfig{
		RepoRoot: t.TempDir(),
		Task:     "test",
		State:    taskstate.NewTaskState("test"),
	})
	if err != nil {
		t.Fatal(err)
	}
	for _, phase := range []string{"plan", "execute", "verify"} {
		if _, ok := o.policy.Phases[phase]; !ok {
			t.Errorf("missing default phase: %s", phase)
		}
	}
}

func TestNewPolicyVerificationDefaults(t *testing.T) {
	o, err := New(RunConfig{
		RepoRoot: t.TempDir(),
		Task:     "test",
		State:    taskstate.NewTaskState("test"),
	})
	if err != nil {
		t.Fatal(err)
	}
	v := o.policy.Verification
	if !v.Build {
		t.Error("Build verification should default to true")
	}
	if !v.Tests {
		t.Error("Tests verification should default to true")
	}
	if !v.Lint {
		t.Error("Lint verification should default to true")
	}
}

func TestAuthModeConstants(t *testing.T) {
	if AuthModeSubscription != "mode1" {
		t.Errorf("AuthModeSubscription=%q, want mode1", AuthModeSubscription)
	}
	if AuthModeAPIKey != "mode2" {
		t.Errorf("AuthModeAPIKey=%q, want mode2", AuthModeAPIKey)
	}
}

func TestNewPreservesRunConfigFields(t *testing.T) {
	dir := t.TempDir()
	state := taskstate.NewTaskState("task-42")
	cfg := RunConfig{
		RepoRoot:     dir,
		Task:         "implement auth",
		TaskType:     "feature",
		WorktreeName: "wt-42",
		AllowedFiles: []string{"src/auth.go"},
		DryRun:       true,
		AuthMode:     AuthModeAPIKey,
		State:        state,
		PlanOnly:     true,
		BuildCommand: "go build ./...",
		TestCommand:  "go test ./...",
		LintCommand:  "golangci-lint run",
	}
	o, err := New(cfg)
	if err != nil {
		t.Fatal(err)
	}
	if o.cfg.Task != "implement auth" {
		t.Errorf("Task=%q", o.cfg.Task)
	}
	if o.cfg.TaskType != "feature" {
		t.Errorf("TaskType=%q", o.cfg.TaskType)
	}
	if !o.cfg.DryRun {
		t.Error("DryRun should be true")
	}
	if !o.cfg.PlanOnly {
		t.Error("PlanOnly should be true")
	}
	if o.cfg.BuildCommand != "go build ./..." {
		t.Errorf("BuildCommand=%q", o.cfg.BuildCommand)
	}
	if len(o.cfg.AllowedFiles) != 1 || o.cfg.AllowedFiles[0] != "src/auth.go" {
		t.Errorf("AllowedFiles=%v", o.cfg.AllowedFiles)
	}
}

func TestNewWithFatalValidationError(t *testing.T) {
	// Create a policy that has a required phase missing (e.g. only "plan" defined,
	// missing "execute" and "verify"). The custom YAML parser only sets what's in the file,
	// and normalizePolicy fills in defaults. To trigger a fatal error, we need to produce
	// a policy with an empty Phases map, which requires a JSON policy approach.
	dir := t.TempDir()
	// JSON policy with only a "plan" phase and no execute/verify -- but normalizePolicy
	// fills in missing phases. So use ValidatePolicy indirectly by creating a policy
	// that has a phase with problematic tool config. The fatal path requires a missing
	// required phase, which only happens if we bypass normalization.
	// Instead, create a policy file that can't be parsed at all.
	if err := os.WriteFile(filepath.Join(dir, "fatal.yaml"), []byte(`
phases:
  plan:
    unknown_key: true
`), 0644); err != nil {
		t.Fatal(err)
	}

	_, err := New(RunConfig{
		RepoRoot:   dir,
		PolicyPath: filepath.Join(dir, "fatal.yaml"),
		Task:       "test",
		State:      taskstate.NewTaskState("test"),
	})
	if err == nil {
		t.Fatal("should error on policy with unknown key")
	}
}

func setupGitRepoForApp(t *testing.T) string {
	t.Helper()
	dir := t.TempDir()
	cmds := [][]string{
		{"git", "init"},
		{"git", "config", "user.email", "test@test.com"},
		{"git", "config", "user.name", "Test"},
	}
	for _, c := range cmds {
		cmd := exec.Command(c[0], c[1:]...)
		cmd.Dir = dir
		if err := cmd.Run(); err != nil {
			t.Fatalf("setup %v: %v", c, err)
		}
	}
	if err := os.WriteFile(filepath.Join(dir, "main.go"), []byte("package main\n"), 0644); err != nil {
		t.Fatal(err)
	}
	cmd := exec.Command("git", "add", ".")
	cmd.Dir = dir
	if err := cmd.Run(); err != nil {
		t.Fatal(err)
	}
	cmd = exec.Command("git", "commit", "-m", "init", "--no-gpg-sign")
	cmd.Dir = dir
	if err := cmd.Run(); err != nil {
		t.Fatal(err)
	}
	return dir
}

func TestRunDryRun(t *testing.T) {
	dir := setupGitRepoForApp(t)

	o, err := New(RunConfig{
		RepoRoot:     dir,
		Task:         "add unit tests",
		DryRun:       true,
		State:        taskstate.NewTaskState("dry-test"),
		BuildCommand: "echo build",
		TestCommand:  "echo test",
		LintCommand:  "echo lint",
	})
	if err != nil {
		t.Fatal(err)
	}

	result, err := o.Run(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if !result.DryRun {
		t.Error("result should be marked as dry run")
	}
}

func TestRunDryRunAutoDetect(t *testing.T) {
	dir := setupGitRepoForApp(t)

	// Write a go.mod so auto-detect picks up Go commands
	if err := os.WriteFile(filepath.Join(dir, "go.mod"), []byte("module test\ngo 1.21\n"), 0644); err != nil {
		t.Fatal(err)
	}

	o, err := New(RunConfig{
		RepoRoot: dir,
		Task:     "add tests",
		DryRun:   true,
		State:    taskstate.NewTaskState("detect-test"),
	})
	if err != nil {
		t.Fatal(err)
	}

	result, err := o.Run(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if !result.DryRun {
		t.Error("result should be marked as dry run")
	}
}

func TestRunDryRunWithExplicitTaskType(t *testing.T) {
	dir := setupGitRepoForApp(t)

	o, err := New(RunConfig{
		RepoRoot:     dir,
		Task:         "fix login bug",
		TaskType:     "bugfix",
		DryRun:       true,
		State:        taskstate.NewTaskState("type-test"),
		BuildCommand: "echo build",
		TestCommand:  "echo test",
		LintCommand:  "echo lint",
	})
	if err != nil {
		t.Fatal(err)
	}

	result, err := o.Run(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if result.TaskType != "bugfix" {
		t.Errorf("TaskType=%q, want bugfix", result.TaskType)
	}
}

func TestRunDryRunPartialAutoDetect(t *testing.T) {
	dir := setupGitRepoForApp(t)

	// Provide only BuildCommand, let the rest auto-detect
	o, err := New(RunConfig{
		RepoRoot:     dir,
		Task:         "refactor auth",
		DryRun:       true,
		State:        taskstate.NewTaskState("partial-test"),
		BuildCommand: "make build",
	})
	if err != nil {
		t.Fatal(err)
	}

	result, err := o.Run(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if !result.DryRun {
		t.Error("result should be marked as dry run")
	}
}
