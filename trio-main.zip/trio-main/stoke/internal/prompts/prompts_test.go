package prompts

import (
	"strings"
	"testing"
)

// TestExecutePromptDoesNotMentionCommit ensures the execute prompt
// does not tell the model to commit, push, or rebase.
// These operations are handled by the harness after review.
func TestExecutePromptDoesNotMentionCommit(t *testing.T) {
	prompt := BuildExecutePrompt("test task", "", "", "")
	lower := strings.ToLower(prompt)

	forbidden := []string{
		"git add -a",
		"git commit",
		"git push",
		"git rebase",
	}
	for _, f := range forbidden {
		if strings.Contains(lower, f) {
			t.Errorf("execute prompt contains forbidden instruction %q", f)
		}
	}
}

// TestVerifyPromptDoesNotMentionGitMutation ensures the verify prompt
// does not tell the reviewer to use git commands that verify policy forbids.
func TestVerifyPromptDoesNotMentionGitMutation(t *testing.T) {
	prompt := BuildVerifyPrompt("test task", []string{"check 1"})
	lower := strings.ToLower(prompt)

	forbidden := []string{
		"git diff head~1",
		"git add",
		"git commit",
		"git push",
		"git checkout",
		"git stash",
	}
	for _, f := range forbidden {
		if strings.Contains(lower, f) {
			t.Errorf("verify prompt contains forbidden git instruction %q", f)
		}
	}

	// Verify it tells the reviewer NOT to use git
	if !strings.Contains(lower, "do not") || !strings.Contains(lower, "git") {
		t.Error("verify prompt should explicitly tell reviewer not to use git commands")
	}
}

func TestBuildPlanPromptWithScope(t *testing.T) {
	prompt := BuildPlanPrompt("implement auth", true, "scope content here", "")
	if !strings.Contains(prompt, "validate it against the actual codebase") {
		t.Error("plan prompt with scope should contain 'validate it against the actual codebase'")
	}
	if !strings.Contains(prompt, "scope content here") {
		t.Error("plan prompt with scope should contain the scope content")
	}
	// Should NOT contain the no-scope text
	if strings.Contains(prompt, "No formal scope was provided") {
		t.Error("plan prompt with scope should not contain 'No formal scope was provided'")
	}
}

func TestBuildPlanPromptWithoutScope(t *testing.T) {
	prompt := BuildPlanPrompt("implement auth", false, "", "")
	if !strings.Contains(prompt, "No formal scope was provided") {
		t.Error("plan prompt without scope should contain 'No formal scope was provided'")
	}
	if !strings.Contains(prompt, "implement auth") {
		t.Error("plan prompt without scope should contain the task text")
	}
	// Should NOT contain the with-scope text
	if strings.Contains(prompt, "Validate it against the actual codebase") {
		t.Error("plan prompt without scope should not contain scope validation text")
	}
}

func TestBuildPlanPromptIntentVerbalization(t *testing.T) {
	prompt := BuildPlanPrompt("any task", false, "", "")
	if !strings.Contains(prompt, "SURFACE FORM") {
		t.Error("plan prompt should contain 'SURFACE FORM' for intent verbalization")
	}
	if !strings.Contains(prompt, "TRUE INTENT") {
		t.Error("plan prompt should contain 'TRUE INTENT' for intent verbalization")
	}
}

func TestBuildPlanPromptWithRepoMap(t *testing.T) {
	repoMap := "## internal/auth/auth.go\n  func Authenticate(token string)\n  type User\n"
	prompt := BuildPlanPrompt("add login", false, "", repoMap)
	if !strings.Contains(prompt, "Repository Structure") {
		t.Error("plan prompt with repoMap should contain 'Repository Structure' header")
	}
	if !strings.Contains(prompt, "func Authenticate") {
		t.Error("plan prompt with repoMap should contain the repo map content")
	}
}

func TestBuildPlanPromptEmptyRepoMap(t *testing.T) {
	prompt := BuildPlanPrompt("add login", false, "", "")
	if strings.Contains(prompt, "Repository Structure") {
		t.Error("plan prompt without repoMap should not contain 'Repository Structure' header")
	}
}

func TestBuildExecutePromptWithVerification(t *testing.T) {
	verification := "1. Check that /api/users returns 200\n2. Verify auth middleware is applied"
	prompt := BuildExecutePrompt("implement user API", verification, "", "")
	if !strings.Contains(prompt, "Check that /api/users returns 200") {
		t.Error("execute prompt should contain the verification checklist")
	}
	if !strings.Contains(prompt, "Verification checklist") {
		t.Error("execute prompt should include the verification section header")
	}
}

func TestBuildExecutePromptWithPriorContext(t *testing.T) {
	priorContext := "TASK-1 added the User model to models/user.go"
	prompt := BuildExecutePrompt("implement user API", "", priorContext, "")
	if !strings.Contains(prompt, priorContext) {
		t.Error("execute prompt should contain the prior context")
	}
	if !strings.Contains(prompt, "Context from prior tasks") {
		t.Error("execute prompt should include the prior context section header")
	}
}

func TestBuildExecutePromptReflection(t *testing.T) {
	prompt := BuildExecutePrompt("any task", "", "", "")
	if !strings.Contains(prompt, "<reflection>") {
		t.Error("execute prompt should contain '<reflection>' block")
	}
	if !strings.Contains(prompt, "WHAT_WORKED") {
		t.Error("execute prompt should contain reflection fields")
	}
}

func TestBuildVerifyPromptWithChecklist(t *testing.T) {
	checklist := []string{
		"GET /api/users returns 200",
		"POST /api/users validates email",
		"Auth middleware rejects invalid tokens",
	}
	prompt := BuildVerifyPrompt("implement user API", checklist)
	for _, item := range checklist {
		if !strings.Contains(prompt, item) {
			t.Errorf("verify prompt should contain checklist item %q", item)
		}
	}
	if !strings.Contains(prompt, "Verification checklist") {
		t.Error("verify prompt should include the verification section header")
	}
}

func TestRepairScopePrompt(t *testing.T) {
	summary := "3 security issues: SQL injection in login, XSS in profile, CSRF missing"
	prompt := RepairScopePrompt(3, summary)
	if !strings.Contains(prompt, "3") {
		t.Error("repair scope prompt should contain the findings count")
	}
	if !strings.Contains(prompt, summary) {
		t.Error("repair scope prompt should contain the findings summary")
	}
	if !strings.Contains(prompt, "triaging") {
		t.Error("repair scope prompt should describe the triage action")
	}
}

func TestShipReadinessPrompt(t *testing.T) {
	tasksSummary := "TASK-1: Added user model\nTASK-2: Added auth middleware"
	verificationChecklist := "V-1: GET /api/users returns 200\nV-2: Auth rejects invalid tokens"
	prompt := ShipReadinessPrompt(tasksSummary, verificationChecklist)
	if !strings.Contains(prompt, tasksSummary) {
		t.Error("ship readiness prompt should contain the tasks summary")
	}
	if !strings.Contains(prompt, verificationChecklist) {
		t.Error("ship readiness prompt should contain the verification checklist")
	}
	if !strings.Contains(prompt, "ship-readiness") {
		t.Error("ship readiness prompt should mention ship-readiness assessment")
	}
}

// TestScopePromptContainsAmbiguityScoring verifies that ScopeSystemPrompt
// includes the ambiguity assessment step and its scoring output marker.
func TestScopePromptContainsAmbiguityScoring(t *testing.T) {
	prompt := ScopeSystemPrompt(0.80)

	if !strings.Contains(prompt, "Ambiguity Assessment") {
		t.Error("scope prompt missing 'Ambiguity Assessment' section")
	}
	if !strings.Contains(prompt, "AMBIGUITY_SCORE") {
		t.Error("scope prompt missing 'AMBIGUITY_SCORE' output marker")
	}
	// Verify the threshold value was injected correctly.
	if !strings.Contains(prompt, "0.80") {
		t.Error("scope prompt should contain the injected threshold value '0.80'")
	}
	// Verify a different threshold also injects correctly.
	prompt2 := ScopeSystemPrompt(0.65)
	if !strings.Contains(prompt2, "0.65") {
		t.Error("scope prompt should contain the injected threshold value '0.65'")
	}
}
