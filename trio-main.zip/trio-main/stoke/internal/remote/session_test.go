package remote

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

// newTestReporter returns a SessionReporter pointed at the given test server.
func newTestReporter(url string) *SessionReporter {
	return &SessionReporter{
		endpoint: url,
		apiKey:   "test-key",
		client:   &http.Client{Timeout: 5 * time.Second},
	}
}

// ---------------------------------------------------------------------------
// New() constructor tests
// ---------------------------------------------------------------------------

func TestNewNoAPIKey(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "")
	r := New()
	if r != nil {
		t.Error("New() should return nil when EMBER_API_KEY is not set")
	}
}

func TestNewWithAPIKey(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key-xyz")
	r := New()
	if r == nil {
		t.Fatal("New() should return non-nil when EMBER_API_KEY is set")
	}
	if r.apiKey != "test-key-xyz" {
		t.Errorf("apiKey=%q", r.apiKey)
	}
}

func TestNewDefaultEndpoint(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key")
	t.Setenv("EMBER_API_URL", "")
	r := New()
	if r == nil {
		t.Fatal("New() should return non-nil")
	}
	if r.endpoint != "https://api.ember.dev" {
		t.Errorf("endpoint=%q", r.endpoint)
	}
}

func TestNewCustomEndpoint(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key")
	t.Setenv("EMBER_API_URL", "https://ember.corp.internal")
	r := New()
	if r == nil {
		t.Fatal("New() should return non-nil")
	}
	if r.endpoint != "https://ember.corp.internal" {
		t.Errorf("endpoint=%q", r.endpoint)
	}
}

func TestNewNonHTTPSEndpointWarning(t *testing.T) {
	// Should still create the reporter, just logs a warning.
	t.Setenv("EMBER_API_KEY", "test-key")
	t.Setenv("EMBER_API_URL", "http://insecure.local")
	r := New()
	if r == nil {
		t.Fatal("New() should return non-nil even for non-HTTPS endpoint")
	}
	if r.endpoint != "http://insecure.local" {
		t.Errorf("endpoint=%q, want %q", r.endpoint, "http://insecure.local")
	}
}

func TestNewClientTimeout(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key")
	t.Setenv("EMBER_API_URL", "")
	r := New()
	if r == nil {
		t.Fatal("New() should return non-nil")
	}
	if r.client == nil {
		t.Fatal("client should not be nil")
	}
	if r.client.Timeout != 10*time.Second {
		t.Errorf("client.Timeout=%v, want 10s", r.client.Timeout)
	}
}

// ---------------------------------------------------------------------------
// SessionID / WebURL accessors
// ---------------------------------------------------------------------------

func TestSessionIDNilReporter(t *testing.T) {
	var r *SessionReporter
	if r.SessionID() != "" {
		t.Error("SessionID() on nil reporter should return empty string")
	}
}

func TestSessionIDWithValue(t *testing.T) {
	r := &SessionReporter{sessionID: "sess-42"}
	if got := r.SessionID(); got != "sess-42" {
		t.Errorf("SessionID()=%q, want %q", got, "sess-42")
	}
}

func TestWebURLNilReporter(t *testing.T) {
	var r *SessionReporter
	if r.WebURL() != "" {
		t.Error("WebURL() on nil reporter should return empty string")
	}
}

func TestWebURLEmptySessionID(t *testing.T) {
	r := &SessionReporter{sessionID: "", endpoint: "https://api.ember.dev"}
	if r.WebURL() != "" {
		t.Error("WebURL() with empty sessionID should return empty string")
	}
}

func TestWebURLWithSessionID(t *testing.T) {
	r := &SessionReporter{sessionID: "sess-abc123", endpoint: "https://api.ember.dev"}
	url := r.WebURL()
	if url != "https://api.ember.dev/s/sess-abc123" {
		t.Errorf("WebURL()=%q", url)
	}
}

// ---------------------------------------------------------------------------
// doReq tests (using httptest)
// ---------------------------------------------------------------------------

func TestDoReqNilBody(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "GET" {
			t.Errorf("method=%q, want GET", r.Method)
		}
		if got := r.Header.Get("Authorization"); got != "Bearer test-key" {
			t.Errorf("Authorization=%q", got)
		}
		if ct := r.Header.Get("Content-Type"); ct != "" {
			t.Errorf("Content-Type should be empty for nil body, got %q", ct)
		}
		w.WriteHeader(200)
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	resp, err := r.doReq("GET", "/v1/health", nil)
	if err != nil {
		t.Fatalf("doReq error: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Errorf("status=%d", resp.StatusCode)
	}
}

func TestDoReqWithBody(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			t.Errorf("method=%q, want POST", r.Method)
		}
		if ct := r.Header.Get("Content-Type"); ct != "application/json" {
			t.Errorf("Content-Type=%q, want application/json", ct)
		}
		body, _ := io.ReadAll(r.Body)
		var m map[string]string
		if err := json.Unmarshal(body, &m); err != nil {
			t.Fatalf("unmarshal body: %v", err)
		}
		if m["plan_id"] != "test-plan" {
			t.Errorf("plan_id=%q", m["plan_id"])
		}
		w.WriteHeader(200)
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	resp, err := r.doReq("POST", "/v1/sessions", map[string]string{"plan_id": "test-plan"})
	if err != nil {
		t.Fatalf("doReq error: %v", err)
	}
	defer resp.Body.Close()
}

func TestDoReqMarshalError(t *testing.T) {
	r := newTestReporter("http://localhost")
	// channels cannot be marshaled to JSON
	_, err := r.doReq("POST", "/fail", make(chan int))
	if err == nil {
		t.Fatal("expected marshal error")
	}
	if !strings.Contains(err.Error(), "marshal request body") {
		t.Errorf("error=%q, want marshal request body", err)
	}
}

func TestDoReqInvalidURL(t *testing.T) {
	r := &SessionReporter{
		endpoint: "://bad-url",
		apiKey:   "k",
		client:   &http.Client{Timeout: time.Second},
	}
	_, err := r.doReq("GET", "/path", nil)
	if err == nil {
		t.Fatal("expected error for invalid URL")
	}
}

// ---------------------------------------------------------------------------
// RegisterSession tests (httptest)
// ---------------------------------------------------------------------------

func TestRegisterSessionNilReporter(t *testing.T) {
	var r *SessionReporter
	url, err := r.RegisterSession("plan-1")
	if err != nil {
		t.Errorf("RegisterSession() on nil reporter should return nil error, got %v", err)
	}
	if url != "" {
		t.Errorf("url=%q, want empty", url)
	}
}

func TestRegisterSessionSuccess(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			t.Errorf("method=%q, want POST", r.Method)
		}
		if r.URL.Path != "/v1/sessions" {
			t.Errorf("path=%q", r.URL.Path)
		}
		body, _ := io.ReadAll(r.Body)
		var m map[string]string
		if err := json.Unmarshal(body, &m); err != nil {
			t.Fatalf("unmarshal: %v", err)
		}
		if m["plan_id"] != "plan-abc" {
			t.Errorf("plan_id=%q", m["plan_id"])
		}
		w.WriteHeader(201)
		json.NewEncoder(w).Encode(map[string]string{
			"session_id": "sess-777",
			"url":        "https://ember.dev/s/sess-777",
		})
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	url, err := r.RegisterSession("plan-abc")
	if err != nil {
		t.Fatalf("RegisterSession error: %v", err)
	}
	if url != "https://ember.dev/s/sess-777" {
		t.Errorf("url=%q", url)
	}
	if r.sessionID != "sess-777" {
		t.Errorf("sessionID=%q", r.sessionID)
	}
}

func TestRegisterSessionHTTP200(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(200)
		json.NewEncoder(w).Encode(map[string]string{
			"session_id": "sess-200",
			"url":        "https://ember.dev/s/sess-200",
		})
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	url, err := r.RegisterSession("plan-x")
	if err != nil {
		t.Fatalf("error: %v", err)
	}
	if url != "https://ember.dev/s/sess-200" {
		t.Errorf("url=%q", url)
	}
}

func TestRegisterSession501(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(501)
		w.Write([]byte("not implemented"))
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	_, err := r.RegisterSession("plan-1")
	if err == nil {
		t.Fatal("expected error for 501")
	}
	if !strings.Contains(err.Error(), "501") {
		t.Errorf("error=%q, want 501 mention", err)
	}
}

func TestRegisterSessionHTTPError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(500)
		w.Write([]byte("internal server error"))
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	_, err := r.RegisterSession("plan-1")
	if err == nil {
		t.Fatal("expected error for HTTP 500")
	}
	if !strings.Contains(err.Error(), "500") {
		t.Errorf("error=%q, want 500 mention", err)
	}
}

func TestRegisterSessionBadJSON(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(201)
		w.Write([]byte("not json"))
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	_, err := r.RegisterSession("plan-1")
	if err == nil {
		t.Fatal("expected decode error for bad JSON")
	}
	if !strings.Contains(err.Error(), "decode session response") {
		t.Errorf("error=%q, want decode mention", err)
	}
}

func TestRegisterSessionNetworkError(t *testing.T) {
	r := newTestReporter("http://127.0.0.1:1") // nothing listening
	_, err := r.RegisterSession("plan-1")
	if err == nil {
		t.Fatal("expected network error")
	}
	if !strings.Contains(err.Error(), "register session") {
		t.Errorf("error=%q, want 'register session' prefix", err)
	}
}

// ---------------------------------------------------------------------------
// Update tests (httptest)
// ---------------------------------------------------------------------------

func TestUpdateNilReporter(t *testing.T) {
	var r *SessionReporter
	err := r.Update(SessionUpdate{})
	if err != nil {
		t.Errorf("Update() on nil reporter should return nil error, got %v", err)
	}
}

func TestUpdateEmptySessionID(t *testing.T) {
	r := &SessionReporter{sessionID: ""}
	err := r.Update(SessionUpdate{})
	if err != nil {
		t.Errorf("Update() with empty sessionID should return nil error, got %v", err)
	}
}

func TestUpdateSuccess(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "PUT" {
			t.Errorf("method=%q, want PUT", r.Method)
		}
		if r.URL.Path != "/v1/sessions/sess-upd" {
			t.Errorf("path=%q", r.URL.Path)
		}
		body, _ := io.ReadAll(r.Body)
		var update SessionUpdate
		if err := json.Unmarshal(body, &update); err != nil {
			t.Fatalf("unmarshal: %v", err)
		}
		if update.SessionID != "sess-upd" {
			t.Errorf("session_id=%q", update.SessionID)
		}
		if update.PlanID != "plan-42" {
			t.Errorf("plan_id=%q", update.PlanID)
		}
		if update.TotalCostUSD != 1.5 {
			t.Errorf("total_cost_usd=%f", update.TotalCostUSD)
		}
		if update.BurstWorkers != 3 {
			t.Errorf("burst_workers=%d", update.BurstWorkers)
		}
		if update.UpdatedAt.IsZero() {
			t.Error("updated_at should not be zero")
		}
		if len(update.Tasks) != 1 {
			t.Fatalf("tasks len=%d", len(update.Tasks))
		}
		if update.Tasks[0].TaskID != "task-1" {
			t.Errorf("task_id=%q", update.Tasks[0].TaskID)
		}
		w.WriteHeader(200)
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	r.sessionID = "sess-upd"

	err := r.Update(SessionUpdate{
		PlanID: "plan-42",
		Tasks: []TaskProgress{
			{
				TaskID:      "task-1",
				Description: "do something",
				Phase:       "execute",
				Worker:      "claude",
				CostUSD:     0.5,
				DurationMs:  1200,
			},
		},
		TotalCostUSD: 1.5,
		BurstWorkers: 3,
	})
	if err != nil {
		t.Fatalf("Update error: %v", err)
	}
}

func TestUpdate501(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(501)
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	r.sessionID = "sess-upd501"

	err := r.Update(SessionUpdate{PlanID: "plan-1"})
	if err == nil {
		t.Fatal("expected error for 501")
	}
	if !strings.Contains(err.Error(), "501") {
		t.Errorf("error=%q, want 501 mention", err)
	}
}

func TestUpdateNetworkError(t *testing.T) {
	r := newTestReporter("http://127.0.0.1:1")
	r.sessionID = "sess-net"

	err := r.Update(SessionUpdate{PlanID: "plan-1"})
	if err == nil {
		t.Fatal("expected network error")
	}
}

// ---------------------------------------------------------------------------
// Complete tests (httptest)
// ---------------------------------------------------------------------------

func TestCompleteNilReporter(t *testing.T) {
	var r *SessionReporter
	err := r.Complete(true, "all done")
	if err != nil {
		t.Errorf("Complete() on nil reporter should return nil error, got %v", err)
	}
}

func TestCompleteEmptySessionID(t *testing.T) {
	r := &SessionReporter{sessionID: ""}
	err := r.Complete(true, "summary")
	if err != nil {
		t.Errorf("Complete() with empty sessionID should return nil error, got %v", err)
	}
}

func TestCompleteSuccess(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "PUT" {
			t.Errorf("method=%q, want PUT", r.Method)
		}
		if r.URL.Path != "/v1/sessions/sess-done" {
			t.Errorf("path=%q", r.URL.Path)
		}
		body, _ := io.ReadAll(r.Body)
		var m map[string]any
		if err := json.Unmarshal(body, &m); err != nil {
			t.Fatalf("unmarshal: %v", err)
		}
		if m["status"] != "completed" {
			t.Errorf("status=%v", m["status"])
		}
		if m["success"] != true {
			t.Errorf("success=%v", m["success"])
		}
		if m["summary"] != "all tasks passed" {
			t.Errorf("summary=%v", m["summary"])
		}
		w.WriteHeader(200)
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	r.sessionID = "sess-done"

	err := r.Complete(true, "all tasks passed")
	if err != nil {
		t.Fatalf("Complete error: %v", err)
	}
}

func TestCompleteFailure(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		var m map[string]any
		json.Unmarshal(body, &m)
		if m["success"] != false {
			t.Errorf("success=%v, want false", m["success"])
		}
		if m["summary"] != "build failed" {
			t.Errorf("summary=%v", m["summary"])
		}
		w.WriteHeader(200)
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	r.sessionID = "sess-fail"

	err := r.Complete(false, "build failed")
	if err != nil {
		t.Fatalf("Complete error: %v", err)
	}
}

func TestComplete501(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(501)
	}))
	defer srv.Close()

	r := newTestReporter(srv.URL)
	r.sessionID = "sess-501"

	err := r.Complete(true, "done")
	if err == nil {
		t.Fatal("expected error for 501")
	}
	if !strings.Contains(err.Error(), "501") {
		t.Errorf("error=%q, want 501 mention", err)
	}
}

func TestCompleteNetworkError(t *testing.T) {
	r := newTestReporter("http://127.0.0.1:1")
	r.sessionID = "sess-net"

	err := r.Complete(true, "done")
	if err == nil {
		t.Fatal("expected network error")
	}
}

// ---------------------------------------------------------------------------
// Authorization header verification
// ---------------------------------------------------------------------------

func TestAuthorizationHeaderSent(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		auth := r.Header.Get("Authorization")
		if auth != "Bearer my-secret-key" {
			t.Errorf("Authorization=%q, want 'Bearer my-secret-key'", auth)
		}
		w.WriteHeader(200)
	}))
	defer srv.Close()

	r := &SessionReporter{
		endpoint: srv.URL,
		apiKey:   "my-secret-key",
		client:   &http.Client{Timeout: 5 * time.Second},
	}
	resp, err := r.doReq("GET", "/test", nil)
	if err != nil {
		t.Fatalf("doReq error: %v", err)
	}
	defer resp.Body.Close()
}
