package subscriptions

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestPollClaudeUsageEmptyToken(t *testing.T) {
	_, err := PollClaudeUsage(context.Background(), "")
	if err == nil {
		t.Error("expected error for empty token")
	}
}

func TestPollClaudeUsageHTTPError(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer test-token" {
			http.Error(w, "missing auth", 401)
			return
		}
		w.WriteHeader(401)
		w.Write([]byte("Unauthorized"))
	}))
	defer server.Close()

	// Override usageURL via the unexported package-level variable approach
	origUsageURL := usageURL
	defer func() { usageURL = origUsageURL }()
	usageURL = server.URL + "/api/oauth/usage"

	_, err := PollClaudeUsage(context.Background(), "test-token")
	if err == nil {
		t.Error("expected error for 401 response")
	}
}

func TestPollClaudeUsageSuccess(t *testing.T) {
	resetTime := time.Now().Add(4 * time.Hour).UTC()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer test-token" {
			http.Error(w, "missing auth", 401)
			return
		}
		data := UsageData{
			FiveHour: UsageWindow{Utilization: 45.5, ResetsAt: &resetTime},
			SevenDay: UsageWindow{Utilization: 12.3, ResetsAt: &resetTime},
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(data)
	}))
	defer server.Close()

	origUsageURL := usageURL
	defer func() { usageURL = origUsageURL }()
	usageURL = server.URL + "/api/oauth/usage"

	data, err := PollClaudeUsage(context.Background(), "test-token")
	if err != nil {
		t.Fatal(err)
	}
	if data.FiveHour.Utilization != 45.5 {
		t.Errorf("FiveHour.Utilization=%f, want 45.5", data.FiveHour.Utilization)
	}
	if data.SevenDay.Utilization != 12.3 {
		t.Errorf("SevenDay.Utilization=%f, want 12.3", data.SevenDay.Utilization)
	}
	if data.FiveHour.ResetsAt == nil {
		t.Fatal("FiveHour.ResetsAt should not be nil")
	}
}

func TestPollClaudeUsageNilResetsAt(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		data := map[string]interface{}{
			"five_hour": map[string]interface{}{"utilization": 10.0},
			"seven_day": map[string]interface{}{"utilization": 5.0},
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(data)
	}))
	defer server.Close()

	origUsageURL := usageURL
	defer func() { usageURL = origUsageURL }()
	usageURL = server.URL + "/api/oauth/usage"

	data, err := PollClaudeUsage(context.Background(), "test-token")
	if err != nil {
		t.Fatal(err)
	}
	if data.FiveHour.ResetsAt != nil {
		t.Error("FiveHour.ResetsAt should be nil when not set")
	}
}

func TestPoolCount(t *testing.T) {
	m := NewManager([]Pool{
		{ID: "c1", Provider: ProviderClaude},
		{ID: "c2", Provider: ProviderClaude},
		{ID: "cx1", Provider: ProviderCodex},
	})

	if n := m.PoolCount(ProviderClaude); n != 2 {
		t.Errorf("Claude count=%d, want 2", n)
	}
	if n := m.PoolCount(ProviderCodex); n != 1 {
		t.Errorf("Codex count=%d, want 1", n)
	}
}

func TestPoolCountZero(t *testing.T) {
	m := NewManager(nil)
	if n := m.PoolCount(ProviderClaude); n != 0 {
		t.Errorf("Claude count=%d, want 0", n)
	}
}

func TestLeastLoadedFound(t *testing.T) {
	m := NewManager([]Pool{
		{ID: "c1", Provider: ProviderClaude, Utilization: 70},
		{ID: "c2", Provider: ProviderClaude, Utilization: 20},
		{ID: "c3", Provider: ProviderClaude, Utilization: 50, Status: StatusBusy},
	})

	pool, err := m.LeastLoaded(ProviderClaude)
	if err != nil {
		t.Fatalf("LeastLoaded() error: %v", err)
	}
	if pool.ID != "c2" {
		t.Errorf("LeastLoaded()=c2 (lowest utilization), got %s", pool.ID)
	}
}

func TestLeastLoadedNoneAvailable(t *testing.T) {
	m := NewManager([]Pool{
		{ID: "c1", Provider: ProviderClaude, Status: StatusBusy},
	})

	_, err := m.LeastLoaded(ProviderClaude)
	if err == nil {
		t.Error("expected error when no pool available")
	}
}

func TestLeastLoadedAllBusy(t *testing.T) {
	// LeastLoaded only skips StatusBusy, not high utilization
	m := NewManager([]Pool{
		{ID: "c1", Provider: ProviderClaude, Status: StatusBusy},
	})

	_, err := m.LeastLoaded(ProviderClaude)
	if err == nil {
		t.Error("expected error when only pool is busy")
	}
}

func TestAcquireExcluding(t *testing.T) {
	m := NewManager([]Pool{
		{ID: "c1", Provider: ProviderClaude},
		{ID: "c2", Provider: ProviderClaude},
	})

	pool, err := m.AcquireExcluding(ProviderClaude, "task-1", map[string]bool{"c1": true})
	if err != nil {
		t.Fatalf("AcquireExcluding() error: %v", err)
	}
	if pool.ID != "c2" {
		t.Errorf("AcquireExcluding()=c2, got %s", pool.ID)
	}
}

func TestAcquireExcludingNoAlternatives(t *testing.T) {
	m := NewManager([]Pool{
		{ID: "c1", Provider: ProviderClaude},
	})

	_, err := m.AcquireExcluding(ProviderClaude, "task-1", map[string]bool{"c1": true})
	if err == nil {
		t.Error("expected error when no alternatives available")
	}
}

func TestAcquireExcludingSkipsBusy(t *testing.T) {
	m := NewManager([]Pool{
		{ID: "c1", Provider: ProviderClaude, Status: StatusBusy},
		{ID: "c2", Provider: ProviderClaude},
	})

	pool, err := m.AcquireExcluding(ProviderClaude, "task-1", nil)
	if err != nil {
		t.Fatalf("AcquireExcluding() error: %v", err)
	}
	if pool.ID != "c2" {
		t.Errorf("AcquireExcluding() should skip busy pool, got %s", pool.ID)
	}
}

func TestAcquireExcludingAllExhausted(t *testing.T) {
	m := NewManager([]Pool{
		{ID: "c1", Provider: ProviderClaude, Utilization: 96},
		{ID: "c2", Provider: ProviderClaude, Utilization: 97},
	})

	_, err := m.AcquireExcluding(ProviderClaude, "task-1", nil)
	if err == nil {
		t.Error("expected error when all pools exhausted")
	}
}

func TestPoolStatusString(t *testing.T) {
	tests := []struct {
		status PoolStatus
		want   string
	}{
		{StatusIdle, "idle"},
		{StatusBusy, "busy"},
		{StatusThrottled, "throttled"},
		{StatusExhausted, "exhausted"},
		{StatusCircuitOpen, "circuit-open"},
		{PoolStatus(99), "unknown(99)"},
	}
	for _, tt := range tests {
		got := tt.status.String()
		if got != tt.want {
			t.Errorf("PoolStatus(%d).String()=%q, want %q", tt.status, got, tt.want)
		}
	}
}

func TestAcquireExcludingConcurrent(t *testing.T) {
	m := NewManager([]Pool{
		{ID: "c1", Provider: ProviderClaude},
		{ID: "c2", Provider: ProviderClaude},
		{ID: "c3", Provider: ProviderClaude},
	})

	excludes := []map[string]bool{
		nil,
		{"c1": true},
		{"c1": true, "c2": true},
	}

	var pools []Pool
	for _, excl := range excludes {
		p, err := m.AcquireExcluding(ProviderClaude, "task", excl)
		if err != nil {
			t.Fatalf("AcquireExcluding() error: %v", err)
		}
		pools = append(pools, p)
	}

	if len(pools) != 3 {
		t.Errorf("got %d pools, want 3", len(pools))
	}
}

func TestStartPollerDoesNotPanic(t *testing.T) {
	m := NewManager([]Pool{
		{ID: "c1", Provider: ProviderClaude, OAuthToken: ""},
	})
	ctx, cancel := context.WithCancel(context.Background())
	cancel() // Cancel immediately

	// Should not panic even with empty OAuthToken
	m.StartPoller(ctx, time.Millisecond)
}
