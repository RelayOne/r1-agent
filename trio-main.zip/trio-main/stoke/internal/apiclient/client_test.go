package apiclient

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestNewClient(t *testing.T) {
	c := NewClient(Config{
		Provider: ProviderAnthropic,
		APIKey:   "test-key",
		Model:    "claude-sonnet-4-20250514",
	})

	if c.Provider() != ProviderAnthropic {
		t.Errorf("expected anthropic, got %s", c.Provider())
	}
	if c.Model() != "claude-sonnet-4-20250514" {
		t.Errorf("unexpected model: %s", c.Model())
	}
}

func TestCompleteAnthropic(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("x-api-key") != "test-key" {
			t.Error("missing api key")
		}
		if r.Header.Get("anthropic-version") == "" {
			t.Error("missing version header")
		}

		resp := map[string]any{
			"content": []map[string]any{
				{"type": "text", "text": "Hello, World!"},
			},
			"stop_reason": "end_turn",
			"model":       "claude-sonnet-4-20250514",
			"usage": map[string]any{
				"input_tokens":  100,
				"output_tokens": 20,
			},
		}
		json.NewEncoder(w).Encode(resp)
	}))
	defer server.Close()

	c := NewClient(Config{
		Provider: ProviderAnthropic,
		APIKey:   "test-key",
		BaseURL:  server.URL,
		Model:    "claude-sonnet-4-20250514",
	})

	resp, err := c.Complete(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hello"}},
	})
	if err != nil {
		t.Fatal(err)
	}
	if resp.Content != "Hello, World!" {
		t.Errorf("expected 'Hello, World!', got %q", resp.Content)
	}
	if resp.Usage.InputTokens != 100 {
		t.Errorf("expected 100 input tokens, got %d", resp.Usage.InputTokens)
	}
}

func TestCompleteOpenAI(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer test-key" {
			t.Error("missing auth header")
		}

		resp := map[string]any{
			"choices": []map[string]any{
				{
					"message":       map[string]any{"content": "Hi there!"},
					"finish_reason": "stop",
				},
			},
			"model": "gpt-4o",
			"usage": map[string]any{
				"prompt_tokens":     50,
				"completion_tokens": 10,
			},
		}
		json.NewEncoder(w).Encode(resp)
	}))
	defer server.Close()

	c := NewClient(Config{
		Provider: ProviderOpenAI,
		APIKey:   "test-key",
		BaseURL:  server.URL,
		Model:    "gpt-4o",
	})

	resp, err := c.Complete(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hello"}},
		System:   "You are helpful",
	})
	if err != nil {
		t.Fatal(err)
	}
	if resp.Content != "Hi there!" {
		t.Errorf("expected 'Hi there!', got %q", resp.Content)
	}
}

func TestStreamAnthropic(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.Write([]byte("data: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"text_delta\",\"text\":\"Hello\"}}\n\n"))
		w.Write([]byte("data: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"text_delta\",\"text\":\" World\"}}\n\n"))
		w.Write([]byte("data: {\"type\":\"message_delta\",\"delta\":{\"stop_reason\":\"end_turn\"},\"usage\":{\"output_tokens\":5}}\n\n"))
		w.Write([]byte("data: [DONE]\n\n"))
	}))
	defer server.Close()

	c := NewClient(Config{
		Provider: ProviderAnthropic,
		APIKey:   "test-key",
		BaseURL:  server.URL,
	})

	var chunks []string
	usage, err := c.Stream(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	}, func(e StreamEvent) {
		if e.Type == "text" {
			chunks = append(chunks, e.Text)
		}
	})

	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) != 2 || chunks[0] != "Hello" || chunks[1] != " World" {
		t.Errorf("unexpected chunks: %v", chunks)
	}
	if usage.OutputTokens != 5 {
		t.Errorf("expected 5 output tokens, got %d", usage.OutputTokens)
	}
}

func TestAPIError(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(429)
		w.Write([]byte(`{"error": {"message": "rate limited"}}`))
	}))
	defer server.Close()

	c := NewClient(Config{
		Provider: ProviderAnthropic,
		APIKey:   "key",
		BaseURL:  server.URL,
	})

	_, err := c.Complete(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	})
	if err == nil {
		t.Fatal("should error on 429")
	}

	apiErr, ok := err.(*APIError)
	if !ok {
		t.Fatalf("expected APIError, got %T", err)
	}
	if !apiErr.IsRateLimit() {
		t.Error("should be rate limit error")
	}
	if !apiErr.IsRetryable() {
		t.Error("rate limit should be retryable")
	}
}

func TestAPIErrorAuth(t *testing.T) {
	e := &APIError{StatusCode: 401, Provider: ProviderAnthropic}
	if !e.IsAuth() {
		t.Error("401 should be auth error")
	}
	if e.IsRetryable() {
		t.Error("auth error should not be retryable")
	}
}

func TestDefaultConfigs(t *testing.T) {
	for _, p := range []Provider{ProviderAnthropic, ProviderOpenAI, ProviderOpenRouter} {
		cfg, ok := DefaultConfigs[p]
		if !ok {
			t.Errorf("missing default config for %s", p)
		}
		if cfg.BaseURL == "" {
			t.Errorf("empty base URL for %s", p)
		}
	}
}

func TestBuildAnthropicBody(t *testing.T) {
	c := NewClient(Config{Provider: ProviderAnthropic, Model: "test"})
	temp := 0.5
	body, err := c.buildRequestBody(Request{
		Messages:    []Message{{Role: "user", Content: "hi"}},
		System:      "be helpful",
		Temperature: &temp,
	})
	if err != nil {
		t.Fatal(err)
	}
	var parsed map[string]any
	json.Unmarshal(body, &parsed)
	if parsed["system"] != "be helpful" {
		t.Error("should include system prompt")
	}
}

func TestBuildOpenAIBody(t *testing.T) {
	c := NewClient(Config{Provider: ProviderOpenAI, Model: "gpt-4o"})
	body, err := c.buildRequestBody(Request{
		Messages: []Message{{Role: "user", Content: "hi"}},
		System:   "be helpful",
	})
	if err != nil {
		t.Fatal(err)
	}
	var parsed map[string]any
	json.Unmarshal(body, &parsed)
	msgs, _ := parsed["messages"].([]any)
	if len(msgs) != 2 {
		t.Errorf("expected 2 messages (system + user), got %d", len(msgs))
	}
}

// --- APIError method tests ---

func TestAPIErrorMessage(t *testing.T) {
	e := &APIError{StatusCode: 500, Message: "internal error", Provider: ProviderAnthropic}
	msg := e.Error()
	if msg == "" {
		t.Fatal("error message should not be empty")
	}
	if !strings.Contains(msg, "500") {
		t.Error("should contain status code")
	}
	if !strings.Contains(msg, "internal error") {
		t.Error("should contain error message")
	}
	if !strings.Contains(msg, "anthropic") {
		t.Error("should contain provider name")
	}
}

func TestAPIErrorIsRetryableVariants(t *testing.T) {
	tests := []struct {
		code      int
		retryable bool
	}{
		{429, true},
		{500, true},
		{502, true},
		{503, true},
		{504, true},
		{400, false},
		{401, false},
		{403, false},
		{404, false},
	}
	for _, tt := range tests {
		e := &APIError{StatusCode: tt.code}
		if got := e.IsRetryable(); got != tt.retryable {
			t.Errorf("status %d: IsRetryable()=%v, want %v", tt.code, got, tt.retryable)
		}
	}
}

func TestAPIErrorIsAuthVariants(t *testing.T) {
	tests := []struct {
		code   int
		isAuth bool
	}{
		{401, true},
		{403, true},
		{400, false},
		{429, false},
		{500, false},
	}
	for _, tt := range tests {
		e := &APIError{StatusCode: tt.code}
		if got := e.IsAuth(); got != tt.isAuth {
			t.Errorf("status %d: IsAuth()=%v, want %v", tt.code, got, tt.isAuth)
		}
	}
}

// --- Error status code tests ---

func TestCompleteError401(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(401)
		w.Write([]byte(`{"error": {"message": "invalid api key"}}`))
	}))
	defer server.Close()

	c := NewClient(Config{Provider: ProviderAnthropic, APIKey: "bad-key", BaseURL: server.URL})
	_, err := c.Complete(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	})
	if err == nil {
		t.Fatal("expected error on 401")
	}
	apiErr, ok := err.(*APIError)
	if !ok {
		t.Fatalf("expected APIError, got %T", err)
	}
	if !apiErr.IsAuth() {
		t.Error("401 should be auth error")
	}
	if apiErr.IsRetryable() {
		t.Error("401 should not be retryable")
	}
}

func TestCompleteError500(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(500)
		w.Write([]byte(`{"error": {"message": "internal server error"}}`))
	}))
	defer server.Close()

	c := NewClient(Config{Provider: ProviderOpenAI, APIKey: "key", BaseURL: server.URL})
	_, err := c.Complete(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	})
	if err == nil {
		t.Fatal("expected error on 500")
	}
	apiErr, ok := err.(*APIError)
	if !ok {
		t.Fatalf("expected APIError, got %T", err)
	}
	if apiErr.IsAuth() {
		t.Error("500 should not be auth error")
	}
	if !apiErr.IsRetryable() {
		t.Error("500 should be retryable")
	}
}

// --- Stream error handling ---

func TestStreamError429(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(429)
		w.Write([]byte(`{"error": {"message": "rate limited"}}`))
	}))
	defer server.Close()

	c := NewClient(Config{Provider: ProviderAnthropic, APIKey: "key", BaseURL: server.URL})
	_, err := c.Stream(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	}, func(e StreamEvent) {})
	if err == nil {
		t.Fatal("expected error on 429")
	}
	apiErr, ok := err.(*APIError)
	if !ok {
		t.Fatalf("expected APIError, got %T", err)
	}
	if !apiErr.IsRateLimit() {
		t.Error("should be rate limit error")
	}
}

// --- buildRequestBody for unsupported provider ---

func TestBuildRequestBodyUnsupportedProvider(t *testing.T) {
	c := NewClient(Config{Provider: Provider("unknown"), Model: "test"})
	_, err := c.buildRequestBody(Request{
		Messages: []Message{{Role: "user", Content: "hi"}},
	})
	if err == nil {
		t.Error("expected error for unsupported provider")
	}
}

// --- buildAnthropicBody with tools and stop sequences ---

func TestBuildAnthropicBodyWithToolsAndStopSeqs(t *testing.T) {
	c := NewClient(Config{Provider: ProviderAnthropic, Model: "claude-sonnet-4-20250514", MaxTokens: 8000})
	body, err := c.buildRequestBody(Request{
		Messages: []Message{{Role: "user", Content: "hi"}},
		Tools: []ToolDef{
			{Name: "search", Description: "search files", InputSchema: map[string]any{"type": "object"}},
		},
		StopSeqs: []string{"DONE", "END"},
	})
	if err != nil {
		t.Fatal(err)
	}
	var parsed map[string]any
	json.Unmarshal(body, &parsed)
	tools, ok := parsed["tools"].([]any)
	if !ok || len(tools) != 1 {
		t.Errorf("expected 1 tool, got %v", parsed["tools"])
	}
	stopSeqs, ok := parsed["stop_sequences"].([]any)
	if !ok || len(stopSeqs) != 2 {
		t.Errorf("expected 2 stop sequences, got %v", parsed["stop_sequences"])
	}
}

// --- buildOpenAIBody without system prompt ---

func TestBuildOpenAIBodyNoSystem(t *testing.T) {
	c := NewClient(Config{Provider: ProviderOpenAI, Model: "gpt-4o"})
	body, err := c.buildRequestBody(Request{
		Messages: []Message{{Role: "user", Content: "hi"}},
	})
	if err != nil {
		t.Fatal(err)
	}
	var parsed map[string]any
	json.Unmarshal(body, &parsed)
	msgs, _ := parsed["messages"].([]any)
	if len(msgs) != 1 {
		t.Errorf("expected 1 message (no system), got %d", len(msgs))
	}
}

func TestBuildOpenAIBodyWithTemperature(t *testing.T) {
	c := NewClient(Config{Provider: ProviderOpenAI, Model: "gpt-4o"})
	temp := 0.7
	body, err := c.buildRequestBody(Request{
		Messages:    []Message{{Role: "user", Content: "hi"}},
		Temperature: &temp,
	})
	if err != nil {
		t.Fatal(err)
	}
	var parsed map[string]any
	json.Unmarshal(body, &parsed)
	if parsed["temperature"] != 0.7 {
		t.Errorf("temperature=%v, want 0.7", parsed["temperature"])
	}
}

// --- buildHTTPRequest URL routing ---

func TestBuildHTTPRequestURLRouting(t *testing.T) {
	tests := []struct {
		provider Provider
		baseURL  string
		wantPath string
	}{
		{ProviderAnthropic, "https://api.anthropic.com", "/v1/messages"},
		{ProviderOpenAI, "https://api.openai.com", "/v1/chat/completions"},
		{ProviderOpenRouter, "https://openrouter.ai", "/api/v1/chat/completions"},
	}
	for _, tt := range tests {
		c := NewClient(Config{Provider: tt.provider, APIKey: "key", BaseURL: tt.baseURL})
		req, err := c.buildHTTPRequest(context.Background(), []byte("{}"))
		if err != nil {
			t.Fatalf("provider %s: %v", tt.provider, err)
		}
		if req.URL.Path != tt.wantPath {
			t.Errorf("provider %s: path=%q, want %q", tt.provider, req.URL.Path, tt.wantPath)
		}
	}
}

func TestBuildHTTPRequestHeaders(t *testing.T) {
	// Anthropic headers
	c := NewClient(Config{Provider: ProviderAnthropic, APIKey: "ant-key"})
	req, _ := c.buildHTTPRequest(context.Background(), []byte("{}"))
	if req.Header.Get("x-api-key") != "ant-key" {
		t.Error("anthropic should set x-api-key header")
	}
	if req.Header.Get("anthropic-version") != "2023-06-01" {
		t.Error("anthropic should set version header")
	}

	// OpenAI headers
	c2 := NewClient(Config{Provider: ProviderOpenAI, APIKey: "oai-key"})
	req2, _ := c2.buildHTTPRequest(context.Background(), []byte("{}"))
	if req2.Header.Get("Authorization") != "Bearer oai-key" {
		t.Error("openai should set Bearer auth header")
	}

	// OpenRouter headers
	c3 := NewClient(Config{Provider: ProviderOpenRouter, APIKey: "or-key"})
	req3, _ := c3.buildHTTPRequest(context.Background(), []byte("{}"))
	if req3.Header.Get("Authorization") != "Bearer or-key" {
		t.Error("openrouter should set Bearer auth header")
	}
}

// --- parseResponse with malformed JSON ---

func TestParseAnthropicResponseMalformedJSON(t *testing.T) {
	c := NewClient(Config{Provider: ProviderAnthropic})
	_, err := c.parseResponse(strings.NewReader("not json"))
	if err == nil {
		t.Error("expected error for malformed JSON")
	}
}

func TestParseOpenAIResponseMalformedJSON(t *testing.T) {
	c := NewClient(Config{Provider: ProviderOpenAI})
	_, err := c.parseResponse(strings.NewReader("{invalid json"))
	if err == nil {
		t.Error("expected error for malformed JSON")
	}
}

func TestParseResponseUnsupportedProvider(t *testing.T) {
	c := NewClient(Config{Provider: Provider("unknown")})
	_, err := c.parseResponse(strings.NewReader("{}"))
	if err == nil {
		t.Error("expected error for unsupported provider")
	}
}

// --- parseAnthropicResponse with empty choices ---

func TestParseAnthropicResponseEmptyContent(t *testing.T) {
	data := `{"content":[],"stop_reason":"end_turn","model":"claude","usage":{"input_tokens":10,"output_tokens":5}}`
	resp, err := parseAnthropicResponse([]byte(data))
	if err != nil {
		t.Fatal(err)
	}
	if resp.Content != "" {
		t.Errorf("expected empty content, got %q", resp.Content)
	}
	if resp.Usage.InputTokens != 10 {
		t.Errorf("input tokens=%d, want 10", resp.Usage.InputTokens)
	}
}

func TestParseAnthropicResponseMultipleBlocks(t *testing.T) {
	data := `{"content":[{"type":"text","text":"Hello "},{"type":"text","text":"World"}],"stop_reason":"end_turn","model":"claude","usage":{}}`
	resp, err := parseAnthropicResponse([]byte(data))
	if err != nil {
		t.Fatal(err)
	}
	if resp.Content != "Hello World" {
		t.Errorf("content=%q, want 'Hello World'", resp.Content)
	}
}

// --- parseOpenAIResponse with empty choices ---

func TestParseOpenAIResponseEmptyChoices(t *testing.T) {
	data := `{"choices":[],"model":"gpt-4o","usage":{"prompt_tokens":10,"completion_tokens":0}}`
	resp, err := parseOpenAIResponse([]byte(data))
	if err != nil {
		t.Fatal(err)
	}
	if resp.Content != "" {
		t.Errorf("expected empty content, got %q", resp.Content)
	}
}

// --- OpenAI SSE streaming ---

func TestStreamOpenAI(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer test-key" {
			t.Error("missing auth header")
		}
		w.Header().Set("Content-Type", "text/event-stream")
		w.Write([]byte("data: {\"choices\":[{\"delta\":{\"content\":\"Hi\"},\"finish_reason\":null}]}\n\n"))
		w.Write([]byte("data: {\"choices\":[{\"delta\":{\"content\":\" there\"},\"finish_reason\":null}]}\n\n"))
		w.Write([]byte("data: {\"choices\":[{\"delta\":{},\"finish_reason\":\"stop\"}]}\n\n"))
		w.Write([]byte("data: [DONE]\n\n"))
	}))
	defer server.Close()

	c := NewClient(Config{
		Provider: ProviderOpenAI,
		APIKey:   "test-key",
		BaseURL:  server.URL,
	})

	var chunks []string
	var gotStop bool
	_, err := c.Stream(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	}, func(e StreamEvent) {
		if e.Type == "text" {
			chunks = append(chunks, e.Text)
		}
		if e.Type == "stop" {
			gotStop = true
		}
	})

	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) != 2 || chunks[0] != "Hi" || chunks[1] != " there" {
		t.Errorf("unexpected chunks: %v", chunks)
	}
	if !gotStop {
		t.Error("expected stop event")
	}
}

// --- Anthropic SSE edge cases ---

func TestStreamAnthropicMessageStart(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.Write([]byte("data: {\"type\":\"message_start\",\"message\":{\"usage\":{\"input_tokens\":50}}}\n\n"))
		w.Write([]byte("data: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"text_delta\",\"text\":\"Done\"}}\n\n"))
		w.Write([]byte("data: [DONE]\n\n"))
	}))
	defer server.Close()

	c := NewClient(Config{Provider: ProviderAnthropic, APIKey: "key", BaseURL: server.URL})
	var chunks []string
	usage, err := c.Stream(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	}, func(e StreamEvent) {
		if e.Type == "text" {
			chunks = append(chunks, e.Text)
		}
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) != 1 || chunks[0] != "Done" {
		t.Errorf("unexpected chunks: %v", chunks)
	}
	if usage.InputTokens != 50 {
		t.Errorf("input tokens=%d, want 50", usage.InputTokens)
	}
}

func TestStreamAnthropicErrorEvent(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.Write([]byte("data: {\"type\":\"error\",\"error\":{\"message\":\"overloaded\"}}\n\n"))
		w.Write([]byte("data: [DONE]\n\n"))
	}))
	defer server.Close()

	c := NewClient(Config{Provider: ProviderAnthropic, APIKey: "key", BaseURL: server.URL})
	var errorMsg string
	_, err := c.Stream(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	}, func(e StreamEvent) {
		if e.Type == "error" {
			errorMsg = e.Error
		}
	})
	if err != nil {
		t.Fatal(err)
	}
	if errorMsg != "overloaded" {
		t.Errorf("error message=%q, want 'overloaded'", errorMsg)
	}
}

// --- SSE parsing edge cases ---

func TestParseSSENonDataLinesIgnored(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.Write([]byte("event: message_start\n"))
		w.Write([]byte(": comment line\n"))
		w.Write([]byte("\n"))
		w.Write([]byte("data: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"text_delta\",\"text\":\"OK\"}}\n\n"))
		w.Write([]byte("data: [DONE]\n\n"))
	}))
	defer server.Close()

	c := NewClient(Config{Provider: ProviderAnthropic, APIKey: "key", BaseURL: server.URL})
	var chunks []string
	_, err := c.Stream(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	}, func(e StreamEvent) {
		if e.Type == "text" {
			chunks = append(chunks, e.Text)
		}
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) != 1 || chunks[0] != "OK" {
		t.Errorf("unexpected chunks: %v", chunks)
	}
}

func TestParseSSEMalformedJSONSkipped(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.Write([]byte("data: {not valid json}\n\n"))
		w.Write([]byte("data: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"text_delta\",\"text\":\"OK\"}}\n\n"))
		w.Write([]byte("data: [DONE]\n\n"))
	}))
	defer server.Close()

	c := NewClient(Config{Provider: ProviderAnthropic, APIKey: "key", BaseURL: server.URL})
	var chunks []string
	_, err := c.Stream(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	}, func(e StreamEvent) {
		if e.Type == "text" {
			chunks = append(chunks, e.Text)
		}
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) != 1 || chunks[0] != "OK" {
		t.Errorf("malformed JSON should be skipped, got chunks: %v", chunks)
	}
}

// --- Complete request format verification ---

func TestCompleteRequestFormat(t *testing.T) {
	var receivedBody map[string]any
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewDecoder(r.Body).Decode(&receivedBody)
		resp := map[string]any{
			"content":     []map[string]any{{"type": "text", "text": "ok"}},
			"stop_reason": "end_turn",
			"model":       "claude-sonnet-4-20250514",
			"usage":       map[string]any{"input_tokens": 10, "output_tokens": 5},
		}
		json.NewEncoder(w).Encode(resp)
	}))
	defer server.Close()

	c := NewClient(Config{
		Provider:  ProviderAnthropic,
		APIKey:    "key",
		BaseURL:   server.URL,
		Model:     "claude-sonnet-4-20250514",
		MaxTokens: 4096,
	})

	_, err := c.Complete(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hello"}},
		System:   "Be brief",
	})
	if err != nil {
		t.Fatal(err)
	}
	if receivedBody["model"] != "claude-sonnet-4-20250514" {
		t.Errorf("model=%v, want claude-sonnet-4-20250514", receivedBody["model"])
	}
	if receivedBody["stream"] != false {
		t.Errorf("stream=%v, want false for Complete", receivedBody["stream"])
	}
	if receivedBody["system"] != "Be brief" {
		t.Errorf("system=%v, want 'Be brief'", receivedBody["system"])
	}
}

// --- OpenRouter Complete ---

func TestCompleteOpenRouter(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/v1/chat/completions" {
			t.Errorf("openrouter path=%q, want /api/v1/chat/completions", r.URL.Path)
		}
		if r.Header.Get("Authorization") != "Bearer or-key" {
			t.Error("missing bearer auth for openrouter")
		}
		resp := map[string]any{
			"choices": []map[string]any{
				{"message": map[string]any{"content": "Hello from OR"}, "finish_reason": "stop"},
			},
			"model": "anthropic/claude-sonnet-4",
			"usage": map[string]any{"prompt_tokens": 30, "completion_tokens": 8},
		}
		json.NewEncoder(w).Encode(resp)
	}))
	defer server.Close()

	c := NewClient(Config{
		Provider: ProviderOpenRouter,
		APIKey:   "or-key",
		BaseURL:  server.URL,
		Model:    "anthropic/claude-sonnet-4",
	})

	resp, err := c.Complete(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	})
	if err != nil {
		t.Fatal(err)
	}
	if resp.Content != "Hello from OR" {
		t.Errorf("content=%q, want 'Hello from OR'", resp.Content)
	}
}

// --- firstNonZero ---

func TestFirstNonZero(t *testing.T) {
	if got := firstNonZero(5, 10); got != 5 {
		t.Errorf("firstNonZero(5,10)=%d, want 5", got)
	}
	if got := firstNonZero(0, 10); got != 10 {
		t.Errorf("firstNonZero(0,10)=%d, want 10", got)
	}
	if got := firstNonZero(0, 0); got != 0 {
		t.Errorf("firstNonZero(0,0)=%d, want 0", got)
	}
}

// --- MaxTokens fallback ---

func TestCompleteUsesConfigMaxTokens(t *testing.T) {
	var receivedBody map[string]any
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewDecoder(r.Body).Decode(&receivedBody)
		resp := map[string]any{
			"content":     []map[string]any{{"type": "text", "text": "ok"}},
			"stop_reason": "end_turn",
			"model":       "claude-sonnet-4-20250514",
			"usage":       map[string]any{"input_tokens": 1, "output_tokens": 1},
		}
		json.NewEncoder(w).Encode(resp)
	}))
	defer server.Close()

	c := NewClient(Config{
		Provider:  ProviderAnthropic,
		APIKey:    "key",
		BaseURL:   server.URL,
		Model:     "claude-sonnet-4-20250514",
		MaxTokens: 2048,
	})

	// Request has no MaxTokens set; should use config's 2048
	_, err := c.Complete(context.Background(), Request{
		Messages: []Message{{Role: "user", Content: "Hi"}},
	})
	if err != nil {
		t.Fatal(err)
	}
	if receivedBody["max_tokens"] != float64(2048) {
		t.Errorf("max_tokens=%v, want 2048", receivedBody["max_tokens"])
	}
}

func TestCompleteUsesRequestMaxTokensOverConfig(t *testing.T) {
	var receivedBody map[string]any
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewDecoder(r.Body).Decode(&receivedBody)
		resp := map[string]any{
			"content":     []map[string]any{{"type": "text", "text": "ok"}},
			"stop_reason": "end_turn",
			"model":       "claude-sonnet-4-20250514",
			"usage":       map[string]any{"input_tokens": 1, "output_tokens": 1},
		}
		json.NewEncoder(w).Encode(resp)
	}))
	defer server.Close()

	c := NewClient(Config{
		Provider:  ProviderAnthropic,
		APIKey:    "key",
		BaseURL:   server.URL,
		Model:     "claude-sonnet-4-20250514",
		MaxTokens: 2048,
	})

	// Request sets MaxTokens=512, should override config
	_, err := c.Complete(context.Background(), Request{
		Messages:  []Message{{Role: "user", Content: "Hi"}},
		MaxTokens: 512,
	})
	if err != nil {
		t.Fatal(err)
	}
	if receivedBody["max_tokens"] != float64(512) {
		t.Errorf("max_tokens=%v, want 512", receivedBody["max_tokens"])
	}
}
