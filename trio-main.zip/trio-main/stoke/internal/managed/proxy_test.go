package managed

import (
	"os"
	"testing"
)

func TestLoadConfigNoKey(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "")
	cfg := LoadConfig()
	if cfg.Enabled {
		t.Error("Enabled should be false when EMBER_API_KEY is empty")
	}
}

func TestLoadConfigWithKey(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key-123")
	t.Setenv("EMBER_API_URL", "https://ember.example.com")
	cfg := LoadConfig()
	if !cfg.Enabled {
		t.Error("Enabled should be true")
	}
	if cfg.APIEndpoint != "https://ember.example.com" {
		t.Errorf("APIEndpoint=%q", cfg.APIEndpoint)
	}
	if cfg.APIKey != "test-key-123" {
		t.Errorf("APIKey=%q", cfg.APIKey)
	}
	if cfg.Markup != 0.20 {
		t.Errorf("Markup=%f, want 0.20", cfg.Markup)
	}
}

func TestLoadConfigDefaultEndpoint(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key")
	t.Setenv("EMBER_API_URL", "")
	cfg := LoadConfig()
	if cfg.APIEndpoint != "https://api.ember.dev" {
		t.Errorf("default endpoint=%q", cfg.APIEndpoint)
	}
}

func TestProxyEnabledTrue(t *testing.T) {
	p := NewProxy(Config{Enabled: true, APIEndpoint: "https://api.ember.dev"})
	if !p.Enabled() {
		t.Error("Enabled() should be true")
	}
}

func TestProxyEnabledFalse(t *testing.T) {
	p := NewProxy(Config{Enabled: false})
	if p.Enabled() {
		t.Error("Enabled() should be false")
	}
}

func TestChatDisabled(t *testing.T) {
	p := NewProxy(Config{Enabled: false})
	_, _, err := p.Chat("model", nil)
	if err == nil {
		t.Error("expected error when disabled")
	}
}

func TestChatSyncDisabled(t *testing.T) {
	p := NewProxy(Config{Enabled: false})
	_, _, err := p.ChatSync("model", nil)
	if err == nil {
		t.Error("expected error when disabled")
	}
}

func TestTotalCostEmpty(t *testing.T) {
	p := NewProxy(Config{Enabled: false})
	cost, markup := p.TotalCost()
	if cost != 0 || markup != 0 {
		t.Errorf("TotalCost()=(%f,%f), want (0,0)", cost, markup)
	}
}

func TestTotalCostAccumulates(t *testing.T) {
	p := &Proxy{
		config: Config{Enabled: true, Markup: 0.20},
		usage: []UsageEvent{
			{CostUSD: 0.05, MarkupUSD: 0.01},
			{CostUSD: 0.10, MarkupUSD: 0.02},
		},
	}
	cost, markup := p.TotalCost()
	if cost < 0.14 || cost > 0.16 {
		t.Errorf("cost=%f, want ~0.15", cost)
	}
	if markup < 0.02 || markup > 0.04 {
		t.Errorf("markup=%f, want ~0.03", markup)
	}
}

func TestFlushUsage(t *testing.T) {
	p := &Proxy{
		config: Config{Enabled: true},
		usage: []UsageEvent{
			{CostUSD: 0.05, Model: "claude-sonnet-4"},
			{CostUSD: 0.10, Model: "claude-sonnet-4"},
		},
	}
	events := p.FlushUsage()
	if len(events) != 2 {
		t.Errorf("FlushUsage()=%d events, want 2", len(events))
	}
	// Second flush should be empty
	events2 := p.FlushUsage()
	if len(events2) != 0 {
		t.Errorf("second FlushUsage()=%d, want 0", len(events2))
	}
}

func TestModelForTaskSecurity(t *testing.T) {
	m := ModelForTask("security")
	if m != "anthropic/claude-sonnet-4" {
		t.Errorf("security=%q", m)
	}
}

func TestModelForTaskPlan(t *testing.T) {
	m := ModelForTask("plan")
	if m != "anthropic/claude-sonnet-4" {
		t.Errorf("plan=%q", m)
	}
}

func TestModelForTaskArchitecture(t *testing.T) {
	m := ModelForTask("architecture")
	if m != "anthropic/claude-sonnet-4" {
		t.Errorf("architecture=%q", m)
	}
}

func TestModelForTaskReview(t *testing.T) {
	m := ModelForTask("review")
	if m != "openai/gpt-4.1" {
		t.Errorf("review=%q", m)
	}
}

func TestModelForTaskDefault(t *testing.T) {
	m := ModelForTask("unknown-task")
	if m != "anthropic/claude-sonnet-4" {
		t.Errorf("default=%q", m)
	}
}

func TestNewProxyHTTPWarning(t *testing.T) {
	// Should not panic, just log a warning
	p := NewProxy(Config{
		Enabled:     true,
		APIEndpoint: "http://insecure.example.com",
		APIKey:      "key",
	})
	if p == nil {
		t.Fatal("NewProxy should not return nil")
	}
}

func TestNewProxyValid(t *testing.T) {
	p := NewProxy(Config{
		Enabled:     true,
		APIEndpoint: "https://secure.example.com",
		APIKey:      "key",
		Markup:      0.20,
	})
	if p == nil {
		t.Fatal("NewProxy should not return nil")
	}
	if p.config.Markup != 0.20 {
		t.Errorf("markup=%f, want 0.20", p.config.Markup)
	}
}

func TestLoadConfigKeyFromEnv(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "env-key-value")
	cfg := LoadConfig()
	if cfg.APIKey != "env-key-value" {
		t.Errorf("APIKey=%q, want env-key-value", cfg.APIKey)
	}
}

func TestLoadConfigKeyFromEnvOverrides(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "key-from-env")
	t.Setenv("EMBER_API_URL", "https://custom.example.com")
	cfg := LoadConfig()
	if cfg.APIEndpoint != "https://custom.example.com" {
		t.Errorf("APIEndpoint=%q", cfg.APIEndpoint)
	}
	if os.Getenv("EMBER_API_KEY") == "" {
		t.Skip("EMBER_API_KEY not set in environment")
	}
}
