package managed

import (
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"
)

// ---------------------------------------------------------------------------
// Proxy creation and HTTP client configuration
// ---------------------------------------------------------------------------

func TestNewProxyClientTimeout(t *testing.T) {
	p := NewProxy(Config{
		Enabled:     true,
		APIEndpoint: "https://api.ember.dev",
		APIKey:      "key",
	})
	if p.client == nil {
		t.Fatal("client should not be nil")
	}
	if p.client.Timeout != 5*time.Minute {
		t.Errorf("client timeout=%v, want 5m", p.client.Timeout)
	}
}

func TestNewProxyStoresConfig(t *testing.T) {
	cfg := Config{
		Enabled:     true,
		APIEndpoint: "https://example.com",
		APIKey:      "secret",
		Markup:      0.35,
	}
	p := NewProxy(cfg)
	if p.config != cfg {
		t.Errorf("config mismatch: got %+v", p.config)
	}
}

func TestNewProxyInitializesEmptyUsage(t *testing.T) {
	p := NewProxy(Config{Enabled: true, APIEndpoint: "https://x.com", APIKey: "k"})
	if p.usage != nil {
		t.Errorf("usage should be nil initially, got len=%d", len(p.usage))
	}
}

// ---------------------------------------------------------------------------
// Chat (streaming SSE) -- success path
// ---------------------------------------------------------------------------

func TestChatStreamingSuccess(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Verify request shape
		if r.Method != "POST" {
			t.Errorf("method=%s, want POST", r.Method)
		}
		if !strings.HasSuffix(r.URL.Path, "/v1/ai/chat") {
			t.Errorf("path=%s, want /v1/ai/chat", r.URL.Path)
		}
		if got := r.Header.Get("Authorization"); got != "Bearer test-key" {
			t.Errorf("Authorization=%q", got)
		}
		if got := r.Header.Get("Content-Type"); got != "application/json" {
			t.Errorf("Content-Type=%q", got)
		}
		if got := r.Header.Get("Accept"); got != "text/event-stream" {
			t.Errorf("Accept=%q", got)
		}

		// Decode body to verify stream=true
		var body map[string]any
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			t.Fatalf("decode request body: %v", err)
		}
		if body["stream"] != true {
			t.Errorf("stream=%v, want true", body["stream"])
		}

		// Send SSE chunks
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		fmt.Fprintln(w, "data: {\"choices\":[{\"delta\":{\"content\":\"Hello\"}}]}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: {\"choices\":[{\"delta\":{\"content\":\" world\"}}]}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: {\"choices\":[],\"usage\":{\"prompt_tokens\":10,\"completion_tokens\":5,\"total_cost\":0.001}}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: [DONE]")
	}))
	defer ts.Close()

	p := NewProxy(Config{
		Enabled:     true,
		APIEndpoint: ts.URL,
		APIKey:      "test-key",
		Markup:      0.25,
	})

	text, usage, err := p.Chat("gpt-4", []Message{{Role: "user", Content: "hi"}})
	if err != nil {
		t.Fatalf("Chat() error: %v", err)
	}
	if text != "Hello world" {
		t.Errorf("text=%q, want %q", text, "Hello world")
	}
	if usage.Model != "gpt-4" {
		t.Errorf("model=%q", usage.Model)
	}
	if usage.InputTokens != 10 {
		t.Errorf("input_tokens=%d, want 10", usage.InputTokens)
	}
	if usage.OutputTokens != 5 {
		t.Errorf("output_tokens=%d, want 5", usage.OutputTokens)
	}
	if math.Abs(usage.CostUSD-0.001) > 1e-9 {
		t.Errorf("cost=%f, want 0.001", usage.CostUSD)
	}
	if math.Abs(usage.MarkupUSD-0.001*0.25) > 1e-9 {
		t.Errorf("markup=%f, want %f", usage.MarkupUSD, 0.001*0.25)
	}
	if usage.Timestamp.IsZero() {
		t.Error("timestamp should not be zero")
	}

	// Verify usage was appended
	cost, markup := p.TotalCost()
	if cost < 0.0009 {
		t.Errorf("TotalCost cost=%f, want >0", cost)
	}
	if markup < 0.0001 {
		t.Errorf("TotalCost markup=%f, want >0", markup)
	}
}

// ---------------------------------------------------------------------------
// Chat -- error responses
// ---------------------------------------------------------------------------

func TestChatHTTP501(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(501)
		fmt.Fprint(w, "not implemented")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k", Markup: 0.2})
	_, _, err := p.Chat("m", []Message{{Role: "user", Content: "hi"}})
	if err == nil {
		t.Fatal("expected error for 501")
	}
	if !strings.Contains(err.Error(), "501") {
		t.Errorf("error should mention 501: %v", err)
	}
	if !strings.Contains(err.Error(), "ENABLE_MANAGED_AI") {
		t.Errorf("error should mention ENABLE_MANAGED_AI: %v", err)
	}
}

func TestChatHTTP500(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(500)
		fmt.Fprint(w, "internal server error")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	_, _, err := p.Chat("m", []Message{{Role: "user", Content: "hi"}})
	if err == nil {
		t.Fatal("expected error for 500")
	}
	if !strings.Contains(err.Error(), "500") {
		t.Errorf("error should mention 500: %v", err)
	}
}

func TestChatHTTP429(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(429)
		fmt.Fprint(w, "rate limited")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	_, _, err := p.Chat("m", nil)
	if err == nil {
		t.Fatal("expected error for 429")
	}
	if !strings.Contains(err.Error(), "429") {
		t.Errorf("error=%v", err)
	}
}

func TestChatBackendUnavailable(t *testing.T) {
	// Connect to a closed server to simulate unavailable backend
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}))
	url := ts.URL
	ts.Close() // close immediately

	p := NewProxy(Config{Enabled: true, APIEndpoint: url, APIKey: "k"})
	_, _, err := p.Chat("m", []Message{{Role: "user", Content: "hi"}})
	if err == nil {
		t.Fatal("expected error for unavailable backend")
	}
}

func TestChatStreamingMalformedJSON(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		// Malformed JSON line -- should be skipped gracefully
		fmt.Fprintln(w, "data: {not valid json}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: {\"choices\":[{\"delta\":{\"content\":\"ok\"}}]}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: [DONE]")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	text, _, err := p.Chat("m", []Message{{Role: "user", Content: "hi"}})
	if err != nil {
		t.Fatalf("Chat() error: %v", err)
	}
	if text != "ok" {
		t.Errorf("text=%q, want %q", text, "ok")
	}
}

func TestChatStreamingNoUsageChunk(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		// No usage chunk -- just content
		fmt.Fprintln(w, "data: {\"choices\":[{\"delta\":{\"content\":\"partial\"}}]}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: [DONE]")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k", Markup: 0.20})
	text, usage, err := p.Chat("m", nil)
	if err != nil {
		t.Fatalf("Chat() error: %v", err)
	}
	if text != "partial" {
		t.Errorf("text=%q", text)
	}
	// Usage should be zero when no usage chunk sent
	if usage.InputTokens != 0 || usage.OutputTokens != 0 {
		t.Errorf("tokens should be zero: input=%d output=%d", usage.InputTokens, usage.OutputTokens)
	}
}

func TestChatStreamingSkipsNonDataLines(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		// Non-data lines (comments, event types)
		fmt.Fprintln(w, ": this is a comment")
		fmt.Fprintln(w, "event: heartbeat")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: {\"choices\":[{\"delta\":{\"content\":\"got it\"}}]}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: [DONE]")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	text, _, err := p.Chat("m", []Message{{Role: "user", Content: "hi"}})
	if err != nil {
		t.Fatalf("Chat() error: %v", err)
	}
	if text != "got it" {
		t.Errorf("text=%q, want %q", text, "got it")
	}
}

func TestChatStreamingMultipleChoicesPerChunk(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		// One chunk with two choices
		fmt.Fprintln(w, `data: {"choices":[{"delta":{"content":"A"}},{"delta":{"content":"B"}}]}`)
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: [DONE]")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	text, _, err := p.Chat("m", nil)
	if err != nil {
		t.Fatalf("error: %v", err)
	}
	if text != "AB" {
		t.Errorf("text=%q, want %q", text, "AB")
	}
}

// ---------------------------------------------------------------------------
// Chat sends messages in request body correctly
// ---------------------------------------------------------------------------

func TestChatRequestBodyMessages(t *testing.T) {
	var receivedModel string
	var receivedMessages []Message
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var body struct {
			Model    string    `json:"model"`
			Messages []Message `json:"messages"`
			Stream   bool      `json:"stream"`
		}
		json.NewDecoder(r.Body).Decode(&body)
		receivedModel = body.Model
		receivedMessages = body.Messages

		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		fmt.Fprintln(w, "data: [DONE]")
	}))
	defer ts.Close()

	msgs := []Message{
		{Role: "system", Content: "you are helpful"},
		{Role: "user", Content: "hello"},
	}
	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	_, _, _ = p.Chat("test-model", msgs)

	if receivedModel != "test-model" {
		t.Errorf("model=%q, want test-model", receivedModel)
	}
	if len(receivedMessages) != 2 {
		t.Fatalf("messages=%d, want 2", len(receivedMessages))
	}
	if receivedMessages[0].Role != "system" || receivedMessages[0].Content != "you are helpful" {
		t.Errorf("msg[0]=%+v", receivedMessages[0])
	}
	if receivedMessages[1].Role != "user" || receivedMessages[1].Content != "hello" {
		t.Errorf("msg[1]=%+v", receivedMessages[1])
	}
}

// ---------------------------------------------------------------------------
// ChatSync -- success path
// ---------------------------------------------------------------------------

func TestChatSyncSuccess(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			t.Errorf("method=%s", r.Method)
		}
		if !strings.HasSuffix(r.URL.Path, "/v1/ai/chat") {
			t.Errorf("path=%s", r.URL.Path)
		}
		if got := r.Header.Get("Authorization"); got != "Bearer sync-key" {
			t.Errorf("Auth=%q", got)
		}

		// Verify stream=false in body
		var body map[string]any
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			t.Fatalf("decode: %v", err)
		}
		if body["stream"] != false {
			t.Errorf("stream=%v, want false", body["stream"])
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{
			"choices": []map[string]any{
				{"message": map[string]any{"content": "sync response"}},
			},
			"usage": map[string]any{
				"prompt_tokens":     20,
				"completion_tokens": 8,
				"total_cost":        0.005,
			},
		})
	}))
	defer ts.Close()

	p := NewProxy(Config{
		Enabled:     true,
		APIEndpoint: ts.URL,
		APIKey:      "sync-key",
		Markup:      0.10,
	})

	text, usage, err := p.ChatSync("claude-3", []Message{{Role: "user", Content: "test"}})
	if err != nil {
		t.Fatalf("ChatSync() error: %v", err)
	}
	if text != "sync response" {
		t.Errorf("text=%q", text)
	}
	if usage.Model != "claude-3" {
		t.Errorf("model=%q", usage.Model)
	}
	if usage.InputTokens != 20 {
		t.Errorf("input=%d, want 20", usage.InputTokens)
	}
	if usage.OutputTokens != 8 {
		t.Errorf("output=%d, want 8", usage.OutputTokens)
	}
	if math.Abs(usage.CostUSD-0.005) > 1e-9 {
		t.Errorf("cost=%f", usage.CostUSD)
	}
	expectedMarkup := 0.005 * 0.10
	if math.Abs(usage.MarkupUSD-expectedMarkup) > 1e-9 {
		t.Errorf("markup=%f, want %f", usage.MarkupUSD, expectedMarkup)
	}
	if usage.Timestamp.IsZero() {
		t.Error("timestamp should not be zero")
	}

	// Usage was appended
	cost, markup := p.TotalCost()
	if cost < 0.004 {
		t.Errorf("TotalCost cost=%f", cost)
	}
	if markup < 0.0004 {
		t.Errorf("TotalCost markup=%f", markup)
	}
}

func TestChatSyncEmptyChoices(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{
			"choices": []map[string]any{},
			"usage": map[string]any{
				"prompt_tokens":     5,
				"completion_tokens": 0,
				"total_cost":        0.0001,
			},
		})
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k", Markup: 0.20})
	text, _, err := p.ChatSync("m", []Message{{Role: "user", Content: "hi"}})
	if err != nil {
		t.Fatalf("ChatSync() error: %v", err)
	}
	if text != "" {
		t.Errorf("text=%q, want empty for no choices", text)
	}
}

// ---------------------------------------------------------------------------
// ChatSync -- error responses
// ---------------------------------------------------------------------------

func TestChatSyncHTTP501(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(501)
		fmt.Fprint(w, "feature disabled")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	_, _, err := p.ChatSync("m", nil)
	if err == nil {
		t.Fatal("expected error for 501")
	}
	if !strings.Contains(err.Error(), "501") || !strings.Contains(err.Error(), "ENABLE_MANAGED_AI") {
		t.Errorf("error=%v", err)
	}
}

func TestChatSyncHTTP403(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(403)
		fmt.Fprint(w, "forbidden")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	_, _, err := p.ChatSync("m", nil)
	if err == nil {
		t.Fatal("expected error for 403")
	}
	if !strings.Contains(err.Error(), "403") {
		t.Errorf("error=%v", err)
	}
}

func TestChatSyncHTTP429(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(429)
		fmt.Fprint(w, "too many requests")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	_, _, err := p.ChatSync("m", nil)
	if err == nil {
		t.Fatal("expected error for 429")
	}
	if !strings.Contains(err.Error(), "429") {
		t.Errorf("error=%v", err)
	}
}

func TestChatSyncBackendUnavailable(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}))
	url := ts.URL
	ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: url, APIKey: "k"})
	_, _, err := p.ChatSync("m", nil)
	if err == nil {
		t.Fatal("expected error for unavailable backend")
	}
}

func TestChatSyncMalformedResponseBody(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(200)
		fmt.Fprint(w, "not json at all")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	_, _, err := p.ChatSync("m", nil)
	if err == nil {
		t.Fatal("expected error for malformed JSON response")
	}
	if !strings.Contains(err.Error(), "decode") {
		t.Errorf("error=%v, want decode error", err)
	}
}

// ---------------------------------------------------------------------------
// ChatSync request body validation
// ---------------------------------------------------------------------------

func TestChatSyncRequestBodyMessages(t *testing.T) {
	var receivedModel string
	var receivedMessages []Message
	var receivedStream bool
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var body struct {
			Model    string    `json:"model"`
			Messages []Message `json:"messages"`
			Stream   bool      `json:"stream"`
		}
		json.NewDecoder(r.Body).Decode(&body)
		receivedModel = body.Model
		receivedMessages = body.Messages
		receivedStream = body.Stream

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{
			"choices": []map[string]any{
				{"message": map[string]any{"content": "ok"}},
			},
			"usage": map[string]any{
				"prompt_tokens": 1, "completion_tokens": 1, "total_cost": 0.0,
			},
		})
	}))
	defer ts.Close()

	msgs := []Message{
		{Role: "system", Content: "sys prompt"},
		{Role: "user", Content: "user msg"},
		{Role: "assistant", Content: "prev response"},
		{Role: "user", Content: "followup"},
	}
	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	_, _, _ = p.ChatSync("my-model", msgs)

	if receivedModel != "my-model" {
		t.Errorf("model=%q", receivedModel)
	}
	if receivedStream != false {
		t.Error("stream should be false for ChatSync")
	}
	if len(receivedMessages) != 4 {
		t.Fatalf("messages=%d, want 4", len(receivedMessages))
	}
	if receivedMessages[2].Role != "assistant" {
		t.Errorf("msg[2].Role=%q", receivedMessages[2].Role)
	}
}

// ---------------------------------------------------------------------------
// ChatSync does not set Accept: text/event-stream (unlike Chat)
// ---------------------------------------------------------------------------

func TestChatSyncDoesNotSetAcceptSSE(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Header.Get("Accept"); got == "text/event-stream" {
			t.Error("ChatSync should not set Accept: text/event-stream")
		}
		if got := r.Header.Get("Content-Type"); got != "application/json" {
			t.Errorf("Content-Type=%q", got)
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{
			"choices": []map[string]any{},
			"usage":   map[string]any{"prompt_tokens": 0, "completion_tokens": 0, "total_cost": 0.0},
		})
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	_, _, _ = p.ChatSync("m", nil)
}

// ---------------------------------------------------------------------------
// FlushUsage preserves ordering and clears buffer
// ---------------------------------------------------------------------------

func TestFlushUsageOrdering(t *testing.T) {
	p := &Proxy{
		config: Config{Enabled: true},
		usage: []UsageEvent{
			{Model: "a", CostUSD: 0.01},
			{Model: "b", CostUSD: 0.02},
			{Model: "c", CostUSD: 0.03},
		},
	}
	events := p.FlushUsage()
	if len(events) != 3 {
		t.Fatalf("len=%d", len(events))
	}
	if events[0].Model != "a" || events[1].Model != "b" || events[2].Model != "c" {
		t.Errorf("ordering wrong: %v", events)
	}
	// Buffer is cleared
	if len(p.FlushUsage()) != 0 {
		t.Error("buffer not cleared")
	}
}

// ---------------------------------------------------------------------------
// Concurrent safety of usage tracking
// ---------------------------------------------------------------------------

func TestChatSyncConcurrentUsageTracking(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{
			"choices": []map[string]any{
				{"message": map[string]any{"content": "ok"}},
			},
			"usage": map[string]any{
				"prompt_tokens":     1,
				"completion_tokens": 1,
				"total_cost":        0.001,
			},
		})
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k", Markup: 0.10})

	var wg sync.WaitGroup
	errs := make([]error, 10)
	n := 10
	wg.Add(n)
	for i := 0; i < n; i++ {
		go func(idx int) {
			defer wg.Done()
			_, _, errs[idx] = p.ChatSync("m", []Message{{Role: "user", Content: "hi"}})
		}(i)
	}
	wg.Wait()

	for i, err := range errs {
		if err != nil {
			t.Errorf("goroutine %d failed: %v", i, err)
		}
	}
	events := p.FlushUsage()
	if len(events) != n {
		t.Errorf("events=%d, want %d", len(events), n)
	}
}

func TestChatConcurrentUsageTracking(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		fmt.Fprintln(w, "data: {\"choices\":[{\"delta\":{\"content\":\"x\"}}],\"usage\":{\"prompt_tokens\":1,\"completion_tokens\":1,\"total_cost\":0.001}}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: [DONE]")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k", Markup: 0.10})

	var wg sync.WaitGroup
	errs := make([]error, 10)
	n := 10
	wg.Add(n)
	for i := 0; i < n; i++ {
		go func(idx int) {
			defer wg.Done()
			_, _, errs[idx] = p.Chat("m", []Message{{Role: "user", Content: "hi"}})
		}(i)
	}
	wg.Wait()

	for i, err := range errs {
		if err != nil {
			t.Errorf("goroutine %d failed: %v", i, err)
		}
	}
	events := p.FlushUsage()
	if len(events) != n {
		t.Errorf("events=%d, want %d", len(events), n)
	}
}

// ---------------------------------------------------------------------------
// TotalCost with multiple ChatSync calls via real HTTP
// ---------------------------------------------------------------------------

func TestTotalCostAfterMultipleChatSyncCalls(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{
			"choices": []map[string]any{
				{"message": map[string]any{"content": "r"}},
			},
			"usage": map[string]any{
				"prompt_tokens":     10,
				"completion_tokens": 5,
				"total_cost":        0.01,
			},
		})
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k", Markup: 0.50})
	for i := 0; i < 3; i++ {
		_, _, err := p.ChatSync("m", []Message{{Role: "user", Content: "hi"}})
		if err != nil {
			t.Fatalf("call %d: %v", i, err)
		}
	}

	cost, markup := p.TotalCost()
	if math.Abs(cost-0.03) > 1e-9 {
		t.Errorf("cost=%f, want 0.03", cost)
	}
	if math.Abs(markup-0.015) > 1e-9 {
		t.Errorf("markup=%f, want 0.015", markup)
	}
}

// ---------------------------------------------------------------------------
// Chat error message text for disabled proxy
// ---------------------------------------------------------------------------

func TestChatDisabledErrorMessage(t *testing.T) {
	p := NewProxy(Config{Enabled: false})
	_, _, err := p.Chat("m", nil)
	if err == nil {
		t.Fatal("expected error")
	}
	if !strings.Contains(err.Error(), "EMBER_API_KEY") {
		t.Errorf("error=%v, should mention EMBER_API_KEY", err)
	}
}

func TestChatSyncDisabledErrorMessage(t *testing.T) {
	p := NewProxy(Config{Enabled: false})
	_, _, err := p.ChatSync("m", nil)
	if err == nil {
		t.Fatal("expected error")
	}
	if !strings.Contains(err.Error(), "not enabled") {
		t.Errorf("error=%v, should mention not enabled", err)
	}
}

// ---------------------------------------------------------------------------
// Chat with usage in final chunk only (common pattern)
// ---------------------------------------------------------------------------

func TestChatStreamingUsageInFinalChunk(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		fmt.Fprintln(w, "data: {\"choices\":[{\"delta\":{\"content\":\"token1 \"}}]}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: {\"choices\":[{\"delta\":{\"content\":\"token2 \"}}]}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: {\"choices\":[{\"delta\":{\"content\":\"token3\"}}]}")
		fmt.Fprintln(w, "")
		// Usage appears in the final data chunk before DONE
		fmt.Fprintln(w, "data: {\"choices\":[],\"usage\":{\"prompt_tokens\":50,\"completion_tokens\":25,\"total_cost\":0.01}}")
		fmt.Fprintln(w, "")
		fmt.Fprintln(w, "data: [DONE]")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k", Markup: 0.20})
	text, usage, err := p.Chat("m", nil)
	if err != nil {
		t.Fatalf("error: %v", err)
	}
	if text != "token1 token2 token3" {
		t.Errorf("text=%q", text)
	}
	if usage.InputTokens != 50 {
		t.Errorf("input=%d", usage.InputTokens)
	}
	if usage.OutputTokens != 25 {
		t.Errorf("output=%d", usage.OutputTokens)
	}
	if math.Abs(usage.CostUSD-0.01) > 1e-9 {
		t.Errorf("cost=%f", usage.CostUSD)
	}
	if math.Abs(usage.MarkupUSD-0.002) > 1e-9 {
		t.Errorf("markup=%f, want 0.002", usage.MarkupUSD)
	}
}

// ---------------------------------------------------------------------------
// Chat with empty stream (immediate DONE)
// ---------------------------------------------------------------------------

func TestChatStreamingEmptyStream(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		fmt.Fprintln(w, "data: [DONE]")
	}))
	defer ts.Close()

	p := NewProxy(Config{Enabled: true, APIEndpoint: ts.URL, APIKey: "k"})
	text, _, err := p.Chat("m", nil)
	if err != nil {
		t.Fatalf("error: %v", err)
	}
	if text != "" {
		t.Errorf("text=%q, want empty", text)
	}
}
