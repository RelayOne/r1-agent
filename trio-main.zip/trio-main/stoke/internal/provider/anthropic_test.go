package provider

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/ericmacdougall/stoke/internal/stream"
)

// ---------------------------------------------------------------------------
// ResolveProvider
// ---------------------------------------------------------------------------

func TestResolveProviderClaude(t *testing.T) {
	p := ResolveProvider("claude-opus-4-6")
	if p.Name() != "anthropic" {
		t.Errorf("expected anthropic, got %s", p.Name())
	}
}

func TestResolveProviderClaudeSonnet(t *testing.T) {
	p := ResolveProvider("claude-sonnet-4-20250514")
	if p.Name() != "anthropic" {
		t.Errorf("expected anthropic, got %s", p.Name())
	}
}

func TestResolveProviderGPT(t *testing.T) {
	p := ResolveProvider("gpt-4.1")
	if p.Name() != "openai" {
		t.Errorf("expected openai, got %s", p.Name())
	}
}

func TestResolveProviderO1(t *testing.T) {
	p := ResolveProvider("o1-preview")
	if p.Name() != "openai" {
		t.Errorf("expected openai for o1 prefix, got %s", p.Name())
	}
}

func TestResolveProviderO3(t *testing.T) {
	p := ResolveProvider("o3-mini")
	if p.Name() != "openai" {
		t.Errorf("expected openai for o3 prefix, got %s", p.Name())
	}
}

func TestResolveProviderGrok(t *testing.T) {
	p := ResolveProvider("grok-3")
	if p.Name() != "xai" {
		t.Errorf("expected xai, got %s", p.Name())
	}
}

func TestResolveProviderOpenRouter(t *testing.T) {
	p := ResolveProvider("anthropic/claude-sonnet-4")
	if p.Name() != "openrouter" {
		t.Errorf("expected openrouter, got %s", p.Name())
	}
}

func TestResolveProviderOpenRouterMeta(t *testing.T) {
	p := ResolveProvider("meta-llama/llama-3-70b")
	if p.Name() != "openrouter" {
		t.Errorf("expected openrouter for slash-delimited model, got %s", p.Name())
	}
}

func TestResolveProviderDefault(t *testing.T) {
	p := ResolveProvider("unknown-model")
	if p.Name() != "anthropic" {
		t.Errorf("expected anthropic default, got %s", p.Name())
	}
}

func TestResolveProviderEmpty(t *testing.T) {
	p := ResolveProvider("")
	if p.Name() != "anthropic" {
		t.Errorf("expected anthropic default for empty model, got %s", p.Name())
	}
}

// ---------------------------------------------------------------------------
// AnthropicProvider: creation and configuration
// ---------------------------------------------------------------------------

func TestNewAnthropicProviderExplicitValues(t *testing.T) {
	p := NewAnthropicProvider("my-key", "https://custom.api.example.com/")
	if p.apiKey != "my-key" {
		t.Errorf("expected apiKey=my-key, got %s", p.apiKey)
	}
	// baseURL should be trimmed of trailing slash
	if p.baseURL != "https://custom.api.example.com" {
		t.Errorf("expected trimmed baseURL, got %s", p.baseURL)
	}
	if p.httpClient == nil {
		t.Error("expected non-nil httpClient")
	}
}

func TestNewAnthropicProviderDefaultBaseURL(t *testing.T) {
	// With empty baseURL and no env var, should default to api.anthropic.com
	p := NewAnthropicProvider("key", "")
	if p.baseURL != "https://api.anthropic.com" {
		t.Errorf("expected default baseURL, got %s", p.baseURL)
	}
}

func TestAnthropicProviderName(t *testing.T) {
	p := NewAnthropicProvider("k", "https://example.com")
	if p.Name() != "anthropic" {
		t.Errorf("expected 'anthropic', got %s", p.Name())
	}
}

// ---------------------------------------------------------------------------
// AnthropicProvider: buildRequestBody
// ---------------------------------------------------------------------------

func TestAnthropicProviderBuildRequestBody(t *testing.T) {
	p := NewAnthropicProvider("test-key", "https://test.api")

	req := ChatRequest{
		Model:     "claude-opus-4-6",
		System:    "You are helpful",
		MaxTokens: 4096,
	}

	body := p.buildRequestBody(req, true)
	if body["stream"] != true {
		t.Error("expected stream=true")
	}
	if body["system"] != "You are helpful" {
		t.Error("expected system prompt")
	}
	if body["model"] != "claude-opus-4-6" {
		t.Error("expected model")
	}
}

func TestBuildRequestBodyNoStream(t *testing.T) {
	p := NewAnthropicProvider("key", "https://api")
	body := p.buildRequestBody(ChatRequest{
		Model:     "claude-sonnet-4-20250514",
		MaxTokens: 1024,
	}, false)

	if _, ok := body["stream"]; ok {
		t.Error("stream should not be set when streaming=false")
	}
	if body["max_tokens"] != 1024 {
		t.Errorf("expected max_tokens=1024, got %v", body["max_tokens"])
	}
}

func TestBuildRequestBodyOmitsEmptySystem(t *testing.T) {
	p := NewAnthropicProvider("key", "https://api")
	body := p.buildRequestBody(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
		System:    "",
	}, false)

	if _, ok := body["system"]; ok {
		t.Error("system should not be present when empty")
	}
}

func TestBuildRequestBodyWithTemperature(t *testing.T) {
	p := NewAnthropicProvider("key", "https://api")
	temp := 0.7
	body := p.buildRequestBody(ChatRequest{
		Model:       "claude-opus-4-6",
		MaxTokens:   100,
		Temperature: &temp,
	}, false)

	if body["temperature"] != 0.7 {
		t.Errorf("expected temperature=0.7, got %v", body["temperature"])
	}
}

func TestBuildRequestBodyOmitsNilTemperature(t *testing.T) {
	p := NewAnthropicProvider("key", "https://api")
	body := p.buildRequestBody(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
	}, false)

	if _, ok := body["temperature"]; ok {
		t.Error("temperature should not be present when nil")
	}
}

func TestBuildRequestBodyWithTools(t *testing.T) {
	p := NewAnthropicProvider("key", "https://api")
	body := p.buildRequestBody(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
		Tools: []ToolDef{
			{Name: "read_file", Description: "Read a file", InputSchema: json.RawMessage(`{"type":"object"}`)},
		},
	}, false)

	tools, ok := body["tools"].([]ToolDef)
	if !ok {
		t.Fatal("tools should be present")
	}
	if len(tools) != 1 || tools[0].Name != "read_file" {
		t.Errorf("unexpected tools: %+v", tools)
	}
}

func TestBuildRequestBodyOmitsEmptyTools(t *testing.T) {
	p := NewAnthropicProvider("key", "https://api")
	body := p.buildRequestBody(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
	}, false)

	if _, ok := body["tools"]; ok {
		t.Error("tools should not be present when empty")
	}
}

func TestBuildRequestBodyWithMessages(t *testing.T) {
	p := NewAnthropicProvider("key", "https://api")
	body := p.buildRequestBody(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
		Messages: []ChatMessage{
			{Role: "user", Content: json.RawMessage(`"Hello"`)},
			{Role: "assistant", Content: json.RawMessage(`"Hi there"`)},
		},
	}, false)

	msgs, ok := body["messages"].([]ChatMessage)
	if !ok {
		t.Fatal("messages should be present")
	}
	if len(msgs) != 2 {
		t.Errorf("expected 2 messages, got %d", len(msgs))
	}
}

// ---------------------------------------------------------------------------
// AnthropicProvider: setHeaders
// ---------------------------------------------------------------------------

func TestSetHeaders(t *testing.T) {
	p := NewAnthropicProvider("secret-key", "https://api")
	req, _ := http.NewRequest("POST", "https://api/v1/messages", nil)
	p.setHeaders(req)

	if got := req.Header.Get("Content-Type"); got != "application/json" {
		t.Errorf("expected Content-Type=application/json, got %s", got)
	}
	if got := req.Header.Get("x-api-key"); got != "secret-key" {
		t.Errorf("expected x-api-key=secret-key, got %s", got)
	}
	if got := req.Header.Get("anthropic-version"); got != "2023-06-01" {
		t.Errorf("expected anthropic-version=2023-06-01, got %s", got)
	}
}

// ---------------------------------------------------------------------------
// AnthropicProvider: Chat via httptest
// ---------------------------------------------------------------------------

func TestAnthropicChatSuccess(t *testing.T) {
	respBody := ChatResponse{
		ID:    "msg_123",
		Model: "claude-opus-4-6",
		Content: []ResponseContent{
			{Type: "text", Text: "Hello!"},
		},
		StopReason: "end_turn",
		Usage:      stream.TokenUsage{Input: 10, Output: 5},
	}
	respJSON, _ := json.Marshal(respBody)

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Validate method and path
		if r.Method != "POST" {
			t.Errorf("expected POST, got %s", r.Method)
		}
		if r.URL.Path != "/v1/messages" {
			t.Errorf("expected /v1/messages, got %s", r.URL.Path)
		}
		// Validate headers
		if r.Header.Get("x-api-key") != "test-api-key" {
			t.Errorf("expected x-api-key=test-api-key, got %s", r.Header.Get("x-api-key"))
		}
		if r.Header.Get("anthropic-version") != "2023-06-01" {
			t.Errorf("missing anthropic-version header")
		}
		// Validate request body
		body, _ := io.ReadAll(r.Body)
		var reqBody map[string]interface{}
		json.Unmarshal(body, &reqBody)
		if reqBody["model"] != "claude-opus-4-6" {
			t.Errorf("expected model=claude-opus-4-6 in body, got %v", reqBody["model"])
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(200)
		w.Write(respJSON)
	}))
	defer srv.Close()

	p := NewAnthropicProvider("test-api-key", srv.URL)
	resp, err := p.Chat(ChatRequest{
		Model:     "claude-opus-4-6",
		System:    "Be helpful",
		MaxTokens: 1024,
		Messages: []ChatMessage{
			{Role: "user", Content: json.RawMessage(`"What is 2+2?"`)},
		},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if resp.ID != "msg_123" {
		t.Errorf("expected ID=msg_123, got %s", resp.ID)
	}
	if len(resp.Content) != 1 || resp.Content[0].Text != "Hello!" {
		t.Errorf("unexpected content: %+v", resp.Content)
	}
	if resp.StopReason != "end_turn" {
		t.Errorf("expected stop_reason=end_turn, got %s", resp.StopReason)
	}
	if resp.Usage.Input != 10 || resp.Usage.Output != 5 {
		t.Errorf("unexpected usage: %+v", resp.Usage)
	}
}

func TestAnthropicChatAPIError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(401)
		w.Write([]byte(`{"error":{"type":"authentication_error","message":"invalid api key"}}`))
	}))
	defer srv.Close()

	p := NewAnthropicProvider("bad-key", srv.URL)
	_, err := p.Chat(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
		Messages: []ChatMessage{
			{Role: "user", Content: json.RawMessage(`"hello"`)},
		},
	})
	if err == nil {
		t.Fatal("expected error for 401 response")
	}
	if !strings.Contains(err.Error(), "401") {
		t.Errorf("error should mention status code 401, got: %s", err.Error())
	}
	if !strings.Contains(err.Error(), "authentication_error") {
		t.Errorf("error should contain response body, got: %s", err.Error())
	}
}

func TestAnthropicChatServerError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(500)
		w.Write([]byte(`{"error":{"type":"server_error","message":"internal error"}}`))
	}))
	defer srv.Close()

	p := NewAnthropicProvider("key", srv.URL)
	_, err := p.Chat(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	})
	if err == nil {
		t.Fatal("expected error for 500 response")
	}
	if !strings.Contains(err.Error(), "500") {
		t.Errorf("error should mention 500, got: %s", err.Error())
	}
}

func TestAnthropicChatRateLimitError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(429)
		w.Write([]byte(`{"error":{"type":"rate_limit_error","message":"too many requests"}}`))
	}))
	defer srv.Close()

	p := NewAnthropicProvider("key", srv.URL)
	_, err := p.Chat(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	})
	if err == nil {
		t.Fatal("expected error for 429 response")
	}
	if !strings.Contains(err.Error(), "429") {
		t.Errorf("error should mention 429, got: %s", err.Error())
	}
}

func TestAnthropicChatMalformedResponse(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(200)
		w.Write([]byte(`{invalid json`))
	}))
	defer srv.Close()

	p := NewAnthropicProvider("key", srv.URL)
	_, err := p.Chat(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	})
	if err == nil {
		t.Fatal("expected error for malformed JSON response")
	}
	if !strings.Contains(err.Error(), "decode response") {
		t.Errorf("expected decode error, got: %s", err.Error())
	}
}

// ---------------------------------------------------------------------------
// AnthropicProvider: ChatStream via httptest
// ---------------------------------------------------------------------------

func TestAnthropicChatStreamSuccess(t *testing.T) {
	ssePayload := strings.Join([]string{
		"event: message_start",
		`data: {"type":"message_start","message":{"id":"msg_s1","model":"claude-opus-4-6","usage":{"input_tokens":15,"output_tokens":0}}}`,
		"",
		"event: content_block_delta",
		`data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"Hello "}}`,
		"",
		"event: content_block_delta",
		`data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"world!"}}`,
		"",
		"event: message_delta",
		`data: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":8}}`,
		"",
		"event: message_stop",
		`data: {"type":"message_stop"}`,
		"",
	}, "\n")

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Accept") != "text/event-stream" {
			t.Errorf("expected Accept=text/event-stream, got %s", r.Header.Get("Accept"))
		}
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		w.Write([]byte(ssePayload))
	}))
	defer srv.Close()

	p := NewAnthropicProvider("key", srv.URL)

	var events []stream.Event
	resp, err := p.ChatStream(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	}, func(ev stream.Event) {
		events = append(events, ev)
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	// Should have accumulated text
	foundText := false
	for _, c := range resp.Content {
		if c.Type == "text" && c.Text != "" {
			foundText = true
		}
	}
	if !foundText {
		t.Error("expected text content in response")
	}

	// Events should have been dispatched
	if len(events) == 0 {
		t.Error("expected at least one event callback")
	}
}

func TestAnthropicChatStreamAPIError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(503)
		w.Write([]byte(`{"error":{"type":"overloaded_error","message":"overloaded"}}`))
	}))
	defer srv.Close()

	p := NewAnthropicProvider("key", srv.URL)
	_, err := p.ChatStream(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	}, nil)
	if err == nil {
		t.Fatal("expected error for 503 response")
	}
	if !strings.Contains(err.Error(), "503") {
		t.Errorf("error should mention 503, got: %s", err.Error())
	}
}

func TestAnthropicChatStreamNilCallback(t *testing.T) {
	ssePayload := strings.Join([]string{
		"event: content_block_delta",
		`data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"ok"}}`,
		"",
	}, "\n")

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		w.Write([]byte(ssePayload))
	}))
	defer srv.Close()

	p := NewAnthropicProvider("key", srv.URL)
	// Pass nil onEvent -- should not panic
	resp, err := p.ChatStream(ChatRequest{
		Model:     "claude-opus-4-6",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	}, nil)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if resp == nil {
		t.Fatal("expected non-nil response even with nil callback")
	}
}

// ---------------------------------------------------------------------------
// OpenAICompatProvider: creation and configuration
// ---------------------------------------------------------------------------

func TestNewOpenAICompatProviderFields(t *testing.T) {
	p := NewOpenAICompatProvider("myProvider", "api-key-123", "https://api.example.com/")
	if p.name != "myProvider" {
		t.Errorf("expected name=myProvider, got %s", p.name)
	}
	if p.apiKey != "api-key-123" {
		t.Errorf("expected apiKey=api-key-123, got %s", p.apiKey)
	}
	if p.baseURL != "https://api.example.com" {
		t.Errorf("expected trimmed baseURL, got %s", p.baseURL)
	}
	if p.httpClient == nil {
		t.Error("expected non-nil httpClient")
	}
}

func TestOpenAICompatProviderName(t *testing.T) {
	p := NewOpenAICompatProvider("xai", "k", "https://api.x.ai")
	if p.Name() != "xai" {
		t.Errorf("expected 'xai', got %s", p.Name())
	}
}

// ---------------------------------------------------------------------------
// OpenAICompatProvider: convertMessages
// ---------------------------------------------------------------------------

func TestOpenAICompatProviderConvertMessages(t *testing.T) {
	p := NewOpenAICompatProvider("test", "key", "https://test")

	req := ChatRequest{
		System: "system prompt",
		Messages: []ChatMessage{
			{Role: "user", Content: []byte(`"hello"`)},
		},
	}

	msgs := p.convertMessages(req)
	if len(msgs) != 2 {
		t.Fatalf("expected 2 messages (system + user), got %d", len(msgs))
	}
	if msgs[0]["role"] != "system" {
		t.Error("first message should be system")
	}
}

func TestConvertMessagesNoSystem(t *testing.T) {
	p := NewOpenAICompatProvider("test", "key", "https://test")
	msgs := p.convertMessages(ChatRequest{
		Messages: []ChatMessage{
			{Role: "user", Content: json.RawMessage(`"hello"`)},
		},
	})
	if len(msgs) != 1 {
		t.Fatalf("expected 1 message (no system), got %d", len(msgs))
	}
	if msgs[0]["role"] != "user" {
		t.Errorf("expected role=user, got %v", msgs[0]["role"])
	}
}

func TestConvertMessagesMultiple(t *testing.T) {
	p := NewOpenAICompatProvider("test", "key", "https://test")
	msgs := p.convertMessages(ChatRequest{
		System: "sys",
		Messages: []ChatMessage{
			{Role: "user", Content: json.RawMessage(`"first"`)},
			{Role: "assistant", Content: json.RawMessage(`"reply"`)},
			{Role: "user", Content: json.RawMessage(`"second"`)},
		},
	})
	if len(msgs) != 4 {
		t.Fatalf("expected 4 messages (system + 3), got %d", len(msgs))
	}
}

func TestConvertMessagesEmpty(t *testing.T) {
	p := NewOpenAICompatProvider("test", "key", "https://test")
	msgs := p.convertMessages(ChatRequest{})
	if msgs != nil {
		t.Errorf("expected nil for no system and no messages, got %v", msgs)
	}
}

// ---------------------------------------------------------------------------
// OpenAICompatProvider: Chat via httptest
// ---------------------------------------------------------------------------

func TestOpenAIChatSuccess(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			t.Errorf("expected POST, got %s", r.Method)
		}
		if r.URL.Path != "/v1/chat/completions" {
			t.Errorf("expected /v1/chat/completions, got %s", r.URL.Path)
		}
		if r.Header.Get("Authorization") != "Bearer test-key" {
			t.Errorf("expected Bearer auth header, got %s", r.Header.Get("Authorization"))
		}

		// Validate request body
		body, _ := io.ReadAll(r.Body)
		var reqBody map[string]interface{}
		json.Unmarshal(body, &reqBody)
		if reqBody["model"] != "gpt-4.1" {
			t.Errorf("expected model=gpt-4.1 in body, got %v", reqBody["model"])
		}

		resp := `{
			"id": "chatcmpl-abc",
			"model": "gpt-4.1",
			"choices": [{
				"message": {"content": "42"},
				"finish_reason": "stop"
			}],
			"usage": {
				"prompt_tokens": 20,
				"completion_tokens": 3
			}
		}`
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(200)
		w.Write([]byte(resp))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("openai", "test-key", srv.URL)
	resp, err := p.Chat(ChatRequest{
		Model:     "gpt-4.1",
		System:    "Answer concisely",
		MaxTokens: 100,
		Messages: []ChatMessage{
			{Role: "user", Content: json.RawMessage(`"What is 6*7?"`)},
		},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if resp.ID != "chatcmpl-abc" {
		t.Errorf("expected ID=chatcmpl-abc, got %s", resp.ID)
	}
	if resp.Model != "gpt-4.1" {
		t.Errorf("expected model=gpt-4.1, got %s", resp.Model)
	}
	if len(resp.Content) != 1 || resp.Content[0].Text != "42" {
		t.Errorf("unexpected content: %+v", resp.Content)
	}
	if resp.StopReason != "stop" {
		t.Errorf("expected stop_reason=stop, got %s", resp.StopReason)
	}
	if resp.Usage.Input != 20 || resp.Usage.Output != 3 {
		t.Errorf("unexpected usage: %+v", resp.Usage)
	}
}

func TestOpenAIChatNoChoices(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		resp := `{"id":"chatcmpl-x","model":"gpt-4.1","choices":[],"usage":{"prompt_tokens":5,"completion_tokens":0}}`
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(200)
		w.Write([]byte(resp))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("openai", "key", srv.URL)
	resp, err := p.Chat(ChatRequest{
		Model:     "gpt-4.1",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	// No choices means no content
	if len(resp.Content) != 0 {
		t.Errorf("expected empty content for no choices, got %+v", resp.Content)
	}
}

func TestOpenAIChatAPIError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(401)
		w.Write([]byte(`{"error":{"message":"Incorrect API key","type":"invalid_request_error"}}`))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("openai", "bad-key", srv.URL)
	_, err := p.Chat(ChatRequest{
		Model:     "gpt-4.1",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	})
	if err == nil {
		t.Fatal("expected error for 401 response")
	}
	if !strings.Contains(err.Error(), "openai") {
		t.Errorf("error should mention provider name, got: %s", err.Error())
	}
	if !strings.Contains(err.Error(), "401") {
		t.Errorf("error should mention 401, got: %s", err.Error())
	}
}

func TestOpenAIChatServerError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(500)
		w.Write([]byte(`server error`))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("xai", "key", srv.URL)
	_, err := p.Chat(ChatRequest{
		Model:     "grok-3",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	})
	if err == nil {
		t.Fatal("expected error for 500 response")
	}
	if !strings.Contains(err.Error(), "xai") {
		t.Errorf("error should mention provider name 'xai', got: %s", err.Error())
	}
}

func TestOpenAIChatMalformedResponse(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(200)
		w.Write([]byte(`not json at all`))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("openai", "key", srv.URL)
	_, err := p.Chat(ChatRequest{
		Model:     "gpt-4.1",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	})
	if err == nil {
		t.Fatal("expected error for malformed JSON response")
	}
}

func TestOpenAIChatWithTemperature(t *testing.T) {
	var receivedTemp float64
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		var reqBody map[string]interface{}
		json.Unmarshal(body, &reqBody)
		if t, ok := reqBody["temperature"].(float64); ok {
			receivedTemp = t
		}
		resp := `{"id":"x","model":"gpt-4.1","choices":[{"message":{"content":"ok"},"finish_reason":"stop"}],"usage":{"prompt_tokens":1,"completion_tokens":1}}`
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(200)
		w.Write([]byte(resp))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("openai", "key", srv.URL)
	temp := 0.3
	_, err := p.Chat(ChatRequest{
		Model:       "gpt-4.1",
		MaxTokens:   50,
		Messages:    []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
		Temperature: &temp,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if receivedTemp != 0.3 {
		t.Errorf("expected temperature=0.3, got %v", receivedTemp)
	}
}

// ---------------------------------------------------------------------------
// OpenAICompatProvider: ChatStream via httptest
// ---------------------------------------------------------------------------

func TestOpenAIChatStreamSuccess(t *testing.T) {
	ssePayload := strings.Join([]string{
		`data: {"choices":[{"delta":{"content":"Hello"},"finish_reason":null}]}`,
		`data: {"choices":[{"delta":{"content":" world"},"finish_reason":null}]}`,
		`data: {"choices":[{"delta":{"content":""},"finish_reason":"stop"}]}`,
		"data: [DONE]",
		"",
	}, "\n")

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Accept") != "text/event-stream" {
			t.Errorf("expected Accept=text/event-stream, got %s", r.Header.Get("Accept"))
		}
		if r.Header.Get("Authorization") != "Bearer stream-key" {
			t.Errorf("expected Bearer stream-key, got %s", r.Header.Get("Authorization"))
		}

		// Validate stream=true in request body
		body, _ := io.ReadAll(r.Body)
		var reqBody map[string]interface{}
		json.Unmarshal(body, &reqBody)
		if reqBody["stream"] != true {
			t.Errorf("expected stream=true in request body")
		}

		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		w.Write([]byte(ssePayload))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("openai", "stream-key", srv.URL)

	var events []stream.Event
	resp, err := p.ChatStream(ChatRequest{
		Model:     "gpt-4.1",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	}, func(ev stream.Event) {
		events = append(events, ev)
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	// Should have accumulated text
	if len(resp.Content) != 1 || resp.Content[0].Text != "Hello world" {
		t.Errorf("expected 'Hello world', got %+v", resp.Content)
	}
	if resp.StopReason != "stop" {
		t.Errorf("expected stop_reason=stop, got %s", resp.StopReason)
	}

	// Events should have been dispatched
	if len(events) != 2 {
		t.Errorf("expected 2 events (for non-empty deltas), got %d", len(events))
	}
	for _, ev := range events {
		if ev.DeltaType != "text_delta" {
			t.Errorf("expected DeltaType=text_delta, got %s", ev.DeltaType)
		}
	}
}

func TestOpenAIChatStreamAPIError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(429)
		w.Write([]byte(`rate limited`))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("openai", "key", srv.URL)
	_, err := p.ChatStream(ChatRequest{
		Model:     "gpt-4.1",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	}, nil)
	if err == nil {
		t.Fatal("expected error for 429 response")
	}
	if !strings.Contains(err.Error(), "429") {
		t.Errorf("error should mention 429, got: %s", err.Error())
	}
}

func TestOpenAIChatStreamNilCallback(t *testing.T) {
	ssePayload := strings.Join([]string{
		`data: {"choices":[{"delta":{"content":"ok"},"finish_reason":null}]}`,
		"data: [DONE]",
		"",
	}, "\n")

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		w.Write([]byte(ssePayload))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("openai", "key", srv.URL)
	// nil callback -- should not panic
	resp, err := p.ChatStream(ChatRequest{
		Model:     "gpt-4.1",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	}, nil)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if resp == nil {
		t.Fatal("expected non-nil response")
	}
	if len(resp.Content) != 1 || resp.Content[0].Text != "ok" {
		t.Errorf("expected text=ok, got %+v", resp.Content)
	}
}

func TestOpenAIChatStreamMalformedChunk(t *testing.T) {
	// Includes a malformed JSON chunk that should be skipped gracefully
	ssePayload := strings.Join([]string{
		`data: {"choices":[{"delta":{"content":"start"},"finish_reason":null}]}`,
		`data: {bad json`,
		`data: {"choices":[{"delta":{"content":" end"},"finish_reason":null}]}`,
		"data: [DONE]",
		"",
	}, "\n")

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		w.Write([]byte(ssePayload))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("openai", "key", srv.URL)
	resp, err := p.ChatStream(ChatRequest{
		Model:     "gpt-4.1",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	}, nil)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	// Malformed chunk should be skipped, good chunks kept
	if len(resp.Content) != 1 || resp.Content[0].Text != "start end" {
		t.Errorf("expected 'start end', got %+v", resp.Content)
	}
}

func TestOpenAIChatStreamIgnoresNonDataLines(t *testing.T) {
	ssePayload := strings.Join([]string{
		": this is a comment",
		"event: message",
		`data: {"choices":[{"delta":{"content":"text"},"finish_reason":null}]}`,
		"id: 12345",
		"retry: 1000",
		"data: [DONE]",
		"",
	}, "\n")

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		w.WriteHeader(200)
		w.Write([]byte(ssePayload))
	}))
	defer srv.Close()

	p := NewOpenAICompatProvider("openai", "key", srv.URL)
	resp, err := p.ChatStream(ChatRequest{
		Model:     "gpt-4.1",
		MaxTokens: 100,
		Messages:  []ChatMessage{{Role: "user", Content: json.RawMessage(`"hi"`)}},
	}, nil)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(resp.Content) != 1 || resp.Content[0].Text != "text" {
		t.Errorf("expected 'text', got %+v", resp.Content)
	}
}

// ---------------------------------------------------------------------------
// Provider interface compliance
// ---------------------------------------------------------------------------

func TestAnthropicImplementsProvider(t *testing.T) {
	var _ Provider = (*AnthropicProvider)(nil)
}

func TestOpenAICompatImplementsProvider(t *testing.T) {
	var _ Provider = (*OpenAICompatProvider)(nil)
}

// ---------------------------------------------------------------------------
// JSON serialization of types
// ---------------------------------------------------------------------------

func TestChatRequestJSON(t *testing.T) {
	temp := 0.5
	req := ChatRequest{
		Model:       "claude-opus-4-6",
		System:      "test",
		MaxTokens:   2048,
		Temperature: &temp,
		Messages: []ChatMessage{
			{Role: "user", Content: json.RawMessage(`"hello"`)},
		},
		Tools: []ToolDef{
			{Name: "tool1", Description: "desc", InputSchema: json.RawMessage(`{"type":"object"}`)},
		},
		Metadata: map[string]string{"key": "value"},
	}

	data, err := json.Marshal(req)
	if err != nil {
		t.Fatalf("failed to marshal ChatRequest: %v", err)
	}

	var decoded map[string]interface{}
	if err := json.Unmarshal(data, &decoded); err != nil {
		t.Fatalf("failed to unmarshal: %v", err)
	}

	// Metadata should not appear (json:"-")
	if _, ok := decoded["metadata"]; ok {
		t.Error("metadata should not be serialized (has json:\"-\" tag)")
	}
	if decoded["model"] != "claude-opus-4-6" {
		t.Errorf("expected model=claude-opus-4-6, got %v", decoded["model"])
	}
}

func TestChatResponseJSON(t *testing.T) {
	resp := ChatResponse{
		ID:    "msg_test",
		Model: "claude-opus-4-6",
		Content: []ResponseContent{
			{Type: "text", Text: "hello"},
			{Type: "tool_use", ID: "tu_1", Name: "read", Input: map[string]interface{}{"path": "/tmp"}},
		},
		StopReason: "end_turn",
		Usage:      stream.TokenUsage{Input: 100, Output: 50},
	}

	data, err := json.Marshal(resp)
	if err != nil {
		t.Fatalf("failed to marshal ChatResponse: %v", err)
	}

	var decoded ChatResponse
	if err := json.Unmarshal(data, &decoded); err != nil {
		t.Fatalf("failed to unmarshal: %v", err)
	}
	if decoded.ID != "msg_test" {
		t.Errorf("expected ID=msg_test, got %s", decoded.ID)
	}
	if len(decoded.Content) != 2 {
		t.Fatalf("expected 2 content blocks, got %d", len(decoded.Content))
	}
	if decoded.Content[1].Name != "read" {
		t.Errorf("expected tool name=read, got %s", decoded.Content[1].Name)
	}
}
