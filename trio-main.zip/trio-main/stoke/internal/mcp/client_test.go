package mcp

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestConfigFromFile(t *testing.T) {
	dir := t.TempDir()
	configPath := filepath.Join(dir, "mcp.json")

	config := `{
		"mcpServers": {
			"filesystem": {
				"command": "npx",
				"args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
				"env": {"NODE_ENV": "production"}
			},
			"github": {
				"command": "npx",
				"args": ["-y", "@modelcontextprotocol/server-github"],
				"env": {"GITHUB_TOKEN": "test"}
			}
		}
	}`
	if err := os.WriteFile(configPath, []byte(config), 0644); err != nil {
		t.Fatal(err)
	}

	configs, err := ConfigFromFile(configPath)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(configs) != 2 {
		t.Fatalf("expected 2 configs, got %d", len(configs))
	}

	// Find filesystem config
	found := false
	for _, c := range configs {
		if c.Name == "filesystem" {
			found = true
			if c.Command != "npx" {
				t.Errorf("expected npx, got %s", c.Command)
			}
			if len(c.Args) != 3 {
				t.Errorf("expected 3 args, got %d", len(c.Args))
			}
			if c.Env["NODE_ENV"] != "production" {
				t.Errorf("expected production, got %s", c.Env["NODE_ENV"])
			}
		}
	}
	if !found {
		t.Error("filesystem config not found")
	}
}

func TestConfigFromFileMissing(t *testing.T) {
	configs, err := ConfigFromFile("/nonexistent/path.json")
	if err != nil {
		t.Fatalf("expected nil error for missing file, got %v", err)
	}
	if configs != nil {
		t.Errorf("expected nil configs, got %v", configs)
	}
}

func TestEmptyConfigPath(t *testing.T) {
	dir := t.TempDir()
	path, err := EmptyConfigPath(dir)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("cannot read: %v", err)
	}
	if string(data) != "{}" {
		t.Errorf("expected empty JSON, got %s", string(data))
	}
}

// ---------------------------------------------------------------------------
// 1. StdioClient creation with various configs
// ---------------------------------------------------------------------------

func TestNewStdioClient_DisabledConfig(t *testing.T) {
	cfg := ServerConfig{
		Name:    "disabled-server",
		Command: "echo",
		Enabled: false,
	}
	client, err := NewStdioClient(cfg)
	if err == nil {
		t.Fatal("expected error for disabled config, got nil")
	}
	if client != nil {
		t.Fatal("expected nil client for disabled config")
	}
	if !strings.Contains(err.Error(), "disabled") {
		t.Errorf("error should mention 'disabled', got: %v", err)
	}
	if !strings.Contains(err.Error(), "disabled-server") {
		t.Errorf("error should mention server name, got: %v", err)
	}
}

func TestNewStdioClient_InvalidCommand(t *testing.T) {
	cfg := ServerConfig{
		Name:    "bad-server",
		Command: "/nonexistent/binary/that/does/not/exist",
		Enabled: true,
	}
	client, err := NewStdioClient(cfg)
	if err == nil {
		if client != nil {
			client.Close()
		}
		t.Fatal("expected error for nonexistent command, got nil")
	}
}

func TestServerConfig_JSONRoundTrip(t *testing.T) {
	cfg := ServerConfig{
		Name:    "test-server",
		Command: "npx",
		Args:    []string{"-y", "@mcp/server", "/tmp"},
		Env:     map[string]string{"KEY": "val", "OTHER": "val2"},
		Enabled: true,
	}
	data, err := json.Marshal(cfg)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}

	var decoded ServerConfig
	if err := json.Unmarshal(data, &decoded); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if decoded.Name != cfg.Name {
		t.Errorf("name: got %q, want %q", decoded.Name, cfg.Name)
	}
	if decoded.Command != cfg.Command {
		t.Errorf("command: got %q, want %q", decoded.Command, cfg.Command)
	}
	if len(decoded.Args) != len(cfg.Args) {
		t.Fatalf("args length: got %d, want %d", len(decoded.Args), len(cfg.Args))
	}
	for i, a := range decoded.Args {
		if a != cfg.Args[i] {
			t.Errorf("arg[%d]: got %q, want %q", i, a, cfg.Args[i])
		}
	}
	if decoded.Env["KEY"] != "val" {
		t.Errorf("env KEY: got %q, want %q", decoded.Env["KEY"], "val")
	}
	if !decoded.Enabled {
		t.Error("expected Enabled to be true")
	}
}

func TestServerConfig_JSONOmitEmpty(t *testing.T) {
	cfg := ServerConfig{
		Name:    "minimal",
		Command: "echo",
		Enabled: true,
	}
	data, err := json.Marshal(cfg)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	s := string(data)
	if strings.Contains(s, `"args"`) {
		t.Errorf("nil Args should be omitted, got: %s", s)
	}
	if strings.Contains(s, `"env"`) {
		t.Errorf("nil Env should be omitted, got: %s", s)
	}
}

// ---------------------------------------------------------------------------
// 2. Config generation / settings file writing
// ---------------------------------------------------------------------------

func TestConfigFromFile_EmptyServers(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "mcp.json")
	if err := os.WriteFile(path, []byte(`{"mcpServers": {}}`), 0644); err != nil {
		t.Fatal(err)
	}
	configs, err := ConfigFromFile(path)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(configs) != 0 {
		t.Errorf("expected 0 configs, got %d", len(configs))
	}
}

func TestConfigFromFile_MalformedJSON(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "bad.json")
	if err := os.WriteFile(path, []byte(`{not json`), 0644); err != nil {
		t.Fatal(err)
	}
	_, err := ConfigFromFile(path)
	if err == nil {
		t.Fatal("expected error for malformed JSON")
	}
	if !strings.Contains(err.Error(), "parse MCP config") {
		t.Errorf("expected 'parse MCP config' in error, got: %v", err)
	}
}

func TestConfigFromFile_NoMcpServersKey(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "empty.json")
	if err := os.WriteFile(path, []byte(`{"other": "stuff"}`), 0644); err != nil {
		t.Fatal(err)
	}
	configs, err := ConfigFromFile(path)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(configs) != 0 {
		t.Errorf("expected 0 configs when mcpServers missing, got %d", len(configs))
	}
}

func TestConfigFromFile_ServerWithNoArgs(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "mcp.json")
	config := `{"mcpServers": {"simple": {"command": "my-tool"}}}`
	if err := os.WriteFile(path, []byte(config), 0644); err != nil {
		t.Fatal(err)
	}
	configs, err := ConfigFromFile(path)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(configs) != 1 {
		t.Fatalf("expected 1 config, got %d", len(configs))
	}
	if configs[0].Command != "my-tool" {
		t.Errorf("command: got %q, want %q", configs[0].Command, "my-tool")
	}
	if len(configs[0].Args) != 0 {
		t.Errorf("expected empty args, got %v", configs[0].Args)
	}
	if !configs[0].Enabled {
		t.Error("loaded configs should have Enabled=true")
	}
}

func TestConfigFromFile_MultipleServersAllEnabled(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "mcp.json")
	config := `{
		"mcpServers": {
			"a": {"command": "cmd-a", "args": ["--flag"]},
			"b": {"command": "cmd-b"},
			"c": {"command": "cmd-c", "env": {"X": "1"}}
		}
	}`
	if err := os.WriteFile(path, []byte(config), 0644); err != nil {
		t.Fatal(err)
	}
	configs, err := ConfigFromFile(path)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(configs) != 3 {
		t.Fatalf("expected 3 configs, got %d", len(configs))
	}
	for _, c := range configs {
		if !c.Enabled {
			t.Errorf("config %q should be enabled", c.Name)
		}
	}
}

func TestEmptyConfigPath_CorrectFilename(t *testing.T) {
	dir := t.TempDir()
	path, err := EmptyConfigPath(dir)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if filepath.Base(path) != "empty-mcp.json" {
		t.Errorf("expected filename 'empty-mcp.json', got %q", filepath.Base(path))
	}
	if filepath.Dir(path) != dir {
		t.Errorf("expected dir %q, got %q", dir, filepath.Dir(path))
	}
}

func TestEmptyConfigPath_Overwrite(t *testing.T) {
	dir := t.TempDir()
	target := filepath.Join(dir, "empty-mcp.json")
	if err := os.WriteFile(target, []byte(`{"old":"data"}`), 0644); err != nil {
		t.Fatal(err)
	}
	path, err := EmptyConfigPath(dir)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if string(data) != "{}" {
		t.Errorf("expected empty JSON after overwrite, got %s", string(data))
	}
}

// ---------------------------------------------------------------------------
// 3. Tool list parsing
// ---------------------------------------------------------------------------

func TestToolDefinition_ParseSingle(t *testing.T) {
	raw := `{
		"name": "read_file",
		"description": "Read a file from disk",
		"input_schema": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}
	}`
	var td ToolDefinition
	if err := json.Unmarshal([]byte(raw), &td); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if td.Name != "read_file" {
		t.Errorf("name: got %q, want %q", td.Name, "read_file")
	}
	if td.Description != "Read a file from disk" {
		t.Errorf("description: got %q", td.Description)
	}
	if td.InputSchema == nil {
		t.Fatal("input_schema should not be nil")
	}
	// Verify the schema is valid JSON we can re-parse
	var schema map[string]interface{}
	if err := json.Unmarshal(td.InputSchema, &schema); err != nil {
		t.Fatalf("input_schema is not valid JSON: %v", err)
	}
	if schema["type"] != "object" {
		t.Errorf("schema type: got %v, want 'object'", schema["type"])
	}
}

func TestToolDefinition_ParseMinimal(t *testing.T) {
	raw := `{"name": "ping", "input_schema": {}}`
	var td ToolDefinition
	if err := json.Unmarshal([]byte(raw), &td); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if td.Name != "ping" {
		t.Errorf("name: got %q, want %q", td.Name, "ping")
	}
	if td.Description != "" {
		t.Errorf("description should be empty, got %q", td.Description)
	}
}

func TestToolListResponse_Parse(t *testing.T) {
	// Simulate the JSON-RPC result for tools/list
	raw := `{
		"tools": [
			{
				"name": "read_file",
				"description": "Read a file",
				"input_schema": {"type": "object", "properties": {"path": {"type": "string"}}}
			},
			{
				"name": "write_file",
				"description": "Write a file",
				"input_schema": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}}
			},
			{
				"name": "list_dir",
				"description": "List directory contents",
				"input_schema": {"type": "object"}
			}
		]
	}`
	var result struct {
		Tools []ToolDefinition `json:"tools"`
	}
	if err := json.Unmarshal([]byte(raw), &result); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if len(result.Tools) != 3 {
		t.Fatalf("expected 3 tools, got %d", len(result.Tools))
	}
	names := map[string]bool{}
	for _, tool := range result.Tools {
		names[tool.Name] = true
		if tool.InputSchema == nil {
			t.Errorf("tool %q has nil input_schema", tool.Name)
		}
	}
	for _, expected := range []string{"read_file", "write_file", "list_dir"} {
		if !names[expected] {
			t.Errorf("missing tool %q", expected)
		}
	}
}

func TestToolListResponse_EmptyList(t *testing.T) {
	raw := `{"tools": []}`
	var result struct {
		Tools []ToolDefinition `json:"tools"`
	}
	if err := json.Unmarshal([]byte(raw), &result); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if len(result.Tools) != 0 {
		t.Errorf("expected 0 tools, got %d", len(result.Tools))
	}
}

func TestToolDefinition_ComplexSchema(t *testing.T) {
	raw := `{
		"name": "query_db",
		"description": "Execute a database query",
		"input_schema": {
			"type": "object",
			"properties": {
				"sql": {"type": "string"},
				"params": {"type": "array", "items": {"type": "string"}},
				"timeout": {"type": "integer", "minimum": 0, "maximum": 30000}
			},
			"required": ["sql"]
		}
	}`
	var td ToolDefinition
	if err := json.Unmarshal([]byte(raw), &td); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if td.Name != "query_db" {
		t.Errorf("name: got %q", td.Name)
	}
	// Verify input_schema round-trips
	var schema map[string]interface{}
	if err := json.Unmarshal(td.InputSchema, &schema); err != nil {
		t.Fatalf("schema re-parse: %v", err)
	}
	props, ok := schema["properties"].(map[string]interface{})
	if !ok {
		t.Fatal("properties should be an object")
	}
	if _, exists := props["sql"]; !exists {
		t.Error("schema should contain 'sql' property")
	}
	if _, exists := props["params"]; !exists {
		t.Error("schema should contain 'params' property")
	}
	if _, exists := props["timeout"]; !exists {
		t.Error("schema should contain 'timeout' property")
	}
}

// ---------------------------------------------------------------------------
// 4. Error handling for malformed responses
// ---------------------------------------------------------------------------

func TestJSONRPCResponse_ParseError(t *testing.T) {
	raw := `{"jsonrpc": "2.0", "id": 1, "error": {"code": -32600, "message": "Invalid Request"}}`
	var resp jsonRPCResponse
	if err := json.Unmarshal([]byte(raw), &resp); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if resp.Error == nil {
		t.Fatal("expected error field to be non-nil")
	}
	if resp.Error.Code != -32600 {
		t.Errorf("error code: got %d, want -32600", resp.Error.Code)
	}
	if resp.Error.Message != "Invalid Request" {
		t.Errorf("error message: got %q", resp.Error.Message)
	}
	if resp.Result != nil {
		t.Error("result should be nil when error is present")
	}
}

func TestJSONRPCResponse_ParseResult(t *testing.T) {
	raw := `{"jsonrpc": "2.0", "id": 42, "result": {"tools": []}}`
	var resp jsonRPCResponse
	if err := json.Unmarshal([]byte(raw), &resp); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if resp.ID != 42 {
		t.Errorf("id: got %d, want 42", resp.ID)
	}
	if resp.Error != nil {
		t.Errorf("unexpected error: %v", resp.Error)
	}
	if resp.Result == nil {
		t.Fatal("result should not be nil")
	}
}

func TestJSONRPCResponse_MalformedJSON(t *testing.T) {
	malformed := []string{
		`{not json}`,
		``,
		`{"jsonrpc": "2.0", "id": "string_id"}`,
		`null`,
	}
	for _, raw := range malformed {
		var resp jsonRPCResponse
		err := json.Unmarshal([]byte(raw), &resp)
		// We just verify these don't panic; some will error, some won't
		_ = err
	}
}

func TestJSONRPCRequest_Serialization(t *testing.T) {
	req := jsonRPCRequest{
		JSONRPC: "2.0",
		ID:      1,
		Method:  "tools/list",
		Params:  nil,
	}
	data, err := json.Marshal(req)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	s := string(data)
	if !strings.Contains(s, `"jsonrpc":"2.0"`) {
		t.Errorf("missing jsonrpc field in: %s", s)
	}
	if !strings.Contains(s, `"method":"tools/list"`) {
		t.Errorf("missing method field in: %s", s)
	}
	if !strings.Contains(s, `"id":1`) {
		t.Errorf("missing id field in: %s", s)
	}
}

func TestJSONRPCRequest_WithParams(t *testing.T) {
	params := map[string]interface{}{
		"name":      "read_file",
		"arguments": map[string]interface{}{"path": "/tmp/test.txt"},
	}
	req := jsonRPCRequest{
		JSONRPC: "2.0",
		ID:      5,
		Method:  "tools/call",
		Params:  params,
	}
	data, err := json.Marshal(req)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	// Verify we can round-trip it
	var decoded map[string]interface{}
	if err := json.Unmarshal(data, &decoded); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if decoded["method"] != "tools/call" {
		t.Errorf("method: got %v", decoded["method"])
	}
	p, ok := decoded["params"].(map[string]interface{})
	if !ok {
		t.Fatal("params should be a map")
	}
	if p["name"] != "read_file" {
		t.Errorf("params.name: got %v", p["name"])
	}
}

func TestToolListResponse_MalformedToolsField(t *testing.T) {
	// tools field is a string instead of array
	raw := `{"tools": "not-an-array"}`
	var result struct {
		Tools []ToolDefinition `json:"tools"`
	}
	err := json.Unmarshal([]byte(raw), &result)
	if err == nil {
		t.Error("expected error for malformed tools field")
	}
}

func TestToolListResponse_MissingToolsField(t *testing.T) {
	raw := `{"other": "data"}`
	var result struct {
		Tools []ToolDefinition `json:"tools"`
	}
	if err := json.Unmarshal([]byte(raw), &result); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if result.Tools != nil {
		t.Errorf("expected nil tools, got %v", result.Tools)
	}
}

func TestJSONRPCError_Format(t *testing.T) {
	tests := []struct {
		name    string
		code    int
		message string
	}{
		{"parse error", -32700, "Parse error"},
		{"invalid request", -32600, "Invalid Request"},
		{"method not found", -32601, "Method not found"},
		{"invalid params", -32602, "Invalid params"},
		{"internal error", -32603, "Internal error"},
		{"server error", -32000, "Server error"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			rpcErr := jsonRPCError{Code: tt.code, Message: tt.message}
			data, err := json.Marshal(rpcErr)
			if err != nil {
				t.Fatalf("marshal: %v", err)
			}
			var decoded jsonRPCError
			if err := json.Unmarshal(data, &decoded); err != nil {
				t.Fatalf("unmarshal: %v", err)
			}
			if decoded.Code != tt.code {
				t.Errorf("code: got %d, want %d", decoded.Code, tt.code)
			}
			if decoded.Message != tt.message {
				t.Errorf("message: got %q, want %q", decoded.Message, tt.message)
			}
		})
	}
}

// ---------------------------------------------------------------------------
// 5. Timeout / config construction
// ---------------------------------------------------------------------------

func TestServerConfig_EnvMerge(t *testing.T) {
	// Verify that environment variables from ServerConfig would be appended
	// to the current environment (testing the config structure, not process launch)
	cfg := ServerConfig{
		Name:    "env-test",
		Command: "echo",
		Env: map[string]string{
			"MCP_TIMEOUT":  "30000",
			"MCP_LOG":      "debug",
			"CUSTOM_TOKEN": "abc123",
		},
		Enabled: true,
	}

	// Build the env slice the same way NewStdioClient does
	env := os.Environ()
	for k, v := range cfg.Env {
		env = append(env, k+"="+v)
	}

	// Verify our custom vars are in there
	found := map[string]bool{}
	for _, e := range env {
		for k, v := range cfg.Env {
			if e == k+"="+v {
				found[k] = true
			}
		}
	}
	for k := range cfg.Env {
		if !found[k] {
			t.Errorf("env var %q not found in merged env", k)
		}
	}
}

func TestServerConfig_CommandArgs(t *testing.T) {
	tests := []struct {
		name     string
		command  string
		args     []string
		wantArgs int
	}{
		{"no args", "my-server", nil, 0},
		{"single arg", "npx", []string{"-y"}, 1},
		{"multiple args", "npx", []string{"-y", "@mcp/server", "--port", "3000"}, 4},
		{"args with spaces", "node", []string{"server.js", "--dir", "/path/with spaces/"}, 3},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cfg := ServerConfig{
				Name:    tt.name,
				Command: tt.command,
				Args:    tt.args,
				Enabled: true,
			}
			if len(cfg.Args) != tt.wantArgs {
				t.Errorf("args count: got %d, want %d", len(cfg.Args), tt.wantArgs)
			}

			// Verify the config would produce a valid JSON round-trip
			data, err := json.Marshal(cfg)
			if err != nil {
				t.Fatalf("marshal: %v", err)
			}
			var decoded ServerConfig
			if err := json.Unmarshal(data, &decoded); err != nil {
				t.Fatalf("unmarshal: %v", err)
			}
			if decoded.Command != tt.command {
				t.Errorf("command: got %q, want %q", decoded.Command, tt.command)
			}
			if len(decoded.Args) != tt.wantArgs {
				t.Errorf("decoded args count: got %d, want %d", len(decoded.Args), tt.wantArgs)
			}
		})
	}
}

func TestConfigFromFile_ServerWithEnvOnly(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "mcp.json")
	config := `{
		"mcpServers": {
			"env-server": {
				"command": "tool",
				"env": {"TIMEOUT": "5000", "RETRIES": "3"}
			}
		}
	}`
	if err := os.WriteFile(path, []byte(config), 0644); err != nil {
		t.Fatal(err)
	}
	configs, err := ConfigFromFile(path)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(configs) != 1 {
		t.Fatalf("expected 1 config, got %d", len(configs))
	}
	c := configs[0]
	if c.Env["TIMEOUT"] != "5000" {
		t.Errorf("TIMEOUT: got %q, want %q", c.Env["TIMEOUT"], "5000")
	}
	if c.Env["RETRIES"] != "3" {
		t.Errorf("RETRIES: got %q, want %q", c.Env["RETRIES"], "3")
	}
}

func TestEmptyConfigPath_ValidJSON(t *testing.T) {
	dir := t.TempDir()
	path, err := EmptyConfigPath(dir)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	// Verify the output is valid JSON that can be parsed as an MCP config
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var parsed map[string]interface{}
	if err := json.Unmarshal(data, &parsed); err != nil {
		t.Fatalf("empty config is not valid JSON: %v", err)
	}
	// Should have no mcpServers key (or be empty object)
	if _, exists := parsed["mcpServers"]; exists {
		t.Error("empty config should not have mcpServers key")
	}
}

func TestConfigFromFile_FullClaudeCodeFormat(t *testing.T) {
	// Test with a realistic Claude Code .claude/mcp.json
	dir := t.TempDir()
	path := filepath.Join(dir, "mcp.json")
	config := `{
		"mcpServers": {
			"filesystem": {
				"command": "npx",
				"args": ["-y", "@modelcontextprotocol/server-filesystem", "/home/user/project"],
				"env": {"NODE_ENV": "production"}
			},
			"github": {
				"command": "npx",
				"args": ["-y", "@modelcontextprotocol/server-github"],
				"env": {"GITHUB_PERSONAL_ACCESS_TOKEN": "ghp_xxx"}
			},
			"postgres": {
				"command": "npx",
				"args": ["-y", "@modelcontextprotocol/server-postgres", "postgresql://localhost/mydb"]
			}
		}
	}`
	if err := os.WriteFile(path, []byte(config), 0644); err != nil {
		t.Fatal(err)
	}
	configs, err := ConfigFromFile(path)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(configs) != 3 {
		t.Fatalf("expected 3 configs, got %d", len(configs))
	}

	byName := map[string]ServerConfig{}
	for _, c := range configs {
		byName[c.Name] = c
	}

	// Check filesystem server
	fs, ok := byName["filesystem"]
	if !ok {
		t.Fatal("missing filesystem config")
	}
	if fs.Command != "npx" {
		t.Errorf("filesystem command: got %q", fs.Command)
	}
	if len(fs.Args) != 3 {
		t.Errorf("filesystem args: got %d, want 3", len(fs.Args))
	}

	// Check github server
	gh, ok := byName["github"]
	if !ok {
		t.Fatal("missing github config")
	}
	if gh.Env["GITHUB_PERSONAL_ACCESS_TOKEN"] != "ghp_xxx" {
		t.Error("github token not preserved")
	}

	// Check postgres server (no env)
	pg, ok := byName["postgres"]
	if !ok {
		t.Fatal("missing postgres config")
	}
	if len(pg.Env) != 0 {
		t.Errorf("postgres should have no env, got %v", pg.Env)
	}
}
