package convergence

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/ericmacdougall/stoke/internal/apiclient"
)

// ModelAnalyzer performs model-driven deep code analysis.
// It complements the regex-based rule engine with semantic understanding
// that can catch logic errors, API misuse, missing edge cases, and
// completeness gaps that pattern matching cannot detect.
type ModelAnalyzer interface {
	Analyze(ctx context.Context, files []FileInput, criteria []string) ([]Finding, error)
}

// APIModelAnalyzer uses apiclient.Client to call AI models for analysis.
type APIModelAnalyzer struct {
	client           *apiclient.Client
	maxFilesPerBatch int
	maxTokenBudget   int
}

// ModelAnalyzerConfig configures the API-based model analyzer.
type ModelAnalyzerConfig struct {
	// Provider is the API provider (anthropic, openai, openrouter).
	Provider apiclient.Provider
	// APIKey for the provider.
	APIKey string
	// BaseURL overrides the default provider URL.
	BaseURL string
	// Model is the specific model to use (e.g., "claude-sonnet-4-20250514").
	Model string
	// MaxFilesPerBatch controls how many files per API call. Default: 10.
	MaxFilesPerBatch int
	// MaxTokenBudget is the approximate input token limit. Default: 100000.
	MaxTokenBudget int
}

// NewAPIModelAnalyzer creates a model analyzer that calls AI APIs for deep analysis.
func NewAPIModelAnalyzer(cfg ModelAnalyzerConfig) *APIModelAnalyzer {
	clientCfg := apiclient.Config{
		Provider: cfg.Provider,
		APIKey:   cfg.APIKey,
		BaseURL:  cfg.BaseURL,
		Model:    cfg.Model,
		MaxTokens: 8192,
		Timeout:  3 * time.Minute,
	}
	if clientCfg.Provider == "" {
		clientCfg.Provider = apiclient.ProviderAnthropic
	}
	if clientCfg.BaseURL == "" {
		if defaults, ok := apiclient.DefaultConfigs[clientCfg.Provider]; ok {
			clientCfg.BaseURL = defaults.BaseURL
		}
	}
	if clientCfg.Model == "" {
		if defaults, ok := apiclient.DefaultConfigs[clientCfg.Provider]; ok {
			clientCfg.Model = defaults.Model
		}
	}

	maxFiles := cfg.MaxFilesPerBatch
	if maxFiles <= 0 {
		maxFiles = 10
	}
	maxTokens := cfg.MaxTokenBudget
	if maxTokens <= 0 {
		maxTokens = 100000
	}

	return &APIModelAnalyzer{
		client:           apiclient.NewClient(clientCfg),
		maxFilesPerBatch: maxFiles,
		maxTokenBudget:   maxTokens,
	}
}

// Analyze sends files to the model for adversarial analysis and returns structured findings.
// Files are batched to stay within token limits. Each batch produces independent findings
// which are merged into a single result set.
func (a *APIModelAnalyzer) Analyze(ctx context.Context, files []FileInput, criteria []string) ([]Finding, error) {
	if len(files) == 0 {
		return nil, nil
	}

	batches := a.batchFiles(files)
	var allFindings []Finding

	for i, batch := range batches {
		log.Printf("[convergence] model analysis batch %d/%d (%d files)", i+1, len(batches), len(batch))

		prompt := buildAnalysisPrompt(batch, criteria)
		req := apiclient.Request{
			Messages: []apiclient.Message{
				{Role: "user", Content: prompt},
			},
			System:    analysisSystemPrompt,
			MaxTokens: 8192,
		}

		resp, err := a.client.Complete(ctx, req)
		if err != nil {
			log.Printf("[convergence] model analysis batch %d failed: %v", i+1, err)
			return allFindings, fmt.Errorf("model analysis batch %d: %w", i+1, err)
		}

		findings := parseModelFindings(resp.Content)
		allFindings = append(allFindings, findings...)
		log.Printf("[convergence] model analysis batch %d: %d findings", i+1, len(findings))
	}

	return allFindings, nil
}

// batchFiles groups files into batches that fit within the token budget.
// Uses a rough 4-chars-per-token estimate.
func (a *APIModelAnalyzer) batchFiles(files []FileInput) [][]FileInput {
	var batches [][]FileInput
	var current []FileInput
	currentTokens := 0

	for _, f := range files {
		fileTokens := len(f.Content) / 4 // rough estimate
		if fileTokens > a.maxTokenBudget/2 {
			// Single file exceeds half the budget — give it its own batch
			if len(current) > 0 {
				batches = append(batches, current)
				current = nil
				currentTokens = 0
			}
			batches = append(batches, []FileInput{f})
			continue
		}

		if len(current) >= a.maxFilesPerBatch || currentTokens+fileTokens > a.maxTokenBudget {
			batches = append(batches, current)
			current = nil
			currentTokens = 0
		}
		current = append(current, f)
		currentTokens += fileTokens
	}
	if len(current) > 0 {
		batches = append(batches, current)
	}

	return batches
}

// parseModelFindings parses the model's JSON response into structured findings.
// If JSON parsing fails, the entire response is treated as a single info-level finding.
func parseModelFindings(content string) []Finding {
	content = strings.TrimSpace(content)

	// Strip markdown code fences if present
	if strings.HasPrefix(content, "```") {
		lines := strings.Split(content, "\n")
		if len(lines) > 2 {
			// Remove first and last lines (``` markers)
			content = strings.Join(lines[1:len(lines)-1], "\n")
		}
	}
	content = strings.TrimSpace(content)

	if content == "[]" || content == "" {
		return nil
	}

	var raw []struct {
		Category    string `json:"category"`
		Severity    string `json:"severity"`
		File        string `json:"file"`
		Line        int    `json:"line"`
		Description string `json:"description"`
		Suggestion  string `json:"suggestion"`
		Evidence    string `json:"evidence"`
	}

	if err := json.Unmarshal([]byte(content), &raw); err != nil {
		// Model didn't return valid JSON — wrap as a single finding
		log.Printf("[convergence] model response was not valid JSON: %v", err)
		return []Finding{{
			RuleID:      "model-parse-error",
			Category:    CatConsistency,
			Severity:    SevInfo,
			Description: "Model analysis returned non-JSON response: " + truncate(content, 200),
		}}
	}

	findings := make([]Finding, 0, len(raw))
	for _, r := range raw {
		f := Finding{
			RuleID:      "model-" + normalizeCategory(r.Category),
			Category:    mapCategory(r.Category),
			Severity:    mapSeverity(r.Severity),
			File:        r.File,
			Line:        r.Line,
			Description: r.Description,
			Suggestion:  r.Suggestion,
		}
		if f.Description == "" {
			continue // skip empty findings
		}
		findings = append(findings, f)
	}

	return findings
}

func normalizeCategory(cat string) string {
	cat = strings.ToLower(strings.TrimSpace(cat))
	switch cat {
	case "logic", "security", "completeness", "test", "code", "docs", "consistency":
		return cat
	default:
		return "general"
	}
}

func mapCategory(cat string) Category {
	switch strings.ToLower(strings.TrimSpace(cat)) {
	case "security":
		return CatSecurity
	case "test":
		return CatTestCoverage
	case "completeness":
		return CatCompleteness
	case "docs":
		return CatDocumentation
	case "consistency":
		return CatConsistency
	default:
		return CatCodeQuality
	}
}

func mapSeverity(sev string) Severity {
	switch strings.ToLower(strings.TrimSpace(sev)) {
	case "blocking":
		return SevBlocking
	case "major":
		return SevMajor
	case "minor":
		return SevMinor
	case "info":
		return SevInfo
	default:
		return SevMajor // default to major — adversarial stance
	}
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}
