package convergence

import (
	"context"
	"testing"
)

// mockModelAnalyzer implements ModelAnalyzer for testing.
type mockModelAnalyzer struct {
	findings []Finding
	err      error
	called   int
}

func (m *mockModelAnalyzer) Analyze(_ context.Context, _ []FileInput, _ []string) ([]Finding, error) {
	m.called++
	return m.findings, m.err
}

func TestValidateDeepNoModel(t *testing.T) {
	v := NewValidator()
	files := []FileInput{
		{Path: "main.go", Content: []byte("package main\nfunc main() {}\n")},
	}
	report := v.ValidateDeep(context.Background(), "m-1", files, nil)
	if report.AnalysisMode != "regex" {
		t.Errorf("mode=%q, want regex", report.AnalysisMode)
	}
}

func TestValidateDeepWithModel(t *testing.T) {
	mock := &mockModelAnalyzer{
		findings: []Finding{
			{RuleID: "model-logic", Category: CatCodeQuality, Severity: SevMajor, File: "main.go", Description: "nil dereference possible"},
		},
	}
	v := NewValidatorWithModel(mock)
	files := []FileInput{
		{Path: "main.go", Content: []byte("package main\nfunc main() {}\n")},
	}
	report := v.ValidateDeep(context.Background(), "m-1", files, nil)
	if report.AnalysisMode != "deep" {
		t.Errorf("mode=%q, want deep", report.AnalysisMode)
	}
	if mock.called != 1 {
		t.Errorf("analyzer called %d times, want 1", mock.called)
	}
	if report.ModelFindingCount != 1 {
		t.Errorf("model findings=%d, want 1", report.ModelFindingCount)
	}
	// Should have model finding merged in
	found := false
	for _, f := range report.Findings {
		if f.RuleID == "model-logic" {
			found = true
		}
	}
	if !found {
		t.Error("model finding not merged into report")
	}
}

func TestValidateDeepModelError(t *testing.T) {
	mock := &mockModelAnalyzer{err: context.DeadlineExceeded}
	v := NewValidatorWithModel(mock)
	files := []FileInput{
		{Path: "main.go", Content: []byte("package main\n")},
	}
	report := v.ValidateDeep(context.Background(), "m-1", files, nil)
	if report.AnalysisMode != "regex-fallback" {
		t.Errorf("mode=%q, want regex-fallback", report.AnalysisMode)
	}
}

func TestValidateDeepDeduplicates(t *testing.T) {
	// Create a finding that matches what regex would find
	mock := &mockModelAnalyzer{
		findings: []Finding{
			// Duplicate: same file+line+category as a regex finding
			{RuleID: "model-consistency", Category: CatConsistency, Severity: SevBlocking, File: "bad.go", Line: 1, Description: "has TODO"},
			// New: model-only finding
			{RuleID: "model-logic", Category: CatCodeQuality, Severity: SevMajor, File: "bad.go", Line: 5, Description: "race condition"},
		},
	}
	v := NewValidatorWithModel(mock)
	files := []FileInput{
		{Path: "bad.go", Content: []byte("// TODO: fix\npackage bad\n")},
	}
	report := v.ValidateDeep(context.Background(), "m-1", files, nil)

	// The regex will find the TODO at line 1 with CatConsistency.
	// The model also reports line 1 CatConsistency — should be deduped.
	// The model's line 5 finding should be added.
	regexCount := 0
	modelCount := 0
	for _, f := range report.Findings {
		if f.RuleID == "model-logic" {
			modelCount++
		}
		if f.RuleID == "no-todo" {
			regexCount++
		}
	}
	if regexCount != 1 {
		t.Errorf("regex findings=%d, want 1", regexCount)
	}
	if modelCount != 1 {
		t.Errorf("model-logic findings=%d, want 1", modelCount)
	}
}

func TestParseModelFindings(t *testing.T) {
	tests := []struct {
		name    string
		content string
		want    int
	}{
		{"empty array", "[]", 0},
		{"empty string", "", 0},
		{"single finding", `[{"category":"security","severity":"blocking","file":"a.go","line":10,"description":"sql injection","suggestion":"use params"}]`, 1},
		{"multiple findings", `[{"category":"logic","severity":"major","file":"a.go","line":1,"description":"issue 1"},{"category":"test","severity":"minor","file":"b.go","line":2,"description":"issue 2"}]`, 2},
		{"with code fences", "```json\n[{\"category\":\"code\",\"severity\":\"info\",\"file\":\"x.go\",\"line\":1,\"description\":\"style\"}]\n```", 1},
		{"invalid json", "not json at all", 1}, // wraps as parse-error finding
		{"skip empty descriptions", `[{"category":"code","severity":"info","file":"a.go","line":1,"description":""}]`, 0},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			findings := parseModelFindings(tt.content)
			if len(findings) != tt.want {
				t.Errorf("got %d findings, want %d", len(findings), tt.want)
			}
		})
	}
}

func TestMapCategory(t *testing.T) {
	tests := map[string]Category{
		"security":     CatSecurity,
		"SECURITY":     CatSecurity,
		"test":         CatTestCoverage,
		"completeness": CatCompleteness,
		"docs":         CatDocumentation,
		"consistency":  CatConsistency,
		"logic":        CatCodeQuality,
		"unknown":      CatCodeQuality,
	}
	for input, want := range tests {
		if got := mapCategory(input); got != want {
			t.Errorf("mapCategory(%q)=%q, want %q", input, got, want)
		}
	}
}

func TestMapSeverity(t *testing.T) {
	tests := map[string]Severity{
		"blocking": SevBlocking,
		"MAJOR":    SevMajor,
		"minor":    SevMinor,
		"info":     SevInfo,
		"unknown":  SevMajor, // defaults to major (adversarial)
	}
	for input, want := range tests {
		if got := mapSeverity(input); got != want {
			t.Errorf("mapSeverity(%q)=%q, want %q", input, got, want)
		}
	}
}

func TestBatchFiles(t *testing.T) {
	a := &APIModelAnalyzer{maxFilesPerBatch: 3, maxTokenBudget: 1000}

	files := []FileInput{
		{Path: "a.go", Content: make([]byte, 100)},
		{Path: "b.go", Content: make([]byte, 100)},
		{Path: "c.go", Content: make([]byte, 100)},
		{Path: "d.go", Content: make([]byte, 100)},
		{Path: "e.go", Content: make([]byte, 100)},
	}
	batches := a.batchFiles(files)
	if len(batches) != 2 {
		t.Errorf("got %d batches, want 2 (3+2)", len(batches))
	}
	if len(batches[0]) != 3 {
		t.Errorf("batch 0 has %d files, want 3", len(batches[0]))
	}
	if len(batches[1]) != 2 {
		t.Errorf("batch 1 has %d files, want 2", len(batches[1]))
	}
}

func TestBatchFilesLargeFile(t *testing.T) {
	a := &APIModelAnalyzer{maxFilesPerBatch: 10, maxTokenBudget: 1000}

	files := []FileInput{
		{Path: "small.go", Content: make([]byte, 100)},
		{Path: "huge.go", Content: make([]byte, 3000)}, // exceeds half budget
		{Path: "small2.go", Content: make([]byte, 100)},
	}
	batches := a.batchFiles(files)
	if len(batches) != 3 {
		t.Errorf("got %d batches, want 3 (large file gets own batch)", len(batches))
	}
}

func TestSetModelAnalyzer(t *testing.T) {
	v := NewValidator()
	mock := &mockModelAnalyzer{}
	v.SetModelAnalyzer(mock)

	files := []FileInput{{Path: "a.go", Content: []byte("package a\n")}}
	report := v.ValidateDeep(context.Background(), "m-1", files, nil)
	if report.AnalysisMode != "deep" {
		t.Errorf("mode=%q after SetModelAnalyzer, want deep", report.AnalysisMode)
	}
	if mock.called != 1 {
		t.Error("model analyzer not called after SetModelAnalyzer")
	}
}

func TestBuildAnalysisPrompt(t *testing.T) {
	files := []FileInput{
		{Path: "main.go", Content: []byte("package main\n")},
	}
	criteria := []string{"handle errors", "add tests"}

	prompt := buildAnalysisPrompt(files, criteria)

	if len(prompt) == 0 {
		t.Fatal("empty prompt")
	}
	// Should contain criteria
	if !containsSubstring(prompt, "handle errors") {
		t.Error("prompt missing criterion 1")
	}
	if !containsSubstring(prompt, "add tests") {
		t.Error("prompt missing criterion 2")
	}
	// Should contain file content
	if !containsSubstring(prompt, "main.go") {
		t.Error("prompt missing file path")
	}
	if !containsSubstring(prompt, "package main") {
		t.Error("prompt missing file content")
	}
}

func containsSubstring(s, sub string) bool {
	return len(s) > 0 && len(sub) > 0 && (s == sub || len(s) > len(sub) && findSubstring(s, sub))
}

func findSubstring(s, sub string) bool {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
