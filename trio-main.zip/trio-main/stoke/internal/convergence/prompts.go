package convergence

import (
	"fmt"
	"strings"
)

// analysisSystemPrompt is the adversarial system prompt for model-driven convergence analysis.
// It instructs the model to find reasons the code is NOT done, not reasons it IS done.
const analysisSystemPrompt = `You are an adversarial code auditor. Your job is to find every reason this code is NOT production-ready.

You must analyze across these dimensions:
1. LOGIC CORRECTNESS: Off-by-one errors, nil/null dereferences, race conditions, deadlocks, infinite loops, incorrect conditionals
2. API CONTRACT VIOLATIONS: Misuse of library APIs, wrong argument types, missing required fields, deprecated usage
3. EDGE CASE HANDLING: What inputs break this? Empty strings, nil maps, zero values, concurrent access, large inputs, unicode
4. SECURITY: Injection (SQL, command, path traversal), auth bypass, secrets in code, missing validation, unsafe deserialization
5. COMPLETENESS: Does the code fully implement all stated criteria? Are there stub methods, placeholder returns, TODO/FIXME?
6. ERROR HANDLING: Ignored errors, swallowed panics, missing recovery, unclear error messages, error type assertions
7. CONCURRENCY: Missing locks, shared state without sync, goroutine leaks, channel misuse, context cancellation
8. RESOURCE MANAGEMENT: Unclosed files/connections, missing defers, memory leaks, unbounded growth

Be adversarial. Assume the code has issues. Your job is to find them, not to validate that it works.
Do NOT report stylistic preferences. Only report genuine correctness, security, or completeness issues.`

// analysisOutputFormat defines the JSON output schema the model must follow.
const analysisOutputFormat = `
Respond with ONLY a JSON array. No markdown, no explanation, no preamble.
Each element must have these fields:
{
  "category": "logic|security|completeness|test|code|docs|consistency",
  "severity": "blocking|major|minor|info",
  "file": "path/to/file.go",
  "line": 0,
  "description": "What is wrong",
  "suggestion": "How to fix it",
  "evidence": "The specific code that demonstrates the issue"
}

If you find NO issues, respond with exactly: []`

// buildAnalysisPrompt constructs the user message for model analysis.
func buildAnalysisPrompt(files []FileInput, criteria []string) string {
	var sb strings.Builder

	if len(criteria) > 0 {
		sb.WriteString("## Acceptance Criteria to Verify\n")
		for i, c := range criteria {
			sb.WriteString(fmt.Sprintf("%d. %s\n", i+1, c))
		}
		sb.WriteString("\nVerify that EVERY criterion is fully implemented, tested, and working.\n\n")
	}

	sb.WriteString("## Files to Analyze\n\n")
	for _, f := range files {
		sb.WriteString(fmt.Sprintf("### %s\n```\n%s\n```\n\n", f.Path, string(f.Content)))
	}

	sb.WriteString(analysisOutputFormat)
	return sb.String()
}

// consensusSystemPrompt is used when a model independently verifies completion.
const consensusSystemPrompt = `You are an independent verification agent. A different AI completed this coding mission. Your job is to determine whether the mission is TRULY complete.

You must be skeptical. The implementing model will claim the work is done — that is expected. Your job is to verify independently.

Check:
1. Does the code ACTUALLY satisfy every stated criterion? Not "it looks like it does" — trace the logic.
2. Are there ANY gaps, stubs, placeholders, or incomplete implementations?
3. Would you ship this code to production without changes?
4. Are there edge cases that would cause failures?
5. Is error handling complete — not just present, but correct?

You are not looking for style issues. You are looking for FUNCTIONAL gaps.`

// consensusOutputFormat is the JSON format for consensus votes.
const consensusOutputFormat = `
Respond with ONLY a JSON object:
{
  "verdict": "complete" or "incomplete",
  "confidence": 0.0 to 1.0,
  "reasoning": "Why you believe this",
  "gaps_found": ["gap 1 description", "gap 2 description"]
}

If gaps_found is empty and verdict is "complete", that means you verified everything works.
If you find ANY gap, verdict MUST be "incomplete".`
