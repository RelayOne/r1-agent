package research

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/ericmacdougall/stoke/internal/apiclient"
)

// ModelSearcher performs semantic search by using a model to re-rank results.
// It uses a two-stage pipeline:
//  1. FTS5/LIKE pre-filter: retrieve top candidates from the research store (fast, free)
//  2. Model re-rank: send candidates to an AI model to rank by semantic relevance (deep, paid)
//
// This produces much better results than keyword matching for queries like
// "authentication flow" matching research about "login implementation" or
// "JWT token handling."
type ModelSearcher struct {
	client    *apiclient.Client
	store     *Store
	preFilter int // how many candidates to pre-filter (default: 50)
}

// ModelSearchConfig configures the model-based research search.
type ModelSearchConfig struct {
	Provider  apiclient.Provider
	APIKey    string
	BaseURL   string
	Model     string
	PreFilter int // candidates to pre-filter before re-ranking (default: 50)
}

// NewModelSearcher creates a model-driven search layer on top of the research store.
func NewModelSearcher(store *Store, cfg ModelSearchConfig) *ModelSearcher {
	clientCfg := apiclient.Config{
		Provider:  cfg.Provider,
		APIKey:    cfg.APIKey,
		BaseURL:   cfg.BaseURL,
		Model:     cfg.Model,
		MaxTokens: 4096,
		Timeout:   30 * time.Second,
	}
	if clientCfg.Provider == "" {
		clientCfg.Provider = apiclient.ProviderAnthropic
	}
	if clientCfg.BaseURL == "" {
		if defaults, ok := apiclient.DefaultConfigs[clientCfg.Provider]; ok {
			clientCfg.BaseURL = defaults.BaseURL
		}
	}
	if clientCfg.Model == "" {
		if defaults, ok := apiclient.DefaultConfigs[clientCfg.Provider]; ok {
			clientCfg.Model = defaults.Model
		}
	}

	preFilter := cfg.PreFilter
	if preFilter <= 0 {
		preFilter = 50
	}

	return &ModelSearcher{
		client:    apiclient.NewClient(clientCfg),
		store:     store,
		preFilter: preFilter,
	}
}

// Search performs semantic search: FTS5 pre-filter then model re-rank.
func (s *ModelSearcher) Search(ctx context.Context, query string, topK int) ([]SearchResult, error) {
	if topK <= 0 {
		topK = 5
	}

	// Stage 1: pre-filter with FTS5/LIKE from the store
	candidates, err := s.store.Search(query, s.preFilter)
	if err != nil {
		return nil, fmt.Errorf("pre-filter search: %w", err)
	}

	if len(candidates) == 0 {
		return nil, nil
	}

	// If fewer candidates than requested, skip re-ranking
	if len(candidates) <= topK {
		return candidates, nil
	}

	// Stage 2: model re-rank
	reranked, err := s.rerank(ctx, query, candidates, topK)
	if err != nil {
		// Fallback to pre-filter results on model error
		log.Printf("[research] model re-rank failed, using pre-filter results: %v", err)
		if len(candidates) > topK {
			candidates = candidates[:topK]
		}
		return candidates, nil
	}

	return reranked, nil
}

func (s *ModelSearcher) rerank(ctx context.Context, query string, candidates []SearchResult, topK int) ([]SearchResult, error) {
	// Build prompt with candidates
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Query: %q\n\nRank these research entries by relevance to the query. ", query))
	sb.WriteString(fmt.Sprintf("Return the top %d as a JSON array of indices (0-based).\n\n", topK))

	for i, c := range candidates {
		sb.WriteString(fmt.Sprintf("[%d] Topic: %s\nContent: %s\n\n", i, c.Entry.Topic, truncateStr(c.Entry.Content, 300)))
	}

	sb.WriteString(fmt.Sprintf("\nRespond with ONLY a JSON array of the %d most relevant indices, ordered by relevance. Example: [3, 0, 7, 1, 5]", topK))

	req := apiclient.Request{
		Messages: []apiclient.Message{
			{Role: "user", Content: sb.String()},
		},
		System:    "You are a search relevance ranker. Given a query and candidate results, return the indices of the most relevant results ordered by relevance. Respond with ONLY a JSON array of integers.",
		MaxTokens: 256,
	}

	resp, err := s.client.Complete(ctx, req)
	if err != nil {
		return nil, fmt.Errorf("model re-rank: %w", err)
	}

	// Parse indices from model response
	indices := parseIndices(resp.Content, len(candidates), topK)
	if len(indices) == 0 {
		return nil, fmt.Errorf("model returned no valid indices")
	}

	results := make([]SearchResult, 0, len(indices))
	for rank, idx := range indices {
		r := candidates[idx]
		r.Score = float64(len(indices)-rank) / float64(len(indices)) // normalize 1.0 → 0.0
		results = append(results, r)
	}

	return results, nil
}

// parseIndices extracts valid indices from a JSON array string.
func parseIndices(content string, maxIdx, limit int) []int {
	content = strings.TrimSpace(content)
	// Strip markdown code fences
	if strings.HasPrefix(content, "```") {
		lines := strings.Split(content, "\n")
		if len(lines) > 2 {
			content = strings.Join(lines[1:len(lines)-1], "\n")
		}
	}
	content = strings.TrimSpace(content)

	var raw []int
	if err := json.Unmarshal([]byte(content), &raw); err != nil {
		return nil
	}

	// Filter valid indices and deduplicate
	seen := make(map[int]bool)
	var valid []int
	for _, idx := range raw {
		if idx >= 0 && idx < maxIdx && !seen[idx] {
			seen[idx] = true
			valid = append(valid, idx)
			if len(valid) >= limit {
				break
			}
		}
	}
	return valid
}

func truncateStr(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}
