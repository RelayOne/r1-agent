package research

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"fmt"
	"testing"
)

func TestParseIndices(t *testing.T) {
	tests := []struct {
		name    string
		content string
		maxIdx  int
		limit   int
		want    int
	}{
		{"valid", "[0, 2, 4]", 10, 5, 3},
		{"with fences", "```json\n[1, 3]\n```", 10, 5, 2},
		{"out of range", "[0, 99, 2]", 10, 5, 2},
		{"duplicates", "[0, 0, 1, 1]", 10, 5, 2},
		{"limit applied", "[0, 1, 2, 3, 4, 5]", 10, 3, 3},
		{"empty array", "[]", 10, 5, 0},
		{"invalid json", "not json", 10, 5, 0},
		{"negative indices", "[-1, 0, 1]", 10, 5, 2},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := parseIndices(tt.content, tt.maxIdx, tt.limit)
			if len(got) != tt.want {
				t.Errorf("got %d indices, want %d: %v", len(got), tt.want, got)
			}
		})
	}
}

func TestModelSearcherSearch(t *testing.T) {
	// Create a test store with some entries
	dir := t.TempDir()
	store, err := NewStore(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()

	// Add research entries with content that contains the search word literally
	for i := 0; i < 6; i++ {
		if err := store.Add(&Entry{
			ID:      fmt.Sprintf("e-%d", i),
			Topic:   "topic",
			Query:   "query",
			Content: fmt.Sprintf("entry %d about JWT tokens and authentication", i),
			Tags:    []string{"auth"},
		}); err != nil {
			t.Fatalf("add entry: %v", err)
		}
	}

	// Create mock re-ranking server that returns Anthropic-style response
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		// Anthropic response format
		json.NewEncoder(w).Encode(map[string]interface{}{
			"content": []map[string]string{
				{"type": "text", "text": "[0, 2]"},
			},
			"stop_reason": "end_turn",
			"model":       "claude-sonnet",
		})
	}))
	defer server.Close()

	searcher := NewModelSearcher(store, ModelSearchConfig{
		APIKey:    "test-key",
		BaseURL:   server.URL,
		PreFilter: 50,
	})

	// Search for "JWT" — literal match in content
	results, err := searcher.Search(context.Background(), "JWT", 2)
	if err != nil {
		t.Fatalf("search error: %v", err)
	}

	if len(results) == 0 {
		t.Error("expected results from pre-filter")
	}
}

func TestModelSearcherFewCandidates(t *testing.T) {
	dir := t.TempDir()
	store, err := NewStore(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()

	if err := store.Add(&Entry{ID: "r-1", Topic: "unique", Query: "unique", Content: "unique searchable content here", Tags: []string{"unique"}}); err != nil {
		t.Fatal(err)
	}

	searcher := NewModelSearcher(store, ModelSearchConfig{
		APIKey: "key",
	})

	// Requesting top 5 but only 1 candidate — should skip re-ranking
	results, err := searcher.Search(context.Background(), "unique", 5)
	if err != nil {
		t.Fatalf("error: %v", err)
	}
	if len(results) != 1 {
		t.Errorf("got %d results, want 1 (no re-ranking needed)", len(results))
	}
}

func TestModelSearcherEmptyStore(t *testing.T) {
	dir := t.TempDir()
	store, err := NewStore(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()

	searcher := NewModelSearcher(store, ModelSearchConfig{APIKey: "key"})

	results, err := searcher.Search(context.Background(), "anything", 5)
	if err != nil {
		t.Fatalf("error: %v", err)
	}
	if len(results) != 0 {
		t.Errorf("got %d results from empty store, want 0", len(results))
	}
}

func TestTruncateStr(t *testing.T) {
	if got := truncateStr("hello", 10); got != "hello" {
		t.Errorf("short string: %q", got)
	}
	if got := truncateStr("hello world", 5); got != "hello..." {
		t.Errorf("truncated: %q", got)
	}
}
