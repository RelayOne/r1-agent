package critic

import (
	"context"
	"errors"
	"testing"
)

// mockModelReviewer implements ModelReviewer for testing.
type mockModelReviewer struct {
	findings []Finding
	err      error
}

func (m *mockModelReviewer) ReviewDiff(_ context.Context, _ DiffContext) ([]Finding, error) {
	return m.findings, m.err
}

func TestReviewDeepNoModel(t *testing.T) {
	// Without a model reviewer, ReviewDeep should fall back to regex-only review.
	c := New(Config{})

	diff := DiffContext{
		Files: map[string]string{
			"main.go": "package main\n\nfunc main() {\n\tfmt.Println(\"hello\")\n}\n",
		},
		Diffs:           map[string]string{"main.go": "+fmt.Println(\"hello\")"},
		TaskDescription: "add hello world",
	}

	verdict := c.ReviewDeep(context.Background(), diff)
	if verdict == nil {
		t.Fatal("expected non-nil verdict")
	}

	// Should produce same result as Review since no model is configured.
	regexVerdict := c.Review(diff.Files)
	if len(verdict.Findings) != len(regexVerdict.Findings) {
		t.Errorf("ReviewDeep without model: got %d findings, want %d (same as Review)",
			len(verdict.Findings), len(regexVerdict.Findings))
	}
	if verdict.Pass != regexVerdict.Pass {
		t.Errorf("ReviewDeep without model: pass=%v, want %v", verdict.Pass, regexVerdict.Pass)
	}
}

func TestReviewDeepWithModel(t *testing.T) {
	// With a model reviewer, ReviewDeep should merge regex + model findings.
	modelFindings := []Finding{
		{
			Severity: SeverityWarn,
			Category: "logic",
			File:     "main.go",
			Line:     10,
			Message:  "potential nil dereference",
		},
		{
			Severity: SeverityInfo,
			Category: "style",
			File:     "utils.go",
			Line:     5,
			Message:  "consider using a constant",
		},
	}

	mock := &mockModelReviewer{findings: modelFindings}
	c := New(Config{ModelReviewer: mock})

	diff := DiffContext{
		Files: map[string]string{
			"main.go":  "package main\n\nfunc main() {\n\tfmt.Println(\"hello\")\n}\n",
			"utils.go": "package main\nfunc helper() {}\n",
		},
		Diffs:           map[string]string{"main.go": "+fmt.Println(\"hello\")"},
		TaskDescription: "add hello world",
	}

	verdict := c.ReviewDeep(context.Background(), diff)
	if verdict == nil {
		t.Fatal("expected non-nil verdict")
	}

	// Should have regex findings + model findings (merged).
	regexVerdict := c.Review(diff.Files)
	if len(verdict.Findings) < len(regexVerdict.Findings) {
		t.Errorf("ReviewDeep with model should have at least as many findings as regex-only: got %d, regex had %d",
			len(verdict.Findings), len(regexVerdict.Findings))
	}

	// Check that model findings are included.
	foundModelFinding := false
	for _, f := range verdict.Findings {
		if f.Message == "potential nil dereference" {
			foundModelFinding = true
			break
		}
	}
	if !foundModelFinding {
		t.Error("expected model finding 'potential nil dereference' in merged results")
	}
}

func TestReviewDeepModelError(t *testing.T) {
	// When the model reviewer returns an error, ReviewDeep should degrade
	// gracefully to regex-only results.
	mock := &mockModelReviewer{err: errors.New("API rate limit exceeded")}
	c := New(Config{ModelReviewer: mock})

	diff := DiffContext{
		Files: map[string]string{
			"main.go": "package main\n\nfunc main() {\n\tfmt.Println(\"hello\")\n}\n",
		},
		Diffs:           map[string]string{"main.go": "+fmt.Println(\"hello\")"},
		TaskDescription: "add hello world",
	}

	verdict := c.ReviewDeep(context.Background(), diff)
	if verdict == nil {
		t.Fatal("expected non-nil verdict on model error")
	}

	// Should produce same result as regex-only Review.
	regexVerdict := c.Review(diff.Files)
	if len(verdict.Findings) != len(regexVerdict.Findings) {
		t.Errorf("ReviewDeep on model error: got %d findings, want %d (same as Review)",
			len(verdict.Findings), len(regexVerdict.Findings))
	}
	if verdict.Pass != regexVerdict.Pass {
		t.Errorf("ReviewDeep on model error: pass=%v, want %v", verdict.Pass, regexVerdict.Pass)
	}
}

func TestDiffContextConstruction(t *testing.T) {
	files := map[string]string{
		"a.go": "package a\n",
		"b.go": "package b\n",
	}
	diffs := map[string]string{
		"a.go": "--- a/a.go\n+++ b/a.go\n@@ -1 +1 @@\n-package old\n+package a\n",
	}

	dc := DiffContext{
		Files:           files,
		Diffs:           diffs,
		TaskDescription: "refactor packages",
	}

	if len(dc.Files) != 2 {
		t.Errorf("expected 2 files, got %d", len(dc.Files))
	}
	if len(dc.Diffs) != 1 {
		t.Errorf("expected 1 diff, got %d", len(dc.Diffs))
	}
	if dc.TaskDescription != "refactor packages" {
		t.Errorf("task description mismatch: %q", dc.TaskDescription)
	}
	if dc.Files["a.go"] != "package a\n" {
		t.Errorf("file content mismatch for a.go: %q", dc.Files["a.go"])
	}
	if dc.Diffs["a.go"] == "" {
		t.Error("expected non-empty diff for a.go")
	}
}

func TestReviewDeepDeduplication(t *testing.T) {
	// Model returns a finding on the same file+line as a regex finding.
	// The duplicate should be removed.
	modelFindings := []Finding{
		{
			Severity: SeverityWarn,
			Category: "style",
			File:     "main.go",
			Line:     4, // same line as fmt.Println regex match
			Message:  "model also flagged this line",
		},
		{
			Severity: SeverityInfo,
			Category: "logic",
			File:     "main.go",
			Line:     20,
			Message:  "unique model finding",
		},
	}

	mock := &mockModelReviewer{findings: modelFindings}
	c := New(Config{ModelReviewer: mock})

	diff := DiffContext{
		Files: map[string]string{
			"main.go": "package main\n\nfunc main() {\n\tfmt.Println(\"hello\")\n}\n",
		},
		Diffs:           map[string]string{},
		TaskDescription: "test dedup",
	}

	verdict := c.ReviewDeep(context.Background(), diff)

	// Count findings for main.go line 4 -- should be exactly 1 (regex wins).
	line4Count := 0
	for _, f := range verdict.Findings {
		if f.File == "main.go" && f.Line == 4 {
			line4Count++
		}
	}
	if line4Count != 1 {
		t.Errorf("expected 1 finding for main.go:4 after dedup, got %d", line4Count)
	}

	// The unique model finding at line 20 should still be present.
	foundLine20 := false
	for _, f := range verdict.Findings {
		if f.File == "main.go" && f.Line == 20 {
			foundLine20 = true
			break
		}
	}
	if !foundLine20 {
		t.Error("expected unique model finding at line 20 to survive deduplication")
	}
}

func TestHasModelReviewer(t *testing.T) {
	c1 := New(Config{})
	if c1.HasModelReviewer() {
		t.Error("expected HasModelReviewer=false with no model configured")
	}

	c2 := New(Config{ModelReviewer: &mockModelReviewer{}})
	if !c2.HasModelReviewer() {
		t.Error("expected HasModelReviewer=true with model configured")
	}
}

func TestParseFindingsValidJSON(t *testing.T) {
	input := `[{"severity":"warn","category":"bug","file":"x.go","line":10,"message":"test","suggestion":"fix it"}]`
	findings, err := parseFindings(input)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(findings) != 1 {
		t.Fatalf("expected 1 finding, got %d", len(findings))
	}
	if findings[0].Severity != SeverityWarn {
		t.Errorf("severity: got %q, want %q", findings[0].Severity, SeverityWarn)
	}
	if findings[0].File != "x.go" {
		t.Errorf("file: got %q, want %q", findings[0].File, "x.go")
	}
}

func TestParseFindingsCodeFence(t *testing.T) {
	input := "```json\n[{\"severity\":\"info\",\"category\":\"style\",\"file\":\"a.go\",\"line\":1,\"message\":\"ok\",\"suggestion\":\"\"}]\n```"
	findings, err := parseFindings(input)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(findings) != 1 {
		t.Fatalf("expected 1 finding, got %d", len(findings))
	}
}

func TestParseFindingsEmptyArray(t *testing.T) {
	findings, err := parseFindings("[]")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(findings) != 0 {
		t.Errorf("expected 0 findings, got %d", len(findings))
	}
}

func TestParseFindingsInvalidJSON(t *testing.T) {
	_, err := parseFindings("This is not JSON at all")
	if err == nil {
		t.Error("expected error for invalid JSON")
	}
}

func TestReviewDeepBlockingModelFinding(t *testing.T) {
	// A blocking finding from the model should cause the verdict to fail.
	modelFindings := []Finding{
		{
			Severity: SeverityBlock,
			Category: "security",
			File:     "auth.go",
			Line:     15,
			Message:  "SQL injection vulnerability",
		},
	}

	mock := &mockModelReviewer{findings: modelFindings}
	c := New(Config{ModelReviewer: mock})

	diff := DiffContext{
		Files:           map[string]string{"auth.go": "package auth\n"},
		Diffs:           map[string]string{},
		TaskDescription: "add auth",
	}

	verdict := c.ReviewDeep(context.Background(), diff)
	if verdict.Pass {
		t.Error("expected verdict to fail with blocking model finding")
	}
}
