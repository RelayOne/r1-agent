package critic

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/ericmacdougall/stoke/internal/apiclient"
)

// ModelReviewer performs model-driven adversarial review of code changes.
type ModelReviewer interface {
	ReviewDiff(ctx context.Context, diff DiffContext) ([]Finding, error)
}

// DiffContext is the enriched context sent to the model for review.
type DiffContext struct {
	Files           map[string]string // file path -> full content for changed files
	Diffs           map[string]string // file path -> unified diff
	TaskDescription string            // what the changes are supposed to accomplish
}

// APIModelReviewer uses apiclient.Client for model-driven code review.
type APIModelReviewer struct {
	client *apiclient.Client
}

// ModelReviewerConfig configures the API-based model reviewer.
type ModelReviewerConfig struct {
	Provider apiclient.Provider
	APIKey   string
	BaseURL  string
	Model    string
}

// NewAPIModelReviewer creates a model reviewer backed by an API client.
func NewAPIModelReviewer(cfg ModelReviewerConfig) *APIModelReviewer {
	clientCfg := apiclient.Config{
		Provider: cfg.Provider,
		APIKey:   cfg.APIKey,
		BaseURL:  cfg.BaseURL,
		Model:    cfg.Model,
		Timeout:  2 * time.Minute,
	}
	if clientCfg.BaseURL == "" {
		if defaults, ok := apiclient.DefaultConfigs[cfg.Provider]; ok {
			clientCfg.BaseURL = defaults.BaseURL
		}
	}
	if clientCfg.Model == "" {
		if defaults, ok := apiclient.DefaultConfigs[cfg.Provider]; ok {
			clientCfg.Model = defaults.Model
		}
	}
	return &APIModelReviewer{
		client: apiclient.NewClient(clientCfg),
	}
}

const reviewSystemPrompt = `You are an adversarial code reviewer. Analyze these diffs for bugs, security issues, logic errors, missing edge cases.

Respond ONLY with a JSON array of findings. Each finding must have:
- "severity": one of "block", "warn", "info"
- "category": one of "bug", "security", "style", "performance", "correctness", "logic"
- "file": the file path
- "line": line number (0 if unknown)
- "message": clear description of the issue
- "suggestion": how to fix it (optional, empty string if none)

If no issues are found, respond with an empty array: []

Example response:
[{"severity":"warn","category":"bug","file":"main.go","line":42,"message":"nil pointer dereference possible when err is non-nil","suggestion":"Add nil check before accessing resp.Body"}]`

// ReviewDiff sends the diff context to the model for adversarial review.
func (r *APIModelReviewer) ReviewDiff(ctx context.Context, diff DiffContext) ([]Finding, error) {
	userPrompt := buildReviewPrompt(diff)

	resp, err := r.client.Complete(ctx, apiclient.Request{
		System: reviewSystemPrompt,
		Messages: []apiclient.Message{
			{Role: "user", Content: userPrompt},
		},
		MaxTokens: 4096,
	})
	if err != nil {
		return nil, fmt.Errorf("model review API call: %w", err)
	}

	findings, parseErr := parseFindings(resp.Content)
	if parseErr != nil {
		log.Printf("[stoke] model reviewer: could not parse JSON response, wrapping as info finding: %v", parseErr)
		return []Finding{{
			Severity: SeverityInfo,
			Category: "review",
			File:     "",
			Message:  fmt.Sprintf("Model review returned non-JSON response: %s", truncate(resp.Content, 200)),
		}}, nil
	}

	return findings, nil
}

func buildReviewPrompt(diff DiffContext) string {
	var b strings.Builder

	if diff.TaskDescription != "" {
		fmt.Fprintf(&b, "## Task\n%s\n\n", diff.TaskDescription)
	}

	fmt.Fprintf(&b, "## Diffs\n")
	for file, d := range diff.Diffs {
		fmt.Fprintf(&b, "### %s\n```diff\n%s\n```\n\n", file, d)
	}

	if len(diff.Files) > 0 {
		fmt.Fprintf(&b, "## Full File Contents\n")
		for file, content := range diff.Files {
			fmt.Fprintf(&b, "### %s\n```\n%s\n```\n\n", file, content)
		}
	}

	return b.String()
}

func parseFindings(content string) ([]Finding, error) {
	content = strings.TrimSpace(content)

	// Strip markdown code fences if the model wrapped the JSON.
	if strings.HasPrefix(content, "```") {
		lines := strings.Split(content, "\n")
		// Remove first line (```json or ```) and last line (```)
		if len(lines) >= 3 {
			end := len(lines) - 1
			for end > 0 && strings.TrimSpace(lines[end]) != "```" {
				end--
			}
			if end > 0 {
				content = strings.Join(lines[1:end], "\n")
			}
		}
	}

	content = strings.TrimSpace(content)

	var findings []Finding
	if err := json.Unmarshal([]byte(content), &findings); err != nil {
		return nil, fmt.Errorf("parse model findings JSON: %w", err)
	}
	return findings, nil
}

func truncate(s string, max int) string {
	if len(s) <= max {
		return s
	}
	return s[:max] + "..."
}
