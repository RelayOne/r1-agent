package engine

import (
	"context"
	"strings"
	"testing"

	"github.com/ericmacdougall/stoke/internal/apiclient"
)

func TestAPIRunnerPrepare(t *testing.T) {
	runner := NewAPIRunner()
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "refactor the auth module",
		WorktreeDir: "/tmp/test-worktree",
		PoolAPIKey:  "sk-test-key-123",
		PoolBaseURL: "https://api.anthropic.com",
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}

	// Binary should be empty (no subprocess)
	if prepared.Binary != "" {
		t.Errorf("binary = %q, want empty (no subprocess)", prepared.Binary)
	}

	// Dir should be the worktree
	if prepared.Dir != "/tmp/test-worktree" {
		t.Errorf("dir = %q, want /tmp/test-worktree", prepared.Dir)
	}

	// Notes should describe the API call
	if len(prepared.Notes) == 0 {
		t.Fatal("notes should not be empty")
	}
	notesJoined := strings.Join(prepared.Notes, " ")
	if !strings.Contains(notesJoined, "Native API runner") {
		t.Error("notes should mention Native API runner")
	}
	if !strings.Contains(notesJoined, "api.anthropic.com") {
		t.Error("notes should include the endpoint URL")
	}
	if !strings.Contains(notesJoined, "execute") {
		t.Error("notes should mention the phase name")
	}
}

func TestAPIRunnerPrepareDefaultBaseURL(t *testing.T) {
	runner := NewAPIRunner()
	prepared, err := runner.Prepare(RunSpec{
		Prompt:     "test prompt",
		PoolAPIKey: "sk-test-key",
		Phase:      PhaseSpec{Name: "plan"},
	})
	if err != nil {
		t.Fatal(err)
	}

	notesJoined := strings.Join(prepared.Notes, " ")
	if !strings.Contains(notesJoined, "api.anthropic.com/v1/messages") {
		t.Error("should default to Anthropic endpoint when no base URL given")
	}
}

func TestAPIRunnerPrepareCustomBaseURL(t *testing.T) {
	runner := NewAPIRunner()
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test prompt",
		PoolAPIKey:  "sk-test-key",
		PoolBaseURL: "http://localhost:4000",
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}

	notesJoined := strings.Join(prepared.Notes, " ")
	if !strings.Contains(notesJoined, "localhost:4000/v1/messages") {
		t.Errorf("notes should show custom endpoint, got: %s", notesJoined)
	}
}

func TestAPIRunnerRequiresAPIKey(t *testing.T) {
	runner := NewAPIRunner()
	_, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: "/tmp/test",
		PoolAPIKey:  "", // no key
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err == nil {
		t.Fatal("expected error when PoolAPIKey is empty")
	}
	if !strings.Contains(err.Error(), "API key") {
		t.Errorf("error should mention API key, got: %q", err.Error())
	}
}

func TestAPIRunnerImplementsCommandRunner(t *testing.T) {
	// Compile-time check that APIRunner satisfies CommandRunner
	var _ CommandRunner = (*APIRunner)(nil)
}

func TestDetectProvider(t *testing.T) {
	tests := []struct {
		baseURL  string
		expected apiclient.Provider
	}{
		{"", apiclient.ProviderAnthropic},
		{"https://api.anthropic.com", apiclient.ProviderAnthropic},
		{"https://api.openai.com", apiclient.ProviderOpenAI},
		{"https://openrouter.ai", apiclient.ProviderOpenRouter},
		{"http://localhost:4000", apiclient.ProviderOpenAI},           // LiteLLM proxy
		{"https://my-litellm.example.com", apiclient.ProviderOpenAI}, // custom proxy
	}

	for _, tt := range tests {
		t.Run(tt.baseURL, func(t *testing.T) {
			got := detectProvider(tt.baseURL)
			if got != tt.expected {
				t.Errorf("detectProvider(%q) = %q, want %q", tt.baseURL, got, tt.expected)
			}
		})
	}
}

func TestEstimateCost(t *testing.T) {
	usage := apiclient.Usage{
		InputTokens:  1000,
		OutputTokens: 500,
	}
	cost := estimateCost(usage)
	// 1000 * 3/1M + 500 * 15/1M = 0.003 + 0.0075 = 0.0105
	if cost < 0.010 || cost > 0.011 {
		t.Errorf("estimateCost = %f, want ~0.0105", cost)
	}
}

func TestEstimateCostZero(t *testing.T) {
	usage := apiclient.Usage{}
	cost := estimateCost(usage)
	if cost != 0 {
		t.Errorf("estimateCost for zero usage = %f, want 0", cost)
	}
}

func TestNewAPIRunnerDefaults(t *testing.T) {
	runner := NewAPIRunner()
	if runner.DefaultModel == "" {
		t.Error("DefaultModel should not be empty")
	}
	if runner.DefaultMaxTokens == 0 {
		t.Error("DefaultMaxTokens should not be zero")
	}
	if runner.Timeout == 0 {
		t.Error("Timeout should not be zero")
	}
}

func TestAPIRunnerRunRequiresAPIKey(t *testing.T) {
	runner := NewAPIRunner()
	_, err := runner.Run(context.Background(), RunSpec{
		Prompt:      "test",
		WorktreeDir: "/tmp/test",
		PoolAPIKey:  "",
		Phase:       PhaseSpec{Name: "execute"},
	}, nil)
	if err == nil {
		t.Fatal("expected error when PoolAPIKey is empty")
	}
	if !strings.Contains(err.Error(), "API key") {
		t.Errorf("error should mention API key, got: %q", err.Error())
	}
}

func TestAPIRunnerPrepareZeroMaxTokensFallback(t *testing.T) {
	// Cover the maxTokens == 0 fallback branch
	runner := &APIRunner{
		DefaultModel:     "test-model",
		DefaultMaxTokens: 0, // explicitly zero
	}
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: "/tmp/test",
		PoolAPIKey:  "sk-test",
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}
	notesJoined := strings.Join(prepared.Notes, " ")
	// Should fall back to 16000
	if !strings.Contains(notesJoined, "16000") {
		t.Errorf("should fall back to 16000 max tokens, got notes: %s", notesJoined)
	}
}

func TestAPIRunnerPrepareModelInNotes(t *testing.T) {
	runner := NewAPIRunner()
	prepared, err := runner.Prepare(RunSpec{
		Prompt:     "test",
		PoolAPIKey: "sk-test",
		Phase:      PhaseSpec{Name: "plan"},
	})
	if err != nil {
		t.Fatal(err)
	}
	notesJoined := strings.Join(prepared.Notes, " ")
	if !strings.Contains(notesJoined, runner.DefaultModel) {
		t.Errorf("notes should contain model name %q, got: %s", runner.DefaultModel, notesJoined)
	}
}

func TestAPIRunnerPreparePhaseNameInNotes(t *testing.T) {
	runner := NewAPIRunner()
	prepared, err := runner.Prepare(RunSpec{
		Prompt:     "test",
		PoolAPIKey: "sk-test",
		Phase:      PhaseSpec{Name: "custom-phase"},
	})
	if err != nil {
		t.Fatal(err)
	}
	notesJoined := strings.Join(prepared.Notes, " ")
	if !strings.Contains(notesJoined, "custom-phase") {
		t.Errorf("notes should contain phase name 'custom-phase', got: %s", notesJoined)
	}
}

func TestRegistryFields(t *testing.T) {
	// Verify Registry can hold runners and they satisfy CommandRunner
	claude := NewClaudeRunner("claude")
	codex := NewCodexRunner("codex")
	gemini := NewGeminiRunner("gemini")
	api := NewAPIRunner()

	reg := Registry{
		Claude: claude,
		Codex:  codex,
		Gemini: gemini,
		API:    api,
	}

	if reg.Claude == nil {
		t.Error("Claude runner should be set")
	}
	if reg.Codex == nil {
		t.Error("Codex runner should be set")
	}
	if reg.Gemini == nil {
		t.Error("Gemini runner should be set")
	}
	if reg.API == nil {
		t.Error("API runner should be set")
	}
}

func TestRegistryWithNilToolCache(t *testing.T) {
	reg := Registry{
		Claude: NewClaudeRunner("claude"),
	}
	if reg.ToolCache != nil {
		t.Error("ToolCache should be nil by default")
	}
}

func TestRunSpecAuthModes(t *testing.T) {
	if AuthModeSubscription != "mode1" {
		t.Errorf("AuthModeSubscription = %q, want 'mode1'", AuthModeSubscription)
	}
	if AuthModeAPIKey != "mode2" {
		t.Errorf("AuthModeAPIKey = %q, want 'mode2'", AuthModeAPIKey)
	}
}

func TestPhaseSpecReadOnly(t *testing.T) {
	phase := PhaseSpec{
		Name:     "verify",
		ReadOnly: true,
		Sandbox:  true,
	}
	if !phase.ReadOnly {
		t.Error("ReadOnly should be true")
	}
	if !phase.Sandbox {
		t.Error("Sandbox should be true")
	}
}

func TestPreparedCommandFields(t *testing.T) {
	cmd := PreparedCommand{
		Binary:          "claude",
		Args:            []string{"--bare", "-p", "test"},
		Dir:             "/tmp/worktree",
		Env:             []string{"PATH=/usr/bin"},
		Notes:           []string{"test note"},
		LastMessagePath: "/tmp/last-msg.txt",
	}
	if cmd.Binary != "claude" {
		t.Error("Binary mismatch")
	}
	if len(cmd.Args) != 3 {
		t.Error("Args length mismatch")
	}
	if cmd.Dir != "/tmp/worktree" {
		t.Error("Dir mismatch")
	}
	if cmd.LastMessagePath != "/tmp/last-msg.txt" {
		t.Error("LastMessagePath mismatch")
	}
}

func TestRunResultFields(t *testing.T) {
	result := RunResult{
		CostUSD:    0.05,
		DurationMs: 1500,
		NumTurns:   3,
		Subtype:    "success",
		IsError:    false,
		ResultText: "done",
		ExitCode:   0,
	}
	if result.CostUSD != 0.05 {
		t.Error("CostUSD mismatch")
	}
	if result.IsError {
		t.Error("IsError should be false")
	}
	if result.Subtype != "success" {
		t.Error("Subtype mismatch")
	}
}

func TestCommandRunnerInterfaceSatisfaction(t *testing.T) {
	// Compile-time checks that all runners satisfy CommandRunner
	var _ CommandRunner = (*ClaudeRunner)(nil)
	var _ CommandRunner = (*CodexRunner)(nil)
	var _ CommandRunner = (*GeminiRunner)(nil)
	var _ CommandRunner = (*APIRunner)(nil)
}
