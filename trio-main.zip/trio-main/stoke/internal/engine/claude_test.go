package engine

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestClaudePrepareStrictMCPAndSettings(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:        "test",
		WorktreeDir:   dir,
		RuntimeDir:    filepath.Join(dir, "runtime"),
		Mode:          AuthModeSubscription,
		PoolConfigDir: filepath.Join(dir, "pool"),
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read", "Glob", "Grep"},
			AllowedRules: []string{"Read"},
			DeniedRules:  []string{},
			MCPEnabled:   false,
			MaxTurns:     3,
		},
		SandboxEnabled: false,
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")
	// --bare already disables MCP; --strict-mcp-config is incompatible with --bare
	if !strings.Contains(joined, "--bare") {
		t.Error("missing --bare")
	}
	if !strings.Contains(joined, "--settings") {
		t.Error("missing --settings")
	}
}

func TestClaudePrepareMCPDisabledBlocksMCPTools(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read"},
			AllowedRules: []string{"Read"},
			DeniedRules:  []string{},
			MCPEnabled:   false,
			MaxTurns:     5,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")

	// Belt-and-suspenders: --disallowedTools should include mcp__*
	if !strings.Contains(joined, "mcp__*") {
		t.Error("MCP-disabled phase should add mcp__* to disallowedTools")
	}
	// --bare handles MCP isolation (--strict-mcp-config is incompatible with --bare)
	if !strings.Contains(joined, "--bare") {
		t.Error("missing --bare for MCP-disabled phase")
	}
}

func TestClaudePrepareMCPEnabledNoBlock(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read", "Edit"},
			AllowedRules: []string{"Read"},
			DeniedRules:  []string{"Bash(rm *)"},
			MCPEnabled:   true,
			MaxTurns:     20,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")

	if strings.Contains(joined, "--strict-mcp-config") {
		t.Error("MCP-enabled phase should not have --strict-mcp-config")
	}
	if strings.Contains(joined, "mcp__*") {
		t.Error("MCP-enabled phase should not block mcp__*")
	}
}

func TestClaudePrepareWritesSettingsJSON(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	_, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeSubscription,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read"},
			AllowedRules: []string{"Read"},
			DeniedRules:  []string{},
			MCPEnabled:   false,
			MaxTurns:     10,
		},
		SandboxEnabled:    true,
		SandboxDomains:    []string{"github.com"},
		SandboxAllowRead:  []string{dir},
		SandboxAllowWrite: []string{dir},
	})
	if err != nil {
		t.Fatal(err)
	}

	settingsPath := filepath.Join(dir, "runtime", "claude-settings-execute.json")
	data, err := os.ReadFile(settingsPath)
	if err != nil {
		t.Fatalf("settings file not written: %v", err)
	}

	var parsed map[string]interface{}
	if err := json.Unmarshal(data, &parsed); err != nil {
		t.Fatalf("invalid JSON: %v", err)
	}

	// apiKeyHelper should be null in Mode 1
	val, exists := parsed["apiKeyHelper"]
	if !exists {
		t.Error("apiKeyHelper key missing from settings")
	}
	if val != nil {
		t.Errorf("apiKeyHelper should be null in Mode 1, got %v", val)
	}

	// Sandbox should be present
	sandbox, ok := parsed["sandbox"].(map[string]interface{})
	if !ok {
		t.Fatal("sandbox section missing")
	}
	if sandbox["enabled"] != true {
		t.Error("sandbox.enabled should be true")
	}
	if sandbox["failIfUnavailable"] != true {
		t.Error("sandbox.failIfUnavailable should be true")
	}
}

func TestClaudePrepareMode1EnvIsolation(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("ANTHROPIC_API_KEY", "leaked-key")
	t.Setenv("PATH", "/usr/bin")

	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:        "test",
		WorktreeDir:   dir,
		RuntimeDir:    filepath.Join(dir, "runtime"),
		Mode:          AuthModeSubscription,
		PoolConfigDir: "/pool/claude-1",
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read"},
			MCPEnabled:   false,
			MaxTurns:     3,
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	envJoined := strings.Join(prepared.Env, "\n")
	if strings.Contains(envJoined, "ANTHROPIC_API_KEY=") {
		t.Error("Mode 1 should strip ANTHROPIC_API_KEY from env")
	}
	if !strings.Contains(envJoined, "CLAUDE_CONFIG_DIR=/pool/claude-1") {
		t.Error("Mode 1 should inject CLAUDE_CONFIG_DIR")
	}
}

func TestClaudePrepareRequiresWorktreeDir(t *testing.T) {
	runner := NewClaudeRunner("claude")
	_, err := runner.Prepare(RunSpec{
		WorktreeDir: "",
		RuntimeDir:  "/tmp/runtime",
		Prompt:      "test",
		Phase:       PhaseSpec{Name: "plan", BuiltinTools: []string{"Read"}, MaxTurns: 3},
	})
	if err == nil {
		t.Fatal("expected error for empty WorktreeDir")
	}
	if !strings.Contains(err.Error(), "missing worktree dir") {
		t.Errorf("error should mention missing worktree dir, got: %q", err.Error())
	}
}

func TestClaudePrepareRequiresRuntimeDir(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	_, err := runner.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  "",
		Prompt:      "test",
		Phase:       PhaseSpec{Name: "plan", BuiltinTools: []string{"Read"}, MaxTurns: 3},
	})
	if err == nil {
		t.Fatal("expected error for empty RuntimeDir")
	}
	if !strings.Contains(err.Error(), "missing runtime dir") {
		t.Errorf("error should mention missing runtime dir, got: %q", err.Error())
	}
}

func TestClaudePrepareBuildsCorrectArgs(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "do something",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read", "Edit"},
			MaxTurns:     10,
			MCPEnabled:   false,
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	joined := strings.Join(prepared.Args, " ")
	requiredFlags := []string{"--bare", "-p", "--verbose", "--output-format", "stream-json"}
	for _, flag := range requiredFlags {
		if !strings.Contains(joined, flag) {
			t.Errorf("args should contain %q, got: %s", flag, joined)
		}
	}
	// Verify prompt is in args
	if !strings.Contains(joined, "do something") {
		t.Error("args should contain the prompt text")
	}
	// Verify --tools with the built-in tools
	if !strings.Contains(joined, "Read,Edit") {
		t.Error("args should contain the tools list")
	}
	// Verify --max-turns
	if !strings.Contains(joined, "10") {
		t.Error("args should contain the max turns value")
	}
}

func TestClaudePrepareSettingsFile(t *testing.T) {
	dir := t.TempDir()
	runtimeDir := filepath.Join(dir, "runtime")
	runner := NewClaudeRunner("claude")
	_, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  runtimeDir,
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read"},
			MaxTurns:     5,
			MCPEnabled:   false,
		},
		SandboxEnabled: true,
	})
	if err != nil {
		t.Fatal(err)
	}

	// Verify the settings file was written to RuntimeDir
	settingsPath := filepath.Join(runtimeDir, "claude-settings-plan.json")
	data, err := os.ReadFile(settingsPath)
	if err != nil {
		t.Fatalf("settings file should exist at %s: %v", settingsPath, err)
	}
	if len(data) == 0 {
		t.Fatal("settings file should not be empty")
	}

	var parsed map[string]interface{}
	if err := json.Unmarshal(data, &parsed); err != nil {
		t.Fatalf("settings file should contain valid JSON: %v", err)
	}
}

func TestClaudePrepareMode2PassesEnv(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("ANTHROPIC_API_KEY", "should-keep")

	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read"},
			MCPEnabled:   false,
			MaxTurns:     3,
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	envJoined := strings.Join(prepared.Env, "\n")
	if strings.Contains(envJoined, "ANTHROPIC_API_KEY=should-keep") {
		t.Error("Mode 2 should strip dangerous vars like ANTHROPIC_API_KEY")
	}
}

func TestClaudePrepareWithDeniedRulesAndMCPDisabled(t *testing.T) {
	// Covers the branch where DeniedRules is non-empty AND MCPEnabled is false,
	// so mcp__* is appended to the denied list.
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test denied rules",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read", "Edit"},
			DeniedRules:  []string{"Bash(rm *)", "Write(/etc/*)"},
			MCPEnabled:   false,
			MaxTurns:     10,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")
	if !strings.Contains(joined, "--disallowedTools") {
		t.Error("should include --disallowedTools when DeniedRules is non-empty")
	}
	// mcp__* should be appended to denied list when MCP is disabled
	if !strings.Contains(joined, "mcp__*") {
		t.Error("should append mcp__* to disallowedTools when MCPEnabled is false")
	}
	// The denied rules themselves should be present
	if !strings.Contains(joined, "Bash(rm *)") {
		t.Error("should contain denied rule Bash(rm *)")
	}
}

func TestClaudePrepareWithDeniedRulesAndMCPEnabled(t *testing.T) {
	// Covers the branch where DeniedRules is non-empty AND MCPEnabled is true,
	// so mcp__* should NOT be appended.
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test denied rules with mcp",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read", "Edit"},
			DeniedRules:  []string{"Bash(rm *)"},
			MCPEnabled:   true,
			MaxTurns:     10,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")
	if !strings.Contains(joined, "--disallowedTools") {
		t.Error("should include --disallowedTools when DeniedRules is non-empty")
	}
	if strings.Contains(joined, "mcp__*") {
		t.Error("should NOT append mcp__* when MCPEnabled is true")
	}
}

func TestClaudePrepareWithAllowedRules(t *testing.T) {
	// Covers the AllowedRules branch (lines 92-94 in claude.go)
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test allowed rules",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read", "Glob", "Grep"},
			AllowedRules: []string{"Read", "Glob"},
			MCPEnabled:   false,
			MaxTurns:     5,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")
	if !strings.Contains(joined, "--allowedTools") {
		t.Error("should include --allowedTools when AllowedRules is non-empty")
	}
	if !strings.Contains(joined, "Read,Glob") {
		t.Error("should contain the allowed tools list")
	}
}

func TestClaudePreparePoolAPIKeyEnv(t *testing.T) {
	// Covers the PoolAPIKey branch in env selection (line 101)
	dir := t.TempDir()
	t.Setenv("ANTHROPIC_API_KEY", "should-be-overridden")

	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test pool api key",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		PoolAPIKey:  "pool-key-xyz",
		PoolBaseURL: "https://litellm.example.com",
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read"},
			MCPEnabled:   false,
			MaxTurns:     5,
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	envJoined := strings.Join(prepared.Env, "\n")
	if !strings.Contains(envJoined, "ANTHROPIC_API_KEY=pool-key-xyz") {
		t.Error("should inject pool API key as ANTHROPIC_API_KEY")
	}
	if !strings.Contains(envJoined, "ANTHROPIC_BASE_URL=https://litellm.example.com") {
		t.Error("should inject ANTHROPIC_BASE_URL from PoolBaseURL")
	}
}

func TestClaudePreparePoolAPIKeyWithoutBaseURL(t *testing.T) {
	// Pool API key set but no base URL
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test pool no base url",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		PoolAPIKey:  "pool-key-only",
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read"},
			MCPEnabled:   false,
			MaxTurns:     5,
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	envJoined := strings.Join(prepared.Env, "\n")
	if !strings.Contains(envJoined, "ANTHROPIC_API_KEY=pool-key-only") {
		t.Error("should inject pool API key")
	}
	if strings.Contains(envJoined, "ANTHROPIC_BASE_URL=") {
		t.Error("should not inject ANTHROPIC_BASE_URL when PoolBaseURL is empty")
	}
}

func TestClaudePrepareDirIsWorktree(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read"},
			MCPEnabled:   false,
			MaxTurns:     5,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	if prepared.Dir != dir {
		t.Errorf("Dir should be the worktree dir, got %q want %q", prepared.Dir, dir)
	}
	if prepared.Binary != "claude" {
		t.Errorf("Binary should be 'claude', got %q", prepared.Binary)
	}
}

func TestClaudePrepareMaxTurnsInArgs(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test max turns",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read"},
			MaxTurns:     42,
			MCPEnabled:   false,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	if !containsSequence(prepared.Args, "--max-turns", "42") {
		t.Errorf("args should contain --max-turns 42, got: %v", prepared.Args)
	}
}

func TestClaudePrepareToolsArg(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test tools arg",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read", "Edit", "Bash"},
			MaxTurns:     5,
			MCPEnabled:   false,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	if !containsSequence(prepared.Args, "--tools", "Read,Edit,Bash") {
		t.Errorf("args should contain --tools Read,Edit,Bash, got: %v", prepared.Args)
	}
}

func TestClaudePrepareSettingsFilePath(t *testing.T) {
	// Verify settings file is named with phase name
	dir := t.TempDir()
	runtimeDir := filepath.Join(dir, "runtime")
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  runtimeDir,
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "my-phase",
			BuiltinTools: []string{"Read"},
			MaxTurns:     3,
			MCPEnabled:   false,
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	expectedSettingsPath := filepath.Join(runtimeDir, "claude-settings-my-phase.json")
	if !containsSequence(prepared.Args, "--settings", expectedSettingsPath) {
		t.Errorf("--settings should point to %q, got args: %v", expectedSettingsPath, prepared.Args)
	}

	// Verify the file exists
	if _, err := os.Stat(expectedSettingsPath); os.IsNotExist(err) {
		t.Errorf("settings file should exist at %s", expectedSettingsPath)
	}
}

func TestClaudePrepareNotes(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read"},
			MaxTurns:     5,
			MCPEnabled:   false,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(prepared.Notes) == 0 {
		t.Fatal("notes should not be empty")
	}
	if !strings.Contains(prepared.Notes[0], "Claude Code") {
		t.Error("notes should mention Claude Code")
	}
	if !strings.Contains(prepared.Notes[0], "--bare") {
		t.Error("notes should mention --bare")
	}
}

// TestContextExceededDetection verifies that context window errors are
// correctly identified and tagged with the "context_exceeded" subtype.
func TestContextExceededDetection(t *testing.T) {
	tests := []struct {
		name       string
		resultText string
		subtype    string
		isError    bool
		wantSubtype string
	}{
		{
			name:        "context window keyword in result text",
			resultText:  "Error: context window exceeded, please reduce input size",
			subtype:     "error",
			isError:     true,
			wantSubtype: "context_exceeded",
		},
		{
			name:        "token limit keyword in result text",
			resultText:  "Request failed: token limit reached for this conversation",
			subtype:     "error_during_execution",
			isError:     true,
			wantSubtype: "context_exceeded",
		},
		{
			name:        "context keyword in subtype",
			resultText:  "something happened",
			subtype:     "context_length_exceeded",
			isError:     true,
			wantSubtype: "context_exceeded",
		},
		{
			name:        "case insensitive context match",
			resultText:  "CONTEXT window is full",
			subtype:     "error",
			isError:     true,
			wantSubtype: "context_exceeded",
		},
		{
			name:        "non-context error is not tagged",
			resultText:  "something went wrong",
			subtype:     "error_during_execution",
			isError:     true,
			wantSubtype: "error_during_execution",
		},
		{
			name:        "non-error result is not tagged even with context keyword",
			resultText:  "I added context to the function",
			subtype:     "success",
			isError:     false,
			wantSubtype: "success",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Simulate the detection logic from Run() to unit-test it directly
			resultSubtype := tt.subtype
			if tt.isError {
				lowText := strings.ToLower(tt.resultText)
				lowSubtype := strings.ToLower(tt.subtype)
				if strings.Contains(lowText, "context") ||
					strings.Contains(lowText, "token limit") ||
					strings.Contains(lowSubtype, "context") {
					resultSubtype = "context_exceeded"
				}
			}
			if resultSubtype != tt.wantSubtype {
				t.Errorf("got subtype %q, want %q", resultSubtype, tt.wantSubtype)
			}
		})
	}
}
