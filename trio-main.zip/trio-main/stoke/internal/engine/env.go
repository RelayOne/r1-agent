package engine

import (
	"os"
	"slices"
	"strings"
)

// SafeEnvForClaudeMode1 builds a scrubbed environment for Mode 1 Claude execution.
// Strips API keys, auth tokens, and cloud provider credentials.
func SafeEnvForClaudeMode1(configDir string) []string {
	return safeEnvForClaudeMode1(configDir)
}

func safeEnvForClaudeMode1(configDir string) []string {
	passthrough := []string{
		"PATH", "HOME", "TERM", "LANG", "SHELL", "TMPDIR", "USER",
		"NODE_PATH", "XDG_CONFIG_HOME", "XDG_DATA_HOME", "PWD",
	}
	passthroughPrefixes := []string{"npm_config_", "GIT_"}
	stripExact := map[string]bool{
		"ANTHROPIC_API_KEY":       true,
		"ANTHROPIC_AUTH_TOKEN":    true,
		"OPENAI_API_KEY":          true,
		"CODEX_API_KEY":           true,
		"CLAUDE_CODE_USE_BEDROCK": true,
		"CLAUDE_CODE_USE_VERTEX":  true,
		"CLAUDE_CODE_USE_FOUNDRY": true,
	}
	stripPrefixes := []string{"AWS_", "GOOGLE_", "AZURE_", "BEDROCK_", "VERTEX_"}

	env := []string{"CLAUDE_CONFIG_DIR=" + configDir}
	for _, entry := range os.Environ() {
		key, _, _ := strings.Cut(entry, "=")
		if stripExact[key] || hasAnyPrefix(key, stripPrefixes) {
			continue
		}
		if slices.Contains(passthrough, key) || hasAnyPrefix(key, passthroughPrefixes) {
			env = append(env, entry)
		}
	}
	return env
}

func safeEnvForCodexMode1(home string) []string {
	passthrough := []string{
		"PATH", "HOME", "TERM", "LANG", "SHELL", "TMPDIR", "USER", "PWD",
		"XDG_CONFIG_HOME", "XDG_DATA_HOME",
	}
	stripExact := map[string]bool{
		"OPENAI_API_KEY":       true,
		"CODEX_API_KEY":        true,
		"ANTHROPIC_API_KEY":    true,
		"ANTHROPIC_AUTH_TOKEN": true,
	}
	stripPrefixes := []string{"AWS_", "GOOGLE_", "AZURE_", "BEDROCK_", "VERTEX_"}

	env := []string{"CODEX_HOME=" + home}
	for _, entry := range os.Environ() {
		key, _, _ := strings.Cut(entry, "=")
		if stripExact[key] || hasAnyPrefix(key, stripPrefixes) {
			continue
		}
		if slices.Contains(passthrough, key) {
			env = append(env, entry)
		}
	}
	return env
}

// dangerousVars are environment variables that must never be passed to
// agent subprocesses, even in the permissive Mode 2.
var dangerousVars = map[string]bool{
	"ANTHROPIC_API_KEY":       true,
	"ANTHROPIC_AUTH_TOKEN":    true,
	"AWS_SECRET_ACCESS_KEY":   true,
	"AWS_SESSION_TOKEN":       true,
	"DATABASE_URL":            true,
	"DB_PASSWORD":             true,
	"STRIPE_SECRET_KEY":       true,
	"GITHUB_TOKEN":            true,
	"GH_TOKEN":                true,
	"OPENAI_API_KEY":          true,
	"CODEX_API_KEY":           true,
	"SLACK_TOKEN":             true,
	"SLACK_BOT_TOKEN":         true,
	"NPM_TOKEN":               true,
	"DOCKER_PASSWORD":         true,
	"VAULT_TOKEN":             true,
	"SENTRY_AUTH_TOKEN":       true,
	"TWILIO_AUTH_TOKEN":       true,
	"SENDGRID_API_KEY":        true,
	"DATADOG_API_KEY":         true,
	"HEROKU_API_KEY":          true,
	"DIGITALOCEAN_ACCESS_TOKEN": true,
}

func safeEnvMode2(extra map[string]string) []string {
	var env []string
	for _, entry := range os.Environ() {
		key, _, _ := strings.Cut(entry, "=")
		if dangerousVars[key] {
			continue
		}
		// Also strip variables with dangerous credential prefixes even in Mode 2.
		// Mode 1 strips these explicitly; Mode 2 must catch them too to avoid
		// leaking cloud/database secrets to agent subprocesses.
		if hasAnyPrefix(key, []string{"AWS_", "GOOGLE_", "AZURE_", "BEDROCK_", "VERTEX_",
			"STRIPE_", "GITHUB_", "GH_", "SLACK_", "DOCKER_", "VAULT_",
			"SENTRY_", "TWILIO_", "SENDGRID_", "DATADOG_", "HEROKU_",
			"DIGITALOCEAN_", "NPM_", "DB_", "DATABASE_"}) {
			continue
		}
		env = append(env, entry)
	}
	for key, value := range extra {
		env = append(env, key+"="+value)
	}
	return env
}

// safeEnvForAPIPool builds an environment for API key / proxy pools (e.g. LiteLLM).
// Injects ANTHROPIC_API_KEY and optionally ANTHROPIC_BASE_URL while stripping
// other dangerous credentials. This is the env for pools registered via add-api-pool.
func safeEnvForAPIPool(apiKey, baseURL string) []string {
	extra := map[string]string{
		"ANTHROPIC_API_KEY": apiKey,
	}
	if baseURL != "" {
		extra["ANTHROPIC_BASE_URL"] = baseURL
	}
	return safeEnvMode2(extra)
}

func hasAnyPrefix(s string, prefixes []string) bool {
	for _, prefix := range prefixes {
		if strings.HasPrefix(s, prefix) {
			return true
		}
	}
	return false
}
