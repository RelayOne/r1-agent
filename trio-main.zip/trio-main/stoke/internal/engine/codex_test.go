package engine

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestCodexPrepareUsesReadOnlyForVerify(t *testing.T) {
	dir := t.TempDir()
	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:        "review diff",
		WorktreeDir:   dir,
		RuntimeDir:    filepath.Join(dir, "runtime"),
		Mode:          AuthModeSubscription,
		PoolConfigDir: dir,
		Phase:         PhaseSpec{Name: "verify", ReadOnly: true},
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")
	if !containsSequence(prepared.Args, "--sandbox", "read-only") {
		t.Fatalf("verify phase should use read-only sandbox, got %q", joined)
	}
	if !containsSequence(prepared.Args, "--profile", "review") {
		t.Error("verify phase should use review profile")
	}
}

func TestCodexPrepareUsesWorkspaceWriteForExecute(t *testing.T) {
	dir := t.TempDir()
	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "implement feature",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if !containsSequence(prepared.Args, "--sandbox", "workspace-write") {
		t.Error("execute phase should use workspace-write sandbox")
	}
	if !containsSequence(prepared.Args, "--profile", "task") {
		t.Error("execute phase should use task profile")
	}
}

func TestCodexPrepareMode1IsolatesCredentials(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("OPENAI_API_KEY", "leaked-key")
	t.Setenv("PATH", "/usr/bin")

	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:        "test",
		WorktreeDir:   dir,
		RuntimeDir:    filepath.Join(dir, "runtime"),
		Mode:          AuthModeSubscription,
		PoolConfigDir: "/pool/codex-1",
		Phase:         PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}

	envJoined := strings.Join(prepared.Env, "\n")
	if strings.Contains(envJoined, "OPENAI_API_KEY=") {
		t.Error("Mode 1 should strip OPENAI_API_KEY")
	}
	if !strings.Contains(envJoined, "CODEX_HOME=/pool/codex-1") {
		t.Error("Mode 1 should inject CODEX_HOME")
	}
}

func TestCodexPrepareRequiresWorktreeDir(t *testing.T) {
	runner := NewCodexRunner("codex")
	_, err := runner.Prepare(RunSpec{
		WorktreeDir: "",
		RuntimeDir:  "/tmp/runtime",
		Prompt:      "test",
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err == nil {
		t.Fatal("expected error for empty WorktreeDir")
	}
	if !strings.Contains(err.Error(), "missing worktree dir") {
		t.Errorf("error should mention missing worktree dir, got: %q", err.Error())
	}
}

func TestCodexPrepareBuildsCorrectArgs(t *testing.T) {
	dir := t.TempDir()
	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "implement the feature",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase:       PhaseSpec{Name: "execute", ReadOnly: false},
	})
	if err != nil {
		t.Fatal(err)
	}

	// Verify the first arg is "exec"
	if len(prepared.Args) == 0 || prepared.Args[0] != "exec" {
		t.Fatalf("first arg should be 'exec', got: %v", prepared.Args)
	}

	joined := strings.Join(prepared.Args, " ")
	requiredFlags := []string{"--cd", "--sandbox", "--json", "--output-last-message", "--profile"}
	for _, flag := range requiredFlags {
		if !strings.Contains(joined, flag) {
			t.Errorf("args should contain %q, got: %s", flag, joined)
		}
	}

	// Verify WorktreeDir is passed to --cd
	if !containsSequence(prepared.Args, "--cd", dir) {
		t.Errorf("--cd should be followed by worktree dir %q", dir)
	}
}

func TestCodexPrepareReadOnlyMode(t *testing.T) {
	dir := t.TempDir()
	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "review changes",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase:       PhaseSpec{Name: "verify", ReadOnly: true},
	})
	if err != nil {
		t.Fatal(err)
	}

	if !containsSequence(prepared.Args, "--sandbox", "read-only") {
		t.Error("ReadOnly phase should set sandbox to 'read-only'")
	}
	if !containsSequence(prepared.Args, "--profile", "review") {
		t.Error("ReadOnly phase should set profile to 'review'")
	}
}

func TestCodexPrepareOutputsLastMessage(t *testing.T) {
	dir := t.TempDir()
	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")
	if !strings.Contains(joined, "--output-last-message") {
		t.Error("should include --output-last-message flag")
	}
	if !strings.Contains(joined, "--json") {
		t.Error("should include --json flag")
	}
}

func TestCodexPrepareLastMessagePath(t *testing.T) {
	dir := t.TempDir()
	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase:       PhaseSpec{Name: "review"},
	})
	if err != nil {
		t.Fatal(err)
	}
	expectedPath := filepath.Join(dir, "runtime", "codex-review-last-message.txt")
	if prepared.LastMessagePath != expectedPath {
		t.Errorf("LastMessagePath = %q, want %q", prepared.LastMessagePath, expectedPath)
	}
}

func TestCodexPrepareMode2EnvStripsSecrets(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("ANTHROPIC_API_KEY", "secret")
	t.Setenv("OPENAI_API_KEY", "openai-secret")
	t.Setenv("SAFE_VAR", "keep-me")

	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey, // Mode 2
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}
	envJoined := strings.Join(prepared.Env, "\n")
	if strings.Contains(envJoined, "ANTHROPIC_API_KEY=secret") {
		t.Error("Mode 2 should strip ANTHROPIC_API_KEY")
	}
	if strings.Contains(envJoined, "OPENAI_API_KEY=openai-secret") {
		t.Error("Mode 2 should strip OPENAI_API_KEY")
	}
	if !strings.Contains(envJoined, "SAFE_VAR=keep-me") {
		t.Error("Mode 2 should keep safe vars")
	}
}

func TestCodexPrepareBinaryIsSet(t *testing.T) {
	dir := t.TempDir()
	runner := NewCodexRunner("my-codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if prepared.Binary != "my-codex" {
		t.Errorf("Binary = %q, want 'my-codex'", prepared.Binary)
	}
	if prepared.Dir != dir {
		t.Errorf("Dir = %q, want %q", prepared.Dir, dir)
	}
}

func TestCodexPrepareNotesSet(t *testing.T) {
	dir := t.TempDir()
	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(prepared.Notes) == 0 {
		t.Fatal("notes should not be empty")
	}
	if !strings.Contains(prepared.Notes[0], "Codex") {
		t.Error("notes should mention Codex")
	}
}

func TestCodexPreparePromptInArgs(t *testing.T) {
	dir := t.TempDir()
	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "implement the auth module",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}
	// Prompt should be the last arg
	lastArg := prepared.Args[len(prepared.Args)-1]
	if lastArg != "implement the auth module" {
		t.Errorf("last arg should be the prompt, got %q", lastArg)
	}
}

func TestCodexPrepareCreatesRuntimeDir(t *testing.T) {
	dir := t.TempDir()
	runtimeDir := filepath.Join(dir, "deeply", "nested", "runtime")
	runner := NewCodexRunner("codex")
	_, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  runtimeDir,
		Mode:        AuthModeAPIKey,
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}
	// Verify the runtime directory was created
	info, statErr := os.Stat(runtimeDir)
	if statErr != nil {
		t.Fatalf("runtime dir should exist: %v", statErr)
	}
	if !info.IsDir() {
		t.Fatal("runtime dir should be a directory")
	}
}

func containsSequence(args []string, a, b string) bool {
	for i := 0; i < len(args)-1; i++ {
		if args[i] == a && args[i+1] == b {
			return true
		}
	}
	return false
}
