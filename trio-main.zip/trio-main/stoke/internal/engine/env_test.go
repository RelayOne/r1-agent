package engine

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSafeEnvForClaudeMode1StripsAuthVariables(t *testing.T) {
	t.Setenv("ANTHROPIC_API_KEY", "secret")
	t.Setenv("ANTHROPIC_AUTH_TOKEN", "token")
	t.Setenv("OPENAI_API_KEY", "openai")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForClaudeMode1("/tmp/pool")
	joined := strings.Join(env, "\n")
	if strings.Contains(joined, "ANTHROPIC_API_KEY=") || strings.Contains(joined, "OPENAI_API_KEY=") {
		t.Fatalf("auth env vars not stripped: %q", joined)
	}
	if !strings.Contains(joined, "CLAUDE_CONFIG_DIR=/tmp/pool") {
		t.Fatalf("CLAUDE_CONFIG_DIR not injected")
	}
}

func TestSafeEnvForClaudeMode1StripsCloudProviders(t *testing.T) {
	t.Setenv("AWS_ACCESS_KEY_ID", "aws-key")
	t.Setenv("AWS_SECRET_ACCESS_KEY", "aws-secret")
	t.Setenv("GOOGLE_APPLICATION_CREDENTIALS", "/path/creds.json")
	t.Setenv("AZURE_TENANT_ID", "tenant")
	t.Setenv("BEDROCK_ENDPOINT", "https://bedrock")
	t.Setenv("VERTEX_PROJECT", "proj")
	t.Setenv("CLAUDE_CODE_USE_BEDROCK", "1")
	t.Setenv("CLAUDE_CODE_USE_VERTEX", "1")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForClaudeMode1("/tmp/pool")
	joined := strings.Join(env, "\n")

	forbidden := []string{
		"AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY",
		"GOOGLE_APPLICATION_CREDENTIALS", "AZURE_TENANT_ID",
		"BEDROCK_ENDPOINT", "VERTEX_PROJECT",
		"CLAUDE_CODE_USE_BEDROCK", "CLAUDE_CODE_USE_VERTEX",
	}
	for _, key := range forbidden {
		if strings.Contains(joined, key+"=") {
			t.Errorf("cloud provider var %s should be stripped in Mode 1", key)
		}
	}
}

func TestSafeEnvForClaudeMode1PassesAllowlisted(t *testing.T) {
	t.Setenv("PATH", "/usr/bin")
	t.Setenv("HOME", "/home/test")
	t.Setenv("LANG", "en_US.UTF-8")
	t.Setenv("GIT_AUTHOR_NAME", "Test")
	t.Setenv("npm_config_registry", "https://registry.npmjs.org")

	env := safeEnvForClaudeMode1("/tmp/pool")
	joined := strings.Join(env, "\n")

	for _, key := range []string{"PATH=", "HOME=", "LANG=", "GIT_AUTHOR_NAME=", "npm_config_registry="} {
		if !strings.Contains(joined, key) {
			t.Errorf("allowlisted var %s should pass through", key)
		}
	}
}

func TestSafeEnvMode2StripsDangerousVars(t *testing.T) {
	t.Setenv("ANTHROPIC_API_KEY", "secret-key")
	t.Setenv("AWS_SECRET_ACCESS_KEY", "aws-secret")
	t.Setenv("CUSTOM_VAR", "custom-value")

	env := safeEnvMode2(map[string]string{"EXTRA": "val"})
	joined := strings.Join(env, "\n")

	// Dangerous vars should be stripped even in Mode 2
	for _, key := range []string{"ANTHROPIC_API_KEY=", "AWS_SECRET_ACCESS_KEY="} {
		if strings.Contains(joined, key) {
			t.Errorf("dangerous var %s should be stripped in Mode 2", key)
		}
	}
	// Safe vars and extras should still pass through
	if !strings.Contains(joined, "CUSTOM_VAR=custom-value") {
		t.Error("Mode 2 should pass safe custom vars")
	}
	if !strings.Contains(joined, "EXTRA=val") {
		t.Error("Mode 2 should inject extra vars")
	}
}

func TestSafeEnvForCodexMode1StripsAuth(t *testing.T) {
	t.Setenv("OPENAI_API_KEY", "openai-secret")
	t.Setenv("CODEX_API_KEY", "codex-secret")
	t.Setenv("ANTHROPIC_API_KEY", "anthropic-secret")
	t.Setenv("AWS_ACCESS_KEY_ID", "aws-key")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForCodexMode1("/tmp/codex-pool")
	joined := strings.Join(env, "\n")

	for _, key := range []string{"OPENAI_API_KEY=", "CODEX_API_KEY=", "ANTHROPIC_API_KEY=", "AWS_ACCESS_KEY_ID="} {
		if strings.Contains(joined, key) {
			t.Errorf("auth var %s should be stripped in Codex Mode 1", key)
		}
	}
	if !strings.Contains(joined, "CODEX_HOME=/tmp/codex-pool") {
		t.Error("CODEX_HOME should be injected")
	}
}

func TestMode1ConfigDirOverridesExisting(t *testing.T) {
	t.Setenv("CLAUDE_CONFIG_DIR", "/original/path")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForClaudeMode1("/override/path")
	configDirCount := 0
	for _, e := range env {
		if strings.HasPrefix(e, "CLAUDE_CONFIG_DIR=") {
			configDirCount++
			if e != "CLAUDE_CONFIG_DIR=/override/path" {
				t.Errorf("CLAUDE_CONFIG_DIR should be overridden, got %s", e)
			}
		}
	}
	if configDirCount != 1 {
		t.Errorf("expected exactly 1 CLAUDE_CONFIG_DIR, got %d", configDirCount)
	}
}

func TestHasAnyPrefix(t *testing.T) {
	prefixes := []string{"AWS_", "GITHUB_", "STRIPE_"}
	if !hasAnyPrefix("AWS_SECRET_KEY", prefixes) {
		t.Error("hasAnyPrefix(AWS_SECRET_KEY) should be true")
	}
	if !hasAnyPrefix("GITHUB_TOKEN", prefixes) {
		t.Error("hasAnyPrefix(GITHUB_TOKEN) should be true")
	}
	if hasAnyPrefix("HOME", prefixes) {
		t.Error("hasAnyPrefix(HOME) should be false")
	}
	if hasAnyPrefix("", prefixes) {
		t.Error("hasAnyPrefix(empty) should be false")
	}
}

func TestNewClaudeRunnerEmptyBinary(t *testing.T) {
	r := NewClaudeRunner("   ")
	if r.Binary != "claude" {
		t.Errorf("empty binary should default to 'claude', got %q", r.Binary)
	}
}

func TestNewCodexRunnerEmptyBinary(t *testing.T) {
	r := NewCodexRunner("")
	if r.Binary != "codex" {
		t.Errorf("empty binary should default to 'codex', got %q", r.Binary)
	}
}

func TestClaudeRunnerPrepareMissingWorktreeDir(t *testing.T) {
	r := NewClaudeRunner("claude")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: "",
		RuntimeDir:  "/tmp/runtime",
	})
	if err == nil {
		t.Error("expected error for missing worktree dir")
	}
}

func TestClaudeRunnerPrepareMissingRuntimeDir(t *testing.T) {
	r := NewClaudeRunner("claude")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: "/tmp/worktree",
		RuntimeDir:  "",
	})
	if err == nil {
		t.Error("expected error for missing runtime dir")
	}
}

func TestClaudeRunnerPrepareCreatesRuntimeDir(t *testing.T) {
	r := NewClaudeRunner("claude")
	dir := t.TempDir()
	_, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  dir + "/runtime",
	})
	if err != nil {
		t.Errorf("Prepare() should create runtime dir: %v", err)
	}
}

func TestClaudeRunnerRunPrepareError(t *testing.T) {
	r := NewClaudeRunner("claude")
	_, err := r.Run(context.Background(), RunSpec{
		WorktreeDir: "",
		RuntimeDir:  "/tmp/runtime",
	}, nil)
	if err == nil {
		t.Error("expected error from Run() when Prepare() fails")
	}
}

func TestCodexRunnerPrepareMissingWorktreeDir(t *testing.T) {
	r := NewCodexRunner("codex")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: "",
		RuntimeDir:  "/tmp/runtime",
	})
	if err == nil {
		t.Error("expected error for missing worktree dir")
	}
}

func TestCodexRunnerPrepareMissingRuntimeDir(t *testing.T) {
	r := NewCodexRunner("codex")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: "/tmp/worktree",
		RuntimeDir:  "",
	})
	if err == nil {
		t.Error("expected error for missing runtime dir")
	}
}

func TestCodexRunnerPrepareReadOnly(t *testing.T) {
	r := NewCodexRunner("codex")
	dir := t.TempDir()
	cmd, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  dir + "/runtime",
		Phase:       PhaseSpec{Name: "verify", ReadOnly: true},
	})
	if err != nil {
		t.Fatal(err)
	}
	args := strings.Join(cmd.Args, " ")
	if !strings.Contains(args, "read-only") {
		t.Errorf("ReadOnly should use sandbox=read-only, got args: %s", args)
	}
	if !strings.Contains(args, "review") {
		t.Errorf("ReadOnly should use profile=review, got args: %s", args)
	}
}

func TestCodexRunnerPrepareDefaultSandbox(t *testing.T) {
	r := NewCodexRunner("codex")
	dir := t.TempDir()
	cmd, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  dir + "/runtime",
		Phase:       PhaseSpec{Name: "execute", ReadOnly: false},
	})
	if err != nil {
		t.Fatal(err)
	}
	args := strings.Join(cmd.Args, " ")
	if !strings.Contains(args, "workspace-write") {
		t.Errorf("Default should use sandbox=workspace-write, got args: %s", args)
	}
}

func TestSafeEnvForClaudeMode1PassthroughPrefix(t *testing.T) {
	t.Setenv("GIT_TRACE", "true")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForClaudeMode1("/tmp/pool")
	joined := strings.Join(env, "\n")

	if !strings.Contains(joined, "GIT_TRACE=true") {
		t.Error("GIT_TRACE should pass through via GIT_ prefix rule")
	}
	if !strings.Contains(joined, "PATH=/usr/bin") {
		t.Error("PATH should pass through via exact passthrough rule")
	}
}

func TestSafeEnvMode2StripsCredentialPrefixes(t *testing.T) {
	t.Setenv("GITHUB_TOKEN", "ghp_secret")
	t.Setenv("STRIPE_SECRET_KEY", "sk_live_secret")
	t.Setenv("NPM_TOKEN", "npm_secret")
	t.Setenv("DB_PASSWORD", "db_secret")
	t.Setenv("DATABASE_URL", "postgres://user:pass@host/db")

	env := safeEnvMode2(nil)
	joined := strings.Join(env, "\n")

	for _, key := range []string{"GITHUB_TOKEN=", "STRIPE_SECRET_KEY=", "NPM_TOKEN=", "DB_PASSWORD=", "DATABASE_URL="} {
		if strings.Contains(joined, key) {
			t.Errorf("credential prefix var %s should be stripped in Mode 2", key)
		}
	}
}

func TestSafeEnvMode2StripsKeys(t *testing.T) {
	// Set dangerous env vars that must be stripped
	t.Setenv("ANTHROPIC_API_KEY", "sk-ant-secret")
	t.Setenv("OPENAI_API_KEY", "sk-openai-secret")
	t.Setenv("CODEX_API_KEY", "codex-secret")
	t.Setenv("VAULT_TOKEN", "hvs-secret")
	t.Setenv("SLACK_BOT_TOKEN", "xoxb-secret")
	t.Setenv("SENTRY_AUTH_TOKEN", "sentry-secret")
	t.Setenv("SAFE_CUSTOM_VAR", "keep-this")

	env := safeEnvMode2(nil)
	joined := strings.Join(env, "\n")

	forbidden := []string{
		"ANTHROPIC_API_KEY=",
		"OPENAI_API_KEY=",
		"CODEX_API_KEY=",
		"VAULT_TOKEN=",
		"SLACK_BOT_TOKEN=",
		"SENTRY_AUTH_TOKEN=",
	}
	for _, key := range forbidden {
		if strings.Contains(joined, key) {
			t.Errorf("safeEnvMode2 should strip %s", key)
		}
	}
	if !strings.Contains(joined, "SAFE_CUSTOM_VAR=keep-this") {
		t.Error("safeEnvMode2 should preserve non-dangerous vars")
	}
}

func TestSafeEnvForAPIPool(t *testing.T) {
	// Strip any existing dangerous vars
	t.Setenv("ANTHROPIC_API_KEY", "should-be-overridden")
	t.Setenv("OPENAI_API_KEY", "should-be-stripped")

	env := safeEnvForAPIPool("pool-key-123", "https://litellm.example.com")
	joined := strings.Join(env, "\n")

	// The pool API key should be injected
	if !strings.Contains(joined, "ANTHROPIC_API_KEY=pool-key-123") {
		t.Error("safeEnvForAPIPool should inject ANTHROPIC_API_KEY with pool key")
	}
	// The base URL should be injected
	if !strings.Contains(joined, "ANTHROPIC_BASE_URL=https://litellm.example.com") {
		t.Error("safeEnvForAPIPool should inject ANTHROPIC_BASE_URL")
	}
	// Other dangerous vars should still be stripped
	if strings.Contains(joined, "OPENAI_API_KEY=") {
		t.Error("safeEnvForAPIPool should still strip OPENAI_API_KEY")
	}
}

func TestSafeEnvForAPIPoolNoBaseURL(t *testing.T) {
	env := safeEnvForAPIPool("pool-key-456", "")
	joined := strings.Join(env, "\n")

	if !strings.Contains(joined, "ANTHROPIC_API_KEY=pool-key-456") {
		t.Error("safeEnvForAPIPool should inject ANTHROPIC_API_KEY")
	}
	if strings.Contains(joined, "ANTHROPIC_BASE_URL=") {
		t.Error("safeEnvForAPIPool should not inject ANTHROPIC_BASE_URL when empty")
	}
}

func TestSafeEnvForClaudeMode1Exported(t *testing.T) {
	// Cover the exported wrapper SafeEnvForClaudeMode1
	t.Setenv("ANTHROPIC_API_KEY", "secret")
	t.Setenv("PATH", "/usr/bin")

	env := SafeEnvForClaudeMode1("/tmp/pool-export")
	joined := strings.Join(env, "\n")
	if strings.Contains(joined, "ANTHROPIC_API_KEY=secret") {
		t.Error("exported wrapper should strip ANTHROPIC_API_KEY")
	}
	if !strings.Contains(joined, "CLAUDE_CONFIG_DIR=/tmp/pool-export") {
		t.Error("exported wrapper should inject CLAUDE_CONFIG_DIR")
	}
}

func TestSafeEnvMode2StripsDangerousPrefixes(t *testing.T) {
	// Cover the prefix-stripping branch in safeEnvMode2 that catches
	// vars with dangerous credential prefixes even when not in the
	// exact dangerousVars map.
	t.Setenv("STRIPE_LIVE_KEY", "sk_live_extra")
	t.Setenv("GH_ENTERPRISE_TOKEN", "ghe-token")
	t.Setenv("SLACK_WEBHOOK_URL", "https://hooks.slack.com/xxx")
	t.Setenv("DOCKER_AUTH_CONFIG", "base64config")
	t.Setenv("VAULT_ADDR", "https://vault.example.com")
	t.Setenv("SENTRY_DSN", "https://sentry.io/123")
	t.Setenv("TWILIO_ACCOUNT_SID", "AC123")
	t.Setenv("SENDGRID_TEMPLATE_ID", "tmpl-123")
	t.Setenv("DATADOG_APP_KEY", "dd-app-key")
	t.Setenv("HEROKU_APP_NAME", "my-app")
	t.Setenv("DIGITALOCEAN_REGION", "nyc1")
	t.Setenv("GOOGLE_CLOUD_PROJECT", "proj-123")
	t.Setenv("AZURE_CLIENT_ID", "client-id")
	t.Setenv("BEDROCK_MODEL_ID", "model-123")
	t.Setenv("VERTEX_LOCATION", "us-central1")
	t.Setenv("DATABASE_POOL_SIZE", "10")
	t.Setenv("SAFE_CUSTOM_VAR", "safe-val")

	env := safeEnvMode2(nil)
	joined := strings.Join(env, "\n")

	forbidden := []string{
		"STRIPE_LIVE_KEY=", "GH_ENTERPRISE_TOKEN=", "SLACK_WEBHOOK_URL=",
		"DOCKER_AUTH_CONFIG=", "VAULT_ADDR=", "SENTRY_DSN=",
		"TWILIO_ACCOUNT_SID=", "SENDGRID_TEMPLATE_ID=", "DATADOG_APP_KEY=",
		"HEROKU_APP_NAME=", "DIGITALOCEAN_REGION=",
		"GOOGLE_CLOUD_PROJECT=", "AZURE_CLIENT_ID=",
		"BEDROCK_MODEL_ID=", "VERTEX_LOCATION=",
		"DATABASE_POOL_SIZE=",
	}
	for _, key := range forbidden {
		if strings.Contains(joined, key) {
			t.Errorf("safeEnvMode2 should strip prefix-matched var %s", key)
		}
	}
	if !strings.Contains(joined, "SAFE_CUSTOM_VAR=safe-val") {
		t.Error("safeEnvMode2 should preserve non-dangerous vars")
	}
}

func TestSafeEnvMode2WithNilExtra(t *testing.T) {
	// Ensure nil extra map works (no panic)
	t.Setenv("SAFE_VAR", "value")
	env := safeEnvMode2(nil)
	joined := strings.Join(env, "\n")
	if !strings.Contains(joined, "SAFE_VAR=value") {
		t.Error("nil extra should still pass through safe vars")
	}
}

func TestSafeEnvMode2WithMultipleExtras(t *testing.T) {
	env := safeEnvMode2(map[string]string{
		"INJECTED_A": "val-a",
		"INJECTED_B": "val-b",
	})
	joined := strings.Join(env, "\n")
	if !strings.Contains(joined, "INJECTED_A=val-a") {
		t.Error("extra vars should be injected")
	}
	if !strings.Contains(joined, "INJECTED_B=val-b") {
		t.Error("extra vars should be injected")
	}
}

func TestClaudeRunnerPrepareMergesHooks(t *testing.T) {
	// When hooks are installed, the settings JSON should include hook configuration.
	// We test this indirectly by verifying Prepare succeeds with hooks installed.
	dir := t.TempDir()
	hooksDir := dir + "/hooks"
	os.MkdirAll(hooksDir, 0755)
	os.WriteFile(hooksDir+"/pre-tool-use.sh", []byte("#!/bin/bash\nexit 0\n"), 0755)
	os.WriteFile(hooksDir+"/post-tool-use.sh", []byte("#!/bin/bash\nexit 0\n"), 0755)

	r := NewClaudeRunner("claude")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  dir + "/runtime",
	})
	if err != nil {
		t.Fatal(err)
	}
	// If Prepare succeeds without error, hook merging did not crash
}

// --- Additional tests for coverage boost ---

func TestClaudeRunnerPrepareWhitespaceWorktreeDir(t *testing.T) {
	r := NewClaudeRunner("claude")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: "   ",
		RuntimeDir:  "/tmp/runtime",
	})
	if err == nil {
		t.Error("expected error for whitespace-only worktree dir")
	}
}

func TestClaudeRunnerPrepareWhitespaceRuntimeDir(t *testing.T) {
	dir := t.TempDir()
	r := NewClaudeRunner("claude")
	// RuntimeDir is empty string, which triggers "missing runtime dir"
	_, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  "",
	})
	if err == nil {
		t.Error("expected error for empty runtime dir")
	}
	if !strings.Contains(err.Error(), "missing runtime dir") {
		t.Errorf("expected 'missing runtime dir' error, got: %q", err.Error())
	}
}

func TestCodexRunnerPrepareWhitespaceWorktreeDir(t *testing.T) {
	r := NewCodexRunner("codex")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: "   ",
		RuntimeDir:  "/tmp/runtime",
	})
	if err == nil {
		t.Error("expected error for whitespace-only worktree dir")
	}
}

func TestNewClaudeRunnerCustomBinary(t *testing.T) {
	r := NewClaudeRunner("/usr/local/bin/custom-claude")
	if r.Binary != "/usr/local/bin/custom-claude" {
		t.Errorf("binary=%q, want /usr/local/bin/custom-claude", r.Binary)
	}
	if r.Parser == nil {
		t.Error("parser should be initialized")
	}
}

func TestNewCodexRunnerCustomBinary(t *testing.T) {
	r := NewCodexRunner("/usr/local/bin/custom-codex")
	if r.Binary != "/usr/local/bin/custom-codex" {
		t.Errorf("binary=%q, want /usr/local/bin/custom-codex", r.Binary)
	}
	if r.Parser == nil {
		t.Error("parser should be initialized")
	}
}

func TestNewCodexRunnerWhitespaceBinary(t *testing.T) {
	r := NewCodexRunner("   ")
	if r.Binary != "codex" {
		t.Errorf("whitespace binary should default to 'codex', got %q", r.Binary)
	}
}

func TestCodexRunnerRunPrepareError(t *testing.T) {
	r := NewCodexRunner("codex")
	_, err := r.Run(context.Background(), RunSpec{
		WorktreeDir: "",
		RuntimeDir:  "/tmp/runtime",
	}, nil)
	if err == nil {
		t.Error("expected error from Run() when Prepare() fails")
	}
}

func TestAuthModeConstants(t *testing.T) {
	// Verify the string representation of AuthMode constants
	if string(AuthModeSubscription) != "mode1" {
		t.Errorf("AuthModeSubscription = %q, want 'mode1'", AuthModeSubscription)
	}
	if string(AuthModeAPIKey) != "mode2" {
		t.Errorf("AuthModeAPIKey = %q, want 'mode2'", AuthModeAPIKey)
	}
	// Verify they are distinct
	if AuthModeSubscription == AuthModeAPIKey {
		t.Error("AuthModeSubscription and AuthModeAPIKey should be distinct")
	}
}

func TestAuthModeStringConversion(t *testing.T) {
	// AuthMode values can be converted to/from strings
	var m AuthMode = "mode1"
	if m != AuthModeSubscription {
		t.Errorf("mode1 should equal AuthModeSubscription")
	}
	m = "mode2"
	if m != AuthModeAPIKey {
		t.Errorf("mode2 should equal AuthModeAPIKey")
	}
}

func TestRegistryNilFields(t *testing.T) {
	// Zero-value Registry has all nil fields
	var reg Registry
	if reg.Claude != nil {
		t.Error("Claude should be nil by default")
	}
	if reg.Codex != nil {
		t.Error("Codex should be nil by default")
	}
	if reg.Gemini != nil {
		t.Error("Gemini should be nil by default")
	}
	if reg.API != nil {
		t.Error("API should be nil by default")
	}
	if reg.ToolCache != nil {
		t.Error("ToolCache should be nil by default")
	}
}

func TestRegistryPartialPopulation(t *testing.T) {
	// Registry with only some runners populated
	reg := Registry{
		Claude: NewClaudeRunner("claude"),
	}
	if reg.Claude == nil {
		t.Fatal("Claude runner should be set")
	}
	if reg.Codex != nil {
		t.Fatal("Codex should be nil when not set")
	}
	if reg.Gemini != nil {
		t.Fatal("Gemini should be nil when not set")
	}
	if reg.API != nil {
		t.Fatal("API should be nil when not set")
	}
	if reg.ToolCache != nil {
		t.Fatal("ToolCache should be nil when not set")
	}
}

func TestPhaseSpecDefaults(t *testing.T) {
	// Zero-value PhaseSpec
	var ps PhaseSpec
	if ps.Name != "" {
		t.Error("Name should be empty")
	}
	if ps.MCPEnabled {
		t.Error("MCPEnabled should default to false")
	}
	if ps.ReadOnly {
		t.Error("ReadOnly should default to false")
	}
	if ps.Sandbox {
		t.Error("Sandbox should default to false")
	}
	if ps.MaxTurns != 0 {
		t.Errorf("MaxTurns should be 0, got %d", ps.MaxTurns)
	}
	if len(ps.BuiltinTools) != 0 {
		t.Error("BuiltinTools should be empty")
	}
	if ps.CompletionPromise != "" {
		t.Error("CompletionPromise should be empty")
	}
}

func TestPhaseSpecAllFieldsPopulated(t *testing.T) {
	ps := PhaseSpec{
		Name:              "execute",
		BuiltinTools:      []string{"Read", "Edit", "Bash"},
		AllowedRules:      []string{"Read"},
		DeniedRules:       []string{"Bash(rm *)"},
		MCPEnabled:        true,
		MaxTurns:          20,
		Prompt:            "Do the task",
		Sandbox:           true,
		ReadOnly:          false,
		CompletionPromise: "TASK_COMPLETE",
	}
	if ps.Name != "execute" {
		t.Errorf("Name=%q", ps.Name)
	}
	if len(ps.BuiltinTools) != 3 {
		t.Errorf("BuiltinTools len=%d", len(ps.BuiltinTools))
	}
	if ps.CompletionPromise != "TASK_COMPLETE" {
		t.Errorf("CompletionPromise=%q", ps.CompletionPromise)
	}
}

func TestRunResultDefaults(t *testing.T) {
	// Zero-value RunResult
	var rr RunResult
	if rr.CostUSD != 0 {
		t.Error("CostUSD should be 0")
	}
	if rr.IsError {
		t.Error("IsError should be false")
	}
	if rr.ExitCode != 0 {
		t.Error("ExitCode should be 0")
	}
	if rr.ResultText != "" {
		t.Error("ResultText should be empty")
	}
}

func TestRunSpecDefaults(t *testing.T) {
	// Zero-value RunSpec
	var rs RunSpec
	if rs.Prompt != "" {
		t.Error("Prompt should be empty")
	}
	if rs.WorktreeDir != "" {
		t.Error("WorktreeDir should be empty")
	}
	if rs.Mode != "" {
		t.Errorf("Mode should be empty, got %q", rs.Mode)
	}
	if rs.SandboxEnabled {
		t.Error("SandboxEnabled should be false")
	}
	if len(rs.SandboxDomains) != 0 {
		t.Error("SandboxDomains should be empty")
	}
	if rs.MCPClient != nil {
		t.Error("MCPClient should be nil")
	}
}

func TestPreparedCommandDefaults(t *testing.T) {
	var pc PreparedCommand
	if pc.Binary != "" {
		t.Error("Binary should be empty")
	}
	if pc.Dir != "" {
		t.Error("Dir should be empty")
	}
	if pc.LastMessagePath != "" {
		t.Error("LastMessagePath should be empty")
	}
	if len(pc.Args) != 0 {
		t.Error("Args should be empty")
	}
	if len(pc.Env) != 0 {
		t.Error("Env should be empty")
	}
	if len(pc.Notes) != 0 {
		t.Error("Notes should be empty")
	}
}

func TestSafeEnvForCodexMode1PassesAllowlisted(t *testing.T) {
	t.Setenv("PATH", "/usr/bin")
	t.Setenv("HOME", "/home/test")
	t.Setenv("TERM", "xterm-256color")
	t.Setenv("LANG", "en_US.UTF-8")
	t.Setenv("PWD", "/tmp")
	t.Setenv("XDG_CONFIG_HOME", "/home/test/.config")

	env := safeEnvForCodexMode1("/tmp/codex-pool")
	joined := strings.Join(env, "\n")

	for _, key := range []string{"PATH=", "HOME=", "TERM=", "LANG=", "PWD=", "XDG_CONFIG_HOME="} {
		if !strings.Contains(joined, key) {
			t.Errorf("allowlisted var %s should pass through in Codex Mode 1", key)
		}
	}
}

func TestSafeEnvForCodexMode1StripsCloudProviders(t *testing.T) {
	t.Setenv("AWS_ACCESS_KEY_ID", "aws-key")
	t.Setenv("GOOGLE_APPLICATION_CREDENTIALS", "/path/creds.json")
	t.Setenv("AZURE_TENANT_ID", "tenant")
	t.Setenv("BEDROCK_ENDPOINT", "https://bedrock")
	t.Setenv("VERTEX_PROJECT", "proj")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForCodexMode1("/tmp/pool")
	joined := strings.Join(env, "\n")

	for _, key := range []string{"AWS_ACCESS_KEY_ID=", "GOOGLE_APPLICATION_CREDENTIALS=", "AZURE_TENANT_ID=", "BEDROCK_ENDPOINT=", "VERTEX_PROJECT="} {
		if strings.Contains(joined, key) {
			t.Errorf("cloud provider var %s should be stripped in Codex Mode 1", key)
		}
	}
}

func TestHasAnyPrefixEmptyPrefixes(t *testing.T) {
	if hasAnyPrefix("AWS_KEY", nil) {
		t.Error("nil prefixes should return false")
	}
	if hasAnyPrefix("AWS_KEY", []string{}) {
		t.Error("empty prefixes should return false")
	}
}

func TestDangerousVarsCompleteness(t *testing.T) {
	// Verify that all expected dangerous vars are in the map
	expected := []string{
		"ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN",
		"AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN",
		"DATABASE_URL", "DB_PASSWORD",
		"STRIPE_SECRET_KEY", "GITHUB_TOKEN", "GH_TOKEN",
		"OPENAI_API_KEY", "CODEX_API_KEY",
		"SLACK_TOKEN", "SLACK_BOT_TOKEN",
		"NPM_TOKEN", "DOCKER_PASSWORD",
		"VAULT_TOKEN", "SENTRY_AUTH_TOKEN",
		"TWILIO_AUTH_TOKEN", "SENDGRID_API_KEY",
		"DATADOG_API_KEY", "HEROKU_API_KEY",
		"DIGITALOCEAN_ACCESS_TOKEN",
	}
	for _, key := range expected {
		if !dangerousVars[key] {
			t.Errorf("dangerousVars should contain %q", key)
		}
	}
}

func TestSafeEnvForAPIPoolInjectsExactly(t *testing.T) {
	// Verify API pool env has the pool key and base URL
	env := safeEnvForAPIPool("my-pool-key", "https://my-proxy.example.com")
	var hasAPIKey, hasBaseURL bool
	for _, e := range env {
		if e == "ANTHROPIC_API_KEY=my-pool-key" {
			hasAPIKey = true
		}
		if e == "ANTHROPIC_BASE_URL=https://my-proxy.example.com" {
			hasBaseURL = true
		}
	}
	if !hasAPIKey {
		t.Error("safeEnvForAPIPool should inject ANTHROPIC_API_KEY")
	}
	if !hasBaseURL {
		t.Error("safeEnvForAPIPool should inject ANTHROPIC_BASE_URL")
	}
}

func TestClaudePrepareSettingsContainsSandboxConfig(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	_, err := runner.Prepare(RunSpec{
		Prompt:            "test sandbox",
		WorktreeDir:       dir,
		RuntimeDir:        filepath.Join(dir, "runtime"),
		Mode:              AuthModeAPIKey,
		Phase:             PhaseSpec{Name: "exec", BuiltinTools: []string{"Read"}, MaxTurns: 5},
		SandboxEnabled:    true,
		SandboxDomains:    []string{"github.com", "npm.org"},
		SandboxAllowRead:  []string{"/tmp/readable"},
		SandboxAllowWrite: []string{"/tmp/writable"},
	})
	if err != nil {
		t.Fatal(err)
	}

	settingsPath := filepath.Join(dir, "runtime", "claude-settings-exec.json")
	data, err := os.ReadFile(settingsPath)
	if err != nil {
		t.Fatalf("settings file not written: %v", err)
	}

	var parsed map[string]interface{}
	if err := json.Unmarshal(data, &parsed); err != nil {
		t.Fatalf("invalid JSON: %v", err)
	}

	sandbox, ok := parsed["sandbox"].(map[string]interface{})
	if !ok {
		t.Fatal("sandbox section missing from settings")
	}
	if sandbox["enabled"] != true {
		t.Error("sandbox.enabled should be true")
	}
}

func TestGeminiRunnerPrepareMissingRuntimeDir(t *testing.T) {
	// GeminiRunner does not use RuntimeDir, but should still require WorktreeDir
	runner := NewGeminiRunner("gemini")
	_, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: "",
	})
	if err == nil {
		t.Error("expected error for missing worktree dir")
	}
}

func TestGeminiPrepareWithMode2Env(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("SAFE_CUSTOM_VAR", "keep-this")
	t.Setenv("AWS_SECRET_ACCESS_KEY", "strip-this")

	runner := NewGeminiRunner("gemini")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test env",
		WorktreeDir: dir,
		Phase:       PhaseSpec{Name: "exec"},
	})
	if err != nil {
		t.Fatal(err)
	}

	joined := strings.Join(prepared.Env, "\n")
	if !strings.Contains(joined, "SAFE_CUSTOM_VAR=keep-this") {
		t.Error("Gemini should keep safe custom vars")
	}
	if strings.Contains(joined, "AWS_SECRET_ACCESS_KEY=") {
		t.Error("Gemini should strip dangerous env vars")
	}
}

func TestClaudePrepareMkdirAllFailure(t *testing.T) {
	dir := t.TempDir()
	// Create a file at the path where RuntimeDir would be created,
	// so MkdirAll fails because it can't create a directory over a file.
	blockingFile := filepath.Join(dir, "blocker")
	os.WriteFile(blockingFile, []byte("x"), 0644)

	r := NewClaudeRunner("claude")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(blockingFile, "subdir"),
		Phase:       PhaseSpec{Name: "plan", BuiltinTools: []string{"Read"}, MaxTurns: 3},
	})
	if err == nil {
		t.Error("expected error when MkdirAll fails")
	}
}

func TestClaudePrepareWriteFileFailure(t *testing.T) {
	dir := t.TempDir()
	runtimeDir := filepath.Join(dir, "runtime")
	os.MkdirAll(runtimeDir, 0755)
	// Make runtimeDir read-only so WriteFile fails
	os.Chmod(runtimeDir, 0555)
	defer os.Chmod(runtimeDir, 0755)

	r := NewClaudeRunner("claude")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  runtimeDir,
		Phase:       PhaseSpec{Name: "plan", BuiltinTools: []string{"Read"}, MaxTurns: 3},
	})
	if err == nil {
		t.Error("expected error when WriteFile fails on read-only dir")
	}
}

func TestCodexPrepareMkdirAllFailure(t *testing.T) {
	dir := t.TempDir()
	blockingFile := filepath.Join(dir, "blocker")
	os.WriteFile(blockingFile, []byte("x"), 0644)

	r := NewCodexRunner("codex")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(blockingFile, "subdir"),
		Phase:       PhaseSpec{Name: "execute"},
	})
	if err == nil {
		t.Error("expected error when MkdirAll fails for Codex")
	}
}

func TestGeminiRunnerRunPrepareError(t *testing.T) {
	runner := NewGeminiRunner("gemini")
	_, err := runner.Run(context.Background(), RunSpec{
		Prompt:      "test",
		WorktreeDir: "",
	}, nil)
	if err == nil {
		t.Error("expected error from Run() when Prepare() fails")
	}
}

func TestCodexRunnerPrepareMode1InjectsCodexHome(t *testing.T) {
	dir := t.TempDir()
	runner := NewCodexRunner("codex")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:        "test",
		WorktreeDir:   dir,
		RuntimeDir:    filepath.Join(dir, "runtime"),
		Mode:          AuthModeSubscription,
		PoolConfigDir: "/pool/codex-home",
		Phase:         PhaseSpec{Name: "execute"},
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Env, "\n")
	if !strings.Contains(joined, "CODEX_HOME=/pool/codex-home") {
		t.Error("Mode 1 should inject CODEX_HOME with PoolConfigDir")
	}
}

func TestGeminiRunSuccessWithEcho(t *testing.T) {
	dir := t.TempDir()
	// Use /bin/echo as a stand-in binary that always succeeds
	runner := NewGeminiRunner("/bin/echo")
	result, err := runner.Run(context.Background(), RunSpec{
		Prompt:      "hello world",
		WorktreeDir: dir,
		Phase:       PhaseSpec{Name: "execute"},
	}, nil)
	if err != nil {
		t.Fatalf("Run with /bin/echo should succeed: %v", err)
	}
	if result.IsError {
		t.Errorf("IsError should be false, subtype=%q", result.Subtype)
	}
	if result.ResultText == "" {
		t.Error("ResultText should contain echo output")
	}
	if result.ExitCode != 0 {
		t.Errorf("ExitCode=%d, want 0", result.ExitCode)
	}
}

func TestGeminiRunExitError(t *testing.T) {
	dir := t.TempDir()
	// Use /bin/false as a stand-in binary that always exits with code 1
	runner := NewGeminiRunner("/bin/false")
	result, err := runner.Run(context.Background(), RunSpec{
		Prompt:      "should fail",
		WorktreeDir: dir,
		Phase:       PhaseSpec{Name: "execute"},
	}, nil)
	if err != nil {
		t.Fatalf("Run should not return an error (error is in result): %v", err)
	}
	if !result.IsError {
		t.Error("IsError should be true for /bin/false")
	}
	if result.ExitCode == 0 {
		t.Error("ExitCode should be non-zero for /bin/false")
	}
}

func TestClaudeRunnerRunStartFailure(t *testing.T) {
	// Use a nonexistent binary so cmd.Start() fails.
	// This covers lines 117-131 in claude.go (setup + Start error).
	dir := t.TempDir()
	r := NewClaudeRunner("nonexistent-claude-binary-xyz")
	_, err := r.Run(context.Background(), RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Phase:       PhaseSpec{Name: "plan", BuiltinTools: []string{"Read"}, MaxTurns: 3},
	}, nil)
	if err == nil {
		t.Fatal("expected error when binary does not exist")
	}
	if !strings.Contains(err.Error(), "start claude") {
		t.Errorf("error should mention 'start claude', got: %q", err.Error())
	}
}

func TestCodexRunnerRunStartFailure(t *testing.T) {
	// Use a nonexistent binary so cmd.Start() fails.
	// This covers lines 69-84 in codex.go (setup + Start error).
	dir := t.TempDir()
	r := NewCodexRunner("nonexistent-codex-binary-xyz")
	_, err := r.Run(context.Background(), RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Phase:       PhaseSpec{Name: "execute"},
	}, nil)
	if err == nil {
		t.Fatal("expected error when binary does not exist")
	}
	if !strings.Contains(err.Error(), "start codex") {
		t.Errorf("error should mention 'start codex', got: %q", err.Error())
	}
}

func TestClaudeRunnerRunWithEcho(t *testing.T) {
	// Use /bin/echo as a stand-in. It will produce output and exit 0.
	// This covers the streaming loop, Wait, and result construction
	// in ClaudeRunner.Run (lines 135-196).
	dir := t.TempDir()
	r := NewClaudeRunner("/bin/echo")
	result, err := r.Run(context.Background(), RunSpec{
		Prompt:      "hello",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Phase:       PhaseSpec{Name: "plan", BuiltinTools: []string{"Read"}, MaxTurns: 3},
	}, nil)
	if err != nil {
		t.Fatalf("Run with /bin/echo should not return error: %v", err)
	}
	// echo produces non-JSON output so no events are parsed, but
	// the streaming loop, Wait, and done channel all execute.
	if result.Prepared.Binary != "/bin/echo" {
		t.Errorf("Binary=%q, want /bin/echo", result.Prepared.Binary)
	}
}

func TestCodexRunnerRunWithEcho(t *testing.T) {
	// Use /bin/echo as a stand-in for Codex runner.
	// Covers the stdout/stderr reading, Wait, and result construction.
	dir := t.TempDir()
	r := NewCodexRunner("/bin/echo")
	result, err := r.Run(context.Background(), RunSpec{
		Prompt:      "hello",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Phase:       PhaseSpec{Name: "execute"},
	}, nil)
	if err != nil {
		t.Fatalf("Run with /bin/echo should not return error: %v", err)
	}
	// echo exits 0 but produces no last-message file, so missing_review_output
	if result.Prepared.Binary != "/bin/echo" {
		t.Errorf("Binary=%q, want /bin/echo", result.Prepared.Binary)
	}
}

func TestCodexRunnerRunWithFalse(t *testing.T) {
	// Use /bin/false to cover the exit-error path in Codex Run
	dir := t.TempDir()
	r := NewCodexRunner("/bin/false")
	result, err := r.Run(context.Background(), RunSpec{
		Prompt:      "should fail",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Phase:       PhaseSpec{Name: "execute"},
	}, nil)
	if err != nil {
		t.Fatalf("Run should not return error (error is in result): %v", err)
	}
	if !result.IsError {
		t.Error("IsError should be true for /bin/false")
	}
	if result.ExitCode == 0 {
		t.Error("ExitCode should be non-zero for /bin/false")
	}
}
