package server

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/ericmacdougall/stoke/internal/mission"
	"github.com/ericmacdougall/stoke/internal/orchestrate"
)

func newTestMissionAPI(t *testing.T) (*Server, *orchestrate.Orchestrator) {
	t.Helper()
	bus := NewEventBus()
	srv := New(0, "", bus)

	orch, err := orchestrate.New(orchestrate.Config{
		StoreDir: t.TempDir(),
	})
	if err != nil {
		t.Fatalf("New orchestrator: %v", err)
	}
	t.Cleanup(func() { orch.Close() })

	RegisterMissionAPI(srv, orch)
	return srv, orch
}

func doReq(t *testing.T, handler http.Handler, method, path string, body interface{}) *httptest.ResponseRecorder {
	t.Helper()
	var buf bytes.Buffer
	if body != nil {
		json.NewEncoder(&buf).Encode(body)
	}
	req := httptest.NewRequest(method, path, &buf)
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	handler.ServeHTTP(w, req)
	return w
}

func decodeJSON(t *testing.T, w *httptest.ResponseRecorder) map[string]interface{} {
	t.Helper()
	var result map[string]interface{}
	if err := json.NewDecoder(w.Body).Decode(&result); err != nil {
		t.Fatalf("decode JSON: %v\nBody: %s", err, w.Body.String())
	}
	return result
}

// --- Create Mission ---

func TestAPICreateMission(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/create", map[string]interface{}{
		"title":    "JWT Auth",
		"intent":   "Add JWT to API",
		"criteria": []string{"Tokens issued", "401 on invalid"},
	})

	if w.Code != http.StatusCreated {
		t.Errorf("status = %d, want 201\nBody: %s", w.Code, w.Body.String())
	}

	result := decodeJSON(t, w)
	if result["id"] == nil || result["id"] == "" {
		t.Error("should return mission ID")
	}
	if result["title"] != "JWT Auth" {
		t.Errorf("title = %v", result["title"])
	}
}

func TestAPICreateMissionValidation(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/create", map[string]interface{}{
		"title": "", "intent": "test",
	})
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPICreateMissionWrongMethod(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/create", nil)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("status = %d, want 405", w.Code)
	}
}

// --- List Missions ---

func TestAPIListMissions(t *testing.T) {
	srv, orch := newTestMissionAPI(t)

	orch.CreateMission("M1", "intent 1", nil)
	orch.CreateMission("M2", "intent 2", nil)

	w := doReq(t, srv.Handler(), "GET", "/api/missions", nil)
	if w.Code != http.StatusOK {
		t.Fatalf("status = %d", w.Code)
	}

	result := decodeJSON(t, w)
	count := result["count"].(float64)
	if count != 2 {
		t.Errorf("count = %v, want 2", count)
	}
}

func TestAPIListMissionsFilterPhase(t *testing.T) {
	srv, orch := newTestMissionAPI(t)

	m, _ := orch.CreateMission("M1", "intent", nil)
	orch.CreateMission("M2", "intent", nil)
	orch.AdvanceMission(m.ID, mission.PhaseResearching, "test", "test")

	w := doReq(t, srv.Handler(), "GET", "/api/missions?phase=created", nil)
	result := decodeJSON(t, w)
	count := result["count"].(float64)
	if count != 1 {
		t.Errorf("count = %v, want 1 (only created phase)", count)
	}
}

// --- Get Mission ---

func TestAPIGetMission(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test intent", nil)

	w := doReq(t, srv.Handler(), "GET", "/api/missions/get?id="+m.ID, nil)
	if w.Code != http.StatusOK {
		t.Fatalf("status = %d", w.Code)
	}

	result := decodeJSON(t, w)
	if result["title"] != "Test" {
		t.Errorf("title = %v", result["title"])
	}
}

func TestAPIGetMissionNotFound(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/get?id=ghost", nil)
	if w.Code != http.StatusNotFound {
		t.Errorf("status = %d, want 404", w.Code)
	}
}

func TestAPIGetMissionMissingID(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/get", nil)
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

// --- Advance Mission ---

func TestAPIAdvanceMission(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", nil)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/advance", map[string]interface{}{
		"mission_id": m.ID,
		"phase":      "researching",
		"reason":     "starting research",
		"agent":      "test",
	})
	if w.Code != http.StatusOK {
		t.Errorf("status = %d\nBody: %s", w.Code, w.Body.String())
	}

	got, _ := orch.GetMission(m.ID)
	if got.Phase != mission.PhaseResearching {
		t.Errorf("phase = %s, want researching", got.Phase)
	}
}

func TestAPIAdvanceMissionInvalid(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", nil)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/advance", map[string]interface{}{
		"mission_id": m.ID,
		"phase":      "completed", // invalid from created
	})
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

// --- Convergence Status ---

func TestAPIConvergenceStatus(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", []string{"Done"})

	w := doReq(t, srv.Handler(), "GET", "/api/missions/convergence?id="+m.ID, nil)
	if w.Code != http.StatusOK {
		t.Fatalf("status = %d", w.Code)
	}

	result := decodeJSON(t, w)
	if result["is_converged"] != false {
		t.Error("should not be converged with unsatisfied criteria")
	}
}

// --- Build Context ---

func TestAPIBuildContext(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("JWT Auth", "Add JWT auth", []string{"Tokens issued"})

	w := doReq(t, srv.Handler(), "POST", "/api/missions/context", map[string]interface{}{
		"mission_id": m.ID,
	})
	if w.Code != http.StatusOK {
		t.Fatalf("status = %d\nBody: %s", w.Code, w.Body.String())
	}

	result := decodeJSON(t, w)
	ctx := result["context"].(string)
	if ctx == "" {
		t.Error("context should not be empty")
	}
	if !contains(ctx, "JWT Auth") {
		t.Error("context should contain mission title")
	}
}

// --- Record Handoff ---

func TestAPIRecordHandoff(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", []string{"Done"})

	w := doReq(t, srv.Handler(), "POST", "/api/missions/handoff", map[string]interface{}{
		"mission_id": m.ID,
		"from_agent": "agent-1",
		"to_agent":   "agent-2",
		"summary":    "Implemented feature X",
	})
	if w.Code != http.StatusOK {
		t.Fatalf("status = %d\nBody: %s", w.Code, w.Body.String())
	}
}

// --- Record Consensus ---

func TestAPIRecordConsensus(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", nil)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/consensus", map[string]interface{}{
		"mission_id": m.ID,
		"model":      "claude",
		"verdict":    "complete",
		"reasoning":  "all good",
	})
	if w.Code != http.StatusOK {
		t.Fatalf("status = %d\nBody: %s", w.Code, w.Body.String())
	}

	result := decodeJSON(t, w)
	if result["has_consensus"] != false {
		t.Error("should not have consensus with 1 vote")
	}
}

// --- RegisterMissionAPI with nil ---

func TestRegisterMissionAPINilOrch(t *testing.T) {
	srv := New(0, "", NewEventBus())
	// Should not panic
	RegisterMissionAPI(srv, nil)
}

// --- List Missions error paths ---

func TestAPIListMissionsWrongMethod(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "POST", "/api/missions", nil)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("status = %d, want 405", w.Code)
	}
}

func TestAPIListMissionsInvalidPhase(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions?phase=nonexistent", nil)
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
	result := decodeJSON(t, w)
	if result["error"] != "invalid phase parameter" {
		t.Errorf("error = %v", result["error"])
	}
}

func TestAPIListMissionsAllPhases(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	orch.CreateMission("M1", "intent", nil)

	phases := []string{"created", "researching", "planning", "executing", "validating", "converged", "completed", "failed", "paused"}
	for _, phase := range phases {
		w := doReq(t, srv.Handler(), "GET", "/api/missions?phase="+phase, nil)
		if w.Code != http.StatusOK {
			t.Errorf("phase=%s: status = %d, want 200", phase, w.Code)
		}
	}
}

// --- Create Mission error paths ---

func TestAPICreateMissionBadJSON(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	req := httptest.NewRequest("POST", "/api/missions/create", bytes.NewBufferString("{invalid"))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	srv.Handler().ServeHTTP(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPICreateMissionResponseContentType(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "POST", "/api/missions/create", map[string]interface{}{
		"title":  "Test",
		"intent": "test intent",
	})

	ct := w.Header().Get("Content-Type")
	if !contains(ct, "application/json") {
		t.Errorf("Content-Type = %q, want application/json", ct)
	}
}

// --- Get Mission error paths ---

func TestAPIGetMissionWrongMethod(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "POST", "/api/missions/get?id=test", nil)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("status = %d, want 405", w.Code)
	}
}

func TestAPIGetMissionInvalidID(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/get?id=../../../etc/passwd", nil)
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400 for path traversal ID", w.Code)
	}
	result := decodeJSON(t, w)
	if result["error"] != "invalid id parameter" {
		t.Errorf("error = %v", result["error"])
	}
}

func TestAPIGetMissionSpecialCharsID(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/get?id=<script>alert(1)</script>", nil)
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400 for XSS-like ID", w.Code)
	}
}

func TestAPIGetMissionResponseContentType(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", nil)

	w := doReq(t, srv.Handler(), "GET", "/api/missions/get?id="+m.ID, nil)
	ct := w.Header().Get("Content-Type")
	if !contains(ct, "application/json") {
		t.Errorf("Content-Type = %q, want application/json", ct)
	}
}

// --- Advance Mission error paths ---

func TestAPIAdvanceMissionWrongMethod(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/advance", nil)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("status = %d, want 405", w.Code)
	}
}

func TestAPIAdvanceMissionBadJSON(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	req := httptest.NewRequest("POST", "/api/missions/advance", bytes.NewBufferString("not json"))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	srv.Handler().ServeHTTP(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPIAdvanceMissionInvalidPhase(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", nil)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/advance", map[string]interface{}{
		"mission_id": m.ID,
		"phase":      "nonexistent-phase",
		"reason":     "test",
		"agent":      "test",
	})
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400 for invalid phase", w.Code)
	}
}

func TestAPIAdvanceMissionNonexistentMission(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/advance", map[string]interface{}{
		"mission_id": "nonexistent-id",
		"phase":      "researching",
		"reason":     "test",
		"agent":      "test",
	})
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400 for nonexistent mission", w.Code)
	}
}

// --- Convergence Status error paths ---

func TestAPIConvergenceWrongMethod(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "POST", "/api/missions/convergence?id=test", nil)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("status = %d, want 405", w.Code)
	}
}

func TestAPIConvergenceMissingID(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/convergence", nil)
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPIConvergenceInvalidID(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/convergence?id=foo/bar", nil)
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400 for invalid ID", w.Code)
	}
}

func TestAPIConvergenceResponseContentType(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", []string{"Done"})

	w := doReq(t, srv.Handler(), "GET", "/api/missions/convergence?id="+m.ID, nil)
	ct := w.Header().Get("Content-Type")
	if !contains(ct, "application/json") {
		t.Errorf("Content-Type = %q, want application/json", ct)
	}
}

// --- Run Convergence ---

func TestAPIRunConvergenceWrongMethod(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/convergence/run", nil)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("status = %d, want 405", w.Code)
	}
}

func TestAPIRunConvergenceBadJSON(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	req := httptest.NewRequest("POST", "/api/missions/convergence/run", bytes.NewBufferString("notjson"))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	srv.Handler().ServeHTTP(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPIRunConvergenceSuccess(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Conv Test", "test convergence", []string{"Has tests"})

	w := doReq(t, srv.Handler(), "POST", "/api/missions/convergence/run", map[string]interface{}{
		"mission_id": m.ID,
		"files": []map[string]interface{}{
			{"Path": "main.go", "Content": "cGFja2FnZSBtYWlu"},
		},
	})

	if w.Code != http.StatusOK {
		t.Errorf("status = %d, want 200\nBody: %s", w.Code, w.Body.String())
	}

	result := decodeJSON(t, w)
	if _, ok := result["score"]; !ok {
		t.Error("response should contain score field")
	}
	if _, ok := result["findings"]; !ok {
		t.Error("response should contain findings field")
	}
}

func TestAPIRunConvergenceNonexistentMission(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/convergence/run", map[string]interface{}{
		"mission_id": "nonexistent",
		"files":      []map[string]interface{}{},
	})
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

// --- Build Context error paths ---

func TestAPIBuildContextWrongMethod(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/context", nil)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("status = %d, want 405", w.Code)
	}
}

func TestAPIBuildContextBadJSON(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	req := httptest.NewRequest("POST", "/api/missions/context", bytes.NewBufferString("{bad"))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	srv.Handler().ServeHTTP(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPIBuildContextNonexistentMission(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "POST", "/api/missions/context", map[string]interface{}{
		"mission_id": "nonexistent",
	})
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPIBuildContextWithConfig(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Ctx Test", "context test", []string{"Done"})

	w := doReq(t, srv.Handler(), "POST", "/api/missions/context", map[string]interface{}{
		"mission_id": m.ID,
		"config": map[string]interface{}{
			"max_tokens":           2000,
			"include_mission_info": true,
			"include_criteria":     true,
			"include_gaps":         false,
		},
	})
	if w.Code != http.StatusOK {
		t.Errorf("status = %d\nBody: %s", w.Code, w.Body.String())
	}

	result := decodeJSON(t, w)
	ctx := result["context"].(string)
	if ctx == "" {
		t.Error("context should not be empty")
	}
}

// --- Record Handoff error paths ---

func TestAPIRecordHandoffWrongMethod(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/handoff", nil)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("status = %d, want 405", w.Code)
	}
}

func TestAPIRecordHandoffBadJSON(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	req := httptest.NewRequest("POST", "/api/missions/handoff", bytes.NewBufferString("notjson"))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	srv.Handler().ServeHTTP(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPIRecordHandoffNonexistentMission(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/handoff", map[string]interface{}{
		"mission_id": "nonexistent",
		"from_agent": "agent-1",
		"to_agent":   "agent-2",
		"summary":    "test",
	})
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPIRecordHandoffResponseContentType(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", nil)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/handoff", map[string]interface{}{
		"mission_id": m.ID,
		"from_agent": "agent-1",
		"to_agent":   "agent-2",
		"summary":    "did stuff",
	})

	ct := w.Header().Get("Content-Type")
	if !contains(ct, "application/json") {
		t.Errorf("Content-Type = %q, want application/json", ct)
	}
}

// --- Record Consensus error paths ---

func TestAPIRecordConsensusWrongMethod(t *testing.T) {
	srv, _ := newTestMissionAPI(t)
	w := doReq(t, srv.Handler(), "GET", "/api/missions/consensus", nil)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("status = %d, want 405", w.Code)
	}
}

func TestAPIRecordConsensusBadJSON(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	req := httptest.NewRequest("POST", "/api/missions/consensus", bytes.NewBufferString("bad"))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	srv.Handler().ServeHTTP(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPIRecordConsensusNonexistentMission(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/consensus", map[string]interface{}{
		"mission_id": "nonexistent",
		"model":      "claude",
		"verdict":    "complete",
		"reasoning":  "all good",
	})
	if w.Code != http.StatusBadRequest {
		t.Errorf("status = %d, want 400", w.Code)
	}
}

func TestAPIRecordConsensusResponseContentType(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", nil)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/consensus", map[string]interface{}{
		"mission_id": m.ID,
		"model":      "gpt4",
		"verdict":    "incomplete",
		"reasoning":  "not done yet",
	})

	ct := w.Header().Get("Content-Type")
	if !contains(ct, "application/json") {
		t.Errorf("Content-Type = %q, want application/json", ct)
	}
}

func TestAPIRecordConsensusMultipleVotes(t *testing.T) {
	srv, orch := newTestMissionAPI(t)
	m, _ := orch.CreateMission("Test", "test", nil)

	w := doReq(t, srv.Handler(), "POST", "/api/missions/consensus", map[string]interface{}{
		"mission_id": m.ID,
		"model":      "claude",
		"verdict":    "complete",
		"reasoning":  "looks good",
	})
	if w.Code != http.StatusOK {
		t.Fatalf("first vote: status = %d", w.Code)
	}

	w = doReq(t, srv.Handler(), "POST", "/api/missions/consensus", map[string]interface{}{
		"mission_id": m.ID,
		"model":      "gpt4",
		"verdict":    "complete",
		"reasoning":  "confirmed done",
	})
	if w.Code != http.StatusOK {
		t.Fatalf("second vote: status = %d", w.Code)
	}

	result := decodeJSON(t, w)
	if _, ok := result["has_consensus"]; !ok {
		t.Error("response should contain has_consensus field")
	}
}

// --- writeError Content-Type ---

func TestWriteErrorContentType(t *testing.T) {
	srv, _ := newTestMissionAPI(t)

	w := doReq(t, srv.Handler(), "GET", "/api/missions/get", nil)
	ct := w.Header().Get("Content-Type")
	if !contains(ct, "application/json") {
		t.Errorf("error response Content-Type = %q, want application/json", ct)
	}
}

// --- Auth on mission endpoints ---

func TestMissionEndpointsRequireAuth(t *testing.T) {
	bus := NewEventBus()
	srv := New(0, "mission-token", bus)
	orch, err := orchestrate.New(orchestrate.Config{StoreDir: t.TempDir()})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { orch.Close() })
	RegisterMissionAPI(srv, orch)

	endpoints := []struct {
		method string
		path   string
	}{
		{"GET", "/api/missions"},
		{"POST", "/api/missions/create"},
		{"GET", "/api/missions/get?id=test"},
		{"POST", "/api/missions/advance"},
		{"GET", "/api/missions/convergence?id=test"},
		{"POST", "/api/missions/convergence/run"},
		{"POST", "/api/missions/context"},
		{"POST", "/api/missions/handoff"},
		{"POST", "/api/missions/consensus"},
	}

	for _, ep := range endpoints {
		req := httptest.NewRequest(ep.method, ep.path, nil)
		w := httptest.NewRecorder()
		srv.Handler().ServeHTTP(w, req)

		if w.Code != http.StatusUnauthorized {
			t.Errorf("%s %s: status = %d, want 401", ep.method, ep.path, w.Code)
		}
	}
}

// --- mustJSON helper ---

func TestMustJSON(t *testing.T) {
	result := mustJSON(map[string]string{"key": "value"})
	if result == "" {
		t.Error("mustJSON should not return empty string")
	}
	var parsed map[string]string
	if err := json.Unmarshal([]byte(result), &parsed); err != nil {
		t.Errorf("mustJSON output should be valid JSON: %v", err)
	}
	if parsed["key"] != "value" {
		t.Errorf("expected key=value, got %v", parsed["key"])
	}
}

func contains(s, substr string) bool {
	return len(s) >= len(substr) && (s == substr || len(s) > 0 && containsStr(s, substr))
}

func containsStr(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}
