# Stoke

The most capable AI coding orchestrator. Drives Claude Code, Codex CLI, Gemini, and native API as execution engines through deterministic PLAN->EXECUTE->VERIFY->REVIEW->COMMIT phases with multi-model routing, cross-model adversarial review, subscription pool rotation, 104-package architecture, model-driven convergence validation (regex + AI two-pass), multi-model consensus engine, cross-surface dependency mapping, cross-session memory, and 11-layer quality enforcement.

**The thesis:** SWE-bench Pro shows the same model jumps ~15 points when you optimize the scaffold. The harness is the product.

## Three Execution Modes

| Mode | How | Cost | Best For |
|------|-----|------|----------|
| **CLI Subscription** | Spawns `claude -p` / `codex exec` | Free (subscription) | Daily development |
| **Native API** | Direct HTTP SSE to Anthropic/OpenAI | Pay-per-token | Maximum control, lowest latency |
| **LiteLLM Proxy** | API through LiteLLM gateway | Cheap (MiniMax/OpenRouter/DeepSeek) | Budget builds, CI/CD |

## Quick Start

```bash
go build ./cmd/stoke
go test ./...

# Single task with auto-detected build/test/lint
stoke run --task "Add request ID middleware" --dry-run

# Multi-task plan with parallel agents
stoke build --plan stoke-plan.json --workers 4 --dry-run

# Generate a plan from codebase analysis
stoke plan --task "Add JWT auth" --dry-run

# Interactive scoping with ambiguity scoring
stoke scope --scope-depth deep

# Deterministic code scan (with AI slop detection)
stoke scan --security

# Multi-perspective audit (17 personas, confidence-scored)
stoke audit --dry-run

# Check progress / resume after crash
stoke status

# Monitor via HTTP API
stoke serve --port 8420

# Send test notification
stoke notify --test

# List plugins
stoke plugin list

# Run the full test harness
go test ./internal/harness/... -v
```

## Commands

| Command | Purpose |
|---------|---------|
| `stoke run` | Single task: PLAN -> EXECUTE -> VERIFY -> REVIEW -> COMMIT |
| `stoke build` | Multi-task plan with parallel agents, resume, ROI filter |
| `stoke plan` | Generate task plan from codebase analysis |
| `stoke scan` | Deterministic code scan (secrets, eval, injection, AI slop, debug) |
| `stoke audit` | Multi-perspective review (17 personas, fanout-validate-filter) |
| `stoke scope` | Interactive scoping with quantitative ambiguity scoring |
| `stoke serve` | HTTP/SSE server for web dashboards and remote monitoring |
| `stoke notify` | Test notification delivery (Discord, Slack, Telegram, webhook) |
| `stoke plugin` | Plugin management (list, install, enable, disable) |
| `stoke status` | Session dashboard (progress, cost, learned patterns) |
| `stoke pool` | Subscription pool utilization + circuit breaker |
| `stoke doctor` | Tool dependency check |
| `stoke yolo` | Fast-path execution with relaxed verification |
| `stoke repair` | Targeted repair execution |
| `stoke ship` | Programmatic build execution |
| `stoke version` | Version info |

## How It Works

```
stoke build --plan stoke-plan.json
  |
  +-- Load plan, validate (cycles, deps, duplicate IDs)
  +-- ROI filter: remove low-value tasks
  +-- Preflight assertions (repo health, tool availability)
  +-- Auto-detect build/test/lint commands
  +-- Sort tasks by GRPW priority (critical path first)
  +-- For each dispatchable task (parallel, file-scope conflicts):
       |
       +-- Resolve provider (fallback: Claude -> Codex -> Gemini -> API -> OpenRouter -> lint-only)
       +-- Acquire pool (least loaded, circuit breaker, rate limiter)
       +-- Create git worktree + install enforcer hooks (7 lifecycle events)
       +-- Take workspace snapshot (for rollback on failure)
       +-- PLAN phase    Read-only tools, MCP disabled, intent verbalization
       +-- EXECUTE phase  Claude/Codex/Gemini/API per task type + completion promise
       +-- AI SLOP SCAN  10 patterns detect AI-generated code smells
       +-- VERIFY phase   Build/test/lint + tiered depth (light/standard/thorough)
       +-- REVIEW         Cross-model gate (Claude -> Codex or vice versa)
       +-- Post-review revalidation (tree SHA comparison)
       +-- MERGE          git merge-tree validation, then merge, then cleanup
       +-- Save checkpoint + session state + wisdom + telemetry
       +-- Record cost (per-phase token breakdown via costtrack)
       +-- Parse agent self-reflection, record to wisdom store
       |
       +-- On failure: classify (10 classes), extract specifics,
       |   autofix loop attempt, checkpoint save,
       |   discard worktree, create fresh, inject retry brief + diff
       |   (max 3 retries + 2 recovery attempts, escalate on same error)
       |   If ralph mode: persistent completion loop with verification
  |
  +-- Generate report (.stoke/reports/latest.json)
  +-- Send notifications (Discord/Slack/Telegram/webhook)
  +-- Fire event-driven reminders (context >60%, error 3x, etc.)
```

## What's Enforced

**Before every commit/merge:**
- Protected file check: `.claude/`, `.stoke/`, `CLAUDE.md`, `.env*`, `stoke.policy.yaml`
- Scope check: agent can only modify files declared in `task.files`
- Build/test/lint verification pipeline (tiered: light/standard/thorough)
- AI slop detection (10 patterns: verbose comments, empty errors, generic names, etc.)
- Confidence-scored findings (threshold 80, filters false positives)
- Completion promise verification (agent must assert task done)
- Cross-model review gate (blocks merge on rejection)
- Post-review tree SHA revalidation (detects reviewer mutations)

**Hook lifecycle (7 events):**
- PreToolUse: blocks dangerous patterns, stale-edit detection, permission pipeline
- PostToolUse: detects type bypasses, secret leaks, records file hashes
- Stop: completion promise verification
- SessionStart/SessionEnd: notifications, telemetry
- PostToolUseFailure: error tracking
- PreCompact: context preservation

**11-layer policy engine:**
`--tools` + MCP isolation + `--disallowedTools` + `--allowedTools` + settings.json + worktree isolation + sandbox + `--max-turns` + enforcer hooks + verify pipeline + git ownership

## Architecture

```
cmd/stoke/main.go           19+ commands, TUI wiring, plan validation, ROI filter
internal/
  app/                       Orchestrator: config + engines + worktree + verify + OnEvent
  apiclient/                 Native API SSE streaming (Anthropic, OpenAI, OpenRouter)
  audit/                     17 review personas, auto-selection, fanout-validate-filter
  autofix/                   Self-healing build loop
  checkpoint/                Save/restore execution state for crash recovery
  config/                    Policy loader, settings builder, auto-detect, validation
  context/                   Three-tier budget, ctxpack adaptive bin-packing, tokenest
  conversation/              Multi-turn conversation state management
  costtrack/                 Per-phase cost tracking with token breakdowns
  ctxpack/                   Adaptive context bin-packing (greedy knapsack by relevance)
  engine/                    Claude + Codex + Gemini + API runners, process groups, timeouts
  extract/                   Robust output parsing (JSON, code blocks, SEARCH/REPLACE)
  failure/                   10 classes, TS/Go/Python/Rust parsers, retry decisions
  harness/                   Full control/visibility test harness (18 scenarios)
  hooks/                     7-event lifecycle, timeout, permission pipeline, atomicfs
  mcp/                       MCP client for external tool integration
  model/                     Task-type + category routing, 6-provider fallback chain
  notify/                    Discord, Slack, Telegram, webhook notifications
  patchapply/                Unified diff parsing with fuzzy context matching
  plan/                      Plan loader, cycle detection, dependency validation, ROI
  plugins/                   Manifest-based plugin system (hooks, tools, scan rules)
  prompts/                   Self-reflective scope/build/verify prompts, ambiguity scoring
  ratelimit/                 Token bucket rate limiting (augments circuit breaker)
  repomap/                   Repository structure map for planning context
  scan/                      Deterministic scan (22 rules) + AI slop (10 rules) + hashline
  scheduler/                 GRPW priority, file-scope conflicts, dispatch queue, resume
  server/                    HTTP/SSE server for web dashboards and remote monitoring
  session/                   JSON + SQLite stores, attempt history, replay
  snapshot/                  Workspace snapshots for rollback
  stream/                    NDJSON + SSE parsing, prompt cache, 3-tier timeouts
  subscriptions/             Pool allocator: acquire/release, circuit breaker, rate limiter
  symindex/                  AST-level symbol index for code intelligence
  taskstate/                 Anti-deception state machine (mandatory evidence at every gate)
  telemetry/                 Structured events at phase boundaries
  testgen/                   Auto-generate tests for changed functions
  tfidf/                     TF-IDF similarity for audit context retrieval
  tokenest/                  Content-aware token estimation
  tui/                       Bubble Tea interactive (Focus/Dashboard/Detail) + headless
  verify/                    Build/test/lint + tiered verification (light/standard/thorough)
  wisdom/                    Cross-task learning: gotchas, decisions, patterns, reflections
  workflow/                  Phase machine: plan -> execute+verify retry loop, merge-on-success
  worktree/                  Git worktree: create, merge (merge-tree), force cleanup
  consensus/                 Multi-model adversarial consensus engine
  surfacemap/                Cross-surface dependency mapping (Go/TS/Python)
  + 28 more utility packages
```

104 packages. 18,000+ lines source. 2,019 test functions. 200+ Go source files.

## Docs

- [Operator Guide](docs/operator-guide.md) -- Mode 1 vs 2, pool setup, macOS caveats
- [Spec](docs/stoke-spec-final.md) -- 1,091-line frozen spec with 3 adversarial reviews

## Prerequisites

- **Go 1.23+** -- required for building from source
- No C compiler needed -- SQLite is provided via `modernc.org/sqlite` (pure Go)

## Install

```bash
# From source (no gcc/CGO required)
CGO_ENABLED=0 go build -o stoke ./cmd/stoke
sudo mv stoke /usr/local/bin/
```

## License

MIT
