// Shared auth middleware for all /v1/* API endpoints.
// Joins api_keys -> users, checks user status, updates last_used_at.
// This replaces the per-route requireApiKey() that was copied into each file.

import { Context, Next } from "hono";
import { rawSql } from "./connection.js";

export function requireApiKeyV1() {
  return async (c: Context, next: Next) => {
    const auth = c.req.header("Authorization");
    const token = auth?.replace("Bearer ", "");
    if (!token) return c.json({ error: "Missing API key" }, 401);

    // Join api_keys -> users: validate key AND user status in one query
    const [result] = await rawSql`
      SELECT k.id as key_id, k.user_id, u.status as user_status
      FROM api_keys k
      JOIN users u ON u.id = k.user_id
      WHERE k.key_hash = encode(sha256(${token}::bytea), 'hex')
        AND k.status = 'active'
      LIMIT 1`;

    if (!result) {
      return c.json({ error: "Invalid API key" }, 401);
    }

    if (result.user_status !== "active") {
      return c.json({ error: "Account suspended or deleted" }, 403);
    }

    // Update last_used_at (async, don't block the request)
    rawSql`UPDATE api_keys SET last_used_at = NOW() WHERE id = ${result.key_id}`.catch((e) => console.error("[v1-auth] last_used_at update failed:", e));

    c.set("userId", result.user_id);
    c.set("apiKeyId", result.key_id);
    return next();
  };
}
