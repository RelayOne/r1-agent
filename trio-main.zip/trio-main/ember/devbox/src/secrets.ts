import crypto from "crypto";

const ENC_PREFIX = "enc:v1:";

function getEncryptionKey(): Buffer | null {
  const raw = process.env.APP_ENCRYPTION_KEY || "";
  if (!raw) return null;

  if (/^[0-9a-f]{64}$/i.test(raw)) {
    return Buffer.from(raw, "hex");
  }

  try {
    const base64 = Buffer.from(raw, "base64");
    if (base64.length === 32) return base64;
  } catch {
    // ignore invalid base64
  }

  throw new Error(
    "APP_ENCRYPTION_KEY must be exactly 32 bytes (64 hex chars or 44 base64 chars). " +
    `Got ${raw.length} characters that did not decode to 32 bytes.`
  );
}

const ENCRYPTION_KEY = getEncryptionKey();

export function encryptSecret(value: string | null | undefined): string | null {
  if (!value) return null;
  if (!ENCRYPTION_KEY) {
    // WARNING: Encryption key not configured. Returning plaintext.
    // In production, APP_ENCRYPTION_KEY must be set to encrypt secrets at rest.
    // Without it, values like OAuth tokens are stored/returned as plaintext.
    console.warn("[secrets] APP_ENCRYPTION_KEY not set — returning plaintext instead of encrypting");
    return value;
  }
  if (value.startsWith(ENC_PREFIX)) return value;

  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", ENCRYPTION_KEY, iv);
  const ciphertext = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${ENC_PREFIX}${iv.toString("base64url")}.${tag.toString("base64url")}.${ciphertext.toString("base64url")}`;
}

export function decryptSecret(value: string | null | undefined): string | null {
  if (!value) return null;
  if (!value.startsWith(ENC_PREFIX)) return value;
  if (!ENCRYPTION_KEY) {
    throw new Error("APP_ENCRYPTION_KEY is required to decrypt stored secrets");
  }

  const payload = value.slice(ENC_PREFIX.length);
  const parts = payload.split(".");
  if (parts.length !== 3) {
    throw new Error("Encrypted secret payload is malformed");
  }

  const [ivB64, tagB64, ciphertextB64] = parts;
  const decipher = crypto.createDecipheriv(
    "aes-256-gcm",
    ENCRYPTION_KEY,
    Buffer.from(ivB64, "base64url"),
  );
  decipher.setAuthTag(Buffer.from(tagB64, "base64url"));

  const plaintext = Buffer.concat([
    decipher.update(Buffer.from(ciphertextB64, "base64url")),
    decipher.final(),
  ]);
  return plaintext.toString("utf8");
}

export function encryptionConfigured(): boolean {
  return !!ENCRYPTION_KEY;
}
