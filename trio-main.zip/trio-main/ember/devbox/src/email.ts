// Pluggable email transport.
// In production, set EMAIL_PROVIDER=sendgrid|resend|ses and provide credentials.
// In development, logs to console.

interface EmailMessage {
  to: string;
  subject: string;
  text: string;
  html?: string;
}

export async function sendEmail(msg: EmailMessage): Promise<boolean> {
  const provider = process.env.EMAIL_PROVIDER || "console";

  if (provider === "console") {
    if (process.env.NODE_ENV === "production") {
      // NEVER log email bodies in production - fail closed
      console.error("[email] EMAIL_PROVIDER=console in production. Email NOT sent.");
      return false;
    }
    console.log(`[email] To: ${msg.to} | Subject: ${msg.subject}`);
    return true;
  }

  if (provider === "resend") {
    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.RESEND_API_KEY}`,
        },
        body: JSON.stringify({
          from: process.env.EMAIL_FROM || "Ember <noreply@ember.dev>",
          to: [msg.to],
          subject: msg.subject,
          text: msg.text,
          html: msg.html,
        }),
      });
      if (!res.ok) {
        console.error(`[email] resend ${res.status}: ${await res.text().catch(() => "")}`);
      }
      return res.ok;
    } catch (e: any) {
      console.error("[email] resend error:", e.message);
      return false;
    }
  }

  console.error(`[email] unknown provider: ${provider}`);
  return false;
}

export function passwordResetEmail(to: string, resetUrl: string): EmailMessage {
  return {
    to,
    subject: "Reset your Ember password",
    text: `Reset your password by visiting: ${resetUrl}\n\nThis link expires in 1 hour. If you didn't request this, ignore this email.`,
    html: `<p>Reset your password by clicking the link below:</p><p><a href="${resetUrl}">${resetUrl}</a></p><p>This link expires in 1 hour. If you didn't request this, ignore this email.</p>`,
  };
}

export function emailVerificationEmail(to: string, verifyUrl: string): EmailMessage {
  return {
    to,
    subject: "Verify your Ember email",
    text: `Verify your email by visiting: ${verifyUrl}\n\nThis link expires in 24 hours.`,
    html: `<p>Verify your email by clicking the link below:</p><p><a href="${verifyUrl}">${verifyUrl}</a></p><p>This link expires in 24 hours.</p>`,
  };
}
