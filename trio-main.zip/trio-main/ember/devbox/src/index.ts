import { serve } from "@hono/node-server";
import { Hono } from "hono";
import { serveStatic } from "@hono/node-server/serve-static";
import { logger } from "hono/logger";
import { secureHeaders } from "hono/secure-headers";
import { eq, sql, isNull, and } from "drizzle-orm";
import crypto from "crypto";

import authRoutes from "./routes/auth.js";
import billingRoutes from "./routes/billing.js";
import machineRoutes from "./routes/machines.js";
import adminRoutes from "./routes/admin.js";
import settingsRoutes from "./routes/settings.js";
import githubRoutes from "./routes/github.js";
import accountRoutes from "./routes/account.js";
import apiKeyRoutes from "./routes/api-keys.js";
import creditsRoutes from "./routes/credits.js";
import workerRoutes from "./routes/workers.js";
import aiRoutes from "./routes/ai.js";
import sessionRoutes from "./routes/sessions.js";
import { csrfProtection, correlationId } from "./middleware.js";
import {
  apiLimiter, authLimiter, registerLimiter,
  billingLimiter, machineLimiter, terminalLimiter,
  forgotPasswordLimiter,
} from "./rate-limit.js";
import { db } from "./connection.js";
import { users, machines, slots } from "./db.js";
import { lucia } from "./auth.js";

function validateProductionConfig() {
  if (process.env.NODE_ENV !== "production") return;

  const errors: string[] = [];
  const appUrl = process.env.APP_URL || "";
  const machineHostSuffix = process.env.MACHINE_HOST_SUFFIX || ".fly.dev";

  for (const key of [
    "DATABASE_URL",
    "FLY_API_TOKEN",
    "CANONICAL_IMAGE_DIGEST",
    "STRIPE_SECRET_KEY",
    "STRIPE_WEBHOOK_SECRET",
    "STRIPE_PRICE_4X",       // Billing uses these with ! assertions
    "STRIPE_PRICE_8X",
    "STRIPE_PRICE_16X",
    "FLY_ORG",
    "RECONCILE_SECRET",
    "APP_ENCRYPTION_KEY",
    "INTERNAL_API_URL",   // Machine-to-API must use private 6PN, not public internet
    "EMAIL_PROVIDER",     // Must be configured for password reset / email verification
  ]) {
    if (!process.env[key]) errors.push(`${key} is required in production`);
  }

  if (!appUrl.startsWith("https://")) {
    errors.push("APP_URL must be an https:// URL in production");
  }
  if (machineHostSuffix === ".fly.dev") {
    errors.push("MACHINE_HOST_SUFFIX must be a custom domain in production; .fly.dev is not reliable for embedded terminals");
  }
  if (process.env.EMAIL_PROVIDER === "console") {
    errors.push("EMAIL_PROVIDER=console is not allowed in production (would leak reset links to logs)");
  }
  if (process.env.EMAIL_PROVIDER === "resend" && !process.env.RESEND_API_KEY) {
    errors.push("RESEND_API_KEY is required when EMAIL_PROVIDER=resend");
  }
  if (process.env.EMAIL_PROVIDER === "resend" && !process.env.EMAIL_FROM) {
    errors.push("EMAIL_FROM is required when EMAIL_PROVIDER=resend (e.g. 'Ember <noreply@ember.dev>')");
  }

  if (errors.length) {
    throw new Error(`Invalid production configuration: ${errors.join("; ")}`);
  }
}

validateProductionConfig();

const app = new Hono();
app.use("*", correlationId());

// Custom logger that redacts query strings on OAuth callback routes
// (which contain live authorization codes that must not appear in logs)
const REDACT_PATHS = ["/api/auth/github/callback", "/api/auth/google/callback", "/api/github/connect/callback"];
app.use("*", logger((msg: string) => {
  for (const p of REDACT_PATHS) {
    if (msg.includes(p + "?")) {
      console.log(msg.replace(/\?[^ ]*/, "?[REDACTED]"));
      return;
    }
  }
  console.log(msg);
}));

// ── Security headers ─────────────────────────────────────────
const machineHostSuffix = process.env.MACHINE_HOST_SUFFIX || ".fly.dev";
const frameSrcPattern = `https://*${machineHostSuffix}`;

app.use(
  "*",
  secureHeaders({
    contentSecurityPolicy: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      frameSrc: [frameSrcPattern],
      connectSrc: ["'self'"],
    },
  }),
);

// ── CSRF protection on all POST/PUT/DELETE ───────────────────
// /v1/* uses API key auth (Authorization header), which is inherently CSRF-proof.
// Only browser-session routes need Origin-based CSRF.
app.use("/api/*", csrfProtection());

// ── Global rate limit ────────────────────────────────────────
app.use("/api/*", apiLimiter);
app.use("/v1/*", apiLimiter);

// ── Per-route rate limits ────────────────────────────────────
app.use("/api/auth/login", authLimiter);
app.use("/api/auth/register", registerLimiter);
app.use("/api/auth/github", authLimiter);
app.use("/api/auth/google", authLimiter);
app.use("/api/account/forgot-password", forgotPasswordLimiter);
app.use("/api/billing/checkout", billingLimiter);
app.use("/api/machines", machineLimiter);
app.use("/api/machines/*/terminal", terminalLimiter);

// ── Routes ───────────────────────────────────────────────────
app.route("/api/auth", authRoutes);
app.route("/api/billing", billingRoutes);
app.route("/api/machines", machineRoutes);
app.route("/api/admin", adminRoutes);
app.route("/api/settings", settingsRoutes);
app.route("/api/github", githubRoutes);
app.route("/api/account", accountRoutes);
app.route("/api/account", apiKeyRoutes);
app.route("/api/credits", creditsRoutes);

// Feature-flagged v1 routes: off by default for paid beta.
// Enable when entitlement/cost model is real.
const notEnabledWorkers = (c: any) => c.json({ error: "Workers API not enabled. Set ENABLE_V1_WORKERS=true." }, 501);
const notEnabledAI = (c: any) => c.json({ error: "Managed AI not enabled. Set ENABLE_MANAGED_AI=true." }, 501);

if (process.env.ENABLE_V1_WORKERS === "true") {
  app.route("/v1/workers", workerRoutes);
  console.log("[flags] v1/workers: enabled");
} else {
  app.all("/v1/workers", notEnabledWorkers);
  app.all("/v1/workers/*", notEnabledWorkers);
}
if (process.env.ENABLE_MANAGED_AI === "true") {
  app.route("/v1/ai", aiRoutes);
  console.log("[flags] v1/ai: enabled");
} else {
  app.all("/v1/ai", notEnabledAI);
  app.all("/v1/ai/*", notEnabledAI);
}
app.route("/v1/sessions", sessionRoutes);

// ── Health check (public) ────────────────────────────────────
app.get("/api/health", (c) => c.json({ status: "ok" }));

// ── Monitoring (admin-only, detailed) ────────────────────────
app.get("/api/health/detailed", async (c) => {
  // Authenticate via reconcile secret OR admin session cookie
  const auth = c.req.header("Authorization");
  const secret = process.env.RECONCILE_SECRET;
  let authorized = false;

  // Check bearer token (constant-time comparison to prevent timing attacks)
  if (secret && auth) {
    const expected = `Bearer ${secret}`;
    if (auth.length === expected.length &&
        crypto.timingSafeEqual(Buffer.from(auth), Buffer.from(expected))) {
      authorized = true;
    }
  }

  // Check admin session cookie
  if (!authorized) {
    try {
      const { getCookie } = await import("hono/cookie");
      const sessionId = getCookie(c, lucia.sessionCookieName);
      if (sessionId) {
        const { session, user: sessionUser } = await lucia.validateSession(sessionId);
        if (session && sessionUser) {
          const [dbUser] = await db.select({ role: users.role }).from(users).where(eq(users.id, sessionUser.id));
          if (dbUser?.role === "admin") authorized = true;
        }
      }
    } catch {}
  }

  if (!authorized) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  try {
    const [
      [{ count: totalUsers }],
      [{ count: totalMachines }],
      [{ count: runningMachines }],
      [{ count: needsStopMachines }],
      [{ count: errorMachines }],
      [{ count: activeSlots }],
      [{ count: cancelledSlots }],
    ] = await Promise.all([
      db.select({ count: sql<number>`count(*)` }).from(users),
      db.select({ count: sql<number>`count(*)` }).from(machines).where(isNull(machines.deletedAt)),
      db.select({ count: sql<number>`count(*)` }).from(machines).where(eq(machines.state, "started")),
      db.select({ count: sql<number>`count(*)` }).from(machines).where(eq(machines.state, "needs_stop")),
      db.select({ count: sql<number>`count(*)` }).from(machines).where(eq(machines.state, "error")),
      db.select({ count: sql<number>`count(*)` }).from(slots).where(eq(slots.status, "active")),
      db.select({ count: sql<number>`count(*)` }).from(slots).where(eq(slots.status, "cancelled")),
    ]);

    return c.json({
      status: needsStopMachines > 0 || errorMachines > 0 ? "degraded" : "ok",
      users: totalUsers,
      machines: {
        total: totalMachines,
        running: runningMachines,
        needs_stop: needsStopMachines,
        error: errorMachines,
      },
      slots: {
        active: activeSlots,
        cancelled: cancelledSlots,
      },
      alerts: [
        ...(needsStopMachines > 0 ? [`${needsStopMachines} machines stuck in needs_stop state`] : []),
        ...(errorMachines > 0 ? [`${errorMachines} machines in error state (possible orphaned Fly resources)`] : []),
      ],
    });
  } catch (e: any) {
    console.error("[health] detailed check failed:", e);
    return c.json({ status: "error", error: "Health check failed" }, 500);
  }
});

// ── Static files ─────────────────────────────────────────────
app.use("/*", serveStatic({ root: "./web/dist" }));
app.get("*", serveStatic({ root: "./web/dist", path: "index.html" }));

const port = parseInt(process.env.PORT || "3000", 10);
console.log(`Ember Cloud API starting on :${port}`);
serve({ fetch: app.fetch, port });
