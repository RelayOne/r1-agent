import { Context, Next } from "hono";
import { getCookie, setCookie } from "hono/cookie";
import type { CookieOptions } from "hono/utils/cookie";
import { lucia } from "./auth.js";
import crypto from "crypto";

export type Env = {
  Variables: {
    user: { id: string; email: string; name: string | null; role: string; status: string; avatarUrl: string | null };
    session: { id: string };
    requestId: string;
  };
};

// ── Request correlation ID ───────────────────────────────────
// Propagated through logs, responses, and downstream calls.
export function correlationId() {
  return async (c: Context, next: Next) => {
    const id = c.req.header("x-request-id") || crypto.randomUUID();
    c.set("requestId", id);
    c.header("X-Request-Id", id);
    return next();
  };
}

export function requireAuth() {
  return async (c: Context<Env>, next: Next) => {
    const sessionId = getCookie(c, lucia.sessionCookieName);
    if (!sessionId) return c.json({ error: "Not authenticated" }, 401);

    const { session, user } = await lucia.validateSession(sessionId);
    if (!session) {
      const blank = lucia.createBlankSessionCookie();
      const blankOpts: CookieOptions = {
        path: blank.attributes.path,
        domain: blank.attributes.domain,
        secure: blank.attributes.secure,
        httpOnly: blank.attributes.httpOnly,
        sameSite: blank.attributes.sameSite,
        maxAge: blank.attributes.maxAge,
      };
      setCookie(c, blank.name, blank.value, blankOpts);
      return c.json({ error: "Session expired" }, 401);
    }

    if (session.fresh) {
      const fresh = lucia.createSessionCookie(session.id);
      const freshOpts: CookieOptions = {
        path: fresh.attributes.path,
        domain: fresh.attributes.domain,
        secure: fresh.attributes.secure,
        httpOnly: fresh.attributes.httpOnly,
        sameSite: fresh.attributes.sameSite,
        maxAge: fresh.attributes.maxAge,
      };
      setCookie(c, fresh.name, fresh.value, freshOpts);
    }

    if (user.status === "banned") return c.json({ error: "Account suspended" }, 403);

    c.set("user", user);
    c.set("session", session);
    return next();
  };
}

export function requireAdmin() {
  return async (c: Context<Env>, next: Next) => {
    const user = c.get("user");
    if (user.role !== "admin") return c.json({ error: "Admin required" }, 403);
    return next();
  };
}

// CSRF protection via Origin header check.
// Safe methods (GET/HEAD/OPTIONS) are exempt.
// Stripe webhooks, machine-to-API calls, and reconcile are exempt
// (they have their own auth mechanisms).
export function csrfProtection() {
  const safeMethods = new Set(["GET", "HEAD", "OPTIONS"]);
  const exemptPrefixes = [
    "/api/billing/webhooks",
    "/api/billing/reconcile",
    "/api/machines/verify-code",
    "/v1/",
  ];

  return async (c: Context, next: Next) => {
    if (safeMethods.has(c.req.method)) return next();

    const pathname = new URL(c.req.url).pathname;
    if (exemptPrefixes.some((prefix) => pathname.startsWith(prefix))) return next();

    // Exempt startup script fetch (Bearer token auth, machine-to-API calls)
    if (/^\/api\/machines\/[^/]+\/startup$/.test(c.req.path)) return next();

    const origin = c.req.header("origin");
    if (!origin) {
      // No origin: require a custom header to prevent cross-origin form attacks.
      // Browsers never send X-Requested-With on cross-origin form POSTs.
      const customHeader = c.req.header("x-requested-with");
      if (customHeader) return next();
      return c.json({ error: "Missing Origin header" }, 403);
    }

    const appUrl = process.env.APP_URL || "http://localhost:3000";
    const allowed = new URL(appUrl).origin;

    if (origin !== allowed) {
      console.warn(`[csrf] blocked: ${origin} != ${allowed}`);
      return c.json({ error: "Invalid request origin" }, 403);
    }

    return next();
  };
}
