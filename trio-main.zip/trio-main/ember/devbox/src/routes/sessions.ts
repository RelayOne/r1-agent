// Ember v1 Sessions API - stores Stoke build progress for dashboard display.
// Uses Postgres for persistence across restarts and multi-instance consistency.

import { Hono } from "hono";
import { requireApiKeyV1 } from "../v1-auth.js";
import { rawSql } from "../connection.js";
import { nanoid } from "nanoid";
import { z } from "zod";

const APP_URL = process.env.APP_URL || "http://localhost:3000";

const app = new Hono<{ Variables: { userId: string; apiKeyId: string } }>();

const createSessionSchema = z.object({
  plan_id: z.string().max(200).optional(),
});

// POST /v1/sessions - register a new Stoke session
app.post("/", requireApiKeyV1(), async (c) => {
  const userId = c.get("userId");
  const parsed = createSessionSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Invalid request body" }, 400);
  const sessionId = nanoid(12);

  await rawSql`INSERT INTO stoke_sessions (id, user_id, plan_id, status, tasks, total_cost_usd, burst_workers, created_at, updated_at)
    VALUES (${sessionId}, ${userId}, ${parsed.data.plan_id || ''}, 'active', '[]'::jsonb, 0, 0, NOW(), NOW())`;

  return c.json({
    session_id: sessionId,
    url: `${APP_URL}/s/${sessionId}`,
  }, 201);
});

// PUT /v1/sessions/:id - update progress
app.put("/:id", requireApiKeyV1(), async (c) => {
  const sessionId = c.req.param("id")!;
  const userId = c.get("userId")!;
  const body = await c.req.json().catch(() => ({}));

  const [existing] = await rawSql`SELECT user_id FROM stoke_sessions WHERE id = ${sessionId}`;
  if (!existing) return c.json({ error: "Session not found" }, 404);
  if (existing.user_id !== userId) return c.json({ error: "Forbidden" }, 403);

  const updateSchema = z.object({
    status: z.enum(["active", "completed", "failed", "cancelled"]).optional(),
    tasks: z.array(z.any()).max(1000).optional(),
    total_cost_usd: z.number().min(0).max(1_000_000).optional(),
    burst_workers: z.number().int().min(0).max(10_000).optional(),
  });
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) return c.json({ error: "Invalid input" }, 400);

  const status: string | null = parsed.data.status || null;
  const tasks: string | null = parsed.data.tasks ? JSON.stringify(parsed.data.tasks) : null;
  const costUsd: string | null = parsed.data.total_cost_usd != null ? String(parsed.data.total_cost_usd) : null;
  const burstWorkers: number | null = parsed.data.burst_workers != null ? parsed.data.burst_workers : null;

  await rawSql`UPDATE stoke_sessions SET
    status = COALESCE(${status}, status),
    tasks = COALESCE(${tasks}::jsonb, tasks),
    total_cost_usd = COALESCE(${costUsd}::numeric, total_cost_usd),
    burst_workers = COALESCE(${burstWorkers}::int, burst_workers),
    updated_at = NOW()
    WHERE id = ${sessionId}`;

  return c.json({ ok: true });
});

// GET /v1/sessions/:id - read progress (public for shareable links)
// total_cost_usd is redacted: cost data is sensitive and must not leak to unauthenticated viewers.
app.get("/:id", async (c) => {
  const sessionId = c.req.param("id")!;
  const [session] = await rawSql`SELECT id, plan_id, status, tasks, burst_workers, created_at, updated_at
    FROM stoke_sessions WHERE id = ${sessionId}`;
  if (!session) return c.json({ error: "Session not found" }, 404);

  return c.json({
    session_id: session.id,
    plan_id: session.plan_id,
    status: session.status,
    tasks: session.tasks,
    burst_workers: session.burst_workers || 0,
    created_at: session.created_at,
    updated_at: session.updated_at,
  });
});

export default app;
