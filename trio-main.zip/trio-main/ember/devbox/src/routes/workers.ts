// Ember v1 Workers API - burst workers for Stoke tasks.
// Billed against prepaid credits via allocate_burst_worker(), NOT slot subscriptions.
// Returns 201 on success, 402 on insufficient credits, 500 with refund on provision failure.

import { Hono } from "hono";
import { nanoid } from "nanoid";
import crypto from "crypto";
import { z } from "zod";
import { requireApiKeyV1 } from "../v1-auth.js";
import { rawSql } from "../connection.js";
import * as fly from "../fly.js";

const app = new Hono<{ Variables: { userId: string; apiKeyId: string } }>();

const MAX_WORKERS = 20;

// Worker cost per size (cents). Only sizes that exist in Fly guest sizing.
// Fly defaults unknown sizes to performance-8x, so accepting 1x/2x would
// bill like a small worker but provision an 8x machine.
const WORKER_COST: Record<string, number> = {
  "performance-4x": 40,
  "performance-8x": 80,
  "performance-16x": 160,
};

const DEFAULT_TTL_MINUTES = 30;

const createWorkerSchema = z.object({
  name: z.string().max(100).optional(),
  size: z.string().default("performance-4x"),
  ttl_minutes: z.number().int().min(1).max(240).optional(),
  task_id: z.string().max(100).optional(),
  task_description: z.string().max(1000).optional(),
  repo_url: z.string().url().optional(),
  metadata: z.record(z.string()).optional(),
  idempotency_key: z.string().max(200).optional(),
});

// POST /v1/workers - spawn a burst worker
app.post("/", requireApiKeyV1(), async (c) => {
  const userId = c.get("userId");
  const apiKeyId = c.get("apiKeyId");

  const parsed = createWorkerSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  const { name, size, ttl_minutes, task_id, task_description, repo_url, metadata, idempotency_key } = parsed.data;

  const costCents = WORKER_COST[size];
  if (!costCents) return c.json({ error: `Invalid size. Options: ${Object.keys(WORKER_COST).join(", ")}` }, 400);

  const ttl = ttl_minutes || DEFAULT_TTL_MINUTES;
  const idemKey = idempotency_key || `wk_${crypto.randomUUID()}`;

  // Worker cap (before spending credits)
  const [countRow] = await rawSql`
    SELECT COUNT(*)::int as count FROM worker_allocations
    WHERE user_id = ${userId} AND status IN ('pending', 'active', 'needs_cleanup')`;
  if ((countRow?.count || 0) >= MAX_WORKERS) {
    return c.json({ error: `Worker limit reached (${MAX_WORKERS})` }, 429);
  }

  // Atomic credit deduction + allocation via PL/pgSQL.
  // Race-safe: UPDATE WHERE credits >= cost acquires row lock.
  // Idempotent: returns existing allocation if key was already used.
  let allocationId: string;
  let creditsRemaining: number;
  let expiresAt: string;
  try {
    const [result] = await rawSql`
      SELECT * FROM allocate_burst_worker(
        ${userId}, ${idemKey}, ${size}, ${costCents}, ${ttl},
        ${task_description || null},
        ${JSON.stringify({ api_key_id: apiKeyId, task_id, repo_url, name, ...(metadata || {}) })}
      )`;
    allocationId = result.allocation_id;
    creditsRemaining = result.credits_remaining;
    expiresAt = result.expires_at;

    if (result.was_duplicate) {
      return c.json({ id: allocationId, status: "already_exists", credits_remaining: creditsRemaining }, 200);
    }
  } catch (e: any) {
    if (e.message?.includes("Insufficient credits")) {
      return c.json({ error: "Insufficient credits. Top up at /credits." }, 402);
    }
    throw e;
  }

  // Provision synchronously. If it fails, refund immediately.
  const flyAppName = fly.appName(fly.flyAppId());
  const machineToken = crypto.randomBytes(32).toString("hex");

  try {
    const appResult = await fly.createFlyApp(flyAppName);
    if (!appResult) throw new Error("Failed to create Fly app");

    await fly.allocateIps(flyAppName);
    const cert = await fly.provisionCustomHostname(flyAppName);

    const flyResult = await fly.createMachine({
      flyAppName, region: "sjc", size,
      machineType: "cli", machineToken,
      label: name || "stoke-worker",
      gitRepo: repo_url,
      imageDigest: process.env.CANONICAL_IMAGE_DIGEST!,
      apiUrl: process.env.INTERNAL_API_URL!,
    });

    await rawSql`
      UPDATE worker_allocations
      SET status = 'active', started_at = NOW(),
          worker_instance_id = ${flyResult?.id || flyAppName},
          metadata = metadata || ${JSON.stringify({ fly_app: flyAppName, fly_machine: flyResult?.id })}::jsonb
      WHERE id = ${allocationId}`;

    return c.json({
      id: allocationId,
      hostname: `${flyAppName}${process.env.MACHINE_HOST_SUFFIX || '.fly.dev'}`,
      status: "active",
      expires_at: expiresAt,
      cost_cents: costCents,
      credits_remaining: creditsRemaining,
    }, 201);
  } catch (e: any) {
    // Provisioning failed. Best-effort cleanup, then refund credits atomically.
    const cleanup = await fly.destroyApp(flyAppName).catch(() => ({ ok: false, errors: ["exception"] }));
    if (!cleanup.ok) console.error(`[workers] provision cleanup failed for ${flyAppName}:`, cleanup.errors);
    await rawSql`SELECT refund_burst_worker(${allocationId}::uuid, ${'refund_' + idemKey}, ${e.message || 'Provisioning failed'})`;
    console.error("[workers] provisioning failed:", e);
    return c.json({ error: "Worker provisioning failed. Credits refunded." }, 500);
  }
});

// GET /v1/workers - list active workers
app.get("/", requireApiKeyV1(), async (c) => {
  const userId = c.get("userId");
  const workers = await rawSql`
    SELECT id, status, worker_type, cost_cents, expires_at,
           worker_instance_id, task_description, started_at, created_at
    FROM worker_allocations
    WHERE user_id = ${userId} AND status IN ('pending', 'active', 'needs_cleanup')
    ORDER BY created_at DESC LIMIT 50`;
  return c.json(workers);
});

// GET /v1/workers/:id/status
app.get("/:id/status", requireApiKeyV1(), async (c) => {
  const userId = c.get("userId");
  const [alloc] = await rawSql`
    SELECT id, status, worker_type, cost_cents, expires_at, error,
           worker_instance_id, started_at, completed_at, metadata
    FROM worker_allocations
    WHERE id = ${c.req.param("id")!} AND user_id = ${userId}`;
  if (!alloc) return c.json({ error: "Not found" }, 404);
  return c.json({
    id: alloc.id,
    status: alloc.status,
    workerType: alloc.worker_type,
    costCents: alloc.cost_cents,
    expiresAt: alloc.expires_at,
    error: alloc.error,
    workerInstanceId: alloc.worker_instance_id,
    startedAt: alloc.started_at,
    completedAt: alloc.completed_at,
    metadata: alloc.metadata,
  });
});

// DELETE /v1/workers/:id
app.delete("/:id", requireApiKeyV1(), async (c) => {
  const userId = c.get("userId");
  const [alloc] = await rawSql`
    SELECT id, status, metadata FROM worker_allocations
    WHERE id = ${c.req.param("id")!} AND user_id = ${userId}`;
  if (!alloc) return c.json({ error: "Not found" }, 404);
  if (["completed", "failed", "expired"].includes(alloc.status)) {
    return c.json({ error: "Worker already finalized" }, 409);
  }

  // Only mark completed after cleanup actually succeeds.
  // If destroyApp fails, mark needs_cleanup so the TTL sweep retries.
  const flyApp = alloc.metadata?.fly_app;
  let cleaned = true;
  if (flyApp) {
    const result = await fly.destroyApp(flyApp).catch(() => ({ ok: false, errors: ["exception"] }));
    cleaned = result.ok;
    if (!cleaned) console.error(`[workers] delete cleanup failed for ${flyApp}:`, result.errors);
  }

  if (cleaned) {
    await rawSql`
      UPDATE worker_allocations SET status = 'completed', completed_at = NOW()
      WHERE id = ${alloc.id} AND status IN ('pending', 'active', 'needs_cleanup')`;
  } else {
    await rawSql`
      UPDATE worker_allocations SET status = 'needs_cleanup'
      WHERE id = ${alloc.id} AND status IN ('pending', 'active', 'needs_cleanup')`;
  }
  return c.json({ ok: true, cleanup: cleaned ? "done" : "pending" });
});

// POST /v1/workers/:id/stop - stop and destroy a burst worker (ephemeral, not persistent)
app.post("/:id/stop", requireApiKeyV1(), async (c) => {
  const userId = c.get("userId");
  const [alloc] = await rawSql`
    SELECT id, worker_instance_id, metadata FROM worker_allocations
    WHERE id = ${c.req.param("id")!} AND user_id = ${userId} AND status IN ('pending', 'active', 'needs_cleanup')`;
  if (!alloc) return c.json({ error: "Not found or already stopped" }, 404);

  const flyApp = alloc.metadata?.fly_app;
  let cleaned = true;
  if (flyApp) {
    const result = await fly.destroyApp(flyApp).catch(() => ({ ok: false, errors: ["exception"] }));
    cleaned = result.ok;
    if (!cleaned) console.error(`[workers] stop cleanup failed for ${flyApp}:`, result.errors);
  }

  if (cleaned) {
    await rawSql`
      UPDATE worker_allocations SET status = 'completed', completed_at = NOW()
      WHERE id = ${alloc.id}`;
  } else {
    await rawSql`
      UPDATE worker_allocations SET status = 'needs_cleanup'
      WHERE id = ${alloc.id}`;
  }
  return c.json({ ok: true, cleanup: cleaned ? "done" : "pending" });
});

export default app;
