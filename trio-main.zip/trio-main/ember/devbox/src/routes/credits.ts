// Credit top-up via Stripe Checkout Sessions (mode: 'payment').
// Decoupled from slot subscriptions. No Stripe Billing surcharge.
// Webhook is the single writer -- never credit from the redirect handler.

import { Hono } from "hono";
import { z } from "zod";
import Stripe from "stripe";
import { rawSql } from "../connection.js";
import { requireAuth, type Env } from "../middleware.js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// Server-defined credit packages. Never trust client-sent amounts.
const CREDIT_PACKAGES: Record<string, { priceCents: number; creditsCents: number; label: string }> = {
  credits_500:  { priceCents: 500,  creditsCents: 500,  label: "$5 Credits" },
  credits_2000: { priceCents: 2000, creditsCents: 2000, label: "$20 Credits" },
  credits_5000: { priceCents: 5000, creditsCents: 5500, label: "$50 Credits (10% bonus)" },
};

const app = new Hono<Env>();

// POST /api/credits/checkout - create a Stripe Checkout Session for credit purchase
app.post("/checkout", requireAuth(), async (c) => {
  const user = c.get("user");
  const body = await c.req.json().catch(() => ({}));

  const packageId = (body as Record<string, unknown>).packageId as string;
  const pkg = CREDIT_PACKAGES[packageId];
  if (!pkg) {
    return c.json({
      error: "Invalid package",
      packages: Object.entries(CREDIT_PACKAGES).map(([id, p]) => ({ id, ...p })),
    }, 400);
  }

  // Look up or create Stripe customer (atomic: lock row to prevent concurrent creation)
  let customerId: string;
  {
    const [locked] = await rawSql`SELECT id, email, stripe_customer_id FROM users WHERE id = ${user.id} FOR UPDATE`;
    if (locked.stripe_customer_id) {
      customerId = locked.stripe_customer_id;
    } else {
      const customer = await stripe.customers.create({ email: user.email, metadata: { user_id: user.id } });
      customerId = customer.id;
      await rawSql`UPDATE users SET stripe_customer_id = ${customerId} WHERE id = ${user.id} AND stripe_customer_id IS NULL`;
      const [fresh] = await rawSql`SELECT stripe_customer_id FROM users WHERE id = ${user.id}`;
      customerId = fresh.stripe_customer_id!;
    }
  }

  const appUrl = process.env.APP_URL || "http://localhost:3000";

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer: customerId,
    line_items: [{
      price_data: {
        currency: "usd",
        unit_amount: pkg.priceCents,
        product_data: { name: pkg.label },
      },
      quantity: 1,
    }],
    metadata: {
      payment_type: "credit_purchase",
      user_id: user.id,
      credits_cents: String(pkg.creditsCents),
      package_id: packageId,
    },
    success_url: `${appUrl}/credits?purchase=success&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${appUrl}/credits?purchase=cancelled`,
  });

  return c.json({ checkoutUrl: session.url });
});

// GET /api/credits/balance - current credit balance + recent transactions
app.get("/balance", requireAuth(), async (c) => {
  const user = c.get("user");

  const [balance] = await rawSql`SELECT credits_cents FROM users WHERE id = ${user.id}`;
  const transactions = await rawSql`
    SELECT type, amount_cents, balance_after_cents, created_at, metadata
    FROM credit_transactions WHERE user_id = ${user.id}
    ORDER BY created_at DESC LIMIT 20`;

  const activeWorkers = await rawSql`
    SELECT id, status, cost_cents, expires_at, worker_type, created_at
    FROM worker_allocations WHERE user_id = ${user.id} AND status IN ('pending', 'active')
    ORDER BY created_at DESC`;

  return c.json({
    credits_cents: balance?.credits_cents || 0,
    recent_transactions: transactions,
    active_workers: activeWorkers,
    packages: Object.entries(CREDIT_PACKAGES).map(([id, p]) => ({ id, ...p })),
  });
});

// GET /api/credits/packages - list available packages (public)
app.get("/packages", (c) => {
  return c.json(Object.entries(CREDIT_PACKAGES).map(([id, p]) => ({ id, ...p })));
});

export default app;
