import { Hono } from "hono";
import { setCookie, getCookie } from "hono/cookie";
import { eq, and } from "drizzle-orm";
import { generateState } from "arctic";
import { db } from "../connection.js";
import { oauthAccounts } from "../db.js";
import { requireAuth, type Env } from "../middleware.js";
import { githubConnect } from "../auth.js";
import { decryptSecret, encryptSecret } from "../secrets.js";
import {
  isGitHubAppConfigured,
  getInstallationForUser,
  listInstallationRepos,
} from "../github-app.js";

// ── GitHub API response types ───────────────────────────────
interface GitHubUser {
  id: number;
  login: string;
  name: string | null;
  avatar_url: string;
}

interface GitHubRepo {
  full_name: string;
  name: string;
  private: boolean;
  clone_url: string;
  default_branch: string;
  updated_at: string;
}

interface GitHubOrg {
  login: string;
  avatar_url: string;
}

const app = new Hono<Env>();
const isProd = process.env.NODE_ENV === "production";
const cookieOpts = { path: "/", httpOnly: true, secure: isProd, maxAge: 600, sameSite: "lax" as const };

async function getGithubToken(userId: string): Promise<string | null> {
  const [account] = await db
    .select()
    .from(oauthAccounts)
    .where(and(eq(oauthAccounts.userId, userId), eq(oauthAccounts.provider, "github")))
    .limit(1);

  if (!account?.accessToken) return null;
  try {
    return decryptSecret(account.accessToken);
  } catch (e: any) {
    console.error(`[github] failed to decrypt token for user ${userId}:`, e.message);
    return null;
  }
}

// ── Status: does user have GitHub repo access? ───────────────
app.get("/status", requireAuth(), async (c) => {
  const user = c.get("user");
  const token = await getGithubToken(user.id);
  if (!token) return c.json({ connected: false, hasRepoAccess: false });

  // Check if the token has repo scope by trying to list repos
  const res = await fetch("https://api.github.com/user", {
    headers: { Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(10000),
  });
  const scopes = res.headers.get("x-oauth-scopes") || "";
  return c.json({
    connected: true,
    hasRepoAccess: scopes.includes("repo"),
  });
});

// ── Connect: upgrade GitHub OAuth to include repo + org scopes ──
// This is separate from login. Login only requests user:email.
// Users trigger this explicitly when they want to use private repos.
app.get("/connect", requireAuth(), async (c) => {
  const state = generateState();
  const url = githubConnect.createAuthorizationURL(state, ["user:email", "read:org", "repo"]);
  setCookie(c, "github_connect_state", state, cookieOpts);
  return c.redirect(url.toString());
});

app.get("/connect/callback", requireAuth(), async (c) => {
  const code = c.req.query("code");
  const state = c.req.query("state");
  const storedState = getCookie(c, "github_connect_state");

  if (!code || !state || state !== storedState) return c.redirect("/settings?error=github_connect_failed");

  try {
    const tokens = await githubConnect.validateAuthorizationCode(code);
    const accessToken = tokens.accessToken();
    const user = c.get("user");

    // Always get the GitHub identity for this token
    const ghRes = await fetch("https://api.github.com/user", {
      headers: { Authorization: `Bearer ${accessToken}` },
      signal: AbortSignal.timeout(10000),
    });
    const ghUser = await ghRes.json() as GitHubUser;
    const ghId = String(ghUser.id);

    const [linkedElsewhere] = await db
      .select()
      .from(oauthAccounts)
      .where(and(eq(oauthAccounts.provider, "github"), eq(oauthAccounts.providerId, ghId)))
      .limit(1);
    if (linkedElsewhere && linkedElsewhere.userId !== user.id) {
      return c.redirect("/settings?error=github_account_already_linked");
    }

    // Enforce one GitHub identity per user: update existing or insert new
    const [existing] = await db
      .select()
      .from(oauthAccounts)
      .where(and(eq(oauthAccounts.userId, user.id), eq(oauthAccounts.provider, "github")))
      .limit(1);

    if (existing) {
      // Update both providerId (in case they switched GitHub accounts) and token
      await db.update(oauthAccounts)
        .set({ providerId: ghId, accessToken: encryptSecret(accessToken) })
        .where(and(eq(oauthAccounts.userId, user.id), eq(oauthAccounts.provider, "github")));
    } else {
      await db.insert(oauthAccounts).values({
        provider: "github",
        providerId: ghId,
        userId: user.id,
        accessToken: encryptSecret(accessToken),
      });
    }

    return c.redirect("/settings?github=connected");
  } catch (e) {
    console.error("GitHub connect error:", e);
    return c.redirect("/settings?error=github_connect_failed");
  }
});

// ── List repos (requires repo scope) ─────────────────────────
app.get("/repos", requireAuth(), async (c) => {
  const user = c.get("user");
  const token = await getGithubToken(user.id);
  if (!token) return c.json({ error: "Connect GitHub first", needsConnect: true, repos: [] });

  const res = await fetch("https://api.github.com/user/repos?per_page=100&sort=updated", {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" },
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) return c.json({ error: "GitHub API failed", repos: [] }, 502);

  const scopes = res.headers.get("x-oauth-scopes") || "";
  if (!scopes.includes("repo")) {
    return c.json({ error: "GitHub repo access required", needsConnect: true, repos: [] }, 403);
  }

  const repos = (await res.json()) as GitHubRepo[];
  return c.json({
    repos: repos.map((r) => ({
      fullName: r.full_name, name: r.name, private: r.private,
      url: r.clone_url, defaultBranch: r.default_branch, updatedAt: r.updated_at,
    })),
  });
});

// ── List orgs ────────────────────────────────────────────────
app.get("/orgs", requireAuth(), async (c) => {
  const user = c.get("user");
  const token = await getGithubToken(user.id);
  if (!token) return c.json({ error: "Connect GitHub first", orgs: [] });

  const res = await fetch("https://api.github.com/user/orgs", {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" },
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) return c.json({ error: "GitHub API failed", orgs: [] }, 502);

  const orgs = (await res.json()) as GitHubOrg[];
  return c.json({ orgs: orgs.map((o) => ({ login: o.login, avatarUrl: o.avatar_url })) });
});

app.get("/orgs/:org/repos", requireAuth(), async (c) => {
  const user = c.get("user");
  const token = await getGithubToken(user.id);
  if (!token) return c.json({ error: "Connect GitHub first" }, 400);

  const orgParam = c.req.param("org")!;
  // Validate org name to prevent header injection in GitHub API URL
  if (!/^[a-zA-Z0-9_-]+$/.test(orgParam)) {
    return c.json({ error: "Invalid org name" }, 400);
  }
  const safeOrg = encodeURIComponent(orgParam);
  const res = await fetch(`https://api.github.com/orgs/${safeOrg}/repos?per_page=100&sort=updated`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" },
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) return c.json({ error: "GitHub API failed" }, 502);

  const repos = (await res.json()) as GitHubRepo[];
  return c.json({
    repos: repos.map((r) => ({
      fullName: r.full_name, name: r.name, private: r.private,
      url: r.clone_url, defaultBranch: r.default_branch,
    })),
  });
});


// Redirect user to install the GitHub App on their account/org
app.get("/install", requireAuth(), async (c) => {
  const appSlug = process.env.GITHUB_APP_SLUG;
  if (!appSlug || !isGitHubAppConfigured()) {
    return c.json({ error: "GitHub App not configured" }, 501);
  }
  return c.redirect(`https://github.com/apps/${appSlug}/installations/new`);
});

// List repos accessible via GitHub App installation (preferred over OAuth)
app.get("/app-repos", requireAuth(), async (c) => {
  if (!isGitHubAppConfigured()) {
    return c.json({ repos: [], method: "app_not_configured" });
  }

  const user = c.get("user");
  // Get user's GitHub username from OAuth account
  const token = await getGithubToken(user.id);
  if (!token) return c.json({ repos: [], method: "no_github_account" });

  let ghUsername: string | null = null;
  try {
    const ghRes = await fetch("https://api.github.com/user", {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" },
      signal: AbortSignal.timeout(10000),
    });
    if (ghRes.ok) {
      const ghUser = await ghRes.json() as GitHubUser;
      ghUsername = ghUser.login;
    }
  } catch {}

  if (!ghUsername) return c.json({ repos: [], method: "github_api_failed" });

  const installationId = await getInstallationForUser(ghUsername);
  if (!installationId) {
    return c.json({ repos: [], method: "no_installation", installUrl: process.env.GITHUB_APP_SLUG
      ? `https://github.com/apps/${process.env.GITHUB_APP_SLUG}/installations/new`
      : null });
  }

  const repos = await listInstallationRepos(installationId);
  return c.json({
    repos: repos.map((r: any) => ({
      fullName: r.full_name, name: r.name, private: r.private,
      url: r.clone_url, defaultBranch: r.default_branch, updatedAt: r.updated_at,
    })),
    method: "app",
  });
});

// Check if user has GitHub App installed
app.get("/app-status", requireAuth(), async (c) => {
  if (!isGitHubAppConfigured()) {
    return c.json({ configured: false, installed: false });
  }

  const user = c.get("user");
  const token = await getGithubToken(user.id);
  if (!token) return c.json({ configured: true, installed: false, needsOAuth: true });

  let ghUsername: string | null = null;
  try {
    const ghRes = await fetch("https://api.github.com/user", {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" },
      signal: AbortSignal.timeout(10000),
    });
    if (ghRes.ok) {
      const ghUser = await ghRes.json() as GitHubUser;
      ghUsername = ghUser.login;
    }
  } catch {}

  if (!ghUsername) return c.json({ configured: true, installed: false });

  const installationId = await getInstallationForUser(ghUsername);
  return c.json({
    configured: true,
    installed: !!installationId,
    installUrl: !installationId && process.env.GITHUB_APP_SLUG
      ? `https://github.com/apps/${process.env.GITHUB_APP_SLUG}/installations/new`
      : null,
  });
});

export default app;
