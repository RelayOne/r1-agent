import { Hono } from "hono";
import Stripe from "stripe";
import { eq, and, lt, isNull, desc } from "drizzle-orm";
import crypto from "crypto";
import { z } from "zod";
import { db, rawSql, type Transaction } from "../connection.js";
import {
  users, slots, billingEvents, machines, subscriptions, purchaseIntents, auditLog,
} from "../db.js";
import { requireAuth, type Env } from "../middleware.js";
import { nanoid } from "nanoid";
import * as fly from "../fly.js";

function requireEnv(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

const stripe = new Stripe(requireEnv("STRIPE_SECRET_KEY"));

const PRICES: Record<string, { stripePriceId: string; cents: number }> = {
  "performance-4x": { stripePriceId: requireEnv("STRIPE_PRICE_4X"), cents: 9600 },
  "performance-8x": { stripePriceId: requireEnv("STRIPE_PRICE_8X"), cents: 17400 },
  "performance-16x": { stripePriceId: requireEnv("STRIPE_PRICE_16X"), cents: 34800 },
};

function priceToSize(priceId: string): string | null {
  for (const [size, p] of Object.entries(PRICES)) {
    if (p.stripePriceId === priceId) return size;
  }
  return null;
}

// Subscription statuses that grant access
const ACCESS_STATUSES = new Set(["active", "trialing"]);
// Subscription statuses that should revoke access
const REVOKE_STATUSES = new Set(["canceled", "unpaid", "paused", "incomplete_expired"]);
// Subscription statuses where user needs to fix payment
const DELINQUENT_STATUSES = new Set(["past_due", "unpaid"]);

const app = new Hono<Env>();

// ══════════════════════════════════════════════════════════════
// READS: All entitlement checks use LOCAL state, never live Stripe
// ══════════════════════════════════════════════════════════════

app.get("/", requireAuth(), async (c) => {
  const user = c.get("user");
  const [dbUser] = await db.select().from(users).where(eq(users.id, user.id));

  const userSubs = await db.select().from(subscriptions)
    .where(eq(subscriptions.userId, user.id))
    .orderBy(desc(subscriptions.createdAt));

  const userSlots = await db.select().from(slots).where(eq(slots.userId, user.id));

  const activeSubs = userSubs.filter(s => ACCESS_STATUSES.has(s.status));
  const delinquentSub = userSubs.find(s => DELINQUENT_STATUSES.has(s.status));

  // Determine billing action
  let billingAction: "fix_payment" | "manage_subscriptions" | null = null;
  if (delinquentSub) {
    billingAction = "fix_payment";
  } else if (activeSubs.length > 1) {
    // Multiple active subscriptions: user needs to consolidate via portal
    billingAction = "manage_subscriptions";
  }

  // Canonical subscription: the one we'll attach new slots to
  const canonicalSub = billingAction ? null : (activeSubs[0] || null);

  return c.json({
    slots: userSlots.filter(s => s.status === "active"),
    cancelledSlots: userSlots.filter(s => s.status === "cancelled"),
    prices: Object.entries(PRICES).map(([size, p]) => ({ size, priceCents: p.cents })),
    hasStripeCustomer: !!dbUser.stripeCustomerId,
    subscription: canonicalSub || delinquentSub || null,
    subscriptionStatus: delinquentSub?.status || (activeSubs.length > 1 ? "multiple_active" : activeSubs[0]?.status) || userSubs[0]?.status || null,
    billingAction,
    activeSubscriptionCount: activeSubs.length,
  });
});

// ══════════════════════════════════════════════════════════════
// PURCHASE: Intent-based idempotency
// ══════════════════════════════════════════════════════════════

const checkoutSchema = z.object({
  size: z.enum(["performance-4x", "performance-8x", "performance-16x"]),
  intentId: z.string().optional(),   // Backend canonical name
  requestId: z.string().optional(),  // Frontend sends this (persisted in localStorage)
});

app.post("/checkout", requireAuth(), async (c) => {
  const user = c.get("user");
  const parsed = checkoutSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Invalid input" }, 400);
  const { size } = parsed.data;
  // Accept either name: frontend sends requestId, backend uses intentId
  const clientIntentId = parsed.data.intentId || parsed.data.requestId;
  const price = PRICES[size]!;

  // 1. Resolve or create a purchase intent
  let intent: any;
  if (clientIntentId) {
    [intent] = await db.select().from(purchaseIntents)
      .where(and(eq(purchaseIntents.id, clientIntentId), eq(purchaseIntents.userId, user.id)))
      .limit(1);
    if (intent?.status === "completed") {
      return c.json({ ok: true, slotId: intent.slotId, intentId: intent.id });
    }
    if (!intent || intent.status === "expired") {
      // Create with the client-provided ID so retries reuse the same key
      intent = null;
    }
  }
  if (!intent) {
    const intentIdToUse = clientIntentId || nanoid();
    intent = { id: intentIdToUse, userId: user.id, type: "checkout", size, status: "pending",
      expiresAt: new Date(Date.now() + 3600_000) };
    await rawSql`INSERT INTO purchase_intents (id, user_id, type, size, status, expires_at, created_at)
      VALUES (${intent.id}, ${intent.userId}, ${intent.type}, ${intent.size}, ${intent.status}, ${intent.expiresAt.toISOString()}, NOW())
      ON CONFLICT (id) DO NOTHING`;
    // Re-read in case of race
    [intent] = await db.select().from(purchaseIntents)
      .where(eq(purchaseIntents.id, intentIdToUse)).limit(1);
    if (!intent) {
      return c.json({ error: "Failed to create purchase intent" }, 500);
    }
  }

  // 2. Ensure Stripe customer (atomic: lock row to prevent concurrent creation)
  let customerId: string;
  {
    const [locked] = await rawSql`SELECT id, email, stripe_customer_id FROM users WHERE id = ${user.id} FOR UPDATE`;
    if (locked.stripe_customer_id) {
      customerId = locked.stripe_customer_id;
    } else {
      const customer = await stripe.customers.create(
        { email: locked.email, metadata: { userId: user.id } },
        { idempotencyKey: `customer:${user.id}` }
      );
      await rawSql`UPDATE users SET stripe_customer_id = ${customer.id}
        WHERE id = ${user.id} AND stripe_customer_id IS NULL`;
      // Re-read in case another transaction set it between our lock release and update
      const [fresh] = await rawSql`SELECT stripe_customer_id FROM users WHERE id = ${user.id}`;
      customerId = fresh.stripe_customer_id!;
    }
  }

  // 3. Check for delinquent or ambiguous subscription state -> portal
  const userSubs = await db.select().from(subscriptions)
    .where(eq(subscriptions.userId, user.id));
  const delinquentSub = userSubs.find(s => DELINQUENT_STATUSES.has(s.status));
  const activeSubs = userSubs.filter(s => ACCESS_STATUSES.has(s.status));

  if (delinquentSub) {
    const APP_URL = process.env.APP_URL || "http://localhost:3000";
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId, return_url: `${APP_URL}/settings`,
    });
    return c.json({ url: session.url, reason: "fix_payment", intentId: intent.id });
  }

  if (activeSubs.length > 1) {
    // Multiple active subscriptions: cannot determine canonical. Send to portal.
    const APP_URL = process.env.APP_URL || "http://localhost:3000";
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId, return_url: `${APP_URL}/settings`,
    });
    return c.json({ url: session.url, reason: "manage_subscriptions", intentId: intent.id });
  }

  // 4. Find single active subscription
  const activeSub = activeSubs[0] || null;

  if (activeSub) {
    // Add slot to existing subscription.
    // Use a per-attempt nonce in the idempotency key so that retries after
    // compensation (which deletes the Stripe item) don't receive a cached
    // response pointing to the now-deleted item.  Intent-level deduplication
    // (the "completed" check above) still prevents true duplicate charges.
    const stripeIdempotencyKey = `slot:${intent.id}:${nanoid()}`;

    let item: Stripe.SubscriptionItem;
    try {
      item = await stripe.subscriptionItems.create({
        subscription: activeSub.stripeSubscriptionId,
        price: price.stripePriceId,
        quantity: 1,
        proration_behavior: "always_invoice",
        payment_behavior: "error_if_incomplete",
      }, { idempotencyKey: stripeIdempotencyKey });
    } catch (e: any) {
      await db.update(purchaseIntents).set({ status: "failed", errorMessage: e.message })
        .where(eq(purchaseIntents.id, intent.id));
      return c.json({ error: "Payment failed", intentId: intent.id }, 402);
    }

    // Write slot + complete intent in transaction
    const slotId = nanoid();
    try {
      await rawSql.begin(async (tx) => {
        await tx`INSERT INTO slots (id, user_id, subscription_id, stripe_subscription_item_id, size, price_cents, status, created_at)
          VALUES (${slotId}, ${user.id}, ${activeSub.id}, ${item.id}, ${size}, ${price.cents}, 'active', NOW())
          ON CONFLICT (stripe_subscription_item_id) DO NOTHING`;
        const [slot] = await tx`SELECT id FROM slots WHERE stripe_subscription_item_id = ${item.id} LIMIT 1`;
        await tx`UPDATE purchase_intents SET status = 'completed', type = 'add_slot', slot_id = ${slot.id},
          stripe_subscription_item_id = ${item.id}, completed_at = NOW()
          WHERE id = ${intent.id}`;
        await tx`INSERT INTO billing_events (id, user_id, type, slot_id, subscription_id, amount_cents, description, created_at)
          VALUES (${nanoid()}, ${user.id}, 'slot_created', ${slot.id}, ${activeSub.id}, ${price.cents}, ${'Added ' + size}, NOW())
          ON CONFLICT DO NOTHING`;
      });
      const [slot] = await rawSql`SELECT id FROM slots WHERE stripe_subscription_item_id = ${item.id}`;
      return c.json({ ok: true, slotId: slot.id, intentId: intent.id });
    } catch (e: any) {
      // Do NOT delete the Stripe item on DB failure.
      // The item has already been charged (payment_behavior: error_if_incomplete).
      // Deleting it would create an orphaned Stripe item if this is a retry that
      // already succeeded on the Stripe side. The reconciler will catch orphans.
      console.error("[billing] DB failed after Stripe item created:", e.message);
      await db.update(purchaseIntents).set({ status: "failed", errorMessage: e.message })
        .where(eq(purchaseIntents.id, intent.id));
      return c.json({ error: "Failed to record slot", intentId: intent.id }, 500);
    }
  }

  // 5. No active subscription: Stripe Checkout
  const APP_URL = process.env.APP_URL || "http://localhost:3000";
  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    mode: "subscription",
    line_items: [{ price: price.stripePriceId, quantity: 1 }],
    success_url: `${APP_URL}/dashboard?checkout=success&intent=${intent.id}`,
    cancel_url: `${APP_URL}/dashboard?checkout=cancelled`,
    metadata: { userId: user.id, size, intentId: intent.id },
  }, { idempotencyKey: `checkout:${intent.id}` });

  await db.update(purchaseIntents)
    .set({ type: "checkout", stripeSessionId: session.id })
    .where(eq(purchaseIntents.id, intent.id));

  return c.json({ url: session.url, intentId: intent.id });
});

// ── Portal ───────────────────────────────────────────────────
app.post("/portal", requireAuth(), async (c) => {
  const user = c.get("user");
  const [dbUser] = await db.select().from(users).where(eq(users.id, user.id));
  if (!dbUser.stripeCustomerId) return c.json({ error: "No billing account" }, 400);
  const APP_URL = process.env.APP_URL || "http://localhost:3000";
  const session = await stripe.billingPortal.sessions.create({
    customer: dbUser.stripeCustomerId, return_url: `${APP_URL}/settings`,
  });
  return c.json({ url: session.url });
});

app.get("/history", requireAuth(), async (c) => {
  const user = c.get("user");
  const events = await db.select().from(billingEvents)
    .where(eq(billingEvents.userId, user.id)).orderBy(desc(billingEvents.createdAt)).limit(100);
  return c.json({ events });
});

// Get or resume a pending intent
app.get("/intent/:id", requireAuth(), async (c) => {
  const user = c.get("user");
  const [intent] = await db.select().from(purchaseIntents)
    .where(and(eq(purchaseIntents.id, c.req.param("id")!), eq(purchaseIntents.userId, user.id)));
  if (!intent) return c.json({ error: "Not found" }, 404);
  return c.json({ intent });
});

// ══════════════════════════════════════════════════════════════
// WEBHOOKS: Write canonical state to local tables
// ══════════════════════════════════════════════════════════════

// Sync a Stripe subscription object into our local subscriptions table.
// This is called from every subscription-related webhook and from the reconciler.
async function syncSubscription(stripeSubId: string, userId: string, stripeSub?: Stripe.Subscription, stripeEventId?: string) {
  if (!stripeSub) {
    stripeSub = await stripe.subscriptions.retrieve(stripeSubId);
  }

  // Convert dates to ISO strings for rawSql (postgres.js tagged templates can't serialize Date objects)
  const periodStart = new Date(stripeSub.current_period_start * 1000).toISOString();
  const periodEnd = new Date(stripeSub.current_period_end * 1000).toISOString();
  const cancelAt = stripeSub.cancel_at ? new Date(stripeSub.cancel_at * 1000).toISOString() : null;
  const canceledAt = stripeSub.canceled_at ? new Date(stripeSub.canceled_at * 1000).toISOString() : null;
  const subStatus = stripeSub.status;

  // Atomic upsert: INSERT ... ON CONFLICT to eliminate TOCTOU race between
  // concurrent webhook events for the same subscription.
  const candidateId = nanoid();
  const [upserted] = await rawSql`INSERT INTO subscriptions (id, user_id, stripe_subscription_id, status,
      current_period_start, current_period_end, cancel_at, canceled_at,
      last_stripe_event_id, last_stripe_event_ts, created_at, updated_at)
    VALUES (${candidateId}, ${userId}, ${stripeSubId}, ${subStatus},
      ${periodStart}, ${periodEnd},
      ${cancelAt}, ${canceledAt}, ${stripeEventId || null}, NOW(), NOW(), NOW())
    ON CONFLICT (stripe_subscription_id) DO UPDATE SET
      status = ${subStatus},
      current_period_start = ${periodStart},
      current_period_end = ${periodEnd},
      cancel_at = ${cancelAt},
      canceled_at = ${canceledAt},
      last_stripe_event_id = ${stripeEventId || null},
      last_stripe_event_ts = NOW(),
      updated_at = NOW()
    RETURNING id`;
  const localSubId = upserted.id;

  // Sync slots: ensure every active subscription item has a local slot
  for (const item of stripeSub.items.data) {
    const size = priceToSize(item.price.id);
    if (!size) continue;

    if (ACCESS_STATUSES.has(stripeSub.status)) {
      // Reactivate or create slot
      const [activeSlot] = await rawSql`
        SELECT id, size, price_cents FROM slots WHERE stripe_subscription_item_id = ${item.id} AND status = 'active' LIMIT 1`;
      if (activeSlot) {
        // Refresh size/price if Stripe changed the plan on the same item ID
        const priceCents = PRICES[size]?.cents || 0;
        if (activeSlot.size !== size || activeSlot.price_cents !== priceCents) {
          await rawSql`UPDATE slots SET size = ${size}, price_cents = ${priceCents}, subscription_id = ${localSubId}, updated_at = NOW()
            WHERE id = ${activeSlot.id}`;
        }
        continue;
      }

      const [cancelledSlot] = await rawSql`
        SELECT id FROM slots WHERE stripe_subscription_item_id = ${item.id} AND status = 'cancelled' LIMIT 1`;
      if (cancelledSlot) {
        await rawSql`UPDATE slots SET status = 'active', cancelled_at = NULL, subscription_id = ${localSubId}
          WHERE id = ${cancelledSlot.id}`;
        continue;
      }

      const slotId = nanoid();
      await rawSql`INSERT INTO slots (id, user_id, subscription_id, stripe_subscription_item_id, size, price_cents, status, created_at)
        VALUES (${slotId}, ${userId}, ${localSubId}, ${item.id}, ${size}, ${PRICES[size]?.cents || 0}, 'active', NOW())
        ON CONFLICT (stripe_subscription_item_id) DO NOTHING`;
    }
  }

  // Cancel slots for items no longer in the subscription
  if (REVOKE_STATUSES.has(stripeSub.status) || DELINQUENT_STATUSES.has(stripeSub.status)) {
    await rawSql`UPDATE slots SET status = 'cancelled', cancelled_at = NOW()
      WHERE subscription_id = ${localSubId} AND status = 'active'`;
  } else {
    const activeItemIds = stripeSub.items.data.map(i => i.id);
    if (activeItemIds.length > 0) {
      // Cancel slots whose items were removed (single atomic UPDATE)
      await rawSql`UPDATE slots SET status = 'cancelled', cancelled_at = NOW()
        WHERE subscription_id = ${localSubId} AND status = 'active'
        AND stripe_subscription_item_id IS NOT NULL
        AND stripe_subscription_item_id NOT IN ${rawSql(activeItemIds)}`;
    }
  }

  return localSubId;
}

// Stop machines bound to cancelled slots
async function enforceSlotCancellations(userId: string) {
  const cancelledSlotIds = (await rawSql`
    SELECT id FROM slots WHERE user_id = ${userId} AND status = 'cancelled'`
  ).map((r: any) => r.id);

  if (!cancelledSlotIds.length) return;

  // Enforce on both "running" AND "creating" machines.
  // A machine stuck in "creating" (hostname provisioning) with a cancelled slot
  // must not be allowed to promote to "running" later.
  const userMachines = await rawSql`
    SELECT id, fly_app_name, fly_machine_id, state, slot_id FROM machines
    WHERE user_id = ${userId} AND state IN ('started', 'creating', 'needs_stop')
      AND deleted_at IS NULL`;

  for (const m of userMachines) {
    if (m.slot_id && cancelledSlotIds.includes(m.slot_id)) {
      if (m.fly_machine_id) {
        const stopped = await fly.stopMachine(m.fly_app_name, m.fly_machine_id);
        if (stopped) {
          await rawSql`UPDATE machines SET state = 'stopped', updated_at = NOW() WHERE id = ${m.id}`;
        } else {
          await rawSql`UPDATE machines SET state = 'needs_stop', updated_at = NOW() WHERE id = ${m.id}`;
        }
      } else {
        // Machine in "creating" with no Fly machine ID yet: just mark stopped
        await rawSql`UPDATE machines SET state = 'stopped', updated_at = NOW() WHERE id = ${m.id}`;
      }
    }
  }
}

app.post("/webhooks", async (c) => {
  if (!process.env.STRIPE_WEBHOOK_SECRET) return c.json({ error: "Webhook not configured" }, 500);

  const sig = c.req.header("stripe-signature");
  const body = await c.req.text();

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig!, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch {
    return c.json({ error: "Invalid signature" }, 400);
  }

  try {
    // Idempotency: atomic INSERT … ON CONFLICT DO NOTHING eliminates the
    // TOCTOU race that existed when the old SELECT ran outside any transaction.
    // If the INSERT returns nothing (conflict), we already processed this event.
    const [fresh] = await rawSql`
      INSERT INTO billing_events (id, user_id, type, stripe_event_id, description, created_at)
      VALUES (${nanoid()}, NULL, 'idempotency_guard', ${event.id}, 'guard', NOW())
      ON CONFLICT (stripe_event_id) DO NOTHING
      RETURNING id`;
    if (!fresh) return c.json({ received: true });

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;

        // Route based on payment_type metadata (credit purchase vs subscription)
        if (session.metadata?.payment_type === "credit_purchase") {
          // Credit top-up: single-writer pattern. Only the webhook credits balance.
          if (session.payment_status !== "paid") break;
          const userId = session.metadata.user_id;
          const creditsCents = parseInt(session.metadata.credits_cents, 10);
          if (!userId || !Number.isFinite(creditsCents) || creditsCents <= 0) break;

          // All three operations in one transaction: idempotency check + balance update + ledger entry.
          // If any step fails, the whole thing rolls back. No partial credit.
          await rawSql.begin(async (tx) => {
            // Check-then-insert: ON CONFLICT DO NOTHING RETURNING returns nothing
            // on conflict, so we must check explicitly to prevent double-crediting.
            const [existing] = await tx`
              SELECT event_id FROM processed_stripe_events WHERE event_id = ${event.id} FOR UPDATE`;
            if (existing) return; // already processed
            await tx`INSERT INTO processed_stripe_events (event_id, classification, processed_at)
              VALUES (${event.id}, 'credit_purchase', NOW())`;

            await tx`UPDATE users SET credits_cents = credits_cents + ${creditsCents} WHERE id = ${userId}`;
            const [user] = await tx`SELECT credits_cents FROM users WHERE id = ${userId}`;
            await tx`
              INSERT INTO credit_transactions (idempotency_key, user_id, type, amount_cents, balance_after_cents, metadata)
              VALUES (${'stripe_evt_' + event.id}, ${userId}, 'topup', ${creditsCents}, ${user.credits_cents},
                ${JSON.stringify({ stripe_session_id: session.id, stripe_event_id: event.id, package_id: session.metadata?.package_id })})`;
          });
          break;
        }

        // Subscription checkout (existing logic)
        const userId = session.metadata?.userId;
        const intentId = session.metadata?.intentId;
        if (!userId || !session.subscription) break;

        // Sync the new subscription
        const localSubId = await syncSubscription(session.subscription as string, userId, undefined, event.id);

        // Complete the purchase intent
        if (intentId) {
          const [slot] = await rawSql`SELECT id FROM slots WHERE subscription_id = ${localSubId} LIMIT 1`;
          await rawSql`UPDATE purchase_intents SET status = 'completed', slot_id = ${slot?.id || null}, completed_at = NOW()
            WHERE id = ${intentId}`;
        }

        await rawSql`INSERT INTO billing_events (id, user_id, type, subscription_id, stripe_event_id, description, created_at)
          VALUES (${nanoid()}, ${userId}, 'checkout_completed', ${localSubId}, ${event.id}, 'New subscription', NOW())
          ON CONFLICT (stripe_event_id) DO NOTHING`;
        break;
      }

      case "invoice.paid": {
        const invoice = event.data.object as Stripe.Invoice;
        const customerId = invoice.customer as string;
        const [user] = await db.select().from(users).where(eq(users.stripeCustomerId, customerId));
        if (!user) break;

        // Sync subscription state (invoice.paid means subscription is healthy)
        let localSubId: string | null = null;
        if (invoice.subscription) {
          localSubId = await syncSubscription(invoice.subscription as string, user.id, undefined, event.id);
        }

        await rawSql`INSERT INTO billing_events (id, user_id, type, subscription_id, amount_cents, stripe_event_id, description, created_at)
          VALUES (${nanoid()}, ${user.id}, 'charge', ${localSubId}, ${invoice.amount_paid}, ${event.id}, ${'Invoice ' + (invoice.number || '')}, NOW())
          ON CONFLICT (stripe_event_id) DO NOTHING`;

        // Clear any needs_stop machines since payment succeeded
        const needsStopMachines = await db.select().from(machines)
          .where(and(eq(machines.userId, user.id), eq(machines.state, "needs_stop")));
        for (const m of needsStopMachines) {
          // Re-check: does this machine's slot now have an active subscription?
          if (m.slotId) {
            const [slot] = await rawSql`SELECT status FROM slots WHERE id = ${m.slotId}`;
            if (slot?.status === "active") {
              await db.update(machines).set({ state: "stopped", updatedAt: new Date() }).where(eq(machines.id, m.id));
            }
          }
        }
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        const customerId = invoice.customer as string;
        const [user] = await db.select().from(users).where(eq(users.stripeCustomerId, customerId));
        if (!user) break;

        if (invoice.subscription) {
          await syncSubscription(invoice.subscription as string, user.id, undefined, event.id);
        }

        await rawSql`INSERT INTO billing_events (id, user_id, type, amount_cents, stripe_event_id, description, created_at)
          VALUES (${nanoid()}, ${user.id}, 'payment_failed', ${invoice.amount_due}, ${event.id}, 'Payment failed', NOW())`;

        // Enforce entitlement loss immediately. syncSubscription above may have
        // transitioned the subscription to "unpaid" or "incomplete", which cancels
        // slots. Stop any running machines bound to those cancelled slots now,
        // instead of waiting for the next reconciler pass or a later webhook.
        await enforceSlotCancellations(user.id);
        break;
      }

      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.paused":
      case "customer.subscription.resumed":
      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;
        const customerId = sub.customer as string;
        const [user] = await db.select().from(users).where(eq(users.stripeCustomerId, customerId));
        if (!user) break;

        // CRITICAL: Do NOT pass the event payload to syncSubscription.
        // Stripe does not guarantee event delivery order.
        // Always fetch the CURRENT subscription state from Stripe API
        // so that a stale event cannot overwrite newer local state.
        const localSubId = await syncSubscription(sub.id, user.id, undefined, event.id);

        await rawSql`INSERT INTO billing_events (id, user_id, type, subscription_id, stripe_event_id, description, created_at)
          VALUES (${nanoid()}, ${user.id}, ${'subscription_' + sub.status}, ${localSubId}, ${event.id}, ${'Sub ' + sub.id + ' event ' + sub.status + ' (live state synced)'}, NOW())`;

        // Enforce access changes
        await enforceSlotCancellations(user.id);
        break;
      }
    }
  } catch (e: unknown) {
    console.error(`[webhook] error processing ${event.type}:`, e);
    // Return 200 for permanent/logic errors so Stripe doesn't retry endlessly.
    // Only return 500 for transient errors (DB/network) that are worth retrying.
    const isTransient = e instanceof Error && (
      e.message.includes("connect") || e.message.includes("timeout") ||
      e.message.includes("ECONNREFUSED") || e.message.includes("database")
    );
    if (isTransient) {
      return c.json({ error: "Internal error" }, 500);
    }
    return c.json({ received: true, warning: "Permanent processing error" });
  }

  return c.json({ received: true });
});

// ══════════════════════════════════════════════════════════════
// RECONCILER: Drift detection + enforcement
// ══════════════════════════════════════════════════════════════

async function reconcile() {
  const results: string[] = [];

  // 1. Retry needs_stop machines (re-check entitlement first)
  const stuckMachines = await db.select().from(machines).where(eq(machines.state, "needs_stop"));
  for (const m of stuckMachines) {
    if (m.slotId) {
      const [slot] = await rawSql`SELECT status FROM slots WHERE id = ${m.slotId}`;
      if (slot?.status === "active") {
        // Slot was reactivated (payment recovered) -- clear needs_stop
        await db.update(machines).set({ state: "stopped", updatedAt: new Date() }).where(eq(machines.id, m.id));
        results.push(`${m.flyAppName}: cleared needs_stop (slot reactivated)`);
        continue;
      }
    }
    const stopped = await fly.stopMachine(m.flyAppName, m.flyMachineId!);
    if (stopped) {
      await db.update(machines).set({ state: "stopped", updatedAt: new Date() }).where(eq(machines.id, m.id));
      results.push(`${m.flyAppName}: stopped`);
    } else {
      results.push(`${m.flyAppName}: still failed`);
    }
  }

  // Track users who may need entitlement enforcement
  const affectedUserIds = new Set<string>();

  // 2. Sync ALL local subscriptions against Stripe (not just active).
  // A missed webhook could leave local state as past_due, unpaid, trialing, or paused
  // while Stripe has moved on. Syncing all ensures we catch every drift.
  const localSubs = await db.select().from(subscriptions).limit(500);
  for (const localSub of localSubs) {
    try {
      await syncSubscription(localSub.stripeSubscriptionId, localSub.userId);
      affectedUserIds.add(localSub.userId);
    } catch (e: any) {
      results.push(`sync ${localSub.stripeSubscriptionId}: ${e.message}`);
    }
  }

  // 3. Detect orphaned Stripe items (item exists in Stripe but no local slot)
  // This runs against all users with a customer ID to catch drift
  const usersWithCustomer = await rawSql`SELECT id, stripe_customer_id FROM users WHERE stripe_customer_id IS NOT NULL`;
  for (const u of usersWithCustomer) {
    try {
      const subs = await stripe.subscriptions.list({ customer: u.stripe_customer_id, limit: 10 });
      for (const sub of subs.data) {
        for (const item of sub.items.data) {
          const [localSlot] = await rawSql`SELECT id FROM slots WHERE stripe_subscription_item_id = ${item.id} LIMIT 1`;
          if (!localSlot) {
            results.push(`ORPHAN: Stripe item ${item.id} (sub ${sub.id}, user ${u.id}) has no local slot`);
          }
        }
      }
    } catch (e: any) {
      results.push(`drift check user ${u.id}: ${e.message}`);
    }
  }

  // 4. Detect local slots without Stripe backing
  const activeSlots = await rawSql`SELECT id, stripe_subscription_item_id, user_id FROM slots WHERE status = 'active' AND stripe_subscription_item_id IS NOT NULL`;
  for (const slot of activeSlots) {
    try {
      await stripe.subscriptionItems.retrieve(slot.stripe_subscription_item_id);
    } catch (e: any) {
      if (e.code === "resource_missing") {
        results.push(`ORPHAN: Local slot ${slot.id} (item ${slot.stripe_subscription_item_id}) has no Stripe backing`);
        await rawSql`UPDATE slots SET status = 'cancelled', cancelled_at = NOW() WHERE id = ${slot.id}`;
        results.push(`  -> cancelled slot ${slot.id}`);
        affectedUserIds.add(slot.user_id);
      }
    }
  }

  // 5. Expire old purchase intents
  await rawSql`UPDATE purchase_intents SET status = 'expired' WHERE status = 'pending' AND expires_at < NOW()`;

  // 6. Fly orphan detection: find machines in DB that don't exist in Fly, and vice versa
  const dbMachines = await rawSql`SELECT id, fly_app_name, state FROM machines WHERE deleted_at IS NULL AND state != 'creating'`;
  for (const m of dbMachines) {
    try {
      const flyState = await fly.getMachineState(m.fly_app_name);
      if (flyState === null) {
        // Fly app doesn't exist but DB says it should
        if (m.state !== "error" && m.state !== "deleted") {
          results.push(`FLY_ORPHAN: DB machine ${m.id} (${m.fly_app_name}) state=${m.state} but Fly app not found`);
          await rawSql`UPDATE machines SET state = 'error', updated_at = NOW() WHERE id = ${m.id}`;
        }
      }
    } catch {
      // Fly API error, skip this machine
    }
  }

  // 7a. Build worker app exclusion set (workers store fly_app in metadata, not machines table)
  let workerFlyApps = new Set<string>();
  try {
    const activeWorkers = await rawSql`
      SELECT metadata->>'fly_app' as fly_app FROM worker_allocations
      WHERE status IN ('pending', 'active', 'needs_cleanup') AND metadata->>'fly_app' IS NOT NULL`;
    workerFlyApps = new Set(activeWorkers.map((w: any) => w.fly_app).filter(Boolean));
  } catch (e: any) {
    results.push(`worker app index: ${e.message}`);
  }

  // 7b. Reverse orphan detection: find Fly apps with no DB record
  const INFRA_APPS = new Set((process.env.FLY_INFRA_APPS || "").split(",").map(s => s.trim()).filter(Boolean));
  try {
    const flyApps = await fly.listOrgApps();
    const dbAppNames = new Set(dbMachines.map((m: any) => m.fly_app_name));
    const allDbApps = await rawSql`SELECT fly_app_name FROM machines`;
    for (const r of allDbApps) dbAppNames.add(r.fly_app_name);

    for (const flyApp of flyApps) {
      if (INFRA_APPS.has(flyApp)) continue;
      if (workerFlyApps.has(flyApp)) continue; // Known worker app
      if (!dbAppNames.has(flyApp)) {
        results.push(`FLY_REVERSE_ORPHAN: Fly app ${flyApp} exists but has no DB record. May need manual cleanup.`);
      }
    }
  } catch (e: any) {
    results.push(`reverse orphan scan: ${e.message}`);
  }

  // 8. Cleanup expired exchange codes
  await rawSql`DELETE FROM exchange_codes WHERE expires_at < NOW()`;

  // 9. Expire old terminal sessions
  await rawSql`UPDATE terminal_sessions SET status = 'expired' WHERE status = 'active' AND expires_at < NOW()`;

  // 10. Enforce entitlement for all users who had slot-state changes.
  for (const userId of affectedUserIds) {
    try {
      await enforceSlotCancellations(userId);
    } catch (e: any) {
      results.push(`enforce ${userId}: ${e.message}`);
    }
  }

  // 11. Expire overdue worker allocations and retry needs_cleanup workers.
  // Only marks expired/completed after destroyApp actually succeeds.
  // Failed cleanups stay as needs_cleanup for the next cycle.
  try {
    const sweepTargets = await rawSql`
      SELECT id, status, metadata FROM worker_allocations
      WHERE (status IN ('pending', 'active') AND expires_at < NOW())
         OR status = 'needs_cleanup'
      LIMIT 20`;
    for (const alloc of sweepTargets) {
      const flyApp = alloc.metadata?.fly_app;
      let cleaned = true;
      if (flyApp) {
        const result = await fly.destroyApp(flyApp).catch(() => ({ ok: false, errors: ["exception"] }));
        cleaned = result.ok;
      }
      if (cleaned) {
        const finalStatus = alloc.status === 'needs_cleanup' ? 'completed' : 'expired';
        await rawSql`UPDATE worker_allocations SET status = ${finalStatus}, completed_at = NOW()
          WHERE id = ${alloc.id}`;
        results.push(`worker ${alloc.id}: ${finalStatus}`);
      } else {
        await rawSql`UPDATE worker_allocations SET status = 'needs_cleanup'
          WHERE id = ${alloc.id} AND status != 'needs_cleanup'`;
        results.push(`worker ${alloc.id}: cleanup failed, marked needs_cleanup`);
      }
    }
  } catch (e: any) {
    results.push(`worker sweep: ${e.message}`);
  }

  return results;
}

app.post("/reconcile", async (c) => {
  // Reject unconditionally before checking the bearer token so that a missing secret
  // cannot be bypassed by omitting the Authorization header.
  if (!process.env.RECONCILE_SECRET) {
    return c.json({ error: "Reconcile not configured" }, 503);
  }
  const auth = c.req.header("Authorization") || "";
  const secret = process.env.RECONCILE_SECRET;
  const expected = `Bearer ${secret}`;
  if (auth.length !== expected.length ||
      !crypto.timingSafeEqual(Buffer.from(auth), Buffer.from(expected))) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  const results = await reconcile();
  return c.json({ ok: true, results });
});

// Background reconciler with leader election.
// Uses pg_try_advisory_lock so only one API instance runs reconciliation at a time.
const RECONCILE_LOCK_ID = 73019; // Arbitrary but fixed advisory lock ID

function startReconcileLoop() {
  const rawInterval = process.env.RECONCILE_INTERVAL_SECONDS
    || (process.env.NODE_ENV === "production" ? "60" : "0");
  const intervalSeconds = parseInt(rawInterval, 10);
  if (!Number.isFinite(intervalSeconds) || intervalSeconds <= 0) return;

  const timer = setInterval(async () => {
    try {
      // Use a transaction to pin a connection for the advisory lock.
      // pg_try_advisory_xact_lock is transaction-scoped: it automatically releases
      // when the transaction ends, and is guaranteed to lock/unlock on the same connection.
      await rawSql.begin(async (tx) => {
        const [{ acquired }] = await tx`SELECT pg_try_advisory_xact_lock(${RECONCILE_LOCK_ID}) as acquired`;
        if (!acquired) return; // Another instance is reconciling

        // reconcile() uses the pool (rawSql) for its own queries, not this transaction.
        // The transaction just holds the advisory lock as a leader-election gate.
        await reconcile();
      });
    } catch (e: any) {
      console.error("[reconcile] loop error:", e.message);
    }
  }, intervalSeconds * 1000);
  timer.unref?.();
}
startReconcileLoop();

export default app;
