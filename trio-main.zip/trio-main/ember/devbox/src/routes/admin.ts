import { Hono } from "hono";
import { eq, and, sql, desc, isNull } from "drizzle-orm";
import { nanoid } from "nanoid";
import { z } from "zod";
import crypto from "crypto";
import { db, rawSql, type Transaction } from "../connection.js";
import { users, machines, slots, billingEvents, auditLog } from "../db.js";
import { requireAuth, requireAdmin, type Env } from "../middleware.js";
import * as fly from "../fly.js";
import { lucia } from "../auth.js";

const app = new Hono<Env>();
app.use("*", requireAuth(), requireAdmin());

app.get("/stats", async (c) => {
  const [{ count: userCount }] = await db.select({ count: sql<number>`count(*)` }).from(users);
  const [{ count: machineCount }] = await db.select({ count: sql<number>`count(*)` }).from(machines).where(isNull(machines.deletedAt));
  const [{ count: activeSlots }] = await db.select({ count: sql<number>`count(*)` }).from(slots).where(eq(slots.status, "active"));
  const [{ total }] = await db.select({ total: sql<number>`COALESCE(SUM(amount_cents), 0)` }).from(billingEvents).where(eq(billingEvents.type, "charge"));
  return c.json({ users: userCount, machines: machineCount, activeSlots, totalRevenueCents: total });
});

app.get("/users", async (c) => {
  const page = Math.max(1, parseInt(c.req.query("page") || "1", 10) || 1);
  const rows = await db
    .select({
      id: users.id, email: users.email, name: users.name,
      role: users.role, status: users.status, creditsCents: users.creditsCents,
      createdAt: users.createdAt,
    })
    .from(users).orderBy(desc(users.createdAt)).limit(100).offset((page - 1) * 100);
  return c.json({ users: rows, page });
});

app.get("/users/:id", async (c) => {
  const [user] = await db
    .select({
      id: users.id, email: users.email, name: users.name,
      role: users.role, status: users.status, creditsCents: users.creditsCents,
      createdAt: users.createdAt,
    })
    .from(users).where(eq(users.id, c.req.param("id")));
  if (!user) return c.json({ error: "Not found" }, 404);

  const userMachines = await db
    .select({
      id: machines.id, name: machines.name, flyAppName: machines.flyAppName,
      flyRegion: machines.flyRegion, size: machines.size, state: machines.state,
      createdAt: machines.createdAt,
    })
    .from(machines).where(eq(machines.userId, user.id));
  const userSlots = await db.select().from(slots).where(eq(slots.userId, user.id));
  const events = await db.select().from(billingEvents)
    .where(eq(billingEvents.userId, user.id)).orderBy(desc(billingEvents.createdAt)).limit(50);
  return c.json({ user, machines: userMachines, slots: userSlots, billingEvents: events });
});

const creditSchema = z.object({
  amountCents: z.number().int().min(-100_000_00).max(100_000_00), // max $100k
  description: z.string().min(1).max(500),
});

app.post("/users/:id/credit", async (c) => {
  const parsed = creditSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  const { amountCents, description } = parsed.data;
  const userId = c.req.param("id")!;

  // Atomic: update balance + write to ledger in one transaction.
  // credit_transactions is the source of truth; users.credits_cents is the materialized balance.
  // Plain addition: if this would go negative, the CHECK constraint on credits_cents >= 0
  // (from migration 003) returns a clear error instead of silently clamping.
  try {
    await rawSql.begin(async (tx) => {
      await tx`UPDATE users SET credits_cents = credits_cents + ${amountCents} WHERE id = ${userId}`;
      const [user] = await tx`SELECT credits_cents FROM users WHERE id = ${userId}`;
      const adminId = c.get("user")?.id || "system";
      const idempotencyKey = crypto.createHash('sha256')
        .update(`admin_credit:${userId}:${amountCents}:${description}:${adminId}`)
        .digest('hex');
      await tx`INSERT INTO credit_transactions (idempotency_key, user_id, type, amount_cents, balance_after_cents, metadata)
        VALUES (${idempotencyKey}, ${userId}, 'admin_adjustment', ${amountCents},
          ${user.credits_cents}, ${JSON.stringify({ description, admin: adminId })})`;
    });
  } catch (e: any) {
    if (e.message?.includes("credits_cents") || e.message?.includes("check")) {
      return c.json({ error: "Adjustment would result in negative balance" }, 400);
    }
    throw e;
  }
  return c.json({ ok: true });
});

// ── Ban: revoke sessions, destroy machines, invalidate app sessions ──
app.post("/users/:id/ban", async (c) => {
  const userId = c.req.param("id")!;
  const admin = c.get("user");

  await db.update(users).set({ status: "banned" }).where(eq(users.id, userId));

  // Revoke API keys (prevents banned user from using /v1/* endpoints)
  await rawSql`UPDATE api_keys SET status = 'revoked' WHERE user_id = ${userId} AND status = 'active'`;

  // Unified terminal session revocation
  const { revokeAllTerminalSessionsForUser } = await import("./machines.js");
  await revokeAllTerminalSessionsForUser(userId, "ban");

  // Destroy all machines in parallel
  const userMachines = await db.select().from(machines)
    .where(and(eq(machines.userId, userId), isNull(machines.deletedAt)));

  const destroyResults = await Promise.allSettled(
    userMachines.map(async (m) => {
      const { ok, errors } = await fly.destroyApp(m.flyAppName);
      if (ok) {
        await db.update(machines).set({ state: "deleted", deletedAt: new Date(), slotId: null, updatedAt: new Date() })
          .where(eq(machines.id, m.id));
        return `${m.flyAppName}: destroyed`;
      } else {
        await db.update(machines).set({ state: "error", updatedAt: new Date() }).where(eq(machines.id, m.id));
        return `${m.flyAppName}: PARTIAL FAILURE (${errors.join("; ")})`;
      }
    })
  );

  const results = destroyResults.map((r) =>
    r.status === "fulfilled" ? r.value : `unknown: ${String(r.reason)}`
  );

  await lucia.invalidateUserSessions(userId);

  await db.insert(auditLog).values({
    id: nanoid(), userId, actorId: admin.id, action: "user.ban",
    resourceType: "user", resourceId: userId,
    details: JSON.stringify({ machineResults: results }),
  });

  return c.json({ ok: results.every(r => r.includes("destroyed")), machineResults: results });
});

app.post("/users/:id/unban", async (c) => {
  await db.update(users).set({ status: "active" }).where(eq(users.id, c.req.param("id")));
  return c.json({ ok: true });
});

export default app;
