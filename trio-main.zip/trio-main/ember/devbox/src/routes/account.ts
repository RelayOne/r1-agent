import { Hono } from "hono";
import { getCookie } from "hono/cookie";
import { eq, and, desc, isNull } from "drizzle-orm";
import { z } from "zod";
import crypto from "crypto";
import { hash } from "@node-rs/argon2";
import { nanoid } from "nanoid";
import { db, rawSql } from "../connection.js";
import { users, sessions, passwordResetTokens, emailVerificationTokens } from "../db.js";
import { lucia } from "../auth.js";
import { requireAuth, type Env } from "../middleware.js";
import { sendEmail, passwordResetEmail, emailVerificationEmail } from "../email.js";
import { revokeAllTerminalSessionsForUser } from "./machines.js";
import Stripe from "stripe";
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

const app = new Hono<Env>();
const APP_URL = process.env.APP_URL || "http://localhost:3000";

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

// ══════════════════════════════════════════════════════════════
// PASSWORD RESET
// ══════════════════════════════════════════════════════════════

const forgotSchema = z.object({ email: z.string().email() });

app.post("/forgot-password", async (c) => {
  const parsed = forgotSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Invalid email" }, 400);

  const email = parsed.data.email.trim().toLowerCase();
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);

  // Always return success (don't leak whether email exists)
  if (!user) return c.json({ ok: true });

  // Rate limit: max 3 active tokens per user
  const activeCount = await rawSql`
    SELECT count(*) as c FROM password_reset_tokens
    WHERE user_id = ${user.id} AND expires_at > NOW() AND used_at IS NULL`;
  if (parseInt(activeCount[0]?.c || "0") >= 3) return c.json({ ok: true });

  const token = crypto.randomBytes(32).toString("hex");
  const tokenId = nanoid();
  const expiresAt = new Date(Date.now() + 3600_000); // 1 hour

  await db.insert(passwordResetTokens).values({
    id: tokenId, userId: user.id, tokenHash: hashToken(token), expiresAt,
  });

  const resetUrl = `${APP_URL}/reset-password?token=${token}`;
  const sent = await sendEmail(passwordResetEmail(email, resetUrl));
  if (!sent) {
    console.error(`[account] failed to send password reset email to ${email}`);
    // Still return ok to avoid leaking user existence, but token won't arrive
  }

  return c.json({ ok: true });
});

const resetSchema = z.object({
  token: z.string().min(1),
  password: z.string().min(8).max(128),
});

app.post("/reset-password", async (c) => {
  const parsed = resetSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Invalid input" }, 400);

  const { token, password } = parsed.data;
  const tokenHash = hashToken(token);

  // Atomically find and mark the token as used
  const result = await rawSql`
    UPDATE password_reset_tokens SET used_at = NOW()
    WHERE token_hash = ${tokenHash} AND expires_at > NOW() AND used_at IS NULL
    RETURNING user_id`;

  if (!result.length) return c.json({ error: "Invalid or expired token" }, 400);

  const userId = result[0].user_id;
  const passwordHash = await hash(password);

  await db.update(users).set({ passwordHash, updatedAt: new Date() }).where(eq(users.id, userId));

  // Invalidate ALL outstanding reset tokens for this user (not just the one we consumed).
  // Without this, older emailed links remain valid until expiry.
  await rawSql`UPDATE password_reset_tokens SET used_at = NOW()
    WHERE user_id = ${userId} AND used_at IS NULL`;

  // Invalidate all sessions and terminal sessions (password changed = full logout)
  await lucia.invalidateUserSessions(userId);
  await revokeAllTerminalSessionsForUser(userId, "password_reset");

  return c.json({ ok: true });
});

// ══════════════════════════════════════════════════════════════
// EMAIL VERIFICATION
// ══════════════════════════════════════════════════════════════

app.post("/send-verification", requireAuth(), async (c) => {
  const user = c.get("user");
  const [dbUser] = await db.select().from(users).where(eq(users.id, user.id));
  if (dbUser.emailVerified) return c.json({ ok: true, already: true });

  // Rate limit: max 3 active tokens
  const activeCount = await rawSql`
    SELECT count(*) as c FROM email_verification_tokens
    WHERE user_id = ${user.id} AND expires_at > NOW() AND used_at IS NULL`;
  if (parseInt(activeCount[0]?.c || "0") >= 3) return c.json({ ok: true });

  const token = crypto.randomBytes(32).toString("hex");
  const tokenId = nanoid();
  const expiresAt = new Date(Date.now() + 86400_000); // 24 hours

  await db.insert(emailVerificationTokens).values({
    id: tokenId, userId: user.id, email: dbUser.email, tokenHash: hashToken(token), expiresAt,
  });

  const verifyUrl = `${APP_URL}/verify-email?token=${token}`;
  const sent = await sendEmail(emailVerificationEmail(dbUser.email, verifyUrl));
  if (!sent) {
    return c.json({ error: "Failed to send verification email. Contact support." }, 503);
  }

  return c.json({ ok: true });
});

app.post("/verify-email", async (c) => {
  const { token } = await c.req.json().catch(() => ({} as Record<string, unknown>));
  if (!token) return c.json({ error: "Missing token" }, 400);

  const tokenHash = hashToken(token);

  const result = await rawSql`
    UPDATE email_verification_tokens SET used_at = NOW()
    WHERE token_hash = ${tokenHash} AND expires_at > NOW() AND used_at IS NULL
    RETURNING user_id, email`;

  if (!result.length) return c.json({ error: "Invalid or expired token" }, 400);

  const { user_id, email } = result[0];

  // Only verify if the email still matches (user might have changed it)
  const [user] = await db.select().from(users).where(eq(users.id, user_id));
  if (user && user.email === email) {
    await db.update(users).set({ emailVerified: true, updatedAt: new Date() }).where(eq(users.id, user_id));
  }

  return c.json({ ok: true });
});

// ══════════════════════════════════════════════════════════════
// SESSION MANAGEMENT
// ══════════════════════════════════════════════════════════════

// List active sessions
app.get("/sessions", requireAuth(), async (c) => {
  const user = c.get("user");
  const currentSessionId = getCookie(c, lucia.sessionCookieName);

  const userSessions = await db.select({
    id: sessions.id,
    expiresAt: sessions.expiresAt,
  }).from(sessions).where(eq(sessions.userId, user.id)).orderBy(desc(sessions.expiresAt));

  return c.json({
    sessions: userSessions.map(s => ({
      id: s.id,
      expiresAt: s.expiresAt,
      current: s.id === currentSessionId,
    })),
  });
});

// Revoke a specific session
app.post("/sessions/:id/revoke", requireAuth(), async (c) => {
  const user = c.get("user");
  const sessionId = c.req.param("id");
  const currentSessionId = getCookie(c, lucia.sessionCookieName);

  if (sessionId === currentSessionId) {
    return c.json({ error: "Cannot revoke current session. Use logout instead." }, 400);
  }

  // Verify session belongs to this user
  const [session] = await db.select().from(sessions)
    .where(and(eq(sessions.id, sessionId!), eq(sessions.userId, user.id))).limit(1);
  if (!session) return c.json({ error: "Session not found" }, 404);

  await lucia.invalidateSession(sessionId!);
  return c.json({ ok: true });
});

// Revoke all other sessions (browser + terminal)
app.post("/sessions/revoke-all", requireAuth(), async (c) => {
  const user = c.get("user");
  const currentSessionId = getCookie(c, lucia.sessionCookieName);

  // Revoke all browser sessions except current
  const userSessions = await db.select({ id: sessions.id }).from(sessions)
    .where(eq(sessions.userId, user.id));
  for (const s of userSessions) {
    if (s.id !== currentSessionId) {
      await lucia.invalidateSession(s.id);
    }
  }

  // Also revoke all terminal sessions + burn exchange codes.
  // Users expect "log out other devices" to kill their other terminals too.
  await revokeAllTerminalSessionsForUser(user.id, "revoke_all_sessions");

  return c.json({ ok: true });
});

// ══════════════════════════════════════════════════════════════
// DATA EXPORT
// ══════════════════════════════════════════════════════════════

app.get("/export", requireAuth(), async (c) => {
  const user = c.get("user");

  const [profile] = await rawSql`SELECT email, name, role, created_at FROM users WHERE id = ${user.id}`;
  const billingHistory = await rawSql`SELECT type, amount_cents, description, created_at FROM billing_events WHERE user_id = ${user.id} ORDER BY created_at`;
  const machineList = await rawSql`SELECT name, fly_region, size, state, created_at FROM machines WHERE user_id = ${user.id}`;
  const slotHistory = await rawSql`SELECT size, status, created_at, cancelled_at FROM slots WHERE user_id = ${user.id}`;
  const oauthConnections = await rawSql`SELECT provider, COALESCE(created_at, NOW()) as created_at FROM oauth_accounts WHERE user_id = ${user.id}`;
  const auditEntries = await rawSql`SELECT action, resource_type, resource_id, created_at FROM audit_log WHERE user_id = ${user.id} ORDER BY created_at DESC LIMIT 100`;

  return c.json({
    exportedAt: new Date().toISOString(),
    profile,
    billing: billingHistory,
    machines: machineList,
    slots: slotHistory,
    oauthConnections,
    recentAuditLog: auditEntries,
  });
});

// ══════════════════════════════════════════════════════════════
// ACCOUNT DELETION
// ══════════════════════════════════════════════════════════════

const deleteAccountSchema = z.object({
  password: z.string().min(1),
  confirm: z.literal("DELETE MY ACCOUNT"),
});

app.post("/delete", requireAuth(), async (c) => {
  const user = c.get("user");
  const parsed = deleteAccountSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Invalid confirmation" }, 400);

  // Verify password
  const [dbUser] = await rawSql`SELECT password_hash FROM users WHERE id = ${user.id}`;
  if (!dbUser?.password_hash) return c.json({ error: "OAuth-only accounts must contact support for deletion" }, 400);

  const { verify } = await import("@node-rs/argon2");
  const valid = await verify(dbUser.password_hash, parsed.data.password);
  if (!valid) return c.json({ error: "Invalid password" }, 401);

  // 1. Destroy all machines (track failures)
  const userMachines = await rawSql`SELECT id, fly_app_name FROM machines WHERE user_id = ${user.id} AND deleted_at IS NULL`;
  const destroyFailures: string[] = [];
  for (const m of userMachines) {
    try {
      const result = await (await import("../fly.js")).destroyApp(m.fly_app_name);
      if (result.ok) {
        await rawSql`UPDATE machines SET state = 'deleted', deleted_at = NOW(), slot_id = NULL WHERE id = ${m.id}`;
      } else {
        destroyFailures.push(m.fly_app_name);
        await rawSql`UPDATE machines SET state = 'error', updated_at = NOW() WHERE id = ${m.id}`;
        console.error(`[account] deletion: failed to destroy ${m.fly_app_name}: ${result.errors.join("; ")}`);
      }
    } catch (e: any) {
      destroyFailures.push(m.fly_app_name);
      await rawSql`UPDATE machines SET state = 'error', updated_at = NOW() WHERE id = ${m.id}`;
      console.error(`[account] deletion: error destroying ${m.fly_app_name}: ${e.message}`);
    }
  }

  // 2. Cancel all Stripe subscriptions
  const [userRecord] = await rawSql`SELECT stripe_customer_id FROM users WHERE id = ${user.id}`;
  if (userRecord?.stripe_customer_id) {
    try {
      const subs = await stripe.subscriptions.list({ customer: userRecord.stripe_customer_id, limit: 100 });
      for (const sub of subs.data) {
        if (sub.status !== "canceled") {
          await stripe.subscriptions.cancel(sub.id);
        }
      }
      // Cancel all local slots
      await rawSql`UPDATE slots SET status = 'cancelled', cancelled_at = NOW() WHERE user_id = ${user.id} AND status = 'active'`;
      await rawSql`UPDATE subscriptions SET status = 'canceled', updated_at = NOW() WHERE user_id = ${user.id}`;
    } catch (e: any) {
      console.error(`[account] deletion: Stripe cancel failed: ${e.message}`);
      // Don't block deletion on Stripe failure - reconciler will catch it
    }
  }

  // 3. Invalidate all sessions
  await lucia.invalidateUserSessions(user.id);

  // 3. Revoke terminal sessions
  await revokeAllTerminalSessionsForUser(user.id, "account_deletion");

  // 4. Delete OAuth tokens + revoke API keys
  await rawSql`DELETE FROM oauth_accounts WHERE user_id = ${user.id}`;
  await rawSql`UPDATE api_keys SET status = 'revoked' WHERE user_id = ${user.id} AND status = 'active'`;

  // 5. Anonymize user record (keep for billing record FK integrity)
  // Null out stripe_customer_id so future webhooks are ignored for this user
  const anonEmail = `deleted-${crypto.createHash("sha256").update(user.id).digest("hex").slice(0, 12)}@deleted.ember.dev`;
  await rawSql`UPDATE users SET
    email = ${anonEmail}, name = NULL, password_hash = NULL, avatar_url = NULL,
    startup_script = NULL, stripe_customer_id = NULL, status = 'deleted', updated_at = NOW()
    WHERE id = ${user.id}`;

  // 6. Audit log
  await rawSql`INSERT INTO audit_log (id, user_id, actor_id, action, resource_type, resource_id, details, created_at)
    VALUES (${crypto.randomUUID()}, ${user.id}, ${user.id}, 'account_deleted', 'user', ${user.id},
    ${destroyFailures.length ? JSON.stringify({ failedMachines: destroyFailures }) : null}, NOW())`;

  return c.json({
    ok: true,
    ...(destroyFailures.length ? {
      warning: `${destroyFailures.length} machine(s) could not be destroyed and need manual cleanup`,
      failedMachines: destroyFailures,
    } : {}),
  });
});

export default app;
