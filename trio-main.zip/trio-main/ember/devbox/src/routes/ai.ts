// Ember v1 AI API - proxies LLM calls through OpenRouter with metering.
//
// This is the managed AI fallback for Stoke users who don't have
// their own Claude/Codex subscriptions. Calls route through OpenRouter
// with a markup billed to the user's Ember account.
//
// Auth: Ember API key (Bearer token).

import { Hono } from "hono";
import { z } from "zod";
import { requireApiKeyV1 } from "../v1-auth.js";
import { rawSql } from "../connection.js";
import { nanoid } from "nanoid";

const chatSchema = z.object({
  model: z.string().max(200).optional(),
  messages: z.array(z.object({
    role: z.enum(["system", "user", "assistant"]),
    content: z.string().max(200_000),
  })).min(1).max(500),
  stream: z.boolean().optional(),
});

const OPENROUTER_KEY = process.env.OPENROUTER_API_KEY || "";
const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const MARKUP_PERCENT = parseFloat(process.env.AI_MARKUP_PERCENT || "0.20");

const app = new Hono<{ Variables: { userId: string } }>();


// POST /v1/ai/chat - proxy to OpenRouter with metering
app.post("/chat", requireApiKeyV1(), async (c) => {
  if (!OPENROUTER_KEY) {
    return c.json({ error: "Managed AI not configured (OPENROUTER_API_KEY not set)" }, 503);
  }

  const userId = c.get("userId");
  const parsed = chatSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Invalid request body" }, 400);
  const { model, messages, stream } = parsed.data;

  // Spend cap: check monthly usage against entitlement
  const MONTHLY_CAP_USD = parseFloat(process.env.AI_MONTHLY_CAP_USD || "50");
  const [monthUsage] = await rawSql`SELECT COALESCE(SUM(cost_usd + markup_usd), 0)::numeric(10,4) as total
    FROM ai_usage WHERE user_id = ${userId} AND created_at > date_trunc('month', NOW())`;
  if (parseFloat(monthUsage?.total || "0") >= MONTHLY_CAP_USD) {
    return c.json({ error: "Monthly AI spend cap reached. Upgrade plan or wait for next billing cycle." }, 429);
  }

  const orRes = await fetch(OPENROUTER_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${OPENROUTER_KEY}`,
      "HTTP-Referer": "https://ember.dev",
      "X-Title": "Ember Managed AI",
    },
    body: JSON.stringify({
      model: model || "anthropic/claude-sonnet-4",
      messages,
      stream: !!stream,
    }),
  });

  if (!orRes.ok) {
    const err = await orRes.text().catch(() => "");
    console.error(`[ai] OpenRouter error ${orRes.status}:`, err);
    return c.json({ error: "AI provider error" }, 502);
  }

  if (stream) {
    const headers = new Headers({
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive",
    });
    const readable = orRes.body;
    if (!readable) return c.json({ error: "No stream body" }, 500);

    // SSE event buffering: chunks may split across arbitrary boundaries.
    // We accumulate a line buffer and parse complete SSE data lines.
    const decoder = new TextDecoder();
    let lineBuf = "";
    let lastUsage: any = null;

    const transform = new TransformStream({
      transform(chunk, controller) {
        controller.enqueue(chunk);

        // Buffer and parse complete SSE lines
        lineBuf += decoder.decode(chunk, { stream: true });
        const lines = lineBuf.split("\n");
        // Keep the last (possibly incomplete) line in the buffer
        lineBuf = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const payload = line.slice(6).trim();
          if (payload === "[DONE]") continue;
          try {
            const parsed = JSON.parse(payload);
            if (parsed.usage) {
              lastUsage = parsed.usage;
            }
          } catch {
            // Incomplete JSON in this line -- skip
          }
        }
      },
      flush() {
        // Process any remaining buffered content
        if (lineBuf.startsWith("data: ")) {
          const rawPayload = lineBuf.slice(6).trim();
          try {
            const parsed = JSON.parse(rawPayload);
            if (parsed.usage) lastUsage = parsed.usage;
          } catch (e) {
            console.error("[ai] SSE flush parse failure, raw data:", rawPayload, e);
            // Attempt to extract total_cost from partial/malformed JSON
            const costMatch = rawPayload.match(/"total_cost"\s*:\s*([\d.]+)/);
            if (costMatch) {
              const partialCost = parseFloat(costMatch[1]);
              if (!isNaN(partialCost) && partialCost > 0) {
                console.error("[ai] Recovered partial total_cost:", partialCost);
                lastUsage = lastUsage || { prompt_tokens: 0, completion_tokens: 0 };
                lastUsage.total_cost = partialCost;
              }
            }
          }
        }

        if (!lastUsage) return;
        const costUSD = lastUsage.total_cost || 0;
        const markupUSD = costUSD * MARKUP_PERCENT;
        rawSql`INSERT INTO ai_usage (id, user_id, model, input_tokens, output_tokens,
          cost_usd, markup_usd, created_at)
          VALUES (${nanoid()}, ${userId}, ${model || 'unknown'},
          ${lastUsage.prompt_tokens || 0}, ${lastUsage.completion_tokens || 0},
          ${costUSD}, ${markupUSD}, NOW())`.catch((e) => console.error("[ai] stream metering failed:", e));
      }
    });

    return new Response(readable.pipeThrough(transform), { status: 200, headers });
  }

  // Non-streaming: parse response, meter, return
  const data = await orRes.json() as any;

  // Record usage event
  const usage = data.usage || {};
  const costUSD = usage.total_cost || 0;
  const markupUSD = costUSD * MARKUP_PERCENT;
  await rawSql`INSERT INTO ai_usage (id, user_id, model, input_tokens, output_tokens,
    cost_usd, markup_usd, created_at)
    VALUES (${nanoid()}, ${userId}, ${model || 'unknown'}, ${usage.prompt_tokens || 0},
    ${usage.completion_tokens || 0}, ${costUSD}, ${markupUSD}, NOW())`.catch((e) => console.error("[ai] metering failed:", e));

  return c.json(data);
});

// GET /v1/ai/usage - get token usage summary for billing
app.get("/usage", requireApiKeyV1(), async (c) => {
  const userId = c.get("userId");
  const period = c.req.query("period") || "month"; // day, week, month
  const periodMap = new Map([["day", "1 day"], ["week", "7 days"], ["month", "30 days"]]);
  const interval = periodMap.get(period);
  if (!interval) return c.json({ error: "Invalid period. Use: day, week, month" }, 400);

  const [totals] = await rawSql`SELECT
    COALESCE(SUM(input_tokens), 0)::int as input_tokens,
    COALESCE(SUM(output_tokens), 0)::int as output_tokens,
    COALESCE(SUM(cost_usd), 0)::numeric(10,4) as cost_usd,
    COALESCE(SUM(markup_usd), 0)::numeric(10,4) as markup_usd,
    COUNT(*)::int as request_count
    FROM ai_usage WHERE user_id = ${userId} AND created_at > NOW() - ${interval}::interval`;

  return c.json({
    period,
    input_tokens: totals?.input_tokens || 0,
    output_tokens: totals?.output_tokens || 0,
    cost_usd: parseFloat(totals?.cost_usd || "0"),
    markup_usd: parseFloat(totals?.markup_usd || "0"),
    total_usd: parseFloat(totals?.cost_usd || "0") + parseFloat(totals?.markup_usd || "0"),
    request_count: totals?.request_count || 0,
  });
});

export default app;
