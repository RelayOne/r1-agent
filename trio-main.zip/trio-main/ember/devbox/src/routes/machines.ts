import { Hono, type Context } from "hono";
import { eq, and, isNull, gt, asc } from "drizzle-orm";
import { nanoid } from "nanoid";
import { db, rawSql, type Transaction } from "../connection.js";
import {
  machines, slots, users, oauthAccounts, subscriptions,
  exchangeCodes, terminalSessions, auditLog,
} from "../db.js";
import { requireAuth, type Env } from "../middleware.js";
import * as fly from "../fly.js";
import { z } from "zod";
import crypto from "crypto";
import { decryptSecret } from "../secrets.js";


function requireEnv(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}
const app = new Hono<Env>();
const API_URL = process.env.API_URL || process.env.APP_URL || "http://localhost:3000";
// Internal URL for machine-to-API calls (6PN/Flycast in production)
const INTERNAL_API_URL = process.env.INTERNAL_API_URL || API_URL;
const ACCESS_STATUSES = new Set(["active", "trialing"]);

const createSchema = z.object({
  name: z.string().min(1).max(40).regex(/^[a-zA-Z0-9-]+$/),
  machineType: z.enum(["cli", "vscode"]).default("cli"),
  size: z.enum(["performance-4x", "performance-8x", "performance-16x"]),
  region: z.enum(["sjc", "lax", "iad", "ord", "dfw", "sea", "ewr"]).default("sjc"),
  gitRepo: z.string().url().optional().or(z.literal("")),
});

// Cleanup expired exchange codes
const cleanupTimer = setInterval(async () => {
  try { await rawSql`DELETE FROM exchange_codes WHERE expires_at < NOW()`; } catch (e) { console.error("[cleanup] exchange codes:", e); }
}, 30000);
cleanupTimer.unref?.();

function getClientIp(c: any): string {
  return c.req.header("fly-client-ip") || c.req.header("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
}

// ── List machines ────────────────────────────────────────────
app.get("/", requireAuth(), async (c) => {
  const user = c.get("user");
  const after = c.req.query("after");
  const conditions = [eq(machines.userId, user.id), isNull(machines.deletedAt)];
  if (after) {
    conditions.push(gt(machines.id, after));
  }
  const rows = await db
    .select({
      id: machines.id, name: machines.name, machineType: machines.machineType,
      flyAppName: machines.flyAppName,
      flyRegion: machines.flyRegion, size: machines.size, state: machines.state,
      gitRepo: machines.gitRepo, hostnameStatus: machines.hostnameStatus, createdAt: machines.createdAt,
    })
    .from(machines)
    .where(and(...conditions))
    .orderBy(asc(machines.id))
    .limit(200);
  return c.json({ machines: rows });
});

// ── Create machine ───────────────────────────────────────────
app.post("/", requireAuth(), async (c) => {
  const user = c.get("user");
  const parsed = createSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  const { name, size, region, machineType } = parsed.data;
  const gitRepo = parsed.data.gitRepo || undefined;

  // Idempotency: if a non-deleted machine with the same (user_id, name) exists, return it
  const [existingMachine] = await rawSql`
    SELECT id, name, machine_type, fly_app_name, fly_region, size, state
    FROM machines WHERE user_id = ${user.id} AND name = ${name} AND state != 'deleted' AND deleted_at IS NULL
    LIMIT 1`;
  if (existingMachine) {
    return c.json({
      machine: {
        id: existingMachine.id, name: existingMachine.name,
        machineType: existingMachine.machine_type, flyAppName: existingMachine.fly_app_name,
        region: existingMachine.fly_region, size: existingMachine.size, state: existingMachine.state,
      },
      deduplicated: true,
    }, 200);
  }

  const machineId = nanoid();
  const flyAppName = fly.appName(fly.flyAppId());
  const machineToken = crypto.randomBytes(32).toString("hex");
  const imageDigest = requireEnv("CANONICAL_IMAGE_DIGEST");

  // GitHub clone token: prefer GitHub App (short-lived, repo-scoped), fall back to OAuth
  let gitToken: string | undefined;
  let gitTokenMethod: "app" | "oauth" | undefined;
  if (gitRepo) {
    try {
      const url = new URL(gitRepo);
      if (["github.com", "www.github.com"].includes(url.hostname)) {
        const [ghAccount] = await db.select().from(oauthAccounts)
          .where(and(eq(oauthAccounts.userId, user.id), eq(oauthAccounts.provider, "github"))).limit(1);

        let ghUsername: string | null = null;
        if (ghAccount?.accessToken) {
          try {
            const decrypted = decryptSecret(ghAccount.accessToken);
            if (decrypted) {
              const ghRes = await fetch("https://api.github.com/user", {
                headers: { Authorization: `Bearer ${decrypted}` },
              });
              if (ghRes.ok) {
                const ghUser: { login: string } = await ghRes.json();
                ghUsername = ghUser.login;
              }
            }
          } catch (e) { console.error("[create] GitHub user lookup failed:", e); }
        }

        const { getCloneToken } = await import("../github-app.js");
        const cloneResult = await getCloneToken(
          gitRepo,
          ghUsername,
          ghAccount?.accessToken ? decryptSecret(ghAccount.accessToken) : null,
        );
        if (cloneResult) {
          gitToken = cloneResult.token;
          gitTokenMethod = cloneResult.method;
        }
      }
    } catch (e) { console.error("[create] git token resolution failed:", e); }
  }

  // ── Phase 1: Short DB transaction to reserve slot + insert machine as "creating" ──
  let slotId: string;
  try {
    const txResult = await rawSql.begin(async (tx) => {
      const freeSlots = await tx`
        SELECT s.id FROM slots s
        WHERE s.user_id = ${user.id} AND s.status = 'active' AND s.size = ${size}
          AND s.id NOT IN (
            SELECT m.slot_id FROM machines m
            WHERE m.user_id = ${user.id} AND m.deleted_at IS NULL AND m.slot_id IS NOT NULL
          )
        LIMIT 1 FOR UPDATE SKIP LOCKED`;

      if (!freeSlots.length) return { needsSlot: true as const };
      const reservedSlotId = freeSlots[0].id;

      // Insert machine as "creating" with no Fly IDs yet. Transaction is short.
      await tx`INSERT INTO machines (id, user_id, slot_id, name, machine_type, fly_app_name,
        fly_region, size, state, git_repo, machine_token, hostname_status, created_at, updated_at)
        VALUES (${machineId}, ${user.id}, ${reservedSlotId}, ${name}, ${machineType}, ${flyAppName},
        ${region}, ${size}, 'creating', ${gitRepo || null},
        ${machineToken}, 'pending', NOW(), NOW())`;

      return { slotId: reservedSlotId };
    });

    if ("needsSlot" in txResult) {
      return c.json({ error: "No available slot", needsSlot: true, size }, 402);
    }
    slotId = txResult.slotId;
  } catch (e: any) {
    console.error("[create] slot reservation failed:", e);
    return c.json({ error: "Failed to reserve slot" }, 500);
  }

  // ── Phase 2: Provision Fly resources OUTSIDE the transaction ──
  // DB row exists as "creating". If this fails, we mark it "error" and cleanup.
  let flyMachineId: string | null = null;
  let flyAppCreated = false;
  try {
    const appResult = await fly.createFlyApp(flyAppName);
    if (!appResult) throw new Error("Failed to create Fly app");
    flyAppCreated = true;

    await fly.allocateIps(flyAppName);
    const certResult = await fly.provisionCustomHostname(flyAppName);
    const hostnameReady = certResult.ok;

    const flyResult = await fly.createMachine({
      flyAppName, region, size, machineType, machineToken,
      label: name, gitRepo, gitToken, imageDigest, apiUrl: INTERNAL_API_URL,
    });
    if (!flyResult?.id) throw new Error("Fly machine creation returned no ID");
    flyMachineId = flyResult.id;

    // ── Phase 3: Update machine row to final state ──
    const finalState = hostnameReady ? "running" : "creating";
    await rawSql`UPDATE machines SET
      fly_machine_id = ${flyMachineId},
      state = ${finalState},
      hostname_status = ${hostnameReady ? 'ready' : 'pending'},
      updated_at = NOW()
      WHERE id = ${machineId}`;

    // Audit log is non-critical. If this fails, the machine is still valid.
    // Do NOT let audit failure trigger the Fly cleanup path.
    try {
      await db.insert(auditLog).values({
        id: nanoid(), userId: user.id, actorId: user.id, action: "machine.create",
        resourceType: "machine", resourceId: machineId, ipAddress: getClientIp(c),
      });
    } catch (auditErr) {
      console.error("[create] audit log failed (non-fatal):", auditErr);
    }

    return c.json({
      machine: { id: machineId, name, machineType, flyAppName, region, size, state: finalState },
      hostnameReady,
    }, 201);
  } catch (e: any) {
    // Fly provisioning failed. Soft-delete the machine row and release the slot
    // so the user's slot is not permanently consumed by a failed create.
    await rawSql`UPDATE machines SET
      state = 'error', slot_id = NULL, deleted_at = NOW(), updated_at = NOW()
      WHERE id = ${machineId}`.catch((e) => console.error("[create] failed to mark machine as error:", e));

    // Only destroy the Fly app if we actually created it
    if (flyAppCreated) {
      const cleanup = await fly.destroyApp(flyAppName).catch(() => ({ ok: false, errors: ["threw"] }));
      if (!cleanup.ok) {
        console.error(`[create] ORPHANED: app=${flyAppName}, errors=${cleanup.errors.join("; ")}`);
      }
    }
    console.error("[create] Fly provisioning failed:", e);
    return c.json({ error: "Machine creation failed" }, 500);
  }
});

// ── Start machine (check entitlement) ────────────────────────
app.post("/:id/start", requireAuth(), async (c) => {
  const user = c.get("user");
  const [machine] = await db.select().from(machines)
    .where(and(eq(machines.id, c.req.param("id")!), eq(machines.userId, user.id), isNull(machines.deletedAt))).limit(1);
  if (!machine) return c.json({ error: "Not found" }, 404);

  // Check entitlement from local state
  let slotOk = false;
  if (machine.slotId) {
    const [slot] = await rawSql`SELECT s.status, sub.status as sub_status
      FROM slots s LEFT JOIN subscriptions sub ON s.subscription_id = sub.id
      WHERE s.id = ${machine.slotId}`;
    slotOk = slot?.status === "active" && (!slot.sub_status || ACCESS_STATUSES.has(slot.sub_status));
  }

  // Try rebinding if current slot is not active
  if (!slotOk) {
    const rebound = await rawSql.begin(async (tx) => {
      const free = await tx`
        SELECT s.id FROM slots s
        LEFT JOIN subscriptions sub ON s.subscription_id = sub.id
        WHERE s.user_id = ${user.id} AND s.status = 'active' AND s.size = ${machine.size}
          AND (sub.status IS NULL OR sub.status IN ('active', 'trialing'))
          AND s.id NOT IN (
            SELECT m.slot_id FROM machines m WHERE m.user_id = ${user.id} AND m.deleted_at IS NULL AND m.slot_id IS NOT NULL
          )
        LIMIT 1 FOR UPDATE SKIP LOCKED`;
      if (!free.length) return false;
      await tx`UPDATE machines SET slot_id = ${free[0].id}, updated_at = NOW() WHERE id = ${machine.id}`;
      return true;
    });
    if (!rebound) return c.json({ error: "No active slot. Add a slot in Billing first." }, 402);
  }

  const result = await fly.startMachine(machine.flyAppName, machine.flyMachineId!);
  if (!result) return c.json({ error: "Failed to start on Fly" }, 502);

  await db.update(machines).set({ state: "running", updatedAt: new Date() }).where(eq(machines.id, machine.id));
  return c.json({ ok: true });
});

// ── Stop machine ─────────────────────────────────────────────
app.post("/:id/stop", requireAuth(), async (c) => {
  const user = c.get("user");
  const [machine] = await db.select().from(machines)
    .where(and(eq(machines.id, c.req.param("id")!), eq(machines.userId, user.id), isNull(machines.deletedAt))).limit(1);
  if (!machine) return c.json({ error: "Not found" }, 404);

  // Idempotency guard: only call Fly API if the machine is actually started.
  // Concurrent stop requests or stopping an already-stopped machine become no-ops.
  if (machine.state !== "running") {
    return c.json({ ok: true, alreadyStopped: true });
  }

  const result = await fly.stopMachine(machine.flyAppName, machine.flyMachineId!);
  if (!result) return c.json({ error: "Failed to stop on Fly" }, 502);

  await db.update(machines).set({ state: "stopped", updatedAt: new Date() }).where(eq(machines.id, machine.id));
  // Revoke terminal sessions on stop
  await revokeTerminalSessionsForMachine(machine.id, "machine_stop");
  return c.json({ ok: true });
});

// ── Delete machine ───────────────────────────────────────────
app.delete("/:id", requireAuth(), async (c) => {
  const user = c.get("user");
  const [machine] = await db.select().from(machines)
    .where(and(eq(machines.id, c.req.param("id")!), eq(machines.userId, user.id), isNull(machines.deletedAt))).limit(1);
  if (!machine) return c.json({ error: "Not found" }, 404);

  // Revoke sessions first
  if (machine.machineToken) {
    await fly.revokeTerminalSessions(machine.flyAppName, machine.machineToken).catch((e) => console.error("[delete] revoke terminal sessions:", e));
  }
  await revokeTerminalSessionsForMachine(machine.id, "machine_delete");

  const { ok, errors } = await fly.destroyApp(machine.flyAppName);
  if (ok) {
    await db.update(machines).set({ state: "deleted", deletedAt: new Date(), slotId: null, updatedAt: new Date() })
      .where(eq(machines.id, machine.id));
    await db.insert(auditLog).values({
      id: nanoid(), userId: user.id, actorId: user.id, action: "machine.delete",
      resourceType: "machine", resourceId: machine.id, ipAddress: getClientIp(c),
    });
    return c.json({ ok: true });
  } else {
    // Release the slot even on failure so it isn't permanently consumed by a
    // broken machine. The user can still see the machine in "error" state.
    await db.update(machines).set({ state: "error", slotId: null, updatedAt: new Date() }).where(eq(machines.id, machine.id));
    console.error(`[delete] cleanup incomplete for ${machine.flyAppName}:`, errors);
    return c.json({ error: "Cleanup incomplete" }, 502);
  }
});

// ══════════════════════════════════════════════════════════════
// TERMINAL AUTH: POST-based exchange, session tracking
// ══════════════════════════════════════════════════════════════

// Dashboard requests a terminal session (returns exchange code)
app.post("/:id/terminal", requireAuth(), async (c) => {
  const user = c.get("user");
  const [machine] = await db.select({
    id: machines.id, flyAppName: machines.flyAppName,
    state: machines.state, hostnameStatus: machines.hostnameStatus,
    slotId: machines.slotId,
  }).from(machines)
    .where(and(eq(machines.id, c.req.param("id")!), eq(machines.userId, user.id), isNull(machines.deletedAt))).limit(1);
  if (!machine) return c.json({ error: "Not found" }, 404);
  if (machine.state !== "running") return c.json({ error: "Machine not running" }, 400);

  // Entitlement check: verify the machine's slot is still active
  if (machine.slotId) {
    const [slot] = await rawSql`SELECT status FROM slots WHERE id = ${machine.slotId}`;
    if (!slot || slot.status !== "active") {
      return c.json({ error: "Subscription slot is no longer active" }, 403);
    }
  }

  // Hard gate: hostname must be ready before terminal access
  if (machine.hostnameStatus !== "ready") {
    return c.json({ error: "Machine hostname not ready. DNS/TLS still provisioning.", hostnameStatus: machine.hostnameStatus }, 503);
  }

  // Create exchange code
  const code = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 60_000);

  // Create terminal session record
  const sessionId = nanoid();
  const sessionExpiresAt = new Date(Date.now() + 86400_000); // 24h
  await db.insert(terminalSessions).values({
    id: sessionId, machineId: machine.id, userId: user.id,
    status: "active", expiresAt: sessionExpiresAt,
  });

  // Store sessionId alongside code so verify-code can return it
  // NOTE: rawSql tagged templates can't serialize Date objects - use .toISOString()
  await rawSql`INSERT INTO exchange_codes (code, machine_id, user_id, fly_app_name, session_id, expires_at)
    VALUES (${code}, ${machine.id}, ${user.id}, ${machine.flyAppName}, ${sessionId}, ${expiresAt.toISOString()})`;

  // Return the bootstrap URL. The iframe loads /auth/init which auto-exchanges
  // the code via same-origin POST, sets the session cookie, then redirects to /
  const origin = fly.machineOrigin(machine.flyAppName);
  return c.json({
    terminalUrl: `${origin}/auth/init?code=${code}`,
    exchangeUrl: `${origin}/auth/exchange`,  // For manual/programmatic use
    code,
    sessionId,
  });
});

// Check/promote hostname readiness for a creating machine.
// Dashboard polls this. Uses checkHostnameStatus (fast GET, no ACME re-POST).
app.post("/:id/check-hostname", requireAuth(), async (c) => {
  const user = c.get("user");
  const [machine] = await db.select().from(machines)
    .where(and(eq(machines.id, c.req.param("id")!), eq(machines.userId, user.id), isNull(machines.deletedAt))).limit(1);
  if (!machine) return c.json({ error: "Not found" }, 404);

  if (machine.hostnameStatus === "ready") {
    return c.json({ ready: true, state: machine.state });
  }

  // Fast check: just reads cert status, doesn't re-request ACME
  const certResult = await fly.checkHostnameStatus(machine.flyAppName);
  if (certResult.ok) {
    // Before promoting creating -> started, verify entitlement is still valid.
    // A slot could have been cancelled while hostname was provisioning.
    let newState = machine.state;
    if (machine.state === "creating") {
      if (machine.slotId) {
        const [slot] = await rawSql`SELECT status FROM slots WHERE id = ${machine.slotId}`;
        if (!slot || slot.status !== "active") {
          // Slot was cancelled during provisioning. Try to stop the machine.
          const stopped = machine.flyMachineId
            ? await fly.stopMachine(machine.flyAppName, machine.flyMachineId).catch(() => false)
            : true;
          const finalState = stopped ? "stopped" : "needs_stop";
          await db.update(machines).set({
            hostnameStatus: "ready", state: finalState, updatedAt: new Date(),
          }).where(eq(machines.id, machine.id));
          return c.json({ ready: true, state: finalState, reason: "Slot no longer active" });
        }
      }
      newState = "running";
    }
    await db.update(machines).set({
      hostnameStatus: "ready", state: newState, updatedAt: new Date(),
    }).where(eq(machines.id, machine.id));
    return c.json({ ready: true, state: newState });
  }

  return c.json({ ready: false, state: machine.state, hostnameStatus: "pending", reason: certResult.reason });
});

// ── Upload file to machine ──────────────────────────────────
// Accepts multipart form data with a "file" field.
// Forwards raw file bytes to the machine's /internal/upload endpoint.
const MAX_UPLOAD_SIZE = 100 * 1024 * 1024; // 100MB

app.post("/:id/upload", requireAuth(), async (c) => {
  const user = c.get("user");
  const [machine] = await db.select({
    id: machines.id, flyAppName: machines.flyAppName,
    machineToken: machines.machineToken, state: machines.state,
  }).from(machines)
    .where(and(eq(machines.id, c.req.param("id")!), eq(machines.userId, user.id), isNull(machines.deletedAt))).limit(1);

  if (!machine) return c.json({ error: "Not found" }, 404);
  if (machine.state !== "running") return c.json({ error: "Machine is not running" }, 409);
  if (!machine.machineToken) return c.json({ error: "Machine has no auth token" }, 500);

  const formData = await c.req.formData();
  const file = formData.get("file");
  if (!file || !(file instanceof File)) return c.json({ error: "No file provided" }, 400);
  if (file.size > MAX_UPLOAD_SIZE) return c.json({ error: "File too large (100MB max)" }, 413);
  if (file.size === 0) return c.json({ error: "Empty file" }, 400);

  const buffer = Buffer.from(await file.arrayBuffer());
  const filename = file.name || "upload";

  const result = await fly.uploadFileToMachine(machine.flyAppName, machine.machineToken, filename, buffer);
  if (!result.ok) {
    return c.json({ error: result.error || "Upload failed" }, 502);
  }

  return c.json({ ok: true, path: result.path, size: result.size, filename });
});

// Machine's auth proxy calls this to verify an exchange code
app.post("/verify-code", async (c) => {
  const auth = c.req.header("Authorization");
  const token = auth?.replace("Bearer ", "");
  if (!token) return c.json({ ok: false }, 401);

  const [machine] = await db.select({ id: machines.id, flyAppName: machines.flyAppName })
    .from(machines).where(eq(machines.machineToken, token)).limit(1);
  if (!machine) return c.json({ ok: false }, 401);

  const { code } = await c.req.json().catch(() => ({} as Record<string, unknown>));
  if (!code) return c.json({ ok: false }, 400);

  // Atomically consume the code, but also validate the associated session
  // and user are still in good standing. This closes the window where a
  // pre-issued code could mint a fresh cookie after logout/ban/password-reset.
  const result = await rawSql`
    UPDATE exchange_codes SET consumed_at = NOW()
    WHERE code = ${code} AND fly_app_name = ${machine.flyAppName}
      AND expires_at > NOW() AND consumed_at IS NULL
    RETURNING code, user_id, machine_id, session_id`;

  if (!result.length) return c.json({ ok: false }, 401);

  const { user_id, machine_id, session_id } = result[0];

  // Validate terminal session is still active and not expired
  if (session_id) {
    const [session] = await rawSql`
      SELECT status, expires_at FROM terminal_sessions
      WHERE id = ${session_id}`;
    if (!session || session.status !== "active" || new Date(session.expires_at) < new Date()) {
      return c.json({ ok: false, error: "Session revoked or expired" }, 401);
    }
  }

  // Validate user is still active (not banned)
  const [user] = await rawSql`SELECT status FROM users WHERE id = ${user_id}`;
  if (!user || user.status !== "active") {
    return c.json({ ok: false, error: "Account suspended" }, 403);
  }

  return c.json({
    ok: true,
    userId: user_id,
    machineId: machine_id,
    sessionId: session_id,
  });
});

// ── Revocation helpers ───────────────────────────────────────

// Revoke all terminal sessions for a machine
async function revokeTerminalSessionsForMachine(machineId: string, reason: string) {
  await rawSql`UPDATE terminal_sessions SET status = 'revoked', revoked_at = NOW(), revoke_reason = ${reason}
    WHERE machine_id = ${machineId} AND status = 'active'`;
}

// Revoke all terminal sessions for a user (logout, ban, password reset)
export async function revokeAllTerminalSessionsForUser(userId: string, reason: string) {
  await rawSql`UPDATE terminal_sessions SET status = 'revoked', revoked_at = NOW(), revoke_reason = ${reason}
    WHERE user_id = ${userId} AND status = 'active'`;

  // Burn all outstanding exchange codes so pre-issued but unconsumed codes
  // cannot mint a fresh cookie after logout/ban/password-reset
  await rawSql`UPDATE exchange_codes SET consumed_at = NOW()
    WHERE user_id = ${userId} AND consumed_at IS NULL AND expires_at > NOW()`;

  // Also call the auth proxy on each running machine
  const userMachines = await db.select({ flyAppName: machines.flyAppName, machineToken: machines.machineToken })
    .from(machines)
    .where(and(eq(machines.userId, userId), eq(machines.state, "running"), isNull(machines.deletedAt)));

  await Promise.allSettled(
    userMachines
      .filter(m => !!m.machineToken)
      .map(m => fly.revokeTerminalSessions(m.flyAppName, m.machineToken!))
  );
}

// ── Startup script (machine-to-API, Bearer auth) ─────────────
// Machine startup script endpoint. Called by start.sh with FLY_APP_NAME as :id.
// Auth is via Bearer machine token. We validate the :id matches the authenticated machine.
app.get("/:id/startup", async (c) => {
  const auth = c.req.header("Authorization");
  const token = auth?.replace("Bearer ", "");
  if (!token) return c.text("", 401);

  const [machine] = await db.select({ id: machines.id, flyAppName: machines.flyAppName, userId: machines.userId })
    .from(machines).where(eq(machines.machineToken, token)).limit(1);
  if (!machine) return c.text("", 401);

  // Validate :id matches either the DB machine id or the flyAppName (start.sh sends FLY_APP_NAME)
  const paramId = c.req.param("id")!;
  if (paramId !== machine.id && paramId !== machine.flyAppName) {
    return c.text("", 403);
  }

  const [user] = await db.select({ startupScript: users.startupScript }).from(users).where(eq(users.id, machine.userId));
  return c.text(user?.startupScript || "# no startup script configured\n");
});

// ── Stoke status (proxied from machine) ─────────────────────
// Dashboard polls this to display Stoke progress pane.
app.get("/:id/stoke-status", requireAuth(), async (c) => {
  const user = c.get("user");
  const [machine] = await db.select({
    id: machines.id, flyAppName: machines.flyAppName,
    machineToken: machines.machineToken, state: machines.state,
  }).from(machines)
    .where(and(eq(machines.id, c.req.param("id")!), eq(machines.userId, user.id), isNull(machines.deletedAt))).limit(1);

  if (!machine) return c.json({ error: "Not found" }, 404);
  if (machine.state !== "running") return c.json({ active: false });
  if (!machine.machineToken) return c.json({ active: false });

  // Proxy to machine's /internal/stoke-status
  const origins = [
    `http://${machine.flyAppName}.internal:8080`,
    fly.machineOrigin(machine.flyAppName),
  ];
  for (const origin of origins) {
    try {
      const res = await fetch(`${origin}/internal/stoke-status`, {
        headers: { Authorization: `Bearer ${machine.machineToken}` },
        signal: AbortSignal.timeout(5000),
      });
      if (res.ok) {
        const data = await res.json();
        return c.json(data);
      }
    } catch {
      // try next origin
    }
  }
  return c.json({ active: false, error: "Could not reach machine" });
});

export default app;
