import { Hono } from "hono";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "../connection.js";
import { users } from "../db.js";
import { requireAuth, type Env } from "../middleware.js";

const profileSchema = z.object({
  name: z.string().min(1).max(100).trim(),
});

const startupSchema = z.object({
  script: z.string().max(50_000), // 50KB max
});

const app = new Hono<Env>();
app.use("*", requireAuth());

app.get("/profile", async (c) => {
  const user = c.get("user");
  const [row] = await db.select().from(users).where(eq(users.id, user.id));
  return c.json({ email: row.email, name: row.name, avatarUrl: row.avatarUrl });
});

app.put("/profile", async (c) => {
  const user = c.get("user");
  const parsed = profileSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  await db.update(users).set({ name: parsed.data.name, updatedAt: new Date() }).where(eq(users.id, user.id));
  return c.json({ ok: true });
});

app.get("/startup", async (c) => {
  const user = c.get("user");
  const [row] = await db.select().from(users).where(eq(users.id, user.id));
  return c.json({ script: row.startupScript || "" });
});

app.put("/startup", async (c) => {
  const user = c.get("user");
  const parsed = startupSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  await db.update(users).set({ startupScript: parsed.data.script, updatedAt: new Date() }).where(eq(users.id, user.id));
  return c.json({ ok: true });
});

// ── Dashboard layout config ──────────────────────────────────

const layoutSchema = z.object({
  // Grid layout: array of pane definitions
  panes: z.array(z.object({
    id: z.string(),
    machineId: z.string().nullable(),   // which machine is shown here (null = empty slot)
    col: z.number().int().min(1),       // grid-column-start
    row: z.number().int().min(1),       // grid-row-start
    colSpan: z.number().int().min(1).max(4).default(1),
    rowSpan: z.number().int().min(1).max(4).default(1),
  })).max(20),
  columns: z.number().int().min(1).max(6).default(2),
  rows: z.number().int().min(1).max(6).default(2),
  sidebarCollapsed: z.boolean().default(false),
}).strict();

app.get("/layout", async (c) => {
  const user = c.get("user");
  const [row] = await db.select().from(users).where(eq(users.id, user.id));
  if (!row.layoutConfig) return c.json({ layout: null });
  try {
    return c.json({ layout: JSON.parse(row.layoutConfig) });
  } catch {
    return c.json({ layout: null });
  }
});

app.put("/layout", async (c) => {
  const user = c.get("user");
  const parsed = layoutSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  const config = JSON.stringify(parsed.data);
  if (config.length > 100_000) return c.json({ error: "Layout config too large" }, 400);
  await db.update(users).set({ layoutConfig: config, updatedAt: new Date() }).where(eq(users.id, user.id));
  return c.json({ ok: true });
});

export default app;
