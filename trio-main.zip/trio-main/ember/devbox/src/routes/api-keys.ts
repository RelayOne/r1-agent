// API key lifecycle routes: create, list, revoke.
// Mounted under /api/account (browser-session auth).

import { Hono } from "hono";
import { z } from "zod";
import crypto from "crypto";
import { nanoid } from "nanoid";
import { rawSql } from "../connection.js";
import { requireAuth, type Env } from "../middleware.js";

const createKeySchema = z.object({
  label: z.string().max(100).default("default"),
});

const app = new Hono<Env>();

// GET /api/account/api-keys - list user's API keys (no secrets)
app.get("/api-keys", requireAuth(), async (c) => {
  const user = c.get("user");

  const keys = await rawSql`SELECT id, label, status, last_used_at, created_at
    FROM api_keys WHERE user_id = ${user.id}
    ORDER BY created_at DESC`;
  return c.json(keys);
});

// POST /api/account/api-keys - create a new API key
// Returns the plaintext key ONCE. Only the hash is stored.
app.post("/api-keys", requireAuth(), async (c) => {
  const user = c.get("user");
  const parsed = createKeySchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Invalid input" }, 400);
  const label = parsed.data.label;

  // Generate a secure random key with ember_ prefix
  const plaintext = `ember_${crypto.randomBytes(32).toString("hex")}`;
  const keyHash = crypto.createHash("sha256").update(plaintext).digest("hex");
  const id = nanoid();

  await rawSql`INSERT INTO api_keys (id, user_id, key_hash, label, status, created_at)
    VALUES (${id}, ${user.id}, ${keyHash}, ${label}, 'active', NOW())`;

  return c.json({
    id,
    key: plaintext,
    label,
    message: "Save this key now. It will not be shown again.",
  }, 201);
});

// POST /api/account/api-keys/:id/revoke - revoke a key
app.post("/api-keys/:id/revoke", requireAuth(), async (c) => {
  const user = c.get("user");
  const keyId = c.req.param("id")!;

  const [key] = await rawSql`SELECT id FROM api_keys
    WHERE id = ${keyId} AND user_id = ${user.id}`;
  if (!key) return c.json({ error: "Not found" }, 404);

  await rawSql`UPDATE api_keys SET status = 'revoked' WHERE id = ${keyId}`;
  return c.json({ ok: true });
});

export default app;
