import { Hono } from "hono";
import { setCookie, getCookie } from "hono/cookie";
import { generateIdFromEntropySize } from "lucia";
import { hash, verify } from "@node-rs/argon2";
import { generateState, generateCodeVerifier } from "arctic";
import { eq, and, isNull } from "drizzle-orm";
import { z } from "zod";
import { db } from "../connection.js";
import { users, oauthAccounts, machines, auditLog } from "../db.js";
import { lucia, github, google } from "../auth.js";
import * as fly from "../fly.js";
import { encryptSecret } from "../secrets.js";
import { type Env } from "../middleware.js";
import { nanoid } from "nanoid";

// ── GitHub / Google API response types (EMBER-058) ──────────
interface GitHubUser {
  id: number;
  login: string;
  name: string | null;
  avatar_url: string;
}

interface GitHubEmail {
  email: string;
  primary: boolean;
  verified: boolean;
}

interface GoogleUser {
  sub: string;
  email: string;
  email_verified: boolean;
  name: string;
  picture: string;
}

const app = new Hono<Env>();
const isProd = process.env.NODE_ENV === "production";
const cookieOpts = { path: "/", httpOnly: true, secure: isProd, maxAge: 600, sameSite: "lax" as const };

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

// ── Register ─────────────────────────────────────────────────
const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(128),
  name: z.string().min(1),
});

app.post("/register", async (c) => {
  const body = registerSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!body.success) return c.json({ error: body.error.flatten() }, 400);

  const email = normalizeEmail(body.data.email);
  const { password, name } = body.data;

  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing.length) return c.json({ error: "Email already registered" }, 409);

  const userId = generateIdFromEntropySize(10);
  const passwordHash = await hash(password);

  await db.insert(users).values({ id: userId, email, passwordHash, name });

  const session = await lucia.createSession(userId, {});
  const cookie = lucia.createSessionCookie(session.id);
  setCookie(c, cookie.name, cookie.value, cookie.attributes as any);

  return c.json({ ok: true });
});

// ── Login ────────────────────────────────────────────────────
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1).max(128),
});

app.post("/login", async (c) => {
  const parsed = loginSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Invalid input" }, 400);

  const email = normalizeEmail(parsed.data.email);
  const { password } = parsed.data;
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user || !user.passwordHash) return c.json({ error: "Invalid credentials" }, 401);

  const valid = await verify(user.passwordHash, password);
  if (!valid) return c.json({ error: "Invalid credentials" }, 401);
  if (user.status === "banned") return c.json({ error: "Account suspended" }, 403);

  const session = await lucia.createSession(user.id, {});
  const cookie = lucia.createSessionCookie(session.id);
  setCookie(c, cookie.name, cookie.value, cookie.attributes as any);

  return c.json({ ok: true });
});

// ── Logout ───────────────────────────────────────────────────
app.post("/logout", async (c) => {
  const sessionId = getCookie(c, lucia.sessionCookieName);
  if (sessionId) {
    const { user } = await lucia.validateSession(sessionId);
    if (user) {
      // Unified terminal session revocation
      const { revokeAllTerminalSessionsForUser } = await import("./machines.js");
      await revokeAllTerminalSessionsForUser(user.id, "logout");

      await db.insert(auditLog).values({
        id: nanoid(), userId: user.id, actorId: user.id,
        action: "user.logout", resourceType: "user", resourceId: user.id,
      });
    }
    await lucia.invalidateSession(sessionId);
  }
  const blank = lucia.createBlankSessionCookie();
  setCookie(c, blank.name, blank.value, blank.attributes as any);
  return c.json({ ok: true });
});

// ── Me ───────────────────────────────────────────────────────
app.get("/me", async (c) => {
  const sessionId = getCookie(c, lucia.sessionCookieName);
  if (!sessionId) return c.json({ user: null });
  const { user, session } = await lucia.validateSession(sessionId);
  if (!user) return c.json({ user: null });
  if (user.status === "banned") {
    await lucia.invalidateSession(session!.id);
    const blank = lucia.createBlankSessionCookie();
    setCookie(c, blank.name, blank.value, blank.attributes as any);
    return c.json({ user: null });
  }
  return c.json({ user });
});

// ── GitHub OAuth (login: minimal scopes) ─────────────────────
app.get("/github", async (c) => {
  const state = generateState();
  // Login only needs email. Repo access is a separate flow via /api/github/connect
  const url = github.createAuthorizationURL(state, ["user:email"]);
  setCookie(c, "github_oauth_state", state, cookieOpts);
  return c.redirect(url.toString());
});

app.get("/github/callback", async (c) => {
  const code = c.req.query("code");
  const state = c.req.query("state");
  const storedState = getCookie(c, "github_oauth_state");

  if (!code || !state || state !== storedState) return c.redirect("/login?error=oauth_failed");

  try {
    const tokens = await github.validateAuthorizationCode(code);
    const accessToken = tokens.accessToken();

    const ghRes = await fetch("https://api.github.com/user", {
      headers: { Authorization: `Bearer ${accessToken}` },
      signal: AbortSignal.timeout(10000),
    });
    const ghUser: GitHubUser = await ghRes.json();

    // Get verified primary email
    const emailRes = await fetch("https://api.github.com/user/emails", {
      headers: { Authorization: `Bearer ${accessToken}` },
      signal: AbortSignal.timeout(10000),
    });
    const emails: GitHubEmail[] = await emailRes.json();
    const verified = emails.find((e) => e.primary && e.verified);
    if (!verified) return c.redirect("/login?error=email_not_verified");

    const email = normalizeEmail(verified.email);
    const ghId = String(ghUser.id);

    // Check for existing OAuth link
    const [existing] = await db
      .select()
      .from(oauthAccounts)
      .where(and(eq(oauthAccounts.provider, "github"), eq(oauthAccounts.providerId, ghId)))
      .limit(1);

    let userId: string;

    if (existing) {
      userId = existing.userId;
      // Don't overwrite accessToken during login - the login flow only has
      // user:email scope. If the user previously connected with repo scope
      // via /api/github/connect, we'd downgrade their token.
      // Only update if they don't have a token at all.
      if (!existing.accessToken) {
        await db
          .update(oauthAccounts)
          .set({ accessToken: encryptSecret(accessToken) })
          .where(and(eq(oauthAccounts.provider, "github"), eq(oauthAccounts.providerId, ghId)));
      }
    } else {
      // No oauth_account found for this GitHub ID.
      // Link to existing user by verified email, or create new user.
      const [emailUser] = await db.select().from(users).where(eq(users.email, email)).limit(1);

      if (emailUser) {
        userId = emailUser.id;
      } else {
        userId = generateIdFromEntropySize(10);
        await db.insert(users).values({
          id: userId,
          email,
          name: ghUser.name || ghUser.login,
          avatarUrl: ghUser.avatar_url,
        });
      }

      // Check if user already has a GitHub oauth_account (e.g., from connect flow
      // with a different GitHub identity). If so, update rather than insert to
      // prevent accumulating multiple GitHub rows per user.
      const [existingForUser] = await db
        .select()
        .from(oauthAccounts)
        .where(and(eq(oauthAccounts.userId, userId), eq(oauthAccounts.provider, "github")))
        .limit(1);

      if (existingForUser) {
        // Update providerId to match current GitHub identity.
        // Don't overwrite accessToken if it already has a broader-scoped one.
        const updates: any = { providerId: ghId };
        if (!existingForUser.accessToken) updates.accessToken = encryptSecret(accessToken);
        await db.update(oauthAccounts).set(updates)
          .where(and(eq(oauthAccounts.userId, userId), eq(oauthAccounts.provider, "github")));
      } else {
        await db.insert(oauthAccounts).values({
          provider: "github",
          providerId: ghId,
          userId,
          accessToken: encryptSecret(accessToken),
        });
      }
    }

    const session = await lucia.createSession(userId, {});
    const cookie = lucia.createSessionCookie(session.id);
    setCookie(c, cookie.name, cookie.value, cookie.attributes as any);

    return c.redirect("/");
  } catch (e) {
    console.error("GitHub OAuth error:", e);
    return c.redirect("/login?error=oauth_failed");
  }
});

// ── Google OAuth ─────────────────────────────────────────────
app.get("/google", async (c) => {
  const state = generateState();
  const codeVerifier = generateCodeVerifier();
  const url = google.createAuthorizationURL(state, codeVerifier, ["openid", "email", "profile"]);
  setCookie(c, "google_oauth_state", state, cookieOpts);
  setCookie(c, "google_code_verifier", codeVerifier, cookieOpts);
  return c.redirect(url.toString());
});

app.get("/google/callback", async (c) => {
  const code = c.req.query("code");
  const state = c.req.query("state");
  const storedState = getCookie(c, "google_oauth_state");
  const codeVerifier = getCookie(c, "google_code_verifier");

  if (!code || !state || state !== storedState || !codeVerifier) return c.redirect("/login?error=oauth_failed");

  try {
    const tokens = await google.validateAuthorizationCode(code, codeVerifier);
    const accessToken = tokens.accessToken();

    const res = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    const gUser: GoogleUser = await res.json();

    // Require verified email
    if (!gUser.email_verified) return c.redirect("/login?error=email_not_verified");

    const email = normalizeEmail(gUser.email);

    const [existing] = await db
      .select()
      .from(oauthAccounts)
      .where(and(eq(oauthAccounts.provider, "google"), eq(oauthAccounts.providerId, gUser.sub)))
      .limit(1);

    let userId: string;

    if (existing) {
      userId = existing.userId;
    } else {
      const [emailUser] = await db.select().from(users).where(eq(users.email, email)).limit(1);

      if (emailUser) {
        userId = emailUser.id;
      } else {
        userId = generateIdFromEntropySize(10);
        await db.insert(users).values({
          id: userId,
          email,
          name: gUser.name,
          avatarUrl: gUser.picture,
        });
      }

      await db.insert(oauthAccounts).values({
        provider: "google",
        providerId: gUser.sub,
        userId,
      });
    }

    const session = await lucia.createSession(userId, {});
    const cookie = lucia.createSessionCookie(session.id);
    setCookie(c, cookie.name, cookie.value, cookie.attributes as any);

    return c.redirect("/");
  } catch (e) {
    console.error("Google OAuth error:", e);
    return c.redirect("/login?error=oauth_failed");
  }
});

export default app;
