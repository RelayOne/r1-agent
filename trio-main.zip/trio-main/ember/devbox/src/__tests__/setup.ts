// Test setup: connects to a test database, runs migrations, provides cleanup.
// Requires TEST_DATABASE_URL env var (defaults to postgres://root@127.0.0.1:5432/ember_test).

import { beforeAll, afterAll, afterEach } from "vitest";
import postgres from "postgres";
import { drizzle } from "drizzle-orm/postgres-js";
import { migrate } from "drizzle-orm/postgres-js/migrator";
import { readFileSync, readdirSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import * as schema from "../db.js";

// Resolve the devbox directory so relative paths work regardless of CWD
const __dirname = dirname(fileURLToPath(import.meta.url));

const TEST_DB_URL = process.env.TEST_DATABASE_URL || "postgres://root@127.0.0.1:5432/ember_test";

export const testSql = postgres(TEST_DB_URL);
export const testDb = drizzle(testSql, { schema });

// Override the connection module's exports for tests
process.env.DATABASE_URL = TEST_DB_URL;

beforeAll(async () => {
  // Run Drizzle migrations
  const devboxDir = join(__dirname, "..", "..");
  await migrate(testDb, { migrationsFolder: join(devboxDir, "drizzle") });

  // Run SQL migrations (credit ledger, etc.)
  const sqlDir = join(devboxDir, "migrations");
  try {
    const files = readdirSync(sqlDir).filter(f => f.endsWith(".sql")).sort();
    for (const file of files) {
      const sql = readFileSync(join(sqlDir, file), "utf8");
      await testSql.unsafe(sql);
    }
  } catch (e: any) {
    if (e.code !== "ENOENT") throw e;
  }
});

afterEach(async () => {
  // Truncate all tables (order matters for FKs)
  await testSql`SET session_replication_role = replica`; // Disable FK checks
  for (const table of [
    "credit_transactions", "worker_allocations", "processed_stripe_events",
    "stoke_sessions", "ai_usage", "api_keys",
    "audit_log", "billing_events", "terminal_sessions", "exchange_codes",
    "purchase_intents", "password_reset_tokens", "email_verification_tokens",
    "machines", "slots", "subscriptions", "oauth_accounts", "sessions", "users",
  ]) {
    await testSql`TRUNCATE TABLE ${testSql(table)} CASCADE`;
  }
  await testSql`SET session_replication_role = DEFAULT`;
});

afterAll(async () => {
  await testSql.end();
});

// Test helpers
export async function createTestUser(overrides: Partial<typeof schema.users.$inferInsert> = {}) {
  const id = crypto.randomUUID().replace(/-/g, "").slice(0, 20);
  const defaults = {
    id,
    email: `test-${id}@example.com`,
    name: "Test User",
    role: "user" as const,
    status: "active" as const,
  };
  const values = { ...defaults, ...overrides };
  await testSql`INSERT INTO users (id, email, name, role, status, created_at, updated_at)
    VALUES (${values.id}, ${values.email}, ${values.name}, ${values.role}, ${values.status}, NOW(), NOW())`;
  return values;
}

export async function createTestSubscription(userId: string, stripeSubId: string, status = "active") {
  const id = crypto.randomUUID().replace(/-/g, "").slice(0, 20);
  await testSql`INSERT INTO subscriptions (id, user_id, stripe_subscription_id, status, created_at, updated_at)
    VALUES (${id}, ${userId}, ${stripeSubId}, ${status}, NOW(), NOW())`;
  return { id, stripeSubId };
}

export async function createTestSlot(userId: string, subscriptionId: string, opts: {
  size?: string; status?: string; stripeItemId?: string;
} = {}) {
  const id = crypto.randomUUID().replace(/-/g, "").slice(0, 20);
  const size = opts.size || "performance-8x";
  const status = opts.status || "active";
  const itemId = opts.stripeItemId || `si_test_${id}`;
  await testSql`INSERT INTO slots (id, user_id, subscription_id, stripe_subscription_item_id, size, price_cents, status, created_at)
    VALUES (${id}, ${userId}, ${subscriptionId}, ${itemId}, ${size}, 17400, ${status}, NOW())`;
  return { id, stripeItemId: itemId };
}

export async function createTestMachine(userId: string, slotId: string, opts: {
  state?: string; flyAppName?: string;
} = {}) {
  const id = crypto.randomUUID().replace(/-/g, "").slice(0, 20);
  const flyAppName = opts.flyAppName || `ember-test-${id.slice(0, 8)}`;
  const state = opts.state || "running";
  await testSql`INSERT INTO machines (id, user_id, slot_id, name, fly_app_name, fly_machine_id, size, state, created_at, updated_at)
    VALUES (${id}, ${userId}, ${slotId}, 'test', ${flyAppName}, 'fm_test', 'performance-8x', ${state}, NOW(), NOW())`;
  return { id, flyAppName };
}
