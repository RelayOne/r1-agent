import { describe, it, expect } from "vitest";
import { testSql, createTestUser, createTestSubscription, createTestSlot, createTestMachine } from "./setup.js";

describe("Billing: Subscription Sync", () => {
  it("creates a subscription record from stripe data", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_test_123", "active");

    const [row] = await testSql`SELECT * FROM subscriptions WHERE id = ${sub.id}`;
    expect(row.status).toBe("active");
    expect(row.stripe_subscription_id).toBe("sub_test_123");
    expect(row.user_id).toBe(user.id);
  });

  it("unique constraint prevents duplicate stripe subscription IDs", async () => {
    const user = await createTestUser();
    await createTestSubscription(user.id, "sub_dup_1", "active");

    await expect(
      createTestSubscription(user.id, "sub_dup_1", "active")
    ).rejects.toThrow();
  });
});

describe("Billing: Slot Lifecycle", () => {
  it("creates an active slot linked to subscription", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_slot_1");
    const slot = await createTestSlot(user.id, sub.id);

    const [row] = await testSql`SELECT * FROM slots WHERE id = ${slot.id}`;
    expect(row.status).toBe("active");
    expect(row.subscription_id).toBe(sub.id);
  });

  it("unique constraint on stripe_subscription_item_id prevents duplicate slots", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_slot_dup");
    await createTestSlot(user.id, sub.id, { stripeItemId: "si_same" });

    await expect(
      createTestSlot(user.id, sub.id, { stripeItemId: "si_same" })
    ).rejects.toThrow();
  });

  it("cancelled slot can be reactivated", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_reactivate");
    const slot = await createTestSlot(user.id, sub.id, { status: "cancelled" });

    await testSql`UPDATE slots SET status = 'active', cancelled_at = NULL WHERE id = ${slot.id}`;
    const [row] = await testSql`SELECT status FROM slots WHERE id = ${slot.id}`;
    expect(row.status).toBe("active");
  });

  it("slot reactivation finds by stripe_subscription_item_id", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_react_2");
    const slot = await createTestSlot(user.id, sub.id, { status: "cancelled", stripeItemId: "si_react" });

    // Simulate invoice.paid reactivation logic
    const result = await testSql`
      UPDATE slots SET status = 'active', cancelled_at = NULL
      WHERE stripe_subscription_item_id = 'si_react' AND status = 'cancelled'
      RETURNING id`;
    expect(result.length).toBe(1);
    expect(result[0].id).toBe(slot.id);
  });
});

describe("Billing: Slot-Machine Binding", () => {
  it("machine.slot_id unique constraint prevents double-bind", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_bind");
    const slot = await createTestSlot(user.id, sub.id);
    await createTestMachine(user.id, slot.id);

    // Second machine on same slot should fail
    await expect(
      createTestMachine(user.id, slot.id)
    ).rejects.toThrow();
  });

  it("slot rebinding works after machine deletion", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_rebind");
    const slot = await createTestSlot(user.id, sub.id);
    const machine = await createTestMachine(user.id, slot.id);

    // Delete machine (free the slot)
    await testSql`UPDATE machines SET state = 'deleted', deleted_at = NOW(), slot_id = NULL WHERE id = ${machine.id}`;

    // New machine can bind to the same slot
    const machine2 = await createTestMachine(user.id, slot.id);
    const [row] = await testSql`SELECT slot_id FROM machines WHERE id = ${machine2.id}`;
    expect(row.slot_id).toBe(slot.id);
  });
});

describe("Billing: Cancellation + Recovery", () => {
  it("cancelling subscription cancels all its slots", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_cancel_1");
    const slot1 = await createTestSlot(user.id, sub.id, { stripeItemId: "si_c1" });
    const slot2 = await createTestSlot(user.id, sub.id, { stripeItemId: "si_c2" });

    // Cancel all slots for this subscription
    await testSql`UPDATE slots SET status = 'cancelled', cancelled_at = NOW()
      WHERE subscription_id = ${sub.id} AND status = 'active'`;

    const rows = await testSql`SELECT status FROM slots WHERE subscription_id = ${sub.id}`;
    expect(rows.every((r: any) => r.status === "cancelled")).toBe(true);
  });

  it("cancellation of one subscription does not affect another", async () => {
    const user = await createTestUser();
    const sub1 = await createTestSubscription(user.id, "sub_multi_1");
    const sub2 = await createTestSubscription(user.id, "sub_multi_2");
    const slot1 = await createTestSlot(user.id, sub1.id, { stripeItemId: "si_m1" });
    const slot2 = await createTestSlot(user.id, sub2.id, { stripeItemId: "si_m2" });

    // Cancel sub1 only
    await testSql`UPDATE slots SET status = 'cancelled' WHERE subscription_id = ${sub1.id}`;

    const [s1] = await testSql`SELECT status FROM slots WHERE id = ${slot1.id}`;
    const [s2] = await testSql`SELECT status FROM slots WHERE id = ${slot2.id}`;
    expect(s1.status).toBe("cancelled");
    expect(s2.status).toBe("active");
  });

  it("needs_stop machine is cleared when slot is reactivated", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_needs_stop");
    const slot = await createTestSlot(user.id, sub.id, { status: "cancelled" });
    const machine = await createTestMachine(user.id, slot.id, { state: "needs_stop" });

    // Reactivate slot (payment recovered)
    await testSql`UPDATE slots SET status = 'active', cancelled_at = NULL WHERE id = ${slot.id}`;

    // Reconciler logic: check slot status, clear needs_stop if active
    const [s] = await testSql`SELECT status FROM slots WHERE id = ${slot.id}`;
    if (s.status === "active") {
      await testSql`UPDATE machines SET state = 'stopped' WHERE id = ${machine.id}`;
    }

    const [m] = await testSql`SELECT state FROM machines WHERE id = ${machine.id}`;
    expect(m.state).toBe("stopped"); // Cleared, not stuck in needs_stop
  });
});

describe("Billing: Webhook Idempotency", () => {
  it("duplicate stripe_event_id is rejected by unique constraint", async () => {
    const user = await createTestUser();

    await testSql`INSERT INTO billing_events (id, user_id, type, amount_cents, stripe_event_id, created_at)
      VALUES ('be1', ${user.id}, 'charge', 1000, 'evt_test_1', NOW())`;

    await expect(
      testSql`INSERT INTO billing_events (id, user_id, type, amount_cents, stripe_event_id, created_at)
        VALUES ('be2', ${user.id}, 'charge', 1000, 'evt_test_1', NOW())`
    ).rejects.toThrow();
  });

  it("purchase intents prevent duplicate Stripe operations", async () => {
    const user = await createTestUser();

    await testSql`INSERT INTO purchase_intents (id, user_id, type, size, status, expires_at, created_at)
      VALUES ('pi_1', ${user.id}, 'add_slot', 'performance-8x', 'pending', NOW() + interval '1 hour', NOW())`;

    // Same intent ID should fail
    await expect(
      testSql`INSERT INTO purchase_intents (id, user_id, type, size, status, expires_at, created_at)
        VALUES ('pi_1', ${user.id}, 'add_slot', 'performance-8x', 'pending', NOW() + interval '1 hour', NOW())`
    ).rejects.toThrow();
  });
});
