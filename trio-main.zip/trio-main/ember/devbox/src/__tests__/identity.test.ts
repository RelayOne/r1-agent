import { describe, it, expect } from "vitest";
import { testSql, createTestUser } from "./setup.js";
import crypto from "crypto";

describe("GitHub: Identity Linking", () => {
  it("one user can have one GitHub oauth_account", async () => {
    const user = await createTestUser();

    await testSql`INSERT INTO oauth_accounts (provider, provider_id, user_id)
      VALUES ('github', 'gh_123', ${user.id})`;

    // Second GitHub account for same user should fail (unique on user_id + provider)
    await expect(
      testSql`INSERT INTO oauth_accounts (provider, provider_id, user_id)
        VALUES ('github', 'gh_456', ${user.id})`
    ).rejects.toThrow();
  });

  it("same GitHub ID cannot be linked to two users", async () => {
    const user1 = await createTestUser({ email: "gh1@t.com" });
    const user2 = await createTestUser({ email: "gh2@t.com" });

    await testSql`INSERT INTO oauth_accounts (provider, provider_id, user_id)
      VALUES ('github', 'gh_shared', ${user1.id})`;

    // Same provider_id for different user should fail (unique on provider + provider_id)
    await expect(
      testSql`INSERT INTO oauth_accounts (provider, provider_id, user_id)
        VALUES ('github', 'gh_shared', ${user2.id})`
    ).rejects.toThrow();
  });

  it("user can have both GitHub and Google accounts", async () => {
    const user = await createTestUser();

    await testSql`INSERT INTO oauth_accounts (provider, provider_id, user_id)
      VALUES ('github', 'gh_999', ${user.id})`;
    await testSql`INSERT INTO oauth_accounts (provider, provider_id, user_id)
      VALUES ('google', 'google_999', ${user.id})`;

    const rows = await testSql`SELECT provider FROM oauth_accounts WHERE user_id = ${user.id} ORDER BY provider`;
    expect(rows.map((r: any) => r.provider)).toEqual(["github", "google"]);
  });

  it("updating provider_id on existing account works", async () => {
    const user = await createTestUser();

    await testSql`INSERT INTO oauth_accounts (provider, provider_id, user_id)
      VALUES ('github', 'gh_old', ${user.id})`;

    // User switches GitHub accounts -- update provider_id
    await testSql`UPDATE oauth_accounts SET provider_id = 'gh_new'
      WHERE user_id = ${user.id} AND provider = 'github'`;

    const [row] = await testSql`SELECT provider_id FROM oauth_accounts WHERE user_id = ${user.id} AND provider = 'github'`;
    expect(row.provider_id).toBe("gh_new");
  });
});

describe("Account: Password Reset", () => {
  it("creates and consumes a reset token", async () => {
    const user = await createTestUser();
    const token = crypto.randomBytes(32).toString("hex");
    const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
    const expiresAt = new Date(Date.now() + 3600_000);

    await testSql`INSERT INTO password_reset_tokens (id, user_id, token_hash, expires_at)
      VALUES ('prt_1', ${user.id}, ${tokenHash}, ${expiresAt.toISOString()})`;

    // Consume
    const result = await testSql`
      UPDATE password_reset_tokens SET used_at = NOW()
      WHERE token_hash = ${tokenHash} AND expires_at > NOW() AND used_at IS NULL
      RETURNING user_id`;

    expect(result.length).toBe(1);
    expect(result[0].user_id).toBe(user.id);

    // Second use fails
    const result2 = await testSql`
      UPDATE password_reset_tokens SET used_at = NOW()
      WHERE token_hash = ${tokenHash} AND used_at IS NULL
      RETURNING user_id`;

    expect(result2.length).toBe(0);
  });

  it("expired token cannot be consumed", async () => {
    const user = await createTestUser();
    const tokenHash = crypto.createHash("sha256").update("expired_token").digest("hex");

    await testSql`INSERT INTO password_reset_tokens (id, user_id, token_hash, expires_at)
      VALUES ('prt_exp', ${user.id}, ${tokenHash}, NOW() - interval '1 hour')`;

    const result = await testSql`
      UPDATE password_reset_tokens SET used_at = NOW()
      WHERE token_hash = ${tokenHash} AND expires_at > NOW() AND used_at IS NULL
      RETURNING user_id`;

    expect(result.length).toBe(0);
  });
});

describe("Account: Email Verification", () => {
  it("creates and consumes a verification token", async () => {
    const user = await createTestUser({ email: "unverified@t.com" });
    const token = crypto.randomBytes(32).toString("hex");
    const tokenHash = crypto.createHash("sha256").update(token).digest("hex");

    await testSql`INSERT INTO email_verification_tokens (id, user_id, email, token_hash, expires_at)
      VALUES ('evt_1', ${user.id}, 'unverified@t.com', ${tokenHash}, NOW() + interval '1 day')`;

    const result = await testSql`
      UPDATE email_verification_tokens SET used_at = NOW()
      WHERE token_hash = ${tokenHash} AND expires_at > NOW() AND used_at IS NULL
      RETURNING user_id, email`;

    expect(result.length).toBe(1);
    expect(result[0].email).toBe("unverified@t.com");
  });
});

describe("Schema: Audit Log", () => {
  it("records audit events with actor and resource", async () => {
    const admin = await createTestUser({ email: "admin@t.com", role: "admin" });
    const user = await createTestUser({ email: "target@t.com" });

    await testSql`INSERT INTO audit_log (id, user_id, actor_id, action, resource_type, resource_id, details, ip_address)
      VALUES ('al_1', ${user.id}, ${admin.id}, 'ban', 'user', ${user.id}, '{"reason":"abuse"}', '10.0.0.1')`;

    const [row] = await testSql`SELECT * FROM audit_log WHERE id = 'al_1'`;
    expect(row.action).toBe("ban");
    expect(row.actor_id).toBe(admin.id);
    expect(row.user_id).toBe(user.id);
    expect(row.ip_address).toBe("10.0.0.1");
  });
});
