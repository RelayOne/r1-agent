import { describe, it, expect } from "vitest";
import { testSql, createTestUser, createTestSubscription, createTestSlot, createTestMachine } from "./setup.js";
import crypto from "crypto";

describe("Terminal: Exchange Codes", () => {
  it("creates and consumes a one-time exchange code", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_term_1");
    const slot = await createTestSlot(user.id, sub.id);
    const machine = await createTestMachine(user.id, slot.id);

    const code = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 60_000);

    await testSql`INSERT INTO exchange_codes (code, machine_id, user_id, fly_app_name, expires_at)
      VALUES (${code}, ${machine.id}, ${user.id}, ${machine.flyAppName}, ${expiresAt.toISOString()})`;

    // Consume: atomic UPDATE ... RETURNING
    const result = await testSql`
      UPDATE exchange_codes SET consumed_at = NOW()
      WHERE code = ${code} AND fly_app_name = ${machine.flyAppName}
        AND expires_at > NOW() AND consumed_at IS NULL
      RETURNING code, user_id`;

    expect(result.length).toBe(1);
    expect(result[0].user_id).toBe(user.id);

    // Second consume should return nothing (single-use)
    const result2 = await testSql`
      UPDATE exchange_codes SET consumed_at = NOW()
      WHERE code = ${code} AND consumed_at IS NULL
      RETURNING code`;

    expect(result2.length).toBe(0);
  });

  it("expired code cannot be consumed", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_term_2");
    const slot = await createTestSlot(user.id, sub.id);
    const machine = await createTestMachine(user.id, slot.id);

    const code = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() - 1000); // Already expired

    await testSql`INSERT INTO exchange_codes (code, machine_id, user_id, fly_app_name, expires_at)
      VALUES (${code}, ${machine.id}, ${user.id}, ${machine.flyAppName}, ${expiresAt.toISOString()})`;

    const result = await testSql`
      UPDATE exchange_codes SET consumed_at = NOW()
      WHERE code = ${code} AND expires_at > NOW() AND consumed_at IS NULL
      RETURNING code`;

    expect(result.length).toBe(0);
  });

  it("code for wrong machine is rejected", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_term_3");
    const slot1 = await createTestSlot(user.id, sub.id, { stripeItemId: "si_t1" });
    const slot2 = await createTestSlot(user.id, sub.id, { stripeItemId: "si_t2" });
    const machine1 = await createTestMachine(user.id, slot1.id, { flyAppName: "ember-m1" });
    const machine2 = await createTestMachine(user.id, slot2.id, { flyAppName: "ember-m2" });

    const code = crypto.randomBytes(32).toString("hex");
    await testSql`INSERT INTO exchange_codes (code, machine_id, user_id, fly_app_name, expires_at)
      VALUES (${code}, ${machine1.id}, ${user.id}, 'ember-m1', NOW() + interval '1 minute')`;

    // Try to consume with wrong fly_app_name
    const result = await testSql`
      UPDATE exchange_codes SET consumed_at = NOW()
      WHERE code = ${code} AND fly_app_name = 'ember-m2' AND consumed_at IS NULL
      RETURNING code`;

    expect(result.length).toBe(0);
  });
});

describe("Terminal: Session Tracking", () => {
  it("creates a session record on terminal auth", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_sess_1");
    const slot = await createTestSlot(user.id, sub.id);
    const machine = await createTestMachine(user.id, slot.id);

    const sessionId = crypto.randomUUID().replace(/-/g, "").slice(0, 20);
    const expiresAt = new Date(Date.now() + 86400_000);

    await testSql`INSERT INTO terminal_sessions (id, machine_id, user_id, status, expires_at)
      VALUES (${sessionId}, ${machine.id}, ${user.id}, 'active', ${expiresAt.toISOString()})`;

    const [row] = await testSql`SELECT * FROM terminal_sessions WHERE id = ${sessionId}`;
    expect(row.status).toBe("active");
    expect(row.user_id).toBe(user.id);
    expect(row.machine_id).toBe(machine.id);
  });

  it("revokes all sessions for a user with reason", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_sess_2");
    const slot = await createTestSlot(user.id, sub.id);
    const machine = await createTestMachine(user.id, slot.id);

    // Create 3 sessions
    for (let i = 0; i < 3; i++) {
      await testSql`INSERT INTO terminal_sessions (id, machine_id, user_id, status, expires_at)
        VALUES (${`ts_${i}`}, ${machine.id}, ${user.id}, 'active', NOW() + interval '1 day')`;
    }

    // Revoke all
    await testSql`UPDATE terminal_sessions SET status = 'revoked', revoked_at = NOW(), revoke_reason = 'logout'
      WHERE user_id = ${user.id} AND status = 'active'`;

    const rows = await testSql`SELECT status, revoke_reason FROM terminal_sessions WHERE user_id = ${user.id}`;
    expect(rows.length).toBe(3);
    expect(rows.every((r: any) => r.status === "revoked" && r.revoke_reason === "logout")).toBe(true);
  });

  it("revocation for one user does not affect another", async () => {
    const user1 = await createTestUser({ email: "u1@t.com" });
    const user2 = await createTestUser({ email: "u2@t.com" });
    const sub = await createTestSubscription(user1.id, "sub_sess_3a");
    const sub2 = await createTestSubscription(user2.id, "sub_sess_3b");
    const slot = await createTestSlot(user1.id, sub.id, { stripeItemId: "si_s3a" });
    const slot2 = await createTestSlot(user2.id, sub2.id, { stripeItemId: "si_s3b" });
    const m1 = await createTestMachine(user1.id, slot.id, { flyAppName: "ember-u1" });
    const m2 = await createTestMachine(user2.id, slot2.id, { flyAppName: "ember-u2" });

    await testSql`INSERT INTO terminal_sessions (id, machine_id, user_id, status, expires_at)
      VALUES ('ts_u1', ${m1.id}, ${user1.id}, 'active', NOW() + interval '1 day')`;
    await testSql`INSERT INTO terminal_sessions (id, machine_id, user_id, status, expires_at)
      VALUES ('ts_u2', ${m2.id}, ${user2.id}, 'active', NOW() + interval '1 day')`;

    // Revoke user1 only
    await testSql`UPDATE terminal_sessions SET status = 'revoked' WHERE user_id = ${user1.id}`;

    const [s1] = await testSql`SELECT status FROM terminal_sessions WHERE id = 'ts_u1'`;
    const [s2] = await testSql`SELECT status FROM terminal_sessions WHERE id = 'ts_u2'`;
    expect(s1.status).toBe("revoked");
    expect(s2.status).toBe("active");
  });
});

describe("Terminal: Revocation Reasons", () => {
  it("tracks different revocation reasons", async () => {
    const user = await createTestUser();
    const sub = await createTestSubscription(user.id, "sub_rev_reasons");
    const slot = await createTestSlot(user.id, sub.id);
    const machine = await createTestMachine(user.id, slot.id);

    for (const reason of ["logout", "ban", "password_reset", "machine_restart"]) {
      const sid = `ts_${reason}`;
      await testSql`INSERT INTO terminal_sessions (id, machine_id, user_id, status, expires_at)
        VALUES (${sid}, ${machine.id}, ${user.id}, 'active', NOW() + interval '1 day')`;
      await testSql`UPDATE terminal_sessions SET status = 'revoked', revoke_reason = ${reason} WHERE id = ${sid}`;
    }

    const rows = await testSql`SELECT revoke_reason FROM terminal_sessions WHERE user_id = ${user.id} ORDER BY revoke_reason`;
    const reasons = rows.map((r: any) => r.revoke_reason);
    expect(reasons).toEqual(["ban", "logout", "machine_restart", "password_reset"]);
  });
});
