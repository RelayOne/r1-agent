import { Lucia } from "lucia";
import { DrizzlePostgreSQLAdapter } from "@lucia-auth/adapter-drizzle";
import { GitHub, Google } from "arctic";
import { db } from "./connection.js";
import { users, sessions } from "./db.js";

// ── Lucia ────────────────────────────────────────────────────
const adapter = new DrizzlePostgreSQLAdapter(db, sessions, users);

export const lucia = new Lucia(adapter, {
  sessionCookie: {
    attributes: {
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    },
  },
  getUserAttributes: (attrs) => ({
    email: attrs.email,
    name: attrs.name,
    role: attrs.role,
    status: attrs.status,
    avatarUrl: attrs.avatar_url,
  }),
});

declare module "lucia" {
  interface Register {
    Lucia: typeof lucia;
    DatabaseUserAttributes: {
      email: string;
      name: string | null;
      role: string;
      status: string;
      avatar_url: string | null;
    };
  }
}

// ── OAuth Providers ──────────────────────────────────────────
const APP_URL = process.env.APP_URL || "http://localhost:3000";

// Login: minimal scope (user:email only)
// OAuth providers are optional - empty strings won't crash but routes will fail gracefully
export const github = new GitHub(
  process.env.GITHUB_CLIENT_ID || "",
  process.env.GITHUB_CLIENT_SECRET || "",
  `${APP_URL}/api/auth/github/callback`
);

// Connect: broader scope for repo access (user triggers explicitly)
export const githubConnect = new GitHub(
  process.env.GITHUB_CLIENT_ID || "",
  process.env.GITHUB_CLIENT_SECRET || "",
  `${APP_URL}/api/github/connect/callback`
);

export const google = new Google(
  process.env.GOOGLE_CLIENT_ID || "",
  process.env.GOOGLE_CLIENT_SECRET || "",
  `${APP_URL}/api/auth/google/callback`
);
