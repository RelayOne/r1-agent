// GitHub App integration.
// Uses fine-grained, short-lived installation tokens instead of classic OAuth repo tokens.
// GitHub recommends Apps because permissions are repository-scoped and tokens expire.
//
// Setup:
//   1. Create a GitHub App at github.com/settings/apps
//   2. Set permissions: Repository contents (read-only)
//   3. Set GITHUB_APP_ID, GITHUB_APP_PRIVATE_KEY in env
//   4. Users install the App on their account/org via /api/github/install
//   5. At machine creation, we generate a short-lived installation token for the specific repo

import crypto from "crypto";

const APP_ID = () => process.env.GITHUB_APP_ID || "";
const PRIVATE_KEY = () => process.env.GITHUB_APP_PRIVATE_KEY || "";

function isConfigured(): boolean {
  return !!(APP_ID() && PRIVATE_KEY());
}

// Create a JWT signed with the App's private key (valid for 10 minutes max)
function createAppJWT(): string {
  const now = Math.floor(Date.now() / 1000);
  const header = Buffer.from(JSON.stringify({ alg: "RS256", typ: "JWT" })).toString("base64url");
  const payload = Buffer.from(JSON.stringify({
    iat: now - 60,   // Allow 60s clock drift
    exp: now + 600,  // 10 minute expiry
    iss: APP_ID(),
  })).toString("base64url");

  const signingInput = `${header}.${payload}`;
  const sign = crypto.createSign("SHA256");
  sign.update(signingInput);
  const signature = sign.sign(PRIVATE_KEY(), "base64url");

  return `${header}.${payload}.${signature}`;
}

// Get installation ID for a user's GitHub account
export async function getInstallationForUser(githubUsername: string): Promise<number | null> {
  if (!isConfigured()) return null;

  try {
    const jwt = createAppJWT();
    const res = await fetch("https://api.github.com/app/installations", {
      headers: {
        Authorization: `Bearer ${jwt}`,
        Accept: "application/vnd.github+json",
      },
    });
    if (!res.ok) return null;

    const installations = await res.json() as any[];
    const match = installations.find((i: any) =>
      i.account?.login?.toLowerCase() === githubUsername.toLowerCase()
    );
    return match?.id || null;
  } catch (e: any) {
    console.error("[github-app] getInstallationForUser:", e.message);
    return null;
  }
}

// Get installation for an org
export async function getInstallationForOrg(orgName: string): Promise<number | null> {
  return getInstallationForUser(orgName); // Same API, same logic
}

// Generate a short-lived installation token scoped to specific repositories
export async function createInstallationToken(
  installationId: number,
  repos?: string[],         // e.g. ["my-repo"] (repo names, not full names)
): Promise<{ token: string; expiresAt: string } | null> {
  if (!isConfigured()) return null;

  try {
    const jwt = createAppJWT();
    const body: any = {};
    if (repos?.length) {
      body.repositories = repos;
      body.permissions = { contents: "read" }; // Minimum: read-only repo contents
    }

    const res = await fetch(
      `https://api.github.com/app/installations/${installationId}/access_tokens`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${jwt}`,
          Accept: "application/vnd.github+json",
          "Content-Type": "application/json",
        },
        body: Object.keys(body).length ? JSON.stringify(body) : undefined,
      }
    );

    if (!res.ok) {
      console.error("[github-app] createInstallationToken:", res.status, await res.text().catch(() => ""));
      return null;
    }

    const data = await res.json() as any;
    return { token: data.token, expiresAt: data.expires_at };
  } catch (e: any) {
    console.error("[github-app] createInstallationToken:", e.message);
    return null;
  }
}

// List repos accessible to an installation
export async function listInstallationRepos(installationId: number): Promise<any[]> {
  if (!isConfigured()) return [];

  const tokenResult = await createInstallationToken(installationId);
  if (!tokenResult) return [];

  try {
    const res = await fetch("https://api.github.com/installation/repositories?per_page=100", {
      headers: {
        Authorization: `Bearer ${tokenResult.token}`,
        Accept: "application/vnd.github+json",
      },
    });
    if (!res.ok) return [];
    const data = await res.json() as any;
    return data.repositories || [];
  } catch {
    return [];
  }
}

// Parse owner/repo from a GitHub clone URL
export function parseGitHubRepo(url: string): { owner: string; repo: string } | null {
  try {
    const u = new URL(url);
    if (u.hostname !== "github.com" && u.hostname !== "www.github.com") return null;
    const parts = u.pathname.replace(/\.git$/, "").split("/").filter(Boolean);
    if (parts.length !== 2) return null;
    return { owner: parts[0], repo: parts[1] };
  } catch {
    return null;
  }
}

// Get a clone token for a specific repo. Prefers GitHub App (short-lived, scoped)
// but falls back to classic OAuth token if App is not configured.
export async function getCloneToken(
  repoUrl: string,
  githubUsername: string | null,
  classicOAuthToken: string | null,
): Promise<{ token: string; method: "app" | "oauth" } | null> {
  const parsed = parseGitHubRepo(repoUrl);
  if (!parsed) return null;

  // Try GitHub App first (preferred: fine-grained, short-lived)
  if (isConfigured()) {
    // 1. Try installation on the repo OWNER (handles org repos)
    const ownerInstallation = await getInstallationForUser(parsed.owner);
    if (ownerInstallation) {
      const tokenResult = await createInstallationToken(ownerInstallation, [parsed.repo]);
      if (tokenResult) {
        return { token: tokenResult.token, method: "app" };
      }
    }

    // 2. Try installation on the authenticated user (handles personal forks)
    if (githubUsername && githubUsername.toLowerCase() !== parsed.owner.toLowerCase()) {
      const userInstallation = await getInstallationForUser(githubUsername);
      if (userInstallation) {
        const tokenResult = await createInstallationToken(userInstallation, [parsed.repo]);
        if (tokenResult) {
          return { token: tokenResult.token, method: "app" };
        }
      }
    }
  }

  // Fall back to classic OAuth token
  if (classicOAuthToken) {
    return { token: classicOAuthToken, method: "oauth" };
  }

  return null;
}

export { isConfigured as isGitHubAppConfigured };
