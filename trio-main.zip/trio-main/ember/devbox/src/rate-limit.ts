// Rate limiter with pluggable backend.
// Default: in-memory (single instance). Set RATE_LIMIT_BACKEND=postgres for multi-instance.
// Postgres backend uses a simple table with window queries.

import { Context, Next } from "hono";

interface RateLimitOpts {
  windowMs: number;
  max: number;
  keyFn?: (c: Context) => string;
  message?: string;
}

function getClientIp(c: Context): string {
  return (
    c.req.header("fly-client-ip") ||
    c.req.header("x-forwarded-for")?.split(",")[0]?.trim() ||
    c.req.header("x-real-ip") ||
    "unknown"
  );
}

// ── In-memory backend ────────────────────────────────────────
// Track the longest configured window so cleanup doesn't expire hits prematurely.
// Starts at 1 hour (the longest default window); rateLimit() updates if longer.
let maxWindowMs = 60 * 60 * 1000;

const memStores = new Map<string, Map<string, number[]>>();
setInterval(() => {
  const now = Date.now();
  for (const [, store] of memStores) {
    for (const [key, ts] of store) {
      const filtered = ts.filter(t => now - t < maxWindowMs);
      if (!filtered.length) store.delete(key);
      else store.set(key, filtered);
    }
  }
}, 60_000).unref?.();

async function memCheck(name: string, key: string, windowMs: number, max: number): Promise<{ allowed: boolean; remaining: number; retryAfter: number }> {
  if (!memStores.has(name)) memStores.set(name, new Map());
  const store = memStores.get(name)!;
  const now = Date.now();
  let ts = store.get(key) || [];
  ts = ts.filter(t => now - t < windowMs);

  if (ts.length >= max) {
    const retryAfter = Math.ceil((ts[0] + windowMs - now) / 1000);
    return { allowed: false, remaining: 0, retryAfter };
  }
  ts.push(now);
  store.set(key, ts);
  return { allowed: true, remaining: max - ts.length, retryAfter: 0 };
}

// ── Postgres backend ─────────────────────────────────────────
// Uses the rate_limit_hits table. Works across multiple API instances.
// Table creation runs once at module init (not on first request).
let pgSql: any = null;
let pgInitPromise: Promise<void> | null = null;

async function initPgBackend(): Promise<void> {
  const { rawSql } = await import("./connection.js");
  pgSql = rawSql;

  await pgSql`CREATE TABLE IF NOT EXISTS rate_limit_hits (
    id serial PRIMARY KEY,
    bucket text NOT NULL,
    key text NOT NULL,
    ts timestamp with time zone NOT NULL DEFAULT NOW()
  )`;
  await pgSql`CREATE INDEX IF NOT EXISTS rate_limit_hits_lookup ON rate_limit_hits (bucket, key, ts)`;
}

async function pgCheck(name: string, key: string, windowMs: number, max: number): Promise<{ allowed: boolean; remaining: number; retryAfter: number }> {
  if (!pgSql) {
    if (!pgInitPromise) pgInitPromise = initPgBackend();
    await pgInitPromise;
  }

  const windowStart = new Date(Date.now() - windowMs).toISOString();
  const bucket = name;

  // Atomic: insert the hit first, then count all hits in the window (including this one).
  // If count exceeds max, we delete the hit we just inserted and reject.
  // This is safe under concurrency because the count includes our own row.
  const [result] = await pgSql`
    WITH new_hit AS (
      INSERT INTO rate_limit_hits (bucket, key) VALUES (${bucket}, ${key})
      RETURNING id, ts
    ),
    window_count AS (
      SELECT count(*)::int as cnt,
             min(ts) as oldest_ts
      FROM rate_limit_hits
      WHERE bucket = ${bucket} AND key = ${key} AND ts > ${windowStart}
    )
    SELECT new_hit.id as hit_id, window_count.cnt, window_count.oldest_ts
    FROM new_hit, window_count`;

  if (result.cnt > max) {
    // Over limit: remove the hit we just inserted
    await pgSql`DELETE FROM rate_limit_hits WHERE id = ${result.hit_id}`;
    let retryAfter = 60;
    if (result.oldest_ts) {
      const ts = new Date(result.oldest_ts).getTime();
      if (Number.isFinite(ts)) {
        retryAfter = Math.ceil((ts + windowMs - Date.now()) / 1000);
      }
    }
    return { allowed: false, remaining: 0, retryAfter: Math.max(1, retryAfter) };
  }

  // Async cleanup (non-blocking) - retain hits for the longest configured window
  pgSql`DELETE FROM rate_limit_hits WHERE ts < ${new Date(Date.now() - maxWindowMs).toISOString()}`.catch((e: any) => console.error("[rate-limit] cleanup:", e));

  return { allowed: true, remaining: max - result.cnt, retryAfter: 0 };
}

// ── Rate limit middleware factory ─────────────────────────────
// Default to postgres backend when DATABASE_URL is available (multi-instance safe).
// Explicit RATE_LIMIT_BACKEND env var overrides auto-detection.
const usePostgres =
  process.env.RATE_LIMIT_BACKEND === "postgres" ||
  (process.env.RATE_LIMIT_BACKEND !== "memory" &&
   (!!process.env.DATABASE_URL || process.env.NODE_ENV === "production"));

// Eagerly initialize postgres backend at module load (outside request path)
if (usePostgres) {
  pgInitPromise = initPgBackend().catch((e) => {
    console.error("[rate-limit] Failed to init postgres backend:", e);
    pgInitPromise = null; // Allow retry on first request
  });
}

if (!usePostgres && process.env.NODE_ENV === "production") {
  console.warn(
    "[rate-limit] WARNING: Using in-memory rate limiter in production. " +
    "Rate limits will not be shared across instances. " +
    "Set DATABASE_URL or RATE_LIMIT_BACKEND=postgres for multi-instance support."
  );
}

export function rateLimit(name: string, opts: RateLimitOpts) {
  // Track the longest window so cleanup doesn't expire hits prematurely
  if (opts.windowMs > maxWindowMs) maxWindowMs = opts.windowMs;

  const check = usePostgres ? pgCheck : memCheck;

  return async (c: Context, next: Next) => {
    const key = opts.keyFn ? opts.keyFn(c) : getClientIp(c);
    const result = await check(name, key, opts.windowMs, opts.max);

    c.header("X-RateLimit-Limit", String(opts.max));
    c.header("X-RateLimit-Remaining", String(result.remaining));

    if (!result.allowed) {
      c.header("Retry-After", String(result.retryAfter));
      return c.json({ error: opts.message || "Too many requests" }, 429);
    }

    return next();
  };
}

// Pre-configured limiters
export const authLimiter = rateLimit("auth", {
  windowMs: 15 * 60 * 1000, max: 20,
  message: "Too many auth attempts. Try again later.",
});
export const registerLimiter = rateLimit("register", {
  windowMs: 60 * 60 * 1000, max: 5,
  message: "Too many accounts created. Try again later.",
});
export const billingLimiter = rateLimit("billing", { windowMs: 60_000, max: 10 });
export const machineLimiter = rateLimit("machines", { windowMs: 60_000, max: 20 });
export const terminalLimiter = rateLimit("terminal", { windowMs: 60_000, max: 30 });
export const apiLimiter = rateLimit("api", { windowMs: 60_000, max: 120 });
export const forgotPasswordLimiter = rateLimit("forgot_password", {
  windowMs: 15 * 60 * 1000, max: 5,
  message: "Too many password reset requests. Try again later.",
});
