import { hash } from "@node-rs/argon2";
import { generateIdFromEntropySize } from "lucia";
import { db } from "./connection.js";
import { users } from "./db.js";

const email = process.argv[2];
const password = process.argv[3];

if (!email || !password) {
  console.error("Usage: tsx src/seed.ts admin@example.com password123");
  process.exit(1);
}

const userId = generateIdFromEntropySize(10);
const passwordHash = await hash(password);

await db.insert(users).values({
  id: userId,
  email,
  passwordHash,
  name: "Admin",
  role: "admin",
});

console.log(`Admin user created: ${email} (id: ${userId})`);
process.exit(0);
