import { pgTable, text, integer, numeric, jsonb, timestamp, boolean, uniqueIndex, index, uuid } from "drizzle-orm/pg-core";

// ── Users ────────────────────────────────────────────────────
export const users = pgTable("users", {
  id: text("id").primaryKey(),
  email: text("email").unique().notNull(),
  emailVerified: boolean("email_verified").notNull().default(false),
  passwordHash: text("password_hash"),
  name: text("name"),
  avatarUrl: text("avatar_url"),
  role: text("role").notNull().default("user"),        // user | admin
  status: text("status").notNull().default("active"),  // active | banned
  creditsCents: integer("credits_cents").notNull().default(0),
  stripeCustomerId: text("stripe_customer_id").unique(),
  startupScript: text("startup_script").default(""),
  mfaSecret: text("mfa_secret"),                       // TOTP secret for admin MFA
  layoutConfig: text("layout_config"),                  // JSON: dashboard grid layout preferences
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ── Sessions (Lucia) ─────────────────────────────────────────
export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true, mode: "date" }).notNull(),
}, (table) => [
  index("idx_sessions_userId").on(table.userId),
]);

// ── OAuth Accounts ───────────────────────────────────────────
export const oauthAccounts = pgTable(
  "oauth_accounts",
  {
    provider: text("provider").notNull(),
    providerId: text("provider_id").notNull(),
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    accessToken: text("access_token"),    // Encrypted via secrets.ts
    refreshToken: text("refresh_token"),  // Encrypted via secrets.ts
    tokenScope: text("token_scope"),      // e.g. "user:email" or "user:email,repo,read:org"
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  },
  (table) => [
    uniqueIndex("oauth_provider_id_idx").on(table.provider, table.providerId),
    uniqueIndex("oauth_user_provider_idx").on(table.userId, table.provider),
  ]
);

// ── Subscriptions (local mirror of Stripe subscription state) ──
// This is the authoritative source for entitlement checks.
// Webhooks write here; API reads from here (never from live Stripe).
export const subscriptions = pgTable("subscriptions", {
  id: text("id").primaryKey(),                        // Our ID
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  stripeSubscriptionId: text("stripe_subscription_id").unique().notNull(),
  status: text("status").notNull(),                    // active | past_due | unpaid | canceled | paused | incomplete | incomplete_expired | trialing
  currentPeriodStart: timestamp("current_period_start", { withTimezone: true }),
  currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }),
  cancelAt: timestamp("cancel_at", { withTimezone: true }),
  canceledAt: timestamp("canceled_at", { withTimezone: true }),
  lastStripeEventId: text("last_stripe_event_id"),     // Monotonic: only process events newer than this
  lastStripeEventTs: timestamp("last_stripe_event_ts", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ── Slots (billing units, linked to subscription) ────────────
export const slots = pgTable("slots", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  subscriptionId: text("subscription_id")
    .references(() => subscriptions.id),
  stripeSubscriptionItemId: text("stripe_subscription_item_id").unique(),
  size: text("size").notNull(),
  priceCents: integer("price_cents").notNull(),
  status: text("status").notNull().default("active"),  // active | cancelled
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
}, (table) => [
  index("idx_slots_userId").on(table.userId),
]);

// ── Purchase Intents (server-side idempotency) ───────────────
// Created before any Stripe call. The intentId IS the Stripe idempotency key.
// Survives page reloads, device switches, retries.
export const purchaseIntents = pgTable("purchase_intents", {
  id: text("id").primaryKey(),                         // Also used as Stripe idempotency key
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull(),                        // checkout | add_slot
  size: text("size").notNull(),
  status: text("status").notNull().default("pending"), // pending | completed | failed | expired
  stripeSessionId: text("stripe_session_id"),
  stripeSubscriptionItemId: text("stripe_subscription_item_id"),
  slotId: text("slot_id").references(() => slots.id),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

// ── Machines ─────────────────────────────────────────────────
export const machines = pgTable("machines", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  slotId: text("slot_id")
    .unique()
    .references(() => slots.id),
  name: text("name").notNull(),
  machineType: text("machine_type").notNull().default("cli"), // cli | vscode
  flyAppName: text("fly_app_name").unique().notNull(),
  flyMachineId: text("fly_machine_id"),
  flyRegion: text("fly_region").notNull().default("sjc"),
  size: text("size").notNull(),
  state: text("state").notNull().default("creating"),  // creating | running | stopped | needs_stop | error | deleted
  gitRepo: text("git_repo"),
  machineToken: text("machine_token"),
  hostnameStatus: text("hostname_status"),              // pending | ready | failed
  metadata: jsonb("metadata"),                              // stoke worker tags, etc.
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}, (table) => [
  index("idx_machines_userId").on(table.userId),
  index("idx_machines_state").on(table.state),
]);

// ── Terminal Sessions (inventory for audit/revocation) ────────
export const terminalSessions = pgTable(
  "terminal_sessions",
  {
    id: text("id").primaryKey(),
    machineId: text("machine_id")
      .notNull()
      .references(() => machines.id, { onDelete: "cascade" }),
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    status: text("status").notNull().default("active"), // active | revoked | expired
    issuedAt: timestamp("issued_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
    lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
    revokeReason: text("revoke_reason"),                 // logout | ban | password_reset | machine_restart
  },
  (table) => [
    index("terminal_sessions_machine_idx").on(table.machineId),
    index("terminal_sessions_user_idx").on(table.userId),
  ]
);

// ── Billing Events (immutable ledger) ────────────────────────
export const billingEvents = pgTable("billing_events", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  slotId: text("slot_id").references(() => slots.id),
  subscriptionId: text("subscription_id").references(() => subscriptions.id),
  amountCents: integer("amount_cents").notNull().default(0),
  stripeEventId: text("stripe_event_id").unique(),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ── Exchange Codes (terminal auth, short-lived) ──────────────
export const exchangeCodes = pgTable("exchange_codes", {
  code: text("code").primaryKey(),
  machineId: text("machine_id").notNull().references(() => machines.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  flyAppName: text("fly_app_name").notNull(),
  sessionId: text("session_id"),   // Links to terminal_sessions.id for cookie tracking
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  consumedAt: timestamp("consumed_at", { withTimezone: true }),
});

// ── Password Reset Tokens ────────────────────────────────────
export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull(),  // SHA-256 of the token sent to user
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ── Email Verification Tokens ────────────────────────────────
export const emailVerificationTokens = pgTable("email_verification_tokens", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  email: text("email").notNull(),
  tokenHash: text("token_hash").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ── Audit Log ────────────────────────────────────────────────
export const auditLog = pgTable(
  "audit_log",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").references(() => users.id),
    actorId: text("actor_id").references(() => users.id), // Who performed the action (admin for bans, etc)
    action: text("action").notNull(),
    resourceType: text("resource_type"),                   // user | machine | slot | subscription | github | terminal
    resourceId: text("resource_id"),
    details: text("details"),                              // JSON string for structured data
    ipAddress: text("ip_address"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("audit_log_user_idx").on(table.userId),
    index("audit_log_action_idx").on(table.action),
    index("audit_log_created_idx").on(table.createdAt),
  ]
);

// ── API Keys (for v1 endpoints: workers, AI, sessions) ──
export const apiKeys = pgTable("api_keys", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  keyHash: text("key_hash").notNull().unique(),
  label: text("label").notNull().default("default"),
  status: text("status").notNull().default("active"),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (table) => [
  index("api_keys_user_idx").on(table.userId),
]);

// ── AI Usage Metering (managed OpenRouter proxy) ──
export const aiUsage = pgTable("ai_usage", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  model: text("model").notNull(),
  inputTokens: integer("input_tokens").notNull().default(0),
  outputTokens: integer("output_tokens").notNull().default(0),
  costUsd: numeric("cost_usd", { precision: 10, scale: 6 }).notNull().default("0"),
  markupUsd: numeric("markup_usd", { precision: 10, scale: 6 }).notNull().default("0"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (table) => [
  index("ai_usage_user_period_idx").on(table.userId, table.createdAt),
]);

// ── Stoke Sessions (build progress for dashboard + shareable links) ──
export const stokeSessions = pgTable("stoke_sessions", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  planId: text("plan_id").notNull().default(""),
  status: text("status").notNull().default("active"),
  tasks: jsonb("tasks").notNull().default([]),
  totalCostUsd: numeric("total_cost_usd", { precision: 10, scale: 4 }).notNull().default("0"),
  burstWorkers: integer("burst_workers").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("stoke_sessions_user_idx").on(table.userId),
]);

// ── Credit Ledger (burst worker billing, decoupled from slot subscriptions) ──

export const creditTransactions = pgTable("credit_transactions", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  idempotencyKey: text("idempotency_key").notNull(),
  userId: text("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // topup, worker_debit, worker_refund, admin_adjustment, promotional_grant
  amountCents: integer("amount_cents").notNull(), // positive=added, negative=consumed
  balanceAfterCents: integer("balance_after_cents").notNull(),
  workerAllocationId: uuid("worker_allocation_id"),
  metadata: jsonb("metadata").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("idx_credit_txn_user_created").on(table.userId, table.createdAt),
  uniqueIndex("idx_credit_txn_idempotency").on(table.userId, table.idempotencyKey),
]);

export const workerAllocations = pgTable("worker_allocations", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull().references(() => users.id),
  status: text("status").notNull().default("pending"), // pending, active, completed, failed, expired, cancelled
  workerType: text("worker_type").notNull(),
  costCents: integer("cost_cents").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  workerInstanceId: text("worker_instance_id"),
  taskDescription: text("task_description"),
  error: text("error"),
  metadata: jsonb("metadata").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  creditTransactionId: integer("credit_transaction_id"),
}, (table) => [
  index("idx_alloc_user_status").on(table.userId, table.status),
]);

export const processedStripeEvents = pgTable("processed_stripe_events", {
  eventId: text("event_id").primaryKey(),
  classification: text("classification").notNull(),
  processedAt: timestamp("processed_at", { withTimezone: true }).notNull().defaultNow(),
});
