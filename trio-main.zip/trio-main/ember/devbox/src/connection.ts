import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "./db.js";

// Single connection pool shared by Drizzle and raw SQL queries.
// Import `rawSql` for transactions/raw queries, `db` for Drizzle ORM.
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL is not set. A Postgres connection string is required. " +
    "Example: DATABASE_URL=postgres://user:pass@host:5432/dbname"
  );
}

export const rawSql = postgres(process.env.DATABASE_URL, {
  max: 25,
  idle_timeout: 20,
  connect_timeout: 5,
});
export const db = drizzle(rawSql, { schema });

// postgres.js v3 TransactionSql loses the tagged-template call signature
// because TypeScript's Omit<> erases call/construct signatures.
// Module augmentation restores it so `tx\`...\`` works without `any`.
declare module "postgres" {
  interface TransactionSql<TTypes extends Record<string, unknown> = {}> {
    <T extends readonly (object | undefined)[] = postgres.Row[]>(
      template: TemplateStringsArray,
      ...parameters: readonly (postgres.ParameterOrFragment<TTypes[keyof TTypes]>)[]
    ): postgres.PendingQuery<T>;
  }
}
export type Transaction = postgres.TransactionSql;

