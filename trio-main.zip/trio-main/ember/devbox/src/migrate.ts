import { migrate } from "drizzle-orm/postgres-js/migrator";
import { db, rawSql } from "./connection.js";
import { readFileSync, readdirSync } from "fs";
import { join } from "path";

console.log("Running Drizzle migrations...");
await migrate(db, { migrationsFolder: "./drizzle" });

// Run SQL migrations from migrations/ folder (credit ledger, etc.)
// These are idempotent (IF NOT EXISTS / ON CONFLICT) so safe to re-run.
const sqlMigrationsDir = "./migrations";
try {
  const files = readdirSync(sqlMigrationsDir).filter(f => f.endsWith(".sql")).sort();
  for (const file of files) {
    console.log(`Running SQL migration: ${file}`);
    const sql = readFileSync(join(sqlMigrationsDir, file), "utf8");
    await rawSql.unsafe(sql);
  }
} catch (e: any) {
  if (e.code !== "ENOENT") throw e;
  // migrations/ folder doesn't exist, skip
}

console.log("All migrations complete.");
process.exit(0);
