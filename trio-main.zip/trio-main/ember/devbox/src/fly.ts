import crypto from "crypto";

const FLY_API = "https://api.machines.dev";
const FLY_GQL = "https://api.fly.io/graphql";
const FLY_TOKEN = () => process.env.FLY_API_TOKEN!;
const FLY_ORG = () => process.env.FLY_ORG || "personal";
const APP_PREFIX = "ember-";
const MACHINE_HOST_SUFFIX = () => process.env.MACHINE_HOST_SUFFIX || ".fly.dev";

// Fly app names must be lowercase alphanumeric + hyphens.
const FLY_SAFE_CHARS = "0123456789abcdefghijklmnopqrstuvwxyz";

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function certificateReady(details: any): boolean {
  const status = String(details?.status || "").toLowerCase();
  return details?.configured === true && ["active", "ready", "issued"].includes(status);
}

function summarizeCertificateIssue(details: any): string {
  const status = details?.status || "unknown";
  const validationErrors = Array.isArray(details?.validation_errors) ? details.validation_errors.join("; ") : "";
  const cname = details?.dns_requirements?.cname ? ` cname=${details.dns_requirements.cname}` : "";
  const ownership = details?.dns_requirements?.ownership?.name
    ? ` ownership_txt=${details.dns_requirements.ownership.name}`
    : "";
  return [`status=${status}`, validationErrors, cname, ownership].filter(Boolean).join(" ");
}

export function flyAppId(length = 12): string {
  const bytes = crypto.randomBytes(length);
  return Array.from(bytes, (b) => FLY_SAFE_CHARS[b % FLY_SAFE_CHARS.length]).join("");
}

export function appName(id: string): string {
  return `${APP_PREFIX}${id}`;
}

export function machineHostname(flyAppName: string): string {
  return `${flyAppName}${MACHINE_HOST_SUFFIX()}`;
}

export function machineOrigin(flyAppName: string): string {
  return `https://${machineHostname(flyAppName)}`;
}

function machineFlyDevOrigin(flyAppName: string): string {
  return `https://${flyAppName}.fly.dev`;
}

// ── Fly API response types ──────────────────────────────────
export interface FlyApp {
  id: string;
  name: string;
  organization: { slug: string };
  status: string;
}

export interface FlyMachine {
  id: string;
  name: string;
  state: string;
  region: string;
  instance_id: string;
  config: Record<string, unknown>;
}

export interface FlyVolume {
  id: string;
  name: string;
  state: string;
  size_gb: number;
  region: string;
}

export interface FlyCertificate {
  id: string;
  hostname: string;
  configured: boolean;
  status: string;
  dns_requirements?: {
    cname?: string;
    ownership?: { name?: string };
  };
  validation_errors?: string[];
}

export async function flyApi<T = unknown>(path: string, method = "GET", body?: unknown): Promise<T | null> {
  const res = await fetch(`${FLY_API}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${FLY_TOKEN()}`,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    console.error(`[fly] ${method} ${path} -> ${res.status}: ${text.slice(0, 400)}`);
    return null;
  }

  const text = await res.text();
  if (!text) return { ok: true } as T;
  try {
    return JSON.parse(text) as T;
  } catch {
    return { ok: true } as T;
  }
}

export async function flyGraphQL(query: string, variables?: any) {
  const res = await fetch(FLY_GQL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${FLY_TOKEN()}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ query, variables }),
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) {
    console.error(`[fly-gql] ${res.status}`);
    return null;
  }
  return res.json();
}

export async function allocateIps(flyAppName: string) {
  const mutation = `mutation($input: AllocateIPAddressInput!) {
    allocateIpAddress(input: $input) { ipAddress { id address type } }
  }`;

  const v4 = await flyGraphQL(mutation, { input: { appId: flyAppName, type: "shared_v4" } });
  if (!v4 || v4.errors?.length) {
    throw new Error(`Failed to allocate IPv4 for ${flyAppName}: ${JSON.stringify(v4?.errors || "no response")}`);
  }

  const v6 = await flyGraphQL(mutation, { input: { appId: flyAppName, type: "v6" } });
  if (!v6 || v6.errors?.length) {
    throw new Error(`Failed to allocate IPv6 for ${flyAppName}: ${JSON.stringify(v6?.errors || "no response")}`);
  }
}

export interface CreateMachineOpts {
  flyAppName: string;
  region: string;
  size: string;
  machineType: "cli" | "vscode";
  machineToken: string;
  label: string;
  gitRepo?: string;
  gitToken?: string;
  imageDigest: string;
  apiUrl: string;
}

const GUEST: Record<string, any> = {
  "performance-4x": { cpu_kind: "performance", cpus: 4, memory_mb: 8192 },
  "performance-8x": { cpu_kind: "performance", cpus: 8, memory_mb: 16384 },
  "performance-16x": { cpu_kind: "performance", cpus: 16, memory_mb: 32768 },
};

export async function createFlyApp(flyAppName: string) {
  return flyApi("/v1/apps", "POST", { app_name: flyAppName, org_slug: FLY_ORG() });
}

// Request hostname cert provisioning. Called ONCE during machine creation.
// Does the ACME POST + initial polling. May take ~30s.
export async function provisionCustomHostname(
  flyAppName: string,
): Promise<{ ok: boolean; hostname: string; details?: any; reason?: string }> {
  const suffix = MACHINE_HOST_SUFFIX();
  const hostname = `${flyAppName}${suffix}`;

  if (suffix === ".fly.dev") {
    return { ok: true, hostname };
  }

  const requested = await flyApi(`/v1/apps/${flyAppName}/certificates/acme`, "POST", { hostname });
  if (!requested) {
    return {
      ok: false,
      hostname,
      reason: `Fly rejected certificate provisioning for ${hostname}`,
    };
  }

  let details = requested;
  if (certificateReady(details)) {
    return { ok: true, hostname, details };
  }

  const encodedHostname = encodeURIComponent(hostname);
  for (let attempt = 0; attempt < 15; attempt++) {
    await sleep(2000);
    const checked = await flyApi(`/v1/apps/${flyAppName}/certificates/${encodedHostname}/check`, "POST");
    if (checked) details = checked;
    if (certificateReady(details)) {
      return { ok: true, hostname, details };
    }
  }

  return {
    ok: false,
    hostname,
    details,
    reason: `Hostname ${hostname} is not ready: ${summarizeCertificateIssue(details)}`,
  };
}

// Check hostname status WITHOUT re-requesting ACME provisioning.
// This is the fast path for dashboard polling. No POST, no waiting.
// Exception: if the cert is completely absent (never provisioned, or Fly lost it),
// we do ONE ACME POST to re-request it. This handles the case where the initial
// request during create failed transiently.
export async function checkHostnameStatus(
  flyAppName: string,
): Promise<{ ok: boolean; hostname: string; reason?: string }> {
  const suffix = MACHINE_HOST_SUFFIX();
  const hostname = `${flyAppName}${suffix}`;

  if (suffix === ".fly.dev") {
    return { ok: true, hostname };
  }

  const encodedHostname = encodeURIComponent(hostname);
  const details = await flyApi(`/v1/apps/${flyAppName}/certificates/${encodedHostname}`);

  if (!details) {
    // Certificate doesn't exist at all. Re-request ACME provisioning once.
    // This is the only code path that re-POSTs; normal polls just read.
    console.log(`[fly] cert absent for ${hostname}, re-requesting ACME provisioning`);
    const requested = await flyApi(`/v1/apps/${flyAppName}/certificates/acme`, "POST", { hostname });
    if (!requested) {
      return { ok: false, hostname, reason: "Certificate absent and re-provisioning failed" };
    }
    if (certificateReady(requested)) {
      return { ok: true, hostname };
    }
    return { ok: false, hostname, reason: "Certificate re-requested, waiting for validation" };
  }

  if (certificateReady(details)) {
    return { ok: true, hostname };
  }
  return { ok: false, hostname, reason: summarizeCertificateIssue(details) };
}

export async function createVolume(flyAppName: string, region: string) {
  const vol = await flyApi<FlyVolume>(`/v1/apps/${flyAppName}/volumes`, "POST", {
    name: "workspace_data",
    region,
    size_gb: 50,
  });
  return vol?.id || null;
}

export async function createMachine(opts: CreateMachineOpts) {
  const guest = GUEST[opts.size] || GUEST["performance-8x"];

  let volId = await createVolume(opts.flyAppName, opts.region);
  if (!volId) {
    const vols = await flyApi<FlyVolume[]>(`/v1/apps/${opts.flyAppName}/volumes`);
    if (Array.isArray(vols) && vols.length) volId = vols[0].id;
  }
  if (!volId) throw new Error("Failed to create volume");

  const env: Record<string, string> = {
    EMBER_LABEL: opts.label,
    MACHINE_TOKEN: opts.machineToken,
    MACHINE_TYPE: opts.machineType,
    // INTERNAL_API_URL: used by machine for API calls (verify-code, startup, revoke).
    API_URL: process.env.INTERNAL_API_URL || opts.apiUrl,
    MACHINE_HOST_SUFFIX: MACHINE_HOST_SUFFIX(),
  };
  if (opts.gitRepo) env.GIT_REPO = opts.gitRepo;
  if (opts.gitToken) env.GIT_TOKEN = opts.gitToken;

  return flyApi<FlyMachine>(`/v1/apps/${opts.flyAppName}/machines`, "POST", {
    region: opts.region,
    config: {
      image: opts.imageDigest,
      env,
      guest,
      restart: { policy: "on-failure", max_retries: 3 },
      metadata: { "ember-label": opts.label },
      mounts: [{ volume: volId, path: "/workspace" }],
      services: [
        {
          ports: [
            { port: 443, handlers: ["tls", "http"] },
            { port: 80, handlers: ["http"] },
          ],
          protocol: "tcp",
          internal_port: 8080,
        },
      ],
      checks: {
        health: {
          type: "http",
          port: 8081,
          path: "/health",
          interval: 30_000_000_000,
          timeout: 5_000_000_000,
        },
      },
    },
  });
}

export async function startMachine(flyAppName: string, machineId: string) {
  return flyApi(`/v1/apps/${flyAppName}/machines/${machineId}/start`, "POST");
}

export async function stopMachine(flyAppName: string, machineId: string) {
  return flyApi(`/v1/apps/${flyAppName}/machines/${machineId}/stop`, "POST");
}

export async function destroyApp(flyAppName: string): Promise<{ ok: boolean; errors: string[] }> {
  const errors: string[] = [];
  try {
    const machines = await flyApi<FlyMachine[]>(`/v1/apps/${flyAppName}/machines`);
    if (Array.isArray(machines)) {
      for (const m of machines) {
        if (m.state === "running") {
          const stopped = await flyApi(`/v1/apps/${flyAppName}/machines/${m.id}/stop`, "POST");
          if (!stopped) errors.push(`Failed to stop machine ${m.id}`);
          await sleep(2000);
        }
        const deleted = await flyApi(`/v1/apps/${flyAppName}/machines/${m.id}`, "DELETE");
        if (!deleted) errors.push(`Failed to delete machine ${m.id}`);
      }
    }

    const vols = await flyApi<FlyVolume[]>(`/v1/apps/${flyAppName}/volumes`);
    if (Array.isArray(vols)) {
      for (const v of vols) {
        const deleted = await flyApi(`/v1/apps/${flyAppName}/volumes/${v.id}`, "DELETE");
        if (!deleted) errors.push(`Failed to delete volume ${v.id}`);
      }
    }

    if (MACHINE_HOST_SUFFIX() !== ".fly.dev") {
      const hostname = machineHostname(flyAppName);
      const certificates = await flyApi<{ certificates?: FlyCertificate[] }>(`/v1/apps/${flyAppName}/certificates?filter=${encodeURIComponent(hostname)}`);
      const hostnameExists = Array.isArray(certificates?.certificates)
        ? certificates.certificates.some((certificate) => certificate.hostname === hostname)
        : false;
      if (hostnameExists) {
        const removed = await flyApi(`/v1/apps/${flyAppName}/certificates/${encodeURIComponent(hostname)}`, "DELETE");
        if (!removed) {
          errors.push(`Failed to delete hostname ${hostname}`);
        }
      }
    }

    const appDeleted = await flyApi(`/v1/apps/${flyAppName}`, "DELETE");
    if (!appDeleted) errors.push(`Failed to delete app ${flyAppName}`);

    return { ok: errors.length === 0, errors };
  } catch (e: any) {
    errors.push(e.message);
    return { ok: false, errors };
  }
}

export async function getMachineState(flyAppName: string): Promise<string | null> {
  const machines = await flyApi<FlyMachine[]>(`/v1/apps/${flyAppName}/machines`);
  if (Array.isArray(machines) && machines.length) return machines[0].state;
  return null;
}

export async function revokeTerminalSessions(flyAppName: string, machineToken: string): Promise<boolean> {
  // Try internal 6PN first (fastest, doesn't traverse public internet),
  // then custom domain, then .fly.dev as fallback.
  const origins = [
    `http://${flyAppName}.internal:8080`,  // Fly 6PN private networking
    machineOrigin(flyAppName),
    machineFlyDevOrigin(flyAppName),
  ];
  for (const origin of origins) {
    try {
      const res = await fetch(`${origin}/internal/revoke`, {
        method: "POST",
        headers: { Authorization: `Bearer ${machineToken}` },
        signal: AbortSignal.timeout(5000),
      });
      if (res.ok) return true;
    } catch {
      // Try next origin
    }
  }
  return false;
}

// Upload a file to a machine's /workspace/uploads/ directory.
// Sends raw file bytes with filename in header. Auth via machine token.
export async function uploadFileToMachine(
  flyAppName: string,
  machineToken: string,
  filename: string,
  fileBuffer: Buffer,
): Promise<{ ok: boolean; path?: string; size?: number; error?: string }> {
  const origins = [
    `http://${flyAppName}.internal:8080`,
    machineOrigin(flyAppName),
    machineFlyDevOrigin(flyAppName),
  ];
  let lastError = "Could not reach machine";
  for (const origin of origins) {
    try {
      const safeFilename = filename.replace(/[\r\n\x00-\x1f]/g, "");
      const res = await fetch(`${origin}/internal/upload`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${machineToken}`,
          "X-Filename": safeFilename,
          "Content-Type": "application/octet-stream",
          "Content-Length": String(fileBuffer.length),
        },
        body: new Uint8Array(fileBuffer),
        signal: AbortSignal.timeout(30000),
      });
      if (res.ok) {
        const data: { path?: string; size?: number } = await res.json();
        return { ok: true, path: data.path, size: data.size };
      }
      // Auth failure is definitive (same machine, wrong token) - don't retry
      if (res.status === 401 || res.status === 403) {
        const errData: { error?: string } = await res.json().catch(() => ({}));
        return { ok: false, error: errData.error || `HTTP ${res.status}` };
      }
      // Other HTTP errors (500, 502, etc.): try next origin
      lastError = `HTTP ${res.status} from ${origin}`;
    } catch {
      // Network error: try next origin
      lastError = `Network error reaching ${origin}`;
    }
  }
  return { ok: false, error: lastError };
}

// List all Fly apps in our org that match the ember prefix.
// Used by reconciler to find Fly-side orphans that have no DB record.
export async function listOrgApps(): Promise<string[]> {
  const query = `query($org: String!) {
    organization(slug: $org) {
      apps { nodes { name } }
    }
  }`;
  const result = await flyGraphQL(query, { org: FLY_ORG() });
  if (!result?.data?.organization?.apps?.nodes) return [];
  return result.data.organization.apps.nodes
    .map((n: any) => n.name as string)
    .filter((name: string) => name.startsWith(APP_PREFIX));
}
