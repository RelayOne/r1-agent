-- Backfill opening ledger entries for existing users with nonzero credits_cents.
-- This ensures the audit view (SUM(amount_cents) vs credits_cents) starts balanced
-- on databases upgraded from before the credit ledger existed.
-- Idempotent: ON CONFLICT DO NOTHING prevents double-insertion.

INSERT INTO credit_transactions (idempotency_key, user_id, type, amount_cents, balance_after_cents, metadata)
SELECT
  'opening_balance_' || id,
  id,
  'opening_balance',
  credits_cents,
  credits_cents,
  '{"source": "migration_004_backfill"}'::jsonb
FROM users
WHERE credits_cents != 0
ON CONFLICT DO NOTHING;
