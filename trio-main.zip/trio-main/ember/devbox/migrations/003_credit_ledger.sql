-- Credit ledger + worker allocations migration
-- Enables burst workers billed against prepaid credits, fully decoupled from slot subscriptions.
-- Source of truth: credit_transactions (append-only ledger).
-- Fast path: users.credits_cents (materialized balance for atomic deductions).

-- Prevent negative credits at the database level
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'users_credits_cents_non_negative') THEN
    ALTER TABLE users ADD CONSTRAINT users_credits_cents_non_negative CHECK (credits_cents >= 0) NOT VALID;
    ALTER TABLE users VALIDATE CONSTRAINT users_credits_cents_non_negative;
  END IF;
END $$;

-- Transaction types
DO $$ BEGIN
  CREATE TYPE credit_transaction_type AS ENUM (
    'topup',              -- Stripe credit purchase
    'worker_debit',       -- Credits consumed by burst worker
    'worker_refund',      -- Refund for failed/cancelled worker
    'admin_adjustment',   -- Manual support adjustment
    'promotional_grant',  -- Free credits (beta, referral)
    'opening_balance'     -- Backfill from pre-ledger credits_cents
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Worker lifecycle states
DO $$ BEGIN
  CREATE TYPE worker_allocation_status AS ENUM (
    'pending', 'active', 'completed', 'failed', 'expired', 'cancelled'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Append-only credit ledger (source of truth)
CREATE TABLE IF NOT EXISTS credit_transactions (
  id                  BIGSERIAL PRIMARY KEY,
  idempotency_key     TEXT NOT NULL,
  user_id             TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  type                credit_transaction_type NOT NULL,
  amount_cents        INTEGER NOT NULL,       -- positive=added, negative=consumed
  balance_after_cents INTEGER NOT NULL,       -- snapshot for point-in-time queries
  worker_allocation_id UUID NULL,
  metadata            JSONB NOT NULL DEFAULT '{}',
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_credit_txn_user_created
  ON credit_transactions (user_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_credit_txn_idempotency
  ON credit_transactions (user_id, idempotency_key);
CREATE INDEX IF NOT EXISTS idx_credit_txn_worker
  ON credit_transactions (worker_allocation_id) WHERE worker_allocation_id IS NOT NULL;

-- Worker allocation lifecycle tracking
CREATE TABLE IF NOT EXISTS worker_allocations (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  status                worker_allocation_status NOT NULL DEFAULT 'pending',
  worker_type           TEXT NOT NULL,
  cost_cents            INTEGER NOT NULL CHECK (cost_cents > 0),
  expires_at            TIMESTAMPTZ NOT NULL,
  worker_instance_id    TEXT NULL,         -- set after provisioning succeeds
  task_description      TEXT NULL,
  error                 TEXT NULL,
  metadata              JSONB NOT NULL DEFAULT '{}',
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  started_at            TIMESTAMPTZ NULL,
  completed_at          TIMESTAMPTZ NULL,
  credit_transaction_id BIGINT NULL REFERENCES credit_transactions(id)
);

CREATE INDEX IF NOT EXISTS idx_alloc_expires
  ON worker_allocations (expires_at) WHERE status IN ('pending', 'active');
CREATE INDEX IF NOT EXISTS idx_alloc_user_status
  ON worker_allocations (user_id, status) WHERE status IN ('pending', 'active');

-- Stripe webhook idempotency
CREATE TABLE IF NOT EXISTS processed_stripe_events (
  event_id       TEXT PRIMARY KEY,
  classification TEXT NOT NULL,
  processed_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Atomic allocation function: deducts credits + creates allocation + logs in one transaction.
-- Race-safe: UPDATE WHERE credits >= cost acquires row lock, re-evaluates after contention.
CREATE OR REPLACE FUNCTION allocate_burst_worker(
  p_user_id TEXT, p_idempotency_key TEXT, p_worker_type TEXT,
  p_cost_cents INTEGER, p_ttl_minutes INTEGER DEFAULT 10,
  p_task_description TEXT DEFAULT NULL, p_metadata JSONB DEFAULT '{}'
) RETURNS TABLE (
  allocation_id UUID, credits_remaining INTEGER,
  expires_at TIMESTAMPTZ, was_duplicate BOOLEAN
) LANGUAGE plpgsql AS $$
DECLARE
  v_alloc_id UUID; v_new_balance INTEGER;
  v_expires TIMESTAMPTZ; v_txn_id BIGINT;
BEGIN
  -- Idempotency: return existing if already processed for this user
  IF EXISTS (SELECT 1 FROM credit_transactions
             WHERE idempotency_key = p_idempotency_key AND user_id = p_user_id) THEN
    RETURN QUERY SELECT wa.id, u.credits_cents::INTEGER, wa.expires_at, TRUE
      FROM credit_transactions ct
      JOIN worker_allocations wa ON wa.id = ct.worker_allocation_id
      JOIN users u ON u.id = ct.user_id
      WHERE ct.idempotency_key = p_idempotency_key AND ct.user_id = p_user_id LIMIT 1;
    RETURN;
  END IF;

  -- Atomic deduct
  UPDATE users SET credits_cents = credits_cents - p_cost_cents
    WHERE id = p_user_id AND credits_cents >= p_cost_cents
    RETURNING credits_cents INTO v_new_balance;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Insufficient credits' USING ERRCODE = 'check_violation';
  END IF;

  v_alloc_id := gen_random_uuid();
  v_expires := now() + (p_ttl_minutes || ' minutes')::INTERVAL;

  INSERT INTO worker_allocations
    (id, user_id, status, worker_type, cost_cents, expires_at,
     task_description, metadata)
    VALUES (v_alloc_id, p_user_id, 'pending', p_worker_type,
            p_cost_cents, v_expires, p_task_description, p_metadata);

  INSERT INTO credit_transactions
    (idempotency_key, user_id, type, amount_cents,
     balance_after_cents, worker_allocation_id, metadata)
    VALUES (p_idempotency_key, p_user_id, 'worker_debit',
            -p_cost_cents, v_new_balance, v_alloc_id, p_metadata)
    RETURNING id INTO v_txn_id;

  UPDATE worker_allocations SET credit_transaction_id = v_txn_id
    WHERE id = v_alloc_id;

  RETURN QUERY SELECT v_alloc_id, v_new_balance, v_expires, FALSE;
END; $$;

-- Atomic refund for failed/cancelled workers
CREATE OR REPLACE FUNCTION refund_burst_worker(
  p_allocation_id UUID, p_idempotency_key TEXT,
  p_reason TEXT DEFAULT 'Worker failed before completing task'
) RETURNS TABLE (credits_remaining INTEGER, was_duplicate BOOLEAN)
LANGUAGE plpgsql AS $$
DECLARE v_user_id TEXT; v_cost INTEGER; v_new_balance INTEGER;
BEGIN
  IF EXISTS (SELECT 1 FROM credit_transactions ct
             JOIN worker_allocations wa ON wa.id = ct.worker_allocation_id
             WHERE ct.idempotency_key = p_idempotency_key
               AND wa.id = p_allocation_id) THEN
    SELECT u.credits_cents::INTEGER INTO v_new_balance FROM worker_allocations wa
      JOIN users u ON u.id = wa.user_id WHERE wa.id = p_allocation_id;
    RETURN QUERY SELECT v_new_balance, TRUE; RETURN;
  END IF;

  SELECT user_id, cost_cents INTO v_user_id, v_cost
    FROM worker_allocations WHERE id = p_allocation_id
    AND status NOT IN ('completed', 'failed', 'expired', 'cancelled') FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Cannot refund allocation % (already finalized)', p_allocation_id; END IF;

  UPDATE users SET credits_cents = credits_cents + v_cost
    WHERE id = v_user_id RETURNING credits_cents INTO v_new_balance;
  INSERT INTO credit_transactions
    (idempotency_key, user_id, type, amount_cents,
     balance_after_cents, worker_allocation_id, metadata)
    VALUES (p_idempotency_key, v_user_id, 'worker_refund',
            v_cost, v_new_balance, p_allocation_id,
            jsonb_build_object('reason', p_reason));
  UPDATE worker_allocations SET status = 'failed', completed_at = now()
    WHERE id = p_allocation_id;

  RETURN QUERY SELECT v_new_balance, FALSE;
END; $$;

-- Audit view: detects balance/ledger drift
CREATE OR REPLACE VIEW credit_balance_audit AS
SELECT u.id AS user_id, u.credits_cents AS current_balance,
  COALESCE(SUM(ct.amount_cents), 0)::INTEGER AS calculated_balance,
  u.credits_cents - COALESCE(SUM(ct.amount_cents), 0)::INTEGER AS discrepancy
FROM users u LEFT JOIN credit_transactions ct ON ct.user_id = u.id
GROUP BY u.id, u.credits_cents
HAVING u.credits_cents != COALESCE(SUM(ct.amount_cents), 0)::INTEGER;
