import { defineConfig } from "vitest/config";
import { fileURLToPath } from "url";
import { dirname, resolve } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  root: resolve(__dirname),
  test: {
    globals: true,
    environment: "node",
    include: ["src/__tests__/**/*.test.ts"],
    setupFiles: ["src/__tests__/setup.ts"],
    testTimeout: 30_000,
    hookTimeout: 30_000,
    // Single-threaded: all test files share one DB connection pool.
    // Prevents deadlocks from concurrent TRUNCATE + INSERT across forks.
    pool: "threads",
    threads: { singleThread: true },
    fileParallelism: false,
  },
});
