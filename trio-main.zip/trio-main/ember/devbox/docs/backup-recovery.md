# Backup & Disaster Recovery

## Backup targets

| Data | Location | Strategy | Retention |
|------|----------|----------|-----------|
| Postgres (users, billing, sessions) | Fly Postgres | Fly daily snapshots + WAL archiving | 30 days |
| /workspace volumes (user code) | Fly volumes | Fly volume snapshots | 5 days default, extend to 14 |
| Stripe billing data | Stripe | Stripe is the source of truth | Stripe retention policy |
| GitHub tokens (encrypted) | Postgres | Covered by Postgres backup | See Postgres |
| Machine image | Container registry | Pinned by digest, immutable | Registry retention |

## Postgres backup

Fly Postgres provides daily snapshots. Verify with:

```bash
fly postgres backup list --app ember-db
```

### Extend retention to 30 days

```bash
fly postgres config update --app ember-db --snapshot-retention 30
```

### Manual backup before risky operations

```bash
fly postgres backup create --app ember-db
```

### WAL archiving (point-in-time recovery)

Fly Postgres supports WAL archiving on HA clusters. For the paid beta, daily snapshots are sufficient. Before scaling:

```bash
fly postgres create --name ember-db --region sjc --ha
```

## Volume backup

Fly takes daily volume snapshots (default 5 days retention).

```bash
# List snapshots for a machine's volume
fly volumes list --app ember-<machine-id>
fly volumes snapshots list <volume-id>
```

### Extend retention

Currently Fly doesn't support configuring volume snapshot retention via CLI. For critical user data, implement application-level backup:

1. Add a `/workspace/.ember-backup` cron inside the machine image
2. Use `restic` or `rclone` to push incremental backups to S3/R2
3. Configure in startup script for users who opt in

## Restore procedures

### Database restore

```bash
# 1. List available backups
fly postgres backup list --app ember-db

# 2. Restore to a new cluster (non-destructive)
fly postgres backup restore <backup-id> --app ember-db-restore

# 3. Verify data
psql "$(fly postgres connect --app ember-db-restore --url)" -c "SELECT count(*) FROM users"

# 4. If verified, swap connection strings
fly secrets set DATABASE_URL="<new-connection-string>" --app ember-api

# 5. Run any pending migrations
fly ssh console --app ember-api -C "node dist/migrate.js"
```

### Single workspace restore

```bash
# 1. Find the volume
fly volumes list --app ember-<machine-id>

# 2. List snapshots
fly volumes snapshots list <volume-id>

# 3. Create a new volume from snapshot
fly volumes create workspace_data --snapshot-id <snapshot-id> --app ember-<machine-id> --region <region>

# 4. Stop the machine, swap volumes, restart
```

### Full disaster recovery

1. Create new Fly Postgres from latest backup
2. Deploy API with new DATABASE_URL
3. Run migrations
4. For each user machine:
   - If volume snapshot exists: restore from snapshot
   - If not: machine must be recreated (user loses workspace data)
5. Run `/api/billing/reconcile` to sync Stripe state
6. Verify terminal auth works end-to-end

## Retention and deletion

| Data | Retention | Deletion trigger |
|------|-----------|-----------------|
| User account data | Until account deletion | User request or 90 days after ban |
| Billing events | 7 years (legal/tax) | Never auto-deleted |
| Cancelled slots | 1 year | Purge job |
| Deleted machines | 90 days (soft-delete) | Purge job |
| Terminal sessions | 90 days | Purge job |
| Exchange codes | 1 hour | Reconciler |
| Password reset tokens | 24 hours | Reconciler |
| Audit log | 2 years | Purge job |
| Startup scripts | Until account deletion | User request |
| OAuth tokens (encrypted) | Until disconnect/deletion | User action |

## Testing backup/restore

**Monthly drill:**

1. Restore Postgres to a staging cluster
2. Restore one volume from snapshot
3. Boot the staging API against restored DB
4. Verify: user login, billing state, machine list, terminal connect
5. Document results in `#ops-drills` channel
