# Observability & Runbooks

## SLOs

| Service | SLI | Target | Measurement |
|---------|-----|--------|-------------|
| API availability | `GET /api/health` returns 200 | 99.9% (43 min/month downtime) | Uptime monitor (Fly health check or external) |
| Machine creation | Create returns 201 within 60s | 95% success rate | Log `[create]` outcomes |
| Terminal connect | Exchange code + cookie set within 5s | 98% success rate | Log `verify-code` outcomes |
| Webhook processing | Stripe webhook returns 200 | 99.5% | Stripe dashboard delivery rate |
| Reconciler cycle | Completes without error | 99% per run | Log `[reconcile]` outcomes |
| Machine cleanup | `needs_stop` duration < 5 min | 95% of cases | `/api/health/detailed` alerts |

## Alerting

### Critical (page immediately)

| Alert | Condition | Source |
|-------|-----------|--------|
| API down | `/api/health` fails 3 consecutive checks | Uptime monitor |
| Webhook failures | Stripe delivery rate < 95% over 1 hour | Stripe dashboard |
| DB connection failure | API logs `ECONNREFUSED` on port 5432 | Log pattern |
| Encryption key missing | `APP_ENCRYPTION_KEY is required` in logs | Log pattern |
| Production config invalid | Startup crash with `Invalid production configuration` | Log pattern |

### High (respond within 1 hour)

| Alert | Condition | Source |
|-------|-----------|--------|
| `needs_stop` machines | `machines.needs_stop > 0` for > 10 min | `/api/health/detailed` |
| `error` machines | `machines.error > 0` | `/api/health/detailed` |
| Orphaned Fly resources | `FLY_ORPHAN` or `ORPHANED FLY RESOURCES` in logs | Log pattern |
| Stripe compensation failure | `COMPENSATION FAILED` in logs | Log pattern |
| Certificate provisioning failure | `hostname_status = 'failed'` | DB query or `/api/health/detailed` |

### Medium (respond within 1 business day)

| Alert | Condition | Source |
|-------|-----------|--------|
| GitHub API failures | > 5 GitHub API errors in 1 hour | Log pattern `[github]` |
| Terminal verify failures | > 10 verify-code 401s in 1 hour | Log pattern |
| High rate limit hits | > 100 429 responses in 1 hour | Log pattern |
| Expired purchase intents | > 10 expired intents in 1 day | Reconciler output |

### Monitoring endpoint

`GET /api/health/detailed` (requires `Authorization: Bearer $RECONCILE_SECRET`):

```json
{
  "status": "ok | degraded",
  "users": 42,
  "machines": { "total": 10, "running": 5, "needs_stop": 0, "error": 0 },
  "slots": { "active": 8, "cancelled": 2 },
  "alerts": ["2 machines in error state"]
}
```

Poll every 60 seconds. Alert on `status: "degraded"` or non-empty `alerts`.

## Runbooks

### Stripe outage

**Symptoms:** Webhooks stop arriving, billing API calls fail.

1. Check [status.stripe.com](https://status.stripe.com)
2. Stripe retries failed webhooks for up to 3 days
3. Do NOT retry billing operations manually
4. When Stripe recovers, run `/api/billing/reconcile` to sync state
5. Verify: check `/api/health/detailed` for orphaned slots

### Fly API outage

**Symptoms:** Machine creation/start/stop fails with 502, health check shows error machines.

1. Check [community.fly.io/c/status](https://community.fly.io/c/status)
2. Existing running machines continue to work (Fly Proxy is separate from API)
3. Do NOT attempt bulk operations during outage
4. When recovered:
   - Run `/api/billing/reconcile` to detect drift
   - Check for `error` and `needs_stop` machines in admin panel
   - Manually clean up any orphaned apps via `flyctl`

### DNS/certificate delay

**Symptoms:** New machines show `hostname_status: pending`, terminals fail to connect.

1. Check DNS propagation: `dig +short <machine>.ember.dev`
2. Check cert status via Fly API:
   ```bash
   fly certs show <machine-app-name>
   ```
3. If DNS is correct but cert is pending, wait (can take up to 30 minutes)
4. If DNS is wrong, fix the CNAME record and re-run cert provisioning:
   ```bash
   fly certs add <hostname> --app <machine-app-name>
   ```

### Orphan cleanup

**Symptoms:** `ORPHANED FLY RESOURCES` in logs, or `/api/health/detailed` shows `error` machines.

1. List machines in error state:
   ```sql
   SELECT id, fly_app_name, state, updated_at FROM machines
   WHERE state = 'error' AND deleted_at IS NULL;
   ```
2. For each, check if the Fly app still exists:
   ```bash
   fly apps list --org ember-prod | grep <fly-app-name>
   ```
3. If app exists: destroy manually
   ```bash
   fly apps destroy <fly-app-name> --yes
   ```
4. Update DB:
   ```sql
   UPDATE machines SET state = 'deleted', deleted_at = NOW(), slot_id = NULL
   WHERE id = '<machine-id>';
   ```

### Database restore

See [backup-recovery.md](./backup-recovery.md).

### Key rotation

See [secrets-rotation.md](./secrets-rotation.md).

## Structured logging

All log messages follow patterns for grep/alerting:

| Pattern | Meaning |
|---------|---------|
| `[create]` | Machine creation flow |
| `[billing]` | Billing/Stripe operations |
| `[webhook]` | Stripe webhook processing |
| `[reconcile]` | Reconciler cycle |
| `[fly]` | Fly API calls |
| `[github]` | GitHub API calls |
| `[auth-proxy]` | Terminal auth proxy |
| `[csrf]` | CSRF protection blocks |
| `ORPHANED FLY RESOURCES` | Failed cleanup (needs manual action) |
| `COMPENSATION FAILED` | Stripe/DB drift (needs manual action) |
| `FLY_ORPHAN` | DB/Fly state mismatch |

## Request correlation

Every API response includes `X-Request-Id`. Use this to trace a request through logs:

```bash
grep "abc123-request-id" /var/log/ember/*.log
```

For webhook processing, the Stripe event ID serves as the correlation ID:

```bash
grep "evt_1234567890" /var/log/ember/*.log
```
