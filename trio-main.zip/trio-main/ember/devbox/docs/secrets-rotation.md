# Secrets Management & Key Rotation

## Secret inventory

| Secret | Storage | Rotation frequency | Impact of leak |
|--------|---------|-------------------|----------------|
| `APP_ENCRYPTION_KEY` | Fly secrets | Manual, on compromise | All encrypted OAuth tokens exposed |
| `FLY_API_TOKEN` | Fly secrets | 90 days or on compromise | Full org access: create/destroy any app |
| `STRIPE_SECRET_KEY` | Fly secrets | On compromise | Billing control, customer data |
| `STRIPE_WEBHOOK_SECRET` | Fly secrets | On webhook endpoint change | Webhook spoofing |
| `RECONCILE_SECRET` | Fly secrets | 90 days | Reconciler/monitoring access |
| `GITHUB_CLIENT_SECRET` | Fly secrets | On compromise | OAuth token issuance |
| `GOOGLE_CLIENT_SECRET` | Fly secrets | On compromise | OAuth token issuance |
| `GITHUB_APP_PRIVATE_KEY` | Fly secrets | Yearly or on compromise | Installation token issuance |
| `MACHINE_TOKEN` (per machine) | Fly machine env | Per machine lifecycle | Terminal auth + API access for one machine |

## Rotation procedures

### APP_ENCRYPTION_KEY rotation

The encryption key protects OAuth tokens at rest. Rotation requires re-encrypting all stored tokens.

```bash
# 1. Generate new key
NEW_KEY=$(openssl rand -hex 32)

# 2. Add rotation script (one-time)
fly ssh console --app ember-api -C "
  OLD_KEY=\$APP_ENCRYPTION_KEY
  APP_ENCRYPTION_KEY=\$NEW_KEY node -e '
    // Re-encrypt all oauth_accounts.access_token and refresh_token
    // Script reads with OLD_KEY, writes with NEW_KEY
    // Implementation: iterate oauth_accounts, decrypt with old, encrypt with new
  '
"

# 3. Update the secret
fly secrets set APP_ENCRYPTION_KEY=$NEW_KEY --app ember-api

# 4. Deploy (process restart picks up new key)
fly deploy --app ember-api
```

**Future improvement:** Support versioned keys (`enc:v2:...` prefix) so old and new keys can coexist during rotation. The `secrets.ts` `ENC_PREFIX` already supports this pattern.

### FLY_API_TOKEN rotation

```bash
# 1. Create new token
NEW_TOKEN=$(fly tokens create org ember-prod --expiry 90d)

# 2. Set new token (takes effect on next deploy/restart)
fly secrets set FLY_API_TOKEN=$NEW_TOKEN --app ember-api

# 3. Verify: create a test machine, then delete it
curl -X POST https://app.ember.dev/api/health/detailed \
  -H "Authorization: Bearer $RECONCILE_SECRET"

# 4. Revoke old token (if possible via Fly dashboard)
```

### RECONCILE_SECRET rotation

```bash
NEW_SECRET=$(openssl rand -hex 32)
fly secrets set RECONCILE_SECRET=$NEW_SECRET --app ember-api
# Update monitoring/cron configs with new secret
```

### MACHINE_TOKEN rotation (per machine)

Machine tokens are generated at creation time and baked into Fly machine env. To rotate:

1. Stop the machine
2. Update the machine config with a new token via Fly API
3. Update the DB row
4. Start the machine

For banned users, we destroy the machine entirely (which is more thorough than rotation).

## Supply chain security

### Base image pinning

`machine-image/Dockerfile` should pin base images by digest:

```dockerfile
# Instead of:
FROM ubuntu:24.04
# Use:
FROM ubuntu:24.04@sha256:<digest>
```

Update digests monthly or when security advisories are published.

### Dependency scanning

```bash
# npm audit
npm audit --production

# Snyk (if configured)
npx snyk test

# GitHub Dependabot: enable in repo settings
```

### SBOM generation

```bash
# Generate SBOM for the API
npx @cyclonedx/cyclonedx-npm --output-file sbom-api.json

# Generate SBOM for machine image
docker sbom ember-machine:latest --format cyclonedx-json > sbom-machine.json
```

### Image scanning

```bash
# Trivy
trivy image ember-api:latest
trivy image ember-machine:latest

# Grype
grype ember-api:latest
```

### Secret scanning

Enable in GitHub repo settings:
- **Secret scanning**: detects committed secrets
- **Push protection**: blocks pushes containing secrets
- **Dependabot security updates**: auto-PRs for vulnerable deps

### Binary verification in machine image

```dockerfile
# In machine-image/Dockerfile, verify downloaded binaries:
RUN curl -fsSL https://github.com/nicm/tmux/releases/... -o tmux.tar.gz \
    && echo "<expected-sha256>  tmux.tar.gz" | sha256sum -c - \
    && tar xzf tmux.tar.gz
```

## Incident response for key compromise

1. **Immediate:** Rotate the compromised key (see procedures above)
2. **Assess:** Determine blast radius using audit log
3. **Notify:** If user data affected, notify affected users within 72 hours
4. **Review:** Post-incident review, update rotation schedule
5. **Document:** Add to incident log with timeline and remediation steps
