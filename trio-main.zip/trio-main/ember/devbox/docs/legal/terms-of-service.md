# Terms of Service

**Last updated:** [DATE]

## 1. Agreement

By using Ember Cloud ("Service"), you agree to these Terms of Service ("Terms"). The Service is operated by [COMPANY_NAME] ("we", "us").

## 2. Service description

Ember Cloud provides cloud-based development machines accessible via web browser. Each machine includes a terminal, persistent workspace storage, and developer tools.

## 3. Accounts

- You must provide accurate information when creating an account.
- You are responsible for maintaining the security of your account credentials.
- You must be at least 18 years old to use the Service.
- One person or entity per account. Sharing accounts is not permitted.

## 4. Billing

- The Service is billed on a subscription basis as described on our pricing page.
- Subscriptions are billed monthly in advance via Stripe.
- You may cancel at any time. Cancellation takes effect at the end of the current billing period.
- Running machines are stopped when a subscription is cancelled or payment fails.
- We do not provide prorated refunds for partial months unless required by law.
- Refund requests for billing errors should be sent to [SUPPORT_EMAIL] within 30 days.

## 5. Acceptable use

You agree NOT to:
- Use the Service for illegal activities
- Run cryptocurrency mining workloads
- Host public-facing production services (the machines are for development)
- Attempt to circumvent resource limits or billing
- Use the Service to attack, scan, or probe other systems
- Store or process regulated data (HIPAA, PCI, etc.) without our written agreement
- Share machine access credentials with unauthorized parties

## 6. Data and privacy

- Your workspace data is stored on persistent volumes in the region you select.
- We do not access your workspace content except as needed for support (with your permission) or to enforce these Terms.
- See our Privacy Policy for details on data collection and processing.

## 7. Service availability

- We target 99.9% API availability but do not guarantee it.
- Machines may be stopped or restarted for maintenance with reasonable notice.
- We are not liable for data loss on workspace volumes. You are responsible for backing up your work.

## 8. Termination

- You may delete your account at any time.
- We may suspend or terminate accounts that violate these Terms.
- On termination, your machines are destroyed and workspace data is deleted within 30 days.

## 9. Limitation of liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW, OUR LIABILITY IS LIMITED TO THE AMOUNT YOU PAID US IN THE 12 MONTHS PRECEDING THE CLAIM. WE ARE NOT LIABLE FOR INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES.

## 10. Changes

We may update these Terms. Material changes will be communicated via email or in-app notice at least 30 days before taking effect.

## 11. Contact

[SUPPORT_EMAIL]
