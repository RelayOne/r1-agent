# Privacy Policy

**Last updated:** [DATE]

## 1. Who we are

[COMPANY_NAME] operates Ember Cloud. Contact: [PRIVACY_EMAIL].

## 2. Data we collect

| Data | Purpose | Legal basis | Retention |
|------|---------|-------------|-----------|
| Email address | Account, billing, notifications | Contract performance | Until account deletion |
| Name | Display in UI | Contract performance | Until account deletion |
| Password hash | Authentication | Contract performance | Until account deletion |
| OAuth identifiers (GitHub, Google) | Authentication, repo access | Consent (OAuth grant) | Until disconnect or account deletion |
| GitHub access tokens (encrypted) | Private repo cloning | Consent (explicit connect flow) | Until disconnect or account deletion |
| Stripe customer/subscription IDs | Billing | Contract performance | 7 years (tax/legal) |
| IP address | Rate limiting, abuse prevention, audit | Legitimate interest | 90 days in audit log |
| Machine metadata (name, region, size) | Service delivery | Contract performance | Until machine deletion + 90 days |
| Workspace data (files on /workspace) | Service delivery | Contract performance | Until machine destruction |
| Terminal session records | Security, abuse detection | Legitimate interest | 90 days |

## 3. Data we do NOT collect

- We do not read or analyze the contents of your /workspace files
- We do not track your terminal commands or output
- We do not sell personal data to third parties
- We do not use your data for advertising

## 4. Subprocessors

| Processor | Purpose | Location |
|-----------|---------|----------|
| Fly.io | Machine hosting, volumes | US (configurable region) |
| Stripe | Payment processing | US |
| GitHub | OAuth authentication, repo access | US |
| Google | OAuth authentication | US |
| [EMAIL_PROVIDER] | Transactional email | [LOCATION] |
| Fly Postgres | Database hosting | US (configurable region) |

## 5. Data security

- OAuth tokens are encrypted at rest using AES-256-GCM
- Passwords are hashed with Argon2id
- All traffic is encrypted in transit (TLS)
- Terminal sessions use HMAC-signed cookies with 24-hour expiry
- Admin access requires authentication and is audit-logged

## 6. Your rights

Depending on your jurisdiction (GDPR, CCPA, etc.), you may have the right to:

- **Access:** Request a copy of your data
- **Correction:** Update inaccurate data
- **Deletion:** Request account and data deletion
- **Portability:** Export your data in a standard format
- **Restriction:** Limit processing of your data
- **Objection:** Object to processing based on legitimate interest

To exercise these rights, contact [PRIVACY_EMAIL]. We respond within 30 days.

## 7. Data export

You can export your data via:

- **Workspace files:** Download from your machine's terminal (scp, rsync, git push)
- **Account data:** Request via [PRIVACY_EMAIL] or the account settings data export feature
- **Billing history:** Available in Settings or via Stripe customer portal

## 8. Account deletion

When you delete your account:

1. All machines are destroyed immediately (workspace data deleted)
2. OAuth tokens are deleted
3. Personal data is deleted within 30 days
4. Billing records are retained for 7 years (legal requirement)
5. Audit log entries are anonymized after 90 days

## 9. Cookies

We use only essential cookies:

| Cookie | Purpose | Duration |
|--------|---------|----------|
| `lucia_session` | App authentication | Session (renewed on activity) |
| `ember_session` | Terminal authentication | 24 hours |
| OAuth state cookies | CSRF protection during OAuth | 10 minutes |

We do not use analytics, tracking, or advertising cookies.

## 10. Children

The Service is not intended for users under 18. We do not knowingly collect data from minors.

## 11. Changes

Material changes to this policy will be communicated via email at least 30 days before taking effect.

## 12. Contact

Data protection inquiries: [PRIVACY_EMAIL]
