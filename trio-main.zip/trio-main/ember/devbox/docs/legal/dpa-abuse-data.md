# Data Processing Agreement (DPA)

**Template for business/team customers.**

This DPA supplements the Terms of Service between [COMPANY_NAME] ("Processor") and the customer ("Controller") and governs the processing of personal data.

## 1. Definitions

- **Personal Data:** Any data relating to an identified or identifiable natural person
- **Processing:** Any operation performed on Personal Data
- **Subprocessor:** A third party engaged by Processor to process Personal Data

## 2. Scope

Processor processes Personal Data solely to provide the Ember Cloud service as described in the Terms of Service.

## 3. Processor obligations

- Process Personal Data only on documented instructions from Controller
- Ensure personnel are bound by confidentiality obligations
- Implement appropriate technical and organizational security measures
- Engage subprocessors only with prior notice (see Privacy Policy subprocessor list)
- Assist Controller with data subject requests within 30 days
- Delete or return Personal Data on termination, subject to legal retention requirements
- Make available information necessary to demonstrate compliance

## 4. Security measures

- Encryption at rest (AES-256-GCM) for sensitive credentials
- Encryption in transit (TLS 1.2+)
- Access controls (role-based, session-based)
- Audit logging
- Regular backups with tested restore procedures
- Incident response plan

## 5. Breach notification

Processor will notify Controller of a Personal Data breach without undue delay and within 72 hours of becoming aware.

## 6. Data transfers

Personal Data may be transferred to the US (Fly.io, Stripe, GitHub, Google). Transfers rely on Standard Contractual Clauses (SCCs) or equivalent mechanisms.

## 7. Term

This DPA remains in effect for the duration of the service agreement plus 90 days for data deletion.

---

# Abuse Policy

## Prohibited uses

1. Cryptocurrency mining
2. DDoS attacks or network scanning
3. Hosting malware or phishing sites
4. Spamming or bulk unsolicited messaging
5. Circumventing billing or resource limits
6. Storing CSAM or other illegal content
7. Using machines as proxies for illegal activity

## Enforcement

1. **Warning:** For first-time, non-malicious violations
2. **Suspension:** Machines stopped, account suspended pending review
3. **Termination:** Account banned, all machines destroyed, no refund

## Reporting

Report abuse to [ABUSE_EMAIL]. Include the machine hostname or user email if known.

## Incident response contacts

| Role | Contact |
|------|---------|
| Security incidents | [SECURITY_EMAIL] |
| Abuse reports | [ABUSE_EMAIL] |
| Privacy/GDPR requests | [PRIVACY_EMAIL] |
| Billing disputes | [SUPPORT_EMAIL] |

---

# Data Export & Account Deletion

## Self-service data export

Users can export their data through:

### Workspace files
```bash
# From within the terminal
tar czf /workspace/export.tar.gz /workspace/
# Then download via scp or push to git
```

### Account data
`GET /api/account/export` (authenticated) returns a JSON file containing:
- User profile (email, name, creation date)
- Billing history (events, not card details)
- Machine list (names, regions, creation dates)
- Slot history
- OAuth connections (providers, not tokens)
- Audit log entries

### Billing data
Accessible via Stripe Customer Portal (link in Settings).

## Account deletion

`DELETE /api/account` (authenticated, requires password confirmation) triggers:

1. All machines destroyed (Fly apps + volumes)
2. All sessions invalidated
3. OAuth tokens deleted
4. User record anonymized (email -> deleted-{hash}@deleted, name -> null)
5. Billing records retained with anonymized user reference (7-year legal requirement)
6. Audit log entries retained for 90 days, then anonymized
7. Confirmation email sent to the original email address

### Admin-initiated deletion

Admin can trigger deletion via `POST /api/admin/users/:id/delete` with the same process plus an audit log entry recording the admin actor.

## Refund policy

- Billing errors: Full refund within 30 days of the error
- Service issues: Prorated credit for documented downtime exceeding SLO
- Cancellation: No prorated refund for partial months
- Account termination (abuse): No refund

Refund requests: [SUPPORT_EMAIL]
