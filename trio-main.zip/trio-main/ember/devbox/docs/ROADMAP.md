# Ember Roadmap

## Product Stack

```
Stoke (open source, Apache 2.0)   AI coding orchestrator
Ember (SaaS, proprietary)         Cloud dev machines + AI compute
Flare (infrastructure, later)     Firecracker microVMs on GCP
```

## Current State

Ember is a cloud dev environment with terminal (ttyd) + VS Code (code-server)
in the browser. Hono API, React SPA, Postgres, Stripe billing, Fly.io machines.

- 69 files, ~135KB source
- 28 tests passing
- Terminal auth via exchange codes + HMAC cookies
- Billing: local slot model with Stripe webhooks + reconciler
- Machine types: CLI (ttyd) + VS Code (code-server)
- File upload to /workspace/uploads/ per machine
- Customizable grid dashboard with machine panes

## Phase 1: Stoke Integration (Month 1)

### Pre-install Stoke on machines
- Add `stoke` binary to machine-image/Dockerfile
- Pre-configure pool with machine's Claude/Codex auth
- Users type `stoke build` in terminal, works immediately

### Stoke progress pane
- New pane type in dashboard grid: ⚡ Stoke Progress
- Reads from GET /internal/stoke-status on machine
- Machine endpoint reads /workspace/.stoke/session.json
- Live task list with phase indicators (pending/executing/verified/committed)
- Cost tracking, burst worker count

### Ember API extensions for Stoke
```
POST   /v1/workers              Spawn a Flare burst worker
DELETE /v1/workers/:id          Destroy worker
GET    /v1/workers/:id/status   Worker state

POST   /v1/ai/chat             Managed OpenRouter proxy
GET    /v1/ai/usage            Token usage for billing

POST   /v1/sessions            Register a Stoke session
PUT    /v1/sessions/:id        Update progress
GET    /v1/sessions/:id        Read progress (dashboard uses this)
```

## Phase 2: Chat Sidebar (Month 2)

### Architecture
The chat sidebar is a conversational layer over Stoke's plan generation.
The LLM only does PLANNING. Stoke's phase machine does execution.

```
User message → planning model → typed Stoke plan JSON
  → sidebar renders as interactive UI (approve/edit/reject)
  → user approves → Stoke executes → progress streams back
  → results shown as diffs with approve/reject
```

### Shared React component
Same chat sidebar component renders in:
- Ember web dashboard (new pane type)
- Ember Desktop (Tauri app)
- VS Code extension (webview panel)

### Key files
```
web/src/components/ChatSidebar.tsx     Shared chat UI
web/src/lib/chat-engine.ts            Conversation → plan → execute flow
web/src/components/PlanViewer.tsx      Interactive plan display
web/src/components/DiffViewer.tsx      Per-task diff display
```

## Phase 3: Desktop + VS Code (Month 2-3)

### Ember Desktop (Tauri)
```
ember-desktop/
  src-tauri/src/main.rs       Tauri shell (~5MB binary, not Electron)
  src/App.tsx                  Chat sidebar + terminal + file tree
  src/lib/stoke-client.ts     Talks to Stoke via machine internal API
  src/lib/ember-client.ts     Talks to Ember API (auth, billing, workers)
```

### VS Code Extension
```
ember-vscode/
  src/extension.ts             Sidebar provider + commands
  src/sidebar/ChatPanel.ts     Webview with chat sidebar
  src/stoke/progress.ts        TreeView for task progress
```

Registers:
- Sidebar panel (chat)
- Tree view (Stoke progress)
- Commands: "Ember: Plan", "Ember: Build", "Ember: Approve"
- Diff provider for Stoke changes per-task

## Phase 4: Flare Migration (Month 3-4)

Switch Ember machines from Fly.io to own Flare infrastructure:
- GCE MIGs with nested virtualization
- Firecracker microVMs (~125ms boot)
- Cloudflare Tunnel for TLS + routing
- Filestore NFS for persistent workspaces
- See flare/ repo for architecture

## Pricing

```
Starter    $29/mo
  1 persistent machine (4-vCPU, 8GB, 50GB)
  5 burst worker hours/month
  500K managed AI tokens
  Stoke pre-installed

Pro        $79/mo
  3 persistent machines (up to 16-vCPU)
  20 burst worker hours/month
  5M managed AI tokens

Team       $199/mo
  10 persistent machines
  100 burst worker hours/month
  20M managed AI tokens
  Team dashboard, shared machines

Overages:
  Burst compute:  $0.008/vCPU-minute
  Managed AI:     OpenRouter rate + 20%
```
