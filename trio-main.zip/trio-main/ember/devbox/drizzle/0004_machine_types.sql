-- Machine type: cli (ttyd terminal) or vscode (code-server)
ALTER TABLE "machines" ADD COLUMN IF NOT EXISTS "machine_type" text NOT NULL DEFAULT 'cli';

-- User layout preferences (stored as JSON, per-user)
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "layout_config" text;

-- oauth_accounts.created_at (needed by data export)
ALTER TABLE "oauth_accounts" ADD COLUMN IF NOT EXISTS "created_at" timestamp with time zone DEFAULT now();
