-- Subscriptions: local mirror of Stripe state
CREATE TABLE IF NOT EXISTS "subscriptions" (
  "id" text PRIMARY KEY NOT NULL,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "stripe_subscription_id" text NOT NULL UNIQUE,
  "status" text NOT NULL,
  "current_period_start" timestamp with time zone,
  "current_period_end" timestamp with time zone,
  "cancel_at" timestamp with time zone,
  "canceled_at" timestamp with time zone,
  "last_stripe_event_id" text,
  "last_stripe_event_ts" timestamp with time zone,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "updated_at" timestamp with time zone NOT NULL DEFAULT now()
);

-- Purchase intents: server-side idempotency
CREATE TABLE IF NOT EXISTS "purchase_intents" (
  "id" text PRIMARY KEY NOT NULL,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "type" text NOT NULL,
  "size" text NOT NULL,
  "status" text NOT NULL DEFAULT 'pending',
  "stripe_session_id" text,
  "stripe_subscription_item_id" text,
  "slot_id" text,
  "error_message" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "completed_at" timestamp with time zone,
  "expires_at" timestamp with time zone NOT NULL
);

-- Terminal sessions: inventory for audit/revocation
CREATE TABLE IF NOT EXISTS "terminal_sessions" (
  "id" text PRIMARY KEY NOT NULL,
  "machine_id" text NOT NULL REFERENCES "machines"("id") ON DELETE CASCADE,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "status" text NOT NULL DEFAULT 'active',
  "issued_at" timestamp with time zone NOT NULL DEFAULT now(),
  "expires_at" timestamp with time zone NOT NULL,
  "revoked_at" timestamp with time zone,
  "last_used_at" timestamp with time zone,
  "revoke_reason" text
);
CREATE INDEX IF NOT EXISTS "terminal_sessions_machine_idx" ON "terminal_sessions" ("machine_id");
CREATE INDEX IF NOT EXISTS "terminal_sessions_user_idx" ON "terminal_sessions" ("user_id");

-- Audit log
CREATE TABLE IF NOT EXISTS "audit_log" (
  "id" text PRIMARY KEY NOT NULL,
  "user_id" text REFERENCES "users"("id"),
  "actor_id" text REFERENCES "users"("id"),
  "action" text NOT NULL,
  "resource_type" text,
  "resource_id" text,
  "details" text,
  "ip_address" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "audit_log_user_idx" ON "audit_log" ("user_id");
CREATE INDEX IF NOT EXISTS "audit_log_action_idx" ON "audit_log" ("action");
CREATE INDEX IF NOT EXISTS "audit_log_created_idx" ON "audit_log" ("created_at");

-- Add subscription_id FK to slots (replaces bare stripe_subscription_id string)
ALTER TABLE "slots" ADD COLUMN IF NOT EXISTS "subscription_id" text REFERENCES "subscriptions"("id");

-- Add email_verified and mfa_secret to users
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "email_verified" boolean NOT NULL DEFAULT false;
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "mfa_secret" text;

-- Add hostname_status to machines
ALTER TABLE "machines" ADD COLUMN IF NOT EXISTS "hostname_status" text;

-- Add token_scope to oauth_accounts
ALTER TABLE "oauth_accounts" ADD COLUMN IF NOT EXISTS "token_scope" text;

-- Add user_id and machine_id to exchange_codes
ALTER TABLE "exchange_codes" ADD COLUMN IF NOT EXISTS "machine_id" text REFERENCES "machines"("id") ON DELETE CASCADE;
ALTER TABLE "exchange_codes" ADD COLUMN IF NOT EXISTS "user_id" text REFERENCES "users"("id") ON DELETE CASCADE;
ALTER TABLE "exchange_codes" ADD COLUMN IF NOT EXISTS "consumed_at" timestamp with time zone;

-- Add subscription_id to billing_events
ALTER TABLE "billing_events" ADD COLUMN IF NOT EXISTS "subscription_id" text REFERENCES "subscriptions"("id");
