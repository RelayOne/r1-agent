-- v1 API support: API keys, AI usage metering, machine metadata

-- API keys for v1 endpoints (workers, AI, sessions)
CREATE TABLE IF NOT EXISTS "api_keys" (
  "id" text PRIMARY KEY,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "key_hash" text NOT NULL UNIQUE,
  "label" text NOT NULL DEFAULT 'default',
  "status" text NOT NULL DEFAULT 'active',
  "last_used_at" timestamp with time zone,
  "created_at" timestamp with time zone NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "api_keys_user_idx" ON "api_keys" ("user_id");
CREATE INDEX IF NOT EXISTS "api_keys_hash_idx" ON "api_keys" ("key_hash");

-- AI usage metering for managed OpenRouter proxy
CREATE TABLE IF NOT EXISTS "ai_usage" (
  "id" text PRIMARY KEY,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "model" text NOT NULL,
  "input_tokens" integer NOT NULL DEFAULT 0,
  "output_tokens" integer NOT NULL DEFAULT 0,
  "cost_usd" numeric(10,6) NOT NULL DEFAULT 0,
  "markup_usd" numeric(10,6) NOT NULL DEFAULT 0,
  "created_at" timestamp with time zone NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "ai_usage_user_period_idx" ON "ai_usage" ("user_id", "created_at");

-- Machine metadata for Stoke worker tagging
ALTER TABLE "machines" ADD COLUMN IF NOT EXISTS "metadata" jsonb DEFAULT '{}';

-- Slot updated_at for sync tracking
ALTER TABLE "slots" ADD COLUMN IF NOT EXISTS "updated_at" timestamp with time zone DEFAULT now();

-- Stoke session progress (for dashboard + shareable links)
CREATE TABLE IF NOT EXISTS "stoke_sessions" (
  "id" text PRIMARY KEY,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "plan_id" text NOT NULL DEFAULT '',
  "status" text NOT NULL DEFAULT 'active',
  "tasks" jsonb NOT NULL DEFAULT '[]',
  "total_cost_usd" numeric(10,4) NOT NULL DEFAULT 0,
  "burst_workers" integer NOT NULL DEFAULT 0,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "updated_at" timestamp with time zone NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS "stoke_sessions_user_idx" ON "stoke_sessions" ("user_id");
