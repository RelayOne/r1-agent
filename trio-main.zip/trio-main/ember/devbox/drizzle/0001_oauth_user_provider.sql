CREATE UNIQUE INDEX IF NOT EXISTS "oauth_user_provider_idx" ON "oauth_accounts" ("user_id", "provider");
