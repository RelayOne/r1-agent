CREATE TABLE IF NOT EXISTS "users" (
  "id" text PRIMARY KEY NOT NULL,
  "email" text NOT NULL UNIQUE,
  "password_hash" text,
  "name" text,
  "avatar_url" text,
  "role" text NOT NULL DEFAULT 'user',
  "status" text NOT NULL DEFAULT 'active',
  "credits_cents" integer NOT NULL DEFAULT 0,
  "stripe_customer_id" text UNIQUE,
  "startup_script" text DEFAULT '',
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "updated_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "sessions" (
  "id" text PRIMARY KEY NOT NULL,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "expires_at" timestamp with time zone NOT NULL
);

CREATE TABLE IF NOT EXISTS "oauth_accounts" (
  "provider" text NOT NULL,
  "provider_id" text NOT NULL,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "access_token" text,
  "refresh_token" text
);
CREATE UNIQUE INDEX IF NOT EXISTS "oauth_provider_id_idx" ON "oauth_accounts" ("provider", "provider_id");

CREATE TABLE IF NOT EXISTS "slots" (
  "id" text PRIMARY KEY NOT NULL,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "size" text NOT NULL,
  "price_cents" integer NOT NULL,
  "stripe_subscription_id" text,
  "stripe_subscription_item_id" text UNIQUE,
  "status" text NOT NULL DEFAULT 'active',
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "cancelled_at" timestamp with time zone
);

CREATE TABLE IF NOT EXISTS "machines" (
  "id" text PRIMARY KEY NOT NULL,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "slot_id" text UNIQUE REFERENCES "slots"("id"),
  "name" text NOT NULL,
  "fly_app_name" text NOT NULL UNIQUE,
  "fly_machine_id" text,
  "fly_region" text NOT NULL DEFAULT 'sjc',
  "size" text NOT NULL,
  "state" text NOT NULL DEFAULT 'creating',
  "git_repo" text,
  "machine_token" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "updated_at" timestamp with time zone NOT NULL DEFAULT now(),
  "deleted_at" timestamp with time zone
);

CREATE TABLE IF NOT EXISTS "billing_events" (
  "id" text PRIMARY KEY NOT NULL,
  "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "type" text NOT NULL,
  "slot_id" text REFERENCES "slots"("id"),
  "amount_cents" integer NOT NULL DEFAULT 0,
  "stripe_event_id" text UNIQUE,
  "description" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "exchange_codes" (
  "code" text PRIMARY KEY NOT NULL,
  "fly_app_name" text NOT NULL,
  "expires_at" timestamp with time zone NOT NULL
);
