# Ember Devbox Codebase Audit
**Date:** 2026-04-02
**TypeScript errors:** None (npx tsc --noEmit passes cleanly)

---

## 1. Untested Route Handlers

All route files in `src/routes/` except `billing.ts` have **zero test coverage**.

### Completely untested (no test file at all)

| File | Endpoints | Notes |
|------|-----------|-------|
| `src/routes/account.ts` | POST /forgot-password, POST /reset-password, POST /send-verification, POST /verify-email, GET /sessions, POST /sessions/:id/revoke, POST /sessions/revoke-all, GET /export, POST /delete | High-value targets: account deletion, password reset |
| `src/routes/admin.ts` | GET /stats, GET /users, GET /users/:id, POST /users/:id/credit, POST /users/:id/ban, POST /users/:id/unban | Admin-only; ban/credit are destructive |
| `src/routes/ai.ts` | POST /v1/ai/chat, GET /v1/ai/usage | Money-metering path for AI calls |
| `src/routes/api-keys.ts` | GET /api-keys, POST /api-keys, POST /api-keys/:id/revoke | Key lifecycle; plaintext key returned once |
| `src/routes/auth.ts` | POST /register, POST /login, POST /logout, GET /me, GET+GET /github, GET+GET /google | OAuth + credential auth |
| `src/routes/credits.ts` | POST /checkout, GET /balance, GET /packages | Credit purchase; money flow |
| `src/routes/github.ts` | GET /status, GET /connect, GET /connect/callback, GET /repos, GET /orgs, GET /orgs/:org/repos, GET /install, GET /app-repos, GET /app-status | GitHub OAuth and App integration |
| `src/routes/machines.ts` | GET /, POST /, POST /:id/start, POST /:id/stop, DELETE /:id, POST /:id/terminal, POST /:id/check-hostname, POST /:id/upload, POST /verify-code, GET /:id/startup, GET /:id/stoke-status | Machine lifecycle + terminal auth |
| `src/routes/sessions.ts` | POST /, PUT /:id, GET /:id | Stoke session lifecycle |
| `src/routes/settings.ts` | GET /profile, PUT /profile, GET /startup, PUT /startup, GET /layout, PUT /layout | User settings and layout config |
| `src/routes/workers.ts` | POST /, GET /, GET /:id/status, DELETE /:id, POST /:id/stop | Worker lifecycle; credits spent |

### Existing tests cover only happy-path DB constraints

`src/__tests__/billing.test.ts` — only tests: unique constraints, slot rebinding, webhook idempotency. **Does not test** the actual HTTP route handlers, Stripe webhook switch logic, `syncSubscription`, `enforceSlotCancellations`, or `reconcile`.

`src/__tests__/identity.test.ts` — only tests: OAuth unique constraints, token create/consume logic. **Does not test** account deletion, session management, data export.

`src/__tests__/terminal.test.ts` — only tests: exchange code create/consume, session creation, revocation. **Does not test** the `verify-code` endpoint (with machine auth), startup script fetch, stoke-status proxy, hostname check, or upload.

---

## 2. Security Issues

### HIGH: Silent JSON parse failures across all route handlers

**Files:** All route files (account.ts:31, billing.ts:98, credits.ts:25, workers.ts:44, ai.ts:38, etc.)

Every route handler uses:
```typescript
const parsed = schema.safeParse(await c.req.json().catch(() => ({})));
```
If the request body is not valid JSON, `c.req.json()` throws, `.catch(() => ({}))` swallows it silently, and `safeParse({})` returns a validation failure. The user gets "Invalid input" instead of "Malformed JSON body". This is a minor but pervasive issue — it masks malformed requests rather than distinguishing them from valid-but-empty bodies.

---

### HIGH: CSRF exemption for /v1/* bypasses origin check

**File:** `src/middleware.ts:84`

```typescript
const exemptPrefixes = [
  "/api/billing/webhooks",
  "/api/billing/reconcile",
  "/api/machines/verify-code",
  "/v1/",         // <-- all v1 endpoints exempt from CSRF
];
```

The `/v1/*` prefix is exempt from CSRF checks. This is intentional for API-key-authenticated endpoints, but it means a third-party website can make browser-based CSRF requests to `/v1/workers`, `/v1/ai/chat`, and `/v1/sessions` PUT if the user has a leaked/stolen API key. The actual auth is via Bearer token, so this is not an auth bypass, but it does mean the CSRF exemption provides no protection for v1 endpoints.

---

### MEDIUM: `/v1/sessions/:id` GET is unauthenticated — cost data leaks on shareable links

**File:** `src/routes/sessions.ts:71-86`

```typescript
// GET /v1/sessions/:id - read progress (public for shareable links)
// total_cost_usd is redacted: cost data is sensitive...
app.get("/:id", async (c) => {
```

The `total_cost_usd` field IS correctly redacted (not selected). However, `plan_id`, `tasks`, and `burst_workers` are returned without ownership verification. Task descriptions from Stoke could contain sensitive information (repo names, file paths, build commands). The `PUT /:id` correctly validates ownership, but the GET is unauthenticated. This is by design for "shareable links" but worth verifying that task content is appropriate for public visibility.

---

### MEDIUM: Reconciler endpoint has no admin check

**File:** `src/routes/billing.ts:748-763`

The `/reconcile` endpoint validates a bearer secret:
```typescript
if (!process.env.RECONCILE_SECRET) { return 503; }
const auth = c.req.header("Authorization") || "";
const expected = `Bearer ${secret}`;
if (auth.length !== expected.length || !crypto.timingSafeEqual(...)) { return 401; }
```
This uses a secret-bearer pattern (correct) and `crypto.timingSafeEqual` (correct). However, there is no admin role check. Any caller with the `RECONCILE_SECRET` can trigger reconciliation. This is acceptable if the secret is sufficiently protected, but if leaked, it allows triggering arbitrary Fly machine operations and Stripe subscription syncs.

---

### MEDIUM: `/reconcile` timing-safe compare will throw on missing Authorization header

**File:** `src/routes/billing.ts:757-758`

```typescript
if (auth.length !== expected.length ||
    !crypto.timingSafeEqual(Buffer.from(auth), Buffer.from(expected))) {
```

If `Authorization` header is missing, `auth = ""`. If `secret` is non-empty, `auth.length !== expected.length` evaluates to `true`, so the second condition is **not evaluated** (short-circuit). This is safe. But if the lengths happen to match coincidentally (e.g., `RECONCILE_SECRET=""` — which should not happen), the `timingSafeEqual` would throw on mismatched buffer sizes. Low risk but worth noting.

---

### MEDIUM: `verify-code` returns different error shapes for auth vs. validation failures

**File:** `src/routes/machines.ts:466-512`

The endpoint returns `{ ok: false }` with 401/400/403 for all failures. The machine auth proxy receives the same response for: invalid machine token, missing code, expired code, revoked session, banned user. This is fine for security (doesn't leak WHY auth failed), but makes debugging harder.

---

### LOW: Silent SSE stream handling — malformed data is dropped

**File:** `src/routes/ai.ts:88-108`

In the SSE transform, if a chunk contains incomplete JSON, it is buffered and retried. If the buffer cannot be parsed at all (including the final flush), the code falls through without any usage record — the AI call was charged by OpenRouter but never metered in `ai_usage`. This is recoverable from server logs, but the path silently fails with only a `console.error`. The fallback `costMatch` regex on raw SSE text is fragile.

---

### LOW: Startup script endpoint has no rate limiting

**File:** `src/routes/machines.ts:547-564`

`GET /api/machines/:id/startup` is exempt from CSRF (machine-to-machine auth) and has no rate limit applied. A compromised machine token could be used to repeatedly poll startup scripts. The machine token is Bearer auth, so if compromised, the attacker already has equivalent access.

---

### LOW: `layoutConfig` JSON parse errors are silently handled

**File:** `src/routes/settings.ts:68-72`

```typescript
try {
  return c.json({ layout: JSON.parse(row.layoutConfig) });
} catch {
  return c.json({ layout: null });
}
```
If stored layout JSON is corrupted, the user silently loses their layout config. No alert is logged.

---

### LOW: `setCookie` cast to `any` bypasses type safety

**Files:** `src/routes/auth.ts:70,96,119,132,242,317`

```typescript
setCookie(c, cookie.name, cookie.value, cookie.attributes as any);
```
Lucia's cookie attributes are structurally typed for Hono's `setCookie`, but the cast is needed due to a TypeScript module mismatch. This is a known limitation, not a runtime risk.

---

## 3. Missing Test Cases

### Billing (`billing.test.ts`)

1. **Webhook: `checkout.session.completed` with `payment_type=credit_purchase`** — credit top-up path not tested
2. **Webhook: `checkout.session.completed` with subscription** — the `intentId`/`slotId` completion path
3. **Webhook: `invoice.paid`** — clearing `needs_stop` machines when payment recovers
4. **Webhook: `invoice.payment_failed`** — `enforceSlotCancellations` call
5. **Webhook: all `customer.subscription.*` events** — syncSubscription + enforceSlotCancellations
6. **`syncSubscription` function** — price-to-size mapping, slot reactivation, slot cancellation for removed items
7. **`enforceSlotCancellations` function** — stopping machines when slot is cancelled
8. **Reconciler (`reconcile`)** — `needs_stop` retry, orphan Stripe items, reverse orphan Fly apps, worker sweep
9. **`reconcile` leader election** — pg_try_advisory_xact_lock behavior
10. **`checkout` for existing subscription (add slot to active sub)**
11. **`checkout` for new subscription (Stripe Checkout redirect)**
12. **`checkout` with delinquent sub** — portal redirect
13. **`portal` endpoint**
14. **`/history` endpoint**
15. **`/intent/:id` endpoint**
16. **Negative: slot rebound fails (no free slots)** — 402 response

### Identity (`identity.test.ts`)

1. **Account deletion** (`POST /api/account/delete`) — full destruction flow including Fly machine teardown, Stripe cancel, session revocation
2. **Password reset** — end-to-end: forgot → token → reset → sessions invalidated
3. **Email verification** — end-to-end: send → token → verify
4. **Session revocation** — specific session revoke vs. revoke-all
5. **Data export** (`GET /api/account/export`) — all sections returned
6. **OAuth callback: linking to existing email user (GitHub and Google)**
7. **OAuth callback: linking to existing GitHub identity for different user** — the "already linked elsewhere" rejection
8. **`/me` endpoint** — banned user session invalidation

### Terminal (`terminal.test.ts`)

1. **`verify-code` endpoint** — machine Bearer auth, exchange code consumption, session expiry check, banned user rejection
2. **Session expiry check** — `terminal_sessions` expires_at validation during `verify-code`
3. **`/startup` endpoint** — machine Bearer auth, :id parameter matching
4. **`/stoke-status` endpoint** — proxy to machine, origin fallback
5. **`/check-hostname` endpoint** — slot-cancelled-during-provisioning path
6. **Machine upload** (`POST /api/machines/:id/upload`) — file size limits, machine state checks
7. **`revokeTerminalSessionsForMachine`** — per-machine revocation
8. **`revokeAllTerminalSessionsForUser`** — burn exchange codes on logout

---

## 4. Type Safety Issues

### `any` casts — critical for future refactoring safety

#### `src/routes/billing.ts`

- **Line 105:** `let intent: any;` — should have a typed interface for `purchaseIntents` row
- **Lines 195, 218:** `catch (e: any)` — should be `catch (e: unknown)` + narrowing
- **Lines 371, 675, 684:** `map((r: any) => r.id / .fly_app / .fly_app_name)` — raw SQL result rows
- **Lines 610, 629, 639, 676, 695, 709, 741, 788:** `catch (e: any)` in reconciler

#### `src/routes/machines.ts`

- **Line 41:** `function getClientIp(c: any): string` — should use `Context` type
- **Lines 166, 215:** `catch (e: any)`

#### `src/routes/ai.ts`

- **Line 84:** `let lastUsage: any = null;` — SSE usage object from OpenRouter; should have a typed interface
- **Line 147:** `const data = await orRes.json() as any;` — untyped OpenRouter response

#### `src/routes/auth.ts`

- **Line 226:** `const updates: any = { providerId: ghId };` — dynamically built update object; should use `Partial<typeof oauthAccounts.$inferInsert>`
- **Lines 70, 96, 119, 132, 242, 317:** `cookie.attributes as any` — Lucia cookie type mismatch

#### `src/routes/sessions.ts`

- **Line 46:** `tasks: z.array(z.any()).max(1000).optional()` — `z.any()` accepts any value in tasks array; no schema validation on task structure

#### `src/routes/workers.ts`

- **Lines 82, 124:** `catch (e: any)` — error narrowing

#### `src/routes/admin.ts`

- **Line 85:** `catch (e: any)`

#### `src/routes/github.ts`

- **Line 52:** `catch (e: any)`
- **Line 255:** `repos.map((r: any) => ({ ... }))` — raw GitHub API response

#### `src/fly.ts`

- **Line 17:** `function certificateReady(details: any): boolean` — Fly API cert response
- **Line 22:** `function summarizeCertificateIssue(details: any): string`
- **Line 115:** `flyGraphQL(query: string, variables?: any)` — `variables` should be `Record<string, unknown>`
- **Line 175:** `Promise<{ ok: boolean; hostname: string; details?: any; reason?: string }>` — `details` should be typed
- **Line 458:** `map((n: any) => n.name as string)` — raw GraphQL result node

#### `src/github-app.ts`

- **Lines 53, 54:** `as any[]` and `(i: any)` — GitHub App API responses
- **Line 78:** `const body: any = {}` — manually built request body
- **Lines 102, 125:** `as any` — untyped JSON responses
- **Line 58:** `catch (e: any)`

#### `src/rate-limit.ts`

- **Line 59:** `let pgSql: any = null` — postgres.js rawSql reference
- **Line 115:** `catch (e: any)` in cleanup

#### `src/index.ts`

- **Lines 145-146:** `(c: any)` — notEnabled handlers

---

## Summary

| Category | Count |
|----------|-------|
| Completely untested route files | 11 out of 12 |
| Individual untested endpoint handlers | ~60+ |
| `any` type occurrences (source files) | ~50+ |
| HIGH severity issues | 2 |
| MEDIUM severity issues | 4 |
| LOW severity issues | 4 |
