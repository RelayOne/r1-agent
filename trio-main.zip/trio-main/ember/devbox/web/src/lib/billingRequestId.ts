const PREFIX = "ember.billingRequest.";

function key(scope: string) {
  return `${PREFIX}${scope}`;
}

export function getOrCreateBillingRequestId(scope: string): string {
  try {
    const existing = window.localStorage.getItem(key(scope));
    if (existing) return existing;
    const created = crypto.randomUUID();
    window.localStorage.setItem(key(scope), created);
    return created;
  } catch {
    return crypto.randomUUID();
  }
}

export function clearBillingRequestId(scope: string) {
  try {
    window.localStorage.removeItem(key(scope));
  } catch {
    // ignore storage failures
  }
}

export function clearAllBillingRequestIds() {
  try {
    const toDelete: string[] = [];
    for (let i = 0; i < window.localStorage.length; i += 1) {
      const storageKey = window.localStorage.key(i);
      if (storageKey?.startsWith(PREFIX)) toDelete.push(storageKey);
    }
    for (const storageKey of toDelete) {
      window.localStorage.removeItem(storageKey);
    }
  } catch {
    // ignore storage failures
  }
}
