// API helper that throws on every non-2xx response.
// Callers that need error details can catch ApiError and inspect .data.

export class ApiError extends Error {
  status: number;
  data: any;
  constructor(status: number, data: any) {
    super(data?.error || `Request failed (${status})`);
    this.name = "ApiError";
    this.status = status;
    this.data = data;
  }
}

export async function api<T = any>(path: string, opts: RequestInit = {}): Promise<T> {
  const res = await fetch(path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...opts.headers },
    credentials: "same-origin",
  });

  if (res.status === 401) {
    if (!window.location.pathname.startsWith("/login") &&
        !window.location.pathname.startsWith("/register") &&
        !window.location.pathname.startsWith("/forgot-password") &&
        !window.location.pathname.startsWith("/reset-password") &&
        !window.location.pathname.startsWith("/verify-email")) {
      window.location.href = "/login";
    }
    throw new ApiError(401, { error: "Not authenticated" });
  }

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new ApiError(res.status, data);
  }

  return data as T;
}

/** Navigate to an external URL only if it uses https. Prevents open-redirect via javascript: or data: URIs. */
export function safeRedirect(url: string) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol === "https:") {
      window.location.href = url;
      return;
    }
  } catch {}
  console.error("[api] blocked redirect to non-https URL:", url);
}

export const get = <T = any>(path: string) => api<T>(path);
export const post = <T = any>(path: string, body?: any) =>
  api<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined });
export const put = <T = any>(path: string, body?: any) =>
  api<T>(path, { method: "PUT", body: body ? JSON.stringify(body) : undefined });
export const del = <T = any>(path: string) => api<T>(path, { method: "DELETE" });
