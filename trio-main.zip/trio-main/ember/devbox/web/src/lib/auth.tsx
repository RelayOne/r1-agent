import React, { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { get, post } from "./api";

interface User {
  id: string;
  email: string;
  name: string | null;
  role: string;
  status: string;
  avatarUrl: string | null;
}

interface AuthCtx {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<string | null>;
  register: (email: string, password: string, name: string) => Promise<string | null>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
}

const AuthContext = createContext<AuthCtx>(null!);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    try {
      const data = await get<{ user: User | null }>("/api/auth/me");
      setUser(data.user);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refresh(); }, []);

  const login = async (email: string, password: string): Promise<string | null> => {
    try {
      const data = await post<{ ok?: boolean; error?: string }>("/api/auth/login", { email, password });
      if (data.ok) { await refresh(); return null; }
      return data.error || "Login failed";
    } catch (e: any) { return e.message || "Login failed"; }
  };

  const register = async (email: string, password: string, name: string): Promise<string | null> => {
    try {
      const data = await post<{ ok?: boolean; error?: string }>("/api/auth/register", { email, password, name });
      if (data.ok) { await refresh(); return null; }
      return data.error || "Registration failed";
    } catch (e: any) { return e.message || "Registration failed"; }
  };

  const logout = async () => {
    await post("/api/auth/logout");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, refresh }}>
      {children}
    </AuthContext.Provider>
  );
}
