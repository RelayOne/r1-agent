import React, { useEffect, useState } from "react";
import { useAuth } from "../lib/auth";
import { safeRedirect } from "../lib/api";
import { useSearchParams } from "react-router-dom";

interface CreditPackage { id: string; priceCents: number; creditsCents: number; label: string; }
interface Transaction { type: string; amount_cents: number; balance_after_cents: number; created_at: string; metadata: any; }
interface WorkerAlloc { id: string; status: string; cost_cents: number; expires_at: string; worker_type: string; created_at: string; }

export default function Credits() {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [workers, setWorkers] = useState<WorkerAlloc[]>([]);
  const [packages, setPackages] = useState<CreditPackage[]>([]);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const purchaseStatus = searchParams.get("purchase");

  useEffect(() => {
    fetch("/api/credits/balance", { credentials: "include" })
      .then(r => r.json())
      .then(data => {
        setBalance(data.credits_cents || 0);
        setTransactions(data.recent_transactions || []);
        setWorkers(data.active_workers || []);
        setPackages(data.packages || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const handlePurchase = async (packageId: string) => {
    setPurchasing(packageId);
    setError(null);
    try {
      const resp = await fetch("/api/credits/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ packageId }),
      });
      const data = await resp.json();
      if (data.checkoutUrl) {
        safeRedirect(data.checkoutUrl);
      }
    } catch {
      setError("Purchase failed. Please try again.");
      setPurchasing(null);
    }
  };

  if (loading) return <div style={{ padding: 32, fontFamily: "var(--mono)", color: "var(--dim)" }}>Loading...</div>;

  return (
    <div style={{ padding: 32, maxWidth: 720, margin: "0 auto", fontFamily: "var(--mono)" }}>
      <h2 style={{ marginBottom: 8 }}>Credits</h2>

      {purchaseStatus === "success" && (
        <div style={{ background: "#1a3a1a", border: "1px solid #2d5a2d", borderRadius: 8, padding: 12, marginBottom: 16, color: "#6fcf6f" }}>
          Purchase successful! Credits added to your balance.
        </div>
      )}
      {purchaseStatus === "cancelled" && (
        <div style={{ background: "#3a2a1a", border: "1px solid #5a3a1a", borderRadius: 8, padding: 12, marginBottom: 16, color: "#cf9f6f" }}>
          Purchase cancelled.
        </div>
      )}

      <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 8, padding: 20, marginBottom: 24 }}>
        <div style={{ fontSize: 14, color: "var(--dim)" }}>Current Balance</div>
        <div style={{ fontSize: 32, fontWeight: 700 }}>${(balance / 100).toFixed(2)}</div>
      </div>

      {error && (
        <div style={{ background: "#3a1a1a", border: "1px solid #5a1a1a", borderRadius: 8, padding: 12, marginBottom: 16, color: "#cf6f6f" }}>
          {error}
        </div>
      )}

      <h3 style={{ marginBottom: 12 }}>Top Up</h3>
      <div style={{ display: "flex", gap: 12, marginBottom: 24, flexWrap: "wrap" }}>
        {packages.map(pkg => (
          <button
            key={pkg.id}
            onClick={() => handlePurchase(pkg.id)}
            disabled={purchasing !== null}
            style={{
              padding: "12px 20px", borderRadius: 8, cursor: "pointer",
              background: purchasing === pkg.id ? "var(--dim)" : "var(--accent)",
              color: "#fff", border: "none", fontFamily: "var(--mono)", fontSize: 14,
            }}
          >
            {pkg.label} - ${(pkg.priceCents / 100).toFixed(2)}
            {pkg.creditsCents > pkg.priceCents && ` (${Math.round((pkg.creditsCents - pkg.priceCents) / pkg.priceCents * 100)}% bonus)`}
          </button>
        ))}
      </div>

      {workers.length > 0 && (
        <>
          <h3 style={{ marginBottom: 8 }}>Active Workers</h3>
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: 24, fontSize: 13 }}>
            <thead>
              <tr style={{ borderBottom: "1px solid var(--border)" }}>
                <th style={{ textAlign: "left", padding: 6 }}>Type</th>
                <th style={{ textAlign: "left", padding: 6 }}>Cost</th>
                <th style={{ textAlign: "left", padding: 6 }}>Expires</th>
                <th style={{ textAlign: "left", padding: 6 }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {workers.map(w => (
                <tr key={w.id} style={{ borderBottom: "1px solid var(--border)" }}>
                  <td style={{ padding: 6 }}>{w.worker_type}</td>
                  <td style={{ padding: 6 }}>${(w.cost_cents / 100).toFixed(2)}</td>
                  <td style={{ padding: 6 }}>{new Date(w.expires_at).toLocaleString()}</td>
                  <td style={{ padding: 6 }}>{w.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      <h3 style={{ marginBottom: 8 }}>Recent Transactions</h3>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
        <thead>
          <tr style={{ borderBottom: "1px solid var(--border)" }}>
            <th style={{ textAlign: "left", padding: 6 }}>Type</th>
            <th style={{ textAlign: "right", padding: 6 }}>Amount</th>
            <th style={{ textAlign: "right", padding: 6 }}>Balance</th>
            <th style={{ textAlign: "left", padding: 6 }}>Date</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((tx, i) => (
            <tr key={i} style={{ borderBottom: "1px solid var(--border)" }}>
              <td style={{ padding: 6 }}>{tx.type}</td>
              <td style={{ padding: 6, textAlign: "right", color: tx.amount_cents >= 0 ? "#6fcf6f" : "#cf6f6f" }}>
                {tx.amount_cents >= 0 ? "+" : ""}{(tx.amount_cents / 100).toFixed(2)}
              </td>
              <td style={{ padding: 6, textAlign: "right" }}>${(tx.balance_after_cents / 100).toFixed(2)}</td>
              <td style={{ padding: 6 }}>{new Date(tx.created_at).toLocaleString()}</td>
            </tr>
          ))}
          {transactions.length === 0 && (
            <tr><td colSpan={4} style={{ padding: 12, color: "var(--dim)", textAlign: "center" }}>No transactions yet</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
