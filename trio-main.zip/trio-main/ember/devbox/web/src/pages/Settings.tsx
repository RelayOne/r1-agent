import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth";
import { get, put, post, safeRedirect } from "../lib/api";
import { getOrCreateBillingRequestId, clearBillingRequestId } from "../lib/billingRequestId";

export default function Settings() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState(user?.name || "");
  const [script, setScript] = useState("");
  const [saved, setSaved] = useState("");
  const [saveError, setSaveError] = useState<string | null>(null);
  const [slots, setSlots] = useState<any[]>([]);
  const [prices, setPrices] = useState<any[]>([]);
  const [addingSlot, setAddingSlot] = useState(false);
  const [hasStripeCustomer, setHasStripeCustomer] = useState(false);
  const [subscriptionStatus, setSubscriptionStatus] = useState<string | null>(null);
  const [billingAction, setBillingAction] = useState<string | null>(null);
  const [ghStatus, setGhStatus] = useState<{ connected: boolean; hasRepoAccess: boolean } | null>(null);

  useEffect(() => {
    get("/api/settings/startup").then(d => setScript(d.script || ""));
    get("/api/billing").then(d => {
      if (d.slots) setSlots(d.slots);
      if (d.prices) setPrices(d.prices);
      if (d.hasStripeCustomer) setHasStripeCustomer(true);
      if (d.subscriptionStatus) setSubscriptionStatus(d.subscriptionStatus);
      if (d.billingAction) setBillingAction(d.billingAction);
    });
    get("/api/github/status").then(setGhStatus).catch(() => {});
  }, []);

  const saveProfile = async () => {
    setSaveError(null);
    try {
      await put("/api/settings/profile", { name });
      setSaved("Profile saved"); setTimeout(() => setSaved(""), 2000);
    } catch { setSaveError("Save failed"); setTimeout(() => setSaveError(null), 3000); }
  };
  const saveScript = async () => {
    setSaveError(null);
    try {
      await put("/api/settings/startup", { script });
      setSaved("Startup script saved"); setTimeout(() => setSaved(""), 2000);
    } catch { setSaveError("Save failed"); setTimeout(() => setSaveError(null), 3000); }
  };
  const openPortal = async () => {
    try {
      const d = await post("/api/billing/portal");
      if (d.url) safeRedirect(d.url);
    } catch {}
  };
  const addSlot = async (size: string) => {
    setAddingSlot(true);
    const requestId = getOrCreateBillingRequestId(`settings:${size}`);
    try {
      const d = await post("/api/billing/checkout", { size, requestId });
      if (d.url) {
        if (d.reason === "fix_payment" || d.reason === "manage_subscriptions") {
          clearBillingRequestId(`settings:${size}`);
        }
        safeRedirect(d.url);
        return;
      }
      if (d.ok) {
        clearBillingRequestId(`settings:${size}`);
        setSaved("Slot added!"); setTimeout(() => setSaved(""), 2000);
        const fresh = await get("/api/billing");
        if (fresh.slots) setSlots(fresh.slots);
      }
    } catch (e: any) {
      // 402 = needs slot purchase (handled by UI flow), other errors show message
      if (e.data?.needsSlot) {
        // Redirect to checkout will be handled by NewMachineModal
      }
      setSaveError(e.data?.error || "Billing error"); setTimeout(() => setSaveError(null), 3000);
    }
    setAddingSlot(false);
  };

  const sizeLabel = (s: string) => s.replace("performance-", "");

  return (
    <div style={{ minHeight: "100vh", padding: 24, maxWidth: 640, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 32 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 400 }}>Settings</h1>
          <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--muted)", marginTop: 4 }}>{user?.email}</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-ghost" onClick={() => navigate("/")}>Dashboard</button>
          <button className="btn btn-ghost" onClick={logout}>Logout</button>
        </div>
      </div>

      {saved && <div style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--success)", marginBottom: 16, padding: "8px 14px", background: "rgba(52,211,153,.1)", borderRadius: 8 }}>{saved}</div>}
      {saveError && <div style={{ fontFamily: "var(--mono)", fontSize: 12, color: "#ef4444", marginBottom: 16, padding: "8px 14px", background: "rgba(239,68,68,.1)", border: "1px solid rgba(239,68,68,.3)", borderRadius: 8 }}>{saveError}</div>}

      {/* Profile */}
      <div className="card" style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: 15, fontWeight: 500, marginBottom: 16 }}>Profile</h2>
        <div style={{ marginBottom: 14 }}>
          <label className="label">Name</label>
          <input className="input" value={name} onChange={e => setName(e.target.value)} />
        </div>
        <button className="btn btn-primary" onClick={saveProfile}>Save</button>
      </div>

      {/* GitHub Integration */}
      <div className="card" style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: 15, fontWeight: 500, marginBottom: 8 }}>GitHub</h2>
        <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--dim)", marginBottom: 12, lineHeight: 1.5 }}>
          Connect GitHub to clone private repos when creating machines.
        </p>
        {ghStatus === null ? (
          <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--dim)" }}>Loading...</p>
        ) : ghStatus.hasRepoAccess ? (
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span className="dot dot-online" style={{ width: 6, height: 6 }} />
            <span style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--success)" }}>Connected with repo access</span>
          </div>
        ) : ghStatus.connected ? (
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <span className="dot dot-stopped" style={{ width: 6, height: 6 }} />
              <span style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--warn)" }}>Connected (login only, no repo access)</span>
            </div>
            <a href="/api/github/connect" className="btn btn-primary" style={{ textDecoration: "none" }}>Grant repo access</a>
          </div>
        ) : (
          <a href="/api/github/connect" className="btn btn-primary" style={{ textDecoration: "none" }}>Connect GitHub</a>
        )}
      </div>

      {/* Startup Script */}
      <div className="card" style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: 15, fontWeight: 500, marginBottom: 8 }}>Startup Script</h2>
        <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--dim)", marginBottom: 12, lineHeight: 1.5 }}>
          Runs on every machine boot. Install packages, set env vars, configure tools. Takes effect on next reboot.
        </p>
        <textarea className="input" value={script} onChange={e => setScript(e.target.value)}
          style={{ height: 200, fontFamily: "var(--mono)", fontSize: 12, resize: "vertical" }}
          placeholder="#!/bin/bash&#10;# cargo install cargo-watch&#10;# npm install -g wrangler" />
        <button className="btn btn-primary" onClick={saveScript} style={{ marginTop: 12 }}>Save</button>
      </div>

      {/* Billing */}
      <div className="card" style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: 15, fontWeight: 500, marginBottom: 12 }}>Billing</h2>

        {(subscriptionStatus === "past_due" || subscriptionStatus === "unpaid") && (
          <div style={{ background: "rgba(239,68,68,.1)", border: "1px solid rgba(239,68,68,.3)", borderRadius: 8, padding: 14, marginBottom: 16 }}>
            <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "#ef4444", fontWeight: 500, marginBottom: 6 }}>Payment issue</p>
            <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--muted)", lineHeight: 1.5, marginBottom: 10 }}>
              Your subscription is {subscriptionStatus}. Update your payment method to restore access.
            </p>
            <button className="btn btn-primary" onClick={openPortal}>Fix Payment on Stripe</button>
          </div>
        )}

        {billingAction === "manage_subscriptions" && (
          <div style={{ background: "rgba(251,191,36,.1)", border: "1px solid rgba(251,191,36,.3)", borderRadius: 8, padding: 14, marginBottom: 16 }}>
            <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "#f59e0b", fontWeight: 500, marginBottom: 6 }}>Multiple active subscriptions</p>
            <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--muted)", lineHeight: 1.5, marginBottom: 10 }}>
              Billing is in an ambiguous state. Use the Stripe portal to consolidate subscriptions before adding more slots.
            </p>
            <button className="btn btn-primary" onClick={openPortal}>Manage Billing on Stripe</button>
          </div>
        )}

        {slots.length > 0 && (
          <div style={{ marginBottom: 16 }}>
            <p className="label">Active Slots</p>
            {slots.map(s => (
              <div key={s.id} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid var(--border)", fontFamily: "var(--mono)", fontSize: 12 }}>
                <span style={{ color: "var(--text)" }}>{sizeLabel(s.size)} slot</span>
                <span style={{ color: "var(--muted)" }}>${(s.priceCents / 100).toFixed(0)}/mo</span>
              </div>
            ))}
          </div>
        )}

        {subscriptionStatus !== "past_due" && subscriptionStatus !== "unpaid" && billingAction !== "manage_subscriptions" && (
          <div style={{ marginBottom: 16 }}>
            <p className="label">Add a machine slot</p>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {prices.map(p => (
                <button key={p.size} className="btn" disabled={addingSlot} onClick={() => addSlot(p.size)} style={{ fontSize: 11 }}>
                  {sizeLabel(p.size)} — ${(p.priceCents / 100).toFixed(0)}/mo
                </button>
              ))}
            </div>
          </div>
        )}

        {hasStripeCustomer && <button className="btn btn-ghost" onClick={openPortal}>Manage Billing on Stripe</button>}
      </div>
    </div>
  );
}
