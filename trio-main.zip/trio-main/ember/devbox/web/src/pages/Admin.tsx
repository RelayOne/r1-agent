import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { get, post } from "../lib/api";

export default function Admin() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [detail, setDetail] = useState<any>(null);
  const [creditAmount, setCreditAmount] = useState("");
  const [creditDesc, setCreditDesc] = useState("");

  useEffect(() => {
    get("/api/admin/stats").then(setStats);
    get("/api/admin/users").then(d => setUsers(d.users || []));
  }, []);

  const loadUser = async (id: string) => {
    setSelected(id);
    const d = await get(`/api/admin/users/${id}`);
    setDetail(d);
  };

  const giveCredit = async () => {
    if (!selected || !creditAmount) return;
    await post(`/api/admin/users/${selected}/credit`, { amountCents: parseInt(creditAmount) * 100, description: creditDesc || "Admin credit" });
    setCreditAmount(""); setCreditDesc("");
    loadUser(selected);
  };

  const ban = async (id: string) => { await post(`/api/admin/users/${id}/ban`); get("/api/admin/users").then(d => setUsers(d.users || [])); setDetail(null); };
  const unban = async (id: string) => { await post(`/api/admin/users/${id}/unban`); get("/api/admin/users").then(d => setUsers(d.users || [])); setDetail(null); };

  return (
    <div style={{ minHeight: "100vh", padding: 24, maxWidth: 960, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
        <h1 style={{ fontSize: 22, fontWeight: 400 }}>Admin</h1>
        <button className="btn btn-ghost" onClick={() => navigate("/")}>Dashboard</button>
      </div>

      {/* Stats */}
      {stats && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            ["Users", stats.users],
            ["Machines", stats.machines],
            ["Active Slots", stats.activeSlots],
            ["Revenue", `$${(stats.totalRevenueCents / 100).toFixed(0)}`],
          ].map(([label, val]) => (
            <div key={label as string} className="card" style={{ textAlign: "center", padding: 16 }}>
              <p style={{ fontFamily: "var(--mono)", fontSize: 24, fontWeight: 600, color: "var(--accent)" }}>{val}</p>
              <p style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--dim)", marginTop: 4, textTransform: "uppercase" }}>{label}</p>
            </div>
          ))}
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: detail ? "1fr 1fr" : "1fr", gap: 16 }}>
        {/* User list */}
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ padding: "12px 16px", borderBottom: "1px solid var(--border)" }}>
            <h2 style={{ fontSize: 14, fontWeight: 500 }}>Users ({users.length})</h2>
          </div>
          <div style={{ maxHeight: 500, overflowY: "auto" }}>
            {users.map(u => (
              <button key={u.id} onClick={() => loadUser(u.id)}
                style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%", padding: "10px 16px", background: selected === u.id ? "var(--accent-dim)" : "transparent",
                  border: "none", borderBottom: "1px solid var(--border)", cursor: "pointer", textAlign: "left" }}>
                <div>
                  <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--text)" }}>{u.name || u.email}</p>
                  <p style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--dim)" }}>{u.email}</p>
                </div>
                <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                  {u.role === "admin" && <span style={{ fontFamily: "var(--mono)", fontSize: 9, color: "var(--accent)", background: "var(--accent-dim)", padding: "2px 6px", borderRadius: 4 }}>admin</span>}
                  {u.status === "banned" && <span style={{ fontFamily: "var(--mono)", fontSize: 9, color: "var(--danger)", background: "rgba(239,68,68,.1)", padding: "2px 6px", borderRadius: 4 }}>banned</span>}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* User detail */}
        {detail && (
          <div>
            <div className="card" style={{ marginBottom: 12 }}>
              <h3 style={{ fontSize: 14, fontWeight: 500, marginBottom: 8 }}>{detail.user.name || detail.user.email}</h3>
              <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--dim)", marginBottom: 4 }}>{detail.user.email}</p>
              <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--dim)", marginBottom: 4 }}>Status: {detail.user.status} | Role: {detail.user.role}</p>
              <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--dim)", marginBottom: 12 }}>Credits: ${(detail.user.creditsCents / 100).toFixed(2)}</p>

              <div style={{ display: "flex", gap: 6, marginBottom: 16 }}>
                {detail.user.status !== "banned"
                  ? <button className="btn btn-danger" style={{ fontSize: 10 }} onClick={() => ban(detail.user.id)}>Ban</button>
                  : <button className="btn" style={{ fontSize: 10 }} onClick={() => unban(detail.user.id)}>Unban</button>
                }
              </div>

              {/* Credit */}
              <div style={{ borderTop: "1px solid var(--border)", paddingTop: 12 }}>
                <p className="label">Give credit</p>
                <div style={{ display: "flex", gap: 6 }}>
                  <input className="input" style={{ width: 80 }} placeholder="$" value={creditAmount} onChange={e => setCreditAmount(e.target.value)} />
                  <input className="input" style={{ flex: 1 }} placeholder="Description" value={creditDesc} onChange={e => setCreditDesc(e.target.value)} />
                  <button className="btn btn-primary" style={{ fontSize: 10 }} onClick={giveCredit}>Add</button>
                </div>
              </div>
            </div>

            {/* Machines */}
            <div className="card" style={{ marginBottom: 12, padding: 16 }}>
              <h4 style={{ fontSize: 12, fontWeight: 500, marginBottom: 8 }}>Machines ({detail.machines.length})</h4>
              {detail.machines.map((m: any) => (
                <div key={m.id} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", fontFamily: "var(--mono)", fontSize: 11 }}>
                  <span style={{ color: "var(--text)" }}>{m.name}</span>
                  <span style={{ color: "var(--dim)" }}>{m.state} · {m.size.replace("performance-", "")}</span>
                </div>
              ))}
            </div>

            {/* Billing events */}
            <div className="card" style={{ padding: 16 }}>
              <h4 style={{ fontSize: 12, fontWeight: 500, marginBottom: 8 }}>Billing ({detail.billingEvents.length})</h4>
              {detail.billingEvents.slice(0, 20).map((e: any) => (
                <div key={e.id} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", fontFamily: "var(--mono)", fontSize: 11, borderBottom: "1px solid var(--border)" }}>
                  <span style={{ color: "var(--dim)" }}>{e.type}</span>
                  <span style={{ color: e.amountCents > 0 ? "var(--success)" : "var(--text)" }}>${(e.amountCents / 100).toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
