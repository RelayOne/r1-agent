import React, { useState } from "react";
import { Link } from "react-router-dom";
import { post } from "../lib/api";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError("");
    try {
      const d = await post("/api/account/forgot-password", { email });
      if (d.ok) setSent(true);
    } catch (e: any) {
      setError(e.data?.error || e.message || "Failed to send reset email");
    }
    setLoading(false);
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ width: 380, maxWidth: "100%" }}>
        <h1 style={{ fontSize: 22, fontWeight: 400, marginBottom: 8, textAlign: "center" }}>Reset password</h1>
        <p style={{ fontSize: 13, color: "var(--muted)", textAlign: "center", marginBottom: 24 }}>
          Enter your email and we'll send a reset link.
        </p>
        {sent ? (
          <div className="card" style={{ textAlign: "center", padding: 24 }}>
            <p style={{ fontFamily: "var(--mono)", fontSize: 13, color: "var(--accent)", marginBottom: 12 }}>Check your email</p>
            <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--muted)", lineHeight: 1.6 }}>
              If an account exists for {email}, you'll receive a password reset link shortly.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="card">
            <div style={{ marginBottom: 16 }}>
              <label className="label">Email</label>
              <input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} required autoFocus />
            </div>
            {error && <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--danger)", marginBottom: 12 }}>{error}</p>}
            <button type="submit" className="btn btn-primary" disabled={loading} style={{ width: "100%", justifyContent: "center", padding: "10px 0", fontSize: 13 }}>
              {loading ? "Sending..." : "Send reset link"}
            </button>
          </form>
        )}
        <p style={{ textAlign: "center", marginTop: 20, fontSize: 13, color: "var(--muted)" }}>
          <Link to="/login">Back to sign in</Link>
        </p>
      </div>
    </div>
  );
}
