import React, { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { post } from "../lib/api";

export default function VerifyEmail() {
  const [params] = useSearchParams();
  const token = params.get("token") || "";
  const [status, setStatus] = useState<"verifying" | "success" | "error">("verifying");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!token) { setStatus("error"); setError("Invalid verification link"); return; }
    post("/api/account/verify-email", { token })
      .then(d => { if (d.ok) setStatus("success"); else { setStatus("error"); setError(d.error || "Verification failed. The link may have expired."); } })
      .catch((e: any) => { setStatus("error"); setError(e.data?.error || e.message || "Verification failed"); });
  }, [token]);

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div className="card" style={{ textAlign: "center", padding: 24, maxWidth: 380 }}>
        {status === "verifying" && <p style={{ fontFamily: "var(--mono)", fontSize: 13, color: "var(--muted)" }}>Verifying email...</p>}
        {status === "success" && <>
          <p style={{ fontFamily: "var(--mono)", fontSize: 14, color: "var(--accent)", marginBottom: 12 }}>Email verified</p>
          <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--muted)", marginBottom: 16 }}>Your email address has been confirmed.</p>
          <Link to="/" className="btn btn-primary" style={{ display: "inline-flex", justifyContent: "center" }}>Go to dashboard</Link>
        </>}
        {status === "error" && <>
          <p style={{ fontFamily: "var(--mono)", fontSize: 14, color: "var(--danger)", marginBottom: 12 }}>Verification failed</p>
          <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--muted)", marginBottom: 16 }}>{error}</p>
          <Link to="/settings" style={{ fontFamily: "var(--mono)", fontSize: 12 }}>Resend from settings</Link>
        </>}
      </div>
    </div>
  );
}
