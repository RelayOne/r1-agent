import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth";

export default function Register() {
  const { register, user } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (user) { navigate("/"); return null; }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError("");
    const err = await register(email, password, name);
    if (err) { setError(typeof err === "string" ? err : "Registration failed"); setLoading(false); }
    else navigate("/");
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ width: 380, maxWidth: "100%" }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 16px", background: "var(--accent-dim)", border: "1px solid var(--accent-border)", borderRadius: 24, marginBottom: 20 }}>
            <span className="dot dot-online" style={{ width: 6, height: 6 }} />
            <span style={{ fontFamily: "var(--mono)", fontSize: 13, color: "var(--accent)", fontWeight: 500 }}>ember</span>
          </div>
          <h1 style={{ fontSize: 24, fontWeight: 400, marginBottom: 8 }}>Create account</h1>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 24 }}>
          <a href="/api/auth/github" className="btn btn-ghost" style={{ justifyContent: "center", padding: "10px 0", fontSize: 13 }}>Continue with GitHub</a>
          <a href="/api/auth/google" className="btn btn-ghost" style={{ justifyContent: "center", padding: "10px 0", fontSize: 13 }}>Continue with Google</a>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
          <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
          <span style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--dim)", textTransform: "uppercase" }}>or</span>
          <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
        </div>

        <form onSubmit={handleSubmit} className="card">
          <div style={{ marginBottom: 16 }}>
            <label className="label">Name</label>
            <input className="input" value={name} onChange={e => setName(e.target.value)} required />
          </div>
          <div style={{ marginBottom: 16 }}>
            <label className="label">Email</label>
            <input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} required />
          </div>
          <div style={{ marginBottom: 16 }}>
            <label className="label">Password</label>
            <input className="input" type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={8} />
          </div>
          {error && <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--danger)", marginBottom: 12 }}>{error}</p>}
          <button type="submit" className="btn btn-primary" disabled={loading} style={{ width: "100%", justifyContent: "center", padding: "10px 0", fontSize: 13 }}>
            {loading ? "Creating..." : "Create account"}
          </button>
        </form>

        <p style={{ textAlign: "center", marginTop: 20, fontSize: 13, color: "var(--muted)" }}>
          Have an account? <Link to="/login">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
