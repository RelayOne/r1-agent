import React, { useState } from "react";
import { Link, useSearchParams, useNavigate } from "react-router-dom";
import { post } from "../lib/api";

export default function ResetPassword() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const token = params.get("token") || "";
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (!token) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ textAlign: "center" }}>
        <p style={{ fontFamily: "var(--mono)", fontSize: 14, color: "var(--danger)", marginBottom: 12 }}>Invalid reset link</p>
        <Link to="/forgot-password" style={{ fontFamily: "var(--mono)", fontSize: 12 }}>Request a new one</Link>
      </div>
    </div>
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) { setError("Password must be at least 8 characters"); return; }
    if (password !== confirm) { setError("Passwords do not match"); return; }
    setLoading(true); setError("");
    try {
      const d = await post("/api/account/reset-password", { token, password });
      if (d.ok) setDone(true);
      else setError(d.error || "Reset failed. The link may have expired.");
    } catch (e: any) { setError(e.data?.error || e.message || "Reset failed"); }
    setLoading(false);
  };

  if (done) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div className="card" style={{ textAlign: "center", padding: 24, maxWidth: 380 }}>
        <p style={{ fontFamily: "var(--mono)", fontSize: 14, color: "var(--accent)", marginBottom: 12 }}>Password updated</p>
        <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--muted)", marginBottom: 16 }}>All sessions have been logged out. Sign in with your new password.</p>
        <button className="btn btn-primary" onClick={() => navigate("/login")} style={{ width: "100%", justifyContent: "center" }}>Sign in</button>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ width: 380, maxWidth: "100%" }}>
        <h1 style={{ fontSize: 22, fontWeight: 400, marginBottom: 8, textAlign: "center" }}>Set new password</h1>
        <form onSubmit={handleSubmit} className="card">
          <div style={{ marginBottom: 16 }}>
            <label className="label">New password</label>
            <input className="input" type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={8} autoFocus />
          </div>
          <div style={{ marginBottom: 16 }}>
            <label className="label">Confirm password</label>
            <input className="input" type="password" value={confirm} onChange={e => setConfirm(e.target.value)} required />
          </div>
          {error && <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--danger)", marginBottom: 12 }}>{error}</p>}
          <button type="submit" className="btn btn-primary" disabled={loading} style={{ width: "100%", justifyContent: "center", padding: "10px 0", fontSize: 13 }}>
            {loading ? "Resetting..." : "Reset password"}
          </button>
        </form>
      </div>
    </div>
  );
}
