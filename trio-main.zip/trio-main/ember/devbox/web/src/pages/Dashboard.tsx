import React, { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth";
import { get, post, put, del, safeRedirect } from "../lib/api";
import NewMachineModal from "../components/NewMachineModal";
import MachineMenu from "../components/MachineMenu";

interface Machine {
  id: string; name: string; machineType: "cli" | "vscode";
  flyAppName: string; flyRegion: string; size: string;
  state: string; gitRepo: string | null; hostnameStatus: string | null;
}
interface Pane { id: string; machineId: string | null; col: number; row: number; colSpan: number; rowSpan: number; }
interface Layout { panes: Pane[]; columns: number; rows: number; sidebarCollapsed: boolean; }

const TIcon = () => <span style={{ fontSize: 10, opacity: .6 }}>▸_</span>;
const VIcon = () => <span style={{ fontSize: 10, opacity: .6 }}>◇</span>;
const mIcon = (t: string) => t === "vscode" ? <VIcon /> : <TIcon />;
const dot = (s: string) => s === "started" ? "dot-online" : s === "creating" ? "dot-creating" : s === "stopped" ? "dot-stopped" : "dot-error";

function autoLayout(ms: Machine[]): Layout {
  const live = ms.filter(m => m.state === "started" || m.state === "creating");
  const c = live.length <= 1 ? 1 : live.length <= 4 ? 2 : 3;
  const r = Math.ceil(live.length / c) || 1;
  return { columns: c, rows: r, sidebarCollapsed: false,
    panes: live.map((m, i) => ({ id: `p${i}`, machineId: m.id, col: (i % c) + 1, row: Math.floor(i / c) + 1, colSpan: 1, rowSpan: 1 })) };
}

// Hostname poll interval while machines are in "creating" state
const HOSTNAME_POLL_MS = 5000;

// Terminal ticket: origin + one-time code. Never cached as a raw URL.
// The iframe loads origin+"/", posts { ready: true }, and the parent
// sends the code back via postMessage. This avoids replaying spent codes.
type TerminalTicket = { origin: string; code: string; issuedAt: number };

export default function Dashboard() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [machines, setMachines] = useState<Machine[]>([]);
  const [tickets, setTickets] = useState<Record<string, TerminalTicket>>({});
  const [layout, setLayout] = useState<Layout | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [menu, setMenu] = useState<Machine | null>(null);
  const [mobActive, setMobActive] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [isMobile] = useState(() => window.innerWidth < 768);
  const saveRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const hostnameTimerRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);

  // ── Fetch a fresh terminal ticket for a machine ──────────────
  const fetchTicket = useCallback(async (machineId: string) => {
    try {
      const d = await post<{ terminalUrl: string; code?: string }>(`/api/machines/${machineId}/terminal`);
      if (d?.terminalUrl) {
        const url = new URL(d.terminalUrl);
        const code = d.code || url.searchParams.get("code") || "";
        setTickets(prev => ({
          ...prev,
          [machineId]: { origin: url.origin, code, issuedAt: Date.now() },
        }));
      }
    } catch {}
  }, []);

  const clearTicket = useCallback((machineId: string) => {
    setTickets(prev => { const n = { ...prev }; delete n[machineId]; return n; });
  }, []);

  // ── Load machines ──────────────────────────────────────────
  const load = useCallback(async () => {
    const d = await get<{ machines: Machine[] }>("/api/machines");
    if (!d?.machines) return;
    setMachines(d.machines);
    // Terminal URLs are fetched on-demand when a pane displays a machine,
    // NOT eagerly for all machines. This avoids creating unused sessions.
  }, []);

  // ── Hostname polling for "creating" machines ───────────────
  useEffect(() => {
    const creating = machines.filter(m => m.state === "creating");
    if (creating.length === 0) {
      if (hostnameTimerRef.current) { clearInterval(hostnameTimerRef.current); hostnameTimerRef.current = undefined; }
      return;
    }
    if (hostnameTimerRef.current) return; // Already polling
    hostnameTimerRef.current = setInterval(async () => {
      const current = machines.filter(m => m.state === "creating");
      if (current.length === 0) {
        clearInterval(hostnameTimerRef.current!); hostnameTimerRef.current = undefined; return;
      }
      let anyReady = false;
      for (const m of current) {
        try {
          const d = await post<{ ready: boolean }>(`/api/machines/${m.id}/check-hostname`);
          if (d?.ready) anyReady = true;
        } catch {}
      }
      if (anyReady) load(); // Reload full machine list when any machine becomes ready
    }, HOSTNAME_POLL_MS);
    return () => { if (hostnameTimerRef.current) { clearInterval(hostnameTimerRef.current); hostnameTimerRef.current = undefined; } };
  }, [machines, load]);

  // ── Load saved layout ──────────────────────────────────────
  useEffect(() => {
    load();
    get<{ layout: Layout | null }>("/api/settings/layout").then(d => { if (d?.layout) setLayout(d.layout); }).catch(() => {});
  }, []);

  useEffect(() => { if (!layout && machines.length) setLayout(autoLayout(machines)); }, [machines, layout]);

  const save = (l: Layout) => { setLayout(l); clearTimeout(saveRef.current); saveRef.current = setTimeout(() => put("/api/settings/layout", l).catch(() => {}), 1500); };
  const swapPane = (pid: string, mid: string | null) => { if (!layout) return; save({ ...layout, panes: layout.panes.map(p => p.id === pid ? { ...p, machineId: mid } : p) }); };
  const resizePane = (pid: string, cs: number, rs: number) => { if (!layout) return; save({ ...layout, panes: layout.panes.map(p => p.id === pid ? { ...p, colSpan: cs, rowSpan: rs } : p) }); };
  const addPane = () => { if (!layout) return; const id = `p${Date.now()}`; const c = (layout.panes.length % layout.columns) + 1; const r = Math.floor(layout.panes.length / layout.columns) + 1; save({ ...layout, rows: Math.max(layout.rows, r), panes: [...layout.panes, { id, machineId: null, col: c, row: r, colSpan: 1, rowSpan: 1 }] }); };
  const rmPane = (pid: string) => { if (!layout) return; save({ ...layout, panes: layout.panes.filter(p => p.id !== pid) }); };
  const setGrid = (c: number, r: number) => { if (!layout) return; save({ ...layout, columns: c, rows: r }); };
  const doStart = async (id: string) => { try { setActionError(null); await post(`/api/machines/${id}/start`); setMenu(null); setTimeout(load, 2000); } catch (e: any) { setActionError(`Failed to start: ${e.message || e}`); } };
  const doStop = async (id: string) => { try { setActionError(null); await post(`/api/machines/${id}/stop`); setMenu(null); setTimeout(load, 2000); } catch (e: any) { setActionError(`Failed to stop: ${e.message || e}`); } };
  const doDel = async (id: string) => { try { setActionError(null); await del(`/api/machines/${id}`); setMenu(null); setTickets(p => { const n = { ...p }; delete n[id]; return n; }); load(); } catch (e: any) { setActionError(`Failed to delete: ${e.message || e}`); } };
  const onCreated = async () => { setShowNew(false); await load(); setLayout(null); };

  // Fetch a FRESH terminal URL for new-tab (new one-time code)
  const openNewTab = async (machineId: string) => {
    try {
      const d = await post<{ terminalUrl: string }>(`/api/machines/${machineId}/terminal`);
      if (d?.terminalUrl) safeRedirect(d.terminalUrl);
    } catch (e) {
      console.error("[dashboard] Failed to open terminal:", e);
    }
  };

  const vis = machines.filter(m => m.state !== "deleted");
  const live = vis.filter(m => m.state === "started" || m.state === "creating");
  const stopped = vis.filter(m => m.state === "stopped");
  const mmap = Object.fromEntries(machines.map(m => [m.id, m]));

  // ── Mobile terminal ticket auto-fetch ────────────────────────
  const mobileActiveId = isMobile ? (mobActive || live[0]?.id) : null;
  useEffect(() => {
    if (!mobileActiveId) return;
    const m = machines.find(x => x.id === mobileActiveId);
    if (m && m.state === "started" && !tickets[mobileActiveId]) {
      fetchTicket(mobileActiveId);
    }
  }, [mobileActiveId, machines, tickets, fetchTicket]);

  // ── MOBILE ─────────────────────────────────────────────────
  if (isMobile) {
    const am = live.find(m => m.id === mobActive) || live[0];
    return (<div style={{ height: "100vh", display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", alignItems: "center", padding: "8px 10px", background: "var(--surface)", borderBottom: "1px solid var(--border)", gap: 6 }}>
        <select value={am?.id || ""} onChange={e => setMobActive(e.target.value)}
          style={{ flex: 1, background: "var(--bg)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 4, padding: "4px 6px", fontFamily: "var(--mono)", fontSize: 11 }}>
          {live.map(m => <option key={m.id} value={m.id}>{m.machineType === "vscode" ? "◇ " : "▸ "}{m.name}</option>)}
        </select>
        <button className="btn btn-primary" style={{ padding: "4px 8px", fontSize: 10 }} onClick={() => setShowNew(true)}>+</button>
      </div>
      <div style={{ flex: 1, position: "relative", background: "#000" }}>{am && <TerminalIframe ticket={tickets[am.id]} />}</div>
      {showNew && <NewMachineModal onClose={() => setShowNew(false)} onCreated={onCreated} />}
    </div>);
  }

  // ── DESKTOP ────────────────────────────────────────────────
  const sw = layout?.sidebarCollapsed ? 40 : 190;
  return (
    <div style={{ height: "100vh", display: "grid", gridTemplateColumns: `${sw}px 1fr`, overflow: "hidden" }}>
      {/* Sidebar */}
      <div style={{ display: "flex", flexDirection: "column", background: "var(--surface)", borderRight: "1px solid var(--border)", overflow: "hidden" }}>
        <div style={{ padding: "10px 8px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          {!layout?.sidebarCollapsed && <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
            <span className="dot dot-online" style={{ width: 5, height: 5 }} />
            <span style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--accent)", fontWeight: 600 }}>ember</span>
            <span style={{ fontFamily: "var(--mono)", fontSize: 8, color: "var(--dim)" }}>{live.length}</span>
          </div>}
          <Btn onClick={() => save({ ...(layout || autoLayout(machines)), sidebarCollapsed: !layout?.sidebarCollapsed })}>{layout?.sidebarCollapsed ? "▸" : "◂"}</Btn>
        </div>
        {!layout?.sidebarCollapsed && <div style={{ flex: 1, overflowY: "auto", padding: "4px 0" }}>
          {live.length > 0 && <Lbl>Running</Lbl>}
          {live.map(m => <SbItem key={m.id} onCtx={() => setMenu(m)}>
            <span className={`dot ${dot(m.state)}`} style={{ width: 5, height: 5 }} />{mIcon(m.machineType)}
            <span style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--text)", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.name}</span>
            <span style={{ fontFamily: "var(--mono)", fontSize: 7, color: "var(--dim)" }}>{m.flyRegion}</span>
          </SbItem>)}
          {stopped.length > 0 && <Lbl>Stopped</Lbl>}
          {stopped.map(m => <SbItem key={m.id} onClick={() => setMenu(m)}>
            <span className={`dot ${dot(m.state)}`} style={{ width: 5, height: 5 }} />{mIcon(m.machineType)}
            <span style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--dim)" }}>{m.name}</span>
          </SbItem>)}
        </div>}
        <div style={{ padding: "6px 8px", borderTop: "1px solid var(--border)", display: "flex", flexDirection: "column", gap: 3 }}>
          <button className="btn btn-primary" style={{ width: "100%", justifyContent: "center", padding: "5px 0", fontSize: 9 }} onClick={() => setShowNew(true)}>{layout?.sidebarCollapsed ? "+" : "+ New Machine"}</button>
          {!layout?.sidebarCollapsed && <div style={{ display: "flex", gap: 3 }}>
            <button className="btn btn-ghost" style={{ flex: 1, justifyContent: "center", fontSize: 8, padding: "3px 0" }} onClick={() => nav("/settings")}>Settings</button>
            {user?.role === "admin" && <button className="btn btn-ghost" style={{ flex: 1, justifyContent: "center", fontSize: 8, padding: "3px 0" }} onClick={() => nav("/admin")}>Admin</button>}
          </div>}
        </div>
      </div>

      {/* Grid */}
      <div style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 8px", background: "var(--surface)", borderBottom: "1px solid var(--border)", flexShrink: 0 }}>
          <span style={{ fontFamily: "var(--mono)", fontSize: 9, color: "var(--dim)" }}>Grid</span>
          <GridCtrl cols={layout?.columns || 2} rows={layout?.rows || 2} onChange={setGrid} />
          <Btn onClick={addPane}>+ Pane</Btn>
          <Btn onClick={load}>↻</Btn>
          <div style={{ flex: 1 }} />
          <button className="btn btn-primary" style={{ padding: "3px 8px", fontSize: 9 }} onClick={() => setShowNew(true)}>+ New</button>
        </div>
        <div style={{ flex: 1, display: "grid", gap: 2, padding: 2, overflow: "hidden",
          gridTemplateColumns: `repeat(${layout?.columns || 2}, 1fr)`, gridTemplateRows: `repeat(${layout?.rows || 2}, 1fr)` }}>
          {layout?.panes.map(p => <PaneCard key={p.id} pane={p} m={p.machineId ? mmap[p.machineId] : null}
            ticket={p.machineId ? tickets[p.machineId] : undefined} all={live}
            onSwap={swapPane} onResize={resizePane} onRm={rmPane}
            onMenu={setMenu} onNewTab={openNewTab} onRefresh={fetchTicket}
            onClearTicket={clearTicket} />)}
        </div>
      </div>

      {actionError && <div style={{ position: "fixed", bottom: 16, left: "50%", transform: "translateX(-50%)", zIndex: 600, background: "var(--danger)", color: "#fff", padding: "8px 16px", borderRadius: 8, fontFamily: "var(--mono)", fontSize: 11, display: "flex", alignItems: "center", gap: 8 }}>
        <span>{actionError}</span>
        <button onClick={() => setActionError(null)} style={{ background: "none", border: "none", color: "#fff", cursor: "pointer", fontSize: 14, lineHeight: 1 }}>x</button>
      </div>}
      {showNew && <NewMachineModal onClose={() => setShowNew(false)} onCreated={onCreated} />}
      {menu && <MachineMenu machine={menu} onOpenNewTab={() => { if (menu) openNewTab(menu.id); setMenu(null); }} onClose={() => setMenu(null)} onStart={doStart} onStop={doStop} onDelete={doDel} />}
    </div>
  );
}

// ── Pane Card ────────────────────────────────────────────────
function PaneCard({ pane, m, ticket, all, onSwap, onResize, onRm, onMenu, onNewTab, onRefresh, onClearTicket }: {
  pane: Pane; m: Machine | null; ticket?: TerminalTicket; all: Machine[];
  onSwap: (id: string, mid: string | null) => void;
  onResize: (id: string, cs: number, rs: number) => void;
  onRm: (id: string) => void; onMenu: (m: Machine) => void;
  onNewTab: (id: string) => void; onRefresh: (id: string) => void;
  onClearTicket: (id: string) => void;
}) {
  const [showSize, setShowSize] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string>("");
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploadPaths, setUploadPaths] = useState<string[]>([]);
  const [stokeView, setStokeView] = useState(false);
  const [stokeData, setStokeData] = useState<any>(null);
  const stokeTimerRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  const sel: React.CSSProperties = { background: "var(--bg)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 3, fontSize: 8, padding: "1px 2px" };

  // Terminal ticket lifecycle:
  // Fetch a ticket when a started machine has no ticket and we're not in Stoke view.
  // No periodic refresh needed: the postMessage flow uses the code once and
  // the auth proxy sets a session cookie for subsequent loads.
  useEffect(() => {
    if (!m || m.state !== "started" || stokeView || ticket) return;
    onRefresh(m.id);
  }, [m?.id, m?.state, stokeView, ticket, onRefresh]);

  // Clear ticket when entering Stoke view so a fresh one is fetched on switch back
  const toggleStoke = () => {
    if (!stokeView && m) {
      onClearTicket(m.id);
    }
    setStokeView(!stokeView);
  };

  // Poll Stoke status when in Stoke view
  useEffect(() => {
    if (!stokeView || !m || m.state !== "started") {
      if (stokeTimerRef.current) { clearInterval(stokeTimerRef.current); stokeTimerRef.current = undefined; }
      return;
    }
    const poll = async () => {
      try { setStokeData(await get(`/api/machines/${m.id}/stoke-status`)); } catch {}
    };
    poll();
    stokeTimerRef.current = setInterval(poll, 2000);
    return () => { if (stokeTimerRef.current) clearInterval(stokeTimerRef.current); };
  }, [stokeView, m?.id, m?.state]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files?.length || !m) return;
    setUploadStatus(`Uploading ${files.length} file${files.length > 1 ? "s" : ""}...`);
    setUploadPaths([]);
    let ok = 0;
    let fail = 0;
    const paths: string[] = [];
    for (const file of Array.from(files)) {
      try {
        const form = new FormData();
        form.append("file", file);
        const res = await fetch(`/api/machines/${m.id}/upload`, {
          method: "POST", body: form, credentials: "same-origin",
        });
        if (res.ok) {
          const data = await res.json();
          ok++;
          if (data.path) paths.push(data.path);
        } else fail++;
      } catch { fail++; }
    }
    setUploadPaths(paths);
    setUploadStatus(fail ? `${ok} uploaded, ${fail} failed` : `${ok} file${ok > 1 ? "s" : ""} uploaded`);
    if (fileRef.current) fileRef.current.value = "";
  };

  const copyPath = (p: string) => {
    navigator.clipboard.writeText(p).catch(() => {});
  };

  const dismissUploads = () => { setUploadStatus(""); setUploadPaths([]); };

  return (
    <div style={{ display: "flex", flexDirection: "column", gridColumn: `${pane.col} / span ${pane.colSpan}`, gridRow: `${pane.row} / span ${pane.rowSpan}`,
      background: "#0a0a12", borderRadius: 5, overflow: "hidden", border: "1px solid var(--border)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 3, padding: "2px 5px", background: "var(--surface)", borderBottom: "1px solid var(--border)", flexShrink: 0 }}>
        {m && <span className={`dot ${dot(m.state)}`} style={{ width: 4, height: 4 }} />}
        {m && mIcon(m.machineType)}
        <select value={pane.machineId || ""} onChange={e => onSwap(pane.id, e.target.value || null)}
          style={{ flex: 1, background: "transparent", color: "var(--text)", border: "none", fontFamily: "var(--mono)", fontSize: 9, fontWeight: 500, cursor: "pointer", outline: "none", minWidth: 0 }}>
          <option value="">-- empty --</option>
          {all.map(x => <option key={x.id} value={x.id}>{x.machineType === "vscode" ? "◇ " : "▸ "}{x.name} · {x.flyRegion}</option>)}
        </select>
        {uploadStatus && <span style={{ fontFamily: "var(--mono)", fontSize: 7, color: "var(--accent)", whiteSpace: "nowrap" }}>{uploadStatus}</span>}
        {(uploadStatus || uploadPaths.length > 0) && <HdrBtn onClick={dismissUploads} title="Dismiss">✓</HdrBtn>}
        {m && m.state === "started" && <>
          <input ref={fileRef} type="file" multiple style={{ display: "none" }} onChange={handleUpload} />
          <HdrBtn onClick={() => fileRef.current?.click()} title="Upload files to /workspace/uploads/">📎</HdrBtn>
        </>}
        {m && m.state === "started" && <HdrBtn onClick={toggleStoke} title={stokeView ? "Show terminal" : "Show Stoke progress"} style={stokeView ? { color: "var(--accent)" } : undefined}>⚡</HdrBtn>}
        <HdrBtn onClick={() => setShowSize(!showSize)} title="Resize">⊞</HdrBtn>
        {m && <HdrBtn onClick={() => { onClearTicket(m.id); onRefresh(m.id); }} title="Reconnect">↻</HdrBtn>}
        {m && <HdrBtn onClick={() => onNewTab(m.id)} title="New tab (fresh auth)">↗</HdrBtn>}
        {m && <HdrBtn onClick={() => onMenu(m)} title="Options">⋯</HdrBtn>}
        <HdrBtn onClick={() => onRm(pane.id)} title="Remove pane">×</HdrBtn>
      </div>
      {showSize && <div style={{ display: "flex", gap: 4, padding: "3px 6px", background: "var(--surface)", borderBottom: "1px solid var(--border)", alignItems: "center" }}>
        <span style={{ fontFamily: "var(--mono)", fontSize: 8, color: "var(--dim)" }}>Span</span>
        <label style={{ fontFamily: "var(--mono)", fontSize: 8, color: "var(--muted)" }}>W<select value={pane.colSpan} onChange={e => onResize(pane.id, +e.target.value, pane.rowSpan)} style={sel}>{[1,2,3,4].map(n => <option key={n}>{n}</option>)}</select></label>
        <label style={{ fontFamily: "var(--mono)", fontSize: 8, color: "var(--muted)" }}>H<select value={pane.rowSpan} onChange={e => onResize(pane.id, pane.colSpan, +e.target.value)} style={sel}>{[1,2,3,4].map(n => <option key={n}>{n}</option>)}</select></label>
      </div>}
      {uploadPaths.length > 0 && (
        <div style={{ padding: "3px 6px", background: "var(--surface)", borderBottom: "1px solid var(--border)", maxHeight: 60, overflowY: "auto" }}>
          {uploadPaths.map((p, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 4, padding: "1px 0" }}>
              <span style={{ fontFamily: "var(--mono)", fontSize: 8, color: "var(--accent)", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p}</span>
              <button onClick={() => copyPath(p)} title="Copy path"
                style={{ background: "none", border: "1px solid var(--border)", borderRadius: 3, color: "var(--dim)", cursor: "pointer", padding: "1px 4px", fontSize: 7, fontFamily: "var(--mono)", whiteSpace: "nowrap" }}>copy</button>
            </div>
          ))}
        </div>
      )}
      <div style={{ flex: 1, position: "relative", background: "#000", minHeight: 0 }}>
        {stokeView && m ? <StokeProgress data={stokeData} />
          : m?.state === "creating" ? <Msg>Provisioning hostname...</Msg>
          : m && ticket ? <TerminalIframe ticket={ticket} />
          : m ? <Msg>Loading {m.machineType === "vscode" ? "VS Code" : "terminal"}...</Msg>
          : <Msg>Select a machine ↑</Msg>}
      </div>
    </div>
  );
}

// TerminalIframe: loads the machine origin, waits for { ready: true } postMessage,
// then sends the exchange code back. The auth proxy sets a session cookie so
// subsequent loads don't need a new code. This avoids caching one-time bootstrap URLs.
function TerminalIframe({ ticket }: { ticket?: TerminalTicket }) {
  const ref = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (!ticket) return;
    const onMessage = (e: MessageEvent) => {
      if (e.origin !== ticket.origin) return;
      if (e.source !== ref.current?.contentWindow) return;
      if (e.data?.ready) {
        ref.current?.contentWindow?.postMessage({ code: ticket.code, parentOrigin: window.location.origin }, ticket.origin);
      }
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [ticket?.origin, ticket?.code]);

  if (!ticket) return null;
  // key={ticket.code} forces React to remount the iframe when the code changes.
  // This is what makes "Reconnect" actually work: new ticket = new iframe = fresh
  // auth handshake via postMessage.
  return <iframe key={ticket.code} ref={ref} src={`${ticket.origin}/`} allow="clipboard-read; clipboard-write"
    sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-downloads"
    referrerPolicy="no-referrer"
    style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: 0 }} />;
}
function Msg({ children }: { children: React.ReactNode }) {
  return <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--mono)", fontSize: 10, color: "var(--dim)" }}>{children}</div>;
}

function StokeProgress({ data }: { data: any }) {
  const s = { fontFamily: "var(--mono)" as const };
  if (!data || !data.active) {
    return <div style={{ ...s, position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--dim)", fontSize: 10 }}>
      No active Stoke session. Run <code style={{ color: "var(--accent)", margin: "0 4px" }}>stoke build</code> in the terminal.
    </div>;
  }

  const session = data.session;
  const tasks = session?.tasks || [];
  const phaseIcon = (status: string) => {
    switch (status) {
      case "done": case "committed": return "✓";
      case "executing": case "claimed": case "executed": case "verified": case "reviewed": return "◉";
      case "failed": return "✗";
      case "blocked": return "⊘";
      default: return "○";
    }
  };
  const phaseColor = (status: string) => {
    if (status === "done" || status === "committed") return "var(--accent)";
    if (status === "failed") return "var(--danger)";
    if (["executing", "claimed", "executed", "verified", "reviewed"].includes(status)) return "#f0c040";
    return "var(--dim)";
  };

  const done = tasks.filter((t: any) => t.status === "done" || t.status === "committed").length;
  const total = tasks.length;

  return (
    <div style={{ ...s, position: "absolute", inset: 0, overflow: "auto", padding: "8px 10px", fontSize: 9, color: "var(--text)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 8, color: "var(--muted)" }}>
        <span>{done}/{total} tasks</span>
        {session?.total_cost_usd != null && <span>${session.total_cost_usd.toFixed(2)} AI</span>}
        {session?.burst_workers > 0 && <span>{session.burst_workers} burst</span>}
      </div>
      {tasks.map((t: any) => (
        <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 6, padding: "3px 0", borderBottom: "1px solid var(--border)" }}>
          <span style={{ color: phaseColor(t.status), fontSize: 10, width: 12, textAlign: "center", flexShrink: 0 }}>{phaseIcon(t.status)}</span>
          <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontSize: 9 }}>{t.description || t.id}</span>
          {t.worker && t.worker !== "local" && <span style={{ fontSize: 7, color: "var(--accent)", flexShrink: 0 }}>⚡</span>}
          <span style={{ fontSize: 7, color: "var(--dim)", flexShrink: 0, width: 45, textAlign: "right" }}>{t.status}</span>
        </div>
      ))}
      {session?.plan_id && <div style={{ fontSize: 7, color: "var(--dim)", marginTop: 8 }}>Plan: {session.plan_id}</div>}
    </div>
  );
}
function GridCtrl({ cols, rows, onChange }: { cols: number; rows: number; onChange: (c: number, r: number) => void }) {
  const s: React.CSSProperties = { background: "var(--bg)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 3, fontSize: 8, padding: "1px 2px", fontFamily: "var(--mono)" };
  return (<div style={{ display: "flex", alignItems: "center", gap: 2 }}>
    <select value={cols} onChange={e => onChange(+e.target.value, rows)} style={s}>{[1,2,3,4,5,6].map(n => <option key={n} value={n}>{n}c</option>)}</select>
    <span style={{ fontFamily: "var(--mono)", fontSize: 8, color: "var(--dim)" }}>×</span>
    <select value={rows} onChange={e => onChange(cols, +e.target.value)} style={s}>{[1,2,3,4,5,6].map(n => <option key={n} value={n}>{n}r</option>)}</select>
  </div>);
}
function Btn({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return <button className="btn btn-ghost" style={{ padding: "2px 6px", fontSize: 8 }} onClick={onClick}>{children}</button>;
}
function HdrBtn({ children, onClick, title, style }: { children: React.ReactNode; onClick: () => void; title: string; style?: React.CSSProperties }) {
  return <button onClick={onClick} title={title} style={{ background: "none", border: "none", color: "var(--dim)", cursor: "pointer", padding: "1px 2px", fontSize: 9, lineHeight: 1, ...style }}>{children}</button>;
}
function Lbl({ children }: { children: React.ReactNode }) {
  return <p style={{ fontFamily: "var(--mono)", fontSize: 7, color: "var(--dim)", textTransform: "uppercase", letterSpacing: ".1em", padding: "7px 8px 2px" }}>{children}</p>;
}
function SbItem({ children, onClick, onCtx }: { children: React.ReactNode; onClick?: () => void; onCtx?: () => void }) {
  return <button onClick={onClick} onContextMenu={onCtx ? e => { e.preventDefault(); onCtx(); } : undefined}
    style={{ display: "flex", alignItems: "center", gap: 5, width: "100%", padding: "4px 8px", background: "transparent", border: "none", cursor: "pointer", textAlign: "left" }}>{children}</button>;
}
