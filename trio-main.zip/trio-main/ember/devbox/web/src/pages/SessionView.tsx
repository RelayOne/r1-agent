import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

export default function SessionView() {
  const { id } = useParams<{ id: string }>();
  const [session, setSession] = useState<any>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;
    const poll = async () => {
      try {
        const res = await fetch(`/v1/sessions/${id}`);
        if (!res.ok) { setError("Session not found"); return; }
        setSession(await res.json());
      } catch { setError("Failed to load session"); }
    };
    poll();
    const timer = setInterval(poll, 3000);
    return () => clearInterval(timer);
  }, [id]);

  if (error) return <Page><Msg>{error}</Msg></Page>;
  if (!session) return <Page><Msg>Loading...</Msg></Page>;

  const tasks = session.tasks || [];
  const done = tasks.filter((t: any) => t.status === "done" || t.status === "committed").length;

  return (
    <Page>
      <div style={{ maxWidth: 600, margin: "0 auto", padding: "40px 20px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 24 }}>
          <h1 style={{ fontFamily: "var(--mono)", fontSize: 16, fontWeight: 600, color: "var(--text)", margin: 0 }}>
            Stoke Build
          </h1>
          <span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--dim)" }}>
            {session.status === "completed" ? "completed" : `${done}/${tasks.length} tasks`}
          </span>
        </div>

        {session.plan_id && (
          <div style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--dim)", marginBottom: 16 }}>
            Plan: {session.plan_id}
          </div>
        )}

        <div style={{ display: "flex", gap: 16, marginBottom: 24, fontFamily: "var(--mono)", fontSize: 11 }}>
          {session.total_cost_usd > 0 && <span style={{ color: "var(--muted)" }}>${session.total_cost_usd.toFixed(2)} AI cost</span>}
          {session.burst_workers > 0 && <span style={{ color: "var(--accent)" }}>{session.burst_workers} burst workers</span>}
        </div>

        {tasks.map((t: any, i: number) => (
          <div key={t.id || i} style={{
            display: "flex", alignItems: "center", gap: 10, padding: "10px 0",
            borderBottom: "1px solid var(--border)", fontFamily: "var(--mono)", fontSize: 12,
          }}>
            <span style={{ color: phaseColor(t.status), fontSize: 14, width: 18, textAlign: "center", flexShrink: 0 }}>
              {phaseIcon(t.status)}
            </span>
            <span style={{ flex: 1, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {t.description || t.id}
            </span>
            {t.worker && t.worker !== "local" && <span style={{ fontSize: 10, color: "var(--accent)" }}>burst</span>}
            <span style={{ fontSize: 10, color: "var(--dim)", width: 60, textAlign: "right", flexShrink: 0 }}>{t.status}</span>
          </div>
        ))}

        <div style={{ fontFamily: "var(--mono)", fontSize: 9, color: "var(--dim)", marginTop: 24, textAlign: "center" }}>
          Powered by <a href="https://ember.dev" style={{ color: "var(--accent)", textDecoration: "none" }}>Ember</a>
        </div>
      </div>
    </Page>
  );
}

function Page({ children }: { children: React.ReactNode }) {
  return <div style={{ minHeight: "100vh", background: "var(--bg)" }}>{children}</div>;
}

function Msg({ children }: { children: React.ReactNode }) {
  return <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", fontFamily: "var(--mono)", fontSize: 13, color: "var(--dim)" }}>{children}</div>;
}

function phaseIcon(status: string) {
  switch (status) {
    case "done": case "committed": return "\u2713";
    case "executing": case "claimed": case "executed": case "verified": case "reviewed": return "\u25C9";
    case "failed": return "\u2717";
    default: return "\u25CB";
  }
}

function phaseColor(status: string) {
  if (status === "done" || status === "committed") return "var(--accent)";
  if (status === "failed") return "#e55";
  if (["executing", "claimed", "executed", "verified", "reviewed"].includes(status)) return "#f0c040";
  return "var(--dim)";
}
