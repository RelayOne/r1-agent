import React, { useState, useEffect } from "react";
import { get, post, safeRedirect } from "../lib/api";
import { getOrCreateBillingRequestId, clearBillingRequestId } from "../lib/billingRequestId";

interface Props { onClose: () => void; onCreated: () => void; }

export default function NewMachineModal({ onClose, onCreated }: Props) {
  const [name, setName] = useState("");
  const [machineType, setMachineType] = useState<"cli" | "vscode">("cli");
  const [size, setSize] = useState("performance-8x");
  const [region, setRegion] = useState("sjc");
  const [gitRepo, setGitRepo] = useState("");
  const [repos, setRepos] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [needsSlot, setNeedsSlot] = useState(false);
  const [buyingSlot, setBuyingSlot] = useState(false);

  const [ghConnected, setGhConnected] = useState(true); // assume connected until proven otherwise

  const [ghMethod, setGhMethod] = useState<"app" | "oauth" | "none">("none");

  useEffect(() => {
    let appLoaded = false;
    // Try GitHub App first (preferred: finer-grained, short-lived tokens)
    get("/api/github/app-status").then(d => {
      if (d.installed) {
        get("/api/github/app-repos").then(r => {
          if (r.repos?.length) { setRepos(r.repos); setGhMethod("app"); appLoaded = true; }
        }).catch(() => {});
      } else if (d.configured) {
        setGhMethod("none");
      }
    }).catch(() => {});
    // OAuth fallback (only if App didn't already load repos)
    get("/api/github/repos").then(d => {
      if (d.repos?.length && !appLoaded) {
        setRepos(prev => prev.length ? prev : d.repos);
        setGhMethod(prev => prev === "app" ? prev : "oauth");
      }
      if (d.needsConnect) setGhConnected(false);
    }).catch(() => {});
  }, []);

  const handleCreate = async () => {
    if (!name.trim()) return;
    setLoading(true); setError(""); setNeedsSlot(false);

    try {
      const data = await post("/api/machines", { name: name.trim(), machineType, size, region, gitRepo: gitRepo || undefined });
      if (data.machine) {
        onCreated();
      } else {
        setError("Creation failed");
        setLoading(false);
      }
    } catch (e: any) {
      if (e.status === 402 && e.data?.needsSlot) {
        setNeedsSlot(true);
      } else {
        setError(e.data?.error || e.message || "Creation failed");
      }
      setLoading(false);
    }
  };

  const handleBuySlot = async () => {
    setBuyingSlot(true);
    const requestScope = `new-machine:${size}`;
    const requestId = getOrCreateBillingRequestId(requestScope);
    try {
      const data = await post("/api/billing/checkout", { size, requestId });

      if (data.url) {
        if (data.reason === "fix_payment" || data.reason === "manage_subscriptions") {
          clearBillingRequestId(requestScope);
        }
        setBuyingSlot(false);
        safeRedirect(data.url);
        return;
      }

      if (data.ok && data.slotId) {
        clearBillingRequestId(requestScope);
        setNeedsSlot(false);
        setBuyingSlot(false);
        handleCreate();
      }
    } catch (e: any) {
      setError(e.data?.error || e.message || "Billing failed");
    } finally {
      setBuyingSlot(false);
    }
  };

  const sizeLabel: Record<string, string> = {
    "performance-4x": "4 vCPU / 8GB",
    "performance-8x": "8 vCPU / 16GB",
    "performance-16x": "16 vCPU / 32GB",
  };
  const sizePrice: Record<string, string> = {
    "performance-4x": "$96/mo",
    "performance-8x": "$174/mo",
    "performance-16x": "$348/mo",
  };

  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 500, background: "rgba(0,0,0,.7)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
      <div onClick={e => e.stopPropagation()} style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, width: 440, maxWidth: "92vw", overflow: "hidden" }}>
        <div style={{ padding: "18px 22px 14px", borderBottom: "1px solid var(--border)" }}>
          <h2 style={{ fontFamily: "var(--sans)", fontSize: 16, fontWeight: 500 }}>New Machine</h2>
          <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--muted)", marginTop: 4 }}>Cloud dev environment with Claude Code</p>
        </div>
        <div style={{ padding: 22 }}>
          <div style={{ marginBottom: 14 }}>
            <label className="label">Machine name</label>
            <input className="input" value={name} onChange={e => setName(e.target.value)} placeholder="api-server" autoFocus
              onKeyDown={e => e.key === "Enter" && !needsSlot && handleCreate()} />
          </div>

          <div style={{ marginBottom: 14 }}>
            <label className="label">Type</label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              <button type="button" onClick={() => setMachineType("cli")}
                style={{ padding: "10px 12px", borderRadius: 8, border: `2px solid ${machineType === "cli" ? "var(--accent)" : "var(--border)"}`,
                  background: machineType === "cli" ? "var(--accent-dim)" : "var(--bg)", cursor: "pointer", textAlign: "left" }}>
                <div style={{ fontFamily: "var(--mono)", fontSize: 13, color: "var(--text)", marginBottom: 2 }}>▸_ Terminal</div>
                <div style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--muted)" }}>ttyd + dtach CLI</div>
              </button>
              <button type="button" onClick={() => setMachineType("vscode")}
                style={{ padding: "10px 12px", borderRadius: 8, border: `2px solid ${machineType === "vscode" ? "var(--accent)" : "var(--border)"}`,
                  background: machineType === "vscode" ? "var(--accent-dim)" : "var(--bg)", cursor: "pointer", textAlign: "left" }}>
                <div style={{ fontFamily: "var(--mono)", fontSize: 13, color: "var(--text)", marginBottom: 2 }}>◇ VS Code</div>
                <div style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--muted)" }}>code-server IDE</div>
              </button>
            </div>
          </div>

          <div style={{ marginBottom: 14 }}>
            <label className="label">Git repo (optional)</label>
            {repos.length > 0 ? (
              <select className="input" value={gitRepo} onChange={e => setGitRepo(e.target.value)} style={{ appearance: "none" }}>
                <option value="">None</option>
                {repos.map(r => <option key={r.fullName} value={r.url}>{r.fullName}{r.private ? " 🔒" : ""}</option>)}
              </select>
            ) : (
              <input className="input" value={gitRepo} onChange={e => setGitRepo(e.target.value)} placeholder="https://github.com/you/project" />
            )}
            {!ghConnected && ghMethod !== "app" && (
              <div style={{ marginTop: 6, display: "flex", flexDirection: "column", gap: 4 }}>
                <a href="/api/github/install" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--accent)", display: "inline-block" }}>
                  Install GitHub App (recommended)
                </a>
                <a href="/api/github/connect" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--muted)", display: "inline-block" }}>
                  Or connect with OAuth
                </a>
              </div>
            )}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 14 }}>
            <div>
              <label className="label">Region</label>
              <select className="input" value={region} onChange={e => setRegion(e.target.value)} style={{ appearance: "none" }}>
                <option value="sjc">San Jose</option>
                <option value="ord">Chicago</option>
                <option value="iad">Virginia</option>
                <option value="yyz">Toronto</option>
                <option value="lhr">London</option>
                <option value="nrt">Tokyo</option>
              </select>
            </div>
            <div>
              <label className="label">Size</label>
              <select className="input" value={size} onChange={e => { setSize(e.target.value); setNeedsSlot(false); }} style={{ appearance: "none" }}>
                <option value="performance-4x">{sizeLabel["performance-4x"]} — {sizePrice["performance-4x"]}</option>
                <option value="performance-8x">{sizeLabel["performance-8x"]} — {sizePrice["performance-8x"]}</option>
                <option value="performance-16x">{sizeLabel["performance-16x"]} — {sizePrice["performance-16x"]}</option>
              </select>
            </div>
          </div>

          {needsSlot && (
            <div style={{ background: "var(--accent-dim)", border: "1px solid var(--accent-border)", borderRadius: 8, padding: 14, marginBottom: 14 }}>
              <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--accent)", marginBottom: 8 }}>
                No {size.replace("performance-", "")} slot available
              </p>
              <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--muted)", lineHeight: 1.5, marginBottom: 12 }}>
                Add a {sizeLabel[size]} slot for {sizePrice[size]}. You can create machines in any open slot.
              </p>
              <button className="btn btn-primary" onClick={handleBuySlot} disabled={buyingSlot} style={{ width: "100%", justifyContent: "center" }}>
                {buyingSlot ? "Redirecting to checkout..." : `Add slot — ${sizePrice[size]}`}
              </button>
            </div>
          )}

          {error && <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--danger)", marginBottom: 12 }}>{error}</p>}

          {!needsSlot && (
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
              <button className="btn btn-primary" onClick={handleCreate} disabled={loading || !name.trim()}>
                {loading ? "Creating..." : "Create"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
