import React, { useState } from "react";

interface Machine {
  id: string; name: string; flyAppName: string; state: string;
  size: string; flyRegion: string; machineType?: "cli" | "vscode";
}
interface Props {
  machine: Machine; onOpenNewTab: () => void; onClose: () => void;
  onStart: (id: string) => void; onStop: (id: string) => void;
  onDelete: (id: string) => void;
}

export default function MachineMenu({ machine: m, onOpenNewTab, onClose, onStart, onStop, onDelete }: Props) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const running = m.state === "started";
  const typeLabel = m.machineType === "vscode" ? "VS Code" : "Terminal";

  if (confirmDelete) {
    return (
      <Overlay onClose={onClose}>
        <div style={{ padding: 22 }}>
          <h3 style={{ fontFamily: "var(--sans)", fontSize: 16, fontWeight: 500, marginBottom: 8 }}>Delete {m.name}?</h3>
          <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--muted)", lineHeight: 1.6, marginBottom: 16 }}>
            This destroys the machine, volume, and all data. Cannot be undone.
          </p>
          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn btn-danger" onClick={() => onDelete(m.id)}>Delete</button>
          </div>
        </div>
      </Overlay>
    );
  }

  return (
    <Overlay onClose={onClose}>
      <div style={{ padding: "8px 12px" }}>
        <p style={{ fontFamily: "var(--mono)", fontSize: 12, fontWeight: 500 }}>
          {m.machineType === "vscode" ? "◇ " : "▸ "}{m.name}
        </p>
        <p style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--dim)", marginTop: 2 }}>
          {typeLabel} · {m.flyRegion} · {m.size.replace("performance-", "")} · {m.state}
        </p>
      </div>
      <div style={{ borderTop: "1px solid var(--border)", paddingTop: 6, marginTop: 4 }}>
        {running && <>
          <MenuBtn onClick={onOpenNewTab}>↗ Open in new tab</MenuBtn>
          <MenuBtn onClick={() => onStop(m.id)} color="var(--danger)">■ Stop machine</MenuBtn>
        </>}
        {!running && <MenuBtn onClick={() => onStart(m.id)} color="var(--success)">▶ Start machine</MenuBtn>}
        <div style={{ borderTop: "1px solid var(--border)", marginTop: 4, paddingTop: 4 }} />
        <MenuBtn onClick={() => setConfirmDelete(true)} color="var(--danger)">✕ Delete machine</MenuBtn>
      </div>
    </Overlay>
  );
}

function Overlay({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 500, background: "rgba(0,0,0,.7)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
      <div onClick={e => e.stopPropagation()} style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, width: 300, maxWidth: "92vw", padding: 8 }}>
        {children}
      </div>
    </div>
  );
}

function MenuBtn({ children, onClick, color }: { children: React.ReactNode; onClick: () => void; color?: string }) {
  return (
    <button onClick={onClick} style={{ display: "flex", alignItems: "center", gap: 10, width: "100%", padding: "8px 12px", background: "transparent", border: "none", cursor: "pointer", borderRadius: 6, textAlign: "left", fontFamily: "var(--mono)", fontSize: 12, color: color || "var(--text)" }}>
      {children}
    </button>
  );
}
