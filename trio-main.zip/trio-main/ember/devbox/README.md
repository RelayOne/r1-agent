# Ember Cloud

Cloud dev machines with Claude Code, Codex, VS Code, Rust, and Git.

## Production requirements

This build now **fails fast** in production unless all of the following are true:

- `APP_URL` is HTTPS
- `MACHINE_HOST_SUFFIX` is a custom domain (not `.fly.dev`)
- `RECONCILE_SECRET` is configured
- billing, Fly, and database secrets are present

That is intentional. Embedded terminal iframes are not reliable on `*.fly.dev` in production because browser cookie policy treats them as cross-site.

## Machine types

Each machine is either **CLI** or **VS Code**:

| Type | Backend | UI | Use case |
|------|---------|-----|----------|
| `cli` | ttyd + dtach on port 8082 | Terminal in iframe | Quick tasks, scripts, Claude Code CLI |
| `vscode` | code-server on port 8082 | Full VS Code IDE in iframe | Multi-file editing, extensions, debugging |

Both types use the same auth proxy on port 8080, same Fly Machine image, and same exchange-code terminal auth flow. The `MACHINE_TYPE` env var is set per-machine at creation time and controls which service `start.sh` launches behind the proxy.

VS Code machines install code-server with Python, Rust, and Go extensions. User data and extensions are stored in `/workspace/.vscode-server` and `/workspace/.vscode-extensions` on the persistent volume, so they survive stop/start cycles.

## Dashboard layout

The dashboard uses a customizable CSS Grid:

- **Grid size**: Toolbar dropdowns set columns (1-6) and rows (1-6)
- **Pane assignment**: Each pane has a header dropdown listing all running machines. Select any machine to hot-swap the pane content.
- **Pane spanning**: Click ⊞ on any pane to set its column span and row span (1-4 each). VS Code panes work well at 2x2; terminals at 1x1.
- **Add/remove panes**: `+ Pane` adds empty slots; `×` removes them.
- **Sidebar**: Collapsible machine list with type icons (▸_ for CLI, ◇ for VS Code).
- **Persistence**: Layout auto-saves to `PUT /api/settings/layout` (debounced 1.5s) and loads on page refresh.
- **Mobile**: Single-machine select dropdown with full-screen iframe.

## Terminal auth flow

1. Dashboard calls `POST /api/machines/:id/terminal`
2. API creates a one-time exchange code in Postgres (60s TTL) and a terminal session record
3. API returns `{ terminalUrl, exchangeUrl, code, sessionId }`
4. Dashboard sets `terminalUrl` as the iframe src (points to `https://{machine}/auth/init?code=...`)
5. The init page auto-POSTs the code to `/auth/exchange` (same-origin, code never logged as URL by the proxy)
6. Auth proxy validates the code via `POST /api/machines/verify-code`, sets HMAC-signed session cookie (24h TTL, includes sessionId)
7. Init page redirects to `/` which proxies to ttyd (terminal)
8. Logout / ban / password reset revoke terminal sessions via `/internal/revoke`
9. If machine hostname is still provisioning (`hostnameStatus: "pending"`), terminal returns 503; Dashboard polls `POST /:id/check-hostname` until ready

The dashboard reconnect button and refresh action fetch fresh terminal bootstrap URLs.

## Billing invariants

- Slots are provisioned on `invoice.paid`
- `customer.subscription.*` changes always fetch live subscription state from Stripe API (never trust event payload ordering)
- `lastStripeEventId` and `lastStripeEventTs` are written on every sync for audit trail
- Users with delinquent subscriptions are redirected to Stripe portal with `reason: "fix_payment"`
- Users with multiple active subscriptions are redirected to Stripe portal with `reason: "manage_subscriptions"` (canonical subscription is only determined when exactly one is active)
- Purchase intents use client-provided `requestId` as the intent ID, so retries reuse the same Stripe idempotency key
- `RECONCILE_SECRET` protects `/api/billing/reconcile` in production

## Custom domains

Use a custom machine suffix such as `.ember.dev` in production.

You must:

1. Configure wildcard DNS for the suffix so machine hostnames resolve to Fly
2. Set `MACHINE_HOST_SUFFIX=.ember.dev`
3. Set `APP_URL=https://app.ember.dev`
4. Deploy the API with `RECONCILE_SECRET` configured

Machine creation now requests certificates through Fly's certificates API. If hostname provisioning is not yet ready, the machine is created in `state: "creating"` and terminal access returns 503 until the certificate is confirmed via the `POST /:id/check-hostname` endpoint. Dashboard polls this automatically.

Billing stop reconciliation now supports both a secret-protected `/api/billing/reconcile` endpoint and an optional in-process loop controlled by `RECONCILE_INTERVAL_SECONDS` (set this in production so transient Fly stop failures self-heal).

## GitHub

- Login uses `user:email` only
- Private repo access uses a separate `/api/github/connect` flow
- Repo tokens are only forwarded for `github.com` clone URLs
- The clone URL is scrubbed from `.git/config` after clone
- `GIT_TOKEN` is unset before user startup scripts run

## Local setup

```bash
npm install
cd web && npm install && cd ..
cp .env.example .env
createdb ember
npm run db:migrate
npm run seed admin@example.com password
npm run dev
```

## Migrations

```bash
# Generate new Drizzle migration after schema changes
npm run db:generate
git add drizzle/

# Run ALL migrations (Drizzle + SQL from migrations/)
npm run db:migrate
```

SQL migrations in `migrations/` (e.g. credit ledger PL/pgSQL functions) are idempotent
and run automatically by `src/migrate.ts` after Drizzle migrations.

## Production deploy

```bash
# machine image
cd machine-image && fly deploy --ha=false

# API
fly orgs create ember-prod
fly apps create ember-api --org ember-prod
fly postgres create --name ember-db --region sjc
fly postgres attach ember-db --app ember-api

fly secrets set \
  STRIPE_SECRET_KEY=... \
  STRIPE_WEBHOOK_SECRET=... \
  STRIPE_PRICE_4X=... \
  STRIPE_PRICE_8X=... \
  STRIPE_PRICE_16X=... \
  FLY_API_TOKEN=... \
  FLY_ORG=ember-prod \
  CANONICAL_IMAGE_DIGEST=registry.fly.io/ember-image@sha256:... \
  APP_URL=https://app.ember.dev \
  API_URL=https://app.ember.dev \
  INTERNAL_API_URL=http://ember-api.internal:3000 \
  MACHINE_HOST_SUFFIX=.ember.dev \
  RECONCILE_SECRET=... \
  APP_ENCRYPTION_KEY=... \
  EMAIL_PROVIDER=resend \
  RESEND_API_KEY=re_... \
  GITHUB_CLIENT_ID=... \
  GITHUB_CLIENT_SECRET=... \
  GOOGLE_CLIENT_ID=... \
  GOOGLE_CLIENT_SECRET=... \
  --app ember-api

fly deploy
fly ssh console --app ember-api -C "node dist/migrate.js"
fly ssh console --app ember-api -C "node dist/seed.js admin@example.com strong-password"
```

Schedule a periodic POST to `/api/billing/reconcile` with `Authorization: Bearer $RECONCILE_SECRET`.

## Stripe webhooks

Configure:

- `checkout.session.completed`
- `invoice.paid`
- `invoice.payment_failed`
- `customer.subscription.created`
- `customer.subscription.updated`
- `customer.subscription.paused`
- `customer.subscription.resumed`
- `customer.subscription.deleted`

## Rate limiting

In-memory sliding window, per IP. Limits per endpoint group:

| Route | Window | Max |
|-------|--------|-----|
| `/api/auth/login`, OAuth | 15 min | 20 |
| `/api/auth/register` | 1 hour | 5 |
| `/api/billing/checkout` | 1 min | 10 |
| `/api/machines/*` | 1 min | 20 |
| `/api/machines/*/terminal` | 1 min | 30 |
| All `/api/*` | 1 min | 120 |

Responses include `X-RateLimit-Limit`, `X-RateLimit-Remaining`, and `Retry-After` headers. 429 returns JSON `{ error: "..." }`.

For multi-instance deployments, set `RATE_LIMIT_BACKEND=postgres` to use a shared `rate_limit_hits` table (auto-created on first request). The billing reconciler also uses `pg_try_advisory_lock` so only one instance runs reconciliation at a time.

## CSRF protection

All state-changing requests to `/api/*` require a matching `Origin` header. Exempt: Stripe webhooks (signature-verified), machine-to-API calls (Bearer token), reconcile (secret).

## Monitoring

`GET /api/health` -- public, returns `{ status: "ok" }`.

`GET /api/health/detailed` -- requires `Authorization: Bearer $RECONCILE_SECRET`. Returns:

```json
{
  "status": "ok | degraded",
  "users": 42,
  "machines": { "total": 10, "running": 5, "needs_stop": 0, "error": 0 },
  "slots": { "active": 8, "cancelled": 2 },
  "alerts": []
}
```

Status is `degraded` when `needs_stop` or `error` machines exist. Wire this to your alerting system. The reconciler auto-retries `needs_stop` machines every 60 seconds. `error` machines need manual cleanup via admin panel or `flyctl`.

## Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | Yes | Postgres connection string |
| `APP_URL` | Yes | Public URL (https in production) |
| `API_URL` | Yes | URL machines use to call the API |
| `INTERNAL_API_URL` | Yes (prod) | Fly 6PN address for machine-to-API (e.g. `http://ember-api.internal:3000`) |
| `MACHINE_HOST_SUFFIX` | Yes | `.ember.dev` for production |
| `FLY_API_TOKEN` | Yes | Fly.io org-scoped API token |
| `FLY_ORG` | Yes | Fly organization slug |
| `CANONICAL_IMAGE_DIGEST` | Yes | Machine image digest |
| `STRIPE_SECRET_KEY` | Yes | Stripe API key |
| `STRIPE_WEBHOOK_SECRET` | Yes | Stripe webhook signing secret |
| `STRIPE_PRICE_4X` | Yes | Stripe price ID for 4-vCPU |
| `STRIPE_PRICE_8X` | Yes | Stripe price ID for 8-vCPU |
| `STRIPE_PRICE_16X` | Yes | Stripe price ID for 16-vCPU |
| `RECONCILE_SECRET` | Yes | Secret for reconcile + monitoring |
| `APP_ENCRYPTION_KEY` | Yes | 32-byte hex key for OAuth token encryption |
| `EMAIL_PROVIDER` | Yes (prod) | `resend` in production (`console` blocked in prod) |
| `RESEND_API_KEY` | If resend | Resend API key |
| `GITHUB_CLIENT_ID` | Yes | GitHub OAuth app client ID |
| `GITHUB_CLIENT_SECRET` | Yes | GitHub OAuth app client secret |
| `GOOGLE_CLIENT_ID` | Yes | Google OAuth client ID |
| `GOOGLE_CLIENT_SECRET` | Yes | Google OAuth client secret |
| `GITHUB_APP_ID` | No | GitHub App ID (preferred for repo access) |
| `GITHUB_APP_PRIVATE_KEY` | No | GitHub App RSA private key |
| `GITHUB_APP_SLUG` | No | GitHub App URL slug |
| `RECONCILE_INTERVAL_SECONDS` | No | Background reconciler interval (default: 60 in prod, 0 in dev) |
| `RATE_LIMIT_BACKEND` | No | `postgres` for multi-instance; default: in-memory |
| `NODE_ENV` | - | Set to `production` for config validation |

### Stoke integration variables

These enable Ember to act as a burst worker backend for Stoke:

| Variable | Required | Description |
|----------|----------|-------------|
| `ENABLE_V1_WORKERS` | Yes (Stoke) | Enable `/v1/workers` endpoint for Stoke burst workers |
| `ENABLE_MANAGED_AI` | No | Enable `/v1/ai/chat` proxy endpoint for Stoke managed AI routing |

Without `ENABLE_V1_WORKERS`, Ember returns HTTP 501 to Stoke's worker pool requests. Stoke handles this gracefully and reports a user-friendly error.

## Security notes

Machines run as root. This is a deliberate choice for dev machines where users need to install system packages, run Docker, and modify system configuration. For shared or untrusted environments, add a non-root user in the machine image and drop privileges after startup.

