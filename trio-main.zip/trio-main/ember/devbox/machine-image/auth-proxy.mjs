// auth-proxy.mjs — reverse proxy for ttyd terminal auth
//
// Exchange flow (no secrets in URLs):
//   1. Dashboard gets exchangeUrl + code from API via POST
//   2. Dashboard's JS sends POST /auth/exchange with {code} in body
//   3. Proxy validates code via API callback
//   4. Sets HMAC-signed session cookie
//   5. Returns JSON {ok: true, redirect: "/"}
//   6. Dashboard opens iframe to / (cookie handles auth)
//
// Cookie: {issuedAt}.{sessionVersion}.{nonce}.{hmac}
// SESSION_SECRET includes BOOT_NONCE so restart invalidates old cookies.
// /internal/revoke bumps sessionVersion for explicit revocation.
// SameSite=None on fly.dev (cross-site), Lax on custom domains.

import http from "http";
import { createHmac, randomBytes, timingSafeEqual } from "crypto";

const MACHINE_TOKEN = process.env.MACHINE_TOKEN || "";
const API_URL = process.env.API_URL || "";
const FLY_APP = process.env.FLY_APP_NAME || "";
const TTYD_PORT = 8082;
const COOKIE_NAME = "ember_session";
const COOKIE_MAX_AGE = 86400;
const SESSION_TTL = 86400;

if (!MACHINE_TOKEN) {
  console.error("FATAL: MACHINE_TOKEN not set.");
  process.exit(1);
}

const BOOT_NONCE = randomBytes(16).toString("hex");
const SESSION_SECRET = createHmac("sha256", "ember-session")
  .update(MACHINE_TOKEN + ":" + BOOT_NONCE).digest("hex");

let sessionVersion = 0;

const hostSuffix = process.env.MACHINE_HOST_SUFFIX || ".fly.dev";
const SAME_SITE = hostSuffix === ".fly.dev" ? "None" : "Lax";

function makeSessionCookie(sessionId) {
  const issuedAt = Math.floor(Date.now() / 1000);
  const nonce = randomBytes(12).toString("hex");
  const sid = sessionId || "none";
  const payload = `${issuedAt}.${sessionVersion}.${sid}.${nonce}`;
  const sig = createHmac("sha256", SESSION_SECRET).update(payload).digest("hex").slice(0, 32);
  return `${payload}.${sig}`;
}

function validateSessionCookie(value) {
  if (!value) return false;
  const parts = value.split(".");
  if (parts.length !== 5) return false;
  const [issuedAtStr, versionStr, _sessionId, nonce, sig] = parts;

  if (parseInt(versionStr, 10) !== sessionVersion) return false;

  const payload = `${issuedAtStr}.${versionStr}.${_sessionId}.${nonce}`;
  const expected = createHmac("sha256", SESSION_SECRET).update(payload).digest("hex").slice(0, 32);
  if (sig.length !== expected.length) return false;
  if (!timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;

  const issuedAt = parseInt(issuedAtStr, 10);
  if (isNaN(issuedAt) || Math.floor(Date.now() / 1000) - issuedAt > SESSION_TTL) return false;

  return true;
}

function getSessionIdFromCookie(value) {
  if (!value) return null;
  const parts = value.split(".");
  if (parts.length !== 5) return null;
  return parts[2] === "none" ? null : parts[2];
}

function getCookie(req, name) {
  return (req.headers.cookie || "").split(";").reduce((v, c) => {
    const [k, val] = c.trim().split("=");
    return k === name ? val : v;
  }, null);
}

function isAuthed(req) {
  return validateSessionCookie(getCookie(req, COOKIE_NAME));
}

function setCookieHeader(res, sessionId) {
  const value = makeSessionCookie(sessionId);
  res.setHeader("Set-Cookie",
    `${COOKIE_NAME}=${value}; Path=/; HttpOnly; SameSite=${SAME_SITE}; Max-Age=${COOKIE_MAX_AGE}; Secure`);
}

async function verifyCode(code) {
  if (!API_URL) return null;
  try {
    const res = await fetch(`${API_URL}/api/machines/verify-code`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${MACHINE_TOKEN}` },
      body: JSON.stringify({ code, flyAppName: FLY_APP }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.ok ? data : null; // Returns { ok, userId, machineId, sessionId }
  } catch (e) {
    console.error("[auth-proxy] verify-code error:", e.message);
    return null;
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (chunk) => chunks.push(chunk));
    req.on("end", () => resolve(Buffer.concat(chunks).toString()));
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  // GET /auth/init?code=xxx: Iframe bootstrap page.
  // Serves a minimal HTML page that auto-POSTs the code to /auth/exchange (same-origin),
  // sets the session cookie, then redirects to / (the terminal).
  // The exchange code is one-time-use with 60s TTL, so the brief URL exposure is acceptable.
  if (url.pathname === "/auth/init" && req.method === "GET") {
    const code = url.searchParams.get("code");
    if (!code) {
      res.writeHead(400, { "Content-Type": "text/plain" });
      res.end("Missing code");
      return;
    }
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(`<!DOCTYPE html><html><body style="background:#000;color:#888;font-family:monospace;display:flex;align-items:center;justify-content:center;height:100vh;margin:0"><p>Connecting...</p><script>
fetch("/auth/exchange",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:${JSON.stringify(code)}})})
.then(r=>r.json()).then(d=>{if(d.ok)location.href="/";else document.body.innerText="Auth failed: "+d.error;})
.catch(e=>{document.body.innerText="Connection error";});
</script></body></html>`);
    return;
  }

  // POST /auth/exchange: exchange code for session cookie (no secrets in URL)
  if (url.pathname === "/auth/exchange" && req.method === "POST") {
    try {
      const body = JSON.parse(await readBody(req));
      const code = body?.code;
      if (!code) {
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: false, error: "Missing code" }));
        return;
      }
      const verifyResult = await verifyCode(code);
      if (!verifyResult) {
        res.writeHead(401, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: false, error: "Invalid or expired code" }));
        return;
      }
      setCookieHeader(res, verifyResult.sessionId);
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ ok: true }));
    } catch (e) {
      res.writeHead(400, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ ok: false, error: "Bad request" }));
    }
    return;
  }

  // POST /internal/revoke: bump sessionVersion (called by API on logout/ban)
  if (url.pathname === "/internal/revoke" && req.method === "POST") {
    const auth = req.headers["authorization"];
    if (auth !== `Bearer ${MACHINE_TOKEN}`) {
      res.writeHead(401); res.end("Unauthorized"); return;
    }
    sessionVersion++;
    console.log(`[auth-proxy] Revoked, version=${sessionVersion}`);
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ ok: true, version: sessionVersion }));
    return;
  }

  // GET /internal/stoke-status: read Stoke session state for Ember dashboard pane
  if (url.pathname === "/internal/stoke-status" && req.method === "GET") {
    const auth = req.headers["authorization"];
    if (auth !== `Bearer ${MACHINE_TOKEN}`) {
      res.writeHead(401); res.end("Unauthorized"); return;
    }
    const { readFileSync, existsSync } = await import("fs");
    const sessionPath = "/workspace/.stoke/session.json";
    const reportGlob = "/workspace/.stoke/reports/latest.json";

    let session = null, report = null;
    try {
      if (existsSync(sessionPath)) {
        session = JSON.parse(readFileSync(sessionPath, "utf-8"));
      }
    } catch {}
    try {
      if (existsSync(reportGlob)) {
        report = JSON.parse(readFileSync(reportGlob, "utf-8"));
      }
    } catch {}

    const status = { active: !!session, session, report };
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(status));
    return;
  }

  // POST /internal/upload: receive a file from the API and write to /workspace/uploads/
  // File comes as raw body with filename in X-Filename header.
  if (url.pathname === "/internal/upload" && req.method === "POST") {
    const auth = req.headers["authorization"];
    if (auth !== `Bearer ${MACHINE_TOKEN}`) {
      res.writeHead(401); res.end("Unauthorized"); return;
    }
    const rawFilename = req.headers["x-filename"] || "upload";
    // Sanitize: strip path traversal, keep only basename
    const filename = rawFilename.replace(/[/\\:*?"<>|]/g, "_").replace(/^\.+/, "").slice(0, 200) || "upload";
    const uploadDir = "/workspace/uploads";

    try {
      const { mkdirSync, writeFileSync } = await import("fs");
      mkdirSync(uploadDir, { recursive: true });

      const chunks = [];
      for await (const chunk of req) chunks.push(chunk);
      const data = Buffer.concat(chunks);

      if (data.length === 0) {
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: false, error: "Empty file" }));
        return;
      }
      if (data.length > 100 * 1024 * 1024) { // 100MB limit
        res.writeHead(413, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: false, error: "File too large (100MB max)" }));
        return;
      }

      const destPath = `${uploadDir}/${filename}`;
      writeFileSync(destPath, data);
      console.log(`[auth-proxy] Upload: ${filename} (${data.length} bytes) -> ${destPath}`);

      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ ok: true, path: destPath, size: data.length }));
    } catch (e) {
      console.error("[auth-proxy] upload error:", e.message);
      res.writeHead(500, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ ok: false, error: "Write failed" }));
    }
    return;
  }

  // GET /auth/status: check if session is valid (for dashboard iframe health check)
  if (url.pathname === "/auth/status" && req.method === "GET") {
    const valid = isAuthed(req);
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ authenticated: valid }));
    return;
  }

  // All other requests: require valid session cookie
  if (!isAuthed(req)) {
    if (url.pathname === "/" || url.pathname === "") {
      // Landing page with auth exchange JS
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Ember Terminal</title>
<style>body{background:#07070d;color:#6e6e82;font-family:monospace;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}</style>
</head><body><div id="msg">Authenticating...</div>
<script>
// Parent window sends the exchange code via postMessage
window.addEventListener("message", async (e) => {
  if (!e.data?.code || !e.data?.parentOrigin) return;
  // Validate origin matches the declared parent origin
  if (e.origin !== e.data.parentOrigin) return;
  try {
    const r = await fetch("/auth/exchange", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      credentials: "same-origin",
      body: JSON.stringify({ code: e.data.code })
    });
    const d = await r.json();
    if (d.ok) { window.location.reload(); }
    else { document.getElementById("msg").textContent = d.error || "Auth failed"; }
  } catch(e) { document.getElementById("msg").textContent = "Connection error"; }
});
// Tell parent we're ready for the code
window.parent?.postMessage({ ready: true }, "*");
</script></body></html>`);
      return;
    }
    res.writeHead(401, { "Content-Type": "text/html" });
    res.end("<html><body style='background:#07070d;color:#6e6e82;font-family:monospace;display:flex;align-items:center;justify-content:center;height:100vh'>Session expired</body></html>");
    return;
  }

  // Proxy to ttyd
  const proxyReq = http.request({
    hostname: "127.0.0.1", port: TTYD_PORT,
    path: req.url, method: req.method, headers: req.headers,
  }, (proxyRes) => {
    res.writeHead(proxyRes.statusCode, proxyRes.headers);
    proxyRes.pipe(res);
  });
  proxyReq.on("error", () => {
    res.writeHead(502, { "Content-Type": "text/plain" });
    res.end("Terminal not ready");
  });
  req.pipe(proxyReq);
});

server.on("upgrade", (req, socket, head) => {
  if (!isAuthed(req)) {
    socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");
    socket.destroy();
    return;
  }
  const proxyReq = http.request({
    hostname: "127.0.0.1", port: TTYD_PORT,
    path: req.url, method: "GET", headers: req.headers,
  });
  proxyReq.on("upgrade", (proxyRes, proxySocket, proxyHead) => {
    socket.write(
      "HTTP/1.1 101 Switching Protocols\r\n" +
      Object.entries(proxyRes.headers).map(([k, v]) => `${k}: ${v}`).join("\r\n") +
      "\r\n\r\n"
    );
    if (proxyHead.length) socket.write(proxyHead);
    proxySocket.pipe(socket);
    socket.pipe(proxySocket);
  });
  proxyReq.on("error", () => socket.destroy());
  proxyReq.end();
});

server.listen(8080, "0.0.0.0", () => {
  console.log(`  Auth proxy on :8080 -> ttyd :${TTYD_PORT} (SameSite=${SAME_SITE})`);
});
