#!/bin/bash
set -eu

# ═══════════════════════════════════════════════════════════════
# Ember machine entrypoint
#
# Architecture:
#   auth-proxy.mjs :8080 (public) -> ttyd :8082 (localhost only)
#   Auth flow: dashboard issues one-time exchange code via API,
#   iframe loads /auth?code=xxx, proxy validates via API callback,
#   sets HMAC-signed HttpOnly session cookie with 24h server-side TTL.
#
# Persistence:
#   dtach keeps the shell alive while the VM runs.
#   /workspace is a persistent volume across stop/start.
#   dtach state (processes, in-memory history) is lost on stop.
# ═══════════════════════════════════════════════════════════════

echo "ember starting..."

# ── Git config ────────────────────────────────────────────────
git config --global init.defaultBranch main
git config --global user.email "${GIT_EMAIL:-dev@ember.dev}"
git config --global user.name "${GIT_NAME:-ember}"

# ── Clone repo (first boot with empty workspace only) ─────────
if [ -n "${GIT_REPO:-}" ]; then
  if [ ! -d "/workspace/.git" ] && [ -z "$(ls -A /workspace 2>/dev/null)" ]; then
    echo "  Cloning $GIT_REPO..."
    if [ -n "${GIT_TOKEN:-}" ]; then
      # Only use token for github.com URLs (prevent token exfiltration)
      case "$GIT_REPO" in
        https://github.com/*|https://www.github.com/*)
          # Use GIT_ASKPASS instead of embedding token in URL.
          # This prevents the token from appearing in:
          #   - process listings (ps aux)
          #   - git error output
          #   - .git/config (no scrubbing needed)
          #   - server logs
          cat > /tmp/git-askpass.sh << 'ASKEOF'
#!/bin/sh
# GIT_ASKPASS script: returns username or password depending on the prompt
case "$1" in
  *Username*) echo "x-access-token" ;;
  *Password*) echo "${GIT_TOKEN}" ;;
esac
ASKEOF
          chmod +x /tmp/git-askpass.sh
          GIT_ASKPASS=/tmp/git-askpass.sh git clone "$GIT_REPO" /workspace 2>&1 | grep -v "^remote:" || echo "  Clone failed, continuing"
          rm -f /tmp/git-askpass.sh
          ;;
        *)
          echo "  WARNING: GIT_TOKEN only supported for github.com URLs, cloning without auth"
          git clone "$GIT_REPO" /workspace 2>&1 || echo "  Clone failed, continuing"
          ;;
      esac
    else
      git clone "$GIT_REPO" /workspace 2>&1 || echo "  Clone failed, continuing"
    fi
  fi
fi

# ── Scrub GIT_TOKEN immediately after clone ───────────────────
# Must happen before startup script runs (user code shouldn't see it)
unset GIT_TOKEN 2>/dev/null || true

# ── Pull and run startup script from API ──────────────────────
# MACHINE_TOKEN still available here for the API call, but GIT_TOKEN is gone.
if [ -n "${MACHINE_TOKEN:-}" ] && [ -n "${API_URL:-}" ]; then
  echo "  Fetching startup script from $API_URL..."
  SCRIPT=$(curl -sf --max-time 10 "${API_URL}/api/machines/${FLY_APP_NAME:-unknown}/startup" \
    -H "Authorization: Bearer ${MACHINE_TOKEN}" 2>/dev/null || echo "")
  if [ -n "$SCRIPT" ] && [ "$SCRIPT" != "# no startup script configured" ]; then
    echo "  Running startup script..."
    echo "$SCRIPT" > /tmp/user-startup.sh
    # Run without MACHINE_TOKEN so user startup code can't read it
    env -u MACHINE_TOKEN bash /tmp/user-startup.sh 2>&1 || echo "  Startup script exited with error, continuing"
    echo "  Startup script done"
  fi
fi

# ── API key status ────────────────────────────────────────────
[ -n "${ANTHROPIC_API_KEY:-}" ] && echo "  ANTHROPIC_API_KEY set"
[ -n "${OPENAI_API_KEY:-}" ]    && echo "  OPENAI_API_KEY set"

# ── Metadata API (port 8081, internal only) ───────────────────
cat > /tmp/api-server.py << 'PYEOF'
import http.server, json, os, subprocess, socket

class Handler(http.server.BaseHTTPRequestHandler):
    def respond(self, code, data):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def _backend_healthy(self):
        """Check if the backend service (ttyd or code-server) is listening on port 8082."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            s.connect(("127.0.0.1", 8082))
            s.close()
            return True
        except Exception:
            return False

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/health":
            backend_up = self._backend_healthy()
            if backend_up:
                self.respond(200, {"status": "ok", "session": os.path.exists("/tmp/dev"), "backend": True})
            else:
                self.respond(503, {"status": "unhealthy", "session": os.path.exists("/tmp/dev"), "backend": False})
        elif path == "/meta":
            self.respond(200, {
                "hostname": socket.gethostname(),
                "fly_app": os.getenv("FLY_APP_NAME", "unknown"),
                "fly_region": os.getenv("FLY_REGION", "unknown"),
                "label": os.getenv("EMBER_LABEL", "ember"),
            })
        elif path == "/stats":
            mem = subprocess.run(["free", "-m"], capture_output=True, text=True)
            disk = subprocess.run(["df", "-h", "/workspace"], capture_output=True, text=True)
            load = subprocess.run(["cat", "/proc/loadavg"], capture_output=True, text=True)
            self.respond(200, {"memory": mem.stdout, "disk": disk.stdout, "load": load.stdout.strip()})
        else:
            self.respond(404, {"error": "not found"})

    def log_message(self, fmt, *args): pass

http.server.ThreadingHTTPServer(("0.0.0.0", 8081), Handler).serve_forever()
PYEOF
python3 /tmp/api-server.py &
echo "  Metadata API on :8081 (internal only)"

# ── Create dtach session (always, for CLI access even in vscode mode) ──
if [ ! -S /tmp/dev ]; then
  env -u MACHINE_TOKEN dtach -n /tmp/dev -Ez bash -l
  sleep 0.5
fi
(while true; do [ ! -S /tmp/dev ] && env -u MACHINE_TOKEN dtach -n /tmp/dev -Ez bash -l; sleep 5; done) &

# ── Start backend service on localhost:8082 with supervision ──
MACHINE_TYPE="${MACHINE_TYPE:-cli}"

start_backend() {
  if [ "$MACHINE_TYPE" = "vscode" ]; then
    code-server \
      --bind-addr 127.0.0.1:8082 \
      --auth none \
      --disable-telemetry \
      --disable-update-check \
      --disable-workspace-trust \
      --user-data-dir /workspace/.vscode-server \
      --extensions-dir /workspace/.vscode-extensions \
      /workspace
  else
    ttyd --port 8082 --interface lo --writable dtach -a /tmp/dev -Ez
  fi
}

# Supervisor loop: restart backend if it crashes (runs in background)
(
  while true; do
    echo "  [supervisor] Starting ${MACHINE_TYPE} backend on :8082..."
    start_backend
    EXIT_CODE=$?
    echo "  [supervisor] Backend exited with code $EXIT_CODE, restarting in 2s..."
    sleep 2
  done
) &
SUPERVISOR_PID=$!
echo "  Backend supervisor PID $SUPERVISOR_PID (type: $MACHINE_TYPE)"

# Wait for ttyd to start
sleep 0.5

# ── Start auth proxy on :8080 (validates via exchange code + cookie) ──
echo "ember ready."
exec node /auth-proxy.mjs
