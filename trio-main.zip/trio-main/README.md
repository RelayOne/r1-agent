# Trio

Three tools. One stack. Cloud dev environments powered by AI, running on your own microVM infrastructure.

**Trio** is a vertically integrated platform for AI-powered cloud development. It combines an AI coding orchestrator, a cloud dev environment platform, and a Firecracker microVM runtime into a single cohesive system. Instead of stitching together five SaaS products, you own the entire stack from "think about what to build" to "VM boots and code runs."

## Why Trio?

Running AI coding agents at scale requires more than just an API key. You need isolated environments, machine provisioning, billing, auth, and an orchestration layer smart enough to retry failures, route across models, and enforce quality gates. Today that means gluing together Fly.io, GitHub Codespaces, and a pile of bash scripts.

Trio eliminates this by giving you three purpose-built components that work together out of the box -- or independently if you only need one.

## The Three Components

### Stoke -- AI Coding Orchestrator

Deterministic PLAN -> EXECUTE -> VERIFY -> COMMIT phases with multi-model routing, parallel agent coordination, and structured quality layers. Drives Claude Code and Codex as execution engines.

The thesis: SWE-bench Pro shows the same model jumps ~15 points when you optimize the scaffold. The harness is the product.

- 20 commands: `run`, `build`, `plan`, `scan`, `audit`, `status`, `pool`, `doctor`, `yolo`, `scope`, `repair`, `ship`, `mission`, `notify`, `serve`, `add-claude`, `add-codex`, `pools`, `remove-pool`, `version`
- 104 internal packages, 18,000+ lines source, 2,019 test functions
- Mission system with model-driven convergence validation, multi-model consensus, cross-session memory, and research persistence
- 5-provider fallback chain (Claude -> Codex -> OpenRouter -> API -> lint-only)
- 11-layer policy engine with sandbox isolation
- Adversarial critic (pattern + model-driven) + cross-model review gates (multi-layer verification)
- Intelligent retry with 10 failure classes and same-error escalation
- Two-pass convergence validator: regex scan + model-driven semantic analysis (8 categories)
- Cross-surface dependency mapping (Go/TypeScript/Python endpoint + consumer extraction)

```bash
# Single task
stoke run --task "Add request ID middleware" --dry-run

# Multi-task plan with parallel agents
stoke build --plan stoke-plan.json --workers 4

# Generate a plan from codebase analysis
stoke plan --task "Add JWT auth"

# Multi-perspective audit (17 personas)
stoke audit --dry-run
```

### Ember -- Cloud Dev Environment Platform

Cloud dev machines with Claude Code, Codex, VS Code, Rust, and Git. Handles billing (Stripe), GitHub integration, machine provisioning, terminal auth, and a multi-pane dashboard.

- CLI and VS Code machine types on Fly.io
- Stripe-based billing with slot provisioning
- GitHub OAuth + GitHub App for private repo access
- Exchange-code terminal auth with HMAC session cookies
- Customizable grid dashboard with hot-swappable panes
- Automatic machine reconciliation and health monitoring

```bash
cd ember/devbox
npm install && cd web && npm install && cd ..
cp .env.example .env
createdb ember
npm run db:migrate
npm run dev
```

### Flare -- Firecracker MicroVM Infrastructure

Fly Machines API on your own infrastructure. Firecracker microVMs on GCP with a Postgres-backed control plane, placement daemons on MIG hosts, and a Fly-compatible REST API.

- Fly-compatible REST API (apps, machines, hostnames)
- Split desired/observed state model
- Atomic host capacity scheduling with `SELECT FOR UPDATE SKIP LOCKED`
- Cloudflare Tunnel ingress with hostname-based routing
- Placement daemon with disk-based recovery
- TypeScript SDK included

```bash
cd flare
go build ./...
go test ./...

# TypeScript SDK
cd sdk/typescript && npm install && npm run build
```

## How They Connect

```
Developer
   |
   v
 stoke (AI orchestrator)
   |  EMBER_API_KEY + EMBER_API_URL
   v
 ember (cloud dev platform)
   |  FLY_API_TOKEN + FLY_ORG
   v
 Fly.io  -- or --  flare (self-hosted microVMs)
```

1. **stoke** receives a task or plan. It resolves a provider, acquires a pool slot, creates a git worktree, and drives Claude Code or Codex through plan/execute/verify/commit phases.
2. **stoke** can spawn workers on **ember** via API key authentication. Ember provisions cloud machines with the right tooling pre-installed.
3. **ember** currently provisions machines on **Fly.io** using the Fly Machines API. Each machine gets a persistent volume, auth proxy, and terminal or VS Code access.
4. **flare** provides a Fly-compatible API on your own GCP infrastructure. It is the planned replacement backend for ember, giving you full control over the VM layer.

## Project Status

### Shipped
- stoke: Full orchestrator with 20 commands, 104 packages, model-driven convergence, multi-model consensus, cross-surface mapping, mission orchestration, cross-session memory, adversarial review
- ember: Production cloud dev platform with billing, GitHub integration, multi-pane dashboard
- flare: v1 control plane and placement daemon with Fly-compatible API, TypeScript SDK

### In Progress
- Migrating ember from Fly.io to flare as the VM backend
- flare: Persistent volumes, guest agent for exec, control plane HA
- stoke: Remote worker provisioning via ember, real e2e testing

### Coming Next
- flare: OCI image support, tenant billing, live migration
- ember: Multi-region support, team workspaces
- Full trio integration: stoke provisions ember workers that run on flare

## Development

Each component builds independently:

```bash
# Stoke (Go)
cd stoke && go build ./cmd/stoke && go test ./...

# Ember (Node.js/TypeScript)
cd ember/devbox && npm install && npm run dev

# Flare (Go + TypeScript SDK)
cd flare && go build ./... && go test ./...
cd flare/sdk/typescript && npm install && npm run build
```

## Documentation

| Document | What You'll Find |
|---|---|
| [Architecture](docs/ARCHITECTURE.md) | System components, integration points, data flow, flare SDK |
| [How It Works](docs/HOW-IT-WORKS.md) | End-to-end user journey, auth flow, data flow with diagrams |
| [Feature Map](docs/FEATURE-MAP.md) | Every feature across all three components with status |
| [Deployment](docs/DEPLOYMENT.md) | Prerequisites, env vars, build, deploy for each component |
| [Business Value](docs/BUSINESS-VALUE.md) | Target market, problem, solution |

## License

MIT

---
*Last updated: 2026-04-04*
