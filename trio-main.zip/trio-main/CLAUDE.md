# Project

## Commands
```bash
# EDIT THESE:
# build:     npm run build
# test:      npm test
# lint:      npm run lint
# typecheck: npx tsc --noEmit
```

## Structure
<!-- EDIT: 3-5 lines about your project -->
- Monorepo. Per-package CLAUDE.md for package-specific context.
- Import shared packages by name, not relative paths across boundaries.

## Docs
Project docs live in `docs/` and must be updated at every phase transition.
Files: README.md, ARCHITECTURE.md, HOW-IT-WORKS.md, FEATURE-MAP.md, DEPLOYMENT.md, BUSINESS-VALUE.md
Each has status sections: Done / In Progress / Scoped / Scoping / Potential-On Horizon.
Doc updates get their own git commit. Always.

## Compaction
When compacting, preserve: current plan file path, all modified file paths, build/test results.

## Rules
- Never classify failures as "pre-existing" to skip them. ALL failures are findings. Present to user. User decides.
- FIXED requires a commit hash: "STATUS: FIXED (commit: abc1234)". Hooks verify the hash exists in git.
- BLOCKED is honest. Use it when you genuinely can't fix something. Present BLOCKED items to user for triage.
- USER-SKIPPED requires explicit user approval via AskUserQuestion before writing.
- Always write findings to a report file (audit/ or plans/) BEFORE presenting them verbally.
