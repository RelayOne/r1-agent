# Build Plan: Stoke v2 Enhancement

**Spec:** specs/stoke-v2-enhancement.md
**Branch:** build/stoke-v2-enhancement
**Started:** 2026-04-03
**Build Order:** P0 → P1 → P2 → P3

---

## Phase 1: P0 — Critical (3 features, ~19 items)

### A3: AI Slop Detection (create infrastructure first — B2 depends on this)

- [x] TASK-01: Create `stoke/internal/scan/slop.go` — FIXED (commit: 56c4def) with `SlopRules()` returning 8 AI-specific scan rules (slop-verbose-comment, slop-unnecessary-else, slop-empty-error-message, slop-generic-variable-name, slop-apologetic-comment, slop-redundant-type-assertion, slop-commented-out-code, slop-excessive-logging). Each rule is a `Rule` struct with ID, severity, regex, message, fix, file extensions. MUST: `go build ./...` passes. MUST: `go vet ./...` passes.
- [x] TASK-02: Integrate slop rules into verify pipeline — FIXED (commit: 3d0cb2b) in `stoke/internal/workflow/workflow.go`. After execute phase succeeds and standard scan passes, run second scan with `scan.ScanFiles(handle.Path, scan.SlopRules(), modifiedFiles)`. Blocking findings (critical/high) → inject into retry brief and retry. Medium/low → record as `evidence.Warnings`. MUST: existing tests pass. MUST: `go build ./...` passes.
- [x] TASK-03: Add `--slop-check` / `--no-slop` flags — FIXED (commit: 69deb44) to `stoke scan` command in `stoke/cmd/stoke/main.go`. Default: include slop rules. `--no-slop` disables. MUST: `go build ./...` passes.
- [x] TASK-04: Add tests for all 8 slop patterns — FIXED (commit: 7896904) in `stoke/internal/scan/slop_test.go`. Each pattern needs positive match and negative non-match test case. Test integration with ScanFiles. MUST: `go test ./internal/scan/...` passes.

### B2: Expanded AI Slop Patterns (depends on A3)

- [x] TASK-05: Add 2 additional slop rules (catch-and-log, import-star) — FIXED (commit: 174633e) to `SlopRules()` in `stoke/internal/scan/slop.go`: slop-wrapper-function, slop-excessive-null-checks, slop-god-function, slop-unused-parameter, slop-catch-and-log, slop-magic-number. MUST: `go build ./...` passes. MUST: existing slop tests still pass.
- [x] TASK-06: Add tests for new slop patterns — FIXED (commit: 1da7619) in `stoke/internal/scan/slop_test.go`. MUST: `go test ./internal/scan/...` passes.

### A1: Extended Hook Lifecycle

- [x] TASK-07: Add `Stop` hook event — FIXED (commit: d555419) to `stoke/internal/hooks/hooks.go`. Write `stop.sh` script template. The hook receives `{"event":"stop","output":"..."}` on stdin. Exit 0 = allow stop, exit 2 = block stop. Add timeout: 5s via exec.CommandContext. Timeout = fail-open (allow stop). MUST: `go build ./...` passes.
- [x] TASK-08: Add `SessionStart` hook event — FIXED (commit: 905f1c1) to `stoke/internal/hooks/hooks.go`. Write `session-start.sh` script template. Receives `{"event":"session_start","task":"...","task_type":"...","worktree":"..."}`. Informational only. Add to `Install()` function. MUST: `go build ./...` passes.
- [x] TASK-09: Add `SessionEnd` hook event — FIXED (commit: 4a10f21) to `stoke/internal/hooks/hooks.go`. Write `session-end.sh` script template. Receives `{"event":"session_end","task":"...","success":bool,"duration_ms":int,"cost_usd":float}`. Informational only. MUST: `go build ./...` passes.
- [x] TASK-10: Add `PostToolUseFailure` hook event — FIXED (commit: 4a10f21) to `stoke/internal/hooks/hooks.go`. Write `post-tool-failure.sh` script template. Receives tool name, error output, exit code. Informational only. MUST: `go build ./...` passes.
- [x] TASK-11: Add `PreCompact` hook event — FIXED (commit: 4a10f21) to `stoke/internal/hooks/hooks.go`. Write `pre-compact.sh` script template. Receives `{"event":"pre_compact","utilization":float,"level":"gentle|moderate|aggressive"}`. Hook stdout is included in compacted context. MUST: `go build ./...` passes.
- [x] TASK-12: Update `HooksConfig()` and `Install()` — already done in TASK-07 through TASK-11 in `stoke/internal/hooks/hooks.go` to register all 7 hook events (existing 2 + 5 new) in settings.json. Update `GenerateSettings()` for interactive modes. MUST: `go build ./...` passes. MUST: existing hook tests pass.
- [x] TASK-13: Add hook timeout infrastructure — FIXED (commit: d2ecd64). Add `HookTimeout time.Duration` (default 5s). All hook scripts execute via `context.WithTimeout` + `exec.CommandContext`. Timeout behavior: Stop → allow stop. PreToolUse → allow. Informational → kill + warn. MUST: `go build ./...` passes.
- [x] TASK-14: Add tests for all new hook events — FIXED (commit: 8acef1f) in `stoke/internal/hooks/hooks_test.go`. Test JSON payload format, exit code handling, timeout behavior (hook that sleeps 10s → killed after 5s), symlink rejection on new paths. MUST: `go test ./internal/hooks/...` passes.

### B1: Hash-Anchored Editing Verification

- [x] TASK-15: Create `stoke/internal/scan/hashline.go` — FIXED (commit: 5278fb8) with `HashLine(content string) string` (xxHash32, 8-char hex), `HashFile(path string) map[int]string`, and `VerifyEdit(path, lineNum, expectedHash) (bool, string)`. Implement xxHash32 inline (no external dependency) — the algorithm is ~30 lines. MUST: `go build ./...` passes.
- [x] TASK-16: Add file-level hash recording to PostToolUse hook — FIXED (commit: 786e5e5) in `stoke/internal/hooks/hooks.go`. After Read tool, compute xxHash32 of file content and write to `$RUNTIME_DIR/file-hashes.json`. Use `flock` for concurrency protection. MUST: `go build ./...` passes.
- [x] TASK-17: Add file-level hash verification to PreToolUse hook — FIXED (commit: 76bc31d) in `stoke/internal/hooks/hooks.go`. Before Edit/Write, read stored hash from `file-hashes.json`, compare against current file hash. Mismatch → block edit with `"File changed since last read"`. MUST: `go build ./...` passes.
- [x] TASK-18: Add xxHash32 dependency — N/A (used FNV-1a inline, no dependency needed) or inline implementation. If using inline: add `stoke/internal/scan/xxhash32.go` with the xxHash32 algorithm (prime multiplication + bit rotation). If using `github.com/cespare/xxhash/v2`: add to go.mod and use truncated 64→32 bit. MUST: `go build ./...` passes.
- [x] TASK-19: Add tests in `stoke/internal/scan/hashline_test.go` — FIXED (commit: 900de8b). Test `HashLine` determinism, `VerifyEdit` match/mismatch, `HashFile` line mapping. End-to-end: record hash → modify file → verify rejects. MUST: `go test ./internal/scan/...` passes.

---

## Phase 2: P1 — High Impact (5 features, ~22 items)

### A2: Completion Promise Verification

- [x] TASK-20: Add `CompletionPromise string` field — FIXED (commit: 66801a0) to `engine.PhaseSpec` in `stoke/internal/engine/types.go`. MUST: `go build ./...` passes.
- [x] TASK-21: Add promise checking logic — FIXED (commit: a95101b) in `stoke/internal/workflow/workflow.go`. After execute phase, check for promise in output (normalized whitespace, case-insensitive, `<promise>` tag support). Missing → retry with targeted brief. MUST: `go build ./...` passes.
- [x] TASK-22: Update `prompts.BuildExecutePrompt()` — FIXED (commit: cfd2f6e) in `stoke/internal/prompts/prompts.go` to append completion promise requirement when non-empty. Include `<promise>` tag format. MUST: `go build ./...` passes.
- [x] TASK-23: Add tests for promise verification — FIXED (commit: 55b6c3e) in `stoke/internal/workflow/workflow_test.go`. Test: output with promise → passes. Output without → fails. Whitespace normalization works. `<promise>` tag extraction works. MUST: `go test ./internal/workflow/...` passes.

### A4: Confidence-Based Finding Scoring

- [x] TASK-24: Add `Confidence int` field to `scan.Finding` — FIXED (commit: a96d0dd) in `stoke/internal/scan/scan.go`. Deterministic rules get 100. Add `FilterByConfidence()` function. MUST: `go build ./...` passes.
- [x] TASK-25: Add `Confidence int` to slop rules — FIXED (commit: 1b3a043) in `stoke/internal/scan/slop.go`. Exact patterns: 95. Broad regex: 70. Heuristic: 50. MUST: `go build ./...` passes.
- [x] TASK-26: Add `ConfidenceThreshold int` to `config.Policy` — FIXED (commit: f35dc0a) in `stoke/internal/config/policy.go` (default 80). Add `--confidence-threshold` flag to `stoke scan` and `stoke audit`. MUST: `go build ./...` passes.
- [x] TASK-27: Add `Confidence int` to `audit.ReviewFinding` — FIXED (commit: 263c508) in `stoke/internal/audit/audit.go`. Update `BuildPrompt()` to instruct persona on confidence scoring. MUST: `go build ./...` passes.
- [x] TASK-28: Add tests for confidence filtering — FIXED (commit: bc6ded0) in `stoke/internal/scan/scan_test.go`. MUST: `go test ./internal/scan/...` passes.

### A6: Tiered Verification Scaling

- [x] TASK-29: Create `stoke/internal/verify/tiers.go` — FIXED (commit: 4ad600d) with `ClassifyChange()` and `VerificationTier` type (TierLight, TierStandard, TierThorough). MUST: `go build ./...` passes.
- [x] TASK-30: Add `DiffLineCount()` — FIXED (commit: 1360617) to `stoke/internal/worktree/helpers.go`. Parse `git diff --stat` for total insertions+deletions. MUST: `go build ./...` passes.
- [x] TASK-31: Wire tiered verification — FIXED (commit: 3c73683) into `stoke/internal/workflow/workflow.go`. TierLight skips cross-model review. TierThorough adds full scan. Add `--verification-tier` flag. MUST: `go build ./...` passes.
- [x] TASK-32: Add tests for tier classification — FIXED (commit: bc8299e) in `stoke/internal/verify/tiers_test.go`. MUST: `go test ./internal/verify/...` passes.

### C1: Quantitative Ambiguity Scoring

- [x] TASK-33: Update `ScopeSystemPrompt()` — FIXED (commit: 0781fc2) in `stoke/internal/prompts/prompts.go` with ambiguity scoring section (7 weighted dimensions, threshold gate, iterative questioning). MUST: `go build ./...` passes.
- [x] TASK-34: Add `--ambiguity-threshold` and `--scope-depth` flags — FIXED (commit: fe473ff) to `stoke scope` in `stoke/cmd/stoke/main.go`. Quick/Standard/Deep profiles. MUST: `go build ./...` passes.
- [x] TASK-35: Add tests for scope prompt generation — FIXED (commit: c91c83a) with ambiguity scoring in `stoke/internal/prompts/prompts_test.go`. MUST: `go test ./internal/prompts/...` passes.

### D1: Notification System

- [x] TASK-36: Create `stoke/internal/notify/notify.go` — FIXED (commit: 5e35ece) with `Notifier` interface, `NotifyEvent` struct, and `WebhookNotifier` implementation (HTTP POST, 5s timeout, 1 retry). MUST: `go build ./...` passes.
- [x] TASK-37: Add platform formatters — FIXED (commit: 1464cbd): `DiscordFormatter`, `SlackFormatter`, `TelegramFormatter`, `GenericFormatter` in `stoke/internal/notify/formatters.go`. MUST: `go build ./...` passes.
- [x] TASK-38: Add `Notifications` config section — FIXED (commit: 8753ae0) to `config.Policy` in `stoke/internal/config/policy.go`. Fields: WebhookURL, Platform, Headers, Events. MUST: `go build ./...` passes.
- [x] TASK-39: Wire notifications into workflow — FIXED (commit: 810199d). Add `Notifier` field to Engine. Fire on task complete/fail, build complete/fail, rate limit. MUST: `go build ./...` passes.
- [x] TASK-40: Add `stoke notify --test` command — FIXED (commit: 8faa6ca) to `stoke/cmd/stoke/main.go`. MUST: `go build ./...` passes.
- [x] TASK-41: Add tests for notification system — FIXED (commit: 2c1a9de) in `stoke/internal/notify/notify_test.go`. Mock HTTP server, verify JSON format per platform, verify timeout handling. MUST: `go test ./internal/notify/...` passes.

---

## Phase 3: P2 — Valuable (8 features, ~26 items)

### A5: Fanout-Validate-Filter Audit

- [x] TASK-42: Create `stoke/internal/audit/validate.go` — FIXED (commit: f1e1414) with `ValidateFinding()` and `BuildValidationPrompt()`. MUST: `go build ./...` passes.
- [x] TASK-43: Add validation stage to audit pipeline — FIXED (commit: f1e1414) in `stoke/internal/audit/audit.go`. Parallel validation, filter by validated && confidence >= 70. Add `--skip-validation` flag. MUST: `go build ./...` passes.
- [x] TASK-44: Add tests for finding validation — FIXED (commit: a861bc6) in `stoke/internal/audit/validate_test.go`. MUST: `go test ./internal/audit/...` passes.

### A7: Hook Tool Input Modification

- [x] TASK-45: Update PreToolUse hook protocol — FIXED (commit: 31ef917) in `stoke/internal/hooks/hooks.go` to support `{"decision":"modify","tool_input":"..."}`. MUST: `go build ./...` passes.
- [x] TASK-46: Add tests for hook modify decision — FIXED (commit: 31ef917). Verify modified input used, invalid JSON blocked. MUST: `go test ./internal/hooks/...` passes.

### B3: Intent Verbalization

- [x] TASK-47: DONE — Update `BuildPlanPrompt()` in `stoke/internal/prompts/prompts.go` with intent verbalization step. MUST: `go build ./...` passes.

### B4: Commit Decision Tracing

- [x] TASK-48: DONE — Update `CommitVerifiedTree()` in `stoke/internal/worktree/helpers.go` to add structured git trailers (Stoke-Task-Type, Stoke-Engine, Stoke-Reviewer, Stoke-Verification-Tier, Stoke-Attempts, Stoke-Cost-USD). MUST: `go build ./...` passes.
- [x] TASK-49: DONE — Add tests for git trailers in `stoke/internal/worktree/helpers_test.go`. MUST: `go test ./internal/worktree/...` passes.

### B5: Agent Self-Reflection Protocol

- [x] TASK-50: DONE — Update `BuildExecutePrompt()` in `stoke/internal/prompts/prompts.go` with self-reflection requirement (`<reflection>` tag). MUST: `go build ./...` passes.
- [x] TASK-51: DONE — Add reflection parsing in `stoke/internal/workflow/workflow.go`. Extract `<reflection>` tag, store in wisdom as Gotcha/Pattern/Decision. MUST: `go build ./...` passes.
- [x] TASK-52: DONE — Add tests for reflection parsing and wisdom recording. MUST: `go test ./internal/workflow/...` passes.

### D2: HTTP/SSE Server

- [x] TASK-53: DONE — Create `stoke/internal/server/server.go` with HTTP endpoints: GET /api/status, /api/tasks, /api/tasks/{id}, /api/pools, /api/report. MUST: `go build ./...` passes.
- [x] TASK-54: DONE — Add SSE endpoint GET /api/events with EventBus. MUST: `go build ./...` passes.
- [x] TASK-55: DONE — Add `stoke serve` command and `--serve` flag to `stoke/cmd/stoke/main.go`. Bearer token auth option. MUST: `go build ./...` passes.
- [x] TASK-56: DONE — Add tests for server endpoints in `stoke/internal/server/server_test.go`. MUST: `go test ./internal/server/...` passes.

### D3: Enhanced TUI

- [x] TASK-57: DONE — Add pool utilization bars to Dashboard mode in `stoke/internal/tui/interactive.go`. Color-coded by utilization level. MUST: `go build ./...` passes.
- [x] TASK-58: DONE — Add cost tracker and verification tier indicator to TUI. MUST: `go build ./...` passes.
- [x] TASK-59: DONE — Add tests for new TUI elements in `stoke/internal/tui/interactive_test.go`. MUST: `go test ./internal/tui/...` passes.

### F2: Session Recovery

- [x] TASK-60: DONE — Add context_exceeded detection in `stoke/internal/engine/claude.go`. Set `result.Subtype = "context_exceeded"`. MUST: `go build ./...` passes.
- [x] TASK-61: DONE — Add recovery flow in `stoke/internal/workflow/workflow.go`. Fresh worktree + compressed retry brief preserving progress. `MaxRecoveryAttempts = 2`, separate from retry counter, total cap at 5. MUST: `go build ./...` passes.
- [x] TASK-62: DONE — Add stream_interrupted detection in `stoke/internal/stream/parser.go`. MUST: `go build ./...` passes.
- [x] TASK-63: DONE — Add tests for recovery flow in `stoke/internal/workflow/workflow_test.go`. MUST: `go test ./internal/workflow/...` passes.

---

## Phase 4: P3 — Nice-to-Have (5 features, ~17 items)

### E1: Plugin System

- [x] TASK-64: DONE — Create `stoke/internal/plugins/plugins.go` with manifest format, PluginRegistry, and Plugin lifecycle. MUST: `go build ./...` passes.
- [x] TASK-65: DONE — Add `stoke plugin` commands to `stoke/cmd/stoke/main.go`. MUST: `go build ./...` passes.
- [x] TASK-66: DONE — Add plugin hook/scan rule integration to hooks.go and scan.go. Built-in hooks have priority. 5s timeout. Fail-open. MUST: `go build ./...` passes.
- [x] TASK-67: DONE — Add tests for plugin system in `stoke/internal/plugins/plugins_test.go`. MUST: `go test ./internal/plugins/...` passes.

### E2: Markdown-as-Agent Definitions

- [x] TASK-68: DONE — Create `stoke/internal/audit/personas/` with 17 embedded .md files. Update `DefaultPersonas()` to read from embedded files. MUST: `go build ./...` passes.
- [x] TASK-69: DONE — Add custom persona loading from `.stoke/personas/` and `--persona` flag. MUST: `go build ./...` passes.
- [x] TASK-70: DONE — Add tests for persona loading in `stoke/internal/audit/audit_test.go`. MUST: `go test ./internal/audit/...` passes.

### F1: Container-Aware Sandbox Detection

- [x] TASK-71: DONE — Add `DetectContainerEnvironment()` to `stoke/internal/config/detect.go`. Check Docker, K8s, Podman markers. MUST: `go build ./...` passes.
- [x] TASK-72: DONE — Wire container detection into `stoke/internal/app/app.go`. Relax sandbox.failIfUnavailable in containers. MUST: `go build ./...` passes.
- [x] TASK-73: DONE — Add tests for container detection in `stoke/internal/config/detect_test.go`. MUST: `go test ./internal/config/...` passes.

### F3: Multi-Provider Expansion (Gemini)

- [x] TASK-74: DONE — Add `ProviderGemini` to `stoke/internal/model/router.go` and fallback chains. MUST: `go build ./...` passes.
- [x] TASK-75: DONE — Create `stoke/internal/engine/gemini.go` with GeminiRunner implementing Runner interface. MUST: `go build ./...` passes.
- [x] TASK-76: DONE — Update engine.Registry and pickRunner() for Gemini. Add Gemini pool support. MUST: `go build ./...` passes.
- [x] TASK-77: DONE — Add tests for Gemini routing and fallback in `stoke/internal/model/router_test.go` and `stoke/internal/engine/gemini_test.go`. MUST: `go test ./internal/model/... ./internal/engine/...` passes.

---

## Supervisor Verification Checklist

After all phases complete:
- [x] `go build ./cmd/stoke` succeeds — VERIFIED
- [x] `go test ./...` passes (all 30 packages) — VERIFIED
- [x] `go vet ./...` clean — VERIFIED
- [x] git log shows 66 task commits (one per TASK) — VERIFIED
- [x] No regressions: 470 test functions pass (was 369, +101 new) — VERIFIED
- [x] Spec updated to STATUS: done — VERIFIED
