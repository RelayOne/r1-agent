// Package reconcile implements a leaderless work-stealing reconciliation loop
// for the Flare control plane. It converges desired_state toward observed_state
// for all machines, using FOR UPDATE SKIP LOCKED for safe concurrent operation.
//
// Design from: https://fly.io architecture + Kubernetes controller-runtime patterns.
// Key insight: every reconciliation step computes the full desired outcome and
// writes it atomically. Partial failures self-heal on the next cycle.
package reconcile

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"time"

	"flare/internal/api"
	"flare/internal/store"
)

// PlacementClient abstracts placement daemon communication.
// The control plane provides the real implementation.
type PlacementClient interface {
	StartVM(ctx context.Context, hostAddr, machineID string) error
	StopVM(ctx context.Context, hostAddr, machineID string) error
	DestroyVM(ctx context.Context, hostAddr, machineID string) error
	GetVMState(ctx context.Context, hostAddr, machineID string) (string, error)
}

// Config for the reconciliation loop.
type Config struct {
	Store        *store.Store
	Placement    PlacementClient
	InstanceID   string        // unique per reconciler instance
	BatchSize    int           // machines per cycle (default 10)
	PollInterval time.Duration // base interval between cycles (default 5s)
	HostTimeout  time.Duration // 3x heartbeat interval (default 45s)
}

// Loop runs the reconciliation loop until ctx is cancelled.
// Safe to run multiple instances concurrently (leaderless work-stealing).
func Loop(ctx context.Context, cfg Config) error {
	if cfg.BatchSize == 0 {
		cfg.BatchSize = 10
	}
	if cfg.PollInterval == 0 {
		cfg.PollInterval = 5 * time.Second
	}
	if cfg.HostTimeout == 0 {
		cfg.HostTimeout = 45 * time.Second
	}

	log.Printf("[reconcile] started (instance=%s batch=%d interval=%s)",
		cfg.InstanceID, cfg.BatchSize, cfg.PollInterval)

	for {
		// Jitter: ±20% of poll interval to prevent thundering herd
		jitter := time.Duration(float64(cfg.PollInterval) * (0.8 + 0.4*rand.Float64()))

		select {
		case <-ctx.Done():
			log.Printf("[reconcile] shutting down")
			return ctx.Err()
		case <-time.After(jitter):
		}

		if err := runCycle(ctx, cfg); err != nil {
			log.Printf("[reconcile] cycle error: %v", err)
		}
	}
}

func runCycle(ctx context.Context, cfg Config) error {
	// Phase 1: Detect dead hosts, cascade to machines
	dead, err := cfg.Store.MarkDeadHosts(ctx, cfg.HostTimeout)
	if err != nil {
		log.Printf("[reconcile] dead host detection failed: %v", err)
		// Continue -- don't let host detection block machine reconciliation
	} else if len(dead) > 0 {
		lost, lostErr := cfg.Store.MarkMachinesLostOnDeadHosts(ctx, dead)
		if lostErr != nil {
			log.Printf("[reconcile] failed to mark machines lost: %v", lostErr)
		} else if len(lost) > 0 {
			log.Printf("[reconcile] marked %d machines lost on %d dead hosts", len(lost), len(dead))
		}
	}

	// Phase 2: Claim and reconcile drifted machines
	machines, err := cfg.Store.ClaimDriftedMachines(ctx, cfg.InstanceID, cfg.BatchSize)
	if err != nil {
		return fmt.Errorf("claim batch: %w", err)
	}
	if len(machines) == 0 {
		return nil // nothing to do
	}

	for _, m := range machines {
		if err := reconcileOne(ctx, cfg, m); err != nil {
			log.Printf("[reconcile] machine %s failed: %v", m.ID, err)
		}
	}

	// Phase 3: Clean up deleting apps.
	// Apps marked "deleting" need their machines destroyed before the app can be marked "deleted".
	deletingApps, err := cfg.Store.ListDeletingApps(ctx)
	if err != nil {
		log.Printf("[reconcile] failed to list deleting apps: %v", err)
	}
	for _, app := range deletingApps {
		machines, listErr := cfg.Store.ListMachinesForApp(ctx, app.ID)
		if listErr != nil {
			log.Printf("[reconcile] failed to list machines for app %s: %v", app.ID, listErr)
			continue
		}
		allGone := true
		for _, m := range machines {
			if m.ObservedState != api.StateDestroyed {
				if err := cfg.Store.UpdateMachineDesired(ctx, m.ID, api.StateDestroyed); err != nil {
					log.Printf("[reconcile] failed to mark machine %s destroyed: %v", m.ID, err)
				}
				allGone = false
			}
		}
		if allGone {
			if err := cfg.Store.MarkAppDeleted(ctx, app.ID); err != nil {
				log.Printf("[reconcile] failed to mark app %s deleted: %v", app.ID, err)
				continue
			}
			log.Printf("[reconcile] app %s fully deleted (%d machines cleaned)", app.ID, len(machines))
		}
	}

	return nil
}

func reconcileOne(ctx context.Context, cfg Config, m store.Machine) error {
	action := computeAction(m)

	switch action {
	case actionStartVM:
		if m.HostID == "" {
			return cfg.Store.RequeueWithBackoff(ctx, m.ID, m.ReconcileAttempts+1, "no host assigned")
		}
		host, err := cfg.Store.GetHost(ctx, m.HostID)
		if err != nil {
			return cfg.Store.RequeueWithBackoff(ctx, m.ID, m.ReconcileAttempts+1, "host not found: "+err.Error())
		}
		if host.Status != api.HostReady {
			return cfg.Store.RequeueWithBackoff(ctx, m.ID, m.ReconcileAttempts+1, "host not ready: "+host.Status)
		}
		err = cfg.Placement.StartVM(ctx, host.APIAddr, m.ID)
		if err != nil {
			return cfg.Store.RequeueWithBackoff(ctx, m.ID, m.ReconcileAttempts+1, "start failed: "+err.Error())
		}
		// Observe actual state from placement to confirm the start took effect.
		// If placement already reports running, update immediately instead of
		// waiting for the transition deadline to expire.
		if observed, err := cfg.Placement.GetVMState(ctx, host.APIAddr, m.ID); err == nil && observed != "" {
			if err2 := cfg.Store.UpdateMachineObserved(ctx, m.ID, observed, "", ""); err2 != nil {
				log.Printf("[reconcile] UpdateMachineObserved failed for %s: %v", m.ID, err2)
				return err2
			}
			if observed == api.StateRunning {
				if err2 := cfg.Store.RecordEvent(ctx, m.ID, "reconcile_start_confirmed", ""); err2 != nil { log.Printf("[reconcile] RecordEvent failed for %s: %v", m.ID, err2) }
				return cfg.Store.ReleaseClaim(ctx, m.ID)
			}
		}
		// Not yet running: set deadline and let next cycle re-observe
		if err := cfg.Store.SetTransitionDeadline(ctx, m.ID, time.Now().Add(2*time.Minute)); err != nil {
			log.Printf("[reconcile] SetTransitionDeadline failed for %s: %v", m.ID, err)
			return err
		}
		if err := cfg.Store.RecordEvent(ctx, m.ID, "reconcile_start", ""); err != nil { log.Printf("[reconcile] RecordEvent failed for %s: %v", m.ID, err) }
		return nil

	case actionStopVM:
		if m.HostID == "" {
			if err := cfg.Store.UpdateMachineObserved(ctx, m.ID, api.StateStopped, "", ""); err != nil {
				log.Printf("[reconcile] UpdateMachineObserved failed for %s: %v", m.ID, err)
				return err
			}
			return cfg.Store.ReleaseClaim(ctx, m.ID)
		}
		host, err := cfg.Store.GetHost(ctx, m.HostID)
		if err != nil {
			return cfg.Store.RequeueWithBackoff(ctx, m.ID, m.ReconcileAttempts+1, "host not found: "+err.Error())
		}
		err = cfg.Placement.StopVM(ctx, host.APIAddr, m.ID)
		if err != nil {
			return cfg.Store.RequeueWithBackoff(ctx, m.ID, m.ReconcileAttempts+1, "stop failed: "+err.Error())
		}
		// Observe to confirm
		if observed, err := cfg.Placement.GetVMState(ctx, host.APIAddr, m.ID); err == nil && observed != "" {
			if err2 := cfg.Store.UpdateMachineObserved(ctx, m.ID, observed, "", ""); err2 != nil {
				log.Printf("[reconcile] UpdateMachineObserved failed for %s: %v", m.ID, err2)
				return err2
			}
			if observed == api.StateStopped {
				if err2 := cfg.Store.RecordEvent(ctx, m.ID, "reconcile_stop_confirmed", ""); err2 != nil { log.Printf("[reconcile] RecordEvent failed for %s: %v", m.ID, err2) }
				return cfg.Store.ReleaseClaim(ctx, m.ID)
			}
		}
		if err := cfg.Store.SetTransitionDeadline(ctx, m.ID, time.Now().Add(60*time.Second)); err != nil {
			log.Printf("[reconcile] SetTransitionDeadline failed for %s: %v", m.ID, err)
			return err
		}
		if err := cfg.Store.RecordEvent(ctx, m.ID, "reconcile_stop", ""); err != nil { log.Printf("[reconcile] RecordEvent failed for %s: %v", m.ID, err) }
		return nil

	case actionObserve:
		// Machine has a host and desired != observed, but we already sent a command
		// (transition deadline was set and expired). Observe actual state from placement.
		host, err := cfg.Store.GetHost(ctx, m.HostID)
		if err != nil {
			return cfg.Store.RequeueWithBackoff(ctx, m.ID, m.ReconcileAttempts+1, "host not found: "+err.Error())
		}
		if host.Status != api.HostReady {
			return cfg.Store.RequeueWithBackoff(ctx, m.ID, m.ReconcileAttempts+1, "host not ready for observe")
		}
		observed, err := cfg.Placement.GetVMState(ctx, host.APIAddr, m.ID)
		if err != nil {
			return cfg.Store.RequeueWithBackoff(ctx, m.ID, m.ReconcileAttempts+1, "observe failed: "+err.Error())
		}
		if observed != "" {
			if err := cfg.Store.UpdateMachineObserved(ctx, m.ID, observed, "", ""); err != nil {
				log.Printf("[reconcile] UpdateMachineObserved failed for %s: %v", m.ID, err)
				return err
			}
		}
		return cfg.Store.ReleaseClaim(ctx, m.ID)

	case actionMarkLost:
		if err := cfg.Store.UpdateMachineObserved(ctx, m.ID, api.StateLost, "", "host dead or missing"); err != nil {
			log.Printf("[reconcile] UpdateMachineObserved failed for %s: %v", m.ID, err)
			return err
		}
		if err := cfg.Store.RecordEvent(ctx, m.ID, "lost", "host dead"); err != nil { log.Printf("[reconcile] RecordEvent failed for %s: %v", m.ID, err) }
		return cfg.Store.ReleaseClaim(ctx, m.ID)

	case actionCleanupDestroyed:
		// Machine desired=destroyed but still in DB.
		// Only tombstone the DB row if the host is unreachable/dead OR placement
		// confirms destruction. Never delete the source-of-truth while the VM
		// might still be running on a healthy host.
		if m.HostID != "" {
			host, hostErr := cfg.Store.GetHost(ctx, m.HostID)
			if hostErr == nil && host.Status == api.HostReady {
				if err := cfg.Placement.DestroyVM(ctx, host.APIAddr, m.ID); err != nil {
					return cfg.Store.RequeueWithBackoff(ctx, m.ID, m.ReconcileAttempts+1, "destroy failed: "+err.Error())
				}
			}
			// Host dead/missing or destroy succeeded -- safe to clean up DB
		}
		// FLARE-027: Why this non-atomic cleanup is safe.
		// DeleteHostnamesByMachine and DeleteMachine are not wrapped in a single
		// transaction. This is intentional and safe because:
		//  1. The machine row has desired_state=destroyed, so no new hostnames can
		//     be created for it (createHostname rejects destroyed machines).
		//  2. If DeleteHostnamesByMachine succeeds but DeleteMachine fails, the
		//     next reconcile cycle will re-claim this machine via ClaimDriftedMachines
		//     (desired != observed) and retry the delete. Orphaned hostname rows
		//     without a machine are harmless -- they point to a non-existent machine
		//     and will never match in ResolveHostname.
		//  3. If DeleteMachine succeeds but DeleteHostnamesByMachine failed, the
		//     hostname rows become dangling foreign keys. The DB schema uses
		//     ON DELETE CASCADE on machine_id, so Postgres cleans them automatically.
		if err := cfg.Store.DeleteHostnamesByMachine(ctx, m.ID); err != nil {
			log.Printf("[reconcile] DeleteHostnamesByMachine failed for %s: %v", m.ID, err)
		}
		if err := cfg.Store.DeleteMachine(ctx, m.ID); err != nil {
			log.Printf("[reconcile] failed to delete machine %s: %v", m.ID, err)
			return err
		}
		if err := cfg.Store.RecordEvent(ctx, m.ID, "reconcile_destroy", ""); err != nil { log.Printf("[reconcile] RecordEvent failed for %s: %v", m.ID, err) }
		return nil

	case actionNone:
		// Converged or in-flight. Release claim.
		return cfg.Store.ReleaseClaim(ctx, m.ID)
	}

	return nil
}

type action int

const (
	actionNone action = iota
	actionStartVM
	actionStopVM
	actionObserve
	actionMarkLost
	actionCleanupDestroyed
)

func computeAction(m store.Machine) action {
	if m.HostID == "" && m.DesiredState == api.StateRunning {
		return actionMarkLost
	}

	switch m.DesiredState {
	case api.StateRunning:
		switch m.ObservedState {
		case api.StateStopped, api.StateCreated, api.StateFailed, api.StateLost, api.StateUnknown:
			return actionStartVM
		case api.StateStarting:
			// Already in transition -- observe instead of re-issuing start
			return actionObserve
		default:
			return actionNone
		}

	case api.StateStopped:
		switch m.ObservedState {
		case api.StateRunning, api.StateFailed:
			return actionStopVM
		case api.StateStopping:
			return actionObserve
		default:
			return actionNone
		}

	case api.StateDestroyed:
		return actionCleanupDestroyed
	}

	return actionNone
}
