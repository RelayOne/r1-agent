package reconcile

import (
	"testing"

	"flare/internal/api"
	"flare/internal/store"
)

func TestComputeAction(t *testing.T) {
	tests := []struct {
		name     string
		machine  store.Machine
		expected action
	}{
		// ── desired=running ──
		{
			name:     "running/stopped -> start",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateRunning, ObservedState: api.StateStopped},
			expected: actionStartVM,
		},
		{
			name:     "running/created -> start",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateRunning, ObservedState: api.StateCreated},
			expected: actionStartVM,
		},
		{
			name:     "running/failed -> start (retry)",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateRunning, ObservedState: api.StateFailed},
			expected: actionStartVM,
		},
		{
			name:     "running/lost -> start (recovery)",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateRunning, ObservedState: api.StateLost},
			expected: actionStartVM,
		},
		{
			name:     "running/starting -> observe",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateRunning, ObservedState: api.StateStarting},
			expected: actionObserve,
		},
		{
			name:     "running/running -> none (converged)",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateRunning, ObservedState: api.StateRunning},
			expected: actionNone,
		},
		{
			name:     "running/no host -> mark lost",
			machine:  store.Machine{HostID: "", DesiredState: api.StateRunning, ObservedState: api.StateStopped},
			expected: actionMarkLost,
		},

		// ── desired=stopped ──
		{
			name:     "stopped/running -> stop",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateStopped, ObservedState: api.StateRunning},
			expected: actionStopVM,
		},
		{
			name:     "stopped/failed -> stop (P0 fix: failed stops converge)",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateStopped, ObservedState: api.StateFailed},
			expected: actionStopVM,
		},
		{
			name:     "stopped/stopping -> observe",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateStopped, ObservedState: api.StateStopping},
			expected: actionObserve,
		},
		{
			name:     "stopped/stopped -> none (converged)",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateStopped, ObservedState: api.StateStopped},
			expected: actionNone,
		},
		{
			name:     "stopped/created -> none",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateStopped, ObservedState: api.StateCreated},
			expected: actionNone,
		},

		// ── desired=destroyed ──
		{
			name:     "destroyed/running -> cleanup",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateDestroyed, ObservedState: api.StateRunning},
			expected: actionCleanupDestroyed,
		},
		{
			name:     "destroyed/stopped -> cleanup",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateDestroyed, ObservedState: api.StateStopped},
			expected: actionCleanupDestroyed,
		},
		{
			name:     "destroyed/destroyed -> cleanup (tombstone DB row)",
			machine:  store.Machine{HostID: "h1", DesiredState: api.StateDestroyed, ObservedState: api.StateDestroyed},
			expected: actionCleanupDestroyed,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := computeAction(tt.machine)
			if got != tt.expected {
				t.Errorf("computeAction() = %d, want %d", got, tt.expected)
			}
		})
	}
}
