package networking

import (
	"fmt"
	"log"
	"net"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"sync"
)

type Bridge struct {
	Name    string // e.g. "br0"
	Subnet  string // e.g. "10.0.0.0/24"
	Gateway string // e.g. "10.0.0.1"
}

type TAPDevice struct {
	Name       string // e.g. "tap0"
	IPAddress  string // e.g. "10.0.0.2"
	MACAddress string
}

// subnet tracks allocation state for a single /24 CIDR range.
type subnet struct {
	cidr    string // e.g. "10.0.1.0/24"
	prefix  string // e.g. "10.0.1" (first three octets)
	gateway string // e.g. "10.0.1.1"
	nextIP  int    // next available last octet (2-254)
	freeIPs []int  // recycled IPs from released TAPs
	count   int    // number of active allocations in this subnet
	capacity int   // max allocations (253 for a /24)
}

type Manager struct {
	mu       sync.Mutex
	bridge   Bridge
	subnets  []*subnet // ordered list; primary first, then overflow subnets
	devices  map[string]*TAPDevice
	deviceSubnet map[string]int // vmID -> subnet index (for release)
	tapSeq   int
}

// parseSubnets parses CIDR strings into subnet structs.
// Each must be a /24. Returns an error if any CIDR is invalid or not /24.
func parseSubnets(cidrs []string) ([]*subnet, error) {
	var result []*subnet
	for _, cidr := range cidrs {
		_, ipNet, err := net.ParseCIDR(cidr)
		if err != nil {
			return nil, fmt.Errorf("invalid CIDR %q: %w", cidr, err)
		}
		ones, _ := ipNet.Mask.Size()
		if ones != 24 {
			return nil, fmt.Errorf("only /24 subnets are supported, got %s", cidr)
		}
		ip := ipNet.IP.To4()
		prefix := fmt.Sprintf("%d.%d.%d", ip[0], ip[1], ip[2])
		gw := fmt.Sprintf("%s.1", prefix)
		result = append(result, &subnet{
			cidr:     cidr,
			prefix:   prefix,
			gateway:  gw,
			nextIP:   2,
			capacity: 253, // .2 through .254
		})
	}
	return result, nil
}

// NewManager creates a networking manager. It reads FLARE_BRIDGE_SUBNETS for
// additional /24 CIDR ranges (comma-separated). When the primary subnet is
// exhausted, IPs are allocated from secondary subnets. If FLARE_BRIDGE_SUBNETS
// is unset, only the bridge's single /24 is used (backwards compatible).
func NewManager(bridge Bridge) *Manager {
	// Primary subnet from bridge config
	gateParts := strings.Split(bridge.Gateway, ".")
	primaryPrefix := strings.Join(gateParts[:3], ".")
	primary := &subnet{
		cidr:     bridge.Subnet,
		prefix:   primaryPrefix,
		gateway:  bridge.Gateway,
		nextIP:   2,
		capacity: 253,
	}
	subnets := []*subnet{primary}

	// Parse additional subnets from env var
	if extra := os.Getenv("FLARE_BRIDGE_SUBNETS"); extra != "" {
		cidrs := strings.Split(extra, ",")
		for i := range cidrs {
			cidrs[i] = strings.TrimSpace(cidrs[i])
		}
		parsed, err := parseSubnets(cidrs)
		if err != nil {
			log.Printf("[networking] WARNING: ignoring invalid FLARE_BRIDGE_SUBNETS: %v", err)
		} else {
			subnets = append(subnets, parsed...)
		}
	}

	return &Manager{
		bridge:       bridge,
		subnets:      subnets,
		devices:      make(map[string]*TAPDevice),
		deviceSubnet: make(map[string]int),
	}
}

// SetupBridge creates the host bridge, assigns the gateway IP, and enables NAT.
func SetupBridge(bridge Bridge) error {
	cmds := [][]string{
		{"ip", "link", "add", bridge.Name, "type", "bridge"},
		{"ip", "addr", "add", bridge.Gateway + "/24", "dev", bridge.Name},
		{"ip", "link", "set", bridge.Name, "up"},
		{"sysctl", "-w", "net.ipv4.ip_forward=1"},
		{"iptables", "-t", "nat", "-A", "POSTROUTING", "-s", bridge.Subnet, "-j", "MASQUERADE"},
	}
	for _, args := range cmds {
		cmd := exec.Command(args[0], args[1:]...)
		if out, err := cmd.CombinedOutput(); err != nil {
			outStr := strings.TrimSpace(string(out))
			// Ignore "already exists" errors (idempotent setup)
			if strings.Contains(outStr, "File exists") || strings.Contains(outStr, "RTNETLINK answers") {
				continue
			}
			return fmt.Errorf("%s: %s: %w", strings.Join(args, " "), outStr, err)
		}
	}
	return nil
}

// allocateFromSubnet picks an IP from the given subnet. Returns the last octet
// or -1 if the subnet is exhausted.
func allocateFromSubnet(s *subnet) int {
	if len(s.freeIPs) > 0 {
		octet := s.freeIPs[len(s.freeIPs)-1]
		s.freeIPs = s.freeIPs[:len(s.freeIPs)-1]
		s.count++
		return octet
	}
	if s.nextIP > 254 {
		return -1
	}
	octet := s.nextIP
	s.nextIP++
	s.count++
	return octet
}

// totalCapacity returns the total and used IP count across all subnets.
func (m *Manager) totalCapacity() (total, used int) {
	for _, s := range m.subnets {
		total += s.capacity
		used += s.count
	}
	return
}

// Allocate creates a TAP device for a VM and connects it to the bridge.
func (m *Manager) Allocate(vmID string) (*TAPDevice, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if _, exists := m.devices[vmID]; exists {
		return m.devices[vmID], nil
	}

	// Find a subnet with available IPs
	var chosenSubnet *subnet
	var chosenIdx int
	var lastOctet int
	for i, s := range m.subnets {
		octet := allocateFromSubnet(s)
		if octet >= 0 {
			chosenSubnet = s
			chosenIdx = i
			lastOctet = octet
			break
		}
	}
	if chosenSubnet == nil {
		return nil, fmt.Errorf("IP address pool exhausted across all %d subnets", len(m.subnets))
	}

	// Alert when utilization exceeds 80%
	total, used := m.totalCapacity()
	if total > 0 {
		utilization := float64(used) / float64(total)
		if utilization > 0.80 {
			log.Printf("[networking] WARNING: TAP IP utilization at %.0f%% (%d/%d) — consider adding subnets via FLARE_BRIDGE_SUBNETS",
				utilization*100, used, total)
		}
	}

	tapName := fmt.Sprintf("tap%d", m.tapSeq)
	m.tapSeq++

	vmIP := fmt.Sprintf("%s.%d", chosenSubnet.prefix, lastOctet)

	prefixParts := strings.Split(chosenSubnet.prefix, ".")
	b2, _ := strconv.Atoi(prefixParts[1])
	b3, _ := strconv.Atoi(prefixParts[2])
	mac := fmt.Sprintf("02:FC:00:%02x:%02x:%02x", b2, b3, lastOctet)

	// Create TAP device and attach to bridge
	cmds := [][]string{
		{"ip", "tuntap", "add", "dev", tapName, "mode", "tap"},
		{"ip", "link", "set", tapName, "master", m.bridge.Name},
		{"ip", "link", "set", tapName, "up"},
	}
	for _, args := range cmds {
		cmd := exec.Command(args[0], args[1:]...)
		if out, err := cmd.CombinedOutput(); err != nil {
			return nil, fmt.Errorf("%s: %s: %w", strings.Join(args, " "), strings.TrimSpace(string(out)), err)
		}
	}

	dev := &TAPDevice{Name: tapName, IPAddress: vmIP, MACAddress: mac}
	m.devices[vmID] = dev
	m.deviceSubnet[vmID] = chosenIdx
	return dev, nil
}

// Release tears down a TAP device and returns the IP to the pool.
func (m *Manager) Release(vmID string) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	dev, exists := m.devices[vmID]
	if !exists {
		return nil
	}

	cmd := exec.Command("ip", "link", "delete", dev.Name)
	cmd.CombinedOutput() // best effort

	// Return IP to the correct subnet's free pool for reuse
	parts := strings.Split(dev.IPAddress, ".")
	if len(parts) == 4 {
		octet, _ := strconv.Atoi(parts[3])
		if octet >= 2 && octet <= 254 {
			if sIdx, ok := m.deviceSubnet[vmID]; ok && sIdx < len(m.subnets) {
				m.subnets[sIdx].freeIPs = append(m.subnets[sIdx].freeIPs, octet)
				m.subnets[sIdx].count--
			}
		}
	}

	delete(m.devices, vmID)
	delete(m.deviceSubnet, vmID)
	return nil
}

// Get returns the TAP device for a VM.
func (m *Manager) Get(vmID string) (*TAPDevice, bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	dev, ok := m.devices[vmID]
	return dev, ok
}

// AllocatedCount returns the number of TAP devices in use.
func (m *Manager) AllocatedCount() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.devices)
}

// RecoverDevice records a pre-existing TAP device (from vm.json recovery)
// into the manager's state. This prevents IP/TAP name collisions when
// new VMs are allocated after a placement daemon restart.
func (m *Manager) RecoverDevice(vmID, tapName, ipAddr, macAddr string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	dev := &TAPDevice{Name: tapName, IPAddress: ipAddr, MACAddress: macAddr}
	m.devices[vmID] = dev

	// Find which subnet this IP belongs to and advance its nextIP
	parts := strings.Split(ipAddr, ".")
	if len(parts) == 4 {
		prefix := strings.Join(parts[:3], ".")
		octet, _ := strconv.Atoi(parts[3])
		for i, s := range m.subnets {
			if s.prefix == prefix {
				if octet >= s.nextIP {
					s.nextIP = octet + 1
				}
				s.count++
				m.deviceSubnet[vmID] = i
				break
			}
		}
	}

	// Advance tapSeq past any recovered TAP name (e.g. "tap3" -> tapSeq=4)
	if strings.HasPrefix(tapName, "tap") {
		seq, _ := strconv.Atoi(strings.TrimPrefix(tapName, "tap"))
		if seq >= m.tapSeq {
			m.tapSeq = seq + 1
		}
	}
}
