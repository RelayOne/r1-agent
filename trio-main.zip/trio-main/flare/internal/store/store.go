// Package store provides a Postgres-backed persistence layer for the control plane.
// Replaces all in-memory maps. Uses database/sql interface (use pgx driver).
package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

type Store struct {
	db *sql.DB
}

func New(db *sql.DB) *Store {
	return &Store{db: db}
}

// ── Apps ──

type App struct {
	ID        string    `json:"id"`
	OrgID     string    `json:"org_id"`
	Name      string    `json:"name"`
	Status    string    `json:"status"`
	CreatedAt time.Time `json:"created_at"`
}

func (s *Store) CreateApp(ctx context.Context, app App) error {
	_, err := s.db.ExecContext(ctx,
		`INSERT INTO apps (id, org_id, name, status, created_at) VALUES ($1, $2, $3, $4, $5)`,
		app.ID, app.OrgID, app.Name, app.Status, app.CreatedAt)
	return err
}

func (s *Store) GetApp(ctx context.Context, id string) (App, error) {
	var a App
	err := s.db.QueryRowContext(ctx,
		`SELECT id, org_id, name, status, created_at FROM apps WHERE id = $1`, id).
		Scan(&a.ID, &a.OrgID, &a.Name, &a.Status, &a.CreatedAt)
	return a, err
}

func (s *Store) MarkAppDeleting(ctx context.Context, id string) error {
	_, err := s.db.ExecContext(ctx, `UPDATE apps SET status = 'deleting' WHERE id = $1`, id)
	return err
}

func (s *Store) ListDeletingApps(ctx context.Context) ([]App, error) {
	rows, err := s.db.QueryContext(ctx, `SELECT id, org_id, name, status, created_at FROM apps WHERE status = 'deleting' LIMIT 100`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var apps []App
	for rows.Next() {
		var a App
		if err := rows.Scan(&a.ID, &a.OrgID, &a.Name, &a.Status, &a.CreatedAt); err != nil {
			return nil, err
		}
		apps = append(apps, a)
	}
	return apps, rows.Err()
}

// ListMachinesForApp returns ALL machines for an app, including destroyed.
// Used by app deletion cleanup to verify all machines are gone.
func (s *Store) ListMachinesForApp(ctx context.Context, appID string) ([]Machine, error) {
	rows, err := s.db.QueryContext(ctx, machineSelect+` WHERE m.app_id = $1`, appID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var machines []Machine
	for rows.Next() {
		m, err := s.scanMachine(rows)
		if err != nil {
			return machines, err
		}
		machines = append(machines, m)
	}
	return machines, rows.Err()
}

func (s *Store) MarkAppDeleted(ctx context.Context, id string) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `DELETE FROM hostnames WHERE app_id = $1`, id); err != nil {
		return fmt.Errorf("delete hostnames: %w", err)
	}
	if _, err := tx.ExecContext(ctx, `UPDATE apps SET status = 'deleted' WHERE id = $1`, id); err != nil {
		return fmt.Errorf("mark app deleted: %w", err)
	}
	return tx.Commit()
}

// ── Hosts ──

type Host struct {
	ID            string    `json:"id"`
	Zone          string    `json:"zone"`
	Region        string    `json:"region"`
	APIAddr       string    `json:"api_addr"`
	IngressAddr   string    `json:"ingress_addr"`
	Status        string    `json:"status"`
	CapacityCPUs  int       `json:"capacity_cpus"`
	CapacityMemMB int       `json:"capacity_mem_mb"`
	UsedCPUs      int       `json:"used_cpus"`
	UsedMemMB     int       `json:"used_mem_mb"`
	ReservedCPUs  int       `json:"reserved_cpus"`
	ReservedMemMB int       `json:"reserved_mem_mb"`
	LastHeartbeat time.Time `json:"last_heartbeat"`
}

func (s *Store) UpsertHost(ctx context.Context, h Host) error {
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO hosts (id, zone, region, api_addr, ingress_addr, status,
			capacity_cpus, capacity_mem_mb, used_cpus, used_mem_mb, last_heartbeat)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
		ON CONFLICT (id) DO UPDATE SET
			zone = EXCLUDED.zone, region = EXCLUDED.region,
			api_addr = EXCLUDED.api_addr, ingress_addr = EXCLUDED.ingress_addr,
			status = 'ready',
			capacity_cpus = EXCLUDED.capacity_cpus, capacity_mem_mb = EXCLUDED.capacity_mem_mb,
			used_cpus = EXCLUDED.used_cpus, used_mem_mb = EXCLUDED.used_mem_mb,
			last_heartbeat = EXCLUDED.last_heartbeat`,
		h.ID, h.Zone, h.Region, h.APIAddr, h.IngressAddr, h.Status,
		h.CapacityCPUs, h.CapacityMemMB, h.UsedCPUs, h.UsedMemMB, time.Now())
	return err
}

// Heartbeat merges usage without overwriting capacity/address.
func (s *Store) Heartbeat(ctx context.Context, hostID string, usedCPUs, usedMemMB int) error {
	res, err := s.db.ExecContext(ctx, `
		UPDATE hosts SET used_cpus = $2, used_mem_mb = $3,
			last_heartbeat = now(), status = 'ready'
		WHERE id = $1`,
		hostID, usedCPUs, usedMemMB)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return fmt.Errorf("host %s not registered", hostID)
	}
	return nil
}

func (s *Store) GetHost(ctx context.Context, id string) (Host, error) {
	var h Host
	err := s.db.QueryRowContext(ctx, `
		SELECT id, zone, region, api_addr, ingress_addr, status,
			capacity_cpus, capacity_mem_mb, used_cpus, used_mem_mb,
			reserved_cpus, reserved_mem_mb
		FROM hosts WHERE id = $1`, id).
		Scan(&h.ID, &h.Zone, &h.Region, &h.APIAddr, &h.IngressAddr, &h.Status,
			&h.CapacityCPUs, &h.CapacityMemMB, &h.UsedCPUs, &h.UsedMemMB,
			&h.ReservedCPUs, &h.ReservedMemMB)
	return h, err
}

// CheckHostCapacity verifies a host has sufficient CPU and memory headroom
// using SELECT ... FOR UPDATE to prevent concurrent overcommit (FLARE-005).
func (s *Store) CheckHostCapacity(ctx context.Context, hostID string, needCPUs, needMemMB int) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("begin tx: %w", err)
	}
	defer tx.Rollback()

	var capacityCPUs, capacityMemMB, usedCPUs, usedMemMB, reservedCPUs, reservedMemMB int
	err = tx.QueryRowContext(ctx, `
		SELECT capacity_cpus, capacity_mem_mb, used_cpus, used_mem_mb,
			reserved_cpus, reserved_mem_mb
		FROM hosts WHERE id = $1 FOR UPDATE`, hostID).
		Scan(&capacityCPUs, &capacityMemMB, &usedCPUs, &usedMemMB, &reservedCPUs, &reservedMemMB)
	if err != nil {
		return fmt.Errorf("lock host row: %w", err)
	}

	availCPU := capacityCPUs - usedCPUs - reservedCPUs
	availMem := capacityMemMB - usedMemMB - reservedMemMB
	if needCPUs > availCPU || needMemMB > availMem {
		return fmt.Errorf("insufficient host capacity: need %dCPU/%dMB, have %dCPU/%dMB",
			needCPUs, needMemMB, availCPU, availMem)
	}

	return tx.Commit()
}

func (s *Store) MarkDeadHosts(ctx context.Context, ttl time.Duration) ([]string, error) {
	rows, err := s.db.QueryContext(ctx, `
		UPDATE hosts SET status = 'dead'
		WHERE status = 'ready' AND last_heartbeat < $1
		RETURNING id`, time.Now().Add(-ttl))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var dead []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		dead = append(dead, id)
	}
	return dead, rows.Err()
}

// PlaceAndReserve atomically selects a host and reserves capacity.
// Uses SELECT FOR UPDATE SKIP LOCKED to avoid contention.
func (s *Store) PlaceAndReserve(ctx context.Context, region string, cpus, memMB int) (Host, error) {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return Host{}, err
	}
	defer tx.Rollback()

	var h Host
	err = tx.QueryRowContext(ctx, `
		SELECT id, zone, region, api_addr, ingress_addr, status,
			capacity_cpus, capacity_mem_mb, used_cpus, used_mem_mb, reserved_cpus, reserved_mem_mb
		FROM hosts
		WHERE status = 'ready'
			AND ($1 = '' OR region = $1)
			AND (capacity_cpus - used_cpus - reserved_cpus) >= $2
			AND (capacity_mem_mb - used_mem_mb - reserved_mem_mb) >= $3
		ORDER BY (capacity_cpus - used_cpus - reserved_cpus) ASC
		LIMIT 1
		FOR UPDATE SKIP LOCKED`,
		region, cpus, memMB).
		Scan(&h.ID, &h.Zone, &h.Region, &h.APIAddr, &h.IngressAddr, &h.Status,
			&h.CapacityCPUs, &h.CapacityMemMB, &h.UsedCPUs, &h.UsedMemMB,
			&h.ReservedCPUs, &h.ReservedMemMB)
	if err == sql.ErrNoRows {
		return Host{}, fmt.Errorf("no host with %d CPUs and %d MB available in region %q", cpus, memMB, region)
	}
	if err != nil {
		return Host{}, err
	}

	_, err = tx.ExecContext(ctx, `
		UPDATE hosts SET reserved_cpus = reserved_cpus + $2, reserved_mem_mb = reserved_mem_mb + $3
		WHERE id = $1`, h.ID, cpus, memMB)
	if err != nil {
		return Host{}, err
	}

	if err := tx.Commit(); err != nil {
		return Host{}, err
	}
	return h, nil
}

func (s *Store) ReleaseReservation(ctx context.Context, hostID string, cpus, memMB int) error {
	_, err := s.db.ExecContext(ctx, `
		UPDATE hosts SET
			reserved_cpus = GREATEST(reserved_cpus - $2, 0),
			reserved_mem_mb = GREATEST(reserved_mem_mb - $3, 0)
		WHERE id = $1`, hostID, cpus, memMB)
	return err
}

// ── Machines ──

type Machine struct {
	ID                string          `json:"id"`
	AppID             string          `json:"app_id"`
	HostID            string          `json:"host_id,omitempty"`
	Name              string          `json:"name"`
	Region            string          `json:"region"`
	ImageRef          string          `json:"image_ref"`
	GuestCPUs         int             `json:"guest_cpus"`
	GuestMemMB        int             `json:"guest_mem_mb"`
	Env               json.RawMessage `json:"env"`
	Metadata          json.RawMessage `json:"metadata"`
	DesiredState      string          `json:"desired_state"`
	ObservedState     string          `json:"observed_state"`
	IPAddress         string          `json:"ip_address,omitempty"`
	GeneratedHostname string          `json:"generated_hostname"`
	LastError         string          `json:"last_error,omitempty"`
	Generation        int             `json:"generation"`
	ReconcileAttempts int             `json:"reconcile_attempts"`
	CreatedAt         time.Time       `json:"created_at"`
	UpdatedAt         time.Time       `json:"updated_at"`
}

func (s *Store) CreateMachine(ctx context.Context, m Machine) error {
	env := m.Env
	if env == nil {
		env = json.RawMessage(`{}`)
	}
	meta := m.Metadata
	if meta == nil {
		meta = json.RawMessage(`{}`)
	}
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO machines (id, app_id, host_id, name, region, image_ref,
			guest_cpus, guest_mem_mb, env, metadata,
			desired_state, observed_state, generated_hostname, generation, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $15)`,
		m.ID, m.AppID, nilIfEmpty(m.HostID), m.Name, m.Region, m.ImageRef,
		m.GuestCPUs, m.GuestMemMB, string(env), string(meta),
		m.DesiredState, m.ObservedState, m.GeneratedHostname, m.Generation,
		m.CreatedAt)
	return err
}

func (s *Store) UpdateMachineObserved(ctx context.Context, id, observedState, ipAddr, lastError string) error {
	_, err := s.db.ExecContext(ctx, `
		UPDATE machines SET observed_state = $2, ip_address = COALESCE(NULLIF($3, ''), ip_address),
			last_error = NULLIF($4, ''), last_observed_at = now(), updated_at = now()
		WHERE id = $1`, id, observedState, ipAddr, lastError)
	return err
}

func (s *Store) UpdateMachineDesired(ctx context.Context, id, desiredState string) error {
	_, err := s.db.ExecContext(ctx, `
		UPDATE machines SET desired_state = $2, updated_at = now() WHERE id = $1`, id, desiredState)
	return err
}

func (s *Store) SetMachineHost(ctx context.Context, id, hostID, ipAddr string) error {
	_, err := s.db.ExecContext(ctx, `
		UPDATE machines SET host_id = $2, ip_address = $3, updated_at = now() WHERE id = $1`,
		id, hostID, ipAddr)
	return err
}

func (s *Store) GetMachine(ctx context.Context, id string) (Machine, error) {
	return s.scanMachine(s.db.QueryRowContext(ctx, machineSelect+` WHERE m.id = $1`, id))
}

func (s *Store) GetMachineScoped(ctx context.Context, appID, id string) (Machine, error) {
	return s.scanMachine(s.db.QueryRowContext(ctx, machineSelect+` WHERE m.id = $1 AND m.app_id = $2`, id, appID))
}

func (s *Store) ListMachines(ctx context.Context, appID string) ([]Machine, error) {
	rows, err := s.db.QueryContext(ctx, machineSelect+` WHERE m.app_id = $1 AND m.observed_state != 'destroyed'`, appID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var list []Machine
	for rows.Next() {
		m, err := s.scanMachineRow(rows)
		if err != nil {
			return nil, err
		}
		list = append(list, m)
	}
	return list, rows.Err()
}

func (s *Store) DeleteMachine(ctx context.Context, id string) error {
	_, err := s.db.ExecContext(ctx, `
		UPDATE machines SET desired_state = 'destroyed', observed_state = 'destroyed', updated_at = now()
		WHERE id = $1`, id)
	return err
}

// ResolveHostname looks up a hostname (auto-generated or custom) and returns the machine + host.
func (s *Store) ResolveHostname(ctx context.Context, hostname string) (Machine, Host, error) {
	var m Machine
	var h Host
	// Try generated hostname first (exclude dead hosts)
	err := s.db.QueryRowContext(ctx, `
		SELECT m.id, m.host_id, m.observed_state, m.ip_address, m.generated_hostname,
			h.ingress_addr
		FROM machines m
		JOIN hosts h ON h.id = m.host_id
		WHERE m.generated_hostname = $1 AND m.observed_state = 'running'
			AND h.status = 'ready'`, hostname).
		Scan(&m.ID, &m.HostID, &m.ObservedState, &m.IPAddress, &m.GeneratedHostname, &h.IngressAddr)
	if err == nil {
		return m, h, nil
	}

	// Try custom hostname (exclude dead hosts)
	err = s.db.QueryRowContext(ctx, `
		SELECT m.id, m.host_id, m.observed_state, m.ip_address, m.generated_hostname,
			h.ingress_addr
		FROM hostnames hn
		JOIN machines m ON m.id = hn.machine_id
		JOIN hosts h ON h.id = m.host_id
		WHERE hn.hostname = $1 AND m.observed_state = 'running'
			AND h.status = 'ready'`, hostname).
		Scan(&m.ID, &m.HostID, &m.ObservedState, &m.IPAddress, &m.GeneratedHostname, &h.IngressAddr)
	if err == sql.ErrNoRows {
		return m, h, fmt.Errorf("no running VM on healthy host for hostname %q", hostname)
	}
	return m, h, err
}

func (s *Store) RecordEvent(ctx context.Context, machineID, eventType, details string) error {
	_, err := s.db.ExecContext(ctx, `INSERT INTO machine_events (machine_id, event_type, details) VALUES ($1, $2, $3)`,
		machineID, eventType, details)
	return err
}

// ── Hostnames ──

type Hostname struct {
	ID        string `json:"id"`
	AppID     string `json:"app_id"`
	MachineID string `json:"machine_id"`
	Hostname  string `json:"hostname"`
}

func (s *Store) CreateHostname(ctx context.Context, hn Hostname) error {
	_, err := s.db.ExecContext(ctx,
		`INSERT INTO hostnames (id, app_id, machine_id, hostname) VALUES ($1, $2, $3, $4)`,
		hn.ID, hn.AppID, hn.MachineID, hn.Hostname)
	return err
}

func (s *Store) DeleteHostname(ctx context.Context, appID, id string) error {
	res, err := s.db.ExecContext(ctx,
		`DELETE FROM hostnames WHERE id = $1 AND app_id = $2`, id, appID)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

// DeleteHostnamesByMachine removes all custom hostnames for a machine.
// Called on machine destroy to free the globally-unique hostname constraint.
func (s *Store) DeleteHostnamesByMachine(ctx context.Context, machineID string) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM hostnames WHERE machine_id = $1`, machineID)
	return err
}

// ── Helpers ──

const machineSelect = `SELECT m.id, m.app_id, COALESCE(m.host_id, ''), m.name, m.region,
	m.image_ref, m.guest_cpus, m.guest_mem_mb, m.env, m.metadata,
	m.desired_state, m.observed_state, COALESCE(m.ip_address, ''),
	m.generated_hostname, COALESCE(m.last_error, ''), m.generation,
	m.reconcile_attempts, m.created_at, m.updated_at
	FROM machines m`

type scannable interface {
	Scan(dest ...any) error
}

func (s *Store) scanMachine(row scannable) (Machine, error) {
	var m Machine
	var env, meta string
	err := row.Scan(&m.ID, &m.AppID, &m.HostID, &m.Name, &m.Region,
		&m.ImageRef, &m.GuestCPUs, &m.GuestMemMB, &env, &meta,
		&m.DesiredState, &m.ObservedState, &m.IPAddress,
		&m.GeneratedHostname, &m.LastError, &m.Generation,
		&m.ReconcileAttempts, &m.CreatedAt, &m.UpdatedAt)
	m.Env = json.RawMessage(env)
	m.Metadata = json.RawMessage(meta)
	return m, err
}

func (s *Store) scanMachineRow(rows *sql.Rows) (Machine, error) {
	return s.scanMachine(rows)
}

func nilIfEmpty(s string) interface{} {
	if s == "" {
		return nil
	}
	return s
}

// RegionFromZone extracts region from zone (e.g. "us-central1-a" -> "us-central1").
func RegionFromZone(zone string) string {
	parts := strings.Split(zone, "-")
	if len(parts) >= 3 {
		return strings.Join(parts[:len(parts)-1], "-")
	}
	return zone
}

// ── Reconciliation ──

// ClaimDriftedMachines atomically claims a batch of machines where desired != observed
// for processing. Uses FOR UPDATE SKIP LOCKED for leaderless work-stealing.
// FLARE-007: Single CTE combines claim + read to avoid two-phase race.
func (s *Store) ClaimDriftedMachines(ctx context.Context, instanceID string, batchSize int) ([]Machine, error) {
	rows, err := s.db.QueryContext(ctx, `
		WITH claimed AS (
			UPDATE machines SET claimed_by = $1, claimed_at = now()
			WHERE id IN (
				SELECT id FROM machines
				WHERE desired_state != observed_state
				  AND (reconcile_after IS NULL OR reconcile_after <= now())
				  AND (transition_deadline IS NULL OR transition_deadline < now())
				  AND (claimed_by IS NULL OR claimed_at < now() - interval '2 minutes')
				ORDER BY reconcile_after NULLS FIRST, created_at
				FOR UPDATE SKIP LOCKED
				LIMIT $2
			)
			RETURNING id
		)
		SELECT m.id, m.app_id, COALESCE(m.host_id, ''), m.name, m.region,
			m.image_ref, m.guest_cpus, m.guest_mem_mb, m.env, m.metadata,
			m.desired_state, m.observed_state, COALESCE(m.ip_address, ''),
			m.generated_hostname, COALESCE(m.last_error, ''), m.generation,
			m.reconcile_attempts, m.created_at, m.updated_at
		FROM machines m
		JOIN claimed c ON c.id = m.id`, instanceID, batchSize)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var machines []Machine
	for rows.Next() {
		m, err := s.scanMachine(rows)
		if err != nil {
			return machines, err
		}
		machines = append(machines, m)
	}
	return machines, rows.Err()
}

// MarkMachinesLostOnDeadHosts sets observed_state='lost' for all machines
// on hosts that were just marked dead. Returns affected machine IDs.
func (s *Store) MarkMachinesLostOnDeadHosts(ctx context.Context, deadHostIDs []string) ([]string, error) {
	if len(deadHostIDs) == 0 {
		return nil, nil
	}
	params := make([]string, len(deadHostIDs))
	args := make([]interface{}, len(deadHostIDs))
	for i, id := range deadHostIDs {
		params[i] = fmt.Sprintf("$%d", i+1)
		args[i] = id
	}
	query := fmt.Sprintf(`
		UPDATE machines
		SET observed_state = 'lost', last_error = 'host marked dead',
		    claimed_by = NULL, claimed_at = NULL
		WHERE host_id IN (%s)
		  AND desired_state != 'destroyed'
		  AND observed_state != 'lost'
		RETURNING id`, strings.Join(params, ","))
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}

// SetTransitionDeadline marks a machine as in-flight (waiting for host response).
// The reconciler won't re-claim it until the deadline passes.
func (s *Store) SetTransitionDeadline(ctx context.Context, machineID string, deadline time.Time) error {
	_, err := s.db.ExecContext(ctx, `
		UPDATE machines SET transition_deadline = $1, claimed_by = NULL WHERE id = $2`,
		deadline, machineID)
	return err
}

// RequeueWithBackoff releases a claimed machine back to the pool with exponential backoff.
func (s *Store) RequeueWithBackoff(ctx context.Context, machineID string, attempts int, lastError string) error {
	// Exponential backoff: 2^attempts seconds, capped at 5 minutes, with jitter
	backoffSec := 1 << min(attempts, 8)
	if backoffSec > 300 {
		backoffSec = 300
	}
	_, err := s.db.ExecContext(ctx, `
		UPDATE machines
		SET reconcile_attempts = $1,
		    reconcile_after = now() + ($2 || ' seconds')::interval,
		    last_error = $3,
		    claimed_by = NULL, claimed_at = NULL
		WHERE id = $4`,
		attempts, fmt.Sprintf("%d", backoffSec), lastError, machineID)
	return err
}

// ReleaseClaim releases a machine claim without requeueing (successful convergence).
func (s *Store) ReleaseClaim(ctx context.Context, machineID string) error {
	_, err := s.db.ExecContext(ctx, `
		UPDATE machines
		SET claimed_by = NULL, claimed_at = NULL,
		    reconcile_attempts = 0, reconcile_after = NULL,
		    transition_deadline = NULL
		WHERE id = $1`, machineID)
	return err
}

// ListDeadHostMachines returns machines on dead hosts that have desired_state='running'.
// These are candidates for recreation on healthy hosts.
func (s *Store) ListDeadHostMachines(ctx context.Context) ([]Machine, error) {
	rows, err := s.db.QueryContext(ctx, machineSelect+`
		JOIN hosts h ON h.id = m.host_id
		WHERE h.status = 'dead'
		  AND m.desired_state = 'running'
		  AND m.observed_state = 'lost'
		LIMIT 100`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var machines []Machine
	for rows.Next() {
		m, err := s.scanMachine(rows)
		if err != nil {
			return machines, err
		}
		machines = append(machines, m)
	}
	return machines, rows.Err()
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
