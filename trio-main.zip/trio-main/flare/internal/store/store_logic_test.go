package store

import (
	"testing"
)

func TestNilIfEmpty(t *testing.T) {
	tests := []struct {
		input    string
		wantNil  bool
		wantVal  string
	}{
		{"", true, ""},
		{"hello", false, "hello"},
		{"foo", false, "foo"},
		{"a", false, "a"},
	}

	for _, tt := range tests {
		got := nilIfEmpty(tt.input)
		if tt.wantNil {
			if got != nil {
				t.Errorf("nilIfEmpty(%q) = %v, want nil", tt.input, got)
			}
		} else {
			if got != tt.wantVal {
				t.Errorf("nilIfEmpty(%q) = %v, want %q", tt.input, got, tt.wantVal)
			}
		}
	}
}

func TestRegionFromZone(t *testing.T) {
	tests := []struct {
		zone string
		want string
	}{
		// Standard zones with region-number format
		{"us-central1-a", "us-central1"},
		{"us-east1-b", "us-east1"},
		{"europe-west1-c", "europe-west1"},
		{"asia-east1-a", "asia-east1"},
		// Two-segment zones (e.g. "local" style)
		{"us-central1", "us-central1"},
		// Single-segment zone
		{"local", "local"},
		{"test", "test"},
		// Empty zone
		{"", ""},
	}

	for _, tt := range tests {
		got := RegionFromZone(tt.zone)
		if got != tt.want {
			t.Errorf("RegionFromZone(%q) = %q, want %q", tt.zone, got, tt.want)
		}
	}
}

func TestMin(t *testing.T) {
	tests := []struct {
		a, b, want int
	}{
		{1, 2, 1},
		{2, 1, 1},
		{5, 5, 5},
		{0, 1, 0},
		{1, 0, 0},
		{-1, 1, -1},
		{-5, -3, -5},
	}
	for _, tt := range tests {
		got := min(tt.a, tt.b)
		if got != tt.want {
			t.Errorf("min(%d, %d) = %d, want %d", tt.a, tt.b, got, tt.want)
		}
	}
}
