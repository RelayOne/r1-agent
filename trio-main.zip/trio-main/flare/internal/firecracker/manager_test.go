package firecracker

import (
	"context"
	"os"
	"path/filepath"
	"testing"
)

func TestGenerateMAC(t *testing.T) {
	mac := GenerateMAC("10.0.0.5")
	if mac != "02:FC:00:00:00:05" {
		t.Errorf("mac=%s, want 02:FC:00:00:00:05", mac)
	}

	mac = GenerateMAC("10.1.2.255")
	if mac != "02:FC:00:01:02:ff" {
		t.Errorf("mac=%s, want 02:FC:00:01:02:ff", mac)
	}

	mac = GenerateMAC("invalid")
	if mac != "02:FC:00:00:00:02" {
		t.Errorf("invalid IP should return default, got %s", mac)
	}
}

func TestNewManager(t *testing.T) {
	dir := t.TempDir()
	mgr, err := NewManager(ManagerOpts{VMDir: dir})
	if err != nil {
		t.Fatalf("NewManager: %v", err)
	}
	if mgr.vmDir != dir {
		t.Errorf("vmDir=%s, want %s", mgr.vmDir, dir)
	}
	if mgr.firecrackerBin != "/usr/local/bin/firecracker" {
		t.Errorf("firecrackerBin=%s, want default", mgr.firecrackerBin)
	}
}

func TestNewManagerDefaults(t *testing.T) {
	dir := t.TempDir()
	mgr, err := NewManager(ManagerOpts{
		FirecrackerBin: "/custom/fc",
		KernelPath:     "/custom/vmlinux",
		BaseRootfs:     "/custom/rootfs.ext4",
		VMDir:          dir,
	})
	if err != nil {
		t.Fatalf("NewManager: %v", err)
	}
	if mgr.firecrackerBin != "/custom/fc" {
		t.Errorf("firecrackerBin=%s, want /custom/fc", mgr.firecrackerBin)
	}
	if mgr.kernelPath != "/custom/vmlinux" {
		t.Errorf("kernelPath=%s, want /custom/vmlinux", mgr.kernelPath)
	}
	if mgr.baseRootfs != "/custom/rootfs.ext4" {
		t.Errorf("baseRootfs=%s, want /custom/rootfs.ext4", mgr.baseRootfs)
	}
}

func TestNewManagerCreatesDir(t *testing.T) {
	dir := filepath.Join(t.TempDir(), "nested", "vms")
	_, err := NewManager(ManagerOpts{VMDir: dir})
	if err != nil {
		t.Fatalf("NewManager: %v", err)
	}
	info, err := os.Stat(dir)
	if err != nil {
		t.Fatalf("vmDir not created: %v", err)
	}
	if !info.IsDir() {
		t.Errorf("vmDir is not a directory")
	}
}

func TestCreateGetListState(t *testing.T) {
	dir := t.TempDir()
	// Create a fake rootfs so cp succeeds
	rootfs := filepath.Join(dir, "rootfs.ext4")
	if err := os.WriteFile(rootfs, []byte("fake-rootfs"), 0644); err != nil {
		t.Fatal(err)
	}

	mgr, err := NewManager(ManagerOpts{
		VMDir:      filepath.Join(dir, "vms"),
		BaseRootfs: rootfs,
	})
	if err != nil {
		t.Fatalf("NewManager: %v", err)
	}

	ctx := context.Background()
	vm, err := mgr.Create(ctx, CreateOpts{
		ID:       "vm-test-1",
		CPUs:     2,
		MemoryMB: 512,
		TAP:      "tap99",
		IP:       "10.0.0.5",
		MAC:      "02:FC:00:00:00:05",
		Gateway:  "10.0.0.1",
	})
	if err != nil {
		t.Fatalf("Create: %v", err)
	}
	if vm.ID != "vm-test-1" {
		t.Errorf("vm.ID=%s, want vm-test-1", vm.ID)
	}
	if vm.CPUs != 2 {
		t.Errorf("vm.CPUs=%d, want 2", vm.CPUs)
	}
	if vm.MemoryMB != 512 {
		t.Errorf("vm.MemoryMB=%d, want 512", vm.MemoryMB)
	}
	if vm.IPAddress != "10.0.0.5" {
		t.Errorf("vm.IPAddress=%s, want 10.0.0.5", vm.IPAddress)
	}

	// Get
	got, ok := mgr.Get("vm-test-1")
	if !ok {
		t.Fatal("Get returned false for existing VM")
	}
	if got.ID != vm.ID {
		t.Errorf("Get returned wrong VM: %s", got.ID)
	}

	// Get non-existent
	_, ok = mgr.Get("vm-nonexistent")
	if ok {
		t.Error("Get returned true for non-existent VM")
	}

	// List
	list := mgr.List()
	if len(list) != 1 {
		t.Errorf("List returned %d VMs, want 1", len(list))
	}

	// State (not started, should be stopped)
	state := mgr.State("vm-test-1")
	if state != "stopped" {
		t.Errorf("State=%s, want stopped", state)
	}

	// State of destroyed VM
	state = mgr.State("vm-nonexistent")
	if state != "destroyed" {
		t.Errorf("State=%s, want destroyed", state)
	}
}

func TestCreateWritesConfigAndVMJSON(t *testing.T) {
	dir := t.TempDir()
	rootfs := filepath.Join(dir, "rootfs.ext4")
	os.WriteFile(rootfs, []byte("fake"), 0644)

	mgr, _ := NewManager(ManagerOpts{
		VMDir:      filepath.Join(dir, "vms"),
		BaseRootfs: rootfs,
	})

	ctx := context.Background()
	mgr.Create(ctx, CreateOpts{
		ID: "vm-cfg", CPUs: 1, MemoryMB: 256,
		TAP: "tap0", IP: "10.0.0.2", MAC: "02:FC:00:00:00:02", Gateway: "10.0.0.1",
	})

	vmDir := filepath.Join(dir, "vms", "vm-cfg")
	if _, err := os.Stat(filepath.Join(vmDir, "config.json")); err != nil {
		t.Errorf("config.json not written: %v", err)
	}
	if _, err := os.Stat(filepath.Join(vmDir, "vm.json")); err != nil {
		t.Errorf("vm.json not written: %v", err)
	}
	if _, err := os.Stat(filepath.Join(vmDir, "root.ext4")); err != nil {
		t.Errorf("root.ext4 not copied: %v", err)
	}
}

func TestCreateRejectsInvalidImageRef(t *testing.T) {
	dir := t.TempDir()
	rootfs := filepath.Join(dir, "rootfs.ext4")
	os.WriteFile(rootfs, []byte("fake"), 0644)

	mgr, _ := NewManager(ManagerOpts{
		VMDir:      filepath.Join(dir, "vms"),
		BaseRootfs: rootfs,
	})

	ctx := context.Background()
	_, err := mgr.Create(ctx, CreateOpts{
		ID: "vm-bad-ref", ImageRef: "../../../etc/passwd",
		CPUs: 1, MemoryMB: 256,
		TAP: "tap0", IP: "10.0.0.2", MAC: "02:FC:00:00:00:02", Gateway: "10.0.0.1",
	})
	if err == nil {
		t.Fatal("expected error for path-traversal image ref")
	}
}

func TestDestroyRemovesVM(t *testing.T) {
	dir := t.TempDir()
	rootfs := filepath.Join(dir, "rootfs.ext4")
	os.WriteFile(rootfs, []byte("fake"), 0644)

	mgr, _ := NewManager(ManagerOpts{
		VMDir:      filepath.Join(dir, "vms"),
		BaseRootfs: rootfs,
	})

	ctx := context.Background()
	vm, _ := mgr.Create(ctx, CreateOpts{
		ID: "vm-destroy", CPUs: 1, MemoryMB: 256,
		TAP: "tap0", IP: "10.0.0.2", MAC: "02:FC:00:00:00:02", Gateway: "10.0.0.1",
	})

	if err := mgr.Destroy(ctx, vm); err != nil {
		t.Fatalf("Destroy: %v", err)
	}

	// VM should no longer be in map
	_, ok := mgr.Get("vm-destroy")
	if ok {
		t.Error("VM still exists after Destroy")
	}

	// State should be destroyed
	state := mgr.State("vm-destroy")
	if state != "destroyed" {
		t.Errorf("State=%s, want destroyed after Destroy", state)
	}

	// VM directory should be removed
	vmDir := filepath.Join(dir, "vms", "vm-destroy")
	if _, err := os.Stat(vmDir); err == nil {
		t.Error("VM directory still exists after Destroy")
	}
}

func TestDestroyIdempotent(t *testing.T) {
	dir := t.TempDir()
	rootfs := filepath.Join(dir, "rootfs.ext4")
	os.WriteFile(rootfs, []byte("fake"), 0644)

	mgr, _ := NewManager(ManagerOpts{
		VMDir:      filepath.Join(dir, "vms"),
		BaseRootfs: rootfs,
	})

	ctx := context.Background()
	vm, _ := mgr.Create(ctx, CreateOpts{
		ID: "vm-double-destroy", CPUs: 1, MemoryMB: 256,
		TAP: "tap0", IP: "10.0.0.2", MAC: "02:FC:00:00:00:02", Gateway: "10.0.0.1",
	})

	if err := mgr.Destroy(ctx, vm); err != nil {
		t.Fatalf("first Destroy: %v", err)
	}
	// Second destroy should be a no-op, not an error
	if err := mgr.Destroy(ctx, vm); err != nil {
		t.Fatalf("second Destroy should be idempotent: %v", err)
	}
}

func TestRecoverFromDisk(t *testing.T) {
	dir := t.TempDir()
	rootfs := filepath.Join(dir, "rootfs.ext4")
	os.WriteFile(rootfs, []byte("fake"), 0644)

	// Create a VM with the first manager
	mgr1, _ := NewManager(ManagerOpts{
		VMDir:      filepath.Join(dir, "vms"),
		BaseRootfs: rootfs,
	})
	ctx := context.Background()
	mgr1.Create(ctx, CreateOpts{
		ID: "vm-recover", CPUs: 4, MemoryMB: 1024,
		TAP: "tap0", IP: "10.0.0.3", MAC: "02:FC:00:00:00:03", Gateway: "10.0.0.1",
	})

	// Create a second manager pointing at the same dir (simulates restart)
	mgr2, _ := NewManager(ManagerOpts{
		VMDir:      filepath.Join(dir, "vms"),
		BaseRootfs: rootfs,
	})
	recovered := mgr2.RecoverFromDisk()
	if recovered != 1 {
		t.Fatalf("recovered=%d, want 1", recovered)
	}

	vm, ok := mgr2.Get("vm-recover")
	if !ok {
		t.Fatal("recovered VM not found via Get")
	}
	if vm.CPUs != 4 {
		t.Errorf("recovered CPUs=%d, want 4", vm.CPUs)
	}
	if vm.MemoryMB != 1024 {
		t.Errorf("recovered MemoryMB=%d, want 1024", vm.MemoryMB)
	}
	if vm.IPAddress != "10.0.0.3" {
		t.Errorf("recovered IP=%s, want 10.0.0.3", vm.IPAddress)
	}
}

func TestResourceUsageStoppedVM(t *testing.T) {
	dir := t.TempDir()
	rootfs := filepath.Join(dir, "rootfs.ext4")
	os.WriteFile(rootfs, []byte("fake"), 0644)

	mgr, _ := NewManager(ManagerOpts{
		VMDir:      filepath.Join(dir, "vms"),
		BaseRootfs: rootfs,
	})
	ctx := context.Background()
	mgr.Create(ctx, CreateOpts{
		ID: "vm-usage", CPUs: 2, MemoryMB: 512,
		TAP: "tap0", IP: "10.0.0.2", MAC: "02:FC:00:00:00:02", Gateway: "10.0.0.1",
	})

	// Stopped VM (PID=0) should not count toward resource usage
	cpus, mem := mgr.ResourceUsage()
	if cpus != 0 || mem != 0 {
		t.Errorf("stopped VM should contribute 0 resources, got cpus=%d mem=%d", cpus, mem)
	}
}

func TestExecDisabled(t *testing.T) {
	dir := t.TempDir()
	mgr, _ := NewManager(ManagerOpts{VMDir: dir})

	ctx := context.Background()
	code, stdout, stderr, err := mgr.Exec(ctx, "any-vm", "id")
	if err == nil {
		t.Fatal("Exec should return an error (disabled for security)")
	}
	if code != -1 {
		t.Errorf("exit code=%d, want -1", code)
	}
	if stdout != "" || stderr != "" {
		t.Errorf("expected empty stdout/stderr, got %q / %q", stdout, stderr)
	}
}

func TestStopNoopWhenNotRunning(t *testing.T) {
	dir := t.TempDir()
	rootfs := filepath.Join(dir, "rootfs.ext4")
	os.WriteFile(rootfs, []byte("fake"), 0644)

	mgr, _ := NewManager(ManagerOpts{
		VMDir:      filepath.Join(dir, "vms"),
		BaseRootfs: rootfs,
	})
	ctx := context.Background()
	vm, _ := mgr.Create(ctx, CreateOpts{
		ID: "vm-stop-noop", CPUs: 1, MemoryMB: 256,
		TAP: "tap0", IP: "10.0.0.2", MAC: "02:FC:00:00:00:02", Gateway: "10.0.0.1",
	})

	// Stop on a VM with PID=0 should be a no-op
	if err := mgr.Stop(ctx, vm); err != nil {
		t.Fatalf("Stop on stopped VM: %v", err)
	}
	state := mgr.State("vm-stop-noop")
	if state != "stopped" {
		t.Errorf("state=%s, want stopped", state)
	}
}

func TestCreateWithEnvWritesEnvFile(t *testing.T) {
	dir := t.TempDir()
	rootfs := filepath.Join(dir, "rootfs.ext4")
	os.WriteFile(rootfs, []byte("fake"), 0644)

	mgr, _ := NewManager(ManagerOpts{
		VMDir:      filepath.Join(dir, "vms"),
		BaseRootfs: rootfs,
	})
	ctx := context.Background()
	mgr.Create(ctx, CreateOpts{
		ID: "vm-env", CPUs: 1, MemoryMB: 256,
		TAP: "tap0", IP: "10.0.0.2", MAC: "02:FC:00:00:00:02", Gateway: "10.0.0.1",
		Env: map[string]string{"APP_PORT": "8080"},
	})

	envPath := filepath.Join(dir, "vms", "vm-env", "env.sh")
	data, err := os.ReadFile(envPath)
	if err != nil {
		t.Fatalf("env.sh not written: %v", err)
	}
	if len(data) == 0 {
		t.Error("env.sh is empty")
	}
}
