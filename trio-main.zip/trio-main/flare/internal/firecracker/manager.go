package firecracker

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

type VM struct {
	mu         sync.Mutex        `json:"-"` // protects PID, StartedAt from concurrent access
	ID         string            `json:"id"`
	SocketPath string            `json:"socket_path"`
	PID        int               `json:"pid"`
	TAPDevice  string            `json:"tap_device"`
	IPAddress  string            `json:"ip_address"`
	MACAddress string            `json:"mac_address"`
	RootDrive  string            `json:"root_drive"`
	DataDrive  string            `json:"data_drive"`
	CPUs       int               `json:"cpus"`
	MemoryMB   int               `json:"memory_mb"`
	Env        map[string]string `json:"env,omitempty"`
	Metadata   map[string]string `json:"metadata,omitempty"`
	StartedAt  time.Time         `json:"started_at"`
}

// VMSnapshot is a point-in-time read of mutable VM fields (PID, StartedAt).
// Use vm.Snapshot() to read these safely from outside the firecracker package.
type VMSnapshot struct {
	PID       int
	StartedAt time.Time
	IPAddress string
}

// Snapshot returns a thread-safe copy of mutable VM fields.
func (vm *VM) Snapshot() VMSnapshot {
	vm.mu.Lock()
	defer vm.mu.Unlock()
	return VMSnapshot{PID: vm.PID, StartedAt: vm.StartedAt, IPAddress: vm.IPAddress}
}

type Manager struct {
	mu             sync.RWMutex
	firecrackerBin string
	kernelPath     string
	baseRootfs     string
	vmDir          string
	vms            map[string]*VM
}

type ManagerOpts struct {
	FirecrackerBin string
	KernelPath     string
	BaseRootfs     string
	VMDir          string
}

func NewManager(opts ManagerOpts) (*Manager, error) {
	if opts.FirecrackerBin == "" {
		opts.FirecrackerBin = "/usr/local/bin/firecracker"
	}
	if opts.KernelPath == "" {
		opts.KernelPath = "/var/lib/flare/vmlinux"
	}
	if opts.BaseRootfs == "" {
		opts.BaseRootfs = "/var/lib/flare/rootfs.ext4"
	}
	if opts.VMDir == "" {
		opts.VMDir = "/var/lib/flare/vms"
	}
	if err := os.MkdirAll(opts.VMDir, 0755); err != nil {
		return nil, fmt.Errorf("create vm dir %s: %w", opts.VMDir, err)
	}
	return &Manager{
		firecrackerBin: opts.FirecrackerBin,
		kernelPath:     opts.KernelPath,
		baseRootfs:     opts.BaseRootfs,
		vmDir:          opts.VMDir,
		vms:            make(map[string]*VM),
	}, nil
}

type CreateOpts struct {
	ID       string
	ImageRef string
	CPUs     int
	MemoryMB int
	Env      map[string]string
	Metadata map[string]string
	DataDisk string
	TAP      string
	IP       string
	MAC      string
	Gateway  string
}

// Create prepares a VM: copies rootfs, writes Firecracker config JSON.
// Does not start the process. Call Start() after Create().
func (m *Manager) Create(ctx context.Context, opts CreateOpts) (*VM, error) {
	dir := filepath.Join(m.vmDir, opts.ID)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, fmt.Errorf("create vm dir: %w", err)
	}

	socketPath := filepath.Join(dir, "firecracker.sock")

	// Build boot args with guest network configuration.
	// The ip= kernel parameter configures the guest NIC at boot without DHCP.
	// Format: ip=client:server:gateway:netmask:hostname:device:autoconf
	bootArgs := fmt.Sprintf(
		"console=ttyS0 reboot=k panic=1 pci=off init=/sbin/init ip=%s::%s:255.255.255.0::%s:off",
		opts.IP, opts.Gateway, "eth0",
	)

	// Select rootfs: use image_ref if provided, otherwise base image.
	// Fail loudly if a specific image was requested but doesn't exist.
	rootfsSource := m.baseRootfs
	if opts.ImageRef != "" {
		// Prevent path traversal: image ref must be a simple name (alphanumeric, dash, underscore, dot).
		for _, c := range opts.ImageRef {
			if !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.') {
				os.RemoveAll(dir)
				return nil, fmt.Errorf("invalid image_ref %q: only alphanumeric, dash, underscore, and dot allowed", opts.ImageRef)
			}
		}
		candidate := filepath.Join(m.vmDir, ".images", opts.ImageRef+".ext4")
		if _, err := os.Stat(candidate); err != nil {
			os.RemoveAll(dir)
			return nil, fmt.Errorf("requested image %q not found at %s", opts.ImageRef, candidate)
		}
		rootfsSource = candidate
	}

	rootDrive := filepath.Join(dir, "root.ext4")
	cpCmd := exec.CommandContext(ctx, "cp", "--reflink=auto", rootfsSource, rootDrive)
	if out, err := cpCmd.CombinedOutput(); err != nil {
		os.RemoveAll(dir)
		return nil, fmt.Errorf("copy rootfs: %s: %w", strings.TrimSpace(string(out)), err)
	}

	// Store env on host for debugging, but real injection happens via MMDS after boot.
	if len(opts.Env) > 0 {
		var sb strings.Builder
		for k, v := range opts.Env {
			sb.WriteString(fmt.Sprintf("export %s=%q\n", k, v))
		}
		os.WriteFile(filepath.Join(dir, "env.sh"), []byte(sb.String()), 0644)
	}

	cfg := fcConfig{
		BootSource: bootSource{
			KernelImagePath: m.kernelPath,
			BootArgs:        bootArgs,
		},
		Drives: []drive{
			{DriveID: "rootfs", PathOnHost: rootDrive, IsRootDevice: true, IsReadOnly: false},
		},
		MachineConfig: machineConfig{VCPUCount: opts.CPUs, MemSizeMiB: opts.MemoryMB},
		NetworkInterfaces: []networkInterface{
			{IfaceID: "eth0", HostDevName: opts.TAP, GuestMAC: opts.MAC},
		},
	}

	// Always enable MMDS (MicroVM Metadata Service).
	// Guest reads vm_id, ip, hostname, env, metadata from http://169.254.169.254/
	cfg.MMDSConfig = &mmdsConfig{
		NetworkInterfaces: []string{"eth0"},
		Version:           "V1",
	}
	if opts.DataDisk != "" {
		cfg.Drives = append(cfg.Drives, drive{
			DriveID: "data", PathOnHost: opts.DataDisk, IsRootDevice: false, IsReadOnly: false,
		})
	}

	configJSON, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		os.RemoveAll(dir)
		return nil, fmt.Errorf("marshal config: %w", err)
	}
	if err := os.WriteFile(filepath.Join(dir, "config.json"), configJSON, 0644); err != nil {
		os.RemoveAll(dir)
		return nil, fmt.Errorf("write config.json: %w", err)
	}

	vm := &VM{
		ID: opts.ID, SocketPath: socketPath, TAPDevice: opts.TAP,
		IPAddress: opts.IP, MACAddress: opts.MAC, RootDrive: rootDrive,
		DataDrive: opts.DataDisk, CPUs: opts.CPUs, MemoryMB: opts.MemoryMB,
		Env: opts.Env, Metadata: opts.Metadata,
	}

	// Persist VM metadata for restart recovery
	vmJSON, err := json.MarshalIndent(vm, "", "  ")
	if err != nil {
		os.RemoveAll(dir)
		return nil, fmt.Errorf("marshal vm.json: %w", err)
	}
	if err := os.WriteFile(filepath.Join(dir, "vm.json"), vmJSON, 0644); err != nil {
		os.RemoveAll(dir)
		return nil, fmt.Errorf("write vm.json: %w", err)
	}

	m.mu.Lock()
	m.vms[opts.ID] = vm
	m.mu.Unlock()
	return vm, nil
}

// Start boots a VM via the Firecracker binary. Returns when the API socket is responsive.
// Idempotent: if the VM is already running (PID alive), returns nil without double-launching.
func (m *Manager) Start(ctx context.Context, vm *VM) error {
	vm.mu.Lock()
	defer vm.mu.Unlock()

	// Idempotency: check if already running before spawning a new process.
	// Without this, repeated starts can leave multiple Firecracker processes
	// contending for the same TAP device and rootfs.
	if vm.PID != 0 {
		if err := syscall.Kill(vm.PID, 0); err == nil {
			return nil // already running
		}
		// PID is stale, clear it and proceed with fresh start
		vm.PID = 0
	}

	dir := filepath.Join(m.vmDir, vm.ID)
	configPath := filepath.Join(dir, "config.json")
	os.Remove(vm.SocketPath)

	cmd := exec.CommandContext(ctx, m.firecrackerBin,
		"--api-sock", vm.SocketPath,
		"--config-file", configPath,
	)
	cmd.Dir = dir
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	stdout, err := os.Create(filepath.Join(dir, "stdout.log"))
	if err != nil {
		return fmt.Errorf("create stdout log: %w", err)
	}
	defer stdout.Close()
	stderr, err := os.Create(filepath.Join(dir, "stderr.log"))
	if err != nil {
		return fmt.Errorf("create stderr log: %w", err)
	}
	defer stderr.Close()
	cmd.Stdout = stdout
	cmd.Stderr = stderr

	if err := cmd.Start(); err != nil {
		return fmt.Errorf("start firecracker: %w", err)
	}
	vm.PID = cmd.Process.Pid
	vm.StartedAt = time.Now()

	// Persist updated PID so recovery can find running VMs
	if err := m.persistVM(vm); err != nil {
		log.Printf("[firecracker] persistVM failed after start for %s: %v (VM may be orphaned on restart)", vm.ID, err)
	}

	// Poll for API socket readiness
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		conn, err := net.DialTimeout("unix", vm.SocketPath, 200*time.Millisecond)
		if err == nil {
			conn.Close()
			// Socket ready. Always inject MMDS (vm_id, ip, hostname, env, metadata).
			m.injectMMDS(vm)
			return nil
		}
		time.Sleep(50 * time.Millisecond)
	}
	return fmt.Errorf("firecracker did not respond within 5s (pid=%d)", vm.PID)
}

// injectMMDS sends env/metadata to Firecracker's MicroVM Metadata Service.
// Guest reads this from http://169.254.169.254/ (like AWS/GCP instance metadata).
// Called after socket is ready in Start(). Best-effort: failure is logged, not fatal.
func (m *Manager) injectMMDS(vm *VM) {
	client := &http.Client{
		Transport: &http.Transport{
			DialContext: func(_ context.Context, _, _ string) (net.Conn, error) {
				return net.Dial("unix", vm.SocketPath)
			},
		},
		Timeout: 3 * time.Second,
	}

	// Build MMDS payload: env vars + VM metadata
	payload := map[string]interface{}{
		"env":      vm.Env,
		"metadata": vm.Metadata,
		"vm_id":    vm.ID,
		"ip":       vm.IPAddress,
		"hostname": vm.ID + ".ember.dev",
	}
	data, _ := json.Marshal(payload)

	req, _ := http.NewRequest("PUT", "http://localhost/mmds", strings.NewReader(string(data)))
	req.Header.Set("Content-Type", "application/json")
	resp, err := client.Do(req)
	if err != nil {
		// MMDS injection is best-effort. The VM still boots and serves traffic.
		// Guest init will see empty metadata and use defaults.
		return
	}
	resp.Body.Close()
}

// Stop gracefully shuts down a VM, force-kills after 10s.
// Works for both child processes (normal start) and non-child processes
// (recovered VMs after daemon restart, where Wait() returns immediately).
func (m *Manager) Stop(ctx context.Context, vm *VM) error {
	vm.mu.Lock()

	if vm.PID == 0 {
		vm.mu.Unlock()
		return nil
	}

	// Check if process is actually alive first
	if err := syscall.Kill(vm.PID, 0); err != nil {
		vm.PID = 0
		if pErr := m.persistVM(vm); pErr != nil {
			log.Printf("[firecracker] persistVM failed for %s (pid cleared): %v", vm.ID, pErr)
		}
		vm.mu.Unlock()
		return nil
	}

	// Capture state needed for graceful shutdown, then release lock
	// so other goroutines (e.g. State()) aren't blocked during network I/O.
	socketPath := vm.SocketPath
	pid := vm.PID
	vm.mu.Unlock()

	// Graceful: SendCtrlAltDel via API socket (lock-free)
	if socketPath != "" {
		client := &http.Client{
			Transport: &http.Transport{
				DialContext: func(_ context.Context, _, _ string) (net.Conn, error) {
					return net.Dial("unix", socketPath)
				},
			},
			Timeout: 3 * time.Second,
		}
		body := strings.NewReader(`{"action_type":"SendCtrlAltDel"}`)
		req, _ := http.NewRequestWithContext(ctx, "PUT", "http://localhost/actions", body)
		req.Header.Set("Content-Type", "application/json")
		client.Do(req)
	}

	// Poll for process exit instead of Wait() (Wait only works for child processes).
	// For recovered VMs after daemon restart, the FC process is not our child.
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		if err := syscall.Kill(pid, 0); err != nil {
			// Process is gone
			vm.mu.Lock()
			vm.PID = 0
			if pErr := m.persistVM(vm); pErr != nil {
				log.Printf("[firecracker] persistVM failed for %s (stopped): %v", vm.ID, pErr)
			}
			vm.mu.Unlock()
			return nil
		}
		time.Sleep(200 * time.Millisecond)
	}

	// Force kill (process group to catch any children)
	syscall.Kill(-pid, syscall.SIGKILL)
	// Brief wait for cleanup
	time.Sleep(500 * time.Millisecond)
	vm.mu.Lock()
	vm.PID = 0
	if pErr := m.persistVM(vm); pErr != nil {
		log.Printf("[firecracker] persistVM failed for %s (force killed): %v", vm.ID, pErr)
	}
	vm.mu.Unlock()
	return nil
}

// persistVM writes vm.json to disk for restart recovery.
// Returns an error if marshalling or writing fails, so callers can log
// the failure — a lost vm.json means the VM becomes orphaned after restart.
func (m *Manager) persistVM(vm *VM) error {
	dir := filepath.Join(m.vmDir, vm.ID)
	data, err := json.MarshalIndent(vm, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal vm %s: %w", vm.ID, err)
	}
	if err := os.WriteFile(filepath.Join(dir, "vm.json"), data, 0644); err != nil {
		return fmt.Errorf("write vm.json for %s: %w", vm.ID, err)
	}
	return nil
}

// Destroy stops the VM and removes all resources.
// FLARE-018: Hold m.mu write lock across entire Destroy to prevent concurrent
// access to VM struct fields during teardown.
func (m *Manager) Destroy(ctx context.Context, vm *VM) error {
	m.mu.Lock()
	// Check if already removed (concurrent destroy)
	if _, exists := m.vms[vm.ID]; !exists {
		m.mu.Unlock()
		return nil
	}
	delete(m.vms, vm.ID)
	m.mu.Unlock()

	m.Stop(ctx, vm)
	os.RemoveAll(filepath.Join(m.vmDir, vm.ID))
	return nil
}

// State returns the current state string.
func (m *Manager) State(vmID string) string {
	m.mu.RLock()
	vm, ok := m.vms[vmID]
	m.mu.RUnlock()
	if !ok {
		return "destroyed"
	}
	vm.mu.Lock()
	defer vm.mu.Unlock()
	if vm.PID == 0 {
		return "stopped"
	}
	if err := syscall.Kill(vm.PID, 0); err != nil {
		vm.PID = 0
		return "stopped"
	}
	return "running"
}

func (m *Manager) Get(vmID string) (*VM, bool) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	vm, ok := m.vms[vmID]
	return vm, ok
}

func (m *Manager) List() []*VM {
	m.mu.RLock()
	defer m.mu.RUnlock()
	list := make([]*VM, 0, len(m.vms))
	for _, vm := range m.vms {
		list = append(list, vm)
	}
	return list
}

func (m *Manager) ResourceUsage() (cpus, memMB int) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	for _, vm := range m.vms {
		vm.mu.Lock()
		pid := vm.PID
		vm.mu.Unlock()
		if pid > 0 {
			if err := syscall.Kill(pid, 0); err == nil {
				cpus += vm.CPUs
				memMB += vm.MemoryMB
			}
		}
	}
	return
}

// SECURITY(FLARE-003): Exec is permanently disabled. The previous implementation
// concatenated user-supplied cmd/args into a single SSH command string, which is
// a textbook command-injection vulnerability (e.g. cmd="id; rm -rf /"). Even with
// shell escaping, SSH command strings are interpreted by the remote shell, making
// safe quoting extremely fragile. Do NOT re-enable without a secure execution
// protocol (e.g. gRPC agent inside the VM with explicit argv passing).
func (m *Manager) Exec(ctx context.Context, vmID, cmd string, args ...string) (int, string, string, error) {
	return -1, "", "", fmt.Errorf("exec is disabled: command injection risk — use a secure execution protocol")
}

// RecoverFromDisk scans the VM directory for vm.json files and restores
// the in-memory VM map. Checks whether each VM's process is still running.
// Returns the number of VMs recovered.
func (m *Manager) RecoverFromDisk() int {
	entries, err := os.ReadDir(m.vmDir)
	if err != nil {
		// FLARE-024: Log the error instead of failing silently
		log.Printf("[firecracker] RecoverFromDisk: ReadDir %s failed: %v", m.vmDir, err)
		return 0
	}
	recovered := 0
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		vmPath := filepath.Join(m.vmDir, entry.Name(), "vm.json")
		data, err := os.ReadFile(vmPath)
		if err != nil {
			continue
		}
		var vm VM
		if err := json.Unmarshal(data, &vm); err != nil {
			continue
		}
		// Check if the Firecracker process is still alive
		if vm.PID > 0 {
			if err := syscall.Kill(vm.PID, 0); err != nil {
				vm.PID = 0 // process died
			}
		}
		m.vms[vm.ID] = &vm
		recovered++
	}
	return recovered
}

// GenerateMAC creates a locally-administered MAC from an IP.
func GenerateMAC(ip string) string {
	parts := strings.Split(ip, ".")
	if len(parts) != 4 {
		return "02:FC:00:00:00:02"
	}
	b2, _ := strconv.Atoi(parts[1])
	b3, _ := strconv.Atoi(parts[2])
	b4, _ := strconv.Atoi(parts[3])
	return fmt.Sprintf("02:FC:00:%02x:%02x:%02x", b2, b3, b4)
}

type fcConfig struct {
	BootSource        bootSource         `json:"boot-source"`
	Drives            []drive            `json:"drives"`
	MachineConfig     machineConfig      `json:"machine-config"`
	NetworkInterfaces []networkInterface `json:"network-interfaces"`
	MMDSConfig        *mmdsConfig        `json:"mmds-config,omitempty"`
}
type bootSource struct {
	KernelImagePath string `json:"kernel_image_path"`
	BootArgs        string `json:"boot_args"`
}
type drive struct {
	DriveID      string `json:"drive_id"`
	PathOnHost   string `json:"path_on_host"`
	IsRootDevice bool   `json:"is_root_device"`
	IsReadOnly   bool   `json:"is_read_only"`
}
type machineConfig struct {
	VCPUCount  int  `json:"vcpu_count"`
	MemSizeMiB int  `json:"mem_size_mib"`
	SMT        bool `json:"smt,omitempty"`
}
type networkInterface struct {
	IfaceID     string `json:"iface_id"`
	HostDevName string `json:"host_dev_name"`
	GuestMAC    string `json:"guest_mac,omitempty"`
}
type mmdsConfig struct {
	NetworkInterfaces []string `json:"network_interfaces"`
	Version           string   `json:"version"`
}
