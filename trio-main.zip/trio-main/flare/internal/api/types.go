// Package api implements the Fly-compatible REST API.
package api

// VM states
const (
	StateCreating  = "creating"
	StateCreated   = "created"
	StateStarting  = "starting"
	StateRunning   = "running"
	StateStopping  = "stopping"
	StateStopped   = "stopped"
	StateFailed    = "failed"
	StateLost      = "lost"
	StateDestroyed = "destroyed"
	StateUnknown   = "unknown"
)

// Host states
const (
	HostReady = "ready"
	HostDead  = "dead"
)

// CreateAppRequest mirrors Fly POST /v1/apps
type CreateAppRequest struct {
	AppName  string `json:"app_name"`
	OrgSlug  string `json:"org_slug"`
}

// CreateMachineRequest mirrors Fly POST /v1/apps/:app/machines
type CreateMachineRequest struct {
	Name   string            `json:"name"`
	Region string            `json:"region"`
	Config MachineConfig     `json:"config"`
}

type MachineConfig struct {
	Image    string            `json:"image"`
	Guest    GuestConfig       `json:"guest"`
	Env      map[string]string `json:"env"`
	Metadata map[string]string `json:"metadata"`
	Mounts   []MountConfig     `json:"mounts"`
}

type GuestConfig struct {
	CPUs     int `json:"cpus"`
	MemoryMB int `json:"memory_mb"`
}

type MountConfig struct {
	Volume string `json:"volume"`
	Path   string `json:"path"`
}

// MachineResponse mirrors Fly machine response with desired/observed state split
type MachineResponse struct {
	ID                string        `json:"id"`
	Name              string        `json:"name"`
	State             string        `json:"state"`
	DesiredState      string        `json:"desired_state"`
	ObservedState     string        `json:"observed_state"`
	Region            string        `json:"region"`
	IPAddress         string        `json:"ip_address,omitempty"`
	GeneratedHostname string        `json:"generated_hostname,omitempty"`
	LastError         string        `json:"last_error,omitempty"`
	Config            MachineConfig `json:"config"`
	CreatedAt         string        `json:"created_at"`
	UpdatedAt         string        `json:"updated_at"`
}

// CreateVolumeRequest mirrors Fly POST /v1/apps/:app/volumes
type CreateVolumeRequest struct {
	Name   string `json:"name"`
	Region string `json:"region"`
	SizeGB int    `json:"size_gb"`
}

// HostnameRequest for POST /v1/apps/:app/hostnames
type HostnameRequest struct {
	VMID     string `json:"vm_id"`
	Hostname string `json:"hostname"`
}
