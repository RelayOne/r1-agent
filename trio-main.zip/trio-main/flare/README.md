# Flare

Firecracker microVMs on GCP. Fly Machines API on your own infrastructure.

## v1 Scope

Flare v1 targets internal/private beta with a deliberately narrow surface:

- One region, multi-zone MIG hosts
- HTTP workloads on guest port :8080
- App + machine create/start/stop/destroy
- Generated `*.ember.dev` hostnames
- Custom hostnames for domains you control
- One bootable guest image (ext4)
- Postgres-backed control plane with desired/observed state split
- No volumes, no exec, no snapshot/restore, no live migration

## Architecture

```
                    Cloudflare Tunnel (TLS)
                           |
                    +------+-------+
                    | Control Plane |  Go HTTP server, Postgres
                    |  API (:8090)  |  Apps, machines, hostnames
                    |  Proxy (:8080)|  Hostname -> machine -> host
                    +------+-------+
                           | VPC internal
        +------------------+------------------+
   +----+-----+      +----+-----+      +----+-----+
   | Host (MIG)|      | Host (MIG)|      | Host (MIG)|
   | placement |      | placement |      | placement |
   |  :9090 API|      |  :9090 API|      |  :9090 API|
   |  :8080 ing|      |  :8080 ing|      |  :8080 ing|
   | FC: vm-a  |      | FC: vm-d  |      | FC: vm-g  |
   | FC: vm-b  |      | FC: vm-e  |      | FC: vm-h  |
   +-----+-----+      +-----+-----+      +-----+-----+
         |                   |                   |
         +------- Filestore NFS (shared) --------+
```

### Ingress path

```
Client -> Cloudflare (TLS) -> Control plane :8080
  -> hostname lookup in Postgres (generated + custom)
  -> reverse proxy to host placement :8080
  -> /_vm/{machineID}/* -> reverse proxy to VM TAP IP:8080
```

No nginx on hosts. No cloudflared on hosts. Routing is a control-plane
concern backed by Postgres, not per-host config files.

### State model

Machines have split state:

| Field | Values | Who sets it |
|-------|--------|-------------|
| `desired_state` | stopped, running, destroyed | API caller |
| `observed_state` | creating, created, starting, running, stopping, stopped, failed, lost, destroyed | Control plane (from placement responses + reconciliation) |

Hosts track capacity with reservations:

```
available = capacity - used - reserved
```

`PlaceAndReserve` uses `SELECT FOR UPDATE SKIP LOCKED` for atomic
scheduling. Reservations are released on create failure.

## Components

### Control Plane (`cmd/control-plane/`)

Go HTTP server. Two listeners:
- `:8090` - Fly-compatible REST API + internal host registration
- `:8080` - VM traffic ingress proxy

All state in Postgres via `internal/store/`. No in-memory maps.
Hostname resolution via DB join across machines + hostnames + hosts.

### Placement Daemon (`cmd/placement/`)

Go binary on each MIG host. Two listeners:
- `:9090` - Internal lifecycle API (create/start/stop/destroy)
- `:8080` - VM traffic ingress proxy (`/_vm/{id}/*` -> VM TAP IP)

Persists VM metadata to `vm.json` for restart recovery.
Registers with control plane on boot, heartbeats every 15s.

### Postgres Store (`internal/store/`)

Single `database/sql` store. Tables: apps, hosts, machines, hostnames,
machine_events. Schema in `migrations/001_initial.sql`.

### Infrastructure (`deploy/terraform/`)

GCE MIG with:
- `advanced_machine_features.enable_nested_virtualization = true`
- Health check firewall for Google probes (130.211.0.0/22, 35.191.0.0/16)
- Internal firewall for control plane -> placement (ports 9090, 8080)
- Instance tags (`flare-host`) for firewall targeting
- Filestore NFS for shared storage
- Runtime config via GCE instance metadata

Startup script assumes pre-baked host image. No internet downloads at boot.

## API (Fly-compatible)

```
POST   /v1/apps                          Create app
DELETE /v1/apps/:app                     Mark app deleting (202)

POST   /v1/apps/:app/machines            Create VM
GET    /v1/apps/:app/machines            List VMs
GET    /v1/apps/:app/machines/:id        Get VM (desired + observed state)
DELETE /v1/apps/:app/machines/:id        Destroy VM
POST   /v1/apps/:app/machines/:id/start  Start VM
POST   /v1/apps/:app/machines/:id/stop   Stop VM

POST   /v1/apps/:app/hostnames           Register custom hostname
DELETE /v1/apps/:app/hostnames/:id       Deregister hostname

POST   /v1/apps/:app/machines/:id/exec   501 Not Implemented (v1)
POST   /v1/apps/:app/volumes             501 Not Implemented (v1)
GET    /v1/apps/:app/volumes             501 Not Implemented (v1)
DELETE /v1/apps/:app/volumes/:id         501 Not Implemented (v1)
```

### Lifecycle semantics

- **create**: Reserves host capacity atomically. Calls placement. Returns
  non-2xx if placement fails. Releases reservation on failure.
- **start/stop**: Updates desired_state, calls placement, only updates
  observed_state on success. Returns host error on failure.
- **destroy**: On placement failure, marks machine `lost` instead of
  deleting DB state. Does not orphan resources.
- **delete app**: Returns 202. Marks `deleting`. Background cleanup.

### Guest contract (v1)

- `config.image` is a bootable ext4 guest image
- Guest must serve HTTP on `:8080`
- One baked image per host (no image distribution in v1)
- Env delivery via Firecracker MMDS (see `docs/guest-contract.md`)
- No exec (SSH removed, guest agent not yet implemented)

## Recovery

### Control plane restart

State survives in Postgres. Hostname resolution, machine state, host
registry all restored on restart. Ingress resumes immediately.

### Placement daemon restart

`RecoverFromDisk()` scans VM_DIR, reads `vm.json` per VM, checks PID
liveness, rebuilds in-memory map. Running VMs continue serving.

### Host death

Health loop marks hosts dead after 90s without heartbeat.
Machines on dead hosts should be marked `lost` by reconciliation loop.
Manual recovery in v1 (auto-recreate planned for v2).

## Known Limitations (v1)

- No volumes (stateless machines only)
- No exec
- No OCI image support (one baked ext4 per host)
- No snapshot/restore or live migration
- No tenant billing or quotas
- No arbitrary customer domain verification
- Single control plane process (no HA)
- config.env delivered via MMDS (requires guest flare-init, see docs/guest-contract.md)
- Tests cover helper packages + reconciler store methods; integration tests need real Firecracker

## Development

```bash
# Build
go build ./...
go test ./...

# TypeScript SDK
cd sdk/typescript && npm install && npm run build

# Apply migrations
psql $DATABASE_URL < migrations/001_initial.sql
psql $DATABASE_URL < migrations/002_reconciliation.sql

# Run control plane (starts reconciliation loop automatically)
DATABASE_URL=postgres://... FLARE_API_KEY=... FLARE_INTERNAL_KEY=... go run ./cmd/control-plane

# Run placement daemon
FLARE_CONTROL_PLANE=http://... HOST_ID=... HOST_ZONE=... HOST_IP=... go run ./cmd/placement

# Bake host image (requires Packer + GCP credentials)
cd deploy/packer && packer init . && packer build -var project_id=$PROJECT .

# Deploy infrastructure
cd deploy/terraform && terraform apply -var project_id=$PROJECT ...
```

## Post-v1 Roadmap

- Persistent volumes (file-backed ext4 on Filestore)
- Guest agent for exec
- Control plane HA (Cloud SQL + multiple replicas)
- Start-time capacity reservation (currently only create reserves)
- Tenant quotas, billing, domain verification
- Structured logging, metrics, dashboards, alerts
