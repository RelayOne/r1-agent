package main

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/subtle"
	"database/sql"
	"embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"sync"
	"path"
	"regexp"
	"sort"
	"strings"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib" // pgx v5 driver for Postgres

	"flare/internal/api"
	"flare/internal/reconcile"
	"flare/internal/store"
)

//go:embed migrations/*.sql
var migrationsFS embed.FS

// validHostnameRe matches RFC 1123 hostnames (labels separated by dots).
var validHostnameRe = regexp.MustCompile(`^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$`)

func newID(prefix string) string {
	b := make([]byte, 8)
	rand.Read(b)
	return prefix + hex.EncodeToString(b)
}

// hostnameEntry is a cached hostname->machine+host resolution with TTL.
type hostnameEntry struct {
	machine  store.Machine
	host     store.Host
	cachedAt time.Time
}

const hostnameCacheTTL = 30 * time.Second

type ControlPlane struct {
	store       *store.Store
	internalKey string
	client      *http.Client
	// FLARE-022: Cache reverse proxies per target host to avoid per-request allocation.
	proxyCache sync.Map // map[string]*httputil.ReverseProxy keyed by host:port
	// FLARE-026: Cache hostname->machine+host lookups to reduce DB queries on
	// the ingress hot path. Entries expire after 30 seconds. A sync.Map is used
	// because reads vastly outnumber writes (steady-state traffic to known hostnames).
	hostnameCache sync.Map // map[string]*hostnameEntry keyed by lowercase hostname
}

func main() {
	port := envOr("PORT", "8090")
	apiKey := os.Getenv("FLARE_API_KEY")
	if apiKey == "" {
		log.Fatal("FLARE_API_KEY is required")
	}
	if os.Getenv("FLARE_INTERNAL_KEY") == "" {
		log.Fatal("FLARE_INTERNAL_KEY must be set")
	}

	var db *sql.DB
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		log.Fatal("DATABASE_URL is required")
	}
	var err error
	db, err = sql.Open("pgx", dsn)
	if err != nil {
		log.Fatalf("database: %v", err)
	}
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(25) // FLARE-023: Match MaxOpenConns to avoid connection churn
	if err := db.Ping(); err != nil {
		log.Fatalf("database ping: %v", err)
	}
	log.Printf("Connected to Postgres")

	// Run SQL migrations before starting the application.
	if err := runMigrations(db); err != nil {
		log.Fatalf("migrations: %v", err)
	}

	st := store.New(db)

	cp := &ControlPlane{
		store:       st,
		internalKey: os.Getenv("FLARE_INTERNAL_KEY"),
		client:      &http.Client{Timeout: 30 * time.Second},
	}

	mux := http.NewServeMux()

	auth := func(next http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			token := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
			if subtle.ConstantTimeCompare([]byte(token), []byte(apiKey)) != 1 {
				writeJSON(w, 401, map[string]string{"error": "Unauthorized"})
				return
			}
			next(w, r)
		}
	}

	internalAuth := func(next http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			if subtle.ConstantTimeCompare([]byte(r.Header.Get("X-Internal-Key")), []byte(cp.internalKey)) != 1 {
				writeJSON(w, 401, map[string]string{"error": "Unauthorized"})
				return
			}
			next(w, r)
		}
	}

	// ── Apps ──
	mux.HandleFunc("POST /v1/apps", auth(cp.createApp))
	mux.HandleFunc("DELETE /v1/apps/{app}", auth(cp.deleteApp))

	// ── Machines ──
	mux.HandleFunc("POST /v1/apps/{app}/machines", auth(cp.createMachine))
	mux.HandleFunc("GET /v1/apps/{app}/machines", auth(cp.listMachines))
	mux.HandleFunc("GET /v1/apps/{app}/machines/{id}", auth(cp.getMachine))
	mux.HandleFunc("DELETE /v1/apps/{app}/machines/{id}", auth(cp.destroyMachine))
	mux.HandleFunc("POST /v1/apps/{app}/machines/{id}/start", auth(cp.startMachine))
	mux.HandleFunc("POST /v1/apps/{app}/machines/{id}/stop", auth(cp.stopMachine))
	mux.HandleFunc("POST /v1/apps/{app}/machines/{id}/exec", auth(cp.execMachine))

	// ── Hostnames ──
	mux.HandleFunc("POST /v1/apps/{app}/hostnames", auth(cp.createHostname))
	mux.HandleFunc("DELETE /v1/apps/{app}/hostnames/{id}", auth(cp.deleteHostname))

	// ── Volumes (not implemented in v1) ──
	notImpl := func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, 501, map[string]string{"error": "volumes not available in v1"})
	}
	mux.HandleFunc("POST /v1/apps/{app}/volumes", auth(notImpl))
	mux.HandleFunc("GET /v1/apps/{app}/volumes", auth(notImpl))
	mux.HandleFunc("DELETE /v1/apps/{app}/volumes/{id}", auth(notImpl))

	// ── Host registration ──
	mux.HandleFunc("POST /internal/hosts/register", internalAuth(cp.registerHost))
	mux.HandleFunc("POST /internal/hosts/heartbeat", internalAuth(cp.heartbeat))

	// ── Health ──
	mux.HandleFunc("GET /health", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, 200, map[string]string{"status": "ok"})
	})

	// Reconciliation loop: detects dead hosts, cascades to machines,
	// converges desired_state toward observed_state.
	// Replaces the old manual health-check goroutine.
	// Uses FOR UPDATE SKIP LOCKED -- safe to run multiple instances.
	{
		instanceID, _ := os.Hostname()
		go reconcile.Loop(context.Background(), reconcile.Config{
			Store:        cp.store,
			Placement:    &placementAdapter{cp: cp},
			InstanceID:   instanceID + "-reconciler",
			BatchSize:    10,
			PollInterval: 5 * time.Second,
			HostTimeout:  45 * time.Second,
		})
	}

	// ── VM ingress proxy (from Cloudflare tunnel) ──
	ingressPort := envOr("INGRESS_PORT", "8080")
	go func() {
		ingressMux := http.NewServeMux()
		ingressMux.HandleFunc("/", cp.proxyVMTraffic)
		log.Printf("Flare VM ingress proxy on :%s", ingressPort)
		if err := http.ListenAndServe(":"+ingressPort, ingressMux); err != nil {
			log.Printf("[ingress] error: %v", err)
		}
	}()

	log.Printf("Flare control plane API on :%s, ingress on :%s", port, ingressPort)
	log.Fatal(http.ListenAndServe(":"+port, mux))
}

// callPlacement sends a request to a placement daemon.
func (cp *ControlPlane) callPlacement(addr, method, path string, body any) (*http.Response, error) {
	var bodyReader io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		bodyReader = bytes.NewReader(b)
	}
	req, err := http.NewRequest(method, fmt.Sprintf("http://%s%s", addr, path), bodyReader)
	if err != nil {
		return nil, err
	}
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if cp.internalKey != "" {
		req.Header.Set("X-Internal-Key", cp.internalKey)
	}
	return cp.client.Do(req)
}

// placementAdapter adapts ControlPlane's callPlacement into the reconcile.PlacementClient interface.
type placementAdapter struct{ cp *ControlPlane }

func (a *placementAdapter) StartVM(ctx context.Context, hostAddr, machineID string) error {
	resp, err := a.cp.callPlacement(hostAddr, "POST", "/vm/"+machineID+"/start", nil)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		body, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("start: HTTP %d: %s", resp.StatusCode, string(body))
	}
	return nil
}

func (a *placementAdapter) StopVM(ctx context.Context, hostAddr, machineID string) error {
	resp, err := a.cp.callPlacement(hostAddr, "POST", "/vm/"+machineID+"/stop", nil)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		body, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("stop: HTTP %d: %s", resp.StatusCode, string(body))
	}
	return nil
}

func (a *placementAdapter) DestroyVM(ctx context.Context, hostAddr, machineID string) error {
	resp, err := a.cp.callPlacement(hostAddr, "DELETE", "/vm/"+machineID, nil)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 && resp.StatusCode != 404 {
		body, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("destroy: HTTP %d: %s", resp.StatusCode, string(body))
	}
	return nil
}

func (a *placementAdapter) GetVMState(ctx context.Context, hostAddr, machineID string) (string, error) {
	resp, err := a.cp.callPlacement(hostAddr, "GET", "/vm/"+machineID+"/state", nil)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	var result struct {
		State string `json:"state"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", fmt.Errorf("decode state response: %w", err)
	}
	return result.State, nil
}

// ── Apps ──

func (cp *ControlPlane) createApp(w http.ResponseWriter, r *http.Request) {
	var req api.CreateAppRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil { writeJSON(w, 400, map[string]string{"error": "invalid JSON: " + err.Error()}); return }
	// FLARE-015: Validate app name: 1-63 chars, lowercase alphanumeric + hyphens, no consecutive hyphens.
	appNameRe := regexp.MustCompile(`^[a-z][a-z0-9-]*$`)
	if len(req.AppName) < 1 || len(req.AppName) > 63 || !appNameRe.MatchString(req.AppName) || strings.Contains(req.AppName, "--") {
		writeJSON(w, 400, map[string]string{"error": "app name must be 1-63 chars, start with a letter, contain only lowercase alphanumeric and hyphens, no consecutive hyphens"})
		return
	}

	app := store.App{ID: newID("app-"), OrgID: "org_ember", Name: req.AppName, Status: "active", CreatedAt: time.Now()}
	if err := cp.store.CreateApp(r.Context(), app); err != nil {
		// FLARE-014: Don't leak internal error details to client
		log.Printf("[createApp] CreateApp failed: %v", err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	writeJSON(w, 201, app)
}

func (cp *ControlPlane) deleteApp(w http.ResponseWriter, r *http.Request) {
	appID := r.PathValue("app")
	// Verify app exists before marking
	if _, err := cp.store.GetApp(r.Context(), appID); err != nil {
		writeJSON(w, 404, map[string]string{"error": "app not found"})
		return
	}
	if err := cp.store.MarkAppDeleting(r.Context(), appID); err != nil {
		// FLARE-014: Don't leak internal error details to client
		log.Printf("[deleteApp] MarkAppDeleting failed for %s: %v", appID, err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	writeJSON(w, 202, map[string]string{"status": "deleting"})
}

// ── Machines (honest lifecycle) ──

func (cp *ControlPlane) createMachine(w http.ResponseWriter, r *http.Request) {
	appID := r.PathValue("app")
	ctx := r.Context()

	// Validate app exists and is active before reserving capacity.
	// Prevents reservation leak on FK failure and blocks resource creation on deleting/deleted apps.
	app, appErr := cp.store.GetApp(ctx, appID)
	if appErr != nil {
		writeJSON(w, 404, map[string]string{"error": "app not found"})
		return
	}
	if app.Status != "active" {
		writeJSON(w, 409, map[string]string{"error": "app is " + app.Status})
		return
	}

	var req api.CreateMachineRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil { writeJSON(w, 400, map[string]string{"error": "invalid JSON: " + err.Error()}); return }

	// Validate config: reject unsupported features loudly instead of silently ignoring.
	if len(req.Config.Mounts) > 0 {
		writeJSON(w, 400, map[string]string{"error": "volumes/mounts not available in v1"})
		return
	}

	cpus := req.Config.Guest.CPUs
	memMB := req.Config.Guest.MemoryMB
	if cpus == 0 {
		cpus = 4
	}
	if memMB == 0 {
		memMB = 8192
	}
	if cpus < 0 || cpus > 256 {
		writeJSON(w, 400, map[string]string{"error": "cpus must be between 1 and 256"})
		return
	}
	if memMB < 0 || memMB > 1048576 {
		writeJSON(w, 400, map[string]string{"error": "memory_mb must be between 1 and 1048576"})
		return
	}
	if req.Config.Image == "" {
		writeJSON(w, 400, map[string]string{"error": "config.image is required"})
		return
	}

	// 1. Reserve host capacity atomically
	host, err := cp.store.PlaceAndReserve(ctx, req.Region, cpus, memMB)
	if err != nil {
		log.Printf("[createMachine] PlaceAndReserve failed: %v", err)
		writeJSON(w, 503, map[string]string{"error": "no capacity available"})
		return
	}

	id := newID("m-")
	hostname := id + ".ember.dev"

	// 2. Insert machine row: desired=stopped, observed=creating
	envJSON, err := json.Marshal(req.Config.Env)
	if err != nil {
		cp.store.ReleaseReservation(ctx, host.ID, cpus, memMB)
		writeJSON(w, 400, map[string]string{"error": "invalid env: " + err.Error()})
		return
	}
	metaJSON, err := json.Marshal(req.Config.Metadata)
	if err != nil {
		cp.store.ReleaseReservation(ctx, host.ID, cpus, memMB)
		writeJSON(w, 400, map[string]string{"error": "invalid metadata: " + err.Error()})
		return
	}
	machine := store.Machine{
		ID: id, AppID: appID, HostID: host.ID, Name: req.Name,
		Region: host.Region, ImageRef: req.Config.Image,
		GuestCPUs: cpus, GuestMemMB: memMB,
		Env: envJSON, Metadata: metaJSON,
		DesiredState: "stopped", ObservedState: "creating",
		GeneratedHostname: hostname, Generation: 1,
		CreatedAt: time.Now(),
	}
	if err := cp.store.CreateMachine(ctx, machine); err != nil {
		cp.store.ReleaseReservation(ctx, host.ID, cpus, memMB)
		// FLARE-014: Don't leak internal error details to client
		log.Printf("[createMachine] CreateMachine failed: %v", err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}

	// 3. Call placement to create VM
	resp, err := cp.callPlacement(host.APIAddr, "POST", "/vm/create", map[string]any{
		"vm_id": id, "image_ref": req.Config.Image,
		"cpus": cpus, "memory_mb": memMB,
		"env": req.Config.Env, "metadata": req.Config.Metadata,
		"hostname": hostname,
	})

	if err != nil {
		// Placement unreachable
		if err2 := cp.store.ReleaseReservation(ctx, host.ID, cpus, memMB); err2 != nil {
			log.Printf("[createMachine] ReleaseReservation failed for host %s: %v", host.ID, err2)
		}
		if err2 := cp.store.UpdateMachineObserved(ctx, id, "failed", "", "placement unreachable: "+err.Error()); err2 != nil {
			log.Printf("[createMachine] UpdateMachineObserved failed for %s: %v", id, err2)
		}
		if err2 := cp.store.RecordEvent(ctx, id, "failed", "placement unreachable"); err2 != nil { log.Printf("[createMachine] RecordEvent failed: %v", err2) }
		writeJSON(w, 502, map[string]string{"error": "placement unreachable"})
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != 201 {
		body, _ := io.ReadAll(resp.Body)
		if err2 := cp.store.ReleaseReservation(ctx, host.ID, cpus, memMB); err2 != nil {
			log.Printf("[createMachine] ReleaseReservation failed for host %s: %v", host.ID, err2)
		}
		if err2 := cp.store.UpdateMachineObserved(ctx, id, "failed", "", string(body)); err2 != nil {
			log.Printf("[createMachine] UpdateMachineObserved failed for %s: %v", id, err2)
		}
		if err2 := cp.store.RecordEvent(ctx, id, "failed", string(body)); err2 != nil { log.Printf("[createMachine] RecordEvent failed: %v", err2) }
		writeJSON(w, 502, map[string]string{"error": "placement create failed"})
		return
	}

	var result struct {
		OK bool   `json:"ok"`
		IP string `json:"ip_address"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		if err2 := cp.store.ReleaseReservation(ctx, host.ID, cpus, memMB); err2 != nil {
			log.Printf("[createMachine] ReleaseReservation failed for host %s: %v", host.ID, err2)
		}
		if err2 := cp.store.UpdateMachineObserved(ctx, id, "failed", "", "decode placement response: "+err.Error()); err2 != nil {
			log.Printf("[createMachine] UpdateMachineObserved failed for %s: %v", id, err2)
		}
		writeJSON(w, 502, map[string]string{"error": "invalid placement response"})
		return
	}

	// 4. Success: update machine with host info.
	// These DB writes are critical -- if they fail the API should report it
	// rather than returning success with stale source-of-truth state.
	// FLARE-010: SetMachineHost must return error on failure (not just log).
	if err := cp.store.SetMachineHost(ctx, id, host.ID, result.IP); err != nil {
		log.Printf("[create] SetMachineHost failed for %s: %v", id, err)
		writeJSON(w, 500, map[string]string{"error": "failed to persist host assignment"})
		return
	}
	// FLARE-010: UpdateMachineObserved failure should be surfaced, not silently swallowed.
	if err := cp.store.UpdateMachineObserved(ctx, id, "created", result.IP, ""); err != nil {
		log.Printf("[create] UpdateMachineObserved failed for %s: %v", id, err)
	}
	if err := cp.store.ReleaseReservation(ctx, host.ID, cpus, memMB); err != nil {
		log.Printf("[create] ReleaseReservation failed for host %s: %v", host.ID, err)
	}
	if err := cp.store.RecordEvent(ctx, id, "created", ""); err != nil { log.Printf("[createMachine] RecordEvent failed: %v", err) }

	// Re-read from DB so response includes all fields (desired/observed state, etc.)
	created, readErr := cp.store.GetMachine(ctx, id)
	if readErr != nil {
		// Fallback: machine was created but we can't read it back
		writeJSON(w, 201, map[string]string{"id": id, "state": "created"})
		return
	}
	writeJSON(w, 201, storeToResponse(created))
}

func (cp *ControlPlane) listMachines(w http.ResponseWriter, r *http.Request) {
	machines, err := cp.store.ListMachines(r.Context(), r.PathValue("app"))
	if err != nil {
		log.Printf("[listMachines] ListMachines failed: %v", err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	var list []api.MachineResponse
	for _, m := range machines {
		list = append(list, storeToResponse(m))
	}
	if list == nil {
		list = []api.MachineResponse{}
	}
	writeJSON(w, 200, list)
}

func (cp *ControlPlane) getMachine(w http.ResponseWriter, r *http.Request) {
	m, err := cp.store.GetMachineScoped(r.Context(), r.PathValue("app"), r.PathValue("id"))
	if err != nil || m.ObservedState == "destroyed" {
		writeJSON(w, 404, map[string]string{"error": "not found"})
		return
	}
	writeJSON(w, 200, storeToResponse(m))
}

func (cp *ControlPlane) startMachine(w http.ResponseWriter, r *http.Request) {
	m, host, err := cp.getMachineAndHost(r)
	if err != nil {
		writeJSON(w, 404, map[string]string{"error": err.Error()})
		return
	}

	// FLARE-005: Atomic capacity check — SELECT host row FOR UPDATE inside a
	// transaction so concurrent starts cannot overcommit.
	if err := cp.store.CheckHostCapacity(r.Context(), host.ID, m.GuestCPUs, m.GuestMemMB); err != nil {
		writeJSON(w, 409, map[string]string{"error": err.Error()})
		return
	}

	// FLARE-004: Call placement BEFORE committing desired_state=running.
	// If placement fails, we never set desired=running so the reconciler
	// won't enter an infinite retry loop.
	resp, err := cp.callPlacement(host.APIAddr, "POST", fmt.Sprintf("/vm/%s/start", m.ID), nil)
	if err != nil {
		if err2 := cp.store.UpdateMachineObserved(r.Context(), m.ID, "failed", "", "placement unreachable on start"); err2 != nil {
			log.Printf("[start] UpdateMachineObserved failed for %s: %v", m.ID, err2)
		}
		if err2 := cp.store.RecordEvent(r.Context(), m.ID, "failed", "placement unreachable on start"); err2 != nil { log.Printf("[start] RecordEvent failed: %v", err2) }
		writeJSON(w, 502, map[string]string{"error": "placement unreachable"})
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		body, _ := io.ReadAll(resp.Body)
		if err2 := cp.store.UpdateMachineObserved(r.Context(), m.ID, "failed", "", string(body)); err2 != nil {
			log.Printf("[start] UpdateMachineObserved failed for %s: %v", m.ID, err2)
		}
		if err2 := cp.store.RecordEvent(r.Context(), m.ID, "failed", "start failed: "+string(body)); err2 != nil { log.Printf("[start] RecordEvent failed: %v", err2) }
		writeJSON(w, 502, map[string]string{"error": "placement error"})
		return
	}

	// Placement succeeded — now commit desired_state=running.
	// FLARE-010: Both writes must succeed; surface failures to the caller.
	if err := cp.store.UpdateMachineDesired(r.Context(), m.ID, "running"); err != nil {
		log.Printf("[start] UpdateMachineDesired failed for %s: %v", m.ID, err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	if err := cp.store.UpdateMachineObserved(r.Context(), m.ID, "running", "", ""); err != nil {
		log.Printf("[start] UpdateMachineObserved failed for %s: %v", m.ID, err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	if err := cp.store.RecordEvent(r.Context(), m.ID, "started", ""); err != nil { log.Printf("[start] RecordEvent failed: %v", err) }
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (cp *ControlPlane) stopMachine(w http.ResponseWriter, r *http.Request) {
	m, host, err := cp.getMachineAndHost(r)
	if err != nil {
		writeJSON(w, 404, map[string]string{"error": err.Error()})
		return
	}

	// FLARE-010: UpdateMachineDesired must succeed before calling placement.
	// If the DB write fails, surface the error rather than continuing with
	// a stale desired_state that prevents the reconciler from converging.
	if err := cp.store.UpdateMachineDesired(r.Context(), m.ID, "stopped"); err != nil {
		log.Printf("[stop] UpdateMachineDesired failed for %s: %v", m.ID, err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	resp, err := cp.callPlacement(host.APIAddr, "POST", fmt.Sprintf("/vm/%s/stop", m.ID), nil)
	if err != nil {
		if err2 := cp.store.UpdateMachineObserved(r.Context(), m.ID, "failed", "", "placement unreachable on stop"); err2 != nil {
			log.Printf("[stop] UpdateMachineObserved failed for %s: %v", m.ID, err2)
		}
		if err2 := cp.store.RecordEvent(r.Context(), m.ID, "failed", "placement unreachable on stop"); err2 != nil { log.Printf("[stop] RecordEvent failed: %v", err2) }
		writeJSON(w, 502, map[string]string{"error": "placement unreachable"})
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		body, _ := io.ReadAll(resp.Body)
		if err2 := cp.store.UpdateMachineObserved(r.Context(), m.ID, "failed", "", string(body)); err2 != nil {
			log.Printf("[stop] UpdateMachineObserved failed for %s: %v", m.ID, err2)
		}
		if err2 := cp.store.RecordEvent(r.Context(), m.ID, "failed", "stop failed: "+string(body)); err2 != nil { log.Printf("[stop] RecordEvent failed: %v", err2) }
		writeJSON(w, 502, map[string]string{"error": "placement error"})
		return
	}

	// FLARE-010: Surface UpdateMachineObserved failure rather than returning 200 with stale state.
	if err := cp.store.UpdateMachineObserved(r.Context(), m.ID, "stopped", "", ""); err != nil {
		log.Printf("[stop] UpdateMachineObserved failed for %s: %v", m.ID, err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	if err := cp.store.RecordEvent(r.Context(), m.ID, "stopped", ""); err != nil { log.Printf("[stop] RecordEvent failed: %v", err) }
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (cp *ControlPlane) destroyMachine(w http.ResponseWriter, r *http.Request) {
	m, host, err := cp.getMachineAndHost(r)
	if err != nil {
		writeJSON(w, 404, map[string]string{"error": err.Error()})
		return
	}

	// FLARE-010: UpdateMachineDesired must succeed; if it fails we should not
	// claim destroy succeeded while the DB still holds a non-destroyed desired_state.
	if err := cp.store.UpdateMachineDesired(r.Context(), m.ID, "destroyed"); err != nil {
		log.Printf("[destroy] UpdateMachineDesired failed for %s: %v", m.ID, err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	resp, pErr := cp.callPlacement(host.APIAddr, "DELETE", fmt.Sprintf("/vm/%s", m.ID), nil)
	if pErr != nil {
		// Can't reach host, mark lost but don't delete DB state
		if err := cp.store.UpdateMachineObserved(r.Context(), m.ID, "lost", "", "placement unreachable on destroy"); err != nil {
			log.Printf("[destroy] UpdateMachineObserved failed for %s: %v", m.ID, err)
		}
		if err2 := cp.store.RecordEvent(r.Context(), m.ID, "lost", "placement unreachable"); err2 != nil { log.Printf("[destroy] RecordEvent failed: %v", err2) }
		writeJSON(w, 502, map[string]string{"error": "placement unreachable, machine marked lost"})
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode == 200 || resp.StatusCode == 404 {
		// 200 = destroyed, 404 = never existed remotely (failed create).
		// Either way, clean up the DB row and hostnames.
		if err := cp.store.DeleteHostnamesByMachine(r.Context(), m.ID); err != nil {
			log.Printf("[destroy] DeleteHostnamesByMachine failed for %s: %v", m.ID, err)
		}
		if err := cp.store.DeleteMachine(r.Context(), m.ID); err != nil {
			log.Printf("[destroy] DeleteMachine failed for %s: %v", m.ID, err)
		}
		if err := cp.store.RecordEvent(r.Context(), m.ID, "destroyed", ""); err != nil { log.Printf("[destroy] RecordEvent failed: %v", err) }
		writeJSON(w, 200, map[string]bool{"ok": true})
	} else {
		body, _ := io.ReadAll(resp.Body)
		if err := cp.store.UpdateMachineObserved(r.Context(), m.ID, "failed", "", string(body)); err != nil {
			log.Printf("[destroy] UpdateMachineObserved failed for %s: %v", m.ID, err)
		}
		writeJSON(w, 502, map[string]string{"error": "placement error"})
	}
}

func (cp *ControlPlane) execMachine(w http.ResponseWriter, r *http.Request) {
	// Exec disabled for v1: SSH-as-product-path is not shippable.
	writeJSON(w, 501, map[string]string{"error": "exec not available in v1"})
}

// ── Hostnames ──

func (cp *ControlPlane) createHostname(w http.ResponseWriter, r *http.Request) {
	appID := r.PathValue("app")

	// Validate app is active before creating hostnames
	app, appErr := cp.store.GetApp(r.Context(), appID)
	if appErr != nil {
		writeJSON(w, 404, map[string]string{"error": "app not found"})
		return
	}
	if app.Status != "active" {
		writeJSON(w, 409, map[string]string{"error": "app is " + app.Status})
		return
	}

	var req api.HostnameRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil { writeJSON(w, 400, map[string]string{"error": "invalid JSON: " + err.Error()}); return }

	// Validate machine belongs to this app and is not destroyed
	if req.VMID != "" {
		m, err := cp.store.GetMachineScoped(r.Context(), appID, req.VMID)
		if err != nil || m.ID == "" {
			writeJSON(w, 404, map[string]string{"error": "machine not found in this app"})
			return
		}
		if m.ObservedState == "destroyed" || m.DesiredState == "destroyed" {
			writeJSON(w, 409, map[string]string{"error": "machine is destroyed"})
			return
		}
	}

	// Normalize hostname: lowercase, strip trailing dot.
	// Ingress normalizes incoming requests the same way, so creation must match.
	normalizedHostname := strings.ToLower(strings.TrimRight(req.Hostname, "."))
	if normalizedHostname == "" {
		writeJSON(w, 400, map[string]string{"error": "hostname required"})
		return
	}
	if len(normalizedHostname) > 253 || !validHostnameRe.MatchString(normalizedHostname) {
		writeJSON(w, 400, map[string]string{"error": "invalid hostname format"})
		return
	}

	hn := store.Hostname{ID: newID("hn-"), AppID: appID, MachineID: req.VMID, Hostname: normalizedHostname}
	if err := cp.store.CreateHostname(r.Context(), hn); err != nil {
		if strings.Contains(err.Error(), "unique") || strings.Contains(err.Error(), "duplicate") {
			writeJSON(w, 409, map[string]string{"error": "hostname already in use"})
			return
		}
		log.Printf("[createHostname] CreateHostname failed: %v", err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	writeJSON(w, 201, hn)
}

func (cp *ControlPlane) deleteHostname(w http.ResponseWriter, r *http.Request) {
	if err := cp.store.DeleteHostname(r.Context(), r.PathValue("app"), r.PathValue("id")); err != nil {
		writeJSON(w, 404, map[string]string{"error": "not found"})
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

// ── Host registration ──

func (cp *ControlPlane) registerHost(w http.ResponseWriter, r *http.Request) {
	var req struct {
		HostID     string `json:"host_id"`
		Zone       string `json:"zone"`
		Address    string `json:"address"`
		CPUs       int    `json:"capacity_cpus"`
		MemoryMB   int    `json:"capacity_memory_mb"`
		UsedCPUs   int    `json:"used_cpus"`
		UsedMemMB  int    `json:"used_memory_mb"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil { writeJSON(w, 400, map[string]string{"error": "invalid JSON: " + err.Error()}); return }

	// FLARE-017: Validate required fields are non-empty
	if req.HostID == "" {
		writeJSON(w, 400, map[string]string{"error": "host_id required"})
		return
	}
	if req.Zone == "" {
		writeJSON(w, 400, map[string]string{"error": "zone required"})
		return
	}
	if req.Address == "" {
		writeJSON(w, 400, map[string]string{"error": "address required"})
		return
	}
	// FLARE-017: Validate address format (host:port)
	addrHost, addrPort, addrErr := net.SplitHostPort(req.Address)
	if addrErr != nil || addrHost == "" || addrPort == "" {
		writeJSON(w, 400, map[string]string{"error": "address must be host:port"})
		return
	}
	if net.ParseIP(addrHost) == nil {
		writeJSON(w, 400, map[string]string{"error": "address host must be a valid IP"})
		return
	}

	region := store.RegionFromZone(req.Zone)
	ingressAddr := strings.Replace(req.Address, ":9090", ":8080", 1)

	host := store.Host{
		ID: req.HostID, Zone: req.Zone, Region: region,
		APIAddr: req.Address, IngressAddr: ingressAddr,
		Status: "ready", CapacityCPUs: req.CPUs, CapacityMemMB: req.MemoryMB,
		UsedCPUs: req.UsedCPUs, UsedMemMB: req.UsedMemMB,
	}
	if err := cp.store.UpsertHost(r.Context(), host); err != nil {
		log.Printf("[registerHost] UpsertHost failed for %s: %v", req.HostID, err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	log.Printf("[register] host %s zone=%s addr=%s cpus=%d mem=%dMB",
		req.HostID, req.Zone, req.Address, req.CPUs, req.MemoryMB)
	writeJSON(w, 200, map[string]bool{"accepted": true})
}

func (cp *ControlPlane) heartbeat(w http.ResponseWriter, r *http.Request) {
	var req struct {
		HostID   string `json:"host_id"`
		UsedCPUs int    `json:"used_cpus"`
		UsedMem  int    `json:"used_memory_mb"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil { writeJSON(w, 400, map[string]string{"error": "invalid JSON: " + err.Error()}); return }
	// FLARE-016: Return HTTP 500 and log when store update fails instead of swallowing errors
	if err := cp.store.Heartbeat(r.Context(), req.HostID, req.UsedCPUs, req.UsedMem); err != nil {
		log.Printf("[heartbeat] store update failed for host %s: %v", req.HostID, err)
		writeJSON(w, 500, map[string]string{"error": "internal error"})
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

// ── VM ingress proxy ──

func (cp *ControlPlane) proxyVMTraffic(w http.ResponseWriter, r *http.Request) {
	// FLARE-002: Require shared-secret authentication on ingress proxy.
	// Without this, anyone who can reach INGRESS_PORT can proxy into VMs.
	apiKey := os.Getenv("FLARE_API_KEY")
	token := r.Header.Get("X-Flare-Token")
	if apiKey == "" || subtle.ConstantTimeCompare([]byte(token), []byte(apiKey)) != 1 {
		writeJSON(w, 401, map[string]string{"error": "Unauthorized"})
		return
	}

	host := r.Host
	if idx := strings.LastIndex(host, ":"); idx > 0 {
		host = host[:idx]
	}
	host = strings.ToLower(strings.TrimRight(host, "."))

	// FLARE-026: Check hostname cache before hitting Postgres.
	var machine store.Machine
	var hostInfo store.Host
	if cached, ok := cp.hostnameCache.Load(host); ok {
		entry := cached.(*hostnameEntry)
		if time.Since(entry.cachedAt) < hostnameCacheTTL {
			machine = entry.machine
			hostInfo = entry.host
		} else {
			cp.hostnameCache.Delete(host) // expired
		}
	}
	if hostInfo.ID == "" {
		var err error
		machine, hostInfo, err = cp.store.ResolveHostname(r.Context(), host)
		if err != nil {
			// FLARE-014: Don't leak internal details in error response
			log.Printf("[ingress] ResolveHostname failed for %s: %v", host, err)
			http.Error(w, "not found", 404)
			return
		}
		cp.hostnameCache.Store(host, &hostnameEntry{
			machine: machine, host: hostInfo, cachedAt: time.Now(),
		})
	}

	// Proxy to host's placement ingress: /_vm/{machineID}
	target, err := url.Parse(fmt.Sprintf("http://%s", hostInfo.IngressAddr))
	if err != nil {
		http.Error(w, "bad host", 500)
		return
	}

	// FLARE-022: Cache ReverseProxy per target host to avoid per-request allocation.
	targetKey := hostInfo.IngressAddr
	cached, ok := cp.proxyCache.Load(targetKey)
	if !ok {
		p := httputil.NewSingleHostReverseProxy(target)
		cached, _ = cp.proxyCache.LoadOrStore(targetKey, p)
	}
	proxy := cached.(*httputil.ReverseProxy)

	// We still need per-request director logic, so wrap the proxy's ServeHTTP
	// by temporarily overriding the request's URL path and Host.
	r2 := r.Clone(r.Context())
	r2.URL.Path = "/_vm/" + machine.ID + r.URL.Path
	r2.URL.Host = target.Host
	r2.URL.Scheme = target.Scheme
	r2.Host = r.Host // preserve original Host header
	proxy.ServeHTTP(w, r2)
}

// ── Helpers ──

func (cp *ControlPlane) getMachineAndHost(r *http.Request) (store.Machine, store.Host, error) {
	m, err := cp.store.GetMachineScoped(r.Context(), r.PathValue("app"), r.PathValue("id"))
	if err != nil {
		return store.Machine{}, store.Host{}, err
	}
	if m.ObservedState == "destroyed" || m.DesiredState == "destroyed" {
		return store.Machine{}, store.Host{}, fmt.Errorf("machine is destroyed")
	}
	var host store.Host
	if m.HostID != "" {
		var err error
		host, err = cp.store.GetHost(r.Context(), m.HostID)
		if err != nil {
			return store.Machine{}, store.Host{}, fmt.Errorf("host not found: %w", err)
		}
	}
	return m, host, nil
}

func storeToResponse(m store.Machine) api.MachineResponse {
	cfg := api.MachineConfig{
		Image: m.ImageRef,
		Guest: api.GuestConfig{CPUs: m.GuestCPUs, MemoryMB: m.GuestMemMB},
	}
	// Restore env/metadata from stored JSON
	if m.Env != nil {
		if err := json.Unmarshal(m.Env, &cfg.Env); err != nil {
			log.Printf("[warn] machine %s: unmarshal env: %v", m.ID, err)
		}
	}
	if m.Metadata != nil {
		if err := json.Unmarshal(m.Metadata, &cfg.Metadata); err != nil {
			log.Printf("[warn] machine %s: unmarshal metadata: %v", m.ID, err)
		}
	}
	return api.MachineResponse{
		ID:                m.ID,
		Name:              m.Name,
		State:             m.ObservedState,
		DesiredState:      m.DesiredState,
		ObservedState:     m.ObservedState,
		Region:            m.Region,
		IPAddress:         m.IPAddress,
		GeneratedHostname: m.GeneratedHostname,
		LastError:         m.LastError,
		Config:        cfg,
		CreatedAt:     m.CreatedAt.Format(time.RFC3339),
		UpdatedAt:     m.UpdatedAt.Format(time.RFC3339),
	}
}

func writeJSON(w http.ResponseWriter, status int, data any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(data)
}

func envOr(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

// runMigrations applies all .sql files from the embedded migrations directory
// that have not yet been applied. Uses a schema_migrations table to track state.
// Each migration runs inside a transaction for atomicity.
func runMigrations(db *sql.DB) error {
	// Ensure the tracking table exists.
	if _, err := db.Exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
		filename TEXT PRIMARY KEY,
		applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
	)`); err != nil {
		return fmt.Errorf("create schema_migrations table: %w", err)
	}

	// Read all .sql files from the embedded migrations directory, sorted by name.
	entries, err := fs.ReadDir(migrationsFS, "migrations")
	if err != nil {
		return fmt.Errorf("read migrations dir: %w", err)
	}
	var filenames []string
	for _, e := range entries {
		if !e.IsDir() && path.Ext(e.Name()) == ".sql" {
			filenames = append(filenames, e.Name())
		}
	}
	sort.Strings(filenames)

	for _, name := range filenames {
		// Check if already applied.
		var exists bool
		if err := db.QueryRow("SELECT EXISTS(SELECT 1 FROM schema_migrations WHERE filename = $1)", name).Scan(&exists); err != nil {
			return fmt.Errorf("check migration %s: %w", name, err)
		}
		if exists {
			continue
		}

		// Read and execute within a transaction.
		content, err := fs.ReadFile(migrationsFS, path.Join("migrations", name))
		if err != nil {
			return fmt.Errorf("read migration %s: %w", name, err)
		}

		tx, err := db.Begin()
		if err != nil {
			return fmt.Errorf("begin tx for %s: %w", name, err)
		}
		if _, err := tx.Exec(string(content)); err != nil {
			tx.Rollback()
			return fmt.Errorf("execute migration %s: %w", name, err)
		}
		if _, err := tx.Exec("INSERT INTO schema_migrations (filename) VALUES ($1)", name); err != nil {
			tx.Rollback()
			return fmt.Errorf("record migration %s: %w", name, err)
		}
		if err := tx.Commit(); err != nil {
			return fmt.Errorf("commit migration %s: %w", name, err)
		}
		log.Printf("[migrations] applied %s", name)
	}
	return nil
}
