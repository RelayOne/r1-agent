-- Flare v1 schema
-- Desired/observed state split for honest lifecycle semantics.

CREATE TABLE IF NOT EXISTS apps (
  id text PRIMARY KEY,
  org_id text NOT NULL DEFAULT 'org_ember',
  name text NOT NULL,
  status text NOT NULL DEFAULT 'active', -- active | deleting | deleted
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(org_id, name)
);

CREATE TABLE IF NOT EXISTS hosts (
  id text PRIMARY KEY,
  zone text NOT NULL,
  region text NOT NULL, -- derived from zone (e.g. us-central1)
  api_addr text NOT NULL, -- placement daemon :9090
  ingress_addr text NOT NULL, -- placement ingress :8080
  status text NOT NULL DEFAULT 'ready', -- ready | draining | dead
  capacity_cpus int NOT NULL,
  capacity_mem_mb int NOT NULL,
  used_cpus int NOT NULL DEFAULT 0,
  used_mem_mb int NOT NULL DEFAULT 0,
  reserved_cpus int NOT NULL DEFAULT 0,
  reserved_mem_mb int NOT NULL DEFAULT 0,
  last_heartbeat timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS machines (
  id text PRIMARY KEY,
  app_id text NOT NULL REFERENCES apps(id),
  host_id text REFERENCES hosts(id),
  name text NOT NULL DEFAULT '',
  region text NOT NULL DEFAULT '',
  image_ref text NOT NULL DEFAULT 'default',
  guest_cpus int NOT NULL DEFAULT 4,
  guest_mem_mb int NOT NULL DEFAULT 8192,
  env jsonb NOT NULL DEFAULT '{}',
  metadata jsonb NOT NULL DEFAULT '{}',

  -- Desired/observed state split
  desired_state text NOT NULL DEFAULT 'stopped', -- stopped | running | destroyed
  observed_state text NOT NULL DEFAULT 'creating', -- creating | created | starting | running | stopping | stopped | failed | lost | destroyed
  ip_address text,
  generated_hostname text NOT NULL,
  last_error text,
  last_observed_at timestamptz,
  generation int NOT NULL DEFAULT 1, -- incremented on reassignment, rejects stale ops

  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS machines_app_idx ON machines(app_id);
CREATE INDEX IF NOT EXISTS machines_host_idx ON machines(host_id);
CREATE INDEX IF NOT EXISTS machines_hostname_idx ON machines(generated_hostname);

CREATE TABLE IF NOT EXISTS hostnames (
  id text PRIMARY KEY,
  app_id text NOT NULL REFERENCES apps(id),
  machine_id text NOT NULL REFERENCES machines(id),
  hostname text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS hostnames_machine_idx ON hostnames(machine_id);

CREATE TABLE IF NOT EXISTS machine_events (
  id bigserial PRIMARY KEY,
  machine_id text NOT NULL REFERENCES machines(id),
  event_type text NOT NULL, -- created, started, stopped, failed, destroyed, lost, reassigned
  details text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS machine_events_machine_idx ON machine_events(machine_id);

-- Idempotency keys for create operations
CREATE TABLE IF NOT EXISTS idempotency_keys (
  key text PRIMARY KEY,
  result_status int NOT NULL,
  result_body jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
