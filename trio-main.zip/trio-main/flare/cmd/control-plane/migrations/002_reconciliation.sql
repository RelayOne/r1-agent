-- Reconciliation support: adds columns for work-stealing, backoff, and fencing.

ALTER TABLE machines ADD COLUMN IF NOT EXISTS reconcile_after timestamptz;
ALTER TABLE machines ADD COLUMN IF NOT EXISTS reconcile_attempts int NOT NULL DEFAULT 0;
ALTER TABLE machines ADD COLUMN IF NOT EXISTS claimed_by text;
ALTER TABLE machines ADD COLUMN IF NOT EXISTS claimed_at timestamptz;
ALTER TABLE machines ADD COLUMN IF NOT EXISTS transition_deadline timestamptz;

-- Partial index: only machines that need reconciliation work.
-- In a fleet of 100K machines where 50 need work, this index has 50 entries.
CREATE INDEX IF NOT EXISTS idx_machines_needs_reconcile
  ON machines (reconcile_after NULLS FIRST, created_at)
  WHERE desired_state != observed_state
    AND desired_state != 'destroyed';

-- Fast lookup for dead-host cascade
CREATE INDEX IF NOT EXISTS idx_machines_host_active
  ON machines (host_id)
  WHERE host_id IS NOT NULL AND desired_state != 'destroyed';
