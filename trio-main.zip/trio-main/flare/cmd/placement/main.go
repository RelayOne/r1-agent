package main

import (
	"bytes"
	"crypto/subtle"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"sync"
	stdpath "path"
	"runtime"
	"strings"
	"time"

	"flare/internal/firecracker"
	"flare/internal/networking"
)

type Daemon struct {
	hostID       string
	zone         string
	address      string
	controlPlane string
	internalKey  string
	fcMgr        *firecracker.Manager
	netMgr       *networking.Manager
	cpuTotal     int
	memTotal     int
	// FLARE-022: Cache reverse proxies per VM target to avoid per-request allocation.
	proxyCache sync.Map // map[string]*httputil.ReverseProxy keyed by vm_ip:port
}

func main() {
	apiPort := envOr("PLACEMENT_PORT", "9090")
	ingressPort := envOr("INGRESS_PORT", "8080")
	controlPlane := requireEnv("FLARE_CONTROL_PLANE")
	hostID := requireEnv("HOST_ID")
	if os.Getenv("FLARE_INTERNAL_KEY") == "" {
		log.Fatal("FLARE_INTERNAL_KEY must be set")
	}
	zone := envOr("HOST_ZONE", "us-central1-a")
	internalKey := envOr("FLARE_INTERNAL_KEY", "")
	selfIP := envOr("HOST_IP", "127.0.0.1")
	address := fmt.Sprintf("%s:%s", selfIP, apiPort)

	bridge := networking.Bridge{Name: "br0", Subnet: "10.0.0.0/24", Gateway: "10.0.0.1"}

	fcMgr, err := firecracker.NewManager(firecracker.ManagerOpts{
		VMDir: envOr("VM_DIR", "/var/lib/flare/vms"),
	})
	if err != nil {
		log.Fatalf("firecracker manager: %v", err)
	}

	d := &Daemon{
		hostID:       hostID,
		zone:         zone,
		address:      address,
		controlPlane: controlPlane,
		internalKey:  internalKey,
		fcMgr:        fcMgr,
		netMgr:   networking.NewManager(bridge),
		cpuTotal: runtime.NumCPU(),
		memTotal: totalMemoryMB(),
	}

	if err := networking.SetupBridge(bridge); err != nil {
		log.Printf("[warn] bridge setup: %v", err)
	}

	// Restore VMs from disk (restart recovery)
	d.recoverVMs()

	if err := d.register(); err != nil {
		log.Fatalf("register: %v", err)
	}
	go d.heartbeatLoop()

	// Internal lifecycle API on :apiPort
	apiMux := http.NewServeMux()
	internalAuth := func(next http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			if subtle.ConstantTimeCompare([]byte(r.Header.Get("X-Internal-Key")), []byte(d.internalKey)) != 1 {
				http.Error(w, "Unauthorized", 401)
				return
			}
			next(w, r)
		}
	}
	apiMux.HandleFunc("POST /vm/create", internalAuth(d.handleCreate))
	apiMux.HandleFunc("POST /vm/{id}/start", internalAuth(d.handleStart))
	apiMux.HandleFunc("POST /vm/{id}/stop", internalAuth(d.handleStop))
	apiMux.HandleFunc("DELETE /vm/{id}", internalAuth(d.handleDestroy))
	apiMux.HandleFunc("GET /vm/{id}/state", internalAuth(d.handleState))
	apiMux.HandleFunc("GET /health", d.handleHealth)
	apiMux.HandleFunc("GET /vms", internalAuth(d.handleListVMs))

	// VM ingress proxy on :ingressPort
	// Replaces nginx entirely. Routes /_vm/{machineID}/* to vm_ip:8080/*
	ingressMux := http.NewServeMux()
	ingressMux.HandleFunc("/", d.handleIngress)

	go func() {
		log.Printf("Placement ingress proxy on :%s", ingressPort)
		if err := http.ListenAndServe(":"+ingressPort, ingressMux); err != nil {
			log.Fatalf("ingress: %v", err)
		}
	}()

	log.Printf("Placement API on :%s, ingress on :%s (host=%s, cpus=%d, mem=%dMB)",
		apiPort, ingressPort, hostID, d.cpuTotal, d.memTotal)
	log.Fatal(http.ListenAndServe(":"+apiPort, apiMux))
}

// handleIngress routes /_vm/{machineID}/* to the VM's TAP IP on port 8080.
// This replaces nginx. The control plane sends traffic here after resolving
// hostname -> machine -> host.
func (d *Daemon) handleIngress(w http.ResponseWriter, r *http.Request) {
	path := r.URL.Path
	if !strings.HasPrefix(path, "/_vm/") {
		http.Error(w, "invalid path", 400)
		return
	}
	// Parse /_vm/{machineID}/rest/of/path
	rest := strings.TrimPrefix(path, "/_vm/")
	slash := strings.IndexByte(rest, '/')
	var vmID, remainder string
	if slash >= 0 {
		vmID = rest[:slash]
		remainder = rest[slash:]
	} else {
		vmID = rest
		remainder = "/"
	}

	// FLARE-020: Sanitize path to prevent path traversal
	remainder = stdpath.Clean(remainder)
	if strings.Contains(remainder, "..") {
		http.Error(w, "invalid path", 400)
		return
	}

	vm, ok := d.fcMgr.Get(vmID)
	if !ok {
		http.Error(w, "VM not found", 404)
		return
	}
	state := d.fcMgr.State(vmID)
	if state != "running" {
		http.Error(w, "VM not running", 503)
		return
	}

	// FLARE-022: Cache ReverseProxy per VM target to avoid per-request allocation.
	targetKey := vm.IPAddress + ":8080"
	cached, ok := d.proxyCache.Load(targetKey)
	if !ok {
		target, _ := url.Parse(fmt.Sprintf("http://%s", targetKey))
		p := httputil.NewSingleHostReverseProxy(target)
		cached, _ = d.proxyCache.LoadOrStore(targetKey, p)
		_ = target // suppress unused if LoadOrStore returns existing
	}
	proxy := cached.(*httputil.ReverseProxy)

	// Clone the request to set per-request path without mutating the shared proxy Director.
	r2 := r.Clone(r.Context())
	r2.URL.Path = remainder
	r2.URL.Host = targetKey
	r2.URL.Scheme = "http"
	r2.Host = r.Host // preserve original Host header for the guest
	proxy.ServeHTTP(w, r2)
}

// recoverVMs restores VM state from disk after daemon restart.
func (d *Daemon) recoverVMs() {
	recovered := d.fcMgr.RecoverFromDisk()
	if recovered == 0 {
		return
	}
	log.Printf("[recover] restored %d VMs from disk", recovered)

	// Recover network state from vm.json data so TAP/IP allocations don't collide.
	for _, vm := range d.fcMgr.List() {
		if vm.TAPDevice != "" && vm.IPAddress != "" {
			mac := vm.MACAddress
			if mac == "" {
				mac = firecracker.GenerateMAC(vm.IPAddress)
			}
			d.netMgr.RecoverDevice(vm.ID, vm.TAPDevice, vm.IPAddress, mac)
		}
	}
	log.Printf("[recover] network state rebuilt for %d VMs", recovered)
}

func (d *Daemon) register() error {
	// Include current usage so the control plane doesn't see this host as
	// empty during the window between register and first heartbeat.
	cpus, mem := d.fcMgr.ResourceUsage()
	body, _ := json.Marshal(map[string]any{
		"host_id": d.hostID, "zone": d.zone, "address": d.address,
		"capacity_cpus": d.cpuTotal, "capacity_memory_mb": d.memTotal,
		"used_cpus": cpus, "used_memory_mb": mem,
	})
	req, err := http.NewRequest("POST", d.controlPlane+"/internal/hosts/register", bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	if d.internalKey != "" {
		req.Header.Set("X-Internal-Key", d.internalKey)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return fmt.Errorf("register: HTTP %d", resp.StatusCode)
	}
	log.Printf("[register] registered at %s", d.controlPlane)
	return nil
}

func (d *Daemon) heartbeatLoop() {
	ticker := time.NewTicker(15 * time.Second)
	defer ticker.Stop()
	// FLARE-025: Track consecutive failures and attempt re-registration after 5.
	consecutiveFailures := 0
	const maxConsecutiveFailures = 5
	for range ticker.C {
		cpus, mem := d.fcMgr.ResourceUsage()
		body, _ := json.Marshal(map[string]any{
			"host_id": d.hostID, "used_cpus": cpus, "used_memory_mb": mem,
		})
		req, err := http.NewRequest("POST", d.controlPlane+"/internal/hosts/heartbeat", bytes.NewReader(body))
		if err != nil {
			consecutiveFailures++
			if consecutiveFailures >= maxConsecutiveFailures {
				log.Printf("[heartbeat] %d consecutive failures, attempting re-registration", consecutiveFailures)
				if regErr := d.register(); regErr != nil {
					log.Printf("[heartbeat] re-registration failed: %v", regErr)
				} else {
					log.Printf("[heartbeat] re-registration succeeded")
					consecutiveFailures = 0
				}
			}
			continue
		}
		req.Header.Set("Content-Type", "application/json")
		if d.internalKey != "" {
			req.Header.Set("X-Internal-Key", d.internalKey)
		}
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			consecutiveFailures++
			log.Printf("[heartbeat] error: %v (failures: %d/%d)", err, consecutiveFailures, maxConsecutiveFailures)
			if consecutiveFailures >= maxConsecutiveFailures {
				log.Printf("[heartbeat] %d consecutive failures, attempting re-registration", consecutiveFailures)
				if regErr := d.register(); regErr != nil {
					log.Printf("[heartbeat] re-registration failed: %v", regErr)
				} else {
					log.Printf("[heartbeat] re-registration succeeded")
					consecutiveFailures = 0
				}
			}
			continue
		}
		resp.Body.Close()
		if resp.StatusCode == 200 {
			consecutiveFailures = 0
		} else {
			consecutiveFailures++
			log.Printf("[heartbeat] unexpected status %d (failures: %d/%d)", resp.StatusCode, consecutiveFailures, maxConsecutiveFailures)
			if consecutiveFailures >= maxConsecutiveFailures {
				log.Printf("[heartbeat] %d consecutive failures, attempting re-registration", consecutiveFailures)
				if regErr := d.register(); regErr != nil {
					log.Printf("[heartbeat] re-registration failed: %v", regErr)
				} else {
					log.Printf("[heartbeat] re-registration succeeded")
					consecutiveFailures = 0
				}
			}
		}
	}
}

func (d *Daemon) handleCreate(w http.ResponseWriter, r *http.Request) {
	var req struct {
		VMID     string            `json:"vm_id"`
		ImageRef string            `json:"image_ref"`
		CPUs     int               `json:"cpus"`
		MemoryMB int               `json:"memory_mb"`
		Env      map[string]string `json:"env"`
		Metadata map[string]string `json:"metadata"`
		Hostname string            `json:"hostname"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, map[string]string{"error": "invalid json"})
		return
	}

	tap, err := d.netMgr.Allocate(req.VMID)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": "network: " + err.Error()})
		return
	}

	vm, err := d.fcMgr.Create(r.Context(), firecracker.CreateOpts{
		ID: req.VMID, ImageRef: req.ImageRef,
		CPUs: req.CPUs, MemoryMB: req.MemoryMB,
		Env: req.Env, Metadata: req.Metadata,
		TAP: tap.Name, IP: tap.IPAddress,
		MAC: tap.MACAddress, Gateway: "10.0.0.1",
	})
	if err != nil {
		d.netMgr.Release(req.VMID)
		writeJSON(w, 500, map[string]string{"error": "create: " + err.Error()})
		return
	}

	writeJSON(w, 201, map[string]any{"ok": true, "ip_address": vm.IPAddress})
}

func (d *Daemon) handleStart(w http.ResponseWriter, r *http.Request) {
	vm, ok := d.fcMgr.Get(r.PathValue("id"))
	if !ok {
		writeJSON(w, 404, map[string]string{"error": "vm not found"})
		return
	}
	if err := d.fcMgr.Start(r.Context(), vm); err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (d *Daemon) handleStop(w http.ResponseWriter, r *http.Request) {
	vm, ok := d.fcMgr.Get(r.PathValue("id"))
	if !ok {
		writeJSON(w, 404, map[string]string{"error": "vm not found"})
		return
	}
	if err := d.fcMgr.Stop(r.Context(), vm); err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (d *Daemon) handleDestroy(w http.ResponseWriter, r *http.Request) {
	vmID := r.PathValue("id")
	vm, ok := d.fcMgr.Get(vmID)
	if !ok {
		writeJSON(w, 404, map[string]string{"error": "vm not found"})
		return
	}
	if err := d.fcMgr.Destroy(r.Context(), vm); err != nil {
		writeJSON(w, 500, map[string]string{"error": "destroy failed: " + err.Error()})
		return
	}
	d.netMgr.Release(vmID)
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (d *Daemon) handleState(w http.ResponseWriter, r *http.Request) {
	vmID := r.PathValue("id")
	state := d.fcMgr.State(vmID)
	vm, ok := d.fcMgr.Get(vmID)
	resp := map[string]any{"state": state}
	if ok {
		snap := vm.Snapshot()
		resp["pid"] = snap.PID
		resp["ip_address"] = snap.IPAddress
		if !snap.StartedAt.IsZero() {
			resp["uptime_seconds"] = int(time.Since(snap.StartedAt).Seconds())
		}
	}
	writeJSON(w, 200, resp)
}

func (d *Daemon) handleHealth(w http.ResponseWriter, r *http.Request) {
	// FLARE-006: Only return status for unauthenticated requests.
	// Full host details (host_id, CPU, memory, VM count) require internal auth
	// to prevent information disclosure to unauthenticated callers.
	if subtle.ConstantTimeCompare([]byte(r.Header.Get("X-Internal-Key")), []byte(d.internalKey)) != 1 {
		writeJSON(w, 200, map[string]string{"status": "ok"})
		return
	}
	cpus, mem := d.fcMgr.ResourceUsage()
	writeJSON(w, 200, map[string]any{
		"status": "ok", "host_id": d.hostID,
		"cpu_used": cpus, "cpu_total": d.cpuTotal,
		"mem_used": mem, "mem_total": d.memTotal,
		"vms": len(d.fcMgr.List()),
	})
}

func (d *Daemon) handleListVMs(w http.ResponseWriter, r *http.Request) {
	vms := d.fcMgr.List()
	type vi struct {
		ID    string `json:"id"`
		State string `json:"state"`
		IP    string `json:"ip_address"`
		CPUs  int    `json:"cpus"`
		Mem   int    `json:"memory_mb"`
	}
	list := make([]vi, 0, len(vms))
	for _, vm := range vms {
		list = append(list, vi{ID: vm.ID, State: d.fcMgr.State(vm.ID), IP: vm.IPAddress, CPUs: vm.CPUs, Mem: vm.MemoryMB})
	}
	writeJSON(w, 200, list)
}

func writeJSON(w http.ResponseWriter, status int, data any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(data)
}

func totalMemoryMB() int {
	data, _ := os.ReadFile("/proc/meminfo")
	for _, line := range bytes.Split(data, []byte("\n")) {
		if bytes.HasPrefix(line, []byte("MemTotal:")) {
			fields := bytes.Fields(line)
			if len(fields) >= 2 {
				kb := 0
				fmt.Sscan(string(fields[1]), &kb)
				return kb / 1024
			}
		}
	}
	return 32768
}

func envOr(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func requireEnv(key string) string {
	v := os.Getenv(key)
	if v == "" {
		log.Fatalf("%s is required", key)
	}
	return v
}
