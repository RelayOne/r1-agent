# Flare GCP Infrastructure
# MIG + Filestore + networking for Firecracker microVM hosting
#
# INGRESS MODEL: Cloudflare tunnel terminates at the control plane (not hosts).
# The control plane reverse-proxies VM traffic to the correct placement daemon
# based on its machine→host mapping. Hosts have no inbound exposure.
#
# This avoids the shared-tunnel-replica problem where Cloudflare routes to a
# random host that may not own the target VM's nginx route.

variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
  default     = "us-central1"
}

variable "zones" {
  description = "GCP zones for MIG"
  type        = list(string)
  default     = ["us-central1-a", "us-central1-b", "us-central1-c"]
}

variable "machine_type" {
  description = "GCE machine type for hosts (must support nested virt: N1 or N2)"
  type        = string
  default     = "n2-standard-32"
}

variable "min_hosts" {
  description = "Minimum number of hosts in MIG"
  type        = number
  default     = 2
}

variable "max_hosts" {
  description = "Maximum number of hosts in MIG"
  type        = number
  default     = 10
}

variable "control_plane_url" {
  description = "Flare control plane internal URL (e.g. http://10.128.0.10:8090)"
  type        = string
}

variable "internal_key" {
  description = "Shared secret for internal auth between control plane and hosts"
  type        = string
  sensitive   = true
}

variable "artifact_bucket" {
  description = "GCS bucket containing placement-daemon, vmlinux, rootfs.ext4"
  type        = string
  default     = "flare-artifacts"
}

variable "network" {
  description = "VPC network name"
  type        = string
  default     = "default"
}

# ── Baked Host Image ──────────────────────────────────────
# Packer builds images into the "firecracker-host" family.
# This always resolves to the latest build.
# Build with: cd packer && packer build -var project_id=$PROJECT .
data "google_compute_image" "flare_host" {
  family  = "firecracker-host"
  project = var.project_id
}

# ── Cloud NAT (outbound internet for private instances) ───
# Hosts have no external IPs. Cloud NAT provides outbound
# for control-plane registration, heartbeats, and package updates.
resource "google_compute_router" "flare_router" {
  name    = "flare-router"
  region  = var.region
  network = var.network
  bgp { asn = 64514 }
}

resource "google_compute_router_nat" "flare_nat" {
  name   = "flare-nat"
  router = google_compute_router.flare_router.name
  region = google_compute_router.flare_router.region

  nat_ip_allocate_option             = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"

  log_config {
    enable = true
    filter = "ERRORS_ONLY"
  }
}

# ── Instance Template ──────────────────────────────────────

resource "google_compute_instance_template" "flare_host" {
  name_prefix  = "flare-host-"
  machine_type = var.machine_type

  # CRITICAL: Firecracker requires nested virtualization.
  # This is the correct Terraform field -- metadata keys do NOT enable it.
  # Requires N1 or N2 machine types with Intel VT-x.
  advanced_machine_features {
    enable_nested_virtualization = true
  }

  disk {
    source_image = data.google_compute_image.flare_host.self_link
    auto_delete  = true
    boot         = true
    disk_size_gb = 200
    disk_type    = "pd-ssd"
  }

  network_interface {
    network = var.network
    # No external IP -- all ingress through Cloudflare tunnel to control plane.
    # Hosts only need outbound (GCS artifacts, control plane registration).
  }

  metadata = {
    # Runtime config read by startup.sh via GCE metadata API
    "flare-control-plane"   = var.control_plane_url
    "flare-internal-key"    = var.internal_key
    "flare-artifact-bucket" = var.artifact_bucket
    "flare-filestore-ip"    = google_filestore_instance.flare_volumes.networks[0].ip_addresses[0]
  }

  metadata_startup_script = file("${path.module}/startup.sh")

  scheduling {
    automatic_restart   = true
    on_host_maintenance = "TERMINATE"  # Required when nested virt is enabled
  }

  service_account {
    scopes = ["cloud-platform"]
  }

  tags = ["flare-host"]

  lifecycle {
    create_before_destroy = true
  }
}

# ── Managed Instance Group ─────────────────────────────────

resource "google_compute_region_instance_group_manager" "flare_mig" {
  name               = "flare-hosts"
  region             = var.region
  base_instance_name = "flare"
  target_size        = var.min_hosts

  version {
    instance_template = google_compute_instance_template.flare_host.id
  }

  auto_healing_policies {
    health_check      = google_compute_health_check.flare_host.id
    initial_delay_sec = 120
  }

  distribution_policy_zones = var.zones

  update_policy {
    type                  = "PROACTIVE"
    minimal_action        = "REPLACE"
    max_surge_fixed       = 1
    max_unavailable_fixed = 0
    replacement_method    = "SUBSTITUTE"
  }
}

# ── Health Check ───────────────────────────────────────────

resource "google_compute_health_check" "flare_host" {
  name                = "flare-host-health"
  check_interval_sec  = 10
  timeout_sec         = 5
  healthy_threshold   = 2
  unhealthy_threshold = 3

  http_health_check {
    port         = 9090
    request_path = "/health"
  }
}

# ── Firewall: allow Google health check probes ─────────────
# GCE health check probes come from these IP ranges.
# Without this rule, probes are blocked and MIG marks all instances unhealthy.

resource "google_compute_firewall" "flare_health_check" {
  name    = "flare-allow-health-check"
  network = var.network

  allow {
    protocol = "tcp"
    ports    = ["9090"]
  }

  # Google health check probe source ranges (required)
  source_ranges = [
    "130.211.0.0/22",
    "35.191.0.0/16",
  ]

  target_tags = ["flare-host"]
}

# ── Firewall: allow control plane to reach placement daemons ─

resource "google_compute_firewall" "flare_internal" {
  name    = "flare-allow-internal"
  network = var.network

  allow {
    protocol = "tcp"
    ports    = ["9090", "8080"]
  }
  source_ranges = ["10.128.0.0/9"]
  target_tags   = ["flare-host"]
}

# ── Autoscaler ─────────────────────────────────────────────

resource "google_compute_region_autoscaler" "flare_autoscaler" {
  name   = "flare-autoscaler"
  region = var.region
  target = google_compute_region_instance_group_manager.flare_mig.id

  autoscaling_policy {
    min_replicas    = var.min_hosts
    max_replicas    = var.max_hosts
    cooldown_period = 120

    cpu_utilization {
      target = 0.7
    }
  }
}

# ── Filestore (shared NFS for VM volumes) ──────────────────

resource "google_filestore_instance" "flare_volumes" {
  name     = "flare-volumes"
  location = "${var.region}-a"
  tier     = "BASIC_HDD"

  file_shares {
    name        = "ember_volumes"
    capacity_gb = 1024
  }

  networks {
    network = var.network
    modes   = ["MODE_IPV4"]
  }
}

# ── Outputs ────────────────────────────────────────────────

output "mig_name" {
  value = google_compute_region_instance_group_manager.flare_mig.name
}

output "filestore_ip" {
  value = google_filestore_instance.flare_volumes.networks[0].ip_addresses[0]
}
