#!/bin/bash
# Flare MIG host startup script.
#
# IMPORTANT: This script assumes a pre-baked host image containing:
#   - /usr/local/bin/firecracker
#   - /usr/local/bin/placement-daemon
#   - /var/lib/flare/vmlinux
#   - /var/lib/flare/rootfs.ext4
#   - Bridge/iptables tooling
#   - systemd service for placement (optional)
#
# To build the host image, use Packer or a similar tool. See docs/host-image.md.
#
# This script only does three things:
#   1. Read runtime config from GCE metadata
#   2. Mount Filestore
#   3. Start placement daemon
set -euo pipefail

META="http://metadata.google.internal/computeMetadata/v1"
MHDR="Metadata-Flavor: Google"

# ── 1. Read runtime config from GCE metadata ──────────────────
FLARE_CONTROL_PLANE=$(curl -sf -H "$MHDR" "$META/instance/attributes/flare-control-plane")
FLARE_INTERNAL_KEY=$(curl -sf -H "$MHDR" "$META/instance/attributes/flare-internal-key" || echo "")
FILESTORE_IP=$(curl -sf -H "$MHDR" "$META/instance/attributes/flare-filestore-ip" || echo "")

HOST_ID=$(curl -sf -H "$MHDR" "$META/instance/id" || echo "unknown")
HOST_ZONE=$(curl -sf -H "$MHDR" "$META/instance/zone" | awk -F/ '{print $NF}' || echo "unknown")
HOST_IP=$(curl -sf -H "$MHDR" "$META/instance/network-interfaces/0/ip" || echo "127.0.0.1")

if [ -z "$FLARE_CONTROL_PLANE" ]; then
  echo "[flare] FATAL: flare-control-plane metadata not set"
  exit 1
fi

echo "[flare] Host: ${HOST_ID} Zone: ${HOST_ZONE} IP: ${HOST_IP}"

# ── 2. Setup bridge networking ─────────────────────────────────
ip link add br0 type bridge 2>/dev/null || echo "[flare] bridge br0 already exists"
ip addr add 10.0.0.1/24 dev br0 2>/dev/null || echo "[flare] br0 address already set"
ip link set br0 up
sysctl -w net.ipv4.ip_forward=1 > /dev/null
iptables -t nat -C POSTROUTING -s 10.0.0.0/24 -j MASQUERADE 2>/dev/null || \
  iptables -t nat -A POSTROUTING -s 10.0.0.0/24 -j MASQUERADE

# ── 3. Mount Filestore ────────────────────────────────────────
if [ -n "$FILESTORE_IP" ]; then
  mkdir -p /mnt/volumes
  if ! mount -t nfs "${FILESTORE_IP}:/ember_volumes" /mnt/volumes; then
    echo "[flare] WARNING: NFS mount failed for ${FILESTORE_IP}:/ember_volumes"
  fi
fi

# ── 4. Start placement daemon ─────────────────────────────────
export FLARE_CONTROL_PLANE HOST_ID HOST_ZONE HOST_IP FLARE_INTERNAL_KEY
export PLACEMENT_PORT="9090"
export INGRESS_PORT="8080"
export VOLUME_ROOT="/mnt/volumes"
export VM_DIR="/var/lib/flare/vms"

exec /usr/local/bin/placement-daemon
