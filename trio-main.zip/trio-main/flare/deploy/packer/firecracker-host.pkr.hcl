packer {
  required_plugins {
    googlecompute = {
      source  = "github.com/hashicorp/googlecompute"
      version = "~> 1.2"
    }
  }
}

variable "project_id" { type = string }
variable "zone"       { type = string; default = "us-central1-a" }
variable "fc_version" { type = string; default = "1.15.0" }

source "googlecompute" "firecracker_host" {
  project_id              = var.project_id
  source_image_family     = "ubuntu-2204-lts"
  source_image_project_id = ["ubuntu-os-cloud"]
  zone                    = var.zone
  machine_type            = "n1-standard-4"
  disk_size               = 50
  disk_type               = "pd-ssd"
  ssh_username            = "ubuntu"

  image_name        = "firecracker-host-{{timestamp}}"
  image_family      = "firecracker-host"
  image_description = "Flare: Firecracker host with placement daemon, kernel, rootfs"

  enable_nested_virtualization = true
  tags = ["packer-build"]
}

build {
  sources = ["source.googlecompute.firecracker_host"]

  # Install Firecracker
  provisioner "shell" {
    environment_vars = ["FC_VERSION=${var.fc_version}"]
    inline = [
      "set -euo pipefail",
      "ARCH=$(uname -m)",
      "curl -fSL https://github.com/firecracker-microvm/firecracker/releases/download/v$${FC_VERSION}/firecracker-v$${FC_VERSION}-$${ARCH}.tgz | tar -xz",
      "sudo install -o root -g root -m 0755 release-v$${FC_VERSION}-$${ARCH}/firecracker-v$${FC_VERSION}-$${ARCH} /usr/local/bin/firecracker",
      "sudo install -o root -g root -m 0755 release-v$${FC_VERSION}-$${ARCH}/jailer-v$${FC_VERSION}-$${ARCH} /usr/local/bin/jailer",
      "rm -rf release-v$${FC_VERSION}-$${ARCH}",
      "firecracker --version",
    ]
  }

  # KVM + networking
  provisioner "shell" {
    inline = [
      "set -euo pipefail",
      "sudo groupadd -r kvm 2>/dev/null || true",
      "echo 'KERNEL==\"kvm\", GROUP=\"kvm\", MODE=\"0660\", OPTIONS+=\"static_node=kvm\"' | sudo tee /etc/udev/rules.d/99-kvm.rules",
      "sudo udevadm control --reload-rules && sudo udevadm trigger",
      "sudo usermod -aG kvm ubuntu",
      "echo kvm       | sudo tee    /etc/modules-load.d/kvm.conf",
      "echo kvm_intel | sudo tee -a /etc/modules-load.d/kvm.conf",
      "echo 'net.ipv4.ip_forward = 1' | sudo tee /etc/sysctl.d/99-ip-forward.conf",
      "sudo sysctl -p /etc/sysctl.d/99-ip-forward.conf",
    ]
  }

  # Guest kernel + rootfs at the paths startup.sh and the manager expect
  provisioner "shell" {
    inline = [
      "set -euo pipefail",
      "sudo mkdir -p /var/lib/flare/vms",
      "ARCH=$(uname -m)",
      "echo '>>> Fetching quickstart kernel and rootfs'",
      "sudo curl -fSL -o /var/lib/flare/vmlinux https://s3.amazonaws.com/spec.ccfc.min/img/quickstart_guide/$${ARCH}/kernels/vmlinux.bin",
      "sudo curl -fSL -o /var/lib/flare/rootfs.ext4 https://s3.amazonaws.com/spec.ccfc.min/img/hello/fsfiles/hello-rootfs.ext4",
      "ls -lh /var/lib/flare/",
    ]
  }

  # Install flare-init into the guest rootfs so MMDS env/metadata delivery works.
  # Mount the ext4 image, copy the script in, install jq + curl inside the guest.
  provisioner "shell" {
    inline = [
      "set -euo pipefail",
      "ROOTFS=/var/lib/flare/rootfs.ext4",
      "# Grow rootfs to have room for additional packages",
      "sudo truncate -s 500M $ROOTFS",
      "sudo e2fsck -fp $ROOTFS || true",
      "sudo resize2fs $ROOTFS",
      "# Mount and install flare-init + deps",
      "MNT=$(mktemp -d)",
      "sudo mount -o loop $ROOTFS $MNT",
      "sudo install -o root -g root -m 0755 /tmp/flare-src/guest/flare-init.sh $MNT/usr/local/bin/flare-init",
      "# Install jq and curl inside the guest rootfs (needed by flare-init)",
      "if [ -f $MNT/etc/alpine-release ]; then",
      "  sudo chroot $MNT apk add --no-cache jq curl 2>/dev/null || echo 'apk install skipped (offline)'",
      "elif [ -f $MNT/etc/debian_version ]; then",
      "  sudo chroot $MNT apt-get update -qq && sudo chroot $MNT apt-get install -y -qq jq curl 2>/dev/null || echo 'apt install skipped (offline)'",
      "fi",
      "sudo mkdir -p $MNT/run/flare",
      "sudo umount $MNT",
      "rmdir $MNT",
      "echo '>>> flare-init installed into guest rootfs'",
    ]
  }

  # Runtime deps (nfs-common required for Filestore mount in startup.sh)
  provisioner "shell" {
    inline = [
      "set -euo pipefail",
      "sudo apt-get update -qq",
      "sudo apt-get install -y -qq jq iproute2 iptables nftables curl nfs-common",
      "sudo apt-get clean && sudo rm -rf /var/lib/apt/lists/*",
    ]
  }

  # Install Go and build placement daemon from source
  provisioner "shell" {
    inline = [
      "set -euo pipefail",
      "GO_VERSION=1.23.4",
      "curl -fsSL https://go.dev/dl/go$${GO_VERSION}.linux-amd64.tar.gz | sudo tar -C /usr/local -xzf -",
      "export PATH=$PATH:/usr/local/go/bin",
      "go version",
    ]
  }

  # Copy source and build
  provisioner "file" {
    source      = "../../"
    destination = "/tmp/flare-src"
  }

  provisioner "shell" {
    inline = [
      "set -euo pipefail",
      "export PATH=$PATH:/usr/local/go/bin",
      "cd /tmp/flare-src",
      "CGO_ENABLED=0 go build -o /tmp/placement-daemon ./cmd/placement",
      "sudo install -o root -g root -m 0755 /tmp/placement-daemon /usr/local/bin/placement-daemon",
      "placement-daemon --version 2>/dev/null || echo 'Placement daemon installed'",
      "# Clean up build artifacts",
      "sudo rm -rf /tmp/flare-src /tmp/placement-daemon /usr/local/go /root/go",
      "echo 'Kernel: /var/lib/flare/vmlinux'",
      "echo 'Rootfs: /var/lib/flare/rootfs.ext4'",
      "echo 'VMs:    /var/lib/flare/vms/'",
      "echo 'Placement: /usr/local/bin/placement-daemon'",
    ]
  }
}
