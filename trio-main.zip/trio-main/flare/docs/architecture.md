# Flare Architecture

## Design Principles

1. **Postgres is the source of truth.** No in-memory maps for durable state.
2. **Desired/observed state split.** API callers express intent; placement reports reality.
3. **Honest lifecycle.** If placement fails, the API returns an error. No silent 201s.
4. **Ingress is a control-plane concern.** Hosts serve traffic but don't decide routing.
5. **Hosts are cattle.** Placement daemons persist local VM metadata and recover on restart.

## Ingress

```
Client (HTTPS)
    |
Cloudflare Tunnel
    |
Control Plane :8080 (ingress proxy)
    |
    +-- normalize hostname (lowercase, strip port/trailing dot)
    +-- query Postgres: generated_hostname OR custom hostname
    +-- join machines + hosts to get host ingress_addr
    +-- reverse proxy to http://<host_ingress_addr>/_vm/<machineID>/...
    |
Host Placement :8080 (ingress proxy)
    |
    +-- parse /_vm/{machineID}/rest/of/path
    +-- load VM from in-memory map (recovered from disk on restart)
    +-- check VM is running
    +-- reverse proxy to http://<vm_tap_ip>:8080/rest/of/path
    |
Guest VM :8080 (application)
```

No nginx. No per-host route files. No cloudflared on hosts.

Custom hostnames work because `ResolveHostname()` queries both
`machines.generated_hostname` and `hostnames.hostname` in one query.

## State Model

### Machines

```
desired_state:  stopped | running | destroyed     (set by API caller)
observed_state: creating | created | starting |   (set by control plane
                running | stopping | stopped |     from placement responses)
                failed | lost | destroyed
```

The control plane updates `observed_state` only when placement confirms
the operation succeeded. On placement failure, the machine keeps its
previous `observed_state` and gets a `last_error`.

### Hosts

```
status:     ready | draining | dead
capacity:   capacity_cpus, capacity_mem_mb        (set at registration)
usage:      used_cpus, used_mem_mb                (updated by heartbeat)
reserved:   reserved_cpus, reserved_mem_mb        (set by PlaceAndReserve)
```

Available capacity = capacity - used - reserved.

### Scheduling

`PlaceAndReserve()` runs inside a transaction:

```sql
SELECT ... FROM hosts
WHERE status = 'ready'
  AND region = $requested_region
  AND (capacity_cpus - used_cpus - reserved_cpus) >= $requested_cpus
  AND (capacity_mem_mb - used_mem_mb - reserved_mem_mb) >= $requested_mem
ORDER BY (capacity_cpus - used_cpus - reserved_cpus) ASC
LIMIT 1
FOR UPDATE SKIP LOCKED
```

This prevents overbooking under concurrent creates. `SKIP LOCKED` avoids
contention between parallel create requests targeting the same host.

Reservations are released on create failure. Heartbeats convert
reservations into `used_*` usage.

## Host Boot Sequence

Assumes pre-baked host image with Firecracker, placement daemon, kernel,
and rootfs already installed.

```
1. MIG creates GCE instance                 ~60s
2. Startup script runs                       ~5s
   - Read runtime config from GCE metadata
   - Setup bridge networking (br0, iptables)
   - Mount Filestore NFS
   - Start placement daemon
3. Placement daemon starts                   ~1s
   - RecoverFromDisk (scan VM_DIR, check PIDs)
   - Register with control plane
   - Begin heartbeat loop (15s interval)
4. Control plane assigns VMs                 ~1s
5. Firecracker boots each VM                 ~125ms each
```

Total recovery from host replacement: ~70s.

## Placement Daemon Recovery

On restart, `RecoverFromDisk()`:

1. Scans `VM_DIR` for subdirectories
2. Reads `vm.json` from each (written during Create)
3. Checks if Firecracker PID is still alive (`syscall.Kill(pid, 0)`)
4. Rebuilds in-memory VM map
5. Re-registers with control plane

Running VMs continue serving. Dead VMs are tracked but not restarted
(reconciliation loop would handle that).

## Audit Trail

`machine_events` table records all lifecycle transitions:

```
created, started, stopped, failed, destroyed, lost, reassigned
```

Each event includes machine_id, event_type, details, and timestamp.

## Cost Model

| | Fly.io | Flare (GCP) | Raw GCE |
|---|--------|-------------|---------|
| 4-vCPU VM/hr | $0.03 | ~$0.006 | $0.13 |
| Base infra/mo | $0 | ~$620 | ~$620 |
| Break-even | - | ~15 VMs | - |
| Boot time | ~300ms | ~125ms | ~30s |

## Security (v1)

- Single global API key (Bearer token on all `/v1/*` routes). Per-org keys planned for v2.
- Internal shared secret (`X-Internal-Key`) for control plane <-> placement
- App-scoped machine/hostname validation
- Lifecycle guards: actions on destroyed machines and deleting/deleted apps are rejected
- Host firewall restricted to control plane sources + health check probes
- No exec (SSH removed, guest agent not implemented)
- No arbitrary customer domains (internal use only)
- Audit events for all lifecycle changes
