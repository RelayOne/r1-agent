# Flare Guest Contract (v1)

## How config reaches the guest

Flare uses Firecracker's **MMDS (MicroVM Metadata Service)** to inject environment
variables and metadata into guests. This works like AWS/GCP instance metadata.

### Host side (placement daemon)

1. `Create()` always enables MMDS in the Firecracker config JSON
2. `Start()` waits for the API socket, then PUTs env data to `http://socket/mmds`
3. The MMDS endpoint becomes available inside the guest at `169.254.169.254`

### Guest side (flare-init)

The guest rootfs image must include `/usr/local/bin/flare-init` (from `guest/flare-init.sh`).
This script:

1. Polls `http://169.254.169.254/` until MMDS data is available (up to 10s)
2. Parses the JSON payload and writes env vars to `/run/flare/env`
3. Sources the env file so child processes inherit the variables

### MMDS payload format

```json
{
  "env": {
    "DATABASE_URL": "postgres://...",
    "API_KEY": "..."
  },
  "vm_id": "m-abc123",
  "ip": "10.0.0.2",
  "hostname": "m-abc123.ember.dev"
}
```

### Guest reads

```bash
# From inside the guest:
curl http://169.254.169.254/           # full JSON
curl http://169.254.169.254/env        # just env vars
curl http://169.254.169.254/vm_id      # just VM ID
```

### Systemd integration

```ini
[Unit]
Description=Flare guest init
Before=workload.service

[Service]
Type=oneshot
ExecStart=/usr/local/bin/flare-init
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
```

Then in your workload service:
```ini
[Service]
EnvironmentFile=/run/flare/env
ExecStart=/usr/local/bin/your-app
```

## What v1 does NOT support

- `config.mounts` -- API returns 400. No volume attachment in v1.
- `config.image` -- Must be a pre-staged `.ext4` file at `/var/lib/flare/vms/.images/<ref>.ext4`.
  Unknown image refs fail loudly instead of falling back to the default rootfs.
- `exec` -- API returns 501. No SSH or guest agent in v1.
