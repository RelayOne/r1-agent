// Flare SDK for TypeScript
// Wire format: snake_case (matches Go API responses directly)
// Property names: snake_case to avoid silent deserialization bugs

export interface FlareConfig {
  endpoint: string;
  apiKey: string;
  /** Request timeout in milliseconds (default: 30000) */
  timeoutMs?: number;
}

// Wire types (snake_case, matches Go JSON)
export interface Machine {
  id: string;
  name: string;
  state: string;
  desired_state: string;
  observed_state: string;
  region: string;
  ip_address?: string;
  generated_hostname?: string;
  last_error?: string;
  config: {
    image: string;
    guest: { cpus: number; memory_mb: number };
    env: Record<string, string>;
    metadata: Record<string, string>;
  };
  created_at: string;
  updated_at: string;
}

export interface Volume {
  id: string;
  name: string;
  size_gb: number;
  zone: string;
  attached_vm_id?: string;
}

export interface ExecResult {
  exit_code: number;
  stdout: string;
  stderr: string;
}

export interface CreateMachineOpts {
  name?: string;
  region?: string;
  image: string;
  cpus: number;
  memory_mb: number;
  env?: Record<string, string>;
  metadata?: Record<string, string>;
  // mounts not available in v1 -- API returns 400 if specified
}

export class FlareClient {
  private endpoint: string;
  private apiKey: string;
  private timeoutMs: number;

  constructor(config: FlareConfig) {
    this.endpoint = config.endpoint.replace(/\/$/, "");
    this.apiKey = config.apiKey;
    this.timeoutMs = config.timeoutMs ?? 30_000;
  }

  private async request<T>(method: string, path: string, body?: any): Promise<T> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);
    let res: Response;
    try {
      res = await fetch(`${this.endpoint}${path}`, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timeout);
    }
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      const errorBody = err as Record<string, unknown>;
      throw new Error(
        (typeof errorBody.error === "string" ? errorBody.error : null) ||
          `Flare API ${res.status}`
      );
    }
    return res.json() as T;
  }

  apps = {
    create: (name: string, orgSlug?: string) =>
      this.request<{ id: string }>("POST", "/v1/apps", {
        app_name: name,
        org_slug: orgSlug,
      }),
    destroy: (app: string) =>
      this.request<{ status: string }>("DELETE", `/v1/apps/${app}`),
  };

  machines = {
    create: (app: string, opts: CreateMachineOpts) =>
      this.request<Machine>("POST", `/v1/apps/${app}/machines`, {
        name: opts.name,
        region: opts.region,
        config: {
          image: opts.image,
          guest: { cpus: opts.cpus, memory_mb: opts.memory_mb },
          env: opts.env || {},
          metadata: opts.metadata || {},
        },
      }),
    list: (app: string) =>
      this.request<Machine[]>("GET", `/v1/apps/${app}/machines`),
    get: (app: string, id: string) =>
      this.request<Machine>("GET", `/v1/apps/${app}/machines/${id}`),
    start: (app: string, id: string) =>
      this.request<{ ok: boolean }>(
        "POST",
        `/v1/apps/${app}/machines/${id}/start`
      ),
    stop: (app: string, id: string) =>
      this.request<{ ok: boolean }>(
        "POST",
        `/v1/apps/${app}/machines/${id}/stop`
      ),
    destroy: (app: string, id: string) =>
      this.request<{ ok: boolean }>(
        "DELETE",
        `/v1/apps/${app}/machines/${id}`
      ),
    /**
     * Execute a command inside a running machine.
     * NOTE: The server currently returns 501 (Not Implemented). Exec is disabled
     * server-side due to command-injection risk in the SSH-based implementation.
     * A secure gRPC-based exec protocol is planned but not yet available.
     */
    exec: (app: string, id: string, cmd: string, args?: string[]) =>
      this.request<ExecResult>(
        "POST",
        `/v1/apps/${app}/machines/${id}/exec`,
        { command: cmd, args }
      ),
  };

  volumes = {
    create: (
      app: string,
      opts: { name: string; region: string; size_gb: number }
    ) => this.request<Volume>("POST", `/v1/apps/${app}/volumes`, opts),
    list: (app: string) =>
      this.request<Volume[]>("GET", `/v1/apps/${app}/volumes`),
    destroy: (app: string, id: string) =>
      this.request<{ ok: boolean }>(
        "DELETE",
        `/v1/apps/${app}/volumes/${id}`
      ),
  };

  hostnames = {
    create: (app: string, vmId: string, hostname: string) =>
      this.request<{ id: string }>("POST", `/v1/apps/${app}/hostnames`, {
        vm_id: vmId,
        hostname,
      }),
    destroy: (app: string, id: string) =>
      this.request<{ ok: boolean }>(
        "DELETE",
        `/v1/apps/${app}/hostnames/${id}`
      ),
  };
}
