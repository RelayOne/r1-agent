#!/bin/bash
# flare-init: reads Firecracker MMDS and exports env vars before workload starts.
# Installed on the guest rootfs image. Runs as a systemd service before the main app.
#
# MMDS is Firecracker's MicroVM Metadata Service, available at 169.254.169.254.
# The host injects env/metadata via the FC API socket after boot (see manager.go).
#
# Usage in systemd:
#   [Unit]
#   Description=Flare guest init
#   Before=workload.service
#   [Service]
#   Type=oneshot
#   ExecStart=/usr/local/bin/flare-init
#   EnvironmentFile=-/run/flare/env
#   [Install]
#   WantedBy=multi-user.target

set -euo pipefail

MMDS_URL="http://169.254.169.254"
ENV_FILE="/run/flare/env"
MAX_RETRIES=10
RETRY_DELAY=1

mkdir -p /run/flare

# Wait for network interface
for i in $(seq 1 5); do
  ip link show eth0 >/dev/null 2>&1 && break
  sleep 1
done

# Firecracker MMDS requires an explicit route (unlike AWS, it's not automatic)
ip route add 169.254.169.254 dev eth0 2>/dev/null || true

# Wait for MMDS to become available (host injects data after socket ready)
for i in $(seq 1 $MAX_RETRIES); do
  RESPONSE=$(curl -sf "$MMDS_URL/" 2>/dev/null || echo "")
  if [ -n "$RESPONSE" ] && [ "$RESPONSE" != "{}" ]; then
    break
  fi
  if [ "$i" -eq "$MAX_RETRIES" ]; then
    echo "[flare-init] MMDS not available after ${MAX_RETRIES}s, starting with defaults"
    touch "$ENV_FILE"
    exit 0
  fi
  sleep $RETRY_DELAY
done

# Parse env vars from MMDS JSON and write to env file.
# MMDS payload: {"env": {"KEY": "value", ...}, "vm_id": "...", "ip": "..."}
echo "$RESPONSE" | jq -r '.env // {} | to_entries[] | "export \(.key)=\(.value | @sh)"' > "$ENV_FILE" 2>/dev/null || true

# Also export VM metadata
VM_ID=$(echo "$RESPONSE" | jq -r '.vm_id // ""' 2>/dev/null || echo "")
VM_IP=$(echo "$RESPONSE" | jq -r '.ip // ""' 2>/dev/null || echo "")
HOSTNAME=$(echo "$RESPONSE" | jq -r '.hostname // ""' 2>/dev/null || echo "")

{
  echo "export FLARE_VM_ID=${VM_ID@Q}"
  echo "export FLARE_VM_IP=${VM_IP@Q}"
  echo "export FLARE_HOSTNAME=${HOSTNAME@Q}"
} >> "$ENV_FILE"

echo "[flare-init] Loaded $(wc -l < "$ENV_FILE") env vars from MMDS"

# Source env so child processes inherit
set -a
source "$ENV_FILE"
set +a
