# Stoke HTTP API Reference

Stoke exposes an HTTP API for monitoring builds and managing missions. Start the server with:

```bash
stoke serve [--port 8420] [--token SECRET]
```

| Flag      | Default | Description                                      |
|-----------|---------|--------------------------------------------------|
| `--port`  | `8420`  | TCP port the HTTP server listens on               |
| `--token` | (none)  | Bearer token for authentication; omit to disable  |

All JSON endpoints set `Access-Control-Allow-Origin: *`.

---

## Authentication

When the server is started with `--token`, every request (except `/api/health`) must include the header:

```
Authorization: Bearer <token>
```

Requests without a valid token receive `401 Unauthorized`.

---

## Core Endpoints

### GET /api/health

Health check. No authentication required.

**Response** `200 OK`

```json
{
  "status": "ok"
}
```

---

### GET /api/status

Returns the current build status. The shape of the response depends on the `StatusFn` registered on the server; when none is configured the default is returned.

**Response** `200 OK`

```json
{
  "status": "running"
}
```

When a custom `StatusFn` is registered (e.g. during a `stoke run`), the response contains whatever that function returns (typically build progress, task counts, and pool utilization).

---

### GET /api/events

Server-Sent Events (SSE) stream. The connection stays open and pushes newline-delimited `data:` frames as events occur.

**Headers**

```
Content-Type: text/event-stream
Cache-Control: no-cache
Connection: keep-alive
```

**Event format**

```
data: {"type":"file_change","event":"modify","path":"src/main.go"}

```

Event types include:

| `type`               | Description                              |
|----------------------|------------------------------------------|
| `file_change`        | A watched file was created/modified/deleted. Fields: `event`, `path`. |
| `mission_created`    | A new mission was created. Fields: `mission_id`, `title`. |
| `mission_advanced`   | A mission changed phase. Fields: `mission_id`, `phase`. |
| `convergence_run`    | Convergence validation completed. Fields: `mission_id`, `converged`, `score`, `findings`. |
| `handoff`            | An agent handoff was recorded. Fields: `mission_id`, `from`, `to`. |
| `consensus`          | A consensus vote was recorded. Fields: `mission_id`, `model`, `verdict`. |

---

## Mission Endpoints

Mission endpoints are registered when an `Orchestrator` is available. They manage the full mission lifecycle: creation, phase advancement, convergence validation, agent context, handoffs, and consensus.

---

### GET /api/missions

List all missions, optionally filtered by phase.

**Query parameters**

| Name    | Required | Description                                                             |
|---------|----------|-------------------------------------------------------------------------|
| `phase` | No       | Filter by phase. One of: `created`, `researching`, `planning`, `executing`, `validating`, `converged`, `completed`, `failed`, `paused`. |

**Response** `200 OK`

```json
{
  "missions": [
    {
      "id": "m-1712345678",
      "title": "JWT Auth",
      "intent": "Add JWT authentication to API",
      "phase": "executing",
      "criteria": [
        {
          "id": "c-1",
          "description": "Tokens issued on login",
          "satisfied": false,
          "evidence": ""
        }
      ],
      "tags": [],
      "metadata": {},
      "created_at": "2026-04-04T10:00:00Z",
      "updated_at": "2026-04-04T10:30:00Z"
    }
  ],
  "count": 1
}
```

---

### POST /api/missions/create

Create a new mission.

**Request body**

```json
{
  "title": "JWT Auth",
  "intent": "Add JWT authentication to the REST API",
  "criteria": [
    "Tokens issued on login",
    "Invalid tokens return 401"
  ]
}
```

| Field      | Type     | Required | Description                        |
|------------|----------|----------|------------------------------------|
| `title`    | string   | Yes      | Short human-readable name          |
| `intent`   | string   | Yes      | Full description of what to build  |
| `criteria` | string[] | No       | Acceptance criteria (plain text)   |

**Response** `201 Created`

Returns the full `Mission` object (same shape as in the list response). Also publishes a `mission_created` SSE event.

---

### GET /api/missions/get

Retrieve a single mission by ID.

**Query parameters**

| Name | Required | Description                                              |
|------|----------|----------------------------------------------------------|
| `id` | Yes      | Mission ID (alphanumeric, hyphens, underscores only)     |

**Response** `200 OK` -- full `Mission` object.

**Errors**

- `400` -- missing or invalid `id`
- `404` -- mission not found

---

### POST /api/missions/advance

Advance a mission to a new phase.

**Request body**

```json
{
  "mission_id": "m-1712345678",
  "phase": "executing",
  "reason": "Planning complete, tasks ready",
  "agent": "claude-opus"
}
```

| Field        | Type   | Required | Description                                                    |
|--------------|--------|----------|----------------------------------------------------------------|
| `mission_id` | string | Yes      | Mission ID                                                     |
| `phase`      | string | Yes      | Target phase (see valid phases below)                          |
| `reason`     | string | No       | Why the transition is happening                                |
| `agent`      | string | No       | Which agent/model is advancing the phase                       |

**Valid phases:** `created`, `researching`, `planning`, `executing`, `validating`, `converged`, `completed`, `failed`, `paused`

Not all transitions are valid. The mission store enforces a transition graph (e.g. `validating` can loop back to `executing` when gaps are found).

**Response** `200 OK`

```json
{
  "status": "ok",
  "phase": "executing"
}
```

Also publishes a `mission_advanced` SSE event.

---

### GET /api/missions/convergence

Check the convergence status of a mission (criteria satisfaction, gap counts, consensus status).

**Query parameters**

| Name | Required | Description  |
|------|----------|--------------|
| `id` | Yes      | Mission ID   |

**Response** `200 OK`

```json
{
  "mission_id": "m-1712345678",
  "phase": "validating",
  "total_criteria": 2,
  "satisfied_criteria": 1,
  "open_gap_count": 3,
  "blocking_gap_count": 1,
  "handoff_count": 2,
  "consensus_count": 0,
  "complete_votes": 0,
  "is_converged": false,
  "has_consensus": false
}
```

---

### POST /api/missions/convergence/run

Run convergence validation against a set of files for a mission. The validator applies its rule set and returns a report with findings, a score, and a converged/not-converged determination.

When `STOKE_ANALYSIS_API_KEY` is set, the validator runs a two-pass analysis: first a fast regex scan, then a model-driven semantic review that catches subtle logic errors, incomplete error handling, and architectural issues that patterns cannot detect. Without the key, only the regex pass runs.

**Request body**

```json
{
  "mission_id": "m-1712345678",
  "files": [
    {
      "path": "src/auth.go",
      "content": "<base64-or-raw file content as byte array>"
    }
  ]
}
```

| Field        | Type       | Required | Description                              |
|--------------|------------|----------|------------------------------------------|
| `mission_id` | string     | Yes      | Mission ID                               |
| `files`      | FileInput[] | Yes     | Files to validate                        |

Each `FileInput` has:

| Field     | Type   | Description                          |
|-----------|--------|--------------------------------------|
| `path`    | string | Relative path within the project     |
| `content` | bytes  | File content                         |

**Response** `200 OK`

```json
{
  "mission_id": "m-1712345678",
  "timestamp": "2026-04-04T10:45:00Z",
  "findings": [
    {
      "rule_id": "todo-check",
      "category": "completeness",
      "severity": "blocking",
      "file": "src/auth.go",
      "line": 42,
      "description": "TODO comment found",
      "suggestion": "Resolve or remove the TODO",
      "evidence": "// TODO: implement feature"
    }
  ],
  "score": 0.75,
  "is_converged": false,
  "summary": "1 blocking finding, 2 minor findings",
  "rules_applied": 18,
  "duration": 1200000
}
```

Finding severities: `blocking`, `major`, `minor`, `info`.

Finding categories: `completeness`, `correctness`, `consistency`, `quality`, `security`.

Also publishes a `convergence_run` SSE event.

---

### POST /api/missions/context

Build agent context for a mission. Returns a text block suitable for injecting into an LLM prompt, containing mission info, criteria, gaps, research, handoffs, and convergence status as configured.

**Request body**

```json
{
  "mission_id": "m-1712345678",
  "config": {
    "max_tokens": 4000,
    "include_mission_info": true,
    "include_criteria": true,
    "include_gaps": true,
    "include_research": true,
    "include_handoffs": true,
    "include_convergence_status": true,
    "research_query": "",
    "max_research_entries": 5
  }
}
```

| Field        | Type          | Required | Description                                        |
|--------------|---------------|----------|----------------------------------------------------|
| `mission_id` | string        | Yes      | Mission ID                                         |
| `config`     | ContextConfig | No       | Controls which sections to include; defaults to all |

**ContextConfig fields**

| Field                        | Type   | Default | Description                                    |
|------------------------------|--------|---------|------------------------------------------------|
| `max_tokens`                 | int    | 4000    | Total token budget (~4 chars/token)            |
| `include_mission_info`       | bool   | true    | Include title, intent, phase                   |
| `include_criteria`           | bool   | true    | Include acceptance criteria checklist           |
| `include_gaps`               | bool   | true    | Include open gaps from convergence              |
| `include_research`           | bool   | true    | Include relevant research findings              |
| `include_handoffs`           | bool   | true    | Include handoff history from prior agents       |
| `include_convergence_status` | bool   | true    | Include convergence metrics                     |
| `research_query`             | string | ""      | Query for finding research; empty uses intent   |
| `max_research_entries`       | int    | 5       | Max research findings to include                |

**Response** `200 OK`

```json
{
  "context": "## Mission: JWT Auth\n\nIntent: Add JWT authentication...\n\n## Criteria\n- [ ] Tokens issued on login\n..."
}
```

---

### POST /api/missions/handoff

Record an agent handoff for a mission. Handoffs capture what one agent completed and what the next agent should pick up.

**Request body**

```json
{
  "mission_id": "m-1712345678",
  "from_agent": "claude-opus",
  "to_agent": "codex",
  "summary": "Implemented JWT signing; tests passing",
  "pending_work": ["Add refresh token rotation", "Rate limiting"],
  "key_decisions": ["Using RS256 over HS256"],
  "files_changed": ["src/auth.go", "src/middleware.go"],
  "test_status": "passing",
  "phase": "executing",
  "timestamp": "2026-04-04T11:00:00Z"
}
```

| Field           | Type     | Required | Description                                         |
|-----------------|----------|----------|-----------------------------------------------------|
| `mission_id`    | string   | Yes      | Mission ID                                          |
| `from_agent`    | string   | Yes      | Agent handing off                                   |
| `to_agent`      | string   | Yes      | Agent receiving the work                            |
| `summary`       | string   | Yes      | What was accomplished                               |
| `pending_work`  | string[] | No       | Remaining tasks                                     |
| `key_decisions` | string[] | No       | Important decisions made                            |
| `files_changed` | string[] | No       | Files that were modified                            |
| `test_status`   | string   | No       | `"passing"`, `"failing"`, or `"unknown"`            |
| `phase`         | string   | No       | Current mission phase                               |
| `timestamp`     | string   | No       | ISO 8601 timestamp                                  |

**Response** `200 OK`

```json
{
  "status": "ok"
}
```

Also publishes a `handoff` SSE event.

---

### POST /api/missions/consensus

Record a consensus vote from a model. When enough models vote "complete", the mission reaches consensus.

**Request body**

```json
{
  "mission_id": "m-1712345678",
  "model": "claude-opus",
  "verdict": "complete",
  "reasoning": "All criteria met, no blocking gaps, tests passing",
  "gaps_found": []
}
```

| Field        | Type     | Required | Description                                          |
|--------------|----------|----------|------------------------------------------------------|
| `mission_id` | string   | Yes      | Mission ID                                           |
| `model`      | string   | Yes      | Which model is voting                                |
| `verdict`    | string   | Yes      | `"complete"` or `"incomplete"`                       |
| `reasoning`  | string   | No       | Explanation of the verdict                           |
| `gaps_found` | string[] | No       | Any gaps identified (relevant when incomplete)       |

**Response** `200 OK`

```json
{
  "status": "ok",
  "has_consensus": true
}
```

`has_consensus` is `true` when 2+ models have voted `"complete"`.

Also publishes a `consensus` SSE event.

---

## Error Responses

All endpoints return errors as JSON:

```json
{
  "error": "description of what went wrong"
}
```

Common HTTP status codes:

| Code  | Meaning                                      |
|-------|----------------------------------------------|
| `400` | Bad request (invalid body, missing params)   |
| `401` | Unauthorized (missing or invalid bearer token) |
| `404` | Resource not found                           |
| `405` | Method not allowed                           |
| `500` | Internal server error                        |
