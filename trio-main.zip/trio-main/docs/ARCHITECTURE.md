# Architecture

## Overview

Trio is three components that form a vertically integrated AI development stack:

```
+-------------------+     +-------------------+     +-------------------+
|      STOKE        |     |      EMBER        |     |      FLARE        |
|  AI Orchestrator  |---->|  Cloud Dev Env    |---->|  MicroVM Runtime  |
|  Go CLI           |     |  Node.js/TS       |     |  Go + Firecracker |
+-------------------+     +-------------------+     +-------------------+
```

## Tech Stack

| Component | Language | Runtime | Database | Infrastructure |
|-----------|----------|---------|----------|----------------|
| stoke | Go 1.23+ | CLI binary | SQLite or JSON file | Local or remote |
| ember | TypeScript | Node.js | Postgres | Fly.io (current) |
| flare | Go | Two binaries | Postgres | GCP with Firecracker |

## Repository Map

```
trio/
├── stoke/                    # AI coding orchestrator
│   ├── cmd/stoke/main.go     # 19 commands, CLI entry point
│   ├── internal/             # 104 packages
│   │   │
│   │   │ ## Core orchestration
│   │   ├── app/              # Orchestrator core
│   │   ├── config/           # Policy, settings, auto-detect
│   │   ├── engine/           # Claude + Codex runners
│   │   ├── workflow/         # Phase machine, retry loop
│   │   ├── scheduler/        # GRPW priority, file conflicts
│   │   ├── plan/             # Plan loader, cycle detection, ROI
│   │   ├── depgraph/         # Dependency graph resolution
│   │   ├── taskstate/        # Task state machine
│   │   ├── dispatch/         # Task dispatch routing
│   │   ├── lifecycle/        # Process lifecycle management
│   │   │
│   │   │ ## Mission & convergence system
│   │   ├── mission/          # Mission lifecycle, store, runner, context, handlers, metrics
│   │   ├── convergence/      # Two-pass convergence validator (regex + model analysis)
│   │   ├── consensus/        # Multi-model adversarial consensus engine
│   │   ├── orchestrate/      # Mission orchestrator
│   │   ├── handoff/          # Session handoff chain
│   │   ├── baseline/         # Baseline verification snapshots
│   │   ├── critic/           # Adversarial code critic (pattern + model-driven review)
│   │   │
│   │   │ ## Intelligence & analysis
│   │   ├── research/         # FTS5-backed research store + model-driven semantic search
│   │   ├── memory/           # Cross-session persistent memory
│   │   ├── semdiff/          # Semantic diff analysis
│   │   ├── vecindex/         # Vector similarity search (API embeddings + model re-ranking)
│   │   ├── tfidf/            # TF-IDF text ranking
│   │   ├── symindex/         # Symbol indexing
│   │   ├── repomap/          # Repository structure mapping
│   │   ├── surfacemap/       # Cross-surface dependency mapping (Go/TS/Python endpoints)
│   │   ├── intent/           # Intent classification
│   │   ├── wisdom/           # Accumulated wisdom store
│   │   │
│   │   │ ## Execution optimization
│   │   ├── specexec/         # Speculative execution
│   │   ├── testselect/       # Intelligent test selection
│   │   ├── flowtrack/        # Execution flow tracking
│   │   ├── promptcache/      # Prompt cache optimization
│   │   ├── microcompact/     # Aggressive context compaction
│   │   ├── ctxpack/          # Context packing
│   │   ├── tokenest/         # Token estimation
│   │   │
│   │   │ ## Safety & policy
│   │   ├── audit/            # 17 review personas
│   │   ├── hooks/            # Pre/Post tool-use guards
│   │   ├── sandattr/         # Sandbox attribution
│   │   ├── sandbox/          # Sandbox isolation
│   │   ├── sandguard/        # Sandbox guards
│   │   ├── conflictres/      # Conflict resolution
│   │   ├── permissions/      # Permission management
│   │   ├── rbac/             # Role-based access control
│   │   ├── consent/          # User consent tracking
│   │   ├── validation/       # Input validation
│   │   ├── schemaval/        # Schema validation
│   │   │
│   │   │ ## Model & provider
│   │   ├── model/            # Task-type inference, provider fallback
│   │   ├── managed/          # Managed AI routing
│   │   ├── provider/         # Provider abstraction
│   │   ├── compute/          # Compute abstraction
│   │   ├── pools/            # Pool management
│   │   ├── subscriptions/    # Pool allocator, circuit breaker
│   │   ├── ratelimit/        # Rate limiting
│   │   ├── costtrack/        # Cost tracking
│   │   │
│   │   │ ## Context & prompts
│   │   ├── context/          # Three-tier context budget
│   │   ├── prompts/          # Prompt templates
│   │   ├── prompt/           # Prompt construction
│   │   ├── prompttpl/        # Prompt templating
│   │   ├── conversation/     # Conversation management
│   │   ├── agentmsg/         # Agent message protocol
│   │   │
│   │   │ ## Code operations
│   │   ├── scan/             # Deterministic code scan
│   │   ├── verify/           # Build/test/lint + scope check
│   │   ├── autofix/          # Automatic fix application
│   │   ├── patchapply/       # Patch application
│   │   ├── diffcomp/         # Diff computation
│   │   ├── extract/          # Code extraction
│   │   ├── testgen/          # Test generation
│   │   ├── gitblame/         # Git blame analysis
│   │   ├── chunker/          # Code chunking
│   │   │
│   │   │ ## Session & state
│   │   ├── session/          # JSON + SQLite session stores
│   │   ├── snapshot/         # State snapshots
│   │   ├── checkpoint/       # Checkpoint management
│   │   ├── replay/           # Session replay
│   │   │
│   │   │ ## Infrastructure & I/O
│   │   ├── remote/           # Remote worker integration
│   │   ├── worktree/         # Git worktree management
│   │   ├── stream/           # NDJSON parser
│   │   ├── report/           # Build reports
│   │   ├── repl/             # REPL interface
│   │   ├── tui/              # Bubble Tea TUI + headless runner
│   │   ├── viewport/         # Terminal viewport
│   │   ├── progress/         # Progress reporting
│   │   ├── notify/           # Notifications
│   │   ├── logging/          # Structured logging
│   │   ├── telemetry/        # Telemetry collection
│   │   ├── metrics/          # Metrics aggregation
│   │   ├── server/           # HTTP server
│   │   ├── apiclient/        # API client
│   │   ├── mcp/              # Model Context Protocol
│   │   │
│   │   │ ## Utilities
│   │   ├── failure/          # 10 failure classes, retry logic
│   │   ├── errtaxonomy/      # Error taxonomy
│   │   ├── jsonutil/         # JSON utilities
│   │   ├── fileutil/         # File utilities
│   │   ├── atomicfs/         # Atomic filesystem ops
│   │   ├── filewatcher/      # File watching
│   │   ├── toolcache/        # Tool result caching
│   │   │
│   │   │ ## Specialized
│   │   ├── skill/            # Skill definitions
│   │   ├── plugins/          # Plugin system
│   │   ├── interview/        # Interactive interview
│   │   ├── preflight/        # Preflight checks
│   │   ├── team/             # Team collaboration
│   │   ├── branch/           # Branch management
│   │   ├── phaserole/        # Phase role assignment
│   │   ├── boulder/          # Large task decomposition
│   │   ├── ralph/            # Ralph assistant
│   │   └── harness/          # Test harness
│   └── docs/                 # Operator guide, frozen spec
│
├── ember/                    # Cloud dev environment platform
│   └── devbox/               # Main application
│       ├── src/              # API server (TypeScript)
│       ├── web/              # Frontend (Vite)
│       ├── drizzle/          # Database schema
│       ├── migrations/       # SQL migrations
│       ├── machine-image/    # Fly Machine image (Dockerfile)
│       └── docs/             # Operational docs
│
├── flare/                    # Firecracker microVM runtime
│   ├── cmd/
│   │   ├── control-plane/    # API server + ingress proxy
│   │   └── placement/        # Per-host VM lifecycle daemon
│   ├── internal/
│   │   └── store/            # Postgres store
│   ├── sdk/typescript/       # TypeScript client SDK
│   ├── deploy/
│   │   ├── terraform/        # GCP infrastructure
│   │   └── packer/           # Host image builder
│   └── migrations/           # Postgres schema
│
└── docs/                     # Cross-repo documentation (this directory)
```

## System Components

### Stoke (AI Orchestrator)

The brain. Accepts tasks or plans, routes them to AI models, manages execution in isolated git worktrees, enforces quality gates, and produces structured reports.

Key internals:
- **Scheduler**: GRPW (Greatest Remaining Planned Work) priority ordering with file-scope conflict detection
- **Engine**: Drives Claude Code and Codex CLI as subprocesses with process group isolation and 3-tier timeouts
- **Workflow**: Phase machine (plan -> execute -> verify -> review -> merge) with clean-worktree retry
- **Model Router**: 9 task types, benchmark-backed routing, 5-provider fallback chain
- **Policy Engine**: 11 layers from CLI flags to sandbox settings to enforcer hooks
- **Convergence**: Two-pass architecture -- fast regex scan, then model-driven semantic analysis when `STOKE_ANALYSIS_API_KEY` is set
- **Consensus Engine**: N models verify completion independently; mission converges only on multi-model agreement

### Ember (Cloud Dev Platform)

The frontend and provisioning layer. Provides a web dashboard where users create and manage cloud dev machines. Handles auth, billing, GitHub integration, and machine lifecycle.

Key internals:
- **Auth**: Email/password + GitHub OAuth + Google OAuth, with session cookies
- **Billing**: Stripe integration with slot-based provisioning, webhook-driven state sync
- **Machine Manager**: Creates Fly Machines via Fly API, manages lifecycle (start/stop/destroy)
- **Terminal Proxy**: Exchange-code auth flow, HMAC session cookies, iframe-based terminal/VS Code
- **Reconciler**: Background loop that stops machines for cancelled subscriptions, retries failures

### Flare (MicroVM Runtime)

The infrastructure layer. Runs Firecracker microVMs on GCP with a Fly-compatible API.

Key internals:
- **Control Plane**: Go HTTP server with Postgres backing. Two listeners: API on :8090, ingress proxy on :8080
- **Placement Daemon**: Per-host binary managing VM lifecycle. Registers with control plane, heartbeats every 15s
- **State Model**: Split desired/observed state with atomic capacity scheduling
- **Ingress**: Cloudflare Tunnel -> control plane -> hostname lookup -> reverse proxy to host -> VM TAP IP

## Integration Architecture

### Current State: Ember on Fly.io

```
                                                    +-----------+
  stoke ----EMBER_API_KEY----> ember API ----FLY_API_TOKEN----> Fly.io
  (local)                      (Node.js)                        (Machines API)
                               Postgres
                               Stripe
```

Ember uses the Fly.io Machines API directly via `FLY_API_TOKEN`. Machine creation, start, stop, and destroy all go through Fly's REST API. This works but means you depend on Fly.io's infrastructure and pricing.

### Planned State: Ember on Flare

```
                                                    +-----------+
  stoke ----EMBER_API_KEY----> ember API ----FLARE_API_KEY----> flare
  (local)                      (Node.js)                        control plane
                               Postgres                         |
                               Stripe                      +----+----+
                                                           | GCP MIG |
                                                           | hosts   |
                                                           +---------+
```

Because flare implements a Fly-compatible API, the migration path is straightforward:
1. Replace `FLY_API_TOKEN` + Fly API base URL with `FLARE_API_KEY` + flare control plane URL
2. Update machine creation to use flare's image format (ext4 instead of Docker)
3. Update hostname/certificate handling (flare uses `*.ember.dev` generated hostnames natively)
4. Update health checks and monitoring to use flare's observed_state model

### The Flare SDK

Flare ships a TypeScript SDK at `flare/sdk/typescript/` that ember could use directly:

```typescript
import { FlareClient } from '@flare/sdk';

const flare = new FlareClient({
  endpoint: 'https://flare.example.com',
  apiKey: process.env.FLARE_API_KEY,
});

// Create a machine (same concepts as Fly)
const machine = await flare.createMachine('my-app', {
  image: 'ember-dev-image',
  guest: { cpus: 4, memory_mb: 8192 },
  env: { MACHINE_TYPE: 'cli' },
});

// Lifecycle
await flare.startMachine('my-app', machine.id);
await flare.stopMachine('my-app', machine.id);
await flare.destroyMachine('my-app', machine.id);
```

The SDK types (`Machine`, `Volume`, `ExecResult`, `CreateMachineOpts`) match flare's wire format (snake_case JSON from the Go API).

### Migration Plan: Ember to Flare

**Phase 1 -- Abstraction layer** (not started): Extract ember's Fly.io API calls into a `MachineProvider` interface. Current implementation becomes `FlyProvider`.

**Phase 2 -- Flare provider** (not started): Implement `FlareProvider` using the flare TypeScript SDK. Feature-flag between Fly and flare backends.

**Phase 3 -- Cutover** (not started): Run both backends in parallel, validate parity, switch default to flare. Remove Fly dependency.

**Blockers**: Flare v1 does not support volumes (ember needs persistent `/workspace`), exec (ember needs terminal access), or OCI images (ember uses Docker images on Fly). These are on flare's post-v1 roadmap.

## Auth Flow

```
  Developer                stoke                   ember API               Fly.io / flare
     |                       |                         |                         |
     |  stoke run --task ... |                         |                         |
     |---------------------->|                         |                         |
     |                       |  POST /api/workers      |                         |
     |                       |  Authorization: Bearer   |                         |
     |                       |  $EMBER_API_KEY          |                         |
     |                       |------------------------>|                         |
     |                       |                         |  POST /v1/apps/.../     |
     |                       |                         |  machines               |
     |                       |                         |  Authorization: Bearer  |
     |                       |                         |  $FLY_API_TOKEN         |
     |                       |                         |------------------------>|
     |                       |                         |  { id, ip, state }      |
     |                       |                         |<------------------------|
     |                       |  { worker_id, url }     |                         |
     |                       |<------------------------|                         |
     |                       |                         |                         |
     |                       |  [drives Claude Code    |                         |
     |                       |   on remote worker]     |                         |
```

- **stoke -> ember**: `EMBER_API_KEY` environment variable. Standard Bearer token auth.
- **ember -> Fly.io**: `FLY_API_TOKEN` org-scoped token. Stored as Fly secret.
- **ember -> flare** (future): `FLARE_API_KEY`. Same Bearer token pattern.
- **ember users -> ember**: Email/password, GitHub OAuth, or Google OAuth. Session cookies.
- **ember -> machines**: Exchange-code flow. One-time code -> HMAC session cookie.

## Data Models

### Stoke

- **Plan**: JSON file with tasks, dependencies, ROI scores
- **Task**: ID, type, files, dependencies, provider preference
- **Session**: Attempt history, learned patterns, cost tracking (JSON or SQLite)
- **BuildReport**: Per-task results, failures, reviews

### Ember

- **User**: Email, password hash, OAuth tokens, billing state
- **Machine**: Fly Machine ID, type (cli/vscode), state, hostname, user association
- **Slot**: Billing slot tied to Stripe subscription
- **TerminalSession**: Exchange code, session ID, HMAC cookie, TTL

### Flare

- **App**: Namespace for machines
- **Machine**: Split state (desired_state + observed_state), host placement, config
- **Host**: Capacity (CPUs, memory), zone, heartbeat timestamp
- **Hostname**: Generated (`*.ember.dev`) or custom, linked to machine

## Testing Architecture

| Component | Unit Tests | Integration Tests | E2E Tests |
|-----------|-----------|-------------------|-----------|
| stoke | 2019 test functions across 104 packages | Mock-based engine tests | Manual (requires Claude Code) |
| ember | Vitest for API routes and services | Database tests with test Postgres | Playwright (planned) |
| flare | Helper packages + reconciler store | Requires real Firecracker | Manual |

---
*Last updated: 2026-04-04*
