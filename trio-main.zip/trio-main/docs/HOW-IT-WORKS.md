# How It Works

## The Big Picture

Trio turns a task description into running, tested, committed code on cloud machines. Three components handle three layers of that problem:

```
"Add JWT auth to the API"
         |
         v
  +-------------+
  |    STOKE    |  Breaks it into subtasks. Routes to AI models.
  |             |  Executes in isolated worktrees. Verifies. Commits.
  +------+------+
         |
         v
  +-------------+
  |    EMBER    |  Provisions cloud machines with the right tools.
  |             |  Handles billing, auth, GitHub integration.
  +------+------+
         |
         v
  +-------------+
  |    FLARE    |  Boots Firecracker microVMs on your own hardware.
  |             |  Fly-compatible API. Full infrastructure control.
  +------+------+
```

## User Journey

### Path 1: Developer Using Stoke Locally

You have a codebase. You want AI to build features, fix bugs, or audit code.

**Step 1: Define the work**

```bash
# Single task
stoke run --task "Add request ID middleware to all HTTP handlers"

# Or generate a multi-task plan
stoke plan --task "Add JWT auth with refresh tokens"

# Or audit the codebase
stoke audit
```

**Step 2: Stoke orchestrates**

Stoke does not just call an AI model. It runs a deterministic state machine:

```
PLAN phase     AI reads the code with read-only tools. MCP disabled.
     |         Produces a plan: which files to change, what to do.
     v
EXECUTE phase  AI writes code. Sandbox on. Restricted to declared files.
     |         Uses Claude Code or Codex based on task type routing.
     v
VERIFY phase   Build. Test. Lint. Protected file check. Scope check.
     |         No AI involved -- deterministic verification.
     v
REVIEW phase   Cross-model gate. If Claude wrote it, Codex reviews it.
     |         Blocks merge on rejection.
     v
MERGE phase    git merge-tree validation. Merge to main. Cleanup worktree.
```

If any phase fails, stoke classifies the failure (10 classes), creates a clean worktree, injects the failure context and diff, and retries (up to 3 attempts with same-error escalation).

**Step 3: You get results**

```bash
stoke status   # See progress, cost, learned patterns
# Reports in .stoke/reports/latest.json
```

### Path 2: Developer Using Ember Cloud Machines

You want cloud dev environments with AI tools pre-installed.

**Step 1: Sign up and subscribe**

Visit the Ember dashboard. Sign in with GitHub or Google. Pick a plan (4/8/16 vCPU machines). Stripe handles billing.

**Step 2: Create a machine**

Click "New Machine" in the dashboard. Choose CLI (terminal) or VS Code. Ember calls the Fly.io API to provision a machine with your chosen specs.

**Step 3: Connect**

The dashboard opens a terminal iframe. The auth flow:

```
Dashboard                    Machine                     Ember API
    |                           |                            |
    |  POST /api/machines/:id/terminal                       |
    |------------------------------------------------------->|
    |  { terminalUrl, exchangeUrl, code, sessionId }         |
    |<-------------------------------------------------------|
    |                           |                            |
    |  iframe src = terminalUrl?code=...                     |
    |-------------------------->|                            |
    |                           |  POST /api/machines/       |
    |                           |  verify-code               |
    |                           |--------------------------->|
    |                           |  { valid: true }           |
    |                           |<---------------------------|
    |                           |                            |
    |                           |  Set HMAC session cookie   |
    |                           |  Redirect to terminal      |
    |  <connected>              |                            |
```

**Step 4: Work**

You have a full terminal or VS Code with Claude Code, Codex, Rust, Go, Python, Git, and your GitHub repos accessible. The persistent volume at `/workspace` survives stop/start cycles.

### Path 3: Running Your Own Infrastructure with Flare

You want Fly.io's developer experience on your own GCP account.

**Step 1: Deploy infrastructure**

```bash
cd flare/deploy/packer
packer build -var project_id=$PROJECT .   # Bake host image

cd ../terraform
terraform apply -var project_id=$PROJECT  # Create MIG, firestore, firewall
```

**Step 2: Start the control plane**

```bash
DATABASE_URL=postgres://... \
FLARE_API_KEY=... \
go run ./cmd/control-plane
```

**Step 3: Use the Fly-compatible API**

```bash
# Create an app
curl -X POST http://localhost:8090/v1/apps \
  -H "Authorization: Bearer $FLARE_API_KEY" \
  -d '{"app_name": "my-app"}'

# Create a machine
curl -X POST http://localhost:8090/v1/apps/my-app/machines \
  -H "Authorization: Bearer $FLARE_API_KEY" \
  -d '{"config": {"image": "my-image", "guest": {"cpus": 2, "memory_mb": 2048}}}'
```

The placement daemon on each host handles the Firecracker VM lifecycle. The control plane tracks state in Postgres and routes ingress traffic.

## Data Flow: Stoke Creates a Worker on Ember

This is the full integration story -- how stoke uses ember to get a remote execution environment:

```
stoke                          ember API                    Fly.io
  |                               |                           |
  |  1. POST /api/workers         |                           |
  |  { task, specs, image }       |                           |
  |  Auth: Bearer EMBER_API_KEY   |                           |
  |------------------------------>|                           |
  |                               |  2. Check user quota      |
  |                               |  (slots vs active machines)|
  |                               |                           |
  |                               |  3. POST /v1/apps/.../    |
  |                               |     machines              |
  |                               |  Auth: FLY_API_TOKEN      |
  |                               |--------------------------->|
  |                               |                           |
  |                               |  4. Machine created       |
  |                               |  { id, ip, state }        |
  |                               |<--------------------------|
  |                               |                           |
  |  5. { worker_id, url,        |                           |
  |       terminal_code }         |                           |
  |<------------------------------|                           |
  |                               |                           |
  |  6. Drive Claude Code on      |                           |
  |     remote worker via         |                           |
  |     terminal session          |                           |
  |                               |                           |
  |  7. POST /api/workers/:id/   |                           |
  |     stop                      |                           |
  |------------------------------>|                           |
  |                               |  8. POST .../stop         |
  |                               |--------------------------->|
```

## Key Technical Decisions

### Why three separate components?

Each solves a distinct problem at a distinct layer. Keeping them separate means:
- You can use stoke without ember (run AI locally)
- You can use ember without flare (run on Fly.io)
- You can use flare without ember (run any workload, not just dev environments)

### Why Firecracker (flare) instead of containers?

Firecracker provides VM-level isolation in ~125ms boot time. Dev machines run as root, install system packages, and modify kernel parameters. Containers cannot provide this level of isolation with this level of flexibility.

### Why split desired/observed state (flare)?

Distributed systems have eventual consistency. A machine can be "desired: running" but "observed: starting" -- and that is not an error, it is reality. The split state model makes this explicit and prevents the control plane from lying about what is actually happening.

### Why cross-model review (stoke)?

Same-model review is a weak signal -- the model is biased toward its own output. Claude implementing and Codex reviewing (or vice versa) catches different classes of errors because the models have different failure modes.

## Mission System

The mission system is Stoke's highest-level orchestration layer. While the workflow engine handles individual tasks, the mission system manages multi-phase goals that span multiple tasks and sessions.

### Mission Lifecycle
1. **Created** — mission defined with intent and success criteria
2. **Researching** — gathering context via research store (FTS5 search)
3. **Planning** — breaking down into tasks with dependency ordering
4. **Executing** — running tasks through the workflow engine
5. **Validating** — convergence validator checks zero-tolerance gates
6. **Consensus** — multi-model agreement on completion
7. **Completed** — all criteria satisfied

### Convergence Validation
The convergence validator uses a two-pass architecture:

**Pass 1 -- Regex scan (fast, deterministic, free):** Pattern matching across 8 categories:
- **Security**: secrets, SQL injection, command injection, auth bypass
- **Consistency**: no TODOs, stubs, placeholders, or incomplete code
- **Completeness**: all declared features implemented and tested
- **Style**: consistent formatting, naming, error handling patterns
- **Testing**: adequate coverage, no empty test bodies
- **Documentation**: public APIs documented
- **Performance**: no unbounded queries, resource leaks
- **Architecture**: no circular dependencies, clean separation

**Pass 2 -- Model analysis (semantic, deep, optional):** When `STOKE_ANALYSIS_API_KEY` is set, the validator sends findings and source context to an AI model for semantic review. The model catches issues that regex cannot: subtle logic errors, incomplete error handling, missing edge cases, and architectural concerns that require understanding intent. Prompts are maintained in `convergence/prompts.go`.

The two-pass design means the validator is always useful (pass 1 is free and fast) but becomes significantly more powerful when model analysis is available.

### Cross-Session Memory
The memory package provides persistent learning across sessions:
- Patterns that worked (reuse in future tasks)
- Gotchas that trip up agents (avoid repeating mistakes)
- Codebase-specific facts (conventions, constraints)
- Anti-patterns that don't work (stop doing what fails)

### Research Store
SQLite-backed research persistence with FTS5 full-text search:
- Store research findings with topics, tags, and source URLs
- Search by keyword, topic, or semantic similarity (via vecindex)
- Track usage counts to surface frequently-accessed knowledge

### Adversarial Critic
The critic package runs adversarial review of code changes in two modes:
- **Pattern-based (Review):** Regex detection of hardcoded secrets, SQL injection, debug prints
- **Model-driven (ReviewDeep):** AI model inference via `critic/model_reviewer.go` for semantic issues that patterns miss -- incomplete error handling, logic flaws, security gaps requiring context understanding
- Blocks on severity:block findings, warns on severity:warn
- Runs after execute phase, before cross-model review

### Multi-Model Consensus Engine
The `consensus/` package implements adversarial consensus for mission completion. N models independently verify whether a mission's criteria are satisfied. The mission converges only when a configurable threshold of models agree. This prevents single-model bias and catches issues that one model's blind spots might miss.

### Cross-Surface Dependency Mapping
The `surfacemap/` package extracts API endpoints and their consumers across Go, TypeScript, and Python codebases. It builds a dependency graph showing which services expose which endpoints and which clients consume them. This powers impact analysis during planning -- when a task modifies an API endpoint, stoke knows which downstream consumers need verification.

---
*Last updated: 2026-04-04*
