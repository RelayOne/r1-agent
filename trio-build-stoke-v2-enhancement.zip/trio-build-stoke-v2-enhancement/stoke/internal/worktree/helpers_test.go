package worktree

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func TestSafeWriteFileRejectsTraversal(t *testing.T) {
	dir := t.TempDir()
	err := SafeWriteFile(dir, "../escape.txt", []byte("bad"), 0644)
	if err == nil {
		t.Fatal("expected path traversal rejection")
	}
}

func TestSafeWriteFileRejectsSymlink(t *testing.T) {
	dir := t.TempDir()
	target := filepath.Join(dir, "real.txt")
	os.WriteFile(target, []byte("original"), 0644)
	link := filepath.Join(dir, "link.txt")
	os.Symlink(target, link)

	err := SafeWriteFile(dir, "link.txt", []byte("overwrite"), 0644)
	if err == nil {
		t.Fatal("expected symlink rejection")
	}
	// Original should be unchanged
	data, _ := os.ReadFile(target)
	if string(data) != "original" {
		t.Errorf("symlink target was modified: %q", data)
	}
}

func TestSafeWriteFileSuccess(t *testing.T) {
	dir := t.TempDir()
	err := SafeWriteFile(dir, "sub/file.txt", []byte("hello"), 0644)
	if err != nil {
		t.Fatal(err)
	}
	data, _ := os.ReadFile(filepath.Join(dir, "sub", "file.txt"))
	if string(data) != "hello" {
		t.Errorf("got %q, want %q", data, "hello")
	}
}

func TestSafeWriteFileRejectsParentSymlink(t *testing.T) {
	dir := t.TempDir()
	// Create a symlink directory: dir/evil -> /tmp
	os.Symlink(os.TempDir(), filepath.Join(dir, "evil"))

	err := SafeWriteFile(dir, "evil/escape.txt", []byte("bad"), 0644)
	if err == nil {
		t.Fatal("expected parent directory symlink rejection")
		// Cleanup in case test fails
		os.Remove(filepath.Join(os.TempDir(), "escape.txt"))
	}
}

func TestHashFiles(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "a.txt"), []byte("hello"), 0644)
	os.WriteFile(filepath.Join(dir, "b.txt"), []byte("world"), 0644)

	h := HashFiles(dir, []string{"a.txt", "b.txt", "missing.txt"})
	if h["a.txt"] == "" || h["a.txt"] == "MISSING" {
		t.Error("a.txt should have a hash")
	}
	if h["b.txt"] == "" || h["b.txt"] == "MISSING" {
		t.Error("b.txt should have a hash")
	}
	if h["missing.txt"] != "MISSING" {
		t.Errorf("missing.txt should be MISSING, got %q", h["missing.txt"])
	}
	if h["a.txt"] == h["b.txt"] {
		t.Error("different files should have different hashes")
	}
	// Same content = same hash
	h2 := HashFiles(dir, []string{"a.txt"})
	if h2["a.txt"] != h["a.txt"] {
		t.Error("same file should produce same hash")
	}
}

// initTestRepo creates a bare-bones git repo with one initial commit and returns
// its path. The caller can branch from "main" to simulate parallel workers.
func initTestRepo(t *testing.T) string {
	t.Helper()
	dir := t.TempDir()
	run := func(args ...string) {
		t.Helper()
		cmd := exec.Command("git", args...)
		cmd.Dir = dir
		cmd.Env = append(os.Environ(),
			"GIT_AUTHOR_NAME=test", "GIT_AUTHOR_EMAIL=test@test",
			"GIT_COMMITTER_NAME=test", "GIT_COMMITTER_EMAIL=test@test",
		)
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("git %v failed: %v\n%s", args, err, out)
		}
	}

	run("init", "-b", "main")
	// Initial commit with a file that will be edited on conflicting branches.
	os.WriteFile(filepath.Join(dir, "shared.txt"), []byte("original\n"), 0644)
	os.WriteFile(filepath.Join(dir, "clean.txt"), []byte("untouched\n"), 0644)
	run("add", "-A")
	run("commit", "-m", "initial")
	return dir
}

func TestDryMerge_Clean(t *testing.T) {
	repo := initTestRepo(t)
	ctx := context.Background()

	run := func(args ...string) {
		t.Helper()
		cmd := exec.Command("git", args...)
		cmd.Dir = repo
		cmd.Env = append(os.Environ(),
			"GIT_AUTHOR_NAME=test", "GIT_AUTHOR_EMAIL=test@test",
			"GIT_COMMITTER_NAME=test", "GIT_COMMITTER_EMAIL=test@test",
		)
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("git %v: %v\n%s", args, err, out)
		}
	}

	// Get base commit on main.
	baseCmd := exec.Command("git", "rev-parse", "HEAD")
	baseCmd.Dir = repo
	baseOut, _ := baseCmd.Output()
	baseCommit := filepath.Clean(string(baseOut)) // trim
	baseCommit = string(baseOut[:len(baseOut)-1])  // trim newline

	// Create a worktree branch that touches a different file.
	run("checkout", "-b", "stoke/worker-clean")
	os.WriteFile(filepath.Join(repo, "clean.txt"), []byte("modified by worker\n"), 0644)
	run("add", "-A")
	run("commit", "-m", "worker edits clean.txt")
	run("checkout", "main")

	handle := Handle{
		Name:       "worker-clean",
		Branch:     "stoke/worker-clean",
		Path:       repo,
		BaseCommit: baseCommit,
		RepoRoot:   repo,
		GitBinary:  "git",
	}

	clean, conflicts, err := DryMerge(ctx, handle)
	if err != nil {
		t.Fatalf("DryMerge error: %v", err)
	}
	if !clean {
		t.Errorf("expected clean merge, got conflicts: %v", conflicts)
	}
	if len(conflicts) != 0 {
		t.Errorf("expected no conflicts, got %v", conflicts)
	}
}

func TestDryMerge_Conflict(t *testing.T) {
	repo := initTestRepo(t)
	ctx := context.Background()

	run := func(args ...string) {
		t.Helper()
		cmd := exec.Command("git", args...)
		cmd.Dir = repo
		cmd.Env = append(os.Environ(),
			"GIT_AUTHOR_NAME=test", "GIT_AUTHOR_EMAIL=test@test",
			"GIT_COMMITTER_NAME=test", "GIT_COMMITTER_EMAIL=test@test",
		)
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("git %v: %v\n%s", args, err, out)
		}
	}

	baseCmd := exec.Command("git", "rev-parse", "HEAD")
	baseCmd.Dir = repo
	baseOut, _ := baseCmd.Output()
	baseCommit := string(baseOut[:len(baseOut)-1])

	// Create worker branch that edits shared.txt.
	run("checkout", "-b", "stoke/worker-conflict")
	os.WriteFile(filepath.Join(repo, "shared.txt"), []byte("worker version\n"), 0644)
	run("add", "-A")
	run("commit", "-m", "worker edits shared.txt")
	run("checkout", "main")

	// Now advance main so it diverges on the same file.
	os.WriteFile(filepath.Join(repo, "shared.txt"), []byte("main version\n"), 0644)
	run("add", "-A")
	run("commit", "-m", "main edits shared.txt")

	handle := Handle{
		Name:       "worker-conflict",
		Branch:     "stoke/worker-conflict",
		Path:       repo,
		BaseCommit: baseCommit,
		RepoRoot:   repo,
		GitBinary:  "git",
	}

	clean, conflicts, err := DryMerge(ctx, handle)
	if err != nil {
		t.Fatalf("DryMerge error: %v", err)
	}
	if clean {
		t.Fatal("expected conflict, got clean merge")
	}
	found := false
	for _, f := range conflicts {
		if f == "shared.txt" {
			found = true
		}
	}
	if !found {
		t.Errorf("expected shared.txt in conflicts, got %v", conflicts)
	}
}

func TestConflictsWith(t *testing.T) {
	repo := initTestRepo(t)
	ctx := context.Background()

	run := func(args ...string) {
		t.Helper()
		cmd := exec.Command("git", args...)
		cmd.Dir = repo
		cmd.Env = append(os.Environ(),
			"GIT_AUTHOR_NAME=test", "GIT_AUTHOR_EMAIL=test@test",
			"GIT_COMMITTER_NAME=test", "GIT_COMMITTER_EMAIL=test@test",
		)
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("git %v: %v\n%s", args, err, out)
		}
	}

	baseCmd := exec.Command("git", "rev-parse", "HEAD")
	baseCmd.Dir = repo
	baseOut, _ := baseCmd.Output()
	baseCommit := string(baseOut[:len(baseOut)-1])

	// Worker A edits shared.txt.
	run("checkout", "-b", "stoke/worker-a")
	os.WriteFile(filepath.Join(repo, "shared.txt"), []byte("worker A\n"), 0644)
	run("add", "-A")
	run("commit", "-m", "worker A")
	run("checkout", "main")

	// Worker B also edits shared.txt (conflict with A).
	run("checkout", "-b", "stoke/worker-b")
	os.WriteFile(filepath.Join(repo, "shared.txt"), []byte("worker B\n"), 0644)
	run("add", "-A")
	run("commit", "-m", "worker B")
	run("checkout", "main")

	handle := Handle{
		Name:       "worker-a",
		Branch:     "stoke/worker-a",
		Path:       repo,
		BaseCommit: baseCommit,
		RepoRoot:   repo,
		GitBinary:  "git",
	}

	// Check worker-a against worker-b: should conflict on shared.txt.
	conflicts, err := ConflictsWith(ctx, handle, "stoke/worker-b")
	if err != nil {
		t.Fatalf("ConflictsWith error: %v", err)
	}
	found := false
	for _, f := range conflicts {
		if f == "shared.txt" {
			found = true
		}
	}
	if !found {
		t.Errorf("expected shared.txt conflict between workers, got %v", conflicts)
	}
}

func TestConflictsWith_Clean(t *testing.T) {
	repo := initTestRepo(t)
	ctx := context.Background()

	run := func(args ...string) {
		t.Helper()
		cmd := exec.Command("git", args...)
		cmd.Dir = repo
		cmd.Env = append(os.Environ(),
			"GIT_AUTHOR_NAME=test", "GIT_AUTHOR_EMAIL=test@test",
			"GIT_COMMITTER_NAME=test", "GIT_COMMITTER_EMAIL=test@test",
		)
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("git %v: %v\n%s", args, err, out)
		}
	}

	baseCmd := exec.Command("git", "rev-parse", "HEAD")
	baseCmd.Dir = repo
	baseOut, _ := baseCmd.Output()
	baseCommit := string(baseOut[:len(baseOut)-1])

	// Worker A edits shared.txt.
	run("checkout", "-b", "stoke/worker-c")
	os.WriteFile(filepath.Join(repo, "shared.txt"), []byte("worker C\n"), 0644)
	run("add", "-A")
	run("commit", "-m", "worker C")
	run("checkout", "main")

	// Worker D edits clean.txt (no overlap).
	run("checkout", "-b", "stoke/worker-d")
	os.WriteFile(filepath.Join(repo, "clean.txt"), []byte("worker D\n"), 0644)
	run("add", "-A")
	run("commit", "-m", "worker D")
	run("checkout", "main")

	handle := Handle{
		Name:       "worker-c",
		Branch:     "stoke/worker-c",
		Path:       repo,
		BaseCommit: baseCommit,
		RepoRoot:   repo,
		GitBinary:  "git",
	}

	conflicts, err := ConflictsWith(ctx, handle, "stoke/worker-d")
	if err != nil {
		t.Fatalf("ConflictsWith error: %v", err)
	}
	if len(conflicts) != 0 {
		t.Errorf("expected no conflicts, got %v", conflicts)
	}
}

func TestAppendStokeTrailers(t *testing.T) {
	msg := "feat: add foo"
	got := AppendStokeTrailers(msg, "refactor", "claude", "codex", "standard", 2, 0.0531)

	for _, key := range []string{
		"Stoke-Task-Type:",
		"Stoke-Engine:",
		"Stoke-Reviewer:",
		"Stoke-Tier:",
		"Stoke-Attempts:",
		"Stoke-Cost:",
	} {
		if !strings.Contains(got, key) {
			t.Errorf("missing trailer key %q in output:\n%s", key, got)
		}
	}

	// Verify specific values
	if !strings.Contains(got, "Stoke-Task-Type: refactor") {
		t.Errorf("expected task type 'refactor' in output:\n%s", got)
	}
	if !strings.Contains(got, "Stoke-Attempts: 2") {
		t.Errorf("expected attempts '2' in output:\n%s", got)
	}
	if !strings.Contains(got, "Stoke-Cost: $0.0531") {
		t.Errorf("expected cost '$0.0531' in output:\n%s", got)
	}

	// Verify original message is preserved at the start
	if !strings.HasPrefix(got, msg) {
		t.Errorf("original message not preserved at start")
	}
}

func TestAppendStokeTrailersCostFormat(t *testing.T) {
	got := AppendStokeTrailers("msg", "feature", "codex", "claude", "light", 1, 1.5)
	if !strings.Contains(got, "Stoke-Cost: $1.5000") {
		t.Errorf("cost should be formatted to 4 decimal places, got:\n%s", got)
	}
}

func TestSlug(t *testing.T) {
	tests := []struct {
		input string
		want  string
	}{
		{"Add request ID middleware", "add-request-id-middleware"},
		{"Fix  CRITICAL  bug!!", "fix--critical--bug"},
		{"", ""},
		{"a/b/c", "a-b-c"},
	}
	for _, tt := range tests {
		got := slug(tt.input)
		if got != tt.want {
			t.Errorf("slug(%q) = %q, want %q", tt.input, got, tt.want)
		}
	}
}
