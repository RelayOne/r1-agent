package hooks

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

// HookDecision represents the parsed outcome of a hook execution.
type HookDecision struct {
	Decision      string // "allow", "block", "warn", "modify"
	Reason        string // from stdout JSON
	Output        string // raw stdout
	ModifiedInput string // rewritten tool_input JSON (only when Decision="modify")
}

// ParseHookOutput interprets hook stdout and exit code into a HookDecision.
//   - Exit 0: tries to parse JSON {"decision":"allow"|"block"|"modify"}, falls back to Decision="allow"
//   - Exit 2: tries to parse JSON {"decision":"block","reason":"..."}, falls back to Decision="block"
//   - Other: Decision="warn", Output=stdout
//
// For decision="modify", the JSON must include a "tool_input" field containing valid JSON.
// If tool_input is missing or not valid JSON, the decision is downgraded to "block" (fail-safe).
func ParseHookOutput(stdout string, exitCode int) HookDecision {
	switch exitCode {
	case 0:
		var parsed struct {
			Decision  string `json:"decision"`
			Reason    string `json:"reason"`
			ToolInput string `json:"tool_input"`
		}
		if err := json.Unmarshal([]byte(stdout), &parsed); err == nil && parsed.Decision != "" {
			if parsed.Decision == "modify" {
				// Fail-safe: tool_input must be present and valid JSON
				if parsed.ToolInput == "" || !json.Valid([]byte(parsed.ToolInput)) {
					return HookDecision{
						Decision: "block",
						Reason:   "modify decision requires valid JSON in tool_input",
						Output:   stdout,
					}
				}
				return HookDecision{
					Decision:      "modify",
					Reason:        parsed.Reason,
					Output:        stdout,
					ModifiedInput: parsed.ToolInput,
				}
			}
			return HookDecision{Decision: parsed.Decision, Reason: parsed.Reason, Output: stdout}
		}
		return HookDecision{Decision: "allow", Output: stdout}
	case 2:
		var parsed struct {
			Decision  string `json:"decision"`
			Reason    string `json:"reason"`
			ToolInput string `json:"tool_input"`
		}
		if err := json.Unmarshal([]byte(stdout), &parsed); err == nil && parsed.Decision != "" {
			if parsed.Decision == "modify" {
				if parsed.ToolInput == "" || !json.Valid([]byte(parsed.ToolInput)) {
					return HookDecision{
						Decision: "block",
						Reason:   "modify decision requires valid JSON in tool_input",
						Output:   stdout,
					}
				}
				return HookDecision{
					Decision:      "modify",
					Reason:        parsed.Reason,
					Output:        stdout,
					ModifiedInput: parsed.ToolInput,
				}
			}
			return HookDecision{Decision: parsed.Decision, Reason: parsed.Reason, Output: stdout}
		}
		return HookDecision{Decision: "block", Output: stdout}
	default:
		return HookDecision{Decision: "warn", Output: stdout}
	}
}

// RunHook executes a hook script with a timeout and returns the output.
// timeout: maximum execution time (5s recommended).
// event: the hook event name for logging.
// payload: JSON bytes piped to the script's stdin.
// Returns: stdout output, error (nil on success, non-nil on timeout or failure).
func RunHook(scriptPath string, payload []byte, timeout time.Duration, event string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()

	cmd := exec.CommandContext(ctx, "bash", scriptPath)
	cmd.Stdin = bytes.NewReader(payload)

	var stdout bytes.Buffer
	cmd.Stdout = &stdout

	err := cmd.Run()
	output := stdout.String()

	if ctx.Err() == context.DeadlineExceeded {
		return output, fmt.Errorf("hook %s timed out after %s", event, timeout)
	}

	if err != nil {
		return output, fmt.Errorf("hook %s failed: %w", event, err)
	}

	return output, nil
}

// safeWrite writes data to a file, rejecting symlinks at any path component.
// Prevents symlink redirection attacks where .stoke or CLAUDE.md is a symlink
// pointing outside the repo.
func safeWrite(target string, data []byte, perm os.FileMode) error {
	abs, err := filepath.Abs(target)
	if err != nil {
		return fmt.Errorf("abs path: %w", err)
	}
	// Walk every component checking for symlinks
	parts := strings.Split(abs, string(filepath.Separator))
	check := string(filepath.Separator)
	for _, part := range parts {
		if part == "" {
			continue
		}
		check = filepath.Join(check, part)
		if info, lErr := os.Lstat(check); lErr == nil {
			if info.Mode()&os.ModeSymlink != 0 {
				return fmt.Errorf("symlink rejected at %q (potential repo escape)", check)
			}
		}
	}
	// Use CreateTemp (O_CREATE|O_EXCL) in the target directory to avoid
	// temp-file symlink attacks. target+".tmp" as a symlink would bypass
	// the check above and redirect writes outside the repo.
	dir := filepath.Dir(abs)
	f, err := os.CreateTemp(dir, ".stoke-safe-*")
	if err != nil {
		return fmt.Errorf("create temp: %w", err)
	}
	tmpPath := f.Name()
	if _, err := f.Write(data); err != nil {
		f.Close()
		os.Remove(tmpPath)
		return err
	}
	f.Close()
	os.Chmod(tmpPath, perm)
	if err := os.Rename(tmpPath, abs); err != nil {
		os.Remove(tmpPath)
		return err
	}
	return nil
}

// safeMkdirAll creates directories, rejecting any existing symlinks in the path.
func safeMkdirAll(dir string) error {
	abs, err := filepath.Abs(dir)
	if err != nil {
		return err
	}
	parts := strings.Split(abs, string(filepath.Separator))
	check := string(filepath.Separator)
	for _, part := range parts {
		if part == "" {
			continue
		}
		check = filepath.Join(check, part)
		if info, lErr := os.Lstat(check); lErr == nil {
			if info.Mode()&os.ModeSymlink != 0 {
				return fmt.Errorf("symlink rejected at %q", check)
			}
		}
	}
	return os.MkdirAll(dir, 0755)
}

// Plugin hook integration:
// Plugins discovered by the plugins.Registry can declare hooks for any event
// (e.g. "PreToolUse", "PostToolUse") in their manifest. The workflow layer
// calls Registry.HooksForEvent(event) to collect plugin hook scripts, then
// executes them via RunHook() alongside the built-in enforcer hooks below.
// Plugin hooks run AFTER the built-in hooks: the enforcer guards are always
// evaluated first to ensure security invariants hold regardless of plugins.

// Install writes enforcer hook files into a worktree's .claude/settings.json hooks section.
// These fire during claude -p execution as fast-filter guards.
func Install(runtimeDir string) error {
	hookDir := filepath.Join(runtimeDir, "hooks")
	if err := safeMkdirAll(hookDir); err != nil {
		return fmt.Errorf("create hook dir: %w", err)
	}

	// PreToolUse hook: blocks dangerous patterns before execution
	// Full guard suite from the enforcer: git stash, mass revert, nested claude,
	// protected files, destructive commands, remote code execution
	preToolUse := `#!/bin/bash
# Stoke enforcer hook: PreToolUse guard
# Blocks dangerous tool invocations before they execute.
# Ported from the Claude Code Enforcer setup.sh guard-bash-writes hook.
#
# Hook decisions:
#   {"decision":"allow"}                              - proceed normally
#   {"decision":"block","reason":"..."}               - deny the operation
#   {"decision":"modify","tool_input":"{...}"}        - rewrite tool input (JSON)

# Read tool input from stdin (Claude Code passes JSON on stdin)
INPUT=$(cat)

# Use jq for safe JSON parsing (no regex bypass via whitespace/unicode/field order).
# Fall back to positional args only; this is acceptable for pre-tool guards that
# only see Read/Glob/Grep tool names (Write/Edit carry file paths we can't safely
# parse without jq). The PreToolUse hook also has git pattern checks that don't
# depend on tool_input content being fully extracted.
if command -v jq >/dev/null 2>&1; then
    TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // empty')
    TOOL_INPUT=$(echo "$INPUT" | jq -r '.tool_input // empty')
else
    TOOL_NAME="$1"
    TOOL_INPUT=""
fi
if [ -z "$TOOL_NAME" ]; then
    TOOL_NAME="$1"
fi
if [ -z "$TOOL_INPUT" ]; then
    TOOL_INPUT="$2"
fi

BLOCK() {
    echo "{\"decision\":\"block\",\"reason\":\"$1\"}"
    exit 0
}

# Stale-edit detection: block edits to files modified since last read
if [ "$TOOL_NAME" = "Write" ] || [ "$TOOL_NAME" = "Edit" ]; then
    HASH_FILE="${STOKE_RUNTIME_DIR:-/tmp}/file-access.log"
    if [ -f "$HASH_FILE" ] && [ -n "$TOOL_INPUT" ]; then
        # Extract target file from tool input (jq if available)
        if command -v jq >/dev/null 2>&1; then
            TARGET_FILE=$(echo "$TOOL_INPUT" | jq -r '.file_path // empty')
        fi
        if [ -n "$TARGET_FILE" ] && [ -f "$TARGET_FILE" ]; then
            FILE_MTIME=$(stat -c %Y "$TARGET_FILE" 2>/dev/null || stat -f %m "$TARGET_FILE" 2>/dev/null)
            LAST_READ=$(grep "$TARGET_FILE" "$HASH_FILE" 2>/dev/null | tail -1 | cut -d' ' -f1)
            if [ -n "$LAST_READ" ] && [ -n "$FILE_MTIME" ]; then
                if [ "$FILE_MTIME" -gt "$LAST_READ" ] 2>/dev/null; then
                    BLOCK "Stale edit: $TARGET_FILE was modified since last read. Re-read the file."
                fi
            fi
        fi
    fi
fi

# Block file writes to protected paths
case "$TOOL_NAME" in
    Write|Edit|MultiEdit)
        case "$TOOL_INPUT" in
            *.claude/*|*.stoke/*|*CLAUDE.md*|*.env*|*stoke.policy.yaml*|*settings.json*)
                BLOCK "Protected file: cannot modify .claude/, .stoke/, CLAUDE.md, .env*, or stoke.policy.yaml"
                ;;
        esac
        ;;
esac

# Block dangerous bash commands
if [ "$TOOL_NAME" = "Bash" ]; then
    CMD="$TOOL_INPUT"

    # Git mutations that hide work from verification
    echo "$CMD" | grep -qE '\bgit\s+stash\b' && BLOCK "git stash hides work from verification. Commit or revert."
    echo "$CMD" | grep -q 'git checkout -- \.' && BLOCK "Mass revert. Use specific file paths."
    echo "$CMD" | grep -qE 'git\s+reset\s+--hard' && BLOCK "git reset --hard destroys evidence."
    echo "$CMD" | grep -qE 'git\s+push' && BLOCK "git push blocked. Stoke controls when to push."
    echo "$CMD" | grep -qE 'git\s+rebase' && BLOCK "git rebase blocked in Stoke-managed worktrees."
    echo "$CMD" | grep -qE 'git\s+commit.*--no-verify' && BLOCK "git commit --no-verify blocked. Hooks must run."
    echo "$CMD" | grep -qE 'git\s+force' && BLOCK "Force operations blocked."

    # Nested Claude/Codex sessions
    echo "$CMD" | grep -qE '\bclaude\b.*--dangerously-skip-permissions' && BLOCK "Cannot spawn nested Claude sessions."
    echo "$CMD" | grep -qE '\bclaude\b.*-p\b' && BLOCK "Cannot spawn nested Claude headless sessions."
    echo "$CMD" | grep -qE '\bcodex\b.*exec\b' && BLOCK "Cannot spawn nested Codex sessions."

    # Destructive commands
    echo "$CMD" | grep -qE 'rm\s+-rf\s+/' && BLOCK "Destructive: rm -rf / blocked."
    echo "$CMD" | grep -qE 'rm\s+-rf\s+~' && BLOCK "Destructive: rm -rf ~ blocked."
    echo "$CMD" | grep -qE '\bsudo\s+rm\b' && BLOCK "Destructive: sudo rm blocked."
    echo "$CMD" | grep -qE 'chmod\s+-R\s+777' && BLOCK "Destructive: chmod -R 777 blocked."

    # Remote code execution
    echo "$CMD" | grep -qE 'curl.*\|\s*bash' && BLOCK "Remote code execution: curl | bash blocked."
    echo "$CMD" | grep -qE 'wget.*-O\s*-.*\|\s*sh' && BLOCK "Remote code execution: wget | sh blocked."

    # Hook/settings tampering
    echo "$CMD" | grep -qE 'rm.*\.stoke/hooks' && BLOCK "Cannot remove Stoke hooks."
    echo "$CMD" | grep -qE 'chmod.*\.stoke/hooks' && BLOCK "Cannot modify Stoke hook permissions."
fi

# Allow everything else
echo '{"decision":"allow"}'
`

	// PostToolUse hook: detects policy violations after execution
	postToolUse := `#!/bin/bash
# Stoke enforcer hook: PostToolUse monitor
# Detects policy violations after tool execution.

TOOL_NAME="$1"
TOOL_OUTPUT="$2"

# Check for type bypass patterns in write output.
# Patterns are stored as separate fixed strings to avoid the guard script itself
# triggering a false-positive match (e.g. unsafe cast strings in a comment).
# Single-dash variants used here; double-dash is what TypeScript/eslint actually use.
BYPASS_PATTERNS="-ts-ignore -ts-expect-error -eslint -type:ignore -noqa -.only("
if [ "$TOOL_NAME" = "Write" ] || [ "$TOOL_NAME" = "Edit" ]; then
    for pat in $BYPASS_PATTERNS; do
        case "$TOOL_OUTPUT" in
            *"$pat"*)
                echo '{"warning":"Policy violation detected: type/lint bypass in written code"}'
                break
                ;;
        esac
    done
    # Also catch unsafe type casts: look for " as " followed by a type identifier
    if echo "$TOOL_OUTPUT" | grep -qF ' as ' 2>/dev/null; then
        echo '{"warning":"Policy violation detected: type cast in written code"}'
    fi
fi

# Check for secret leaks in bash output
if [ "$TOOL_NAME" = "Bash" ]; then
    if echo "$TOOL_OUTPUT" | grep -qiE 'sk-[a-zA-Z0-9]{20,}|AKIA[A-Z0-9]{16}|ghp_[a-zA-Z0-9]{36}' 2>/dev/null; then
        echo '{"warning":"Possible secret leak detected in command output"}'
    fi
fi

# Record file access timestamps for stale-edit detection
if [ "$TOOL_NAME" = "Read" ]; then
    HASH_FILE="${STOKE_RUNTIME_DIR:-/tmp}/file-access.log"
    # Append file path + timestamp (flock for concurrency safety)
    (flock -n 200 && echo "$(date +%s) $TOOL_INPUT" >> "$HASH_FILE") 200>"$HASH_FILE.lock" 2>/dev/null
fi
`

	if err := safeWrite(filepath.Join(hookDir, "pre-tool-use.sh"), []byte(preToolUse), 0755); err != nil {
		return err
	}
	if err := safeWrite(filepath.Join(hookDir, "post-tool-use.sh"), []byte(postToolUse), 0755); err != nil {
		return err
	}

	// Stop hook: fires when the agent attempts to finish. Exit 0 = allow, exit 2 = block.
	// Default: always allow. TASK-21 will add completion promise checking logic.
	stop := `#!/bin/bash
# Stoke enforcer hook: Stop guard
# Fires when the agent attempts to complete. Exit 0 = allow, exit 2 = block.
INPUT=$(cat)
# Default: allow stop
echo '{"decision":"allow"}'
`

	// SessionStart hook: informational event when a Stoke workflow begins
	sessionStart := `#!/bin/bash
# Stoke enforcer hook: SessionStart
# Fires when a Stoke workflow begins. Informational only.
INPUT=$(cat)
# No decision needed — informational hook
`

	// SessionEnd hook: informational event when a Stoke workflow finishes
	sessionEnd := `#!/bin/bash
# Stoke enforcer hook: SessionEnd
# Fires when a Stoke workflow finishes. Informational only.
INPUT=$(cat)
`

	// PostToolUseFailure hook: informational event when a tool invocation fails
	postToolFailure := `#!/bin/bash
# Stoke enforcer hook: PostToolUseFailure
# Fires when a tool invocation fails. Informational only.
INPUT=$(cat)
`

	// PreCompact hook: informational event before context compaction
	// Hook stdout is captured and included in compacted context.
	preCompact := `#!/bin/bash
# Stoke enforcer hook: PreCompact
# Fires before context compaction. Informational only.
INPUT=$(cat)
`

	if err := safeWrite(filepath.Join(hookDir, "stop.sh"), []byte(stop), 0755); err != nil {
		return err
	}
	if err := safeWrite(filepath.Join(hookDir, "session-start.sh"), []byte(sessionStart), 0755); err != nil {
		return err
	}
	if err := safeWrite(filepath.Join(hookDir, "session-end.sh"), []byte(sessionEnd), 0755); err != nil {
		return err
	}
	if err := safeWrite(filepath.Join(hookDir, "post-tool-failure.sh"), []byte(postToolFailure), 0755); err != nil {
		return err
	}
	if err := safeWrite(filepath.Join(hookDir, "pre-compact.sh"), []byte(preCompact), 0755); err != nil {
		return err
	}

	return nil
}

// HooksConfig returns the Claude Code hooks configuration for settings.json.
// This tells Claude Code to call our hook scripts on tool use events.
func HooksConfig(runtimeDir string) map[string]interface{} {
	hookDir := filepath.Join(runtimeDir, "hooks")
	return map[string]interface{}{
		"hooks": map[string]interface{}{
			"PreToolUse": []map[string]interface{}{
				{
					"type":    "command",
					"command": filepath.Join(hookDir, "pre-tool-use.sh"),
				},
			},
			"PostToolUse": []map[string]interface{}{
				{
					"type":    "command",
					"command": filepath.Join(hookDir, "post-tool-use.sh"),
				},
			},
			"Stop": []map[string]interface{}{
				{
					"type":    "command",
					"command": filepath.Join(hookDir, "stop.sh"),
				},
			},
			"SessionStart": []map[string]interface{}{
				{
					"type":    "command",
					"command": filepath.Join(hookDir, "session-start.sh"),
				},
			},
			"SessionEnd": []map[string]interface{}{
				{
					"type":    "command",
					"command": filepath.Join(hookDir, "session-end.sh"),
				},
			},
			"PostToolUseFailure": []map[string]interface{}{
				{
					"type":    "command",
					"command": filepath.Join(hookDir, "post-tool-failure.sh"),
				},
			},
			"PreCompact": []map[string]interface{}{
				{
					"type":    "command",
					"command": filepath.Join(hookDir, "pre-compact.sh"),
				},
			},
		},
	}
}

// Cleanup removes hook files from a runtime directory.
func Cleanup(runtimeDir string) {
	os.RemoveAll(filepath.Join(runtimeDir, "hooks"))
}

// InstallInRepo installs hooks directly in a repo (for yolo/scope interactive modes).
// Unlike Install() which writes to RuntimeDir for headless mode, this writes to
// repoRoot/.stoke/hooks/ so that GenerateSettings() can reference them.
func InstallInRepo(repoRoot string) error {
	stokeDir := filepath.Join(repoRoot, ".stoke")
	return Install(stokeDir)
}

// GenerateSettings writes a claude-settings.json for interactive mode.
// mode: "yolo" (full tools) or "scope" (read-only + plan output)
// outputFile: for scope mode, the one file Write is allowed to (e.g. "stoke-plan.json")
func GenerateSettings(repoRoot, mode, outputFile string) (string, error) {
	settingsDir := filepath.Join(repoRoot, ".stoke", "generated")
	if err := safeMkdirAll(settingsDir); err != nil {
		return "", err
	}

	hookDir := filepath.Join(repoRoot, ".stoke", "hooks")
	settings := map[string]interface{}{
		"hooks": map[string]interface{}{
			"PreToolUse": []map[string]interface{}{
				{"type": "command", "command": filepath.Join(hookDir, "pre-tool-use.sh")},
			},
			"PostToolUse": []map[string]interface{}{
				{"type": "command", "command": filepath.Join(hookDir, "post-tool-use.sh")},
			},
			"Stop": []map[string]interface{}{
				{"type": "command", "command": filepath.Join(hookDir, "stop.sh")},
			},
			"SessionStart": []map[string]interface{}{
				{"type": "command", "command": filepath.Join(hookDir, "session-start.sh")},
			},
			"SessionEnd": []map[string]interface{}{
				{"type": "command", "command": filepath.Join(hookDir, "session-end.sh")},
			},
			"PostToolUseFailure": []map[string]interface{}{
				{"type": "command", "command": filepath.Join(hookDir, "post-tool-failure.sh")},
			},
			"PreCompact": []map[string]interface{}{
				{"type": "command", "command": filepath.Join(hookDir, "pre-compact.sh")},
			},
		},
		"permissions": map[string]interface{}{
			"allow": []string{},
			"deny":  []string{},
		},
	}

	if mode == "yolo" {
		settings["permissions"] = map[string]interface{}{
			"allow": []string{"Read", "Write", "Edit", "MultiEdit", "Bash", "Glob", "Grep"},
		}
	} else {
		// scope: read + write only to the plan output file
		// Write is allowed so Claude can save the plan artifact.
		// The PreToolUse hook blocks protected files.
		// Bash is denied to keep the session non-destructive.
		settings["permissions"] = map[string]interface{}{
			"allow": []string{"Read", "Write", "Glob", "Grep", "WebSearch", "WebFetch"},
			"deny":  []string{"Edit", "MultiEdit", "Bash"},
		}
	}

	// Suppress repo-supplied API key helpers (Mode 1 enforcement)
	settings["apiKeyHelper"] = nil

	data, err := json.MarshalIndent(settings, "", "  ")
	if err != nil {
		return "", err
	}

	path := filepath.Join(settingsDir, fmt.Sprintf("claude-%s-settings.json", mode))
	if err := safeWrite(path, data, 0600); err != nil {
		return "", err
	}

	// For scope: install a scope-specific write guard that only allows the plan output
	if mode == "scope" && outputFile != "" {
		installScopeWriteGuard(repoRoot, outputFile)
	}

	return path, nil
}

// installScopeWriteGuard overwrites the PreToolUse hook to only allow writes to the plan file.
// The allowed path is written to a separate file to prevent shell injection via crafted file paths.
func installScopeWriteGuard(repoRoot, allowedFile string) {
	hookDir := filepath.Join(repoRoot, ".stoke", "hooks")
	absAllowed := filepath.Join(repoRoot, allowedFile)

	// Write allowed paths to a separate file — never embed in bash script.
	// This file is 0600 to prevent other users reading the allowed path.
	allowedPathFile := filepath.Join(hookDir, "allowed-path.txt")
	pathData := absAllowed + "\n" + allowedFile + "\n"
	if err := safeWrite(allowedPathFile, []byte(pathData), 0600); err != nil {
		return
	}

	guard := `#!/bin/bash
# Stoke scope guard: only allows writes to the plan output file.
# Allowed path is read from allowed-path.txt (never embedded in script).
INPUT=$(cat)

# Use jq for safe JSON parsing
if command -v jq >/dev/null 2>&1; then
    TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // empty')
else
    TOOL_NAME=""
fi
if [ -z "$TOOL_NAME" ]; then TOOL_NAME="$1"; fi

if [ "$TOOL_NAME" = "Write" ]; then
    SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
    ALLOWED_PATH_FILE="$SCRIPT_DIR/allowed-path.txt"
    if [ ! -f "$ALLOWED_PATH_FILE" ]; then
        echo '{"decision":"block","reason":"Scope guard: allowed-path.txt missing"}'
        exit 0
    fi
    # Read only the first line — absolute path. Second line (relative) is present but unused.
    ALLOWED=$(sed -n '1p' "$ALLOWED_PATH_FILE")

    if command -v jq >/dev/null 2>&1; then
        FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')
    else
        FILE_PATH=""
    fi
    # Canonicalise the requested path to catch symlink/dot-dot escapes
    REAL_PATH=$(realpath "$FILE_PATH" 2>/dev/null || echo "$FILE_PATH")
    if [ "$REAL_PATH" = "$ALLOWED" ]; then
        echo '{"decision":"allow"}'
        exit 0
    fi
    echo "{\"decision\":\"block\",\"reason\":\"Scope mode: writes only allowed to one file\"}"
    exit 0
fi

echo '{"decision":"allow"}'
`

	safeWrite(filepath.Join(hookDir, "pre-tool-use.sh"), []byte(guard), 0755)
}

// GenerateCLAUDEmd writes a CLAUDE.md file with Stoke context for interactive sessions.
// outputFile: for scope mode, the allowed plan output path.
func GenerateCLAUDEmd(repoRoot, mode, outputFile string) error {
	content := `# Stoke-Managed Session

This repo is under Stoke orchestration. Rules:

## Non-negotiable
- Do NOT modify .stoke/, .claude/, CLAUDE.md, or .env files
- Do NOT use git push, git reset --hard, git rebase, or git stash
- Do NOT spawn nested claude or codex sessions
- Do NOT use --no-verify on git commits
- Do NOT classify failures as "pre-existing" or "out of scope"
- Do NOT mark tasks as FIXED without a real commit hash

## Quality
- No type-ignores, unsafe casts, lint-disable comments, or commented-out tests
- No empty catch blocks
- No incomplete or skeletal code
- No tautological tests (expect(true).toBe(true))
- No disabled or skipped tests

## Workflow
- One task at a time
- Commit after each completed task: git add -A && git commit -m "feat(TASK-ID): description"
- Run build/test/lint before claiming done
- If blocked, say BLOCKED with reason -- do not fake progress
`

	if mode == "scope" {
		content += fmt.Sprintf(`
## Scope Mode
- You are in SCOPE mode. Read the codebase, discuss with the user, plan what to build.
- You CAN read any file (Read, Glob, Grep).
- You CAN write ONLY to: %s
- You CANNOT edit existing files, run bash commands, or modify anything else.
- When the plan is ready, save it as valid JSON to %s using the Write tool.
- The JSON should follow this format:
  {"id": "plan-YYYYMMDD", "description": "...", "tasks": [{"id": "TASK-1", "description": "...", "files": [...], "dependencies": [], "type": "refactor"}]}
`, outputFile, outputFile)
	}

	return safeWrite(filepath.Join(repoRoot, "CLAUDE.md"), []byte(content), 0600)
}
