package workflow

import (
	"context"
	"os"
	"strings"
	"testing"

	"github.com/ericmacdougall/stoke/internal/config"
	"github.com/ericmacdougall/stoke/internal/engine"
	"github.com/ericmacdougall/stoke/internal/failure"
	"github.com/ericmacdougall/stoke/internal/model"
	"github.com/ericmacdougall/stoke/internal/subscriptions"
	"github.com/ericmacdougall/stoke/internal/verify"
	"github.com/ericmacdougall/stoke/internal/worktree"
)

func TestDryRunWorkflowBuildsCommands(t *testing.T) {
	repo := t.TempDir()
	policy := config.DefaultPolicy()
	wf := Engine{
		RepoRoot:     repo,
		Task:         "Update the README",
		TaskType:     model.TaskTypeDocs,
		WorktreeName: "docs-task",
		AuthMode:     engine.AuthModeSubscription,
		Policy:       policy,
		DryRun:       true,
		Pools:        subscriptions.NewManager(nil),
		Worktrees:    stubManager{repo: repo},
		Runners:      engine.Registry{Claude: engine.NewClaudeRunner("claude"), Codex: engine.NewCodexRunner("codex")},
		Verifier:     verify.NewPipeline("", "", ""),
	}
	result, err := wf.Run(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if len(result.Steps) != 3 {
		t.Fatalf("expected 3 phases, got %d", len(result.Steps))
	}
	if !strings.Contains(result.Render(), "plan") {
		t.Fatalf("expected render output to include plan phase")
	}
	if !strings.Contains(result.Render(), "Stoke") {
		t.Error("render should say Stoke, not Forge")
	}
}

func TestDryRunPhaseEngineRouting(t *testing.T) {
	repo := t.TempDir()
	wf := Engine{
		RepoRoot:     repo,
		Task:         "Add Docker support",
		TaskType:     model.TaskTypeDevOps,
		WorktreeName: "devops-task",
		AuthMode:     engine.AuthModeSubscription,
		Policy:       config.DefaultPolicy(),
		DryRun:       true,
		Pools:        subscriptions.NewManager(nil),
		Worktrees:    stubManager{repo: repo},
		Runners:      engine.Registry{Claude: engine.NewClaudeRunner("claude"), Codex: engine.NewCodexRunner("codex")},
		Verifier:     verify.NewPipeline("", "", ""),
	}
	result, err := wf.Run(context.Background())
	if err != nil {
		t.Fatal(err)
	}

	// Plan always uses Claude
	if result.Steps[0].Engine != "claude" {
		t.Errorf("plan engine=%q, want claude", result.Steps[0].Engine)
	}
	// DevOps execute should use Codex per routing table
	if result.Steps[1].Engine != "codex" {
		t.Errorf("execute engine=%q, want codex for devops", result.Steps[1].Engine)
	}
}

func TestBuildRetryPromptIncludesFailureContext(t *testing.T) {
	analysis := &failure.Analysis{
		Class:     failure.BuildFailed,
		Summary:   "2 TypeScript errors in src/auth.ts",
		RootCause: "Property 'user' does not exist on type 'Request'",
		Specifics: []failure.Detail{
			{File: "src/auth.ts", Line: 45, Message: "TS2339: Property 'user' missing", Fix: "extend Express Request type"},
		},
	}

	prompt := buildRetryPrompt("Original task: add auth", 2, analysis, "src/auth.ts | 45 +++")

	if !strings.Contains(prompt, "RETRY CONTEXT (attempt 2)") {
		t.Error("should include attempt number")
	}
	if !strings.Contains(prompt, "2 TypeScript errors") {
		t.Error("should include failure summary")
	}
	if !strings.Contains(prompt, "Property 'user'") {
		t.Error("should include root cause")
	}
	if !strings.Contains(prompt, "src/auth.ts:45") {
		t.Error("should include specific file:line")
	}
	if !strings.Contains(prompt, "extend Express Request type") {
		t.Error("should include suggested fix")
	}
	if !strings.Contains(prompt, "src/auth.ts | 45 +++") {
		t.Error("should include diff summary")
	}
	if !strings.Contains(prompt, "DO NOT") {
		t.Error("should include constraints")
	}
}

func TestBuildRetryPromptPolicyViolation(t *testing.T) {
	analysis := &failure.Analysis{Class: failure.PolicyViolation, Summary: "ts-ignore used"}
	prompt := buildRetryPrompt("task", 2, analysis, "")
	if !strings.Contains(prompt, "@ts-ignore") {
		t.Error("policy violation retry should warn about ts-ignore")
	}
}

func TestBuildRetryPromptWrongFiles(t *testing.T) {
	analysis := &failure.Analysis{Class: failure.WrongFiles, Summary: "out of scope"}
	prompt := buildRetryPrompt("task", 2, analysis, "")
	if !strings.Contains(prompt, "outside the task scope") {
		t.Error("wrong files retry should warn about scope")
	}
}

func TestBuildRetryPromptNoDiff(t *testing.T) {
	analysis := &failure.Analysis{Class: failure.BuildFailed, Summary: "errors"}
	prompt := buildRetryPrompt("task", 2, analysis, "(diff unavailable)")
	if strings.Contains(prompt, "CHANGES FROM PREVIOUS ATTEMPT") {
		t.Error("should not include diff section when unavailable")
	}
}

func TestSlugFromTask(t *testing.T) {
	tests := []struct {
		input string
		want  string
	}{
		{"Add request ID middleware", "add-request-id-middleware"},
		{"", "task"},
		{"A/B/C", "a-b-c"},
		{"Short", "short"},
	}
	for _, tt := range tests {
		got := slugFromTask(tt.input)
		if got != tt.want {
			t.Errorf("slugFromTask(%q) = %q, want %q", tt.input, got, tt.want)
		}
	}
}

func TestSlugTruncation(t *testing.T) {
	long := strings.Repeat("a", 100)
	got := slugFromTask(long)
	if len(got) > 32 {
		t.Errorf("slug length=%d, should be <= 32", len(got))
	}
}

func TestResultRenderIncludesCost(t *testing.T) {
	r := Result{
		WorktreePath: "/tmp/test",
		Branch:       "stoke/test",
		TaskType:     model.TaskTypeRefactor,
		TotalCostUSD: 0.1234,
	}
	rendered := r.Render()
	if !strings.Contains(rendered, "0.1234") {
		t.Error("render should include cost")
	}
}

// --- containsPromise tests ---

func TestContainsPromiseDirectMatch(t *testing.T) {
	output := "I have completed the task. all tests pass. Done."
	if !containsPromise(output, "all tests pass") {
		t.Error("expected direct match to return true")
	}
}

func TestContainsPromiseCaseInsensitive(t *testing.T) {
	output := "All Tests Pass and the build succeeds."
	if !containsPromise(output, "all tests pass") {
		t.Error("expected case-insensitive match to return true")
	}
}

func TestContainsPromiseWhitespaceNormalized(t *testing.T) {
	output := "Result: all tests pass confirmed."
	if !containsPromise(output, "all  tests   pass") {
		t.Error("expected whitespace-normalized match to return true")
	}
}

func TestContainsPromiseInTag(t *testing.T) {
	output := "Work complete.\n<promise>all tests pass</promise>\nDone."
	if !containsPromise(output, "all tests pass") {
		t.Error("expected promise in <promise> tag to return true")
	}
}

func TestContainsPromiseNotFound(t *testing.T) {
	output := "I made some changes to the codebase."
	if containsPromise(output, "all tests pass") {
		t.Error("expected non-matching output to return false")
	}
}

func TestContainsPromiseEmptyPromise(t *testing.T) {
	output := "Any output at all."
	if !containsPromise(output, "") {
		t.Error("expected empty promise to return true")
	}
	if !containsPromise(output, "   ") {
		t.Error("expected whitespace-only promise to return true")
	}
}

func TestContainsPromisePartialMatch(t *testing.T) {
	output := "I ran all tests but some failed."
	if containsPromise(output, "all tests pass") {
		t.Error("expected partial match to return false")
	}
}

// --- parseReflection tests ---

func TestParseReflectionValid(t *testing.T) {
	output := `Some agent output here.
<reflection>
WHAT_WORKED: incremental testing after each change
WHAT_FAILED: tried to refactor too many files at once
SURPRISE: the config package has no tests at all
FOR_NEXT_TASK: run go vet early to catch interface mismatches
</reflection>
Done.`

	got := parseReflection(output)
	expected := map[string]string{
		"WHAT_WORKED":   "incremental testing after each change",
		"WHAT_FAILED":   "tried to refactor too many files at once",
		"SURPRISE":      "the config package has no tests at all",
		"FOR_NEXT_TASK": "run go vet early to catch interface mismatches",
	}
	for k, want := range expected {
		if got[k] != want {
			t.Errorf("parseReflection[%q] = %q, want %q", k, got[k], want)
		}
	}
	if len(got) != len(expected) {
		t.Errorf("parseReflection returned %d keys, want %d", len(got), len(expected))
	}
}

func TestParseReflectionNoTag(t *testing.T) {
	output := "Just some normal agent output with no reflection block."
	got := parseReflection(output)
	if len(got) != 0 {
		t.Errorf("expected empty map for no reflection tag, got %v", got)
	}
}

func TestParseReflectionMalformed(t *testing.T) {
	// Only opening tag, no closing tag
	output := `<reflection>
WHAT_WORKED: this should not parse
`
	got := parseReflection(output)
	if len(got) != 0 {
		t.Errorf("expected empty map for missing closing tag, got %v", got)
	}

	// Partial content: some lines have colons, some don't
	output2 := `<reflection>
WHAT_WORKED: partial parse works
this line has no colon-space separator
FOR_NEXT_TASK: advice here
</reflection>`
	got2 := parseReflection(output2)
	if got2["WHAT_WORKED"] != "partial parse works" {
		t.Errorf("expected WHAT_WORKED to parse, got %q", got2["WHAT_WORKED"])
	}
	if got2["FOR_NEXT_TASK"] != "advice here" {
		t.Errorf("expected FOR_NEXT_TASK to parse, got %q", got2["FOR_NEXT_TASK"])
	}
	if len(got2) != 2 {
		t.Errorf("expected 2 parseable keys, got %d: %v", len(got2), got2)
	}
}

// --- context_exceeded recovery tests ---

// TestContextExceededRecoveryCounterIsSeparate verifies that recovery attempts
// for context_exceeded are tracked separately from retry attempts, and that
// the recovery counter has its own independent limit.
func TestContextExceededRecoveryCounterIsSeparate(t *testing.T) {
	// The recovery mechanism uses a separate counter (recoveryAttempts)
	// from the main retry loop (attempt). Verify the limits are independent.
	maxAttempts := 3
	maxRecoveryAttempts := 2
	recoveryAttempts := 0

	// Simulate: each attempt hits context_exceeded, recovery should be capped
	for attempt := 1; attempt <= maxAttempts; attempt++ {
		subtype := "context_exceeded"
		if subtype == "context_exceeded" {
			recoveryAttempts++
			if recoveryAttempts > maxRecoveryAttempts {
				// Should stop here
				break
			}
			// Recovery doesn't consume a retry attempt
			attempt--
			continue
		}
	}

	if recoveryAttempts != maxRecoveryAttempts+1 {
		t.Errorf("recoveryAttempts = %d, want %d (should exceed limit then stop)", recoveryAttempts, maxRecoveryAttempts+1)
	}
}

// TestContextExceededSubtypeDetection verifies that the "context_exceeded"
// subtype is distinct from "rate_limited" and triggers different handling.
func TestContextExceededSubtypeDetection(t *testing.T) {
	subtypes := map[string]string{
		"context_exceeded": "recovery",
		"rate_limited":     "rotation",
		"success":          "continue",
	}

	for subtype, expectedAction := range subtypes {
		action := "continue"
		if subtype == "context_exceeded" {
			action = "recovery"
		} else if subtype == "rate_limited" {
			action = "rotation"
		}
		if action != expectedAction {
			t.Errorf("subtype %q: got action %q, want %q", subtype, action, expectedAction)
		}
	}
}

// --- stubs ---

type stubManager struct{ repo string }

func (s stubManager) Prepare(_ context.Context, explicitName string) (worktree.Handle, error) {
	path := s.repo + "/.stoke/worktrees/" + explicitName
	runtimeDir := os.TempDir() + "/stoke-test-runtime-" + explicitName
	os.MkdirAll(runtimeDir, 0o755)
	return worktree.Handle{Name: explicitName, Branch: "stoke/" + explicitName, Path: path, RuntimeDir: runtimeDir, BaseCommit: "abc123", RepoRoot: s.repo, GitBinary: "git"}, nil
}

func (s stubManager) Merge(_ context.Context, _ worktree.Handle, _ string) error { return nil }
func (s stubManager) Cleanup(_ context.Context, _ worktree.Handle) error        { return nil }
