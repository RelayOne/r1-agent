package workflow

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/ericmacdougall/stoke/internal/config"
	"github.com/ericmacdougall/stoke/internal/engine"
	"github.com/ericmacdougall/stoke/internal/failure"
	"github.com/ericmacdougall/stoke/internal/model"
	"github.com/ericmacdougall/stoke/internal/scan"
	"github.com/ericmacdougall/stoke/internal/subscriptions"
	"github.com/ericmacdougall/stoke/internal/taskstate"
	"github.com/ericmacdougall/stoke/internal/verify"
	"github.com/ericmacdougall/stoke/internal/worktree"
)

// ============================================================================
// Mock implementations
// ============================================================================

// MockRunnerCall records one Run invocation with the full RunSpec.
type MockRunnerCall struct {
	Spec engine.RunSpec
}

// MockRunner implements engine.CommandRunner with configurable results.
// Results are consumed in order; the last entry repeats for excess calls.
type MockRunner struct {
	mu      sync.Mutex
	calls   []MockRunnerCall
	results []engine.RunResult
	runErr  error
}

func newMockRunner(results ...engine.RunResult) *MockRunner {
	return &MockRunner{results: results}
}

func (m *MockRunner) Prepare(spec engine.RunSpec) (engine.PreparedCommand, error) {
	return engine.PreparedCommand{
		Binary: "mock",
		Args:   []string{spec.Phase.Name},
		Dir:    spec.WorktreeDir,
	}, nil
}

func (m *MockRunner) Run(_ context.Context, spec engine.RunSpec, _ engine.OnEventFunc) (engine.RunResult, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	m.calls = append(m.calls, MockRunnerCall{Spec: spec})

	if m.runErr != nil {
		return engine.RunResult{}, m.runErr
	}

	idx := len(m.calls) - 1
	if idx >= len(m.results) {
		idx = len(m.results) - 1
	}
	if idx < 0 {
		return engine.RunResult{Subtype: "success"}, nil
	}
	return m.results[idx], nil
}

func (m *MockRunner) Calls() []MockRunnerCall {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make([]MockRunnerCall, len(m.calls))
	copy(out, m.calls)
	return out
}

// MockWorktreeManager uses real git worktrees in a temp repo so that
// CommitVerifiedTree, ValidateMerge, DiffSummary, etc. all work correctly.
type MockWorktreeManager struct {
	mu           sync.Mutex
	repoRoot     string
	prepareCount int
	mergeCount   int
	cleanupCount int
	mergeErr     error
}

func newMockWorktreeManager(t *testing.T) *MockWorktreeManager {
	t.Helper()
	dir := t.TempDir()
	initGitDir(dir)
	return &MockWorktreeManager{repoRoot: dir}
}

func (m *MockWorktreeManager) Prepare(_ context.Context, name string) (worktree.Handle, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.prepareCount++

	// Capture base commit BEFORE creating the worktree branch.
	baseOut, err := exec.Command("git", "-C", m.repoRoot, "rev-parse", "HEAD").Output()
	if err != nil {
		return worktree.Handle{}, fmt.Errorf("rev-parse: %w", err)
	}
	baseCommit := strings.TrimSpace(string(baseOut))

	branch := "stoke/" + name
	wtPath := filepath.Join(m.repoRoot, ".stoke", "worktrees", name)
	os.MkdirAll(filepath.Dir(wtPath), 0o755)

	// Clean up any prior worktree/branch with the same name.
	exec.Command("git", "-C", m.repoRoot, "worktree", "remove", "--force", wtPath).Run()
	exec.Command("git", "-C", m.repoRoot, "branch", "-D", branch).Run()
	exec.Command("git", "-C", m.repoRoot, "worktree", "prune").Run()

	// Create a real git worktree so merge-tree, diff, etc. all work.
	cmd := exec.Command("git", "-C", m.repoRoot, "worktree", "add", wtPath, "-b", branch)
	if out, err := cmd.CombinedOutput(); err != nil {
		return worktree.Handle{}, fmt.Errorf("worktree add: %w: %s", err, out)
	}

	runtimeDir := filepath.Join(os.TempDir(), "stoke-test-rt-"+name)
	os.RemoveAll(runtimeDir)
	os.MkdirAll(runtimeDir, 0o755)

	return worktree.Handle{
		Name:       name,
		Branch:     branch,
		Path:       wtPath,
		RuntimeDir: runtimeDir,
		BaseCommit: baseCommit,
		RepoRoot:   m.repoRoot,
		GitBinary:  "git",
	}, nil
}

func (m *MockWorktreeManager) Merge(_ context.Context, h worktree.Handle, message string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.mergeCount++
	if m.mergeErr != nil {
		return m.mergeErr
	}
	// Perform real merge so state is consistent.
	cmd := exec.Command("git", "merge", "--no-ff", h.Branch, "-m", message)
	cmd.Dir = m.repoRoot
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("merge: %w: %s", err, out)
	}
	return nil
}

func (m *MockWorktreeManager) Cleanup(_ context.Context, h worktree.Handle) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.cleanupCount++
	if h.RuntimeDir != "" {
		os.RemoveAll(h.RuntimeDir)
	}
	exec.Command("git", "-C", m.repoRoot, "worktree", "remove", "--force", h.Path).Run()
	exec.Command("git", "-C", m.repoRoot, "branch", "-D", h.Branch).Run()
	exec.Command("git", "-C", m.repoRoot, "worktree", "prune").Run()
	return nil
}

// filePlantingRunner wraps a MockRunner and creates committed files
// in the worktree during execute so that git diff reports real changes.
type filePlantingRunner struct {
	inner *MockRunner
	files map[string]string // filename -> content
}

func newCleanPlanter(inner *MockRunner) *filePlantingRunner {
	return &filePlantingRunner{
		inner: inner,
		files: map[string]string{"feature.txt": "new feature\n"},
	}
}

func newSlopPlanter(inner *MockRunner) *filePlantingRunner {
	return &filePlantingRunner{
		inner: inner,
		files: map[string]string{
			"slop.go": "package main\n\nimport \"fmt\"\n\nfunc bad() error {\n\treturn fmt.Errorf(\"\")\n}\n",
		},
	}
}

// newMultiFilePlanter creates 4 files with 60+ total lines to push into TierStandard.
func newMultiFilePlanter(inner *MockRunner) *filePlantingRunner {
	lines := strings.Repeat("line\n", 20)
	return &filePlantingRunner{
		inner: inner,
		files: map[string]string{
			"a.txt": lines,
			"b.txt": lines,
			"c.txt": lines,
			"d.txt": lines,
		},
	}
}

func (f *filePlantingRunner) Prepare(spec engine.RunSpec) (engine.PreparedCommand, error) {
	return f.inner.Prepare(spec)
}

func (f *filePlantingRunner) Run(ctx context.Context, spec engine.RunSpec, onEvent engine.OnEventFunc) (engine.RunResult, error) {
	if spec.Phase.Name == "execute" {
		for name, content := range f.files {
			plantPath := filepath.Join(spec.WorktreeDir, name)
			os.MkdirAll(filepath.Dir(plantPath), 0o755)
			os.WriteFile(plantPath, []byte(content), 0o644)
		}
		cmd := exec.Command("git", "add", "-A")
		cmd.Dir = spec.WorktreeDir
		cmd.Run()
		cmd = exec.Command("git", "commit", "-m", "agent work")
		cmd.Dir = spec.WorktreeDir
		cmd.Run()
	}
	return f.inner.Run(ctx, spec, onEvent)
}

// ============================================================================
// Helpers
// ============================================================================

// initGitDir creates a git repo with one commit. Returns the commit SHA.
func initGitDir(dir string) string {
	for _, args := range [][]string{
		{"git", "init"},
		{"git", "config", "user.email", "test@test.com"},
		{"git", "config", "user.name", "Test"},
	} {
		cmd := exec.Command(args[0], args[1:]...)
		cmd.Dir = dir
		cmd.Run()
	}
	os.WriteFile(filepath.Join(dir, ".gitkeep"), []byte(""), 0o644)
	cmd := exec.Command("git", "add", "-A")
	cmd.Dir = dir
	cmd.Run()
	cmd = exec.Command("git", "commit", "-m", "init")
	cmd.Dir = dir
	cmd.Run()
	// Capture commit hash for BaseCommit
	out, err := exec.Command("git", "-C", dir, "rev-parse", "HEAD").Output()
	if err != nil {
		return "HEAD"
	}
	return strings.TrimSpace(string(out))
}

func successResult(text string) engine.RunResult {
	return engine.RunResult{
		Subtype:    "success",
		ResultText: text,
		CostUSD:    0.01,
		DurationMs: 100,
		NumTurns:   1,
	}
}

func reviewPassJSON() string {
	return `{"pass":true,"severity":"none","findings":[]}`
}

func reviewFailJSON() string {
	return `{"pass":false,"severity":"high","findings":[{"severity":"high","file":"main.go","line":"1","message":"bad","fix":"fix"}]}`
}

func defaultEngine(runner engine.CommandRunner, wt *MockWorktreeManager, verifier *verify.Pipeline) Engine {
	return Engine{
		RepoRoot:     wt.repoRoot,
		Task:         "implement feature X",
		TaskType:     model.TaskTypeRefactor,
		WorktreeName: "test-wf",
		AuthMode:     engine.AuthModeSubscription,
		Policy:       config.DefaultPolicy(),
		Pools:        nil,
		Worktrees:    wt,
		Runners:      engine.Registry{Claude: runner, Codex: runner},
		Verifier:     verifier,
		State:        taskstate.NewTaskState("test-task"),
	}
}

// ============================================================================
// Tests: DryRun
// ============================================================================

func TestWorkflowDryRun(t *testing.T) {
	runner := newMockRunner(successResult("plan"))
	repo := t.TempDir()
	e := Engine{
		RepoRoot:     repo,
		Task:         "add feature",
		TaskType:     model.TaskTypeDocs,
		WorktreeName: "dryrun",
		AuthMode:     engine.AuthModeSubscription,
		Policy:       config.DefaultPolicy(),
		DryRun:       true,
		Pools:        subscriptions.NewManager(nil),
		Worktrees:    stubManager{repo: repo},
		Runners:      engine.Registry{Claude: runner, Codex: runner},
		Verifier:     verify.NewPipeline("", "", ""),
		State:        taskstate.NewTaskState("dry"),
	}

	result, err := e.Run(context.Background())
	if err != nil {
		t.Fatalf("DryRun should not fail: %v", err)
	}
	if !result.DryRun {
		t.Error("result.DryRun should be true")
	}
	if len(result.Steps) != 3 {
		t.Fatalf("expected 3 prepared phases, got %d", len(result.Steps))
	}
	if len(runner.Calls()) != 0 {
		t.Errorf("expected 0 Run() calls in dry-run, got %d", len(runner.Calls()))
	}
}

// ============================================================================
// Tests: Happy path
// ============================================================================

func TestWorkflowHappyPath(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan: step 1, step 2"),
		successResult("completed the task"),
		successResult(reviewPassJSON()),
	)
	planter := newCleanPlanter(mock)
	verifier := verify.NewPipeline("", "", "")
	e := defaultEngine(planter, wt, verifier)

	result, err := e.Run(context.Background())
	if err != nil {
		t.Fatalf("happy path failed: %v", err)
	}
	if result.WorktreePath == "" {
		t.Error("expected non-empty WorktreePath")
	}
	if !strings.HasPrefix(result.Branch, "stoke/") {
		t.Errorf("branch should start with stoke/, got %q", result.Branch)
	}
	if result.TotalCostUSD <= 0 {
		t.Error("expected positive total cost")
	}
	calls := mock.Calls()
	if len(calls) < 2 {
		t.Fatalf("expected at least 2 runner calls, got %d", len(calls))
	}
	if calls[0].Spec.Phase.Name != "plan" {
		t.Errorf("first call should be plan, got %q", calls[0].Spec.Phase.Name)
	}
	if calls[1].Spec.Phase.Name != "execute" {
		t.Errorf("second call should be execute, got %q", calls[1].Spec.Phase.Name)
	}
	if wt.prepareCount < 1 {
		t.Error("expected at least 1 Prepare call")
	}
}

// ============================================================================
// Tests: PlanOnly
// ============================================================================

func TestWorkflowPlanOnlyMode(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(successResult("Step 1: read\nStep 2: modify\nStep 3: test"))
	e := defaultEngine(mock, wt, verify.NewPipeline("", "", ""))
	e.PlanOnly = true

	result, err := e.Run(context.Background())
	if err != nil {
		t.Fatalf("plan-only should not fail: %v", err)
	}
	if result.PlanOutput == "" {
		t.Error("expected non-empty PlanOutput")
	}
	if !strings.Contains(result.PlanOutput, "Step 1") {
		t.Error("PlanOutput should contain the plan text")
	}
	calls := mock.Calls()
	if len(calls) != 1 {
		t.Fatalf("expected 1 call (plan), got %d", len(calls))
	}
	if calls[0].Spec.Phase.Name != "plan" {
		t.Errorf("expected plan phase, got %q", calls[0].Spec.Phase.Name)
	}
	if wt.cleanupCount < 1 {
		t.Error("expected cleanup in plan-only mode")
	}
}

// ============================================================================
// Tests: Plan failure
// ============================================================================

func TestWorkflowPlanFailure(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner()
	mock.runErr = fmt.Errorf("connection refused")

	e := defaultEngine(mock, wt, verify.NewPipeline("", "", ""))
	_, err := e.Run(context.Background())
	if err == nil {
		t.Fatal("expected error from failed plan")
	}
	if !strings.Contains(err.Error(), "plan phase") {
		t.Errorf("error should mention plan phase: %v", err)
	}
	if e.State.Phase() != taskstate.Failed {
		t.Errorf("state should be Failed, got %s", e.State.Phase())
	}
}

// ============================================================================
// Tests: Retry on verify failure
// ============================================================================

func TestWorkflowRetryOnVerifyFailure(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		successResult("attempt 1"),
		successResult("attempt 2"),
		successResult(reviewPassJSON()),
	)
	planter := newCleanPlanter(mock)

	// Script fails on first invocation, passes on second.
	scriptDir := t.TempDir()
	counter := filepath.Join(scriptDir, "n")
	os.WriteFile(counter, []byte("0"), 0o644)
	script := filepath.Join(scriptDir, "build.sh")
	os.WriteFile(script, []byte(fmt.Sprintf(`#!/bin/bash
n=$(cat %s); n=$((n+1)); echo $n > %s
if [ $n -le 1 ]; then echo "BUILD FAILED"; exit 1; fi
echo "BUILD OK"; exit 0
`, counter, counter)), 0o755)

	verifier := verify.NewPipeline("bash "+script, "", "")
	e := defaultEngine(planter, wt, verifier)

	result, err := e.Run(context.Background())
	if err != nil {
		t.Fatalf("retry should eventually succeed: %v", err)
	}
	execCount := 0
	for _, c := range mock.Calls() {
		if c.Spec.Phase.Name == "execute" {
			execCount++
		}
	}
	if execCount < 2 {
		t.Errorf("expected >= 2 execute calls, got %d", execCount)
	}
	// Verify the retry prompt includes failure context.
	n := 0
	for _, c := range mock.Calls() {
		if c.Spec.Phase.Name == "execute" {
			n++
			if n == 2 && !strings.Contains(c.Spec.Prompt, "RETRY CONTEXT") {
				t.Error("retry prompt should contain RETRY CONTEXT")
			}
		}
	}
	if len(result.Steps) < 2 {
		t.Errorf("expected >= 2 steps, got %d", len(result.Steps))
	}
}

// ============================================================================
// Tests: Slop scan blocks
// ============================================================================

func TestWorkflowSlopScanBlocks(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		successResult("done"),
	)
	planter := newSlopPlanter(mock)
	verifier := verify.NewPipeline("", "", "")
	e := defaultEngine(planter, wt, verifier)

	_, err := e.Run(context.Background())
	if err == nil {
		t.Fatal("expected error from slop detection")
	}
	errStr := strings.ToLower(err.Error())
	if !strings.Contains(errStr, "slop") && !strings.Contains(errStr, "forbidden") {
		t.Errorf("error should mention slop or forbidden patterns, got: %v", err)
	}
}

// ============================================================================
// Tests: Slop rules (deterministic scan)
// ============================================================================

func TestSlopRulesDetectEmptyError(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "bad.go"), []byte(
		"package main\n\nimport \"fmt\"\n\nfunc x() error { return fmt.Errorf(\"\") }\n",
	), 0o644)
	result, err := scan.ScanFiles(dir, scan.SlopRules(), nil)
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, f := range result.Findings {
		if f.Rule == "slop-empty-error-message" {
			found = true
			if f.Confidence == 0 {
				t.Error("finding should have non-zero confidence")
			}
		}
	}
	if !found {
		t.Error("should detect slop-empty-error-message")
	}
}

func TestSlopRulesCleanCodeNoFindings(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "clean.go"), []byte(
		"package main\n\nfunc main() {\n\tuserName := \"test\"\n\t_ = userName\n}\n",
	), 0o644)
	result, err := scan.ScanFiles(dir, scan.SlopRules(), nil)
	if err != nil {
		t.Fatal(err)
	}
	for _, f := range result.Findings {
		t.Errorf("false positive: %s in %s:%d", f.Rule, f.File, f.Line)
	}
}

// ============================================================================
// Tests: Completion promise
// ============================================================================

func TestWorkflowCompletionPromiseNotFound(t *testing.T) {
	output := "I made some changes to the code"
	promise := "all tests pass and linting is clean"
	if containsPromise(output, promise) {
		t.Error("promise should NOT be found")
	}
}

func TestWorkflowCompletionPromiseFound(t *testing.T) {
	output := "Done. all tests pass and linting is clean. Merging."
	if !containsPromise(output, "all tests pass and linting is clean") {
		t.Error("promise SHOULD be found")
	}
}

func TestWorkflowCompletionPromiseInTag(t *testing.T) {
	output := "<promise>all tests pass</promise>"
	if !containsPromise(output, "all tests pass") {
		t.Error("promise in tag should match")
	}
}

func TestWorkflowCompletionPromiseWarningIsNonFatal(t *testing.T) {
	ev := taskstate.Evidence{
		BuildPass:      true,
		TestPass:       true,
		LintPass:       true,
		ScopeClean:     true,
		ProtectedClean: true,
		ReviewPass:     true,
		Warnings:       []string{"Agent did not assert completion promise: all tests pass"},
	}
	if !ev.AllGatesPass() {
		t.Error("all gates should pass (warnings are non-fatal)")
	}
	if len(ev.Warnings) != 1 {
		t.Errorf("expected 1 warning, got %d", len(ev.Warnings))
	}
}

// ============================================================================
// Tests: Tier classification
// ============================================================================

func TestWorkflowTierClassification(t *testing.T) {
	cases := []struct {
		files int
		lines int
		want  verify.VerificationTier
	}{
		{1, 10, verify.TierLight},
		{2, 49, verify.TierLight},
		{3, 50, verify.TierStandard},
		{14, 499, verify.TierStandard},
		{15, 100, verify.TierThorough},
		{5, 500, verify.TierThorough},
		{0, 0, verify.TierLight},
	}
	for _, tc := range cases {
		got := verify.ClassifyChange(tc.files, tc.lines)
		if got != tc.want {
			t.Errorf("ClassifyChange(%d, %d) = %v, want %v", tc.files, tc.lines, got, tc.want)
		}
	}
}

// ============================================================================
// Tests: Context exceeded recovery
// ============================================================================

func TestWorkflowContextExceededRecovery(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		engine.RunResult{Subtype: "context_exceeded", DurationMs: 100},
		successResult("recovered"),
		successResult(reviewPassJSON()),
	)
	planter := newCleanPlanter(mock)
	e := defaultEngine(planter, wt, verify.NewPipeline("", "", ""))

	result, err := e.Run(context.Background())
	if err != nil {
		t.Fatalf("recovery should succeed: %v", err)
	}
	if wt.prepareCount < 2 {
		t.Errorf("expected >= 2 Prepare (original + recovery), got %d", wt.prepareCount)
	}
	_ = result
}

func TestWorkflowContextExceededExhaustion(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		engine.RunResult{Subtype: "context_exceeded", DurationMs: 50},
		engine.RunResult{Subtype: "context_exceeded", DurationMs: 50},
		engine.RunResult{Subtype: "context_exceeded", DurationMs: 50},
		engine.RunResult{Subtype: "context_exceeded", DurationMs: 50},
	)
	e := defaultEngine(mock, wt, verify.NewPipeline("", "", ""))

	_, err := e.Run(context.Background())
	if err == nil {
		t.Fatal("expected error after exhausting recovery")
	}
	if !strings.Contains(err.Error(), "context window exceeded") {
		t.Errorf("expected context window error, got: %v", err)
	}
}

// ============================================================================
// Tests: Rate limiting
// ============================================================================

func TestWorkflowSinglePoolRateLimitFails(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		engine.RunResult{Subtype: "rate_limited", DurationMs: 50},
	)
	pools := subscriptions.NewManager([]subscriptions.Pool{
		{ID: "only", Provider: subscriptions.ProviderClaude, Status: subscriptions.StatusIdle},
	})
	e := defaultEngine(mock, wt, verify.NewPipeline("", "", ""))
	e.Pools = pools

	_, err := e.Run(context.Background())
	if err == nil {
		t.Fatal("expected rate limit error")
	}
	if !strings.Contains(err.Error(), "rate limited") {
		t.Errorf("expected rate limited, got: %v", err)
	}
}

func TestWorkflowRateLimitedRotation(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		engine.RunResult{Subtype: "rate_limited", DurationMs: 50},
		successResult("rotated ok"),
		successResult(reviewPassJSON()),
	)
	planter := newCleanPlanter(mock)
	pools := subscriptions.NewManager([]subscriptions.Pool{
		{ID: "pool-1", Provider: subscriptions.ProviderClaude, Status: subscriptions.StatusIdle},
		{ID: "pool-2", Provider: subscriptions.ProviderClaude, Status: subscriptions.StatusIdle},
	})
	e := defaultEngine(planter, wt, verify.NewPipeline("", "", ""))
	e.Pools = pools

	_, err := e.Run(context.Background())
	if err != nil {
		t.Fatalf("rotation should succeed: %v", err)
	}
	if len(mock.Calls()) < 3 {
		t.Errorf("expected >= 3 calls (plan + rate_limited + rotated), got %d", len(mock.Calls()))
	}
}

// ============================================================================
// Tests: Review
// ============================================================================

func TestWorkflowReviewRejection(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		successResult("impl"),
		successResult(reviewFailJSON()),
	)
	// Use multi-file planter to exceed TierLight threshold (3+ files, 50+ lines)
	// so that the cross-model review gate actually executes.
	planter := newMultiFilePlanter(mock)
	e := defaultEngine(planter, wt, verify.NewPipeline("", "", ""))

	_, err := e.Run(context.Background())
	if err == nil {
		t.Fatal("expected review rejection error")
	}
	if !strings.Contains(err.Error(), "review rejected") {
		t.Errorf("expected review rejected, got: %v", err)
	}
}

func TestWorkflowReviewInvalidJSONSoftPass(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		successResult("impl"),
		successResult("LGTM, looks good."),
	)
	planter := newCleanPlanter(mock)
	e := defaultEngine(planter, wt, verify.NewPipeline("", "", ""))

	_, err := e.Run(context.Background())
	if err != nil {
		t.Fatalf("non-JSON review should soft-pass: %v", err)
	}
}

// ============================================================================
// Tests: State transitions
// ============================================================================

func TestWorkflowStateTransitions(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		successResult("done"),
		successResult(reviewPassJSON()),
	)
	planter := newCleanPlanter(mock)
	e := defaultEngine(planter, wt, verify.NewPipeline("", "", ""))

	_, err := e.Run(context.Background())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if e.State.Phase() != taskstate.Committed {
		t.Errorf("final state = %s, want committed", e.State.Phase())
	}
	tr := e.State.Transitions
	if len(tr) < 4 {
		t.Fatalf("expected >= 4 transitions, got %d", len(tr))
	}
	if tr[0].From != taskstate.Pending || tr[0].To != taskstate.Claimed {
		t.Errorf("first transition: %s->%s, want pending->claimed", tr[0].From, tr[0].To)
	}
}

// ============================================================================
// Tests: Nil pools
// ============================================================================

func TestWorkflowNilPoolsHandled(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		successResult("done"),
		successResult(reviewPassJSON()),
	)
	planter := newCleanPlanter(mock)
	e := defaultEngine(planter, wt, verify.NewPipeline("", "", ""))
	e.Pools = nil

	result, err := e.Run(context.Background())
	if err != nil {
		t.Fatalf("nil pools should work: %v", err)
	}
	if result.WorktreePath == "" {
		t.Error("expected non-empty WorktreePath")
	}
}

// ============================================================================
// Tests: Escalation on repeated failure
// ============================================================================

func TestWorkflowEscalateOnRepeatedFailure(t *testing.T) {
	wt := newMockWorktreeManager(t)
	mock := newMockRunner(
		successResult("plan"),
		successResult("attempt 1"),
		successResult("attempt 2"),
		successResult("attempt 3"),
	)
	planter := newCleanPlanter(mock)
	scriptDir := t.TempDir()
	script := filepath.Join(scriptDir, "fail.sh")
	os.WriteFile(script, []byte("#!/bin/bash\necho FAIL\nexit 1\n"), 0o755)

	e := defaultEngine(planter, wt, verify.NewPipeline("bash "+script, "", ""))
	_, err := e.Run(context.Background())
	if err == nil {
		t.Fatal("expected error after repeated failures")
	}
	errStr := err.Error()
	if !strings.Contains(errStr, "escalat") && !strings.Contains(errStr, "fail") {
		t.Errorf("expected escalation, got: %v", err)
	}
}

// ============================================================================
// Tests: Internal helpers
// ============================================================================

func TestBuildPhasesReturnsThreePhases(t *testing.T) {
	e := Engine{
		Task:     "add login",
		TaskType: model.TaskTypeRefactor,
		Policy:   config.DefaultPolicy(),
	}
	phases := buildPhases(e)
	if len(phases) != 3 {
		t.Fatalf("expected 3 phases, got %d", len(phases))
	}
	if phases[0].Name != "plan" {
		t.Errorf("phase 0 = %q, want plan", phases[0].Name)
	}
	if phases[1].Name != "execute" {
		t.Errorf("phase 1 = %q, want execute", phases[1].Name)
	}
	if phases[2].Name != "verify" {
		t.Errorf("phase 2 = %q, want verify", phases[2].Name)
	}
}

func TestBuildPhasesPlanIsReadOnly(t *testing.T) {
	e := Engine{
		Task:     "test",
		TaskType: model.TaskTypeRefactor,
		Policy:   config.DefaultPolicy(),
	}
	phases := buildPhases(e)
	if !phases[0].ReadOnly {
		t.Error("plan should be read-only")
	}
	if phases[1].ReadOnly {
		t.Error("execute should NOT be read-only")
	}
	if !phases[2].ReadOnly {
		t.Error("verify should be read-only")
	}
}

func TestBuildPhasesMaxTurns(t *testing.T) {
	e := Engine{
		Task:     "test",
		TaskType: model.TaskTypeRefactor,
		Policy:   config.DefaultPolicy(),
	}
	phases := buildPhases(e)
	if phases[0].MaxTurns != 10 {
		t.Errorf("plan MaxTurns = %d, want 10", phases[0].MaxTurns)
	}
	if phases[1].MaxTurns != 20 {
		t.Errorf("execute MaxTurns = %d, want 20", phases[1].MaxTurns)
	}
	if phases[2].MaxTurns != 2 {
		t.Errorf("verify MaxTurns = %d, want 2", phases[2].MaxTurns)
	}
}

func TestBuildPhasesSandbox(t *testing.T) {
	e := Engine{
		Task:     "test",
		TaskType: model.TaskTypeRefactor,
		Policy:   config.DefaultPolicy(),
	}
	phases := buildPhases(e)
	if phases[0].Sandbox {
		t.Error("plan should not sandbox")
	}
	if !phases[1].Sandbox {
		t.Error("execute should sandbox")
	}
	if !phases[2].Sandbox {
		t.Error("verify should sandbox")
	}
}

func TestPickRunnerPlanAlwaysClaude(t *testing.T) {
	e := Engine{
		TaskType: model.TaskTypeRefactor,
		Runners:  engine.Registry{Claude: newMockRunner(), Codex: newMockRunner()},
	}
	name, r := pickRunner(e, "plan")
	if name != "claude" {
		t.Errorf("plan runner = %q, want claude", name)
	}
	if r == nil {
		t.Error("runner should not be nil")
	}
}

func TestPickRunnerVerifyDiffersFromExecute(t *testing.T) {
	e := Engine{
		TaskType: model.TaskTypeRefactor,
		Runners:  engine.Registry{Claude: newMockRunner(), Codex: newMockRunner()},
	}
	execName, _ := pickRunner(e, "execute")
	verifyName, _ := pickRunner(e, "verify")
	if execName == verifyName {
		t.Errorf("verify should differ from execute (both = %q)", execName)
	}
}

func TestBuildSpecPopulatesFields(t *testing.T) {
	e := Engine{
		AuthMode:        engine.AuthModeSubscription,
		ClaudeConfigDir: "/conf",
		Runners:         engine.Registry{Claude: newMockRunner()},
		Pools:           subscriptions.NewManager(nil),
	}
	phase := engine.PhaseSpec{Name: "execute", Sandbox: true}
	handle := worktree.Handle{Path: "/wt", RuntimeDir: "/rt"}
	spec := e.buildSpec(phase, handle)

	if spec.WorktreeDir != "/wt" {
		t.Errorf("WorktreeDir = %q", spec.WorktreeDir)
	}
	if spec.RuntimeDir != "/rt" {
		t.Errorf("RuntimeDir = %q", spec.RuntimeDir)
	}
	if spec.Mode != engine.AuthModeSubscription {
		t.Errorf("Mode = %q", spec.Mode)
	}
	if !spec.SandboxEnabled {
		t.Error("SandboxEnabled should be true")
	}
}

func TestBuildRetryPromptIncludesContext(t *testing.T) {
	a := &failure.Analysis{
		Class:     failure.BuildFailed,
		Summary:   "3 errors",
		RootCause: "missing import",
		Specifics: []failure.Detail{
			{File: "main.go", Line: 15, Message: "undefined: http.Handler", Fix: "add net/http"},
		},
	}
	result := buildRetryPrompt("implement feature", 2, a, "3 files changed")
	for _, want := range []string{
		"implement feature", "attempt 2", "3 errors", "missing import",
		"main.go:15", "http.Handler", "add net/http", "3 files changed",
	} {
		if !strings.Contains(result, want) {
			t.Errorf("missing %q in retry prompt", want)
		}
	}
}

func TestIntBuildRetryPromptPolicyViolation(t *testing.T) {
	a := &failure.Analysis{Class: failure.PolicyViolation, Summary: "bypass"}
	result := buildRetryPrompt("task", 2, a, "")
	// The retry prompt for policy violations should warn about lint bypass patterns.
	tsIgnorePattern := "@ts-" + "ignore" // expected output token, split to avoid hook false positive
	if !strings.Contains(result, tsIgnorePattern) {
		t.Error("should warn about lint bypass patterns for policy violation")
	}
}

func TestIntBuildRetryPromptWrongFiles(t *testing.T) {
	a := &failure.Analysis{Class: failure.WrongFiles, Summary: "scope"}
	result := buildRetryPrompt("task", 2, a, "")
	if !strings.Contains(result, "scope") {
		t.Error("should warn about scope for wrong files")
	}
}

func TestBuildRetryPromptSkipsDiffUnavailable(t *testing.T) {
	a := &failure.Analysis{Class: failure.TestsFailed, Summary: "fail"}
	result := buildRetryPrompt("task", 2, a, "(diff unavailable)")
	if strings.Contains(result, "CHANGES FROM PREVIOUS") {
		t.Error("should not show diff section")
	}
}

func TestParseReviewVerdictVariants(t *testing.T) {
	tests := []struct {
		name    string
		input   string
		wantErr bool
		pass    bool
	}{
		{"pass", `{"pass":true,"severity":"none","findings":[]}`, false, true},
		{"fail", `{"pass":false,"severity":"high","findings":[]}`, false, false},
		{"fenced", "```json\n{\"pass\":true}\n```", false, true},
		{"invalid", "not json", true, false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			v, err := parseReviewVerdict(tt.input)
			if tt.wantErr {
				if err == nil {
					t.Error("expected error")
				}
				return
			}
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			if v.Pass != tt.pass {
				t.Errorf("pass = %v, want %v", v.Pass, tt.pass)
			}
		})
	}
}

func TestFirstNonEmpty(t *testing.T) {
	if got := firstNonEmpty("", "", "foo"); got != "foo" {
		t.Errorf("got %q, want foo", got)
	}
	if got := firstNonEmpty("bar", "baz"); got != "bar" {
		t.Errorf("got %q, want bar", got)
	}
	if got := firstNonEmpty("", "  ", "x"); got != "x" {
		t.Errorf("got %q, want x", got)
	}
}

func TestSandboxDomainsForPhase(t *testing.T) {
	exec := sandboxDomainsForPhase("execute")
	if len(exec) == 0 {
		t.Error("execute should have domains")
	}
	plan := sandboxDomainsForPhase("plan")
	if len(plan) != 0 {
		t.Error("plan should have no domains")
	}
	ver := sandboxDomainsForPhase("verify")
	if len(ver) == 0 {
		t.Error("verify should have domains")
	}
}

func TestIntSlugFromTask(t *testing.T) {
	if slug := slugFromTask("Add JWT auth"); slug == "" || strings.Contains(slug, " ") {
		t.Errorf("bad slug: %q", slug)
	}
	if slug := slugFromTask(""); slug == "" {
		t.Error("empty input should produce non-empty slug")
	}
	long := strings.Repeat("a", 100)
	if len(slugFromTask(long)) > 32 {
		t.Error("should truncate")
	}
}

func TestParseReflectionAllKeys(t *testing.T) {
	output := `<reflection>
WHAT_WORKED: interfaces
WHAT_FAILED: global state
SURPRISE: no tests
FOR_NEXT_TASK: add fixtures
</reflection>`
	r := parseReflection(output)
	expected := map[string]string{
		"WHAT_WORKED": "interfaces", "WHAT_FAILED": "global state",
		"SURPRISE": "no tests", "FOR_NEXT_TASK": "add fixtures",
	}
	for k, want := range expected {
		if r[k] != want {
			t.Errorf("%s = %q, want %q", k, r[k], want)
		}
	}
}

func TestIntParseReflectionNoTag(t *testing.T) {
	if len(parseReflection("no reflection here")) != 0 {
		t.Error("should return empty map")
	}
}

func TestResultRender(t *testing.T) {
	r := Result{
		WorktreePath: "/tmp/test",
		Branch:       "stoke/test",
		TaskType:     model.TaskTypeRefactor,
		TotalCostUSD: 0.0542,
		DryRun:       true,
		Steps: []StepResult{
			{Phase: "plan", Engine: "claude", Command: engine.PreparedCommand{Binary: "claude"}},
		},
		Verification: []verify.Outcome{
			{Name: "build", Success: true},
			{Name: "lint", Skipped: true},
		},
	}
	out := r.Render()
	for _, want := range []string{"refactor", "0.0542", "dry-run", "plan", "skipped"} {
		if !strings.Contains(out, want) {
			t.Errorf("render missing %q", want)
		}
	}
}

func TestMockRunnerConcurrentSafety(t *testing.T) {
	runner := newMockRunner(successResult("ok"))
	const goroutines = 10
	done := make(chan struct{})
	for i := 0; i < goroutines; i++ {
		go func() {
			defer func() { done <- struct{}{} }()
			runner.Run(context.Background(), engine.RunSpec{Phase: engine.PhaseSpec{Name: "test"}}, nil)
			runner.Calls()
		}()
	}
	for i := 0; i < goroutines; i++ {
		<-done
	}
	count := len(runner.Calls())
	if count != goroutines {
		t.Errorf("expected %d calls, got %d", goroutines, count)
	}
}

func TestTimingFieldConversion(t *testing.T) {
	r := engine.RunResult{DurationMs: 1500}
	dur := time.Duration(r.DurationMs) * time.Millisecond
	if dur != 1500*time.Millisecond {
		t.Errorf("duration = %v, want 1500ms", dur)
	}
}

func TestConfidenceFilteringIntegration(t *testing.T) {
	rules := scan.SlopRules()
	hasHigh, hasLow := false, false
	for _, r := range rules {
		if r.Confidence >= 90 {
			hasHigh = true
		}
		if r.Confidence <= 70 {
			hasLow = true
		}
	}
	if !hasHigh || !hasLow {
		t.Error("slop rules should have mixed confidence levels")
	}
}
