package workflow

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"github.com/ericmacdougall/stoke/internal/config"
	"github.com/ericmacdougall/stoke/internal/costtrack"
	"github.com/ericmacdougall/stoke/internal/engine"
	"github.com/ericmacdougall/stoke/internal/extract"
	"github.com/ericmacdougall/stoke/internal/failure"
	"github.com/ericmacdougall/stoke/internal/hooks"
	"github.com/ericmacdougall/stoke/internal/model"
	"github.com/ericmacdougall/stoke/internal/notify"
	"github.com/ericmacdougall/stoke/internal/wisdom"
	stokeprompts "github.com/ericmacdougall/stoke/internal/prompts"
	"github.com/ericmacdougall/stoke/internal/scan"
	"github.com/ericmacdougall/stoke/internal/subscriptions"
	"github.com/ericmacdougall/stoke/internal/taskstate"
	"github.com/ericmacdougall/stoke/internal/verify"
	"github.com/ericmacdougall/stoke/internal/worktree"
)

type WorktreeManager interface {
	Prepare(ctx context.Context, explicitName string) (worktree.Handle, error)
	Merge(ctx context.Context, handle worktree.Handle, message string) error
	Cleanup(ctx context.Context, handle worktree.Handle) error
}

// Engine is the phase-machine orchestrator for a single Stoke task.
// It drives plan -> execute+verify retry loop -> cross-model review -> merge,
// managing worktree lifecycle, pool acquisition, and state transitions.
type Engine struct {
	RepoRoot         string
	Task             string
	TaskType         model.TaskType
	TaskVerification []string // per-task verification checklist from planner
	WorktreeName     string
	AllowedFiles     []string
	AuthMode         engine.AuthMode
	Policy           config.Policy
	DryRun           bool
	Pools            *subscriptions.Manager
	Worktrees        WorktreeManager
	Runners          engine.Registry
	Verifier         *verify.Pipeline
	ClaudeConfigDir  string
	CodexHome        string
	OnEvent          engine.OnEventFunc
	State            *taskstate.TaskState
	PlanOnly         bool
	Wisdom           *wisdom.Store
	Notifier         notify.Notifier
	CostBudget       float64 // optional USD budget limit (0 = unlimited)
}

type Result struct {
	WorktreePath string
	Branch       string
	TaskType     model.TaskType
	DryRun       bool
	PlanOutput   string // populated in PlanOnly mode
	Steps        []StepResult
	Verification []verify.Outcome
	TotalCostUSD float64
	CostSummary  string // human-readable cost breakdown from costtrack
}

type StepResult struct {
	Phase   string
	Engine  string
	Command engine.PreparedCommand
}

func (r Result) Render() string {
	var b strings.Builder
	fmt.Fprintf(&b, "Stoke workflow result\n")
	fmt.Fprintf(&b, "Task type: %s\n", r.TaskType)
	fmt.Fprintf(&b, "Worktree: %s\n", r.WorktreePath)
	fmt.Fprintf(&b, "Branch: %s\n", r.Branch)
	if r.TotalCostUSD > 0 {
		fmt.Fprintf(&b, "Cost: $%.4f\n", r.TotalCostUSD)
	}
	if r.DryRun {
		fmt.Fprintf(&b, "Mode: dry-run\n")
	}
	fmt.Fprintf(&b, "\nSteps:\n")
	for _, step := range r.Steps {
		fmt.Fprintf(&b, "- [%s via %s] %s %s\n", step.Phase, step.Engine, step.Command.Binary, strings.Join(step.Command.Args, " "))
	}
	if len(r.Verification) > 0 {
		fmt.Fprintf(&b, "\nVerification:\n")
		for _, outcome := range r.Verification {
			status := "ok"
			if outcome.Skipped {
				status = "skipped"
			} else if !outcome.Success {
				status = "failed"
			}
			fmt.Fprintf(&b, "- %s: %s\n", outcome.Name, status)
		}
	}
	return b.String()
}

func (e Engine) Run(ctx context.Context) (Result, error) {
	name := firstNonEmpty(e.WorktreeName, string(e.TaskType)+"-"+slugFromTask(e.Task))

	// Initialize cost tracker for this workflow run
	tracker := costtrack.NewTracker(e.CostBudget, func(alert costtrack.Alert) {
		log.Printf("[stoke] cost alert [%s]: %s", alert.Level, alert.Message)
	})

	var handle worktree.Handle
	if e.DryRun {
		runtimeDir := filepath.Join(os.TempDir(), "stoke-runtime-dryrun-"+name)
		if err := os.MkdirAll(runtimeDir, 0o755); err != nil {
			return Result{}, fmt.Errorf("create runtime dir: %w", err)
		}
		handle = worktree.Handle{
			Name:       name,
			Branch:     "stoke/" + name,
			Path:       filepath.Join(e.RepoRoot, ".stoke", "worktrees", name),
			RuntimeDir: runtimeDir,
		}
	} else {
		var err error
		handle, err = e.Worktrees.Prepare(ctx, name)
		if err != nil {
			return Result{}, err
		}
		// Install enforcer hooks in the worktree (§9 Layer 9)
		if hookErr := hooks.Install(handle.RuntimeDir); hookErr != nil {
			e.Worktrees.Cleanup(ctx, handle)
			return Result{}, fmt.Errorf("hook install failed (safety boundary): %w", hookErr)
		}
	}

	result := Result{WorktreePath: handle.Path, Branch: handle.Branch, TaskType: e.TaskType, DryRun: e.DryRun}
	phases := buildPhases(e)

	// Dry run: just prepare commands, don't execute
	if e.DryRun {
		for _, phase := range phases {
			runnerName, runner := pickRunner(e, phase.Name)
			spec := e.buildSpec(phase, handle)
			prepared, err := runner.Prepare(spec)
			if err != nil {
				os.RemoveAll(handle.RuntimeDir)
				return result, err
			}
			result.Steps = append(result.Steps, StepResult{Phase: phase.Name, Engine: runnerName, Command: prepared})
		}
		os.RemoveAll(handle.RuntimeDir)
		return result, nil
	}

	// --- PLAN phase (no retry) ---
	// Advance state: Pending -> Claimed (harness takes ownership)
	if err := e.advanceState(taskstate.Claimed, "harness dispatching to plan phase"); err != nil {
		return result, err
	}

	planPhase := phases[0]
	planRunner, planEngine := pickRunner(e, planPhase.Name)
	planSpec := e.buildSpec(planPhase, handle)
	planResult, err := planEngine.Run(ctx, planSpec, e.OnEvent)
	if err != nil {
		_ = e.advanceState(taskstate.Failed, "plan phase failed: "+err.Error())
		return result, fmt.Errorf("plan phase: %w", err)
	}
	result.Steps = append(result.Steps, StepResult{Phase: "plan", Engine: planRunner, Command: planResult.Prepared})
	tracker.Record(planRunner, name, planResult.Tokens.Input, planResult.Tokens.Output, planResult.Tokens.CacheRead, planResult.Tokens.CacheCreation)
	// Use tracker-computed cost when token data is available; fall back to engine-reported CostUSD
	result.TotalCostUSD += maxFloat(costtrack.ComputeCost(planRunner, planResult.Tokens.Input, planResult.Tokens.Output, planResult.Tokens.CacheRead, planResult.Tokens.CacheCreation), planResult.CostUSD)

	// --- PLAN-ONLY MODE: structurally prevents execute/verify/commit/merge ---
	// This is not a prompt instruction. The harness does not call execute.
	if e.PlanOnly {
		result.PlanOutput = planResult.ResultText
		result.CostSummary = tracker.Summary()
		e.Worktrees.Cleanup(ctx, handle)
		return result, nil
	}

	// --- EXECUTE + VERIFY loop (with retry) ---
	maxAttempts := 3
	maxRecoveryAttempts := 2
	recoveryAttempts := 0
	executePhase := phases[1]
	verifyPhase := phases[2]
	var lastFailure *failure.Analysis
	var lastDiff string

	for attempt := 1; attempt <= maxAttempts; attempt++ {
		// §7: "Each retry starts from a clean worktree (fresh copy of main)."
		// The learning is in the INSTRUCTIONS (retry brief), not in code state.
		if attempt > 1 {
			lastDiff = worktree.DiffSummary(ctx, handle)
			e.Worktrees.Cleanup(ctx, handle)
			retryName := fmt.Sprintf("%s-attempt-%d", name, attempt)
			var prepErr error
			handle, prepErr = e.Worktrees.Prepare(ctx, retryName)
			if prepErr != nil {
				return result, fmt.Errorf("prepare retry worktree: %w", prepErr)
			}
			if hookErr := hooks.Install(handle.RuntimeDir); hookErr != nil {
				e.Worktrees.Cleanup(ctx, handle)
				return result, fmt.Errorf("hook install failed (safety boundary): %w", hookErr)
			}
			result.WorktreePath = handle.Path
			result.Branch = handle.Branch
		}

		// Build execute prompt
		prompt := executePhase.Prompt
		if attempt > 1 && lastFailure != nil {
			prompt = buildRetryPrompt(prompt, attempt, lastFailure, lastDiff)
		}

		// Run execute phase
		currentPhase := executePhase
		currentPhase.Prompt = prompt
		execRunnerName, execRunner := pickRunner(e, currentPhase.Name)

		// Pool-aware execution with rotation on rate limit
		var execResult engine.RunResult
		var acquiredPoolID string
		triedPools := map[string]bool{} // track which pools we've tried this attempt
		maxPoolRotations := 5            // don't spin forever

		// Determine provider for pool acquisition and rotation (must be outside rotation loop scope)
		execProvider := subscriptions.ProviderClaude
		if execRunnerName == string(model.ProviderCodex) {
			execProvider = subscriptions.ProviderCodex
		}

		for rotation := 0; rotation < maxPoolRotations; rotation++ {
			execSpec := e.buildSpec(currentPhase, handle)

			// Acquire a pool (excluding already-tried ones)
			if e.Pools != nil {
				var pool subscriptions.Pool
				var acqErr error
				if len(triedPools) == 0 {
					pool, acqErr = e.Pools.Acquire(execProvider, fmt.Sprintf("%s-attempt-%d", name, attempt))
				} else {
					pool, acqErr = e.Pools.AcquireExcluding(execProvider, fmt.Sprintf("%s-attempt-%d", name, attempt), triedPools)
				}

				if acqErr != nil {
					// All pools tried -- wait for one to come back
					if e.Pools.PoolCount(execProvider) > 1 {
						waitCtx, waitCancel := context.WithTimeout(ctx, 6*time.Minute)
						pool, acqErr = e.Pools.WaitForPool(waitCtx, execProvider, fmt.Sprintf("%s-attempt-%d-wait", name, attempt))
						waitCancel()
					}
					if acqErr != nil {
						return result, fmt.Errorf("all pools exhausted for %s: %w", execProvider, acqErr)
					}
				}
				acquiredPoolID = pool.ID
				triedPools[pool.ID] = true
				execSpec.PoolConfigDir = pool.ConfigDir
				execSpec.PoolAPIKey = pool.APIKey
				execSpec.PoolBaseURL = pool.BaseURL
			}

			var runErr error
			execResult, runErr = execRunner.Run(ctx, execSpec, e.OnEvent)

			// Release pool
			if acquiredPoolID != "" && e.Pools != nil {
				rateLimited := execResult.Subtype == "rate_limited"
				e.Pools.Release(acquiredPoolID, rateLimited)
			}

			if runErr != nil {
				_ = e.advanceState(taskstate.Failed, fmt.Sprintf("execute phase attempt %d failed: %s", attempt, runErr))
				return result, fmt.Errorf("execute phase (attempt %d): %w", attempt, runErr)
			}

			// Rate limited? Rotate to another pool (using the actual provider, not hardcoded Claude)
			if execResult.Subtype == "rate_limited" {
				if e.Pools != nil && e.Pools.PoolCount(execProvider) > 1 {
					// Clean worktree and retry with different pool
					e.Worktrees.Cleanup(ctx, handle)
					retryName := fmt.Sprintf("%s-attempt-%d-rot-%d", name, attempt, rotation+1)
					var prepErr error
					handle, prepErr = e.Worktrees.Prepare(ctx, retryName)
					if prepErr != nil {
						return result, fmt.Errorf("prepare rotation worktree: %w", prepErr)
					}
					if hookErr := hooks.Install(handle.RuntimeDir); hookErr != nil {
						e.Worktrees.Cleanup(ctx, handle)
						return result, fmt.Errorf("hook install failed (safety boundary): %w", hookErr)
					}
					result.WorktreePath = handle.Path
					result.Branch = handle.Branch
					continue // try next pool
				}
				// Single pool, no rotation possible
				e.Worktrees.Cleanup(ctx, handle)
				return result, fmt.Errorf("rate limited during execute phase (single pool, no rotation available)")
			}

			break // success or non-rate-limit failure -- exit rotation loop
		}

		// Context exceeded recovery: save progress, create fresh worktree, retry
		if execResult.Subtype == "context_exceeded" {
			recoveryAttempts++
			if recoveryAttempts > maxRecoveryAttempts {
				e.Worktrees.Cleanup(ctx, handle)
				return result, fmt.Errorf("context window exceeded after %d recovery attempts", recoveryAttempts)
			}
			log.Printf("[stoke] context window exceeded, attempting recovery (%d/%d)", recoveryAttempts, maxRecoveryAttempts)
			// Save progress before cleanup
			lastDiff = worktree.DiffSummary(ctx, handle)
			// Clean and create fresh worktree
			e.Worktrees.Cleanup(ctx, handle)
			retryName := fmt.Sprintf("%s-recovery-%d", name, recoveryAttempts)
			var prepErr error
			handle, prepErr = e.Worktrees.Prepare(ctx, retryName)
			if prepErr != nil {
				return result, fmt.Errorf("prepare recovery worktree: %w", prepErr)
			}
			if hookErr := hooks.Install(handle.RuntimeDir); hookErr != nil {
				e.Worktrees.Cleanup(ctx, handle)
				return result, fmt.Errorf("hook install: %w", hookErr)
			}
			result.WorktreePath = handle.Path
			result.Branch = handle.Branch
			// Don't count as a retry attempt — recovery is separate
			attempt--
			continue
		}

		// State: agent CLAIMS done (not verified yet -- model proposes, harness decides)
		attemptStart := time.Now().Add(-time.Duration(execResult.DurationMs) * time.Millisecond)

		result.Steps = append(result.Steps, StepResult{
			Phase: fmt.Sprintf("execute (attempt %d)", attempt), Engine: execRunnerName, Command: execResult.Prepared,
		})
		tracker.Record(execRunnerName, name, execResult.Tokens.Input, execResult.Tokens.Output, execResult.Tokens.CacheRead, execResult.Tokens.CacheCreation)
		result.TotalCostUSD += maxFloat(costtrack.ComputeCost(execRunnerName, execResult.Tokens.Input, execResult.Tokens.Output, execResult.Tokens.CacheRead, execResult.Tokens.CacheCreation), execResult.CostUSD)

		// --- REFLECTION EXTRACTION ---
		if e.Wisdom != nil {
			reflection := parseReflection(execResult.ResultText)
			if v, ok := reflection["WHAT_FAILED"]; ok {
				e.Wisdom.Record(name, wisdom.Learning{Category: wisdom.Gotcha, Description: v})
			}
			if v, ok := reflection["WHAT_WORKED"]; ok {
				e.Wisdom.Record(name, wisdom.Learning{Category: wisdom.Pattern, Description: v})
			}
			if v, ok := reflection["FOR_NEXT_TASK"]; ok {
				e.Wisdom.Record(name, wisdom.Learning{Category: wisdom.Decision, Description: v})
			}
		}

		// --- COMPLETION PROMISE CHECK ---
		var promiseWarning string
		if e.Task != "" && executePhase.CompletionPromise != "" {
			if !containsPromise(execResult.ResultText, executePhase.CompletionPromise) {
				// Agent stopped without asserting completion — treat as incomplete
				// This feeds into the retry loop as a verification failure
				log.Printf("[stoke] completion promise not found in agent output")
				// Don't fail hard — let it go through verify which may catch real issues
				// But add a warning to evidence
				promiseWarning = "Agent did not assert completion promise: " + executePhase.CompletionPromise
			}
		}

		// --- VERIFY ---
		outcomes, verifyErr := e.Verifier.Run(ctx, handle.Path)
		result.Verification = outcomes

		// Build evidence for this attempt
		evidence := taskstate.Evidence{
			DiffSummary: worktree.DiffSummary(ctx, handle),
		}
		if promiseWarning != "" {
			evidence.Warnings = append(evidence.Warnings, promiseWarning)
		}
		for _, o := range outcomes {
			switch o.Name {
			case "build":
				evidence.BuildOutput = o.Output
				evidence.BuildPass = o.Success
			case "test":
				evidence.TestOutput = o.Output
				evidence.TestPass = o.Success
			case "lint":
				evidence.LintOutput = o.Output
				evidence.LintPass = o.Success
			}
		}

		if verifyErr == nil {
			// Clean gitignored build artifacts created by the verification pipeline
			// (e.g. .turbo/, dist/, __pycache__). These are from build/test/lint,
			// not from the agent, and would cause false positives in the scope check.
			worktree.CleanIgnored(ctx, handle)

			// --- SCOPE ENFORCEMENT (pre-review validation) ---
			// Harness runtime files are now in RuntimeDir (outside worktree).
			// Any .stoke/ path in the worktree is agent-created and suspicious.
			modifiedFiles, modErr := worktree.ModifiedFiles(ctx, handle)
			if modErr != nil {
				e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)
				e.Worktrees.Cleanup(ctx, handle)
				_ = e.advanceState(taskstate.Failed, "cannot enumerate modified files: "+modErr.Error())
				return result, fmt.Errorf("modified files check failed: %w", modErr)
			}

			// --- VERIFICATION TIER ---
			diffLines := worktree.DiffLineCount(ctx, handle)
			tier := verify.ClassifyChange(len(modifiedFiles), diffLines)
			log.Printf("[stoke] verification tier: %s (%d files, %d lines)", tier, len(modifiedFiles), diffLines)

			// Detect gitignored files created by the agent. These are invisible
			// to git add -A and won't be in the merged commit, but build/test
			// may depend on them. FAIL CLOSED: if the verified environment
			// includes files that can't ship, the verification is invalid.
			if ignored := worktree.IgnoredNewFiles(ctx, handle); len(ignored) > 0 {
				evidence.Warnings = append(evidence.Warnings,
					fmt.Sprintf("agent created %d gitignored file(s) not in merge: %v", len(ignored), ignored))
				e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)
				e.Worktrees.Cleanup(ctx, handle)
				_ = e.advanceState(taskstate.Failed, fmt.Sprintf(
					"verified environment diverges from merge artifact: %d gitignored file(s) would be lost: %v",
					len(ignored), ignored))
				return result, fmt.Errorf("gitignored files in verified tree (verified != merged): %v", ignored)
			}

			protectedViolations := verify.CheckProtectedFiles(modifiedFiles, e.Policy.Files.Protected)
			evidence.ProtectedClean = len(protectedViolations) == 0
			if !evidence.ProtectedClean {
				e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)
				e.Worktrees.Cleanup(ctx, handle)
				_ = e.advanceState(taskstate.Failed, fmt.Sprintf("protected files modified: %v", protectedViolations))
				return result, fmt.Errorf("protected file(s) modified: %v", protectedViolations)
			}

			scopeClean := true
			if len(e.AllowedFiles) > 0 {
				scopeViolations := verify.CheckScope(modifiedFiles, e.AllowedFiles)
				scopeClean = len(scopeViolations) == 0
				if !scopeClean {
					evidence.ScopeClean = false
					e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)
					e.Worktrees.Cleanup(ctx, handle)
					_ = e.advanceState(taskstate.Failed, fmt.Sprintf("out-of-scope: %v", scopeViolations))
					return result, fmt.Errorf("out-of-scope file(s) modified: %v", scopeViolations)
				}
			}
			evidence.ScopeClean = scopeClean

			// --- FORBIDDEN-PATTERN SCAN ---
			scanResult, scanErr := scan.ScanFiles(handle.Path, scan.DefaultRules(), modifiedFiles)
			if scanErr == nil && scanResult.HasBlocking() {
				evidence.ReviewPass = false
				e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)
				e.Worktrees.Cleanup(ctx, handle)
				_ = e.advanceState(taskstate.Failed, "blocking scan findings: "+scanResult.Summary())
				return result, fmt.Errorf("forbidden patterns found: %s", scanResult.Summary())
			}

			// --- AI SLOP SCAN ---
			slopResult, slopErr := scan.ScanFiles(handle.Path, scan.SlopRules(), modifiedFiles)
			if slopErr == nil && slopResult != nil {
				if slopResult.HasBlocking() {
					evidence.ReviewPass = false
					e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)
					e.Worktrees.Cleanup(ctx, handle)
					_ = e.advanceState(taskstate.Failed, "blocking AI slop findings: "+slopResult.Summary())
					return result, fmt.Errorf("AI slop detected: %s", slopResult.Summary())
				}
				for _, f := range slopResult.Findings {
					evidence.Warnings = append(evidence.Warnings,
						fmt.Sprintf("AI slop: %s in %s:%d — %s", f.Rule, f.File, f.Line, f.Message))
				}
			}

			// State: Executed -> Verified (harness confirmed build+test+lint+scope)
			if err := e.advanceState(taskstate.Executed, "agent returned, harness verifying"); err != nil {
				return result, err
			}
			if err := e.advanceState(taskstate.Verified, "build pass, test pass, lint pass, scope clean"); err != nil {
				return result, err
			}

			// Save pre-review state: file list + tree SHA.
			// TreeSHA captures content, modes, and structure in one hash.
			preReviewFiles := make([]string, len(modifiedFiles))
			copy(preReviewFiles, modifiedFiles)
			preReviewTree, treeErr := worktree.TreeSHA(ctx, handle)
			if treeErr != nil {
				preReviewTree = "" // fall back to file-set-only comparison
			}

			// --- TIERED REVIEW GATE ---
			// postReviewFiles: the validated file set used for commit.
			// For TierLight (no review), this is just preReviewFiles.
			// For Standard/Thorough, it's re-enumerated after the review.
			var postReviewFiles []string

			// TierLight: skip cross-model review (build+lint only).
			if tier == verify.TierLight {
				postReviewFiles = preReviewFiles
				evidence.ReviewPass = true
				evidence.Warnings = append(evidence.Warnings, "review skipped: light tier")
				e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)
				if err := e.advanceState(taskstate.Reviewed, "review skipped: light tier"); err != nil {
					return result, err
				}
			} else {

			// --- CROSS-MODEL REVIEW with pool rotation ---
			verifyRunnerName, verifyRunner := pickRunner(e, verifyPhase.Name)

			reviewProvider := subscriptions.ProviderCodex
			if verifyRunnerName == string(model.ProviderClaude) {
				reviewProvider = subscriptions.ProviderClaude
			}

			var verifyResult engine.RunResult
			var reviewErr error
			triedReviewPools := map[string]bool{}
			maxReviewRotations := 5

			for reviewRot := 0; reviewRot < maxReviewRotations; reviewRot++ {
				verifySpec := e.buildSpec(verifyPhase, handle)
				// Override verify prompt with actual changed file list and diff.
				// The diff is included inline so the reviewer does not need tools.
				verifySpec.Prompt = stokeprompts.BuildVerifyPrompt(e.Task, e.TaskVerification) +
					"\n\n## Changed files (harness-enumerated)\n" +
					strings.Join(preReviewFiles, "\n") +
					"\n\n## Diff summary\n" +
					worktree.DiffSummary(ctx, handle) +
					"\n\nThe diff is above. Do NOT use tools. Output ONLY the JSON verdict."
				// Strip tools — diff is in the prompt, reviewer just needs to produce JSON
				verifySpec.Phase.BuiltinTools = []string{}
				verifySpec.Phase.MaxTurns = 1

				var verifyPoolID string
				if e.Pools != nil {
					var pool subscriptions.Pool
					var acqErr error
					if len(triedReviewPools) == 0 {
						pool, acqErr = e.Pools.Acquire(reviewProvider, "review-"+name)
					} else {
						pool, acqErr = e.Pools.AcquireExcluding(reviewProvider, "review-"+name, triedReviewPools)
					}
					if acqErr != nil {
						log.Printf("[stoke] review pool acquire failed: %v (provider=%s, count=%d)", acqErr, reviewProvider, e.Pools.PoolCount(reviewProvider))
						if e.Pools.PoolCount(reviewProvider) > 1 {
							waitCtx, waitCancel := context.WithTimeout(ctx, 6*time.Minute)
							pool, acqErr = e.Pools.WaitForPool(waitCtx, reviewProvider, "review-wait-"+name)
							waitCancel()
						}
					}
					if acqErr == nil {
						verifyPoolID = pool.ID
						triedReviewPools[pool.ID] = true
						verifySpec.PoolConfigDir = pool.ConfigDir
						verifySpec.PoolAPIKey = pool.APIKey
						verifySpec.PoolBaseURL = pool.BaseURL
						log.Printf("[stoke] review pool acquired: %s (apiKey=%t, baseURL=%s)", pool.ID, pool.APIKey != "", pool.BaseURL)
					} else {
						log.Printf("[stoke] review running WITHOUT pool credentials")
					}
				}

				verifyResult, reviewErr = verifyRunner.Run(ctx, verifySpec, e.OnEvent)

				if verifyPoolID != "" && e.Pools != nil {
					rateLimited := verifyResult.Subtype == "rate_limited"
					e.Pools.Release(verifyPoolID, rateLimited)

					if rateLimited && e.Pools.PoolCount(reviewProvider) > 1 {
						continue // rotate to next pool
					}
				}
				break // success or non-rate-limit failure
			}

			evidence.ReviewEngine = verifyRunnerName
			if reviewErr != nil {
				evidence.ReviewPass = false
				evidence.ReviewOutput = reviewErr.Error()
				e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)
				e.Worktrees.Cleanup(ctx, handle)
				_ = e.advanceState(taskstate.Failed, "cross-model review failed to execute")
				return result, fmt.Errorf("cross-model review failed: %w", reviewErr)
			}
			result.Steps = append(result.Steps, StepResult{
				Phase: "verify", Engine: verifyRunnerName, Command: verifyResult.Prepared,
			})
			tracker.Record(verifyRunnerName, name, verifyResult.Tokens.Input, verifyResult.Tokens.Output, verifyResult.Tokens.CacheRead, verifyResult.Tokens.CacheCreation)
			result.TotalCostUSD += maxFloat(costtrack.ComputeCost(verifyRunnerName, verifyResult.Tokens.Input, verifyResult.Tokens.Output, verifyResult.Tokens.CacheRead, verifyResult.Tokens.CacheCreation), verifyResult.CostUSD)
			evidence.ReviewOutput = verifyResult.ResultText
			log.Printf("[stoke] review result: subtype=%q isError=%v exitCode=%d cost=$%.4f",
				verifyResult.Subtype, verifyResult.IsError, verifyResult.ExitCode, verifyResult.CostUSD)

			// Parse review verdict as JSON (not just process exit code)
			verdict, parseErr := parseReviewVerdict(verifyResult.ResultText)
			if parseErr != nil {
				// Non-JSON review response: treat as soft pass if all other gates passed.
				// This handles models (e.g. MiniMax) that don't follow JSON format reliably.
				if evidence.ScopeClean && evidence.ProtectedClean && evidence.BuildPass && evidence.TestPass && evidence.LintPass {
					log.Printf("[stoke] review returned non-JSON but all other gates passed; treating as soft pass")
					evidence.ReviewPass = true
					evidence.Warnings = append(evidence.Warnings,
						fmt.Sprintf("review response was not valid JSON (parse: %v); soft-passed because build/test/lint/scope all passed", parseErr))
				} else {
					evidence.ReviewPass = false
					e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)
					e.Worktrees.Cleanup(ctx, handle)
					_ = e.advanceState(taskstate.Failed, "review returned invalid JSON")
					return result, fmt.Errorf("cross-model review returned invalid JSON: %v", parseErr)
				}
			} else {
				evidence.ReviewPass = verdict.Pass
				if !verdict.Pass {
					e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)
					e.Worktrees.Cleanup(ctx, handle)
					_ = e.advanceState(taskstate.Failed, "cross-model review rejected")
					return result, fmt.Errorf("cross-model review rejected: %s severity, %d findings", verdict.Severity, len(verdict.Findings))
				}
			}

			// --- POST-REVIEW REVALIDATION ---
			// Review MUST be read-only. Any worktree mutation = task failure.
			var postModErr error
			postReviewFiles, postModErr = worktree.ModifiedFiles(ctx, handle)
			if postModErr != nil {
				e.Worktrees.Cleanup(ctx, handle)
				_ = e.advanceState(taskstate.Failed, "post-review file check failed: "+postModErr.Error())
				return result, fmt.Errorf("post-review validation failed: %w", postModErr)
			}

			// Exact set comparison: any difference in file sets fails the task.
			// This catches adds, removes, AND the case where both sets have
			// the same paths but different content.
			preSet := make(map[string]bool, len(preReviewFiles))
			for _, f := range preReviewFiles { preSet[f] = true }
			postSet := make(map[string]bool, len(postReviewFiles))
			for _, f := range postReviewFiles { postSet[f] = true }

			var setDiffs []string
			for f := range postSet {
				if !preSet[f] { setDiffs = append(setDiffs, "+"+f) }
			}
			for f := range preSet {
				if !postSet[f] { setDiffs = append(setDiffs, "-"+f) }
			}
			if len(setDiffs) > 0 {
				e.Worktrees.Cleanup(ctx, handle)
				_ = e.advanceState(taskstate.Failed, fmt.Sprintf("review mutated file set: %v", setDiffs))
				return result, fmt.Errorf("post-review validation failed: file set changed: %v", setDiffs)
			}

			// Tree comparison: detect ANY working tree mutation by the reviewer.
			// TreeSHA captures content + modes + structure. This catches in-place
			// edits, mode changes (chmod +x), and any other tree-level mutation
			// that file-set comparison alone would miss.
			if preReviewTree != "" {
				postReviewTree, postTreeErr := worktree.TreeSHA(ctx, handle)
				if postTreeErr == nil && postReviewTree != preReviewTree {
					e.Worktrees.Cleanup(ctx, handle)
					_ = e.advanceState(taskstate.Failed, "review mutated working tree (tree SHA mismatch)")
					return result, fmt.Errorf("post-review validation failed: tree SHA changed (pre=%s post=%s)", preReviewTree[:min(12, len(preReviewTree))], postReviewTree[:min(12, len(postReviewTree))])
				}
			}

			// Re-run full validation on post-review file set
			postProtected := verify.CheckProtectedFiles(postReviewFiles, e.Policy.Files.Protected)
			if len(postProtected) > 0 {
				e.Worktrees.Cleanup(ctx, handle)
				_ = e.advanceState(taskstate.Failed, fmt.Sprintf("post-review protected violation: %v", postProtected))
				return result, fmt.Errorf("post-review protected file violation: %v", postProtected)
			}
			if len(e.AllowedFiles) > 0 {
				postScope := verify.CheckScope(postReviewFiles, e.AllowedFiles)
				if len(postScope) > 0 {
					e.Worktrees.Cleanup(ctx, handle)
					_ = e.advanceState(taskstate.Failed, fmt.Sprintf("post-review scope violation: %v", postScope))
					return result, fmt.Errorf("post-review scope violation: %v", postScope)
				}
			}
			postScan, postScanErr := scan.ScanFiles(handle.Path, scan.DefaultRules(), postReviewFiles)
			if postScanErr == nil && postScan.HasBlocking() {
				e.Worktrees.Cleanup(ctx, handle)
				_ = e.advanceState(taskstate.Failed, "post-review scan: "+postScan.Summary())
				return result, fmt.Errorf("post-review forbidden patterns: %s", postScan.Summary())
			}

			e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)

			// State: Verified -> Reviewed (opposite-family model approved)
			if err := e.advanceState(taskstate.Reviewed, fmt.Sprintf("%s review: approved", verifyRunnerName)); err != nil {
				return result, err
			}

			} // end tier != TierLight else block

			// --- MERGE GATES: evidence AND state must agree ---
			if !evidence.AllGatesPass() {
				e.Worktrees.Cleanup(ctx, handle)
				return result, fmt.Errorf("merge blocked: gates failed: %v", evidence.FailedGates())
			}
			if !e.State.CanCommit() {
				e.Worktrees.Cleanup(ctx, handle)
				return result, fmt.Errorf("merge blocked: state not committable (phase=%s)", e.State.Phase())
			}

			// --- COMMIT AND MERGE ---
			// CommitVerifiedTree builds one clean commit from BaseCommit containing
			// ONLY the validated files. No intermediate agent commits survive.
			commitMsg := fmt.Sprintf("feat(%s): %s", slugFromTask(e.Task), e.Task)
			commitErr := worktree.CommitVerifiedTree(ctx, handle, postReviewFiles, commitMsg)
			if errors.Is(commitErr, worktree.ErrNothingToCommit) {
				// True no-op: validated file set is empty. Skip merge entirely.
				// This prevents net-zero-diff branches (add then remove) from
				// leaking unverified agent commits through merge.
				e.Worktrees.Cleanup(ctx, handle)
				_ = e.advanceState(taskstate.Committed, "no changes to merge (empty validated set)")
				break
			}
			if commitErr != nil {
				e.Worktrees.Cleanup(ctx, handle)
				return result, fmt.Errorf("commit: %w", commitErr)
			}
			if valErr := worktree.ValidateMerge(ctx, handle); valErr != nil {
				e.Worktrees.Cleanup(ctx, handle)
				return result, fmt.Errorf("merge validation: %w", valErr)
			}
			if mergeErr := e.Worktrees.Merge(ctx, handle, commitMsg); mergeErr != nil {
				e.Worktrees.Cleanup(ctx, handle)
				return result, fmt.Errorf("merge: %w", mergeErr)
			}

			// State: Reviewed -> Committed (Stoke merged to main)
			if err := e.advanceState(taskstate.Committed, "merged to main by harness"); err != nil {
				return result, err
			}
			if e.Notifier != nil {
				e.Notifier.Notify(notify.NotifyEvent{
					Type:      "task_complete",
					TaskID:    name,
					Message:   fmt.Sprintf("Task completed: %s", e.Task),
					Timestamp: time.Now(),
				})
			}
			break
		}

		// Verification FAILED -- record evidence BEFORE analyzing
		e.recordAttemptEvidence(attempt, attemptStart, execRunnerName, execResult.ResultText, evidence)

		analysis := verify.AnalyzeOutcomes(outcomes)
		if analysis == nil {
			break
		}

		// Record failure wisdom for future tasks in this session
		e.recordWisdom(name, analysis)

		// Use failure.ShouldRetry for the retry/escalate decision
		decision := failure.ShouldRetry(analysis, attempt, lastFailure)
		if decision.Action == failure.Escalate {
			_ = e.advanceState(taskstate.Failed, "escalating to human: "+decision.Reason)
			if e.Notifier != nil {
				e.Notifier.Notify(notify.NotifyEvent{
					Type:      "task_failed",
					TaskID:    name,
					Message:   fmt.Sprintf("Task failed: %s — %s", e.Task, decision.Reason),
					Timestamp: time.Now(),
				})
			}
			e.Worktrees.Cleanup(ctx, handle)
			return result, fmt.Errorf("escalating: %s", decision.Reason)
		}

		lastFailure = analysis
	}

	result.CostSummary = tracker.Summary()
	// Keep the accumulated TotalCostUSD (already computed per-phase above)
	return result, nil
}

// advanceState transitions the task state machine.
// State is required (no legacy mode). Invalid transitions are fatal.
// Errors are logged so that fire-and-forget callers (_ = advanceState)
// do not silently swallow transition failures.
func (e Engine) advanceState(to taskstate.Phase, reason string) error {
	err := e.State.Advance(to, reason)
	if err != nil {
		log.Printf("[WARN] advanceState(%s, %q): %v", to, reason, err)
	}
	return err
}

// recordAttemptEvidence records an attempt with evidence on the state machine.
// ProposedSummary is the model's UNTRUSTED claim. FailureCodes are derived from evidence.
func (e Engine) recordAttemptEvidence(number int, startedAt time.Time, engineName string, proposedSummary string, ev taskstate.Evidence) {
	if e.State != nil {
		// Derive failure codes from evidence (harness decides, not model)
		var codes []taskstate.FailureCode
		var details []taskstate.FailureDetail
		if !ev.BuildPass {
			codes = append(codes, taskstate.FailureBuildFailed)
			details = append(details, taskstate.FailureDetail{Code: taskstate.FailureBuildFailed, Message: truncStr(ev.BuildOutput, 200)})
		}
		if !ev.TestPass {
			codes = append(codes, taskstate.FailureTestsFailed)
			details = append(details, taskstate.FailureDetail{Code: taskstate.FailureTestsFailed, Message: truncStr(ev.TestOutput, 200)})
		}
		if !ev.LintPass {
			codes = append(codes, taskstate.FailureLintFailed)
			details = append(details, taskstate.FailureDetail{Code: taskstate.FailureLintFailed, Message: truncStr(ev.LintOutput, 200)})
		}
		if !ev.ScopeClean {
			codes = append(codes, taskstate.FailureWrongFiles)
		}
		if !ev.ProtectedClean {
			codes = append(codes, taskstate.FailureProtectedPathTouched)
		}
		if !ev.ReviewPass && ev.ReviewEngine != "" {
			codes = append(codes, taskstate.FailureReviewRejected)
			details = append(details, taskstate.FailureDetail{Code: taskstate.FailureReviewRejected, Message: truncStr(ev.ReviewOutput, 200)})
		}
		if ev.DiffSummary == "" || ev.DiffSummary == "(diff unavailable)" {
			codes = append(codes, taskstate.FailureNoDiff)
		}

		e.State.RecordAttempt(taskstate.Attempt{
			Number:          number,
			StartedAt:       startedAt,
			Duration:        time.Since(startedAt),
			Engine:          engineName,
			ProposedSummary: proposedSummary,
			Evidence:        ev,
			FailureCodes:    codes,
			FailureDetails:  details,
		})
	}
}

func truncStr(s string, n int) string {
	if len(s) <= n { return s }
	return s[:n] + "..."
}

func maxFloat(a, b float64) float64 {
	if a > b {
		return a
	}
	return b
}

// buildSpec creates a RunSpec for a phase and worktree handle.
func (e Engine) buildSpec(phase engine.PhaseSpec, handle worktree.Handle) engine.RunSpec {
	return engine.RunSpec{
		Prompt:            phase.Prompt,
		WorktreeDir:       handle.Path,
		RuntimeDir:        handle.RuntimeDir,
		Mode:              e.AuthMode,
		Phase:             phase,
		PoolConfigDir:     poolConfigForRunner(e, pickRunnerName(e, phase.Name)),
		SandboxEnabled:    phase.Sandbox,
		SandboxDomains:    sandboxDomainsForPhase(phase.Name),
		SandboxAllowRead:  []string{filepath.Clean(handle.Path), handle.RuntimeDir},
		SandboxAllowWrite: []string{filepath.Clean(handle.Path)}, // NO .stoke -- harness writes go to RuntimeDir
	}
}

func pickRunnerName(e Engine, phase string) string {
	name, _ := pickRunner(e, phase)
	return name
}

// buildRetryPrompt injects failure analysis and diff context into the next attempt.
func buildRetryPrompt(originalPrompt string, attempt int, analysis *failure.Analysis, diffSummary string) string {
	var sb strings.Builder
	sb.WriteString(originalPrompt)
	sb.WriteString(fmt.Sprintf("\n\n--- RETRY CONTEXT (attempt %d) ---\n", attempt))
	sb.WriteString("Previous attempt FAILED: " + analysis.Summary + "\n")
	if analysis.RootCause != "" {
		sb.WriteString("Root cause: " + analysis.RootCause + "\n")
	}
	if len(analysis.Specifics) > 0 {
		sb.WriteString("\nSPECIFIC ISSUES:\n")
		for _, d := range analysis.Specifics {
			sb.WriteString(fmt.Sprintf("  %s:%d -- %s\n", d.File, d.Line, d.Message))
			if d.Fix != "" {
				sb.WriteString(fmt.Sprintf("    Suggested fix: %s\n", d.Fix))
			}
		}
	}
	if diffSummary != "" && diffSummary != "(diff unavailable)" {
		sb.WriteString("\nCHANGES FROM PREVIOUS ATTEMPT:\n")
		sb.WriteString(diffSummary + "\n")
	}
	sb.WriteString("\nDO NOT:\n")
	switch analysis.Class {
	case failure.PolicyViolation:
		sb.WriteString("  - Use @ts-ignore, as any, or eslint-disable\n")
	case failure.WrongFiles:
		sb.WriteString("  - Modify files outside the task scope\n")
	case failure.Regression:
		sb.WriteString("  - Break existing passing tests\n")
	default:
		sb.WriteString("  - Repeat the same approach that just failed\n")
	}
	return sb.String()
}

func buildPhases(e Engine) []engine.PhaseSpec {
	plan := e.Policy.Phases["plan"]
	execute := e.Policy.Phases["execute"]
	verifyPhase := e.Policy.Phases["verify"]
	return []engine.PhaseSpec{
		{
			Name:         "plan",
			BuiltinTools: plan.BuiltinTools,
			AllowedRules: plan.AllowedRules,
			DeniedRules:  plan.DeniedRules,
			MCPEnabled:   plan.MCPEnabled,
			MaxTurns:     10,
			Prompt:       planPrompt(e.Task),
			Sandbox:      false,
			ReadOnly:     true,
		},
		{
			Name:         "execute",
			BuiltinTools: execute.BuiltinTools,
			AllowedRules: execute.AllowedRules,
			DeniedRules:  execute.DeniedRules,
			MCPEnabled:   execute.MCPEnabled,
			MaxTurns:     20,
			Prompt:       executePrompt(e.Task, e.TaskType, e.TaskVerification) + e.wisdomContext(),
			Sandbox:      true,
			ReadOnly:     false,
		},
		{
			Name:         "verify",
			BuiltinTools: verifyPhase.BuiltinTools,
			AllowedRules: verifyPhase.AllowedRules,
			DeniedRules:  verifyPhase.DeniedRules,
			MCPEnabled:   verifyPhase.MCPEnabled,
			MaxTurns:     2,
			Prompt:       stokeprompts.BuildVerifyPrompt(e.Task, e.TaskVerification),
			Sandbox:      true,
			ReadOnly:     true,
		},
	}
}

func pickRunner(e Engine, phase string) (string, engine.CommandRunner) {
	if phase == "plan" {
		return string(model.ProviderClaude), e.Runners.Claude
	}

	// Use Resolve() with fallback chain -- checks pool availability
	isAvailable := func(p model.Provider) bool {
		switch p {
		case model.ProviderClaude:
			return e.Runners.Claude != nil
		case model.ProviderCodex:
			return e.Runners.Codex != nil
		case model.ProviderGemini:
			return e.Runners.Gemini != nil
		default:
			return false // openrouter/direct-api not yet wired as runners
		}
	}

	if phase == "verify" {
		execProvider := model.Resolve(e.TaskType, isAvailable)
		reviewer := model.CrossModelReviewer(execProvider)
		// Fall back to execution provider if reviewer has no pools
		if reviewer == model.ProviderCodex && e.Pools != nil && e.Pools.PoolCount(subscriptions.ProviderCodex) == 0 {
			reviewer = model.ProviderClaude
		} else if reviewer == model.ProviderClaude && e.Pools != nil && e.Pools.PoolCount(subscriptions.ProviderClaude) == 0 {
			reviewer = model.ProviderCodex
		}
		return providerToRunner(e, reviewer)
	}

	resolved := model.Resolve(e.TaskType, isAvailable)
	return providerToRunner(e, resolved)
}

func providerToRunner(e Engine, p model.Provider) (string, engine.CommandRunner) {
	switch p {
	case model.ProviderCodex:
		if e.Runners.Codex != nil {
			return string(p), e.Runners.Codex
		}
		return string(model.ProviderClaude), e.Runners.Claude
	case model.ProviderGemini:
		if e.Runners.Gemini != nil {
			return string(p), e.Runners.Gemini
		}
		return string(model.ProviderClaude), e.Runners.Claude
	default:
		return string(model.ProviderClaude), e.Runners.Claude
	}
}

func poolConfigForRunner(e Engine, runner string) string {
	switch runner {
	case string(model.ProviderClaude):
		return e.ClaudeConfigDir
	case string(model.ProviderCodex):
		return e.CodexHome
	default:
		return ""
	}
}

func sandboxDomainsForPhase(phase string) []string {
	if phase == "execute" || phase == "verify" {
		return []string{"github.com", "*.npmjs.org", "registry.yarnpkg.com"}
	}
	return nil
}

func planPrompt(task string) string {
	return stokeprompts.BuildPlanPrompt(task, false, "", "")
}

func (e Engine) wisdomContext() string {
	if e.Wisdom == nil {
		return ""
	}
	s := e.Wisdom.ForPrompt()
	if s == "" {
		return ""
	}
	return "\n\n" + s
}

func (e Engine) recordWisdom(taskID string, analysis *failure.Analysis) {
	if e.Wisdom == nil || analysis == nil {
		return
	}
	desc := analysis.Summary
	if analysis.RootCause != "" {
		desc = analysis.RootCause
	}
	if desc != "" {
		e.Wisdom.Record(taskID, wisdom.Learning{
			Category:    wisdom.Gotcha,
			Description: desc,
		})
	}
}

func executePrompt(task string, taskType model.TaskType, verification []string) string {
	verificationStr := ""
	if len(verification) > 0 {
		verificationStr = strings.Join(verification, "\n")
	}
	return stokeprompts.BuildExecutePrompt(task, verificationStr, "", "")
}

// reviewVerdict is the parsed output of a cross-model review.
type reviewVerdict struct {
	Pass     bool   `json:"pass"`
	Severity string `json:"severity"`
	Findings []struct {
		Severity string `json:"severity"`
		File     string `json:"file"`
		Line     string `json:"line"`
		Message  string `json:"message"`
		Fix      string `json:"fix"`
	} `json:"findings"`
}

// parseReviewVerdict parses the reviewer's JSON response.
// Uses extract.ExtractFirstJSON for robust JSON extraction from model output,
// with fallback to direct unmarshalling for clean JSON responses.
func parseReviewVerdict(s string) (*reviewVerdict, error) {
	s = strings.TrimSpace(s)

	// Try structured extraction first: handles markdown fences, inline JSON, etc.
	if parsed := extract.ExtractFirstJSON(s); parsed != nil {
		// Re-marshal and unmarshal into our typed struct
		raw, err := json.Marshal(parsed)
		if err == nil {
			var v reviewVerdict
			if err := json.Unmarshal(raw, &v); err == nil {
				return &v, nil
			}
		}
	}

	// Fallback: direct parse after stripping markdown fences
	cleaned := strings.TrimPrefix(s, "```json")
	cleaned = strings.TrimPrefix(cleaned, "```")
	cleaned = strings.TrimSuffix(cleaned, "```")
	cleaned = strings.TrimSpace(cleaned)

	var v reviewVerdict
	if err := json.Unmarshal([]byte(cleaned), &v); err != nil {
		return nil, err
	}
	return &v, nil
}

func firstNonEmpty(values ...string) string {
	for _, v := range values {
		if strings.TrimSpace(v) != "" {
			return v
		}
	}
	return ""
}

func slugFromTask(task string) string {
	cleaned := strings.ToLower(task)
	repl := strings.NewReplacer(" ", "-", "/", "-", "_", "-")
	cleaned = repl.Replace(cleaned)
	if len(cleaned) > 32 {
		cleaned = cleaned[:32]
	}
	cleaned = strings.Trim(cleaned, "-")
	if cleaned == "" {
		return "task"
	}
	return cleaned
}

// containsPromise checks whether output contains the given completion promise.
// It supports direct text match (case-insensitive, whitespace-normalized)
// and promise text wrapped in <promise>...</promise> tags.
// Also uses extract to check inside structured blocks (code blocks, JSON).
// An empty promise matches any output (returns true).
func containsPromise(output, promise string) bool {
	if strings.TrimSpace(promise) == "" {
		return true
	}
	normalized := normalizeWhitespace(strings.ToLower(promise))
	normalizedOutput := normalizeWhitespace(strings.ToLower(output))

	// Direct match (case-insensitive, whitespace-normalized)
	if strings.Contains(normalizedOutput, normalized) {
		return true
	}

	// Check inside <promise>...</promise> tags
	re := regexp.MustCompile(`(?i)<promise>(.*?)</promise>`)
	matches := re.FindAllStringSubmatch(output, -1)
	for _, m := range matches {
		tagContent := normalizeWhitespace(strings.ToLower(m[1]))
		if strings.Contains(tagContent, normalized) {
			return true
		}
	}

	// Check inside extracted code blocks and JSON (agent may embed promise in structured output)
	for _, block := range extract.ExtractAll(output) {
		blockNorm := normalizeWhitespace(strings.ToLower(block.Content))
		if strings.Contains(blockNorm, normalized) {
			return true
		}
	}

	return false
}

var wsRun = regexp.MustCompile(`\s+`)

func normalizeWhitespace(s string) string {
	return strings.TrimSpace(wsRun.ReplaceAllString(s, " "))
}

// parseReflection extracts KEY: VALUE pairs from a <reflection>...</reflection> block.
// Uses extract.ExtractJSON as a secondary source: if the agent returns reflection
// data as JSON instead of the KEY: VALUE format, we capture it too.
func parseReflection(output string) map[string]string {
	result := make(map[string]string)

	// Primary: parse <reflection> tags (original format)
	start := strings.Index(output, "<reflection>")
	end := strings.Index(output, "</reflection>")
	if start >= 0 && end > start {
		content := output[start+len("<reflection>") : end]
		for _, line := range strings.Split(content, "\n") {
			line = strings.TrimSpace(line)
			if idx := strings.Index(line, ": "); idx > 0 {
				key := strings.TrimSpace(line[:idx])
				val := strings.TrimSpace(line[idx+2:])
				if key != "" && val != "" {
					result[key] = val
				}
			}
		}
	}

	// Secondary: check for JSON-formatted reflections in case the agent
	// returns reflection data as a structured JSON block
	if len(result) == 0 {
		for _, obj := range extract.ExtractJSON(output) {
			for _, key := range []string{"WHAT_FAILED", "WHAT_WORKED", "FOR_NEXT_TASK", "SURPRISE"} {
				if v, ok := obj[key]; ok {
					if s, ok := v.(string); ok && s != "" {
						result[key] = s
					}
				}
			}
		}
	}

	return result
}
