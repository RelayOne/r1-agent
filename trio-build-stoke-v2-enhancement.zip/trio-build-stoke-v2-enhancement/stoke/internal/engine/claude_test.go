package engine

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestClaudePrepareStrictMCPAndSettings(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:        "test",
		WorktreeDir:   dir,
		RuntimeDir:    filepath.Join(dir, "runtime"),
		Mode:          AuthModeSubscription,
		PoolConfigDir: filepath.Join(dir, "pool"),
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read", "Glob", "Grep"},
			AllowedRules: []string{"Read"},
			DeniedRules:  []string{},
			MCPEnabled:   false,
			MaxTurns:     3,
		},
		SandboxEnabled: false,
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")
	// --bare already disables MCP; --strict-mcp-config is incompatible with --bare
	if !strings.Contains(joined, "--bare") {
		t.Error("missing --bare")
	}
	if !strings.Contains(joined, "--settings") {
		t.Error("missing --settings")
	}
}

func TestClaudePrepareMCPDisabledBlocksMCPTools(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read"},
			AllowedRules: []string{"Read"},
			DeniedRules:  []string{},
			MCPEnabled:   false,
			MaxTurns:     5,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")

	// Belt-and-suspenders: --disallowedTools should include mcp__*
	if !strings.Contains(joined, "mcp__*") {
		t.Error("MCP-disabled phase should add mcp__* to disallowedTools")
	}
	// --bare handles MCP isolation (--strict-mcp-config is incompatible with --bare)
	if !strings.Contains(joined, "--bare") {
		t.Error("missing --bare for MCP-disabled phase")
	}
}

func TestClaudePrepareMCPEnabledNoBlock(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read", "Edit"},
			AllowedRules: []string{"Read"},
			DeniedRules:  []string{"Bash(rm *)"},
			MCPEnabled:   true,
			MaxTurns:     20,
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	joined := strings.Join(prepared.Args, " ")

	if strings.Contains(joined, "--strict-mcp-config") {
		t.Error("MCP-enabled phase should not have --strict-mcp-config")
	}
	if strings.Contains(joined, "mcp__*") {
		t.Error("MCP-enabled phase should not block mcp__*")
	}
}

func TestClaudePrepareWritesSettingsJSON(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	_, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeSubscription,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read"},
			AllowedRules: []string{"Read"},
			DeniedRules:  []string{},
			MCPEnabled:   false,
			MaxTurns:     10,
		},
		SandboxEnabled:    true,
		SandboxDomains:    []string{"github.com"},
		SandboxAllowRead:  []string{dir},
		SandboxAllowWrite: []string{dir},
	})
	if err != nil {
		t.Fatal(err)
	}

	settingsPath := filepath.Join(dir, "runtime", "claude-settings-execute.json")
	data, err := os.ReadFile(settingsPath)
	if err != nil {
		t.Fatalf("settings file not written: %v", err)
	}

	var parsed map[string]interface{}
	if err := json.Unmarshal(data, &parsed); err != nil {
		t.Fatalf("invalid JSON: %v", err)
	}

	// apiKeyHelper should be null in Mode 1
	val, exists := parsed["apiKeyHelper"]
	if !exists {
		t.Error("apiKeyHelper key missing from settings")
	}
	if val != nil {
		t.Errorf("apiKeyHelper should be null in Mode 1, got %v", val)
	}

	// Sandbox should be present
	sandbox, ok := parsed["sandbox"].(map[string]interface{})
	if !ok {
		t.Fatal("sandbox section missing")
	}
	if sandbox["enabled"] != true {
		t.Error("sandbox.enabled should be true")
	}
	if sandbox["failIfUnavailable"] != true {
		t.Error("sandbox.failIfUnavailable should be true")
	}
}

func TestClaudePrepareMode1EnvIsolation(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("ANTHROPIC_API_KEY", "leaked-key")
	t.Setenv("PATH", "/usr/bin")

	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:        "test",
		WorktreeDir:   dir,
		RuntimeDir:    filepath.Join(dir, "runtime"),
		Mode:          AuthModeSubscription,
		PoolConfigDir: "/pool/claude-1",
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read"},
			MCPEnabled:   false,
			MaxTurns:     3,
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	envJoined := strings.Join(prepared.Env, "\n")
	if strings.Contains(envJoined, "ANTHROPIC_API_KEY=") {
		t.Error("Mode 1 should strip ANTHROPIC_API_KEY from env")
	}
	if !strings.Contains(envJoined, "CLAUDE_CONFIG_DIR=/pool/claude-1") {
		t.Error("Mode 1 should inject CLAUDE_CONFIG_DIR")
	}
}

func TestClaudePrepareRequiresWorktreeDir(t *testing.T) {
	runner := NewClaudeRunner("claude")
	_, err := runner.Prepare(RunSpec{
		WorktreeDir: "",
		RuntimeDir:  "/tmp/runtime",
		Prompt:      "test",
		Phase:       PhaseSpec{Name: "plan", BuiltinTools: []string{"Read"}, MaxTurns: 3},
	})
	if err == nil {
		t.Fatal("expected error for empty WorktreeDir")
	}
	if !strings.Contains(err.Error(), "missing worktree dir") {
		t.Errorf("error should mention missing worktree dir, got: %q", err.Error())
	}
}

func TestClaudePrepareRequiresRuntimeDir(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	_, err := runner.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  "",
		Prompt:      "test",
		Phase:       PhaseSpec{Name: "plan", BuiltinTools: []string{"Read"}, MaxTurns: 3},
	})
	if err == nil {
		t.Fatal("expected error for empty RuntimeDir")
	}
	if !strings.Contains(err.Error(), "missing runtime dir") {
		t.Errorf("error should mention missing runtime dir, got: %q", err.Error())
	}
}

func TestClaudePrepareBuildsCorrectArgs(t *testing.T) {
	dir := t.TempDir()
	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "do something",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "execute",
			BuiltinTools: []string{"Read", "Edit"},
			MaxTurns:     10,
			MCPEnabled:   false,
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	joined := strings.Join(prepared.Args, " ")
	requiredFlags := []string{"--bare", "-p", "--verbose", "--output-format", "stream-json"}
	for _, flag := range requiredFlags {
		if !strings.Contains(joined, flag) {
			t.Errorf("args should contain %q, got: %s", flag, joined)
		}
	}
	// Verify prompt is in args
	if !strings.Contains(joined, "do something") {
		t.Error("args should contain the prompt text")
	}
	// Verify --tools with the built-in tools
	if !strings.Contains(joined, "Read,Edit") {
		t.Error("args should contain the tools list")
	}
	// Verify --max-turns
	if !strings.Contains(joined, "10") {
		t.Error("args should contain the max turns value")
	}
}

func TestClaudePrepareSettingsFile(t *testing.T) {
	dir := t.TempDir()
	runtimeDir := filepath.Join(dir, "runtime")
	runner := NewClaudeRunner("claude")
	_, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  runtimeDir,
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read"},
			MaxTurns:     5,
			MCPEnabled:   false,
		},
		SandboxEnabled: true,
	})
	if err != nil {
		t.Fatal(err)
	}

	// Verify the settings file was written to RuntimeDir
	settingsPath := filepath.Join(runtimeDir, "claude-settings-plan.json")
	data, err := os.ReadFile(settingsPath)
	if err != nil {
		t.Fatalf("settings file should exist at %s: %v", settingsPath, err)
	}
	if len(data) == 0 {
		t.Fatal("settings file should not be empty")
	}

	var parsed map[string]interface{}
	if err := json.Unmarshal(data, &parsed); err != nil {
		t.Fatalf("settings file should contain valid JSON: %v", err)
	}
}

func TestClaudePrepareMode2PassesEnv(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("ANTHROPIC_API_KEY", "should-keep")

	runner := NewClaudeRunner("claude")
	prepared, err := runner.Prepare(RunSpec{
		Prompt:      "test",
		WorktreeDir: dir,
		RuntimeDir:  filepath.Join(dir, "runtime"),
		Mode:        AuthModeAPIKey,
		Phase: PhaseSpec{
			Name:         "plan",
			BuiltinTools: []string{"Read"},
			MCPEnabled:   false,
			MaxTurns:     3,
		},
	})
	if err != nil {
		t.Fatal(err)
	}

	envJoined := strings.Join(prepared.Env, "\n")
	if strings.Contains(envJoined, "ANTHROPIC_API_KEY=should-keep") {
		t.Error("Mode 2 should strip dangerous vars like ANTHROPIC_API_KEY")
	}
}

// TestContextExceededDetection verifies that context window errors are
// correctly identified and tagged with the "context_exceeded" subtype.
func TestContextExceededDetection(t *testing.T) {
	tests := []struct {
		name       string
		resultText string
		subtype    string
		isError    bool
		wantSubtype string
	}{
		{
			name:        "context window keyword in result text",
			resultText:  "Error: context window exceeded, please reduce input size",
			subtype:     "error",
			isError:     true,
			wantSubtype: "context_exceeded",
		},
		{
			name:        "token limit keyword in result text",
			resultText:  "Request failed: token limit reached for this conversation",
			subtype:     "error_during_execution",
			isError:     true,
			wantSubtype: "context_exceeded",
		},
		{
			name:        "context keyword in subtype",
			resultText:  "something happened",
			subtype:     "context_length_exceeded",
			isError:     true,
			wantSubtype: "context_exceeded",
		},
		{
			name:        "case insensitive context match",
			resultText:  "CONTEXT window is full",
			subtype:     "error",
			isError:     true,
			wantSubtype: "context_exceeded",
		},
		{
			name:        "non-context error is not tagged",
			resultText:  "something went wrong",
			subtype:     "error_during_execution",
			isError:     true,
			wantSubtype: "error_during_execution",
		},
		{
			name:        "non-error result is not tagged even with context keyword",
			resultText:  "I added context to the function",
			subtype:     "success",
			isError:     false,
			wantSubtype: "success",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Simulate the detection logic from Run() to unit-test it directly
			resultSubtype := tt.subtype
			if tt.isError {
				lowText := strings.ToLower(tt.resultText)
				lowSubtype := strings.ToLower(tt.subtype)
				if strings.Contains(lowText, "context") ||
					strings.Contains(lowText, "token limit") ||
					strings.Contains(lowSubtype, "context") {
					resultSubtype = "context_exceeded"
				}
			}
			if resultSubtype != tt.wantSubtype {
				t.Errorf("got subtype %q, want %q", resultSubtype, tt.wantSubtype)
			}
		})
	}
}
