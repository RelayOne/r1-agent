package engine

import (
	"context"

	"github.com/ericmacdougall/stoke/internal/stream"
)

type AuthMode string

const (
	// AuthModeSubscription uses the subscription pool's credentials to authenticate
	// with the AI provider. The harness injects pool-owned config dirs and strips
	// caller credentials from the environment so the agent cannot exfiltrate keys.
	AuthModeSubscription AuthMode = "mode1"

	// AuthModeAPIKey uses the caller's own API key to authenticate with the AI
	// provider. The harness passes through the caller's environment (with dangerous
	// vars stripped) instead of injecting pool credentials.
	AuthModeAPIKey AuthMode = "mode2"
)

type PhaseSpec struct {
	Name              string
	BuiltinTools      []string
	AllowedRules      []string
	DeniedRules       []string
	MCPEnabled        bool
	MaxTurns          int
	Prompt            string
	Sandbox           bool
	ReadOnly          bool   // if true, runner uses read-only sandbox and review profile
	CompletionPromise string // statement agent must include in output to prove task completion; empty means no promise required
}

type PreparedCommand struct {
	Binary          string
	Args            []string
	Dir             string
	Env             []string
	Notes           []string
	LastMessagePath string // codex --output-last-message path (for review output)
}

// RunResult captures everything from a single engine execution.
type RunResult struct {
	Prepared   PreparedCommand
	CostUSD    float64
	DurationMs int64
	NumTurns   int
	Tokens     stream.TokenUsage
	Subtype    string // success, error_max_turns, error_during_execution, rate_limited
	IsError    bool
	ResultText string
	ExitCode   int
}

// OnEventFunc is called for each streaming event during execution.
// Used by the TUI and headless runner for live progress.
type OnEventFunc func(ev stream.Event)

type CommandRunner interface {
	Prepare(spec RunSpec) (PreparedCommand, error)
	Run(ctx context.Context, spec RunSpec, onEvent OnEventFunc) (RunResult, error)
}

type RunSpec struct {
	Prompt            string
	WorktreeDir       string
	RuntimeDir        string // outside worktree, for harness-owned files only
	Mode              AuthMode
	Phase             PhaseSpec
	PoolConfigDir     string
	PoolAPIKey        string // for API/proxy pools (injected as ANTHROPIC_API_KEY)
	PoolBaseURL       string // custom API base URL (injected as ANTHROPIC_BASE_URL)
	SandboxEnabled    bool
	SandboxDomains    []string
	SandboxAllowRead  []string
	SandboxAllowWrite []string
}

// Registry holds the available command runners.
// Fields use the CommandRunner interface so callers can inject mocks for testing.
type Registry struct {
	Claude CommandRunner
	Codex  CommandRunner
	Gemini CommandRunner
	API    CommandRunner // native API runner (direct HTTP, no subprocess)
}
