package engine

import (
	"context"
	"os"
	"strings"
	"testing"
)

func TestSafeEnvForClaudeMode1StripsAuthVariables(t *testing.T) {
	t.Setenv("ANTHROPIC_API_KEY", "secret")
	t.Setenv("ANTHROPIC_AUTH_TOKEN", "token")
	t.Setenv("OPENAI_API_KEY", "openai")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForClaudeMode1("/tmp/pool")
	joined := strings.Join(env, "\n")
	if strings.Contains(joined, "ANTHROPIC_API_KEY=") || strings.Contains(joined, "OPENAI_API_KEY=") {
		t.Fatalf("auth env vars not stripped: %q", joined)
	}
	if !strings.Contains(joined, "CLAUDE_CONFIG_DIR=/tmp/pool") {
		t.Fatalf("CLAUDE_CONFIG_DIR not injected")
	}
}

func TestSafeEnvForClaudeMode1StripsCloudProviders(t *testing.T) {
	t.Setenv("AWS_ACCESS_KEY_ID", "aws-key")
	t.Setenv("AWS_SECRET_ACCESS_KEY", "aws-secret")
	t.Setenv("GOOGLE_APPLICATION_CREDENTIALS", "/path/creds.json")
	t.Setenv("AZURE_TENANT_ID", "tenant")
	t.Setenv("BEDROCK_ENDPOINT", "https://bedrock")
	t.Setenv("VERTEX_PROJECT", "proj")
	t.Setenv("CLAUDE_CODE_USE_BEDROCK", "1")
	t.Setenv("CLAUDE_CODE_USE_VERTEX", "1")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForClaudeMode1("/tmp/pool")
	joined := strings.Join(env, "\n")

	forbidden := []string{
		"AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY",
		"GOOGLE_APPLICATION_CREDENTIALS", "AZURE_TENANT_ID",
		"BEDROCK_ENDPOINT", "VERTEX_PROJECT",
		"CLAUDE_CODE_USE_BEDROCK", "CLAUDE_CODE_USE_VERTEX",
	}
	for _, key := range forbidden {
		if strings.Contains(joined, key+"=") {
			t.Errorf("cloud provider var %s should be stripped in Mode 1", key)
		}
	}
}

func TestSafeEnvForClaudeMode1PassesAllowlisted(t *testing.T) {
	t.Setenv("PATH", "/usr/bin")
	t.Setenv("HOME", "/home/test")
	t.Setenv("LANG", "en_US.UTF-8")
	t.Setenv("GIT_AUTHOR_NAME", "Test")
	t.Setenv("npm_config_registry", "https://registry.npmjs.org")

	env := safeEnvForClaudeMode1("/tmp/pool")
	joined := strings.Join(env, "\n")

	for _, key := range []string{"PATH=", "HOME=", "LANG=", "GIT_AUTHOR_NAME=", "npm_config_registry="} {
		if !strings.Contains(joined, key) {
			t.Errorf("allowlisted var %s should pass through", key)
		}
	}
}

func TestSafeEnvMode2StripsDangerousVars(t *testing.T) {
	t.Setenv("ANTHROPIC_API_KEY", "secret-key")
	t.Setenv("AWS_SECRET_ACCESS_KEY", "aws-secret")
	t.Setenv("CUSTOM_VAR", "custom-value")

	env := safeEnvMode2(map[string]string{"EXTRA": "val"})
	joined := strings.Join(env, "\n")

	// Dangerous vars should be stripped even in Mode 2
	for _, key := range []string{"ANTHROPIC_API_KEY=", "AWS_SECRET_ACCESS_KEY="} {
		if strings.Contains(joined, key) {
			t.Errorf("dangerous var %s should be stripped in Mode 2", key)
		}
	}
	// Safe vars and extras should still pass through
	if !strings.Contains(joined, "CUSTOM_VAR=custom-value") {
		t.Error("Mode 2 should pass safe custom vars")
	}
	if !strings.Contains(joined, "EXTRA=val") {
		t.Error("Mode 2 should inject extra vars")
	}
}

func TestSafeEnvForCodexMode1StripsAuth(t *testing.T) {
	t.Setenv("OPENAI_API_KEY", "openai-secret")
	t.Setenv("CODEX_API_KEY", "codex-secret")
	t.Setenv("ANTHROPIC_API_KEY", "anthropic-secret")
	t.Setenv("AWS_ACCESS_KEY_ID", "aws-key")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForCodexMode1("/tmp/codex-pool")
	joined := strings.Join(env, "\n")

	for _, key := range []string{"OPENAI_API_KEY=", "CODEX_API_KEY=", "ANTHROPIC_API_KEY=", "AWS_ACCESS_KEY_ID="} {
		if strings.Contains(joined, key) {
			t.Errorf("auth var %s should be stripped in Codex Mode 1", key)
		}
	}
	if !strings.Contains(joined, "CODEX_HOME=/tmp/codex-pool") {
		t.Error("CODEX_HOME should be injected")
	}
}

func TestMode1ConfigDirOverridesExisting(t *testing.T) {
	t.Setenv("CLAUDE_CONFIG_DIR", "/original/path")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForClaudeMode1("/override/path")
	configDirCount := 0
	for _, e := range env {
		if strings.HasPrefix(e, "CLAUDE_CONFIG_DIR=") {
			configDirCount++
			if e != "CLAUDE_CONFIG_DIR=/override/path" {
				t.Errorf("CLAUDE_CONFIG_DIR should be overridden, got %s", e)
			}
		}
	}
	if configDirCount != 1 {
		t.Errorf("expected exactly 1 CLAUDE_CONFIG_DIR, got %d", configDirCount)
	}
}

func TestHasAnyPrefix(t *testing.T) {
	prefixes := []string{"AWS_", "GITHUB_", "STRIPE_"}
	if !hasAnyPrefix("AWS_SECRET_KEY", prefixes) {
		t.Error("hasAnyPrefix(AWS_SECRET_KEY) should be true")
	}
	if !hasAnyPrefix("GITHUB_TOKEN", prefixes) {
		t.Error("hasAnyPrefix(GITHUB_TOKEN) should be true")
	}
	if hasAnyPrefix("HOME", prefixes) {
		t.Error("hasAnyPrefix(HOME) should be false")
	}
	if hasAnyPrefix("", prefixes) {
		t.Error("hasAnyPrefix(empty) should be false")
	}
}

func TestNewClaudeRunnerEmptyBinary(t *testing.T) {
	r := NewClaudeRunner("   ")
	if r.Binary != "claude" {
		t.Errorf("empty binary should default to 'claude', got %q", r.Binary)
	}
}

func TestNewCodexRunnerEmptyBinary(t *testing.T) {
	r := NewCodexRunner("")
	if r.Binary != "codex" {
		t.Errorf("empty binary should default to 'codex', got %q", r.Binary)
	}
}

func TestClaudeRunnerPrepareMissingWorktreeDir(t *testing.T) {
	r := NewClaudeRunner("claude")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: "",
		RuntimeDir:  "/tmp/runtime",
	})
	if err == nil {
		t.Error("expected error for missing worktree dir")
	}
}

func TestClaudeRunnerPrepareMissingRuntimeDir(t *testing.T) {
	r := NewClaudeRunner("claude")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: "/tmp/worktree",
		RuntimeDir:  "",
	})
	if err == nil {
		t.Error("expected error for missing runtime dir")
	}
}

func TestClaudeRunnerPrepareCreatesRuntimeDir(t *testing.T) {
	r := NewClaudeRunner("claude")
	dir := t.TempDir()
	_, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  dir + "/runtime",
	})
	if err != nil {
		t.Errorf("Prepare() should create runtime dir: %v", err)
	}
}

func TestClaudeRunnerRunPrepareError(t *testing.T) {
	r := NewClaudeRunner("claude")
	_, err := r.Run(context.Background(), RunSpec{
		WorktreeDir: "",
		RuntimeDir:  "/tmp/runtime",
	}, nil)
	if err == nil {
		t.Error("expected error from Run() when Prepare() fails")
	}
}

func TestCodexRunnerPrepareMissingWorktreeDir(t *testing.T) {
	r := NewCodexRunner("codex")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: "",
		RuntimeDir:  "/tmp/runtime",
	})
	if err == nil {
		t.Error("expected error for missing worktree dir")
	}
}

func TestCodexRunnerPrepareMissingRuntimeDir(t *testing.T) {
	r := NewCodexRunner("codex")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: "/tmp/worktree",
		RuntimeDir:  "",
	})
	if err == nil {
		t.Error("expected error for missing runtime dir")
	}
}

func TestCodexRunnerPrepareReadOnly(t *testing.T) {
	r := NewCodexRunner("codex")
	dir := t.TempDir()
	cmd, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  dir + "/runtime",
		Phase:       PhaseSpec{Name: "verify", ReadOnly: true},
	})
	if err != nil {
		t.Fatal(err)
	}
	args := strings.Join(cmd.Args, " ")
	if !strings.Contains(args, "read-only") {
		t.Errorf("ReadOnly should use sandbox=read-only, got args: %s", args)
	}
	if !strings.Contains(args, "review") {
		t.Errorf("ReadOnly should use profile=review, got args: %s", args)
	}
}

func TestCodexRunnerPrepareDefaultSandbox(t *testing.T) {
	r := NewCodexRunner("codex")
	dir := t.TempDir()
	cmd, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  dir + "/runtime",
		Phase:       PhaseSpec{Name: "execute", ReadOnly: false},
	})
	if err != nil {
		t.Fatal(err)
	}
	args := strings.Join(cmd.Args, " ")
	if !strings.Contains(args, "workspace-write") {
		t.Errorf("Default should use sandbox=workspace-write, got args: %s", args)
	}
}

func TestSafeEnvForClaudeMode1PassthroughPrefix(t *testing.T) {
	t.Setenv("GIT_TRACE", "true")
	t.Setenv("PATH", "/usr/bin")

	env := safeEnvForClaudeMode1("/tmp/pool")
	joined := strings.Join(env, "\n")

	if !strings.Contains(joined, "GIT_TRACE=true") {
		t.Error("GIT_TRACE should pass through via GIT_ prefix rule")
	}
	if !strings.Contains(joined, "PATH=/usr/bin") {
		t.Error("PATH should pass through via exact passthrough rule")
	}
}

func TestSafeEnvMode2StripsCredentialPrefixes(t *testing.T) {
	t.Setenv("GITHUB_TOKEN", "ghp_secret")
	t.Setenv("STRIPE_SECRET_KEY", "sk_live_secret")
	t.Setenv("NPM_TOKEN", "npm_secret")
	t.Setenv("DB_PASSWORD", "db_secret")
	t.Setenv("DATABASE_URL", "postgres://user:pass@host/db")

	env := safeEnvMode2(nil)
	joined := strings.Join(env, "\n")

	for _, key := range []string{"GITHUB_TOKEN=", "STRIPE_SECRET_KEY=", "NPM_TOKEN=", "DB_PASSWORD=", "DATABASE_URL="} {
		if strings.Contains(joined, key) {
			t.Errorf("credential prefix var %s should be stripped in Mode 2", key)
		}
	}
}

func TestSafeEnvMode2StripsKeys(t *testing.T) {
	// Set dangerous env vars that must be stripped
	t.Setenv("ANTHROPIC_API_KEY", "sk-ant-secret")
	t.Setenv("OPENAI_API_KEY", "sk-openai-secret")
	t.Setenv("CODEX_API_KEY", "codex-secret")
	t.Setenv("VAULT_TOKEN", "hvs-secret")
	t.Setenv("SLACK_BOT_TOKEN", "xoxb-secret")
	t.Setenv("SENTRY_AUTH_TOKEN", "sentry-secret")
	t.Setenv("SAFE_CUSTOM_VAR", "keep-this")

	env := safeEnvMode2(nil)
	joined := strings.Join(env, "\n")

	forbidden := []string{
		"ANTHROPIC_API_KEY=",
		"OPENAI_API_KEY=",
		"CODEX_API_KEY=",
		"VAULT_TOKEN=",
		"SLACK_BOT_TOKEN=",
		"SENTRY_AUTH_TOKEN=",
	}
	for _, key := range forbidden {
		if strings.Contains(joined, key) {
			t.Errorf("safeEnvMode2 should strip %s", key)
		}
	}
	if !strings.Contains(joined, "SAFE_CUSTOM_VAR=keep-this") {
		t.Error("safeEnvMode2 should preserve non-dangerous vars")
	}
}

func TestSafeEnvForAPIPool(t *testing.T) {
	// Strip any existing dangerous vars
	t.Setenv("ANTHROPIC_API_KEY", "should-be-overridden")
	t.Setenv("OPENAI_API_KEY", "should-be-stripped")

	env := safeEnvForAPIPool("pool-key-123", "https://litellm.example.com")
	joined := strings.Join(env, "\n")

	// The pool API key should be injected
	if !strings.Contains(joined, "ANTHROPIC_API_KEY=pool-key-123") {
		t.Error("safeEnvForAPIPool should inject ANTHROPIC_API_KEY with pool key")
	}
	// The base URL should be injected
	if !strings.Contains(joined, "ANTHROPIC_BASE_URL=https://litellm.example.com") {
		t.Error("safeEnvForAPIPool should inject ANTHROPIC_BASE_URL")
	}
	// Other dangerous vars should still be stripped
	if strings.Contains(joined, "OPENAI_API_KEY=") {
		t.Error("safeEnvForAPIPool should still strip OPENAI_API_KEY")
	}
}

func TestSafeEnvForAPIPoolNoBaseURL(t *testing.T) {
	env := safeEnvForAPIPool("pool-key-456", "")
	joined := strings.Join(env, "\n")

	if !strings.Contains(joined, "ANTHROPIC_API_KEY=pool-key-456") {
		t.Error("safeEnvForAPIPool should inject ANTHROPIC_API_KEY")
	}
	if strings.Contains(joined, "ANTHROPIC_BASE_URL=") {
		t.Error("safeEnvForAPIPool should not inject ANTHROPIC_BASE_URL when empty")
	}
}

func TestClaudeRunnerPrepareMergesHooks(t *testing.T) {
	// When hooks are installed, the settings JSON should include hook configuration.
	// We test this indirectly by verifying Prepare succeeds with hooks installed.
	dir := t.TempDir()
	hooksDir := dir + "/hooks"
	os.MkdirAll(hooksDir, 0755)
	os.WriteFile(hooksDir+"/pre-tool-use.sh", []byte("#!/bin/bash\nexit 0\n"), 0755)
	os.WriteFile(hooksDir+"/post-tool-use.sh", []byte("#!/bin/bash\nexit 0\n"), 0755)

	r := NewClaudeRunner("claude")
	_, err := r.Prepare(RunSpec{
		WorktreeDir: dir,
		RuntimeDir:  dir + "/runtime",
	})
	if err != nil {
		t.Fatal(err)
	}
	// If Prepare succeeds without error, hook merging did not crash
}
