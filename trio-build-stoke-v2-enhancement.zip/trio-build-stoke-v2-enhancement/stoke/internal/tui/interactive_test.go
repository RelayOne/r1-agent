package tui

import (
	"testing"
	"time"

	"github.com/ericmacdougall/stoke/internal/stream"
)

// ---- NewInteractiveModel ----

func TestNewInteractiveModel(t *testing.T) {
	m := NewInteractiveModel("plan-123", 5)
	if m == nil {
		t.Fatal("NewInteractiveModel should not return nil")
	}
	if m.planID != "plan-123" {
		t.Errorf("planID=%q", m.planID)
	}
	if m.totalTasks != 5 {
		t.Errorf("totalTasks=%d", m.totalTasks)
	}
	if m.taskIndex == nil {
		t.Error("taskIndex should be initialized")
	}
	if len(m.tasks) != 0 {
		t.Errorf("tasks len=%d, want 0", len(m.tasks))
	}
}

// ---- counts() ----

func TestCounts(t *testing.T) {
	m := &InteractiveModel{
		tasks: []TaskState{
			{ID: "t1", Status: "done"},
			{ID: "t2", Status: "failed"},
			{ID: "t3", Status: "active"},
			{ID: "t4", Status: "active"},
		},
	}
	done, failed, active := m.counts()
	if done != 1 || failed != 1 || active != 2 {
		t.Errorf("counts()=(%d,%d,%d), want (1,1,2)", done, failed, active)
	}
}

func TestCountsEmpty(t *testing.T) {
	m := &InteractiveModel{tasks: []TaskState{}}
	done, failed, active := m.counts()
	if done != 0 || failed != 0 || active != 0 {
		t.Errorf("counts()=(%d,%d,%d), want (0,0,0)", done, failed, active)
	}
}

// ---- taskIcon ----

func TestTaskIcon(t *testing.T) {
	icon, _ := taskIcon("done")
	if icon != "✓" {
		t.Errorf("done icon=%q, want ✓", icon)
	}

	icon, _ = taskIcon("failed")
	if icon != "✗" {
		t.Errorf("failed icon=%q, want ✗", icon)
	}

	icon, _ = taskIcon("active")
	if icon != "▸" {
		t.Errorf("active icon=%q, want ▸", icon)
	}

	icon, _ = taskIcon("unknown")
	if icon != "○" {
		t.Errorf("unknown icon=%q, want ○", icon)
	}
}

// ---- renderBar ----

func TestRenderBar(t *testing.T) {
	b := renderBar(50, 10)
	if len(b) == 0 {
		t.Fatal("renderBar should return non-empty string")
	}
}

func TestRenderBarFull(t *testing.T) {
	b := renderBar(100, 10)
	// Should be all full blocks (█) and no empty (░)
	if b == "" {
		t.Error("bar at 100% should not be empty")
	}
}

func TestRenderBarZero(t *testing.T) {
	b := renderBar(0, 10)
	if b == "" {
		t.Error("bar at 0% should not be empty")
	}
}

func TestRenderBarNegative(t *testing.T) {
	b := renderBar(-10, 10)
	// Should cap at 0
	if b == "" {
		t.Error("bar at negative should not be empty")
	}
}

func TestRenderBarOverflow(t *testing.T) {
	b := renderBar(150, 10)
	// Should cap at full width
	if b == "" {
		t.Error("bar at 150% should not be empty")
	}
}

// ---- truncStr ----

func TestTruncStr(t *testing.T) {
	if truncStr("hello", 10) != "hello" {
		t.Error("short string should pass through")
	}
}

func TestTruncStrTruncate(t *testing.T) {
	// truncStr keeps n-3 chars + "..." so "hello world" (11 chars) → "hello..." (8 chars)
	got := truncStr("hello world", 8)
	if got != "hello..." {
		t.Errorf("truncStr=%q, want \"hello...\"", got)
	}
}

func TestTruncStrExactly(t *testing.T) {
	got := truncStr("hello", 5)
	if got != "hello" {
		t.Errorf("exact length should pass through, got %q", got)
	}
}

func TestTruncStrNThree(t *testing.T) {
	got := truncStr("hello", 2)
	if got != "he" {
		t.Errorf("n<=3 should return first n chars, got %q", got)
	}
}

// ---- View: dashboard ----

func TestViewDashboardEmpty(t *testing.T) {
	m := NewInteractiveModel("plan-1", 0)
	view := m.viewDashboard()
	if view == "" {
		t.Error("dashboard view should not be empty")
	}
}

func TestViewDashboardWithTask(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.tasks = append(m.tasks, TaskState{
		ID:          "T1",
		Description: "Add auth middleware",
		Status:      "active",
		PoolID:      "claude-1",
	})
	view := m.viewDashboard()
	if view == "" {
		t.Error("dashboard view should not be empty")
	}
	if !containsStr(view, "T1") {
		t.Error("dashboard should show task ID")
	}
}

func TestViewDashboardWithCost(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.tasks = append(m.tasks, TaskState{
		ID:      "T1",
		Status:  "done",
		CostUSD: 0.05,
	})
	m.totalCost = 0.05
	view := m.viewDashboard()
	if !containsStr(view, "0.05") && !containsStr(view, "$") {
		// Cost should appear in the view somewhere
	}
}

// ---- View: focus ----

func TestViewFocusNoActiveTask(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.focusTask = "nonexistent"
	view := m.viewFocus()
	if !containsStr(view, "No active task") {
		t.Error("focus should say no active task")
	}
}

func TestViewFocusWithTask(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.tasks = []TaskState{
		{ID: "T1", Description: "Test task", Status: "active", PoolID: "claude-1"},
	}
	m.taskIndex["T1"] = 0
	m.focusTask = "T1"
	view := m.viewFocus()
	if !containsStr(view, "T1") {
		t.Error("focus view should show task")
	}
}

func TestViewFocusWithEvents(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.tasks = []TaskState{
		{
			ID:          "T1",
			Description: "Test",
			Status:      "active",
			PoolID:      "claude-1",
			Events: []stream.Event{
				{
					Type: "assistant",
					ToolUses: []stream.ToolUse{
						{Name: "Read", Input: map[string]interface{}{"file_path": "main.go"}},
					},
				},
			},
		},
	}
	m.taskIndex["T1"] = 0
	m.focusTask = "T1"
	view := m.viewFocus()
	if !containsStr(view, "Read") {
		t.Error("focus view should show tool use")
	}
}

// ---- View: detail ----

func TestViewDetailNotFound(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.detailTask = "nonexistent"
	view := m.viewDetail()
	if !containsStr(view, "not found") {
		t.Error("detail view should say task not found")
	}
}

func TestViewDetailWithTask(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.tasks = []TaskState{
		{
			ID:          "T1",
			Description: "Add auth",
			Status:      "done",
			PoolID:      "claude-1",
			CostUSD:     0.05,
			DurationSec: 12.5,
			Attempt:     2,
		},
	}
	m.taskIndex["T1"] = 0
	m.detailTask = "T1"
	view := m.viewDetail()
	if !containsStr(view, "T1") {
		t.Error("detail view should show task ID")
	}
}

func TestViewDetailWithError(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.tasks = []TaskState{
		{ID: "T1", Status: "failed", Error: "build failed"},
	}
	m.taskIndex["T1"] = 0
	m.detailTask = "T1"
	view := m.viewDetail()
	if !containsStr(view, "build failed") {
		t.Error("detail view should show error")
	}
}

func TestViewDetailWithVerdict(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.tasks = []TaskState{
		{ID: "T1", Status: "done", Verdict: "Approved: all checks pass"},
	}
	m.taskIndex["T1"] = 0
	m.detailTask = "T1"
	view := m.viewDetail()
	if !containsStr(view, "Claimed vs Verified") {
		t.Error("detail view should show verdict section")
	}
}

func TestViewDetailToolCounts(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.tasks = []TaskState{
		{
			ID:      "T1",
			Status:  "done",
			Events: []stream.Event{
				{ToolUses: []stream.ToolUse{{Name: "Read"}}},
				{ToolUses: []stream.ToolUse{{Name: "Edit"}}},
				{ToolUses: []stream.ToolUse{{Name: "Read"}}},
			},
		},
	}
	m.taskIndex["T1"] = 0
	m.detailTask = "T1"
	view := m.viewDetail()
	if !containsStr(view, "Tools used") {
		t.Error("detail view should show tools used section")
	}
}

// ---- Update: message handlers ----
// State transitions are driven by the message types defined in
// interactive.go (taskStartMsg, taskEventMsg, etc.). All keyboard
// shortcuts are exercised via the same Update() path.

func TestUpdateTaskStart(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.Update(taskStartMsg{id: "T1", desc: "First task", pool: "claude-1"})
	m.mu.Lock()
	defer m.mu.Unlock()
	if len(m.tasks) != 1 {
		t.Fatalf("len(tasks)=%d, want 1", len(m.tasks))
	}
	if m.tasks[0].ID != "T1" {
		t.Errorf("task ID=%q", m.tasks[0].ID)
	}
	if m.tasks[0].Status != "active" {
		t.Errorf("task status=%q, want active", m.tasks[0].Status)
	}
	if m.tasks[0].PoolID != "claude-1" {
		t.Errorf("pool ID=%q", m.tasks[0].PoolID)
	}
}

func TestUpdateTaskEvent(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.mu.Lock()
	m.tasks = []TaskState{{ID: "T1", Status: "active"}}
	m.taskIndex["T1"] = 0
	m.mu.Unlock()

	m.Update(taskEventMsg{
		id: "T1",
		ev: stream.Event{
			ToolUses: []stream.ToolUse{
				{Name: "Read", Input: map[string]interface{}{"file_path": "main.go"}},
			},
		},
	})

	m.mu.Lock()
	defer m.mu.Unlock()
	if len(m.tasks[0].Events) != 1 {
		t.Errorf("Events count=%d, want 1", len(m.tasks[0].Events))
	}
	if m.tasks[0].LastTool != "Read" {
		t.Errorf("LastTool=%q, want Read", m.tasks[0].LastTool)
	}
}

func TestUpdateTaskCompleteSuccess(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.mu.Lock()
	m.tasks = []TaskState{{ID: "T1", Status: "active"}}
	m.taskIndex["T1"] = 0
	m.mu.Unlock()

	m.Update(taskCompleteMsg{
		id: "T1", success: true, cost: 0.05, dur: 10.5, attempt: 1,
		verdict: "Approved",
	})

	m.mu.Lock()
	defer m.mu.Unlock()
	if m.tasks[0].Status != "done" {
		t.Errorf("status=%q, want done", m.tasks[0].Status)
	}
	if m.tasks[0].CostUSD != 0.05 {
		t.Errorf("cost=%.2f, want 0.05", m.tasks[0].CostUSD)
	}
	if m.tasks[0].Verdict != "Approved" {
		t.Errorf("verdict=%q", m.tasks[0].Verdict)
	}
}

func TestUpdateTaskCompleteFailure(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	m.mu.Lock()
	m.tasks = []TaskState{{ID: "T1", Status: "active"}}
	m.taskIndex["T1"] = 0
	m.mu.Unlock()

	m.Update(taskCompleteMsg{
		id: "T1", success: false, err: "build failed",
	})

	m.mu.Lock()
	defer m.mu.Unlock()
	if m.tasks[0].Status != "failed" {
		t.Errorf("status=%q, want failed", m.tasks[0].Status)
	}
	if m.tasks[0].Error != "build failed" {
		t.Errorf("error=%q", m.tasks[0].Error)
	}
}

func TestUpdateDoneMsg(t *testing.T) {
	m := NewInteractiveModel("plan-1", 1)
	_, cmd := m.Update(doneMsg{})
	if cmd == nil {
		t.Fatal("doneMsg should return a non-nil tea.Cmd")
	}
	m.mu.Lock()
	done := m.done
	m.mu.Unlock()
	if !done {
		t.Fatal("done flag should be set after doneMsg")
	}
}

// ---- PoolStatus helper ----

func TestPoolStatusDisplay(t *testing.T) {
	resetAt := time.Now().Add(2 * time.Hour)
	pools := []PoolInfo{
		{ID: "c1", Label: "Primary", Utilization: 45.0, ResetAt: resetAt},
	}
	// ResetAt must be in the future when the pool was created
	if resetAt.Before(time.Now()) {
		t.Fatalf("ResetAt=%v should be after now=%v", resetAt, time.Now())
	}
	// PoolStatus must not panic
	PoolStatus(pools)
}

// ---- Init ----

// ---- costDisplay ----

func TestCostDisplay(t *testing.T) {
	m := &InteractiveModel{
		tasks: []TaskState{
			{ID: "t1", Status: "done"},
			{ID: "t2", Status: "done"},
			{ID: "t3", Status: "failed"},
			{ID: "t4", Status: "active"},
		},
		totalCost: 0.1200,
	}
	got := m.costDisplay()
	// 3 completed (done+failed), avg = 0.12/3 = 0.04
	if !containsStr(got, "Total: $0.1200") {
		t.Errorf("costDisplay=%q, should contain Total: $0.1200", got)
	}
	if !containsStr(got, "Avg/task: $0.0400") {
		t.Errorf("costDisplay=%q, should contain Avg/task: $0.0400", got)
	}
}

func TestCostDisplayZeroTasks(t *testing.T) {
	m := &InteractiveModel{
		tasks:     []TaskState{},
		totalCost: 0.0,
	}
	got := m.costDisplay()
	if !containsStr(got, "Total: $0.0000") {
		t.Errorf("costDisplay=%q, should contain Total: $0.0000", got)
	}
	if !containsStr(got, "Avg/task: $0.0000") {
		t.Errorf("costDisplay=%q, should contain Avg/task: $0.0000", got)
	}
}

func TestCostDisplayOnlyActive(t *testing.T) {
	m := &InteractiveModel{
		tasks:     []TaskState{{ID: "t1", Status: "active"}},
		totalCost: 0.0,
	}
	got := m.costDisplay()
	// No done/failed tasks, avg should be 0
	if !containsStr(got, "Avg/task: $0.0000") {
		t.Errorf("costDisplay=%q, should contain Avg/task: $0.0000", got)
	}
}

// ---- renderPoolBar ----

func TestRenderPoolBarZero(t *testing.T) {
	p := PoolInfo{ID: "c1", Label: "idle", Utilization: 0}
	got := renderPoolBar(p)
	if !containsStr(got, "[c1]") {
		t.Errorf("renderPoolBar=%q, should contain pool ID", got)
	}
	if !containsStr(got, "0%") {
		t.Errorf("renderPoolBar=%q, should contain 0%%", got)
	}
	if !containsStr(got, "idle") {
		t.Errorf("renderPoolBar=%q, should contain label", got)
	}
	// Bar should be all spaces (20 wide)
	if !containsStr(got, "[                    ]") {
		t.Errorf("renderPoolBar=%q, should contain empty 20-char bar", got)
	}
}

func TestRenderPoolBarFifty(t *testing.T) {
	p := PoolInfo{ID: "c2", Label: "active", Utilization: 50}
	got := renderPoolBar(p)
	if !containsStr(got, "[c2]") {
		t.Errorf("renderPoolBar=%q, should contain pool ID", got)
	}
	if !containsStr(got, "50%") {
		t.Errorf("renderPoolBar=%q, should contain 50%%", got)
	}
	// 50% of 20 = 10 filled
	if !containsStr(got, "[==========          ]") {
		t.Errorf("renderPoolBar=%q, should contain half-filled 20-char bar", got)
	}
}

func TestRenderPoolBarFull(t *testing.T) {
	p := PoolInfo{ID: "c3", Label: "saturated", Utilization: 100}
	got := renderPoolBar(p)
	if !containsStr(got, "[c3]") {
		t.Errorf("renderPoolBar=%q, should contain pool ID", got)
	}
	if !containsStr(got, "100%") {
		t.Errorf("renderPoolBar=%q, should contain 100%%", got)
	}
	// Full bar: 20 = signs
	if !containsStr(got, "[====================]") {
		t.Errorf("renderPoolBar=%q, should contain full 20-char bar", got)
	}
}

// ---- helpers for testing ----

func containsStr(s, sub string) bool {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
