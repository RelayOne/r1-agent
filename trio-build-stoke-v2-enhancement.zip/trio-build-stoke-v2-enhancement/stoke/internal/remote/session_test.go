package remote

import (
	"testing"
)

func TestNewNoAPIKey(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "")
	r := New()
	if r != nil {
		t.Error("New() should return nil when EMBER_API_KEY is not set")
	}
}

func TestNewWithAPIKey(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key-xyz")
	r := New()
	if r == nil {
		t.Fatal("New() should return non-nil when EMBER_API_KEY is set")
	}
	if r.apiKey != "test-key-xyz" {
		t.Errorf("apiKey=%q", r.apiKey)
	}
}

func TestNewDefaultEndpoint(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key")
	t.Setenv("EMBER_API_URL", "")
	r := New()
	if r == nil {
		t.Fatal("New() should return non-nil")
	}
	if r.endpoint != "https://api.ember.dev" {
		t.Errorf("endpoint=%q", r.endpoint)
	}
}

func TestNewCustomEndpoint(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key")
	t.Setenv("EMBER_API_URL", "https://ember.corp.internal")
	r := New()
	if r == nil {
		t.Fatal("New() should return non-nil")
	}
	if r.endpoint != "https://ember.corp.internal" {
		t.Errorf("endpoint=%q", r.endpoint)
	}
}

func TestSessionIDNilReporter(t *testing.T) {
	var r *SessionReporter
	if r.SessionID() != "" {
		t.Error("SessionID() on nil reporter should return empty string")
	}
}

func TestWebURLNilReporter(t *testing.T) {
	var r *SessionReporter
	if r.WebURL() != "" {
		t.Error("WebURL() on nil reporter should return empty string")
	}
}

func TestWebURLEmptySessionID(t *testing.T) {
	r := &SessionReporter{sessionID: "", endpoint: "https://api.ember.dev"}
	if r.WebURL() != "" {
		t.Error("WebURL() with empty sessionID should return empty string")
	}
}

func TestWebURLWithSessionID(t *testing.T) {
	r := &SessionReporter{sessionID: "sess-abc123", endpoint: "https://api.ember.dev"}
	url := r.WebURL()
	if url == "" {
		t.Error("WebURL() should return non-empty string")
	}
	if url != "https://api.ember.dev/s/sess-abc123" {
		t.Errorf("WebURL()=%q", url)
	}
}

func TestRegisterSessionNilReporter(t *testing.T) {
	var r *SessionReporter
	_, err := r.RegisterSession("plan-1")
	if err != nil {
		t.Errorf("RegisterSession() on nil reporter should return nil error, got %v", err)
	}
}

func TestUpdateNilReporter(t *testing.T) {
	var r *SessionReporter
	err := r.Update(SessionUpdate{})
	if err != nil {
		t.Errorf("Update() on nil reporter should return nil error, got %v", err)
	}
}

func TestUpdateEmptySessionID(t *testing.T) {
	r := &SessionReporter{sessionID: ""}
	err := r.Update(SessionUpdate{})
	if err != nil {
		t.Errorf("Update() with empty sessionID should return nil error, got %v", err)
	}
}

func TestCompleteNilReporter(t *testing.T) {
	var r *SessionReporter
	err := r.Complete(true, "all done")
	if err != nil {
		t.Errorf("Complete() on nil reporter should return nil error, got %v", err)
	}
}

func TestCompleteEmptySessionID(t *testing.T) {
	r := &SessionReporter{sessionID: ""}
	err := r.Complete(true, "summary")
	if err != nil {
		t.Errorf("Complete() with empty sessionID should return nil error, got %v", err)
	}
}

func TestDoReqNilBody(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key")
	t.Setenv("EMBER_API_URL", "https://api.ember.dev")
	r := New()

	resp, err := r.doReq("GET", "/v1/health", nil)
	if err != nil {
		t.Skipf("ember endpoint not available: %v", err)
	}
	defer resp.Body.Close()
	// Any response (even 404) means the request was formed correctly
}

func TestDoReqWithBody(t *testing.T) {
	t.Setenv("EMBER_API_KEY", "test-key")
	t.Setenv("EMBER_API_URL", "https://api.ember.dev")
	r := New()

	// POST with a body should not cause a marshal error
	resp, err := r.doReq("POST", "/v1/health", map[string]string{"plan_id": "test"})
	if err != nil {
		t.Skipf("ember endpoint not available: %v", err)
	}
	defer resp.Body.Close()
	_ = resp // request formed correctly
}
