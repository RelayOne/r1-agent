package pools

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestLoadManifestFileNotExist(t *testing.T) {
	// Use a temp HOME so ManifestPath() returns a path in that directory
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	// ~/.stoke/pools/manifest.json definitely does not exist
	m, err := LoadManifest()
	if err != nil {
		t.Fatal(err)
	}
	if len(m.Pools) != 0 {
		t.Errorf("empty manifest: got %d pools", len(m.Pools))
	}
}

func TestLoadManifestParseError(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	// Create the manifest file with invalid JSON
	store := filepath.Join(tmp, ".stoke", "pools")
	if err := os.MkdirAll(store, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(store, "manifest.json"), []byte("{ invalid json"), 0600); err != nil {
		t.Fatal(err)
	}

	_, err := LoadManifest()
	if err == nil {
		t.Error("expected parse error")
	}
}

func TestManifestSaveAndReload(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	m := &Manifest{Pools: []Pool{
		{ID: "claude-1", Label: "Primary", ConfigDir: "/cfg/1", Provider: "claude", AccountID: "acct-1"},
		{ID: "codex-1", Label: "Secondary", ConfigDir: "/cfg/2", Provider: "codex", AccountID: "acct-2"},
	}}

	if err := m.Save(); err != nil {
		t.Fatal(err)
	}

	m2, err := LoadManifest()
	if err != nil {
		t.Fatal(err)
	}
	if len(m2.Pools) != 2 {
		t.Errorf("got %d pools, want 2", len(m2.Pools))
	}
	if m2.Pools[0].AccountID != "acct-1" {
		t.Errorf("AccountID=%q", m2.Pools[0].AccountID)
	}
}

func TestManifestFindByAccount(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "c1", AccountID: "a1"},
		{ID: "c2", AccountID: "a2"},
	}}

	p := m.FindByAccount("a2")
	if p == nil || p.ID != "c2" {
		t.Errorf("FindByAccount(a2)=%v, want c2", p)
	}

	p = m.FindByAccount("nonexistent")
	if p != nil {
		t.Error("FindByAccount(nonexistent) should return nil")
	}
}

func TestManifestClaudeDirs(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "c1", Provider: "claude", ConfigDir: "/cfg/1"},
		{ID: "cx1", Provider: "codex", ConfigDir: "/cfg/2"},
		{ID: "c2", Provider: "claude", ConfigDir: "/cfg/3"},
	}}

	dirs := m.ClaudeDirs()
	if len(dirs) != 2 {
		t.Errorf("ClaudeDirs()=%v, want 2", dirs)
	}
}

func TestManifestCodexDirs(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "cx1", Provider: "codex", ConfigDir: "/cfg/1"},
		{ID: "c1", Provider: "claude", ConfigDir: "/cfg/2"},
	}}

	dirs := m.CodexDirs()
	if len(dirs) != 1 || dirs[0] != "/cfg/1" {
		t.Errorf("CodexDirs()=%v", dirs)
	}
}

func TestManifestNextIDEmpty(t *testing.T) {
	m := &Manifest{}
	id := m.NextID("claude")
	if id != "claude-1" {
		t.Errorf("NextID(claude) on empty manifest=%q, want claude-1", id)
	}
}

func TestManifestNextIDSequential(t *testing.T) {
	m := &Manifest{Pools: []Pool{
		{ID: "claude-1"}, {ID: "claude-3"},
	}}
	id := m.NextID("claude")
	if id != "claude-4" {
		t.Errorf("NextID(claude)=%q, want claude-4", id)
	}
}

func TestManifestNextIDWrongProvider(t *testing.T) {
	m := &Manifest{Pools: []Pool{{ID: "claude-5"}}}
	id := m.NextID("codex")
	if id != "codex-1" {
		t.Errorf("NextID(codex)=%q, want codex-1", id)
	}
}

func TestReadAccountIDNoFile(t *testing.T) {
	result := readAccountID("/nonexistent/path")
	if result != "" {
		t.Errorf("readAccountID(nonexistent)=%q, want empty", result)
	}
}

func TestReadAccountIDEmail(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, ".credentials.json")
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{
			"email": "alice@example.com",
		},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readAccountID(dir)
	if result != "alice@example.com" {
		t.Errorf("readAccountID()=%q, want alice@example.com", result)
	}
}

func TestReadAccountIDAccountId(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, ".credentials.json")
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{
			"accountId": "acct_12345",
		},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readAccountID(dir)
	if result != "acct_12345" {
		t.Errorf("readAccountID()=%q, want acct_12345", result)
	}
}

func TestReadAccountIDTokenFallback(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, ".credentials.json")
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{
			"accessToken": "sk-ant-something",
		},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readAccountID(dir)
	// Token should be hashed, not returned raw
	if result == "" || result == "sk-ant-something" {
		t.Errorf("readAccountID()=%q — token should be hashed, not raw", result)
	}
}

func TestReadTokenNoFile(t *testing.T) {
	result := readToken("/nonexistent")
	if result != "" {
		t.Errorf("readToken(nonexistent)=%q, want empty", result)
	}
}

func TestReadTokenValid(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, ".credentials.json")
	creds := map[string]interface{}{
		"claudeAiOauth": map[string]interface{}{
			"accessToken": "sk-ant-test-token",
		},
	}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readToken(dir)
	if result != "sk-ant-test-token" {
		t.Errorf("readToken()=%q", result)
	}
}

func TestReadCodexAccountIDEmail(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, "credentials.json")
	creds := map[string]interface{}{"email": "bob@example.com"}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readCodexAccountID(dir)
	if result != "bob@example.com" {
		t.Errorf("readCodexAccountID()=%q, want bob@example.com", result)
	}
}

func TestReadCodexAccountIDToken(t *testing.T) {
	dir := t.TempDir()
	credFile := filepath.Join(dir, "credentials.json")
	creds := map[string]interface{}{"api_key": "sk-codex-test"}
	data, _ := json.Marshal(creds)
	os.WriteFile(credFile, data, 0600)

	result := readCodexAccountID(dir)
	// Token should be hashed
	if result == "" || result == "sk-codex-test" {
		t.Errorf("readCodexAccountID()=%q — token should be hashed", result)
	}
}

func TestReadCodexAccountIDNoCreds(t *testing.T) {
	result := readCodexAccountID("/nonexistent")
	if result != "" {
		t.Errorf("readCodexAccountID()=%q, want empty", result)
	}
}

func TestCopyCredentials(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()

	os.WriteFile(filepath.Join(src, "auth.json"), []byte(`{"token":"abc"}`), 0600)
	os.WriteFile(filepath.Join(src, "config.json"), []byte(`{"key":"val"}`), 0600)
	os.MkdirAll(filepath.Join(src, "subdir"), 0700)
	os.WriteFile(filepath.Join(src, "subdir", "nested.json"), []byte(`{}`), 0600)

	if err := copyCredentials(src, dst); err != nil {
		t.Fatal(err)
	}

	for _, name := range []string{"auth.json", "config.json"} {
		if _, err := os.Stat(filepath.Join(dst, name)); err != nil {
			t.Errorf("file %s not copied: %v", name, err)
		}
	}

	// subdir should be skipped
	if _, err := os.Stat(filepath.Join(dst, "subdir")); !os.IsNotExist(err) {
		t.Error("subdirectories should be skipped by copyCredentials")
	}
}

func TestRemovePoolFound(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	m := &Manifest{Pools: []Pool{
		{ID: "c1", ConfigDir: filepath.Join(tmp, "cfg1")},
		{ID: "c2", ConfigDir: filepath.Join(tmp, "cfg2")},
	}}
	os.MkdirAll(filepath.Join(tmp, "cfg1"), 0755)
	os.MkdirAll(filepath.Join(tmp, "cfg2"), 0755)

	if err := m.Save(); err != nil {
		t.Fatal(err)
	}

	if err := RemovePool("c1"); err != nil {
		t.Fatal(err)
	}

	m2, _ := LoadManifest()
	if len(m2.Pools) != 1 || m2.Pools[0].ID != "c2" {
		t.Errorf("after remove: got %v", m2.Pools)
	}
}

func TestRemovePoolNotFound(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)

	err := RemovePool("nonexistent")
	if err == nil {
		t.Error("expected error for nonexistent pool")
	}
}
