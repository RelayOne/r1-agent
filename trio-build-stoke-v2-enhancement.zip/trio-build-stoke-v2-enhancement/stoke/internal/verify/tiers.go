package verify

// VerificationTier determines the depth of verification applied to a task.
type VerificationTier int

const (
	TierLight    VerificationTier = iota // <3 files AND <50 diff lines: build+lint only
	TierStandard                         // <15 files AND <500 diff lines: full pipeline
	TierThorough                         // >=15 files OR >=500 diff lines: full + security scan
)

func (t VerificationTier) String() string {
	switch t {
	case TierLight:
		return "light"
	case TierStandard:
		return "standard"
	case TierThorough:
		return "thorough"
	default:
		return "unknown"
	}
}

// ClassifyChange determines the verification tier based on change scope.
func ClassifyChange(fileCount int, diffLines int) VerificationTier {
	if fileCount < 3 && diffLines < 50 {
		return TierLight
	}
	if fileCount >= 15 || diffLines >= 500 {
		return TierThorough
	}
	return TierStandard
}
