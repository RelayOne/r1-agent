package verify

import "testing"

func TestClassifyChange_Light(t *testing.T) {
	tier := ClassifyChange(1, 20)
	if tier != TierLight {
		t.Errorf("1 file, 20 lines: got %s, want light", tier)
	}
}

func TestClassifyChange_Standard(t *testing.T) {
	tier := ClassifyChange(5, 200)
	if tier != TierStandard {
		t.Errorf("5 files, 200 lines: got %s, want standard", tier)
	}
}

func TestClassifyChange_Thorough(t *testing.T) {
	tier := ClassifyChange(20, 800)
	if tier != TierThorough {
		t.Errorf("20 files, 800 lines: got %s, want thorough", tier)
	}
}

func TestClassifyChange_FilesLightButLinesNot(t *testing.T) {
	// 2 files < 3 but 60 lines >= 50 → not light, should be standard
	tier := ClassifyChange(2, 60)
	if tier != TierStandard {
		t.Errorf("2 files, 60 lines: got %s, want standard", tier)
	}
}

func TestClassifyChange_FilesTriggersThrough(t *testing.T) {
	// 15 files >= 15 → thorough even with low diff lines
	tier := ClassifyChange(15, 40)
	if tier != TierThorough {
		t.Errorf("15 files, 40 lines: got %s, want thorough", tier)
	}
}

func TestVerificationTier_String(t *testing.T) {
	tests := []struct {
		tier VerificationTier
		want string
	}{
		{TierLight, "light"},
		{TierStandard, "standard"},
		{TierThorough, "thorough"},
		{VerificationTier(99), "unknown"},
	}
	for _, tt := range tests {
		got := tt.tier.String()
		if got != tt.want {
			t.Errorf("VerificationTier(%d).String() = %q, want %q", tt.tier, got, tt.want)
		}
	}
}
