#!/bin/bash
# Stoke comprehensive test runner
# Usage: ./test.sh [--quick|--full|--coverage|--race]
set -uo pipefail
# Note: NOT using set -e because grep returns exit 1 when no matches found,
# which is expected behavior (e.g., zero test failures = grep finds nothing).

STOKE_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$STOKE_DIR"

MODE="${1:-full}"
MODE="${MODE#--}"  # strip leading --
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BOLD='\033[1m'
NC='\033[0m'

pass() { echo -e "${GREEN}PASS${NC} $1"; }
fail() { echo -e "${RED}FAIL${NC} $1"; FAILURES=$((FAILURES + 1)); }
warn() { echo -e "${YELLOW}WARN${NC} $1"; }
FAILURES=0
START_TIME=$(date +%s)

echo -e "${BOLD}Stoke Test Runner${NC}"
echo "Mode: $MODE"
echo "---"

# --- Stage 1: Build ---
echo -e "\n${BOLD}[1/6] Build${NC}"
if go build ./cmd/stoke 2>&1; then
    pass "go build ./cmd/stoke"
else
    fail "go build ./cmd/stoke"
    echo "Build failed — cannot continue."
    exit 1
fi

# --- Stage 2: Vet ---
echo -e "\n${BOLD}[2/6] Vet${NC}"
VET_OUTPUT=$(go vet ./... 2>&1)
if [ -z "$VET_OUTPUT" ]; then
    pass "go vet ./..."
else
    fail "go vet: $VET_OUTPUT"
fi

# --- Stage 3: Tests ---
echo -e "\n${BOLD}[3/6] Tests${NC}"
if [ "$MODE" = "quick" ]; then
    # Quick: just run tests, no coverage
    TEST_OUTPUT=$(go test ./... -count=1 -timeout 120s 2>&1)
    PASS_COUNT=$(echo "$TEST_OUTPUT" | grep -cE "^ok " || true)
    FAIL_COUNT=$(echo "$TEST_OUTPUT" | grep -cE "^FAIL" || true)
    echo "$TEST_OUTPUT" | grep -E "^(ok |FAIL)" | head -40
    if [ "$FAIL_COUNT" -gt 0 ]; then
        fail "tests: $FAIL_COUNT packages failed"
        echo "$TEST_OUTPUT" | grep -A5 "^FAIL"
    else
        pass "tests: $PASS_COUNT packages pass"
    fi
elif [ "$MODE" = "race" ]; then
    # Race detector
    echo "Running with race detector (slower)..."
    TEST_OUTPUT=$(go test ./... -race -count=1 -timeout 300s 2>&1)
    PASS_COUNT=$(echo "$TEST_OUTPUT" | grep -cE "^ok " || true)
    FAIL_COUNT=$(echo "$TEST_OUTPUT" | grep -cE "^FAIL" || true)
    RACE_COUNT=$(echo "$TEST_OUTPUT" | grep -cE "DATA RACE" || true)
    echo "$TEST_OUTPUT" | grep -E "^(ok |FAIL)" | head -40
    if [ "$RACE_COUNT" -gt 0 ]; then
        fail "race detector: $RACE_COUNT data races found"
        echo "$TEST_OUTPUT" | grep -B2 -A10 "DATA RACE"
    elif [ "$FAIL_COUNT" -gt 0 ]; then
        fail "tests: $FAIL_COUNT packages failed"
    else
        pass "tests: $PASS_COUNT packages pass (race-clean)"
    fi
else
    # Full: with coverage
    TEST_OUTPUT=$(go test ./... -coverprofile=/tmp/stoke-coverage.out -count=1 -timeout 180s 2>&1)
    PASS_COUNT=$(echo "$TEST_OUTPUT" | grep -cE "^ok " || true)
    FAIL_COUNT=$(echo "$TEST_OUTPUT" | grep -cE "^FAIL" || true)
    echo "$TEST_OUTPUT" | grep -E "^(ok |FAIL)" | head -40
    if [ "$FAIL_COUNT" -gt 0 ]; then
        fail "tests: $FAIL_COUNT packages failed"
        echo "$TEST_OUTPUT" | grep -A5 "^FAIL"
    else
        pass "tests: $PASS_COUNT packages pass"
    fi
fi

# --- Stage 4: Test function count ---
echo -e "\n${BOLD}[4/6] Test Metrics${NC}"
FUNC_COUNT=$(go test ./... -v -count=1 -timeout 180s 2>&1 | grep -c "\-\-\- PASS:" || true)
echo "  Test functions: $FUNC_COUNT"
if [ "$FUNC_COUNT" -lt 400 ]; then
    warn "test functions below 400 threshold ($FUNC_COUNT)"
fi

# --- Stage 5: Coverage analysis ---
if [ "$MODE" = "full" ] || [ "$MODE" = "coverage" ]; then
    echo -e "\n${BOLD}[5/6] Coverage Analysis${NC}"
    if [ -f /tmp/stoke-coverage.out ]; then
        TOTAL_COV=$(go tool cover -func=/tmp/stoke-coverage.out 2>/dev/null | grep "total:" | awk '{print $3}')
        echo "  Total coverage: $TOTAL_COV"

        # Show low-coverage packages
        echo "  Low coverage packages (<50%):"
        go test ./... -cover -count=1 -timeout 180s 2>&1 | grep -E "^ok.*coverage:" | while read -r line; do
            cov=$(echo "$line" | grep -oP '\d+\.\d+%' | head -1)
            cov_num=$(echo "$cov" | tr -d '%')
            pkg=$(echo "$line" | awk '{print $2}')
            if [ "$(echo "$cov_num < 50" | bc -l 2>/dev/null || echo 0)" = "1" ]; then
                echo -e "    ${YELLOW}$pkg: $cov${NC}"
            fi
        done 2>/dev/null || true

        # Generate HTML report
        if [ "$MODE" = "coverage" ]; then
            go tool cover -html=/tmp/stoke-coverage.out -o /tmp/stoke-coverage.html 2>/dev/null
            echo "  HTML report: /tmp/stoke-coverage.html"
        fi
    else
        warn "no coverage data (run with --full or --coverage)"
    fi
else
    echo -e "\n${BOLD}[5/6] Coverage${NC} (skipped in $MODE mode)"
fi

# --- Stage 6: Binary smoke test ---
echo -e "\n${BOLD}[6/6] Binary Smoke Test${NC}"
STOKE_BIN="$STOKE_DIR/stoke"
if [ -f "$STOKE_BIN" ]; then
    # Version
    VERSION=$("$STOKE_BIN" version 2>&1 || true)
    if [ -n "$VERSION" ]; then
        pass "stoke version: $VERSION"
    else
        fail "stoke version returned empty"
    fi

    # Help
    HELP=$("$STOKE_BIN" help 2>&1 || true)
    if echo "$HELP" | grep -q "stoke"; then
        pass "stoke help output valid"
    else
        fail "stoke help output invalid"
    fi

    # Doctor
    DOCTOR=$("$STOKE_BIN" doctor 2>&1 || true)
    pass "stoke doctor ran"

    # Scan dry run (on our own codebase)
    SCAN=$("$STOKE_BIN" scan --no-slop 2>&1 || true)
    pass "stoke scan completed"

    # Print default policy
    POLICY=$("$STOKE_BIN" print-default-policy 2>&1 || true)
    if echo "$POLICY" | grep -q "phases:"; then
        pass "stoke print-default-policy valid YAML"
    else
        fail "stoke print-default-policy invalid"
    fi
else
    warn "stoke binary not found at $STOKE_BIN (run 'go build ./cmd/stoke' first)"
fi

# --- Summary ---
END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))

echo ""
echo -e "${BOLD}=== Summary ===${NC}"
echo "  Duration: ${ELAPSED}s"
echo "  Packages: $PASS_COUNT pass"
echo "  Functions: $FUNC_COUNT"
if [ -n "${TOTAL_COV:-}" ]; then
    echo "  Coverage: $TOTAL_COV"
fi

if [ "$FAILURES" -gt 0 ]; then
    echo -e "  ${RED}${BOLD}$FAILURES FAILURE(S)${NC}"
    exit 1
else
    echo -e "  ${GREEN}${BOLD}ALL PASS${NC}"
    exit 0
fi
