# Feature Map

## Stoke -- AI Coding Orchestrator

| Feature | Benefit | Status |
|---|---|---|
| Single-task execution (`stoke run`) | One command to plan, execute, verify, and commit a code change | Done |
| Multi-task parallel build (`stoke build`) | Execute entire project plans with parallel agents and dependency ordering | Done |
| Plan generation (`stoke plan`) | AI analyzes codebase and generates a task plan with dependencies and ROI | Done |
| Deterministic code scan (`stoke scan`) | Find secrets, eval, injection, debug code without AI cost | Done |
| Multi-perspective audit (`stoke audit`) | 17 specialized personas review the codebase from different angles | Done |
| Session management (`stoke status`) | Track progress, cost, and learned patterns across sessions | Done |
| Pool management (`stoke pool`, `pools`, `add-claude`, `add-codex`, `remove-pool`) | Manage multiple Claude/Codex subscription pools with circuit breakers | Done |
| Interactive TUI (`--interactive`) | Bubble Tea dashboard with focus/detail modes and keyboard navigation | Done |
| ROI filter (`--roi`) | Skip low-value tasks before execution to optimize time and cost | Done |
| 5-provider fallback chain | Automatic failover: Claude -> Codex -> OpenRouter -> API -> lint-only | Done |
| 11-layer policy engine | Defense in depth from CLI flags to sandbox to enforcer hooks | Done |
| Cross-model review gate | Claude implements, Codex reviews (or vice versa) to catch model-specific errors | Done |
| Intelligent retry (10 failure classes) | Classify failures, inject context, clean worktree per retry, escalate on repeat | Done |
| Scope enforcement | Agents can only modify files declared in task.files | Done |
| Protected file guard | Blocks modifications to .claude/, .stoke/, CLAUDE.md, .env*, policy files | Done |
| SQLite session store | Persistent session storage with WAL mode as alternative to JSON files | Done |
| Auto-detect build/test/lint | Detects Node.js, Go, Rust, Python project commands automatically | Done |
| `stoke yolo` | Fast-path execution with relaxed verification | Done |
| `stoke scope` | Interactive scoping conversation with research | Done |
| `stoke repair` | Targeted repair execution | Done |
| `stoke ship` | Programmatic build execution | Done |
| `stoke doctor` | Verify tool dependencies are installed | Done |
| Remote worker provisioning via ember | Spawn cloud workers for parallel execution | In Progress |
| Managed AI model routing | Ember-managed model routing for cost optimization | In Progress |

## Ember -- Cloud Dev Environment Platform

| Feature | Benefit | Status |
|---|---|---|
| CLI machines (ttyd + dtach) | Terminal-based dev environment in the browser | Done |
| VS Code machines (code-server) | Full IDE with extensions in the browser | Done |
| Stripe billing (4/8/16 vCPU tiers) | Subscription-based machine provisioning with slot management | Done |
| GitHub OAuth login | One-click sign-in with GitHub | Done |
| Google OAuth login | One-click sign-in with Google | Done |
| GitHub App for private repos | Secure access to private repositories without personal tokens | Done |
| Exchange-code terminal auth | Secure iframe-based terminal access with HMAC session cookies | Done |
| Multi-pane grid dashboard | Customizable layout with hot-swappable machine panes | Done |
| Machine reconciliation | Background loop stops machines for cancelled subscriptions, retries failures | Done |
| Health monitoring (`/api/health/detailed`) | Machine and slot status with degraded state alerts | Done |
| Rate limiting (per-endpoint) | In-memory or Postgres-backed sliding window rate limiting | Done |
| CSRF protection | Origin header validation on all state-changing requests | Done |
| Custom domains (`*.ember.dev`) | Branded machine hostnames with TLS certificate provisioning | Done |
| Persistent volumes | `/workspace` survives stop/start cycles | Done |
| Credit ledger (PL/pgSQL) | Precise billing credits and usage tracking | Done |
| Stoke worker API | Enable stoke to provision and manage workers programmatically | In Progress |
| Multi-region support | Deploy machines in multiple Fly.io regions | Scoping |
| Team workspaces | Shared machine pools for teams | Horizon |
| Flare backend migration | Replace Fly.io with self-hosted flare infrastructure | Scoped |

## Flare -- Firecracker MicroVM Infrastructure

| Feature | Benefit | Status |
|---|---|---|
| Fly-compatible REST API | Drop-in replacement for Fly Machines API | Done |
| App management (CRUD) | Namespace machines into logical applications | Done |
| Machine lifecycle (create/start/stop/destroy) | Full VM lifecycle with atomic capacity scheduling | Done |
| Split desired/observed state | Honest state reporting for distributed system consistency | Done |
| Generated hostnames (`*.ember.dev`) | Automatic hostname assignment for every machine | Done |
| Custom hostnames | Bring your own domain for machine access | Done |
| Cloudflare Tunnel ingress | TLS termination and hostname-based routing | Done |
| Placement daemon with recovery | Per-host VM management with disk-based crash recovery | Done |
| Host health monitoring | 90-second heartbeat timeout with dead host detection | Done |
| Atomic capacity scheduling | `SELECT FOR UPDATE SKIP LOCKED` prevents over-provisioning | Done |
| GCP Terraform infrastructure | One-command infrastructure deployment | Done |
| TypeScript SDK | Type-safe client for the flare API | Done |
| Persistent volumes | Stateful machines with file-backed ext4 volumes | Scoped |
| Guest agent for exec | Remote command execution inside running VMs | Scoped |
| Control plane HA | Cloud SQL + multiple replicas for high availability | Scoped |
| OCI image support | Use Docker/OCI images instead of baked ext4 | Horizon |
| Tenant billing and quotas | Multi-tenant resource management | Horizon |
| Live migration | Move running VMs between hosts without downtime | Horizon |
| Snapshot/restore | Point-in-time VM snapshots | Horizon |

## Cross-Component Integration

| Feature | Benefit | Status |
|---|---|---|
| stoke -> ember worker provisioning | AI orchestrator spawns cloud workers on demand | In Progress |
| ember -> Fly.io machine provisioning | Cloud platform provisions machines on Fly infrastructure | Done |
| ember -> flare machine provisioning | Cloud platform provisions machines on self-hosted infrastructure | Scoped |
| End-to-end: stoke -> ember -> flare | Full vertical integration from task to VM | Horizon |

---
*Last updated: 2026-04-01*
