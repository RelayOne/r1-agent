# [Project Name]

<!-- WHAT: One paragraph explaining what this project does and why it exists -->

## What It Does

<!-- Clear, non-technical explanation of the product's function -->

## Why It Exists

<!-- The problem it solves. Who has this problem. Why existing solutions fall short. -->

## How to Use It

<!-- End-user instructions. What does someone DO with this? -->

## How to Run It

<!-- Developer setup: clone, install, configure, run -->
```bash
# Setup steps here
```

## How to Interact With It

<!-- APIs, CLIs, UIs, integrations — how do systems and people talk to this -->

## Project Status

### Done
### In Progress
### Scoped (ready to build)
### Scoping (researching)
### On Horizon (potential)

## Documentation
- [Architecture](ARCHITECTURE.md) — repo map, tech stack, data models, API surface
- [How It Works](HOW-IT-WORKS.md) — user journey and technical walkthrough
- [Feature Map](FEATURE-MAP.md) — all features with benefits and status
- [Deployment](DEPLOYMENT.md) — how to deploy and operate
- [Business Value](BUSINESS-VALUE.md) — who it's for, why they want it, what it delivers

---
*Last updated: YYYY-MM-DD*
